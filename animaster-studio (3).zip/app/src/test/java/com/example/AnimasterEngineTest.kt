package com.example

import com.example.data.model.AnimationLayer
import com.example.data.model.EasingType
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.engine.InterpolationEngine
import com.example.engine.MotionPreset
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.engine.StoryboardTemplate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot

class AnimasterEngineTest {

    @Test
    fun interpolation_easingAndKeyframes() {
        val layer = AnimationLayer(
            keyframes = listOf(
                TransformKeyframe(frame = 0, x = 0f, y = 0f, scaleX = 1f, easing = EasingType.LINEAR.name),
                TransformKeyframe(frame = 10, x = 100f, y = -50f, scaleX = 2f, easing = EasingType.LINEAR.name)
            )
        )
        val mid = InterpolationEngine.evaluateLayerTransform(layer, frame = 5, totalFrames = 20)
        assertEquals(50f, mid.x, 0.01f)
        assertEquals(-25f, mid.y, 0.01f)
        assertEquals(1.5f, mid.scaleX, 0.01f)
    }

    @Test
    fun rigSolver_fkAndTwoBoneIk() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 400f)
        val fk = RigSolver.solveForwardKinematics(rig)
        assertEquals(rig.bones.size, fk.size)

        val currentAngles = rig.bones.associate { it.id to it.localAngleDeg }
        val target = Vec2(600f, 340f)
        val solvedAngles = RigSolver.solveDragTarget(rig, "arm_r_low", target, currentAngles, useIk = true)
        val fkAfter = RigSolver.solveForwardKinematics(rig, solvedAngles)
        val hand = fkAfter.first { it.bone.id == "arm_r_low" }
        assertTrue(hypot(hand.end.x - target.x, hand.end.y - target.y) < 35f)
    }

    @Test
    fun proceduralTemplatesAndSvgParser() {
        val proj = ProceduralSmartTools.createProjectFromTemplate("Test", 1280, 720, 24, StoryboardTemplate.THREE_ACT_STORY)
        assertEquals(3, proj.scenes.size)

        val movedLayer = ProceduralSmartTools.applyMotionPreset(AnimationLayer(), MotionPreset.BOUNCE_LOOP, 36)
        assertTrue(movedLayer.keyframes.size >= 3)

        val svg = """<svg><rect x="10" y="20" width="100" height="50"/><circle cx="60" cy="60" r="30"/></svg>"""
        val shapes = SceneRenderer.parseSimpleSvgShapes(svg, 1280f, 720f)
        assertEquals(2, shapes.size)
    }
}
