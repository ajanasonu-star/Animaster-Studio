package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AnimasterDatabase
import com.example.data.local.ProjectRepository
import com.example.engine.ProceduralSmartTools
import com.example.engine.StoryboardTemplate
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProjectRepositoryTest {

    @Test
    fun saveAndLoadAllTemplates_roundTripSucceeds() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AnimasterDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ProjectRepository(db.projectDao(), db.localAssetDao())

        for (tpl in StoryboardTemplate.entries) {
            val proj = ProceduralSmartTools.createProjectFromTemplate("Proj_${tpl.name}", 1280, 720, 24, tpl)
            repo.saveProject(proj, isRecovery = false)
            val loaded = repo.loadProject(proj.id)
            assertNotNull("Failed to reload template $tpl", loaded)
            assertEquals(proj.name, loaded!!.name)
            assertEquals(proj.scenes.size, loaded.scenes.size)
            assertEquals(proj.scenes.first().layers.size, loaded.scenes.first().layers.size)
        }
        db.close()
    }
}
