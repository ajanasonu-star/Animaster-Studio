package com.example.data.local

import com.example.data.model.AnimationProject
import com.example.data.model.ProjectSummary
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ProjectRepository(
    private val projectDao: ProjectDao,
    private val assetDao: LocalAssetDao
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val projectAdapter = moshi.adapter(AnimationProject::class.java)

    val projectsFlow: Flow<List<ProjectSummary>> = projectDao.observeAllProjects().map { list ->
        list.map { entity ->
            ProjectSummary(
                id = entity.id,
                name = entity.name,
                width = entity.width,
                height = entity.height,
                fps = entity.fps,
                sceneCount = entity.sceneCount,
                updatedAt = entity.updatedAt,
                isRecoverySnapshot = entity.isRecoverySnapshot
            )
        }
    }

    val recoverySnapshotFlow: Flow<ProjectSummary?> = projectDao.observeRecoverySnapshot().map { entity ->
        entity?.let {
            ProjectSummary(
                id = it.id,
                name = it.name,
                width = it.width,
                height = it.height,
                fps = it.fps,
                sceneCount = it.sceneCount,
                updatedAt = it.updatedAt,
                isRecoverySnapshot = true
            )
        }
    }

    val assetsFlow: Flow<List<LocalAssetEntity>> = assetDao.observeAllAssets()

    suspend fun getProjectCount(): Int = withContext(Dispatchers.IO) {
        projectDao.getProjectCount()
    }

    suspend fun saveProject(project: AnimationProject, isRecovery: Boolean = false) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val updated = project.copy(updatedAt = now)
        val json = projectAdapter.toJson(updated)
        val entity = ProjectEntity(
            id = if (isRecovery) "recovery_${updated.id}" else updated.id,
            name = updated.name,
            width = updated.width,
            height = updated.height,
            fps = updated.fps,
            sceneCount = updated.scenes.size,
            jsonPayload = json,
            isRecoverySnapshot = isRecovery,
            createdAt = updated.createdAt,
            updatedAt = now
        )
        if (isRecovery) {
            projectDao.clearRecoverySnapshots()
        }
        projectDao.upsertProject(entity)
    }

    suspend fun loadProject(projectId: String): AnimationProject? = withContext(Dispatchers.IO) {
        val entity = projectDao.getProjectById(projectId) ?: return@withContext null
        runCatching { projectAdapter.fromJson(entity.jsonPayload) }.getOrNull()
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        projectDao.deleteProjectById(projectId)
    }

    suspend fun clearRecovery() = withContext(Dispatchers.IO) {
        projectDao.clearRecoverySnapshots()
    }

    suspend fun exportProjectToJson(project: AnimationProject): String = withContext(Dispatchers.IO) {
        projectAdapter.indent("  ").toJson(project)
    }

    suspend fun importProjectFromJson(json: String): AnimationProject? = withContext(Dispatchers.IO) {
        runCatching { projectAdapter.fromJson(json) }.getOrNull()
    }

    suspend fun saveLocalAsset(asset: LocalAssetEntity) = withContext(Dispatchers.IO) {
        assetDao.upsertAsset(asset)
    }

    suspend fun deleteLocalAsset(id: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById(id)
    }
}
