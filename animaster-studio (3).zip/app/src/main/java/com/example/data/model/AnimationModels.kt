package com.example.data.model

import com.squareup.moshi.JsonClass
import java.util.UUID

enum class EditorTool(val label: String, val shortcut: String) {
    PENCIL("Pencil", "P"),
    BRUSH("Brush", "B"),
    AIRBRUSH("Airbrush", "A"),
    ERASER("Eraser", "E"),
    BUCKET("Fill", "G"),
    PEN_BEZIER("Bezier", "N"),
    LINE("Line", "L"),
    RECTANGLE("Rect", "R"),
    CIRCLE("Circle", "C"),
    POLYGON("Poly", "Y"),
    TEXT("Text", "T"),
    EYEDROPPER("Picker", "I"),
    SELECT("Select", "V"),
    RIG_EDIT("Rig", "K"),
    MOTION_PATH("Path", "M"),
    HAND_PAN("Pan", "H")
}

enum class LayerType(val displayName: String) {
    DRAWING("Vector & Raster"),
    CHARACTER("Character"),
    RIG("Skeletal Rig"),
    BACKGROUND("Background"),
    FOREGROUND("Foreground")
}

enum class EasingType(val displayName: String) {
    LINEAR("Linear"),
    EASE_IN("Ease In"),
    EASE_OUT("Ease Out"),
    EASE_IN_OUT("Ease In-Out"),
    BOUNCE("Bounce")
}

enum class SceneTransition(val displayName: String) {
    CUT("Cut"),
    FADE("Crossfade"),
    SLIDE_LEFT("Slide Left"),
    ZOOM_IN("Zoom In")
}

enum class BackgroundTemplate(val displayName: String) {
    SOLID("Solid Canvas"),
    SUNNY_MEADOW("Sunny Meadow"),
    CYBERPUNK_CITY("Neon City"),
    COZY_STUDIO("Cozy Studio"),
    OUTER_SPACE("Deep Space"),
    SUNSET_DESERT("Sunset Dunes"),
    GRID_PAPER("Animator Grid")
}

enum class ShapeKind {
    LINE, RECTANGLE, CIRCLE, POLYGON, FILL_BACKDROP
}

enum class AudioTrackKind(val displayName: String) {
    VOICE("Voice"),
    SFX("SFX"),
    MUSIC("Music")
}

enum class ExportFormat(val label: String, val ext: String, val mime: String) {
    PNG("PNG Frame", "png", "image/png"),
    PNG_SEQUENCE("PNG Sequence (ZIP)", "zip", "application/zip"),
    GIF("Animated GIF", "gif", "image/gif"),
    MP4("MP4 Video (H.264)", "mp4", "video/mp4"),
    WEBM("WebM Video (VP8)", "webm", "video/webm")
}

@JsonClass(generateAdapter = true)
data class Vec2(
    val x: Float,
    val y: Float
)

@JsonClass(generateAdapter = true)
data class DrawStroke(
    val id: String = UUID.randomUUID().toString(),
    val tool: String = EditorTool.BRUSH.name,
    val points: List<Vec2> = emptyList(),
    val colorArgb: Long = 0xFFFFFFFFL,
    val gradientEndArgb: Long? = null,
    val strokeWidth: Float = 8f,
    val opacity: Float = 1f,
    val isClosedBezier: Boolean = false
)

@JsonClass(generateAdapter = true)
data class VectorShape(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = ShapeKind.RECTANGLE.name,
    val startX: Float = 0f,
    val startY: Float = 0f,
    val endX: Float = 100f,
    val endY: Float = 100f,
    val polygonSides: Int = 5,
    val strokeColorArgb: Long = 0xFFFFFFFFL,
    val fillColorArgb: Long? = null,
    val gradientEndArgb: Long? = null,
    val strokeWidth: Float = 5f,
    val opacity: Float = 1f,
    val rotationDeg: Float = 0f
)

@JsonClass(generateAdapter = true)
data class CanvasTextItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Hello!",
    val x: Float = 320f,
    val y: Float = 180f,
    val fontSize: Float = 44f,
    val colorArgb: Long = 0xFFFFFFFFL,
    val isBold: Boolean = true
)

@JsonClass(generateAdapter = true)
data class ImportedImageItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Image",
    val filePath: String = "",
    val x: Float = 320f,
    val y: Float = 180f,
    val width: Float = 320f,
    val height: Float = 240f,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f
)

@JsonClass(generateAdapter = true)
data class CharacterSpec(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nova",
    val x: Float = 640f,
    val y: Float = 380f,
    val scale: Float = 1f,
    val skinToneArgb: Long = 0xFFF5C6A5L,
    val faceShape: String = "OVAL", // OVAL, ROUND, SQUARE, CHIBI
    val eyeStyle: String = "ANIME", // ANIME, DOT, CARTOON, COOL, STAR
    val eyeColorArgb: Long = 0xFF2DD4BFL,
    val mouthStyle: String = "SMILE", // SMILE, OPEN, SMIRK, CAT, O_SHAPE
    val expression: String = "HAPPY", // NEUTRAL, HAPPY, SURPRISED, ANGRY, SAD, WINK, TALKING
    val hairStyle: String = "SPIKY", // SPIKY, BOB, PONYTAIL, CURLY, MOHAWK, BALD
    val hairColorArgb: Long = 0xFF252B3AL,
    val shirtStyle: String = "HOODIE", // HOODIE, TEE, JACKET, CAPE, TUNIC
    val shirtColorArgb: Long = 0xFFFF6B35L,
    val pantsColorArgb: Long = 0xFF1E293BL,
    val accessory: String = "NONE", // NONE, GLASSES, HEADPHONES, CROWN, SCARF, HAT
    val pose: String = "IDLE" // IDLE, WAVE, WALK_A, WALK_B, JUMP, HERO, SIT
)

@JsonClass(generateAdapter = true)
data class RigBone(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Bone",
    val parentId: String? = null,
    val length: Float = 75f,
    val localAngleDeg: Float = -90f,
    val thickness: Float = 18f,
    val colorArgb: Long = 0xFF2DD4BFL
)

@JsonClass(generateAdapter = true)
data class SkeletalRig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Hero Rig",
    val rootX: Float = 640f,
    val rootY: Float = 390f,
    val bones: List<RigBone> = emptyList(),
    // Map of frameIndex (as String for Moshi JSON) -> Map<boneId, angleDeg>
    val poseKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    val showSkinMesh: Boolean = true,
    val ikEnabled: Boolean = true
)

@JsonClass(generateAdapter = true)
data class FrameContent(
    val strokes: List<DrawStroke> = emptyList(),
    val shapes: List<VectorShape> = emptyList(),
    val texts: List<CanvasTextItem> = emptyList(),
    val images: List<ImportedImageItem> = emptyList(),
    val characterOverride: CharacterSpec? = null
)

@JsonClass(generateAdapter = true)
data class TransformKeyframe(
    val frame: Int = 0,
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val opacity: Float = 1f,
    val easing: String = EasingType.EASE_IN_OUT.name
)

@JsonClass(generateAdapter = true)
data class CameraKeyframe(
    val frame: Int = 0,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val rotationDeg: Float = 0f,
    val easing: String = EasingType.EASE_IN_OUT.name
)

@JsonClass(generateAdapter = true)
data class AnimationLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Layer 1",
    val type: String = LayerType.DRAWING.name,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val opacity: Float = 1f,
    val parallaxDepth: Float = 1f,
    // Keyed by frame index string so Moshi serializes cleanly
    val frames: Map<String, FrameContent> = emptyMap(),
    val keyframes: List<TransformKeyframe> = emptyList(),
    val motionPath: List<Vec2> = emptyList(),
    val character: CharacterSpec? = null,
    val rig: SkeletalRig? = null
)

@JsonClass(generateAdapter = true)
data class AnimationScene(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Scene 1",
    val durationFrames: Int = 48,
    val backgroundColorArgb: Long = 0xFF141824L,
    val backgroundTemplate: String = BackgroundTemplate.SUNNY_MEADOW.name,
    val transition: String = SceneTransition.FADE.name,
    val layers: List<AnimationLayer> = emptyList(),
    val cameraKeyframes: List<CameraKeyframe> = listOf(CameraKeyframe(frame = 0))
)

@JsonClass(generateAdapter = true)
data class AudioTrackItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Track 1",
    val filePath: String = "",
    val kind: String = AudioTrackKind.SFX.name,
    val startFrame: Int = 0,
    val durationMs: Long = 2000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 2000L,
    val volume: Float = 0.85f,
    val fadeInMs: Long = 100L,
    val fadeOutMs: Long = 150L,
    val muted: Boolean = false,
    val waveformPeaks: List<Float> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AnimationProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Animation",
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 24,
    val scenes: List<AnimationScene> = emptyList(),
    val activeSceneId: String = "",
    val audioTracks: List<AudioTrackItem> = emptyList(),
    val savedCharacters: List<CharacterSpec> = emptyList(),
    val savedRigs: List<SkeletalRig> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class ProjectSummary(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val sceneCount: Int,
    val updatedAt: Long,
    val isRecoverySnapshot: Boolean = false
)

data class ExportSettings(
    val format: ExportFormat = ExportFormat.GIF,
    val width: Int = 960,
    val height: Int = 540,
    val fps: Int = 24,
    val quality: Int = 85,
    val startFrame: Int = 0,
    val endFrame: Int = 47
)
