package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AnimationLayer
import com.example.data.model.AudioTrackItem
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioBorderSubtle
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

@Composable
fun TimelinePanel(
    uiState: StudioUiState,
    onTogglePlay: () -> Unit,
    onStepFrame: (Int) -> Unit,
    onSelectFrame: (Int) -> Unit,
    onSelectLayer: (String) -> Unit,
    onSetFps: (Int) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleOnionSkin: () -> Unit,
    onToggleGhostFrames: () -> Unit,
    onAddBlankCel: () -> Unit,
    onDuplicateCel: () -> Unit,
    onInsertKeyframe: () -> Unit,
    modifier: Modifier = Modifier
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val totalFrames = scene.durationFrames.coerceAtLeast(1)
    val horizontalScroll = rememberScrollState()
    var fpsMenuExpanded by remember { mutableStateOf(false) }
    var tracksExpanded by remember { mutableStateOf(true) }

    val seconds = uiState.currentFrame.toFloat() / project.fps.coerceAtLeast(1).toFloat()
    val timecode = String.format("F%02d/%02d • %04.1fs", uiState.currentFrame + 1, totalFrames, seconds)

    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 1. Transport & Keyframe Control Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StudioSurfaceVariant)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = { onStepFrame(-1) },
                    modifier = Modifier.size(38.dp).testTag("timeline_prev_frame")
                ) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous frame", tint = StudioTextPrimary)
                }
                Surface(
                    color = StudioCoral,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onTogglePlay)
                        .testTag("timeline_play_pause")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (uiState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (uiState.isPlaying) "Pause" else "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                IconButton(
                    onClick = { onStepFrame(1) },
                    modifier = Modifier.size(38.dp).testTag("timeline_next_frame")
                ) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next frame", tint = StudioTextPrimary)
                }

                // Loop toggle
                TimelineToggleChip(
                    label = "Loop",
                    active = uiState.isLooping,
                    accent = StudioCyan,
                    onClick = onToggleLoop
                )

                // Timecode badge
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioBorder)
                ) {
                    Text(
                        text = timecode,
                        style = MaterialTheme.typography.labelMedium,
                        color = StudioTextPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                // FPS Selector
                Box {
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clickable { fpsMenuExpanded = true }
                            .testTag("fps_selector")
                    ) {
                        Text(
                            text = "${project.fps} FPS",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioAmber,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = fpsMenuExpanded,
                        onDismissRequest = { fpsMenuExpanded = false }
                    ) {
                        listOf(12, 24, 30, 60).forEach { fps ->
                            DropdownMenuItem(
                                text = { Text("$fps FPS") },
                                onClick = {
                                    fpsMenuExpanded = false
                                    onSetFps(fps)
                                }
                            )
                        }
                    }
                }

                TimelineToggleChip(
                    label = "Onion",
                    active = uiState.onionSkinEnabled,
                    accent = StudioViolet,
                    onClick = onToggleOnionSkin
                )
                TimelineToggleChip(
                    label = "Ghost",
                    active = uiState.ghostFramesEnabled,
                    accent = StudioCyan,
                    onClick = onToggleGhostFrames
                )

                TimelineActionPill(
                    icon = Icons.Rounded.Add,
                    label = "Cel",
                    tint = StudioTextPrimary,
                    onClick = onAddBlankCel
                )
                TimelineActionPill(
                    icon = Icons.Rounded.ContentCopy,
                    label = "Dup",
                    tint = StudioTextPrimary,
                    onClick = onDuplicateCel
                )
                TimelineActionPill(
                    icon = Icons.Rounded.Diamond,
                    label = "Key",
                    tint = StudioViolet,
                    onClick = onInsertKeyframe
                )
                IconButton(
                    onClick = { tracksExpanded = !tracksExpanded },
                    modifier = Modifier.size(34.dp).testTag("timeline_collapse_toggle")
                ) {
                    Icon(
                        imageVector = if (tracksExpanded) Icons.Rounded.ExpandMore else Icons.Rounded.ExpandLess,
                        contentDescription = if (tracksExpanded) "Collapse tracks" else "Expand tracks",
                        tint = StudioTextSecondary
                    )
                }
            }

            HorizontalDivider(color = StudioBorder)

            // Smooth Playhead Scrubber Bar
            if (totalFrames > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .background(StudioSurface)
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("SCRUB", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                    Slider(
                        value = uiState.currentFrame.toFloat(),
                        onValueChange = { onSelectFrame(it.toInt()) },
                        valueRange = 0f..(totalFrames - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = StudioCoral,
                            activeTrackColor = StudioCoral,
                            inactiveTrackColor = StudioBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("timeline_scrubber")
                    )
                }
            }

            if (tracksExpanded) {
            // 2. Frame Ruler Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .background(StudioSurface)
            ) {
                Box(
                    modifier = Modifier
                        .width(108.dp)
                        .fillMaxHeight()
                        .background(StudioSurfaceVariant)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text("TRACKS", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                }
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .horizontalScroll(horizontalScroll)
                ) {
                    for (f in 0 until totalFrames) {
                        val isCurrent = f == uiState.currentFrame
                        Box(
                            modifier = Modifier
                                .width(26.dp)
                                .fillMaxHeight()
                                .background(if (isCurrent) StudioCoral else Color.Transparent)
                                .border(0.5.dp, StudioBorderSubtle)
                                .clickable { onSelectFrame(f) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isCurrent || f % 4 == 0) "${f + 1}" else "·",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isCurrent) Color.Black else StudioTextMuted,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = StudioBorderSubtle)

            // 3. Multi-Track Lanes (Layers + Camera + Audio)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(118.dp),
                contentPadding = PaddingValues(bottom = 4.dp)
            ) {
                items(scene.layers.reversed(), key = { it.id }) { layer ->
                    LayerTimelineRow(
                        layer = layer,
                        totalFrames = totalFrames,
                        currentFrame = uiState.currentFrame,
                        isSelected = layer.id == uiState.selectedLayer?.id,
                        scrollState = horizontalScroll,
                        onSelectLayer = { onSelectLayer(layer.id) },
                        onSelectFrame = onSelectFrame
                    )
                }

                // Camera Track
                item(key = "camera_track") {
                    CameraTimelineRow(
                        keyframeFrames = scene.cameraKeyframes.map { it.frame }.toSet(),
                        totalFrames = totalFrames,
                        currentFrame = uiState.currentFrame,
                        scrollState = horizontalScroll,
                        onSelectFrame = onSelectFrame
                    )
                }

                // Audio Tracks
                items(project.audioTracks, key = { it.id }) { audio ->
                    AudioTimelineRow(
                        track = audio,
                        fps = project.fps,
                        totalFrames = totalFrames,
                        currentFrame = uiState.currentFrame,
                        scrollState = horizontalScroll,
                        onSelectFrame = onSelectFrame
                    )
                }
            }
            }
        }
    }
}

@Composable
private fun LayerTimelineRow(
    layer: AnimationLayer,
    totalFrames: Int,
    currentFrame: Int,
    isSelected: Boolean,
    scrollState: androidx.compose.foundation.ScrollState,
    onSelectLayer: () -> Unit,
    onSelectFrame: (Int) -> Unit
) {
    val keyframeSet = remember(layer.keyframes) { layer.keyframes.map { it.frame }.toSet() }
    val rigPoseSet = remember(layer.rig?.poseKeyframes) {
        layer.rig?.poseKeyframes?.keys?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(if (isSelected) StudioSurfaceElevated else StudioSurface)
    ) {
        Row(
            modifier = Modifier
                .width(108.dp)
                .fillMaxHeight()
                .clickable(onClick = onSelectLayer)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) StudioCoral else if (layer.visible) StudioCyan else StudioTextMuted)
            )
            Text(
                text = layer.name,
                style = MaterialTheme.typography.bodySmall,
                color = if (isSelected) StudioTextPrimary else StudioTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .horizontalScroll(scrollState)
        ) {
            for (f in 0 until totalFrames) {
                val hasCel = layer.frames.containsKey(f.toString())
                val hasKf = keyframeSet.contains(f) || rigPoseSet.contains(f)
                val isCurrent = f == currentFrame
                Box(
                    modifier = Modifier
                        .width(26.dp)
                        .fillMaxHeight()
                        .background(
                            when {
                                isCurrent -> StudioCoral.copy(alpha = 0.22f)
                                hasCel -> StudioCyan.copy(alpha = 0.14f)
                                else -> Color.Transparent
                            }
                        )
                        .border(0.5.dp, StudioBorderSubtle)
                        .clickable {
                            onSelectLayer()
                            onSelectFrame(f)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (hasKf) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .rotate(45f)
                                .background(StudioViolet)
                        )
                    } else if (hasCel) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(StudioCyan)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CameraTimelineRow(
    keyframeFrames: Set<Int>,
    totalFrames: Int,
    currentFrame: Int,
    scrollState: androidx.compose.foundation.ScrollState,
    onSelectFrame: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
            .background(StudioSurface)
    ) {
        Row(
            modifier = Modifier
                .width(108.dp)
                .fillMaxHeight()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(Icons.Rounded.Videocam, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(13.dp))
            Text("Camera", style = MaterialTheme.typography.bodySmall, color = StudioAmber)
        }
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .horizontalScroll(scrollState)
        ) {
            for (f in 0 until totalFrames) {
                val hasKf = keyframeFrames.contains(f)
                Box(
                    modifier = Modifier
                        .width(26.dp)
                        .fillMaxHeight()
                        .background(if (f == currentFrame) StudioCoral.copy(alpha = 0.18f) else Color.Transparent)
                        .border(0.5.dp, StudioBorderSubtle)
                        .clickable { onSelectFrame(f) },
                    contentAlignment = Alignment.Center
                ) {
                    if (hasKf) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .rotate(45f)
                                .background(StudioAmber)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioTimelineRow(
    track: AudioTrackItem,
    fps: Int,
    totalFrames: Int,
    currentFrame: Int,
    scrollState: androidx.compose.foundation.ScrollState,
    onSelectFrame: (Int) -> Unit
) {
    val clipFrames = (((track.trimEndMs - track.trimStartMs).coerceAtLeast(200L) / 1000f) * fps).toInt().coerceAtLeast(2)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
            .background(StudioSurface)
    ) {
        Row(
            modifier = Modifier
                .width(108.dp)
                .fillMaxHeight()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(13.dp))
            Text(
                track.name,
                style = MaterialTheme.typography.bodySmall,
                color = if (track.muted) StudioTextMuted else StudioEmerald,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .horizontalScroll(scrollState)
        ) {
            for (f in 0 until totalFrames) {
                val inside = f >= track.startFrame && f < track.startFrame + clipFrames
                val peakIdx = if (inside && track.waveformPeaks.isNotEmpty()) {
                    (((f - track.startFrame).toFloat() / clipFrames) * track.waveformPeaks.size).toInt()
                        .coerceIn(0, track.waveformPeaks.lastIndex)
                } else -1
                val barH = if (peakIdx >= 0) (track.waveformPeaks[peakIdx] * 18f).coerceIn(3f, 18f) else 0f

                Box(
                    modifier = Modifier
                        .width(26.dp)
                        .fillMaxHeight()
                        .background(
                            when {
                                f == currentFrame -> StudioCoral.copy(alpha = 0.2f)
                                inside -> StudioEmerald.copy(alpha = if (track.muted) 0.08f else 0.18f)
                                else -> Color.Transparent
                            }
                        )
                        .border(0.5.dp, StudioBorderSubtle)
                        .clickable { onSelectFrame(f) },
                    contentAlignment = Alignment.Center
                ) {
                    if (inside) {
                        Box(
                            modifier = Modifier
                                .width(12.dp)
                                .height(barH.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (track.muted) StudioTextMuted else StudioEmerald)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelineToggleChip(
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) accent.copy(alpha = 0.2f) else StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (active) accent else StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) accent else StudioTextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun TimelineActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        color = StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
        }
    }
}
