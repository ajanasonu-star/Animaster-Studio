package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.MovieCreation
import androidx.compose.material.icons.rounded.OfflinePin
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ProjectSummary
import com.example.engine.StoryboardTemplate
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProjectHubScreen(
    projects: List<ProjectSummary>,
    recoverySnapshot: ProjectSummary?,
    statusBanner: String? = null,
    onOpenProject: (String) -> Unit,
    onCreateProject: (name: String, width: Int, height: Int, fps: Int, template: StoryboardTemplate) -> Unit,
    onDeleteProject: (String) -> Unit,
    onImportProject: () -> Unit,
    onRecoverAutosave: (String) -> Unit,
    onDismissRecovery: () -> Unit
) {
    var showNewDialog by remember { mutableStateOf(false) }
    var preselectedTemplate by remember { mutableStateOf(StoryboardTemplate.HERO_DEMO) }

    Scaffold(
        containerColor = StudioBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWide = maxWidth >= 720.dp
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding(),
                contentPadding = PaddingValues(horizontal = if (isWide) 28.dp else 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Hero Studio Banner
                item {
                    StudioHeroHeader(
                        isWide = isWide,
                        onNewProject = {
                            preselectedTemplate = StoryboardTemplate.HERO_DEMO
                            showNewDialog = true
                        },
                        onImportProject = onImportProject
                    )
                }

                // Autosave Recovery Banner
                if (recoverySnapshot != null) {
                    item {
                        RecoveryBannerCard(
                            snapshot = recoverySnapshot,
                            onRecover = { onRecoverAutosave(recoverySnapshot.id) },
                            onDismiss = onDismissRecovery
                        )
                    }
                }

                // Quick-Start Storyboard Templates
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Quick-Start Templates",
                                style = MaterialTheme.typography.titleLarge,
                                color = StudioTextPrimary
                            )
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(StoryboardTemplate.entries) { template ->
                                TemplateCard(
                                    template = template,
                                    onClick = {
                                        preselectedTemplate = template
                                        showNewDialog = true
                                    }
                                )
                            }
                        }
                    }
                }

                // Recent Projects Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Local Projects (${projects.size})",
                            style = MaterialTheme.typography.titleLarge,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "Stored Offline",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioCyan
                        )
                    }
                }

                // Projects List / Grid
                if (projects.isEmpty()) {
                    item {
                        Surface(
                            color = StudioSurface,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, StudioBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Rounded.MovieCreation,
                                    contentDescription = null,
                                    tint = StudioTextMuted,
                                    modifier = Modifier.size(40.dp)
                                )
                                Text(
                                    text = "No projects yet",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = StudioTextPrimary
                                )
                                Text(
                                    text = "Start from a blank canvas or storyboard template above.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StudioTextSecondary
                                )
                            }
                        }
                    }
                } else {
                    val rows = if (isWide) projects.chunked(2) else projects.map { listOf(it) }
                    items(rows) { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowItems.forEach { proj ->
                                ProjectCard(
                                    project = proj,
                                    modifier = Modifier.weight(1f),
                                    onOpen = { onOpenProject(proj.id) },
                                    onDelete = { onDeleteProject(proj.id) }
                                )
                            }
                            if (isWide && rowItems.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            if (statusBanner != null) {
                Surface(
                    color = StudioSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCoral),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 24.dp)
                ) {
                    Text(
                        text = statusBanner,
                        style = MaterialTheme.typography.labelMedium,
                        color = StudioTextPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }

    if (showNewDialog) {
        NewProjectDialog(
            initialTemplate = preselectedTemplate,
            onDismiss = { showNewDialog = false },
            onCreate = { name, w, h, fps, tpl ->
                showNewDialog = false
                onCreateProject(name, w, h, fps, tpl)
            }
        )
    }
}

@Composable
private fun StudioHeroHeader(
    isWide: Boolean,
    onNewProject: () -> Unit,
    onImportProject: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (isWide) 210.dp else 196.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, StudioBorder, RoundedCornerShape(20.dp))
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_studio_hero_1795056095811),
            contentDescription = "Animaster Studio Workspace Banner",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xEE0D0F14),
                            Color(0xBB0D0F14),
                            Color(0x550D0F14)
                        )
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = StudioCoral.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Rounded.OfflinePin,
                            contentDescription = null,
                            tint = StudioCoral,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "100% OFFLINE STUDIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCoral
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "ANIMASTER STUDIO",
                    style = MaterialTheme.typography.displaySmall,
                    color = StudioTextPrimary
                )
                Text(
                    text = "2D Vector & Raster Drawing • Rigging • Timeline • Local Export",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudioTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onNewProject,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("new_project_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New Project", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onImportProject,
                    border = BorderStroke(1.dp, StudioBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = StudioSurface.copy(alpha = 0.75f),
                        contentColor = StudioTextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("import_project_button")
                ) {
                    Icon(Icons.Rounded.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Import")
                }
            }
        }
    }
}

@Composable
private fun RecoveryBannerCard(
    snapshot: ProjectSummary,
    onRecover: () -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        color = StudioAmber.copy(alpha = 0.12f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Rounded.Restore, contentDescription = null, tint = StudioAmber)
            Column(modifier = Modifier.weight(1f)) {
                Text("Autosave Recovery Available", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                Text("\"${snapshot.name}\" • ${snapshot.fps} FPS", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
            }
            TextButton(onClick = onDismiss) { Text("Dismiss", color = StudioTextSecondary) }
            Button(
                onClick = onRecover,
                colors = ButtonDefaults.buttonColors(containerColor = StudioAmber, contentColor = Color.Black),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Recover", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TemplateCard(
    template: StoryboardTemplate,
    onClick: () -> Unit
) {
    val accent = when (template) {
        StoryboardTemplate.BLANK_STUDIO -> StudioTextSecondary
        StoryboardTemplate.HERO_DEMO -> StudioCoral
        StoryboardTemplate.THREE_ACT_STORY -> StudioCyan
        StoryboardTemplate.BOUNCE_STUDY -> StudioViolet
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = BorderStroke(1.dp, StudioBorder),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(210.dp)
            .clickable(onClick = onClick)
            .testTag("template_${template.name.lowercase()}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(accent)
            )
            Text(
                text = template.title,
                style = MaterialTheme.typography.titleMedium,
                color = StudioTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = template.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = StudioTextSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ProjectCard(
    project: ProjectSummary,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val formattedDate = remember(project.updatedAt) {
        SimpleDateFormat("MMM dd • HH:mm", Locale.getDefault()).format(Date(project.updatedAt))
    }
    Card(
        onClick = onOpen,
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = BorderStroke(1.dp, StudioBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.testTag("project_card_${project.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(StudioSurfaceElevated, StudioCoral.copy(alpha = 0.25f))
                        )
                    )
                    .border(1.dp, StudioBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    contentDescription = "Open ${project.name}",
                    tint = StudioCoral,
                    modifier = Modifier.size(28.dp)
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = project.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = StudioTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MetaPill("${project.width}×${project.height}")
                    MetaPill("${project.fps} FPS")
                    MetaPill("${project.sceneCount} Scene${if (project.sceneCount == 1) "" else "s"}")
                }
                Text(
                    text = "Updated $formattedDate",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextMuted
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("delete_project_${project.id}")
            ) {
                Icon(
                    Icons.Rounded.DeleteOutline,
                    contentDescription = "Delete project",
                    tint = StudioTextMuted
                )
            }
        }
    }
}

@Composable
private fun MetaPill(text: String) {
    Surface(
        color = StudioSurfaceVariant,
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = StudioTextSecondary,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun NewProjectDialog(
    initialTemplate: StoryboardTemplate,
    onDismiss: () -> Unit,
    onCreate: (name: String, width: Int, height: Int, fps: Int, template: StoryboardTemplate) -> Unit
) {
    var name by remember { mutableStateOf("My Cartoon") }
    var selectedRes by remember { mutableIntStateOf(0) }
    var selectedFps by remember { mutableIntStateOf(24) }
    var selectedTemplate by remember { mutableStateOf(initialTemplate) }

    val resolutions = listOf(
        Triple("HD 16:9", 1280, 720),
        Triple("Full HD", 1920, 1080),
        Triple("Square 1:1", 1080, 1080),
        Triple("Shorts 9:16", 720, 1280)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface,
        title = { Text("New Animation Project", color = StudioTextPrimary) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("project_name_input")
                )
                Text("Canvas Resolution", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(resolutions.indices.toList()) { idx ->
                        FilterChip(
                            selected = selectedRes == idx,
                            onClick = { selectedRes = idx },
                            label = { Text(resolutions[idx].first) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = StudioCoral.copy(alpha = 0.25f))
                        )
                    }
                }
                Text("Frame Rate (FPS)", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(12, 24, 30, 60).forEach { fps ->
                        FilterChip(
                            selected = selectedFps == fps,
                            onClick = { selectedFps = fps },
                            label = { Text("$fps") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = StudioCyan.copy(alpha = 0.25f))
                        )
                    }
                }
                Text("Starter Template", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(StoryboardTemplate.entries) { tpl ->
                        FilterChip(
                            selected = selectedTemplate == tpl,
                            onClick = { selectedTemplate = tpl },
                            label = { Text(tpl.title) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val res = resolutions[selectedRes]
                    onCreate(name, res.second, res.third, selectedFps, selectedTemplate)
                },
                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                modifier = Modifier.testTag("confirm_new_project_button")
            ) {
                Text("Create Studio", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = StudioTextSecondary) }
        }
    )
}
