package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Polyline
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.LocalAssetEntity
import com.example.data.model.CharacterSpec
import com.example.data.model.EasingType
import com.example.data.model.LayerType
import com.example.data.model.SkeletalRig
import com.example.engine.MotionPreset
import com.example.engine.ProceduralPropKind
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

val StudioColorSwatches = listOf(
    0xFFFFFFFFL, 0xFF0F172AL, 0xFFFF6B35L, 0xFFFB7185L,
    0xFFFBBF24L, 0xFF34D399L, 0xFF2DD4BFL, 0xFF38BDF8L,
    0xFF818CF8L, 0xFFA78BFAL, 0xFFF472B6L, 0xFF94A3B8L
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LayersInspectorPanel(
    uiState: StudioUiState,
    onSelectLayer: (String) -> Unit,
    onAddLayer: (LayerType) -> Unit,
    onDeleteLayer: (String) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onToggleLock: (String) -> Unit,
    onMoveOrder: (String, Boolean) -> Unit,
    onUpdateOpacity: (String, Float) -> Unit,
    onUpdateParallax: (String, Float) -> Unit,
    onApplyMotionPreset: (MotionPreset) -> Unit,
    onClearCel: () -> Unit,
    onClearMotionPath: () -> Unit
) {
    val scene = uiState.activeScene ?: return
    val selected = uiState.selectedLayer

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Add Layer", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                LayerType.entries.forEach { type ->
                    Surface(
                        color = StudioSurfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onAddLayer(type) }
                            .testTag("add_layer_${type.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(14.dp))
                            Text(type.displayName, style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary)
                        }
                    }
                }
            }
        }

        items(scene.layers.reversed(), key = { it.id }) { layer ->
            val isSel = layer.id == selected?.id
            Surface(
                color = if (isSel) StudioSurfaceElevated else StudioSurfaceVariant,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (isSel) StudioCoral else StudioBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectLayer(layer.id) }
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val icon = when (layer.type) {
                            LayerType.CHARACTER.name -> Icons.Rounded.Face
                            LayerType.RIG.name -> Icons.Rounded.AccessibilityNew
                            else -> Icons.Rounded.Brush
                        }
                        Icon(icon, contentDescription = null, tint = if (isSel) StudioCoral else StudioCyan, modifier = Modifier.size(18.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                layer.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = StudioTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "${layer.type} • ${layer.keyframes.size} KF",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        }
                        IconButton(onClick = { onToggleVisibility(layer.id) }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                if (layer.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                contentDescription = "Toggle visibility",
                                tint = if (layer.visible) StudioTextPrimary else StudioTextMuted,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(onClick = { onToggleLock(layer.id) }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                if (layer.locked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                                contentDescription = "Toggle lock",
                                tint = if (layer.locked) StudioCoral else StudioTextMuted,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(onClick = { onMoveOrder(layer.id, true) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move up", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { onMoveOrder(layer.id, false) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move down", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                        }
                        if (scene.layers.size > 1) {
                            IconButton(onClick = { onDeleteLayer(layer.id) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete layer", tint = StudioRose, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    if (isSel) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Opacity ${(layer.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                            Slider(
                                value = layer.opacity,
                                onValueChange = { onUpdateOpacity(layer.id, it) },
                                valueRange = 0f..1f,
                                colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Parallax ${String.format("%.2fx", layer.parallaxDepth)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                            Slider(
                                value = layer.parallaxDepth,
                                onValueChange = { onUpdateParallax(layer.id, it) },
                                valueRange = 0.3f..1.8f,
                                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, tint = StudioViolet, modifier = Modifier.size(16.dp))
                Text("Offline Motion Presets", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
            }
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MotionPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { onApplyMotionPreset(preset) },
                        label = { Text(preset.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onClearCel, modifier = Modifier.weight(1f)) {
                    Text("Clear Cel", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = onClearMotionPath, modifier = Modifier.weight(1f)) {
                    Text("Clear Path", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertiesInspectorPanel(
    uiState: StudioUiState,
    onSetPrimaryColor: (Long) -> Unit,
    onSetGradientColor: (Long) -> Unit,
    onToggleGradient: (Boolean) -> Unit,
    onSetBrushSize: (Float) -> Unit,
    onSetBrushOpacity: (Float) -> Unit,
    onToggleFillShapes: (Boolean) -> Unit,
    onSetPolygonSides: (Int) -> Unit,
    onSetEasing: (EasingType) -> Unit,
    onNudgeTransform: (Float, Float, Float, Float) -> Unit,
    onInsertKeyframe: () -> Unit,
    onDeleteKeyframe: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Color & Gradient", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StudioColorSwatches.forEach { argb ->
                    val selected = uiState.primaryColorArgb == argb
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .border(if (selected) 3.dp else 1.dp, if (selected) StudioCoral else StudioBorder, CircleShape)
                            .clickable { onSetPrimaryColor(argb) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Gradient Fill / Stroke", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                Switch(checked = uiState.useGradient, onCheckedChange = onToggleGradient)
            }
            if (uiState.useGradient) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StudioColorSwatches.forEach { argb ->
                        val selected = uiState.gradientColorArgb == argb
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .border(if (selected) 2.5.dp else 1.dp, if (selected) StudioCyan else StudioBorder, CircleShape)
                                .clickable { onSetGradientColor(argb) }
                        )
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Stroke & Shape Settings", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Size ${uiState.brushSize.toInt()}px", style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary, modifier = Modifier.width(78.dp))
                Slider(
                    value = uiState.brushSize,
                    onValueChange = onSetBrushSize,
                    valueRange = 1f..64f,
                    colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Alpha ${(uiState.brushOpacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary, modifier = Modifier.width(78.dp))
                Slider(
                    value = uiState.brushOpacity,
                    onValueChange = onSetBrushOpacity,
                    valueRange = 0.1f..1f,
                    colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Fill Closed Shapes", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                Switch(checked = uiState.fillShapes, onCheckedChange = onToggleFillShapes)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Polygon ${uiState.polygonSides} sides", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(105.dp))
                Slider(
                    value = uiState.polygonSides.toFloat(),
                    onValueChange = { onSetPolygonSides(it.toInt()) },
                    valueRange = 3f..10f,
                    steps = 6,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Keyframe & Transform", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                EasingType.entries.forEach { easing ->
                    FilterChip(
                        selected = uiState.activeEasing == easing,
                        onClick = { onSetEasing(easing) },
                        label = { Text(easing.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, -15f, 0f) }, modifier = Modifier.weight(1f)) {
                    Text("-15°", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, 15f, 0f) }, modifier = Modifier.weight(1f)) {
                    Text("+15°", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, 0f, -0.15f) }, modifier = Modifier.weight(1f)) {
                    Text("-Scale", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, 0f, 0.15f) }, modifier = Modifier.weight(1f)) {
                    Text("+Scale", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onInsertKeyframe,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioViolet, contentColor = Color.Black),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Set Keyframe", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(onClick = onDeleteKeyframe, modifier = Modifier.weight(1f)) {
                    Text("Remove KF", style = MaterialTheme.typography.labelMedium, color = StudioRose)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssetsLibraryPanel(
    uiState: StudioUiState,
    localAssets: List<LocalAssetEntity>,
    onImportImage: () -> Unit,
    onImportSvg: () -> Unit,
    onInsertProp: (ProceduralPropKind) -> Unit,
    onInsertLocalImage: (String, String) -> Unit,
    onInsertSavedCharacter: (CharacterSpec) -> Unit,
    onInsertSavedRig: (SkeletalRig) -> Unit
) {
    val project = uiState.activeProject ?: return

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Import Media (Offline)", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onImportImage,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    modifier = Modifier.weight(1f).testTag("import_image_asset_button")
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("PNG / JPG", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onImportSvg,
                    modifier = Modifier.weight(1f).testTag("import_svg_asset_button")
                ) {
                    Icon(Icons.Rounded.Polyline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("SVG", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Procedural Vector Props", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ProceduralPropKind.entries.forEach { kind ->
                    FilterChip(
                        selected = false,
                        onClick = { onInsertProp(kind) },
                        label = { Text(kind.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Saved Characters (${project.savedCharacters.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                project.savedCharacters.forEach { spec ->
                    Surface(
                        color = StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onInsertSavedCharacter(spec) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(spec.shirtColorArgb)))
                            Text(spec.name, style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Saved Rigs (${project.savedRigs.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                project.savedRigs.forEach { rig ->
                    FilterChip(
                        selected = false,
                        onClick = { onInsertSavedRig(rig) },
                        label = { Text("${rig.name} (${rig.bones.size}b)", style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        if (localAssets.isNotEmpty()) {
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Imported Library (${localAssets.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            }
            items(localAssets, key = { it.id }) { asset ->
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onInsertLocalImage(asset.filePath, asset.name) }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Rounded.Image, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(18.dp))
                        Text(asset.name, style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary, modifier = Modifier.weight(1f))
                        Text("Insert", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                    }
                }
            }
        }
    }
}
