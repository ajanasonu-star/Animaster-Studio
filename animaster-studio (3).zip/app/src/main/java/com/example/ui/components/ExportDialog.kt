package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ExportFormat
import com.example.data.model.ExportSettings
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioUiState
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExportStudioDialog(
    uiState: StudioUiState,
    onDismiss: () -> Unit,
    onStartExport: (ExportSettings) -> Unit,
    onSaveExportedToDevice: (File, ExportFormat) -> Unit,
    onShareExportedFile: (File, String) -> Unit,
    onExportProjectJson: () -> Unit
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val maxFrame = (scene.durationFrames - 1).coerceAtLeast(0)

    var format by remember { mutableStateOf(ExportFormat.GIF) }
    var resIdx by remember { mutableIntStateOf(1) }
    var fps by remember { mutableIntStateOf(project.fps) }
    var quality by remember { mutableIntStateOf(85) }
    var startFrame by remember { mutableIntStateOf(0) }
    var endFrame by remember { mutableIntStateOf(maxFrame) }

    val resolutions = listOf(
        Triple("640×360 (Fast)", 640, 360),
        Triple("960×540 (Balanced)", 960, 540),
        Triple("1280×720 (HD)", 1280, 720),
        Triple("1920×1080 (Full HD)", 1920, 1080)
    )

    AlertDialog(
        onDismissRequest = { if (!uiState.isExporting) onDismiss() },
        containerColor = StudioSurface,
        title = { Text("Local Offline Export", color = StudioTextPrimary) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Format", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExportFormat.entries.forEach { fmt ->
                        FilterChip(
                            selected = format == fmt,
                            onClick = { format = fmt },
                            label = { Text(fmt.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("export_format_${fmt.name.lowercase()}")
                        )
                    }
                }

                Text("Resolution", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    resolutions.forEachIndexed { idx, res ->
                        FilterChip(
                            selected = resIdx == idx,
                            onClick = { resIdx = idx },
                            label = { Text(res.first, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                if (format != ExportFormat.PNG) {
                    Text("FPS & Frame Range (F${startFrame + 1} – F${endFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(12, 24, 30, 60).forEach { f ->
                            FilterChip(
                                selected = fps == f,
                                onClick = { fps = f },
                                label = { Text("$f", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    if (maxFrame > 0) {
                        Slider(
                            value = endFrame.toFloat(),
                            onValueChange = { endFrame = it.toInt().coerceAtLeast(startFrame) },
                            valueRange = 0f..maxFrame.toFloat()
                        )
                    }
                }

                Text("Quality: $quality%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                Slider(
                    value = quality.toFloat(),
                    onValueChange = { quality = it.toInt() },
                    valueRange = 40f..100f
                )

                if (uiState.isExporting) {
                    LinearProgressIndicator(
                        progress = { uiState.exportProgress.coerceIn(0f, 1f) },
                        color = StudioCoral,
                        trackColor = StudioSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    )
                    Text(uiState.exportStatus, style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }

                uiState.lastExportResult?.let { result ->
                    Surface(
                        color = if (result.success) StudioEmerald.copy(alpha = 0.14f) else StudioRose.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (result.success) StudioEmerald else StudioRose),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = if (result.success) StudioEmerald else StudioRose,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(result.message, style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
                            }
                            result.savedGalleryPath?.let { path ->
                                Text("Saved to $path", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                            }
                            if (result.success && result.file != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = { onSaveExportedToDevice(result.file, result.format) },
                                        colors = ButtonDefaults.buttonColors(containerColor = StudioCyan),
                                        modifier = Modifier.weight(1f).testTag("save_to_device_button")
                                    ) {
                                        Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Save As", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(
                                        onClick = { onShareExportedFile(result.file, result.format.mime) },
                                        modifier = Modifier.weight(1f).testTag("share_export_button")
                                    ) {
                                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Share", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = onExportProjectJson,
                    enabled = !uiState.isExporting,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Backup Project File (.animaster.json)", style = MaterialTheme.typography.labelSmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val r = resolutions[resIdx]
                    onStartExport(
                        ExportSettings(
                            format = format,
                            width = r.second,
                            height = r.third,
                            fps = fps,
                            quality = quality,
                            startFrame = startFrame,
                            endFrame = endFrame
                        )
                    )
                },
                enabled = !uiState.isExporting,
                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                modifier = Modifier.testTag("start_export_button")
            ) {
                Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (uiState.isExporting) "Rendering..." else "Render Local", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !uiState.isExporting) {
                Text("Close", color = StudioTextSecondary)
            }
        }
    )
}
