package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AnimasterDatabase
import com.example.data.local.LocalAssetEntity
import com.example.data.local.ProjectRepository
import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationProject
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CameraKeyframe
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterSpec
import com.example.data.model.DrawStroke
import com.example.data.model.EasingType
import com.example.data.model.EditorTool
import com.example.data.model.ExportSettings
import com.example.data.model.FrameContent
import com.example.data.model.ImportedImageItem
import com.example.data.model.LayerType
import com.example.data.model.ProjectSummary
import com.example.data.model.RigBone
import com.example.data.model.SceneTransition
import com.example.data.model.ShapeKind
import com.example.data.model.SkeletalRig
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.engine.AudioStudioEngine
import com.example.engine.BuiltInAudioPreset
import com.example.engine.ExportEngine
import com.example.engine.ExportResult
import com.example.engine.InterpolationEngine
import com.example.engine.MotionPreset
import com.example.engine.ProceduralPropKind
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.engine.StoryboardTemplate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

enum class InspectorTab(val label: String) {
    LAYERS("Layers"),
    PROPS("Props"),
    CHARACTER("Character"),
    RIG("Rigging"),
    SCENE("Scene"),
    AUDIO("Audio"),
    ASSETS("Assets")
}

data class StudioUiState(
    val activeProject: AnimationProject? = null,
    val currentFrame: Int = 0,
    val selectedLayerId: String? = null,
    val selectedBoneId: String? = null,
    val activeTool: EditorTool = EditorTool.BRUSH,
    val primaryColorArgb: Long = 0xFFFF6B35L,
    val useGradient: Boolean = false,
    val gradientColorArgb: Long = 0xFF2DD4BFL,
    val brushSize: Float = 10f,
    val brushOpacity: Float = 1f,
    val fillShapes: Boolean = true,
    val polygonSides: Int = 5,
    val activeEasing: EasingType = EasingType.EASE_IN_OUT,
    val isPlaying: Boolean = false,
    val isLooping: Boolean = true,
    val onionSkinEnabled: Boolean = true,
    val ghostFramesEnabled: Boolean = false,
    val showRigOverlay: Boolean = true,
    val showMotionPaths: Boolean = true,
    val activeInspectorTab: InspectorTab = InspectorTab.LAYERS,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isRecordingVoice: Boolean = false,
    val voiceAmplitude: Float = 0f,
    val isExporting: Boolean = false,
    val exportProgress: Float = 0f,
    val exportStatus: String = "",
    val lastExportResult: ExportResult? = null,
    val statusBanner: String? = null,
    val canvasZoom: Float = 1f,
    val canvasPanX: Float = 0f,
    val canvasPanY: Float = 0f
) {
    val activeScene: AnimationScene?
        get() = activeProject?.let { p ->
            p.scenes.firstOrNull { it.id == p.activeSceneId } ?: p.scenes.firstOrNull()
        }

    val selectedLayer: AnimationLayer?
        get() = activeScene?.layers?.firstOrNull { it.id == selectedLayerId }
            ?: activeScene?.layers?.firstOrNull()
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AnimasterDatabase.getInstance(application)
    val repository = ProjectRepository(db.projectDao(), db.localAssetDao())
    val audioEngine = AudioStudioEngine(application)
    val exportEngine = ExportEngine(application)

    val projects: StateFlow<List<ProjectSummary>> = repository.projectsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recoverySnapshot: StateFlow<ProjectSummary?> = repository.recoverySnapshotFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val localAssets: StateFlow<List<LocalAssetEntity>> = repository.assetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private val undoStack = ArrayDeque<AnimationProject>()
    private val redoStack = ArrayDeque<AnimationProject>()
    private var playbackJob: Job? = null
    private var autosaveJob: Job? = null
    private var voiceJob: Job? = null

    init {
        // Seed one rich demo project on first launch only when the local DB is genuinely empty
        viewModelScope.launch {
            if (repository.getProjectCount() == 0) {
                val starter = ProceduralSmartTools.createProjectFromTemplate(
                    name = "Neon Studio Demo",
                    width = 1280,
                    height = 720,
                    fps = 24,
                    template = StoryboardTemplate.HERO_DEMO
                )
                repository.saveProject(starter, isRecovery = false)
            }
        }
    }

    // ─── Project Management ─────────────────────────────────────────

    fun createNewProject(
        name: String,
        width: Int,
        height: Int,
        fps: Int,
        template: StoryboardTemplate
    ) {
        val proj = ProceduralSmartTools.createProjectFromTemplate(name, width, height, fps, template)
        openProjectDirect(proj)
        viewModelScope.launch {
            repository.saveProject(proj, isRecovery = false)
            showToast("Created \"${proj.name}\"")
        }
    }

    fun openProject(projectId: String) {
        viewModelScope.launch {
            val loaded = repository.loadProject(projectId)
            if (loaded != null) {
                openProjectDirect(loaded)
            } else {
                showToast("Could not load project")
            }
        }
    }

    fun recoverAutosave(recoveryId: String) {
        viewModelScope.launch {
            val loaded = repository.loadProject(recoveryId)
            if (loaded != null) {
                openProjectDirect(loaded)
                repository.saveProject(loaded, isRecovery = false)
                repository.clearRecovery()
                showToast("Recovered \"${loaded.name}\"")
            }
        }
    }

    fun dismissRecovery() {
        viewModelScope.launch { repository.clearRecovery() }
    }

    private fun openProjectDirect(project: AnimationProject) {
        stopPlayback()
        undoStack.clear()
        redoStack.clear()
        val scene = project.scenes.firstOrNull { it.id == project.activeSceneId } ?: project.scenes.firstOrNull()
        val topLayer = scene?.layers?.lastOrNull { it.type == LayerType.DRAWING.name } ?: scene?.layers?.lastOrNull()
        _uiState.update {
            it.copy(
                activeProject = project,
                currentFrame = 0,
                selectedLayerId = topLayer?.id,
                selectedBoneId = null,
                canUndo = false,
                canRedo = false,
                canvasZoom = 1f,
                canvasPanX = 0f,
                canvasPanY = 0f
            )
        }
    }

    fun closeProjectToHub() {
        stopPlayback()
        val current = _uiState.value.activeProject
        if (current != null) {
            viewModelScope.launch {
                repository.saveProject(current, isRecovery = false)
                repository.clearRecovery()
            }
        }
        _uiState.update { it.copy(activeProject = null, isPlaying = false) }
    }

    fun saveProjectNow() {
        val current = _uiState.value.activeProject ?: return
        viewModelScope.launch {
            repository.saveProject(current, isRecovery = false)
            repository.clearRecovery()
            showToast("Saved \"${current.name}\" locally")
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            showToast("Project deleted")
        }
    }

    fun renameActiveProject(newName: String) {
        if (newName.isBlank()) return
        mutateProject { it.copy(name = newName.trim()) }
    }

    fun importProjectFromUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val json = runCatching {
                getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (json != null) {
                val parsed = repository.importProjectFromJson(json)
                if (parsed != null) {
                    val imported = parsed.copy(id = UUID.randomUUID().toString(), updatedAt = System.currentTimeMillis())
                    repository.saveProject(imported, isRecovery = false)
                    withContext(Dispatchers.Main) {
                        openProjectDirect(imported)
                        showToast("Imported \"${imported.name}\"")
                    }
                    return@launch
                }
            }
            withContext(Dispatchers.Main) { showToast("Invalid Animaster project JSON") }
        }
    }

    fun exportProjectJsonToUri(uri: Uri) {
        val proj = _uiState.value.activeProject ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val json = repository.exportProjectToJson(proj)
            val ok = runCatching {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray())
                }
            }.isSuccess
            withContext(Dispatchers.Main) {
                showToast(if (ok) "Exported project JSON" else "Failed to write JSON")
            }
        }
    }

    // ─── Core Project Mutation + Undo/Redo + Autosave ───────────────

    private fun mutateProject(recordUndo: Boolean = true, transform: (AnimationProject) -> AnimationProject) {
        val current = _uiState.value.activeProject ?: return
        if (recordUndo) {
            if (undoStack.size >= 35) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
        }
        val next = transform(current).copy(updatedAt = System.currentTimeMillis())
        val scene = next.scenes.firstOrNull { it.id == next.activeSceneId } ?: next.scenes.firstOrNull()
        val validLayerId = scene?.layers?.firstOrNull { it.id == _uiState.value.selectedLayerId }?.id
            ?: scene?.layers?.firstOrNull()?.id
        val clampedFrame = _uiState.value.currentFrame.coerceIn(0, ((scene?.durationFrames ?: 1) - 1).coerceAtLeast(0))

        _uiState.update {
            it.copy(
                activeProject = next,
                selectedLayerId = validLayerId,
                currentFrame = clampedFrame,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty()
            )
        }
        scheduleAutosave(next)
    }

    private fun mutateActiveScene(recordUndo: Boolean = true, transform: (AnimationScene) -> AnimationScene) {
        mutateProject(recordUndo) { proj ->
            proj.copy(scenes = proj.scenes.map { s -> if (s.id == proj.activeSceneId) transform(s) else s })
        }
    }

    private fun mutateSelectedLayer(recordUndo: Boolean = true, transform: (AnimationLayer) -> AnimationLayer) {
        val layerId = _uiState.value.selectedLayer?.id ?: return
        mutateActiveScene(recordUndo) { scene ->
            scene.copy(layers = scene.layers.map { l -> if (l.id == layerId) transform(l) else l })
        }
    }

    private fun scheduleAutosave(project: AnimationProject) {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(1500)
            repository.saveProject(project, isRecovery = true)
            repository.saveProject(project, isRecovery = false)
        }
    }

    fun undo() {
        val current = _uiState.value.activeProject ?: return
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(current)
        _uiState.update {
            it.copy(activeProject = prev, canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty())
        }
        scheduleAutosave(prev)
    }

    fun redo() {
        val current = _uiState.value.activeProject ?: return
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(current)
        _uiState.update {
            it.copy(activeProject = next, canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty())
        }
        scheduleAutosave(next)
    }

    // ─── Tool & Viewport Controls ───────────────────────────────────

    fun selectTool(tool: EditorTool) {
        if (tool == EditorTool.RIG_EDIT) {
            val scene = _uiState.value.activeScene
            val currentHasRig = _uiState.value.selectedLayer?.rig != null
            if (!currentHasRig && scene != null) {
                val rigLayer = scene.layers.lastOrNull { it.rig != null && it.visible }
                if (rigLayer != null) {
                    _uiState.update { it.copy(activeTool = tool, selectedLayerId = rigLayer.id) }
                    showToast("Selected Rig: ${rigLayer.name} — drag any joint")
                    return
                } else {
                    showToast("No rig layer yet — add one in Rigging")
                }
            }
        }
        _uiState.update { it.copy(activeTool = tool) }
    }
    fun setPrimaryColor(argb: Long) = _uiState.update { it.copy(primaryColorArgb = argb) }
    fun setGradientColor(argb: Long) = _uiState.update { it.copy(gradientColorArgb = argb) }
    fun toggleGradient(enabled: Boolean) = _uiState.update { it.copy(useGradient = enabled) }
    fun setBrushSize(size: Float) = _uiState.update { it.copy(brushSize = size.coerceIn(1f, 80f)) }
    fun setBrushOpacity(opacity: Float) = _uiState.update { it.copy(brushOpacity = opacity.coerceIn(0.05f, 1f)) }
    fun toggleFillShapes(fill: Boolean) = _uiState.update { it.copy(fillShapes = fill) }
    fun setPolygonSides(sides: Int) = _uiState.update { it.copy(polygonSides = sides.coerceIn(3, 12)) }
    fun setActiveEasing(easing: EasingType) = _uiState.update { it.copy(activeEasing = easing) }
    fun setInspectorTab(tab: InspectorTab) = _uiState.update { it.copy(activeInspectorTab = tab) }
    fun toggleOnionSkin() = _uiState.update { it.copy(onionSkinEnabled = !it.onionSkinEnabled) }
    fun toggleGhostFrames() = _uiState.update { it.copy(ghostFramesEnabled = !it.ghostFramesEnabled) }
    fun toggleRigOverlay() = _uiState.update { it.copy(showRigOverlay = !it.showRigOverlay) }
    fun toggleMotionPaths() = _uiState.update { it.copy(showMotionPaths = !it.showMotionPaths) }
    fun toggleLooping() = _uiState.update { it.copy(isLooping = !it.isLooping) }
    fun updateCanvasViewport(zoom: Float, panX: Float, panY: Float) = _uiState.update {
        it.copy(canvasZoom = zoom.coerceIn(0.4f, 4.5f), canvasPanX = panX, canvasPanY = panY)
    }
    fun resetCanvasViewport() = _uiState.update { it.copy(canvasZoom = 1f, canvasPanX = 0f, canvasPanY = 0f) }

    // ─── Drawing & Vector Operations ────────────────────────────────

    private fun ensureDrawableLayerSelected(): AnimationLayer? {
        val state = _uiState.value
        val selected = state.selectedLayer
        if (selected != null && !selected.locked) return selected
        return null
    }

    fun commitStroke(stroke: DrawStroke) {
        val layer = ensureDrawableLayerSelected() ?: run {
            showToast("Layer is locked")
            return
        }
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val currentContent = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            val updated = if (stroke.tool == EditorTool.ERASER.name) {
                val eraserR = (stroke.strokeWidth * 1.8f).coerceAtLeast(18f)
                val remainingStrokes = currentContent.strokes.filterNot { existing ->
                    existing.points.any { p ->
                        stroke.points.any { e -> kotlin.math.hypot(p.x - e.x, p.y - e.y) < eraserR }
                    }
                }
                val remainingShapes = currentContent.shapes.filterNot { s ->
                    val minX = kotlin.math.min(s.startX, s.endX) - eraserR
                    val maxX = kotlin.math.max(s.startX, s.endX) + eraserR
                    val minY = kotlin.math.min(s.startY, s.endY) - eraserR
                    val maxY = kotlin.math.max(s.startY, s.endY) + eraserR
                    stroke.points.any { e -> e.x in minX..maxX && e.y in minY..maxY }
                }
                val remainingTexts = currentContent.texts.filterNot { t ->
                    stroke.points.any { e -> kotlin.math.hypot(t.x - e.x, t.y - e.y) < eraserR * 2.5f }
                }
                currentContent.copy(
                    strokes = remainingStrokes,
                    shapes = remainingShapes,
                    texts = remainingTexts
                )
            } else {
                currentContent.copy(strokes = currentContent.strokes + stroke)
            }
            l.copy(frames = l.frames + (frameKey to updated))
        }
    }

    fun commitShape(shape: VectorShape) {
        ensureDrawableLayerSelected() ?: return
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val currentContent = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frameKey to currentContent.copy(shapes = currentContent.shapes + shape)))
        }
    }

    fun applyPaintBucket(canvasX: Float, canvasY: Float) {
        ensureDrawableLayerSelected() ?: return
        val state = _uiState.value
        val frameKey = state.currentFrame.toString()
        val fillHex = state.primaryColorArgb
        val gradHex = if (state.useGradient) state.gradientColorArgb else null

        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, state.currentFrame, holdPrevious = true)
                ?: FrameContent()
            // Check if tap hit an existing shape; if so recolor its fill, else add a fill backdrop rectangle
            val hitIdx = content.shapes.indexOfLast { s ->
                val minX = kotlin.math.min(s.startX, s.endX)
                val maxX = kotlin.math.max(s.startX, s.endX)
                val minY = kotlin.math.min(s.startY, s.endY)
                val maxY = kotlin.math.max(s.startY, s.endY)
                canvasX in minX..maxX && canvasY in minY..maxY
            }
            val newShapes = if (hitIdx >= 0) {
                content.shapes.mapIndexed { idx, s ->
                    if (idx == hitIdx) s.copy(fillColorArgb = fillHex, gradientEndArgb = gradHex) else s
                }
            } else {
                val p = state.activeProject
                val backdrop = VectorShape(
                    kind = ShapeKind.FILL_BACKDROP.name,
                    startX = 0f,
                    startY = 0f,
                    endX = (p?.width ?: 1280).toFloat(),
                    endY = (p?.height ?: 720).toFloat(),
                    strokeColorArgb = fillHex,
                    fillColorArgb = fillHex,
                    gradientEndArgb = gradHex,
                    strokeWidth = 0f
                )
                listOf(backdrop) + content.shapes
            }
            l.copy(frames = l.frames + (frameKey to content.copy(shapes = newShapes)))
        }
    }

    fun pickColorAt(canvasX: Float, canvasY: Float) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val bmp = SceneRenderer.renderSceneToBitmap(
            scene, _uiState.value.currentFrame, 320, 180, proj.width, proj.height
        )
        val px = ((canvasX / proj.width) * 320f).toInt().coerceIn(0, 319)
        val py = ((canvasY / proj.height) * 180f).toInt().coerceIn(0, 179)
        val pixel = bmp.getPixel(px, py)
        bmp.recycle()
        val argb = (pixel.toLong() and 0xFFFFFFFFL) or 0xFF000000L
        _uiState.update { it.copy(primaryColorArgb = argb, activeTool = EditorTool.BRUSH) }
        showToast("Picked color")
    }

    fun addTextItem(text: String, x: Float, y: Float, fontSize: Float = 48f) {
        if (text.isBlank()) return
        val frameKey = _uiState.value.currentFrame.toString()
        val item = CanvasTextItem(
            text = text.trim(),
            x = x,
            y = y,
            fontSize = fontSize,
            colorArgb = _uiState.value.primaryColorArgb
        )
        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frameKey to content.copy(texts = content.texts + item)))
        }
    }

    fun insertProceduralProp(kind: ProceduralPropKind) {
        val proj = _uiState.value.activeProject ?: return
        val (shapes, strokes) = ProceduralSmartTools.generatePropShapes(kind, proj.width * 0.5f, proj.height * 0.5f)
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(
                frames = l.frames + (frameKey to content.copy(
                    shapes = content.shapes + shapes,
                    strokes = content.strokes + strokes
                ))
            )
        }
        showToast("Inserted ${kind.label}")
    }

    fun importImageFromUri(uri: Uri) {
        val proj = _uiState.value.activeProject ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val dir = File(getApplication<Application>().filesDir, "images").apply { mkdirs() }
            val outFile = File(dir, "img_${System.currentTimeMillis()}.png")
            val ok = runCatching {
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
            }.isSuccess
            if (ok && outFile.exists()) {
                repository.saveLocalAsset(
                    LocalAssetEntity(
                        id = UUID.randomUUID().toString(),
                        name = outFile.nameWithoutExtension,
                        category = "IMAGE",
                        filePath = outFile.absolutePath,
                        jsonPayload = null,
                        createdAt = System.currentTimeMillis()
                    )
                )
                withContext(Dispatchers.Main) {
                    insertLocalImageFile(outFile.absolutePath, "Imported Image")
                }
            }
        }
    }

    fun insertLocalImageFile(filePath: String, name: String) {
        val proj = _uiState.value.activeProject ?: return
        val frameKey = _uiState.value.currentFrame.toString()
        val item = ImportedImageItem(
            name = name,
            filePath = filePath,
            x = proj.width * 0.5f,
            y = proj.height * 0.5f,
            width = proj.width * 0.35f,
            height = proj.height * 0.35f
        )
        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frameKey to content.copy(images = content.images + item)))
        }
        showToast("Added image to frame")
    }

    fun importSvgFromUri(uri: Uri) {
        val proj = _uiState.value.activeProject ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val svgText = runCatching {
                getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull() ?: return@launch
            val parsedShapes = SceneRenderer.parseSimpleSvgShapes(svgText, proj.width.toFloat(), proj.height.toFloat())
            withContext(Dispatchers.Main) {
                if (parsedShapes.isNotEmpty()) {
                    val frameKey = _uiState.value.currentFrame.toString()
                    mutateSelectedLayer { l ->
                        val content = l.frames[frameKey]
                            ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                            ?: FrameContent()
                        l.copy(frames = l.frames + (frameKey to content.copy(shapes = content.shapes + parsedShapes)))
                    }
                    showToast("Imported ${parsedShapes.size} SVG vector shapes")
                } else {
                    showToast("No basic SVG shapes found")
                }
            }
        }
    }

    fun nudgeSelectedLayerTransform(dx: Float, dy: Float, dRot: Float = 0f, dScale: Float = 0f, recordUndo: Boolean = false) {
        val frame = _uiState.value.currentFrame
        val scene = _uiState.value.activeScene ?: return
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val cur = InterpolationEngine.evaluateLayerTransform(l, frame, scene.durationFrames)
            val kf = TransformKeyframe(
                frame = frame,
                x = cur.x + dx,
                y = cur.y + dy,
                rotationDeg = cur.rotationDeg + dRot,
                scaleX = (cur.scaleX + dScale).coerceIn(0.15f, 4f),
                scaleY = (cur.scaleY + dScale).coerceIn(0.15f, 4f),
                opacity = cur.opacity,
                easing = _uiState.value.activeEasing.name
            )
            val updatedKfs = l.keyframes.filterNot { it.frame == frame } + kf
            l.copy(keyframes = updatedKfs.sortedBy { it.frame })
        }
    }

    fun addMotionPathPoint(pt: Vec2) {
        mutateSelectedLayer { l -> l.copy(motionPath = l.motionPath + pt) }
    }

    fun clearMotionPath() {
        mutateSelectedLayer { l -> l.copy(motionPath = emptyList()) }
    }

    // ─── Layer Operations ───────────────────────────────────────────

    fun selectLayer(layerId: String) = _uiState.update { it.copy(selectedLayerId = layerId) }

    fun addLayer(type: LayerType) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val idx = scene.layers.size + 1
        val newLayer = when (type) {
            LayerType.CHARACTER -> AnimationLayer(
                name = "Character $idx",
                type = type.name,
                character = ProceduralSmartTools.characterPresets.first().copy(x = proj.width * 0.5f, y = proj.height * 0.58f)
            )
            LayerType.RIG -> AnimationLayer(
                name = "Rig $idx",
                type = type.name,
                rig = RigSolver.createHumanoidRig("Rig $idx", proj.width * 0.5f, proj.height * 0.58f)
            )
            LayerType.FOREGROUND -> AnimationLayer(name = "Foreground $idx", type = type.name, parallaxDepth = 1.35f)
            LayerType.BACKGROUND -> AnimationLayer(name = "Background $idx", type = type.name, parallaxDepth = 0.65f)
            LayerType.DRAWING -> AnimationLayer(name = "Drawing $idx", type = type.name)
        }
        mutateActiveScene { s -> s.copy(layers = s.layers + newLayer) }
        _uiState.update { it.copy(selectedLayerId = newLayer.id) }
    }

    fun deleteLayer(layerId: String) {
        mutateActiveScene { s ->
            if (s.layers.size <= 1) s else s.copy(layers = s.layers.filterNot { it.id == layerId })
        }
    }

    fun toggleLayerVisibility(layerId: String) {
        mutateActiveScene { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(visible = !it.visible) else it })
        }
    }

    fun toggleLayerLock(layerId: String) {
        mutateActiveScene { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(locked = !it.locked) else it })
        }
    }

    fun updateLayerOpacity(layerId: String, opacity: Float) {
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(opacity = opacity.coerceIn(0f, 1f)) else it })
        }
    }

    fun updateLayerParallax(layerId: String, depth: Float) {
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(parallaxDepth = depth.coerceIn(0.2f, 2f)) else it })
        }
    }

    fun moveLayerOrder(layerId: String, up: Boolean) {
        mutateActiveScene { s ->
            val list = s.layers.toMutableList()
            val idx = list.indexOfFirst { it.id == layerId }
            if (idx < 0) return@mutateActiveScene s
            val target = if (up) idx + 1 else idx - 1
            if (target in list.indices) {
                val item = list.removeAt(idx)
                list.add(target, item)
            }
            s.copy(layers = list)
        }
    }

    // ─── Timeline, Playback & Keyframes ─────────────────────────────

    fun setCurrentFrame(frame: Int) {
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 1) - 1).coerceAtLeast(0)
        _uiState.update { it.copy(currentFrame = frame.coerceIn(0, maxF)) }
    }

    fun stepFrame(delta: Int) {
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 1) - 1).coerceAtLeast(0)
        val next = (_uiState.value.currentFrame + delta).coerceIn(0, maxF)
        _uiState.update { it.copy(currentFrame = next) }
    }

    fun setFps(fps: Int) {
        mutateProject { it.copy(fps = fps.coerceIn(6, 60)) }
    }

    fun setSceneDuration(frames: Int) {
        mutateActiveScene { it.copy(durationFrames = frames.coerceIn(6, 600)) }
    }

    fun togglePlayback() {
        if (_uiState.value.isPlaying) {
            stopPlayback()
        } else {
            startPlayback()
        }
    }

    private fun startPlayback() {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        playbackJob?.cancel()
        _uiState.update { it.copy(isPlaying = true) }

        playbackJob = viewModelScope.launch {
            while (isActive && _uiState.value.isPlaying) {
                val curState = _uiState.value
                val fps = (curState.activeProject?.fps ?: proj.fps).coerceIn(6, 60)
                val total = (curState.activeScene?.durationFrames ?: scene.durationFrames).coerceAtLeast(1)
                val frameNow = curState.currentFrame
                curState.activeProject?.audioTracks?.let { audioEngine.triggerTracksForFrame(it, frameNow) }
                delay((1000L / fps).coerceAtLeast(16L))
                val nextFrame = frameNow + 1
                if (nextFrame >= total) {
                    if (curState.isLooping) {
                        _uiState.update { it.copy(currentFrame = 0) }
                    } else {
                        stopPlayback()
                    }
                } else {
                    _uiState.update { it.copy(currentFrame = nextFrame) }
                }
            }
        }
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        audioEngine.stopAllPlayback()
        _uiState.update { it.copy(isPlaying = false) }
    }

    fun addBlankCelAtCurrentFrame() {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l -> l.copy(frames = l.frames + (frameKey to FrameContent())) }
        showToast("Added blank cel on F${_uiState.value.currentFrame + 1}")
    }

    fun duplicatePreviousCelToCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer { l ->
            val src = InterpolationEngine.resolveFrameContent(l, (frame - 1).coerceAtLeast(0), holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frame.toString() to src))
        }
        showToast("Duplicated cel to F${frame + 1}")
    }

    fun clearCurrentCel() {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l -> l.copy(frames = l.frames + (frameKey to FrameContent())) }
    }

    fun insertOrUpdateKeyframeAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        val scene = _uiState.value.activeScene ?: return
        mutateSelectedLayer { l ->
            val tf = InterpolationEngine.evaluateLayerTransform(l, frame, scene.durationFrames)
            val kf = TransformKeyframe(
                frame = frame,
                x = tf.x, y = tf.y, rotationDeg = tf.rotationDeg,
                scaleX = tf.scaleX, scaleY = tf.scaleY, opacity = tf.opacity,
                easing = _uiState.value.activeEasing.name
            )
            l.copy(keyframes = (l.keyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame })
        }
        showToast("Keyframe set at F${frame + 1}")
    }

    fun deleteKeyframeAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer { l -> l.copy(keyframes = l.keyframes.filterNot { it.frame == frame }) }
    }

    fun applyMotionPresetToSelectedLayer(preset: MotionPreset) {
        val scene = _uiState.value.activeScene ?: return
        if (preset == MotionPreset.DRAMATIC_ZOOM) {
            val end = (scene.durationFrames - 1).coerceAtLeast(1)
            mutateActiveScene { s ->
                s.copy(
                    cameraKeyframes = listOf(
                        CameraKeyframe(0, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(end / 2, 0f, -15f, 1.32f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(end, 0f, 0f, 1f, 0f, EasingType.EASE_OUT.name)
                    )
                )
            }
            showToast("Applied Camera Zoom-In preset")
            return
        }
        mutateSelectedLayer { l ->
            ProceduralSmartTools.applyMotionPreset(l, preset, scene.durationFrames)
        }
        showToast("Applied ${preset.label}")
    }

    // ─── Character Creator ──────────────────────────────────────────

    fun upsertCharacterLayer(spec: CharacterSpec, createNewLayer: Boolean) {
        val selected = _uiState.value.selectedLayer
        if (!createNewLayer && selected != null && selected.type == LayerType.CHARACTER.name) {
            mutateSelectedLayer { it.copy(name = spec.name, character = spec) }
        } else {
            val newLayer = AnimationLayer(name = spec.name, type = LayerType.CHARACTER.name, character = spec)
            mutateActiveScene { s -> s.copy(layers = s.layers + newLayer) }
            _uiState.update { it.copy(selectedLayerId = newLayer.id) }
        }
        showToast("Updated character \"${spec.name}\"")
    }

    fun saveCharacterTemplate(spec: CharacterSpec) {
        mutateProject { p ->
            val updated = p.savedCharacters.filterNot { it.id == spec.id } + spec.copy(id = UUID.randomUUID().toString())
            p.copy(savedCharacters = updated)
        }
        showToast("Saved character template \"${spec.name}\"")
    }

    fun setCharacterFrameExpressionOrPose(expression: String? = null, pose: String? = null) {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val base = l.frames[frameKey]?.characterOverride ?: l.character ?: return@mutateSelectedLayer l
            val nextChar = base.copy(
                expression = expression ?: base.expression,
                pose = pose ?: base.pose
            )
            val content = l.frames[frameKey] ?: FrameContent()
            l.copy(
                character = if (_uiState.value.currentFrame == 0) nextChar else l.character,
                frames = l.frames + (frameKey to content.copy(characterOverride = nextChar))
            )
        }
    }

    // ─── Skeletal Rigging ───────────────────────────────────────────

    fun selectBone(boneId: String?) = _uiState.update { it.copy(selectedBoneId = boneId) }

    fun dragRigBoneTo(boneId: String, target: Vec2, recordUndo: Boolean = false) {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val currentAngles = InterpolationEngine.evaluateRigAngles(rig, frame)
            val newAngles = RigSolver.solveDragTarget(rig, boneId, target, currentAngles, rig.ikEnabled)
            val updatedKeyframes = rig.poseKeyframes + (frame.toString() to newAngles)
            l.copy(rig = rig.copy(poseKeyframes = updatedKeyframes))
        }
    }

    fun applyRigPosePreset(poseName: String) {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val poseMap = RigSolver.presetPoseAngles(poseName)
            l.copy(rig = rig.copy(poseKeyframes = rig.poseKeyframes + (frameKey to poseMap)))
        }
        showToast("Keyframed $poseName pose at F${_uiState.value.currentFrame + 1}")
    }

    fun addChildBoneToRig(name: String, length: Float = 62f) {
        val parentId = _uiState.value.selectedBoneId
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val newBone = RigBone(
                name = name.ifBlank { "Bone ${rig.bones.size + 1}" },
                parentId = parentId ?: rig.bones.firstOrNull()?.id,
                length = length,
                localAngleDeg = 25f,
                thickness = 15f,
                colorArgb = 0xFF2DD4BFL
            )
            l.copy(rig = rig.copy(bones = rig.bones + newBone))
        }
    }

    fun toggleRigIkMode() {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(ikEnabled = !rig.ikEnabled))
        }
    }

    fun toggleRigSkinMesh() {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(showSkinMesh = !rig.showSkinMesh))
        }
    }

    fun saveRigTemplate() {
        val rig = _uiState.value.selectedLayer?.rig ?: return
        mutateProject { p ->
            p.copy(savedRigs = p.savedRigs + rig.copy(id = UUID.randomUUID().toString()))
        }
        showToast("Saved rig template \"${rig.name}\"")
    }

    fun insertSavedRig(rig: SkeletalRig) {
        val newLayer = AnimationLayer(
            name = rig.name,
            type = LayerType.RIG.name,
            rig = rig.copy(id = UUID.randomUUID().toString())
        )
        mutateActiveScene { s -> s.copy(layers = s.layers + newLayer) }
        _uiState.update { it.copy(selectedLayerId = newLayer.id, activeTool = EditorTool.RIG_EDIT) }
    }

    // ─── Scene & Camera ─────────────────────────────────────────────

    fun selectScene(sceneId: String) {
        val proj = _uiState.value.activeProject ?: return
        val target = proj.scenes.firstOrNull { it.id == sceneId } ?: return
        mutateProject(recordUndo = false) { it.copy(activeSceneId = sceneId) }
        _uiState.update { it.copy(currentFrame = 0, selectedLayerId = target.layers.firstOrNull()?.id) }
    }

    fun addScene(name: String) {
        val newScene = AnimationScene(
            name = name.ifBlank { "Scene ${(_uiState.value.activeProject?.scenes?.size ?: 0) + 1}" },
            durationFrames = 48,
            backgroundTemplate = BackgroundTemplate.SUNNY_MEADOW.name,
            layers = listOf(AnimationLayer(name = "Drawing 1", type = LayerType.DRAWING.name))
        )
        mutateProject { p -> p.copy(scenes = p.scenes + newScene, activeSceneId = newScene.id) }
        _uiState.update { it.copy(currentFrame = 0, selectedLayerId = newScene.layers.first().id) }
    }

    fun deleteScene(sceneId: String) {
        mutateProject { p ->
            if (p.scenes.size <= 1) p
            else {
                val rem = p.scenes.filterNot { it.id == sceneId }
                val nextActive = if (p.activeSceneId == sceneId) rem.first().id else p.activeSceneId
                p.copy(scenes = rem, activeSceneId = nextActive)
            }
        }
    }

    fun setSceneBackgroundTemplate(template: BackgroundTemplate) {
        mutateActiveScene { it.copy(backgroundTemplate = template.name) }
    }

    fun setSceneBackgroundColor(argb: Long) {
        mutateActiveScene { it.copy(backgroundColorArgb = argb, backgroundTemplate = BackgroundTemplate.SOLID.name) }
    }

    fun setSceneTransition(transition: SceneTransition) {
        mutateActiveScene { it.copy(transition = transition.name) }
    }

    fun updateCameraKeyframeAtCurrentFrame(panX: Float, panY: Float, zoom: Float, rotationDeg: Float) {
        val frame = _uiState.value.currentFrame
        val kf = CameraKeyframe(
            frame = frame,
            panX = panX,
            panY = panY,
            zoom = zoom.coerceIn(0.4f, 3.0f),
            rotationDeg = rotationDeg,
            easing = _uiState.value.activeEasing.name
        )
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(cameraKeyframes = (s.cameraKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame })
        }
    }

    fun resetCameraKeyframes() {
        mutateActiveScene { it.copy(cameraKeyframes = listOf(CameraKeyframe(frame = 0))) }
    }

    // ─── Audio Studio ───────────────────────────────────────────────

    fun startVoiceRecording() {
        if (_uiState.value.isRecordingVoice) return
        _uiState.update { it.copy(isRecordingVoice = true, voiceAmplitude = 0f) }
        voiceJob = viewModelScope.launch {
            audioEngine.recordVoiceToWav(
                onAmplitude = { amp -> _uiState.update { it.copy(voiceAmplitude = amp) } },
                onFinished = { track ->
                    _uiState.update { it.copy(isRecordingVoice = false, voiceAmplitude = 0f) }
                    if (track != null) {
                        val positioned = track.copy(startFrame = _uiState.value.currentFrame)
                        mutateProject { p -> p.copy(audioTracks = p.audioTracks + positioned) }
                        showToast("Recorded voice track")
                    } else {
                        showToast("Recording too short or mic unavailable")
                    }
                }
            )
        }
    }

    fun stopVoiceRecording() {
        audioEngine.stopVoiceRecording()
    }

    fun addBuiltInAudioPreset(preset: BuiltInAudioPreset) {
        viewModelScope.launch {
            val track = audioEngine.synthesizeBuiltInPreset(preset, _uiState.value.currentFrame)
            mutateProject { p -> p.copy(audioTracks = p.audioTracks + track) }
            audioEngine.previewTrack(track)
            showToast("Added ${preset.title}")
        }
    }

    fun importAudioFromUri(uri: Uri, displayName: String) {
        viewModelScope.launch {
            val track = audioEngine.importAudioUri(uri, displayName, _uiState.value.currentFrame)
            if (track != null) {
                mutateProject { p -> p.copy(audioTracks = p.audioTracks + track) }
                showToast("Imported audio \"${track.name}\"")
            } else {
                showToast("Could not import audio file")
            }
        }
    }

    fun updateAudioTrack(updated: AudioTrackItem) {
        mutateProject(recordUndo = false) { p ->
            p.copy(audioTracks = p.audioTracks.map { if (it.id == updated.id) updated else it })
        }
    }

    fun deleteAudioTrack(trackId: String) {
        mutateProject { p -> p.copy(audioTracks = p.audioTracks.filterNot { it.id == trackId }) }
    }

    fun previewAudioTrack(track: AudioTrackItem) = audioEngine.previewTrack(track)

    // ─── Local Offline Export ───────────────────────────────────────

    fun runLocalExport(settings: ExportSettings) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        stopPlayback()
        _uiState.update { it.copy(isExporting = true, exportProgress = 0.05f, exportStatus = "Preparing renderer...", lastExportResult = null) }

        viewModelScope.launch {
            val res = exportEngine.exportScene(
                project = proj,
                scene = scene,
                settings = settings,
                currentFrame = _uiState.value.currentFrame,
                onProgress = { prog, status ->
                    _uiState.update { it.copy(exportProgress = prog, exportStatus = status) }
                }
            )
            _uiState.update {
                it.copy(
                    isExporting = false,
                    exportProgress = if (res.success) 1f else 0f,
                    exportStatus = res.message,
                    lastExportResult = res
                )
            }
        }
    }

    fun saveExportFileToUri(sourceFile: File, targetUri: Uri) {
        viewModelScope.launch {
            val ok = exportEngine.copyExportFileToUri(sourceFile, targetUri)
            showToast(if (ok) "Saved to phone storage" else "Could not save file")
        }
    }

    fun clearExportResult() = _uiState.update { it.copy(lastExportResult = null, exportStatus = "", exportProgress = 0f) }

    fun showToast(message: String) {
        _uiState.update { it.copy(statusBanner = message) }
        viewModelScope.launch {
            delay(2600)
            _uiState.update { if (it.statusBanner == message) it.copy(statusBanner = null) else it }
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stopVoiceRecording()
        audioEngine.stopAllPlayback()
        playbackJob?.cancel()
    }
}
