package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CharacterSpec
import com.example.data.model.LayerType
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.CanvasBackdrop
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CharacterCreatorPanel(
    uiState: StudioUiState,
    onApplyCharacter: (CharacterSpec, Boolean) -> Unit,
    onSaveTemplate: (CharacterSpec) -> Unit,
    onKeyframeExpressionPose: (String?, String?) -> Unit
) {
    val activeChar = uiState.selectedLayer?.character
    var draft by remember(activeChar?.id) {
        mutableStateOf(activeChar ?: ProceduralSmartTools.characterPresets.first())
    }

    LaunchedEffect(activeChar) {
        if (activeChar != null) draft = activeChar
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Live Character Preview Stage
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CanvasBackdrop)
                    .border(1.dp, StudioBorder, RoundedCornerShape(14.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawIntoCanvas { c ->
                        val nc = c.nativeCanvas
                        nc.save()
                        val previewChar = draft.copy(x = size.width / 2f, y = size.height * 0.56f, scale = 0.52f)
                        SceneRenderer.drawCharacter(nc, previewChar, 1f, null)
                        nc.restore()
                    }
                }
                Surface(
                    color = StudioSurfaceVariant.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clickable { draft = ProceduralSmartTools.randomizeCharacter() }
                        .testTag("randomize_character_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.Casino, contentDescription = "Randomize", tint = StudioCyan, modifier = Modifier.size(15.dp))
                        Text("Randomize", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                    }
                }
            }
        }

        // Character Presets & Name
        item {
            OutlinedTextField(
                value = draft.name,
                onValueChange = { draft = draft.copy(name = it) },
                label = { Text("Character Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text("Quick Presets", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ProceduralSmartTools.characterPresets.forEach { preset ->
                    FilterChip(
                        selected = draft.name == preset.name,
                        onClick = { draft = preset.copy(x = draft.x, y = draft.y) },
                        label = { Text(preset.name, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Expression & Pose
        item {
            Text("Facial Expression", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("HAPPY", "NEUTRAL", "SURPRISED", "ANGRY", "SAD", "WINK", "TALKING").forEach { exp ->
                    FilterChip(
                        selected = draft.expression == exp,
                        onClick = {
                            draft = draft.copy(expression = exp)
                            if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) {
                                onKeyframeExpressionPose(exp, null)
                            }
                        },
                        label = { Text(exp, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Character Pose", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("IDLE", "WAVE", "WALK_A", "WALK_B", "JUMP", "HERO", "SIT").forEach { pose ->
                    FilterChip(
                        selected = draft.pose == pose,
                        onClick = {
                            draft = draft.copy(pose = pose)
                            if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) {
                                onKeyframeExpressionPose(null, pose)
                            }
                        },
                        label = { Text(pose, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Face, Eyes, Hair, Outfit, Accessory
        item {
            OptionRow("Face", listOf("OVAL", "ROUND", "SQUARE", "CHIBI"), draft.faceShape) { draft = draft.copy(faceShape = it) }
            OptionRow("Eyes", listOf("ANIME", "DOT", "CARTOON", "COOL", "STAR"), draft.eyeStyle) { draft = draft.copy(eyeStyle = it) }
            OptionRow("Hair", listOf("SPIKY", "BOB", "PONYTAIL", "CURLY", "MOHAWK", "BALD"), draft.hairStyle) { draft = draft.copy(hairStyle = it) }
            OptionRow("Outfit", listOf("HOODIE", "TEE", "JACKET", "CAPE", "TUNIC"), draft.shirtStyle) { draft = draft.copy(shirtStyle = it) }
            OptionRow("Accessory", listOf("NONE", "GLASSES", "HEADPHONES", "CROWN", "SCARF", "HAT"), draft.accessory) { draft = draft.copy(accessory = it) }
        }

        // Skin, Hair & Outfit Colors
        item {
            ColorRow("Skin Tone", listOf(0xFFFFDFC4L, 0xFFF5C6A5L, 0xFFE0AC69L, 0xFFC68642L, 0xFF8D5524L), draft.skinToneArgb) {
                draft = draft.copy(skinToneArgb = it)
            }
            ColorRow("Hair Color", listOf(0xFF1F2937L, 0xFF7C2D12L, 0xFF4C1D95L, 0xFFEC4899L, 0xFF0284C7L, 0xFFF59E0BL), draft.hairColorArgb) {
                draft = draft.copy(hairColorArgb = it)
            }
            ColorRow("Shirt Color", listOf(0xFFFF6B35L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFBBF24L, 0xFF10B981L, 0xFFFB7185L), draft.shirtColorArgb) {
                draft = draft.copy(shirtColorArgb = it)
            }
        }

        // Apply / Insert / Save Actions
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onApplyCharacter(draft, false) },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    modifier = Modifier.weight(1f).testTag("apply_character_button")
                ) {
                    Text(
                        if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) "Update Layer" else "Insert Character",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedButton(
                    onClick = { onSaveTemplate(draft) },
                    modifier = Modifier.testTag("save_character_template_button")
                ) {
                    Icon(Icons.Rounded.BookmarkAdd, contentDescription = "Save template", modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(4.dp))
            OutlinedButton(
                onClick = { onApplyCharacter(draft, true) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add as New Character Layer", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RiggingInspectorPanel(
    uiState: StudioUiState,
    onAddRigLayer: () -> Unit,
    onInsertMascotRig: () -> Unit,
    onSelectBone: (String) -> Unit,
    onAddChildBone: (String) -> Unit,
    onApplyPosePreset: (String) -> Unit,
    onToggleIk: () -> Unit,
    onToggleSkin: () -> Unit,
    onSaveRigTemplate: () -> Unit
) {
    val rig = uiState.selectedLayer?.rig
    var newBoneName by remember { mutableStateOf("Tail / Prop") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (rig == null) {
            item {
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.AccessibilityNew, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(34.dp))
                        Text("No Rig Layer Selected", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        Text(
                            "Select an existing Rig layer or create a humanoid/cartoon skeleton to pose with 2-Bone IK.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                        Button(
                            onClick = onAddRigLayer,
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth().testTag("create_humanoid_rig_button")
                        ) {
                            Text("Create Humanoid Rig", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = onInsertMascotRig, modifier = Modifier.fillMaxWidth()) {
                            Text("Create Cartoon Mascot Rig")
                        }
                    }
                }
            }
        } else {
            item {
                Surface(
                    color = StudioCyan.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tip: Select the RIG tool and drag any joint circle directly on the canvas to animate with ${if (rig.ikEnabled) "2-Bone IK" else "FK Rotation"}!",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioCyan,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("2-Bone Inverse Kinematics (IK)", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                    Switch(checked = rig.ikEnabled, onCheckedChange = { onToggleIk() })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Show Stylized Limb Mesh", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                    Switch(checked = rig.showSkinMesh, onCheckedChange = { onToggleSkin() })
                }
            }

            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Keyframe Pose Presets (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("IDLE", "WAVE", "WALK_A", "WALK_B", "JUMP").forEach { pose ->
                        FilterChip(
                            selected = false,
                            onClick = { onApplyPosePreset(pose) },
                            label = { Text(pose, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Add Child Bone", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = newBoneName,
                        onValueChange = { newBoneName = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { onAddChildBone(newBoneName) },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioCoral)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add bone", modifier = Modifier.size(18.dp))
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Bone Hierarchy (${rig.bones.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                    OutlinedButton(onClick = onSaveRigTemplate) {
                        Text("Save Rig", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            items(rig.bones, key = { it.id }) { bone ->
                val isSel = uiState.selectedBoneId == bone.id
                Surface(
                    color = if (isSel) StudioSurfaceElevated else StudioSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (isSel) StudioCoral else StudioBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectBone(bone.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(bone.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                            Text(
                                text = "Parent: ${bone.parentId ?: "Root"} • Len ${bone.length.toInt()}px",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Color(bone.colorArgb))
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OptionRow(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            options.forEach { opt ->
                FilterChip(
                    selected = selected == opt,
                    onClick = { onSelect(opt) },
                    label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                )
            }
        }
    }
}

@Composable
private fun ColorRow(label: String, colors: List<Long>, selected: Long, onSelect: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.forEach { argb ->
                val isSel = selected == argb
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .border(if (isSel) 2.5.dp else 1.dp, if (isSel) StudioViolet else StudioBorder, CircleShape)
                        .clickable { onSelect(argb) }
                )
            }
        }
    }
}
