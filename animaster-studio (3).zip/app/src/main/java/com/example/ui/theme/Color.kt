package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian-Graphite Dark Studio Palette
val StudioBg = Color(0xFF0D0F14)
val StudioSurface = Color(0xFF151922)
val StudioSurfaceVariant = Color(0xFF1D222E)
val StudioSurfaceElevated = Color(0xFF252B3A)
val StudioBorder = Color(0xFF2E3648)
val StudioBorderSubtle = Color(0xFF222836)

// Primary & Accent Colors
val StudioCoral = Color(0xFFFF6B35)
val StudioCoralLight = Color(0xFFFF8F66)
val StudioCoralDark = Color(0xFFD94E1F)
val StudioCyan = Color(0xFF2DD4BF)
val StudioCyanDim = Color(0xFF1A4D48)
val StudioViolet = Color(0xFFA78BFA)
val StudioVioletDim = Color(0xFF3A2D5C)
val StudioAmber = Color(0xFFFBBF24)
val StudioRose = Color(0xFFFB7185)
val StudioEmerald = Color(0xFF34D399)

// Text Hierarchy
val StudioTextPrimary = Color(0xFFF3F5F9)
val StudioTextSecondary = Color(0xFFA5B0C4)
val StudioTextMuted = Color(0xFF6B768C)

// Onion Skin & Canvas Guides
val OnionPastTint = Color(0xFFA78BFA)
val OnionFutureTint = Color(0xFF2DD4BF)
val CanvasBackdrop = Color(0xFF0A0C10)
