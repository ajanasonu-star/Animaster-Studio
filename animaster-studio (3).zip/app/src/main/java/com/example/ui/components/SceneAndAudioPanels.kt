package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.SceneTransition
import com.example.engine.BuiltInAudioPreset
import com.example.engine.InterpolationEngine
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SceneCameraInspectorPanel(
    uiState: StudioUiState,
    onSelectScene: (String) -> Unit,
    onAddScene: () -> Unit,
    onDeleteScene: (String) -> Unit,
    onSetDuration: (Int) -> Unit,
    onSetBackgroundTemplate: (BackgroundTemplate) -> Unit,
    onSetTransition: (SceneTransition) -> Unit,
    onUpdateCamera: (Float, Float, Float, Float) -> Unit,
    onResetCamera: () -> Unit
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val cam = InterpolationEngine.evaluateCamera(scene, uiState.currentFrame)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Scenes list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Scenes (${project.scenes.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                OutlinedButton(onClick = onAddScene, modifier = Modifier.testTag("add_scene_button")) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("New Scene", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                project.scenes.forEach { s ->
                    val active = s.id == scene.id
                    Surface(
                        color = if (active) StudioSurfaceElevated else StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (active) StudioCoral else StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectScene(s.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(s.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                Text("${s.durationFrames} frames • ${s.layers.size} layers", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                            }
                            if (project.scenes.size > 1) {
                                IconButton(onClick = { onDeleteScene(s.id) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete scene", tint = StudioRose, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Duration & Background Template
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Scene Duration: ${scene.durationFrames} frames", style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
            Slider(
                value = scene.durationFrames.toFloat(),
                onValueChange = { onSetDuration(it.toInt()) },
                valueRange = 12f..180f,
                colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral)
            )
            Text("Background Template", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BackgroundTemplate.entries.forEach { tpl ->
                    FilterChip(
                        selected = scene.backgroundTemplate == tpl.name,
                        onClick = { onSetBackgroundTemplate(tpl) },
                        label = { Text(tpl.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Scene Transition", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneTransition.entries.forEach { tr ->
                    FilterChip(
                        selected = scene.transition == tr.name,
                        onClick = { onSetTransition(tr) },
                        label = { Text(tr.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Camera Keyframes at current frame
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Camera Keyframe (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                IconButton(onClick = onResetCamera, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.RestartAlt, contentDescription = "Reset camera", tint = StudioTextSecondary)
                }
            }
            CameraSlider("Zoom ${String.format("%.2fx", cam.zoom)}", cam.zoom, 0.5f..2.5f) {
                onUpdateCamera(cam.panX, cam.panY, it, cam.rotationDeg)
            }
            CameraSlider("Pan X ${cam.panX.toInt()}", cam.panX, -400f..400f) {
                onUpdateCamera(it, cam.panY, cam.zoom, cam.rotationDeg)
            }
            CameraSlider("Pan Y ${cam.panY.toInt()}", cam.panY, -300f..300f) {
                onUpdateCamera(cam.panX, it, cam.zoom, cam.rotationDeg)
            }
            CameraSlider("Tilt ${cam.rotationDeg.toInt()}°", cam.rotationDeg, -45f..45f) {
                onUpdateCamera(cam.panX, cam.panY, cam.zoom, it)
            }
        }
    }
}

@Composable
private fun CameraSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
            modifier = Modifier.weight(1f)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AudioStudioInspectorPanel(
    uiState: StudioUiState,
    onRequestRecordVoice: () -> Unit,
    onStopVoiceRecording: () -> Unit,
    onImportAudio: () -> Unit,
    onAddBuiltInPreset: (BuiltInAudioPreset) -> Unit,
    onPreviewTrack: (AudioTrackItem) -> Unit,
    onUpdateTrack: (AudioTrackItem) -> Unit,
    onDeleteTrack: (String) -> Unit
) {
    val project = uiState.activeProject ?: return

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Voice Recording & Import
        item {
            Text("Voice & Audio Import", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (uiState.isRecordingVoice) onStopVoiceRecording() else onRequestRecordVoice()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isRecordingVoice) StudioRose else StudioCoral
                    ),
                    modifier = Modifier.weight(1f).testTag("voice_record_button")
                ) {
                    Icon(
                        if (uiState.isRecordingVoice) Icons.Rounded.Stop else Icons.Rounded.Mic,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (uiState.isRecordingVoice) "Stop Rec" else "Record Voice", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onImportAudio,
                    modifier = Modifier.weight(1f).testTag("import_audio_button")
                ) {
                    Icon(Icons.Rounded.AudioFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Import", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (uiState.isRecordingVoice) {
                Spacer(Modifier.height(8.dp))
                Text("Recording live audio...", style = MaterialTheme.typography.labelSmall, color = StudioRose)
                LinearProgressIndicator(
                    progress = { uiState.voiceAmplitude.coerceIn(0.05f, 1f) },
                    color = StudioRose,
                    trackColor = StudioSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                )
            }
        }

        // Built-in Offline SFX & Music Synth
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(16.dp))
                Text("Offline SFX & Music Synth", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            }
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BuiltInAudioPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { onAddBuiltInPreset(preset) },
                        label = { Text(preset.title, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Audio Track Mixer Cards
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Timeline Audio Tracks (${project.audioTracks.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
        }

        if (project.audioTracks.isEmpty()) {
            item {
                Text(
                    "Record your voice, import audio, or tap any offline SFX above to add it at frame F${uiState.currentFrame + 1}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextMuted
                )
            }
        } else {
            items(project.audioTracks, key = { it.id }) { track ->
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(track.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("Start F${track.startFrame + 1} • ${track.durationMs}ms", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                            }
                            IconButton(onClick = { onPreviewTrack(track) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Preview track", tint = StudioEmerald)
                            }
                            IconButton(onClick = { onUpdateTrack(track.copy(muted = !track.muted)) }, modifier = Modifier.size(34.dp)) {
                                Icon(
                                    if (track.muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                    contentDescription = "Mute toggle",
                                    tint = if (track.muted) StudioTextMuted else StudioCyan
                                )
                            }
                            IconButton(onClick = { onDeleteTrack(track.id) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete track", tint = StudioRose)
                            }
                        }

                        // Mini Waveform Bar Strip
                        if (track.waveformPeaks.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(26.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0D1117))
                                    .padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                track.waveformPeaks.take(36).forEach { peak ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height((peak * 22f).coerceIn(3f, 22f).dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(if (track.muted) StudioTextMuted else StudioEmerald)
                                    )
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vol ${(track.volume * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(64.dp))
                            Slider(
                                value = track.volume,
                                onValueChange = { onUpdateTrack(track.copy(volume = it)) },
                                valueRange = 0f..1f,
                                colors = SliderDefaults.colors(thumbColor = StudioEmerald, activeTrackColor = StudioEmerald),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Start F${track.startFrame + 1}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(64.dp))
                            Slider(
                                value = track.startFrame.toFloat(),
                                onValueChange = { onUpdateTrack(track.copy(startFrame = it.toInt())) },
                                valueRange = 0f..((uiState.activeScene?.durationFrames ?: 48) - 1).coerceAtLeast(1).toFloat(),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Trim ${(track.trimEndMs / 1000f).let { String.format("%.1fs", it) }}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(64.dp))
                            Slider(
                                value = track.trimEndMs.toFloat().coerceIn(200f, track.durationMs.toFloat().coerceAtLeast(250f)),
                                onValueChange = { onUpdateTrack(track.copy(trimEndMs = it.toLong())) },
                                valueRange = 200f..track.durationMs.toFloat().coerceAtLeast(250f),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
