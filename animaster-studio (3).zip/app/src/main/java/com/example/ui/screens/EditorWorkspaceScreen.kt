package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.ChangeHistory
import androidx.compose.material.icons.rounded.Circle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Colorize
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.CropSquare
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FormatColorFill
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.HorizontalRule
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PanTool
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.LocalAssetEntity
import com.example.data.model.EditorTool
import com.example.data.model.ExportFormat
import com.example.data.model.LayerType
import com.example.engine.RigSolver
import com.example.ui.components.AssetsLibraryPanel
import com.example.ui.components.AudioStudioInspectorPanel
import com.example.ui.components.CanvasStage
import com.example.ui.components.CharacterCreatorPanel
import com.example.ui.components.ExportStudioDialog
import com.example.ui.components.LayersInspectorPanel
import com.example.ui.components.PropertiesInspectorPanel
import com.example.ui.components.RiggingInspectorPanel
import com.example.ui.components.SceneCameraInspectorPanel
import com.example.ui.components.TimelinePanel
import com.example.ui.theme.StudioBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.InspectorTab
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.StudioViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorWorkspaceScreen(
    viewModel: StudioViewModel,
    uiState: StudioUiState,
    localAssets: List<LocalAssetEntity>,
    onBackToHub: () -> Unit,
    onImportImage: () -> Unit,
    onImportSvg: () -> Unit,
    onImportAudio: () -> Unit,
    onRequestRecordVoice: () -> Unit,
    onExportProjectJson: () -> Unit,
    onSaveExportedToDevice: (File, ExportFormat) -> Unit,
    onShareExportedFile: (File, String) -> Unit
) {
    val project = uiState.activeProject ?: return
    var showExportDialog by remember { mutableStateOf(false) }
    var mobileSheetOpen by remember { mutableStateOf(false) }
    var inspectorWidthDp by remember { mutableFloatStateOf(300f) }

    BackHandler { onBackToHub() }

    Scaffold(
        containerColor = StudioBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown) {
                        when {
                            event.isCtrlPressed && event.key == Key.Z -> { viewModel.undo(); true }
                            event.isCtrlPressed && event.key == Key.Y -> { viewModel.redo(); true }
                            event.key == Key.Spacebar -> { viewModel.togglePlayback(); true }
                            event.key == Key.DirectionLeft -> { viewModel.stepFrame(-1); true }
                            event.key == Key.DirectionRight -> { viewModel.stepFrame(1); true }
                            event.key == Key.B -> { viewModel.selectTool(EditorTool.BRUSH); true }
                            event.key == Key.P -> { viewModel.selectTool(EditorTool.PENCIL); true }
                            event.key == Key.E -> { viewModel.selectTool(EditorTool.ERASER); true }
                            event.key == Key.G -> { viewModel.selectTool(EditorTool.BUCKET); true }
                            event.key == Key.V -> { viewModel.selectTool(EditorTool.SELECT); true }
                            event.key == Key.K -> { viewModel.selectTool(EditorTool.RIG_EDIT); true }
                            event.key == Key.O -> { viewModel.toggleOnionSkin(); true }
                            else -> false
                        }
                    } else false
                }
        ) {
            val isDesktopLayout = maxWidth >= 760.dp

            Column(modifier = Modifier.fillMaxSize()) {
                // 1. Professional Studio Top Bar
                StudioTopToolbar(
                    projectName = project.name,
                    sceneName = uiState.activeScene?.name ?: "Scene 1",
                    primaryColorArgb = uiState.primaryColorArgb,
                    canUndo = uiState.canUndo,
                    canRedo = uiState.canRedo,
                    isDesktop = isDesktopLayout,
                    onBack = onBackToHub,
                    onUndo = { viewModel.undo() },
                    onRedo = { viewModel.redo() },
                    onSave = { viewModel.saveProjectNow() },
                    onExport = {
                        viewModel.clearExportResult()
                        showExportDialog = true
                    },
                    onOpenMobileInspector = {
                        viewModel.setInspectorTab(InspectorTab.PROPS)
                        mobileSheetOpen = true
                    }
                )

                // 2. Main Middle Workspace (Tools + Stage + Resizable Desktop Inspector)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    // Left Vertical Tool Palette
                    VerticalToolRail(
                        activeTool = uiState.activeTool,
                        onSelectTool = { viewModel.selectTool(it) }
                    )

                    // Center Canvas Stage
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        CanvasStage(
                            uiState = uiState,
                            onCommitStroke = { viewModel.commitStroke(it) },
                            onCommitShape = { viewModel.commitShape(it) },
                            onPaintBucket = { x, y -> viewModel.applyPaintBucket(x, y) },
                            onPickColor = { x, y -> viewModel.pickColorAt(x, y) },
                            onAddText = { txt, x, y -> viewModel.addTextItem(txt, x, y) },
                            onNudgeLayerTransform = { dx, dy, rec -> viewModel.nudgeSelectedLayerTransform(dx, dy, 0f, 0f, rec) },
                            onSelectLayer = { viewModel.selectLayer(it) },
                            onSelectBone = { viewModel.selectBone(it) },
                            onDragRigBone = { bid, pt, rec -> viewModel.dragRigBoneTo(bid, pt, rec) },
                            onAddMotionPathPoint = { viewModel.addMotionPathPoint(it) },
                            onUpdateViewport = { z, px, py -> viewModel.updateCanvasViewport(z, px, py) },
                            onResetViewport = { viewModel.resetCanvasViewport() }
                        )

                        // Floating Status Banner
                        androidx.compose.animation.AnimatedVisibility(
                            visible = uiState.statusBanner != null,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp)
                        ) {
                            Surface(
                                color = StudioSurfaceElevated.copy(alpha = 0.95f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, StudioCoral)
                            ) {
                                Text(
                                    text = uiState.statusBanner.orEmpty(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StudioTextPrimary,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }

                    // Desktop/Tablet Docked & Resizable Right Inspector Panel
                    if (isDesktopLayout) {
                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .fillMaxHeight()
                                .background(StudioBorder)
                                .pointerInput(Unit) {
                                    detectHorizontalDragGestures { _, dragAmount ->
                                        inspectorWidthDp = (inspectorWidthDp - dragAmount * 0.6f).coerceIn(240f, 440f)
                                    }
                                }
                        )
                        Surface(
                            color = StudioSurface,
                            modifier = Modifier
                                .width(inspectorWidthDp.dp)
                                .fillMaxHeight()
                        ) {
                            InspectorHost(
                                viewModel = viewModel,
                                uiState = uiState,
                                localAssets = localAssets,
                                onImportImage = onImportImage,
                                onImportSvg = onImportSvg,
                                onImportAudio = onImportAudio,
                                onRequestRecordVoice = onRequestRecordVoice
                            )
                        }
                    }
                }

                // 3. Mobile Quick Inspector Dock Strip (Compact screens only)
                if (!isDesktopLayout) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(StudioSurfaceVariant)
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        InspectorTab.entries.forEach { tab ->
                            val selected = uiState.activeInspectorTab == tab && mobileSheetOpen
                            Surface(
                                color = if (selected) StudioCoral.copy(alpha = 0.22f) else StudioSurface,
                                shape = RoundedCornerShape(9.dp),
                                border = BorderStroke(1.dp, if (selected) StudioCoral else StudioBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(9.dp))
                                    .clickable {
                                        viewModel.setInspectorTab(tab)
                                        mobileSheetOpen = true
                                    }
                                    .testTag("mobile_tab_${tab.name.lowercase()}")
                            ) {
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) StudioCoral else StudioTextPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }

                // 4. Advanced Multi-Track Bottom Timeline
                TimelinePanel(
                    uiState = uiState,
                    onTogglePlay = { viewModel.togglePlayback() },
                    onStepFrame = { viewModel.stepFrame(it) },
                    onSelectFrame = { viewModel.setCurrentFrame(it) },
                    onSelectLayer = { viewModel.selectLayer(it) },
                    onSetFps = { viewModel.setFps(it) },
                    onToggleLoop = { viewModel.toggleLooping() },
                    onToggleOnionSkin = { viewModel.toggleOnionSkin() },
                    onToggleGhostFrames = { viewModel.toggleGhostFrames() },
                    onAddBlankCel = { viewModel.addBlankCelAtCurrentFrame() },
                    onDuplicateCel = { viewModel.duplicatePreviousCelToCurrentFrame() },
                    onInsertKeyframe = { viewModel.insertOrUpdateKeyframeAtCurrentFrame() }
                )
            }
        }
    }

    // Mobile Inspector Bottom Sheet
    if (mobileSheetOpen) {
        ModalBottomSheet(
            onDismissRequest = { mobileSheetOpen = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = StudioSurface
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(470.dp)
                    .navigationBarsPadding()
            ) {
                InspectorHost(
                    viewModel = viewModel,
                    uiState = uiState,
                    localAssets = localAssets,
                    onImportImage = onImportImage,
                    onImportSvg = onImportSvg,
                    onImportAudio = onImportAudio,
                    onRequestRecordVoice = onRequestRecordVoice,
                    onCloseMobile = { mobileSheetOpen = false }
                )
            }
        }
    }

    // Export Modal
    if (showExportDialog) {
        ExportStudioDialog(
            uiState = uiState,
            onDismiss = { showExportDialog = false },
            onStartExport = { viewModel.runLocalExport(it) },
            onSaveExportedToDevice = onSaveExportedToDevice,
            onShareExportedFile = onShareExportedFile,
            onExportProjectJson = onExportProjectJson
        )
    }
}

@Composable
private fun StudioTopToolbar(
    projectName: String,
    sceneName: String,
    primaryColorArgb: Long,
    canUndo: Boolean,
    canRedo: Boolean,
    isDesktop: Boolean,
    onBack: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSave: () -> Unit,
    onExport: () -> Unit,
    onOpenMobileInspector: () -> Unit
) {
    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp).testTag("editor_back_button")) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to projects", tint = StudioTextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = projectName,
                    style = MaterialTheme.typography.titleMedium,
                    color = StudioTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = sceneName,
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (!isDesktop) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(primaryColorArgb))
                        .border(2.dp, StudioBorder, CircleShape)
                        .clickable(onClick = onOpenMobileInspector)
                        .testTag("quick_color_swatch")
                )
            }

            IconButton(onClick = onUndo, enabled = canUndo, modifier = Modifier.size(40.dp).testTag("undo_button")) {
                Icon(
                    Icons.AutoMirrored.Rounded.Undo,
                    contentDescription = "Undo",
                    tint = if (canUndo) StudioTextPrimary else StudioTextMuted
                )
            }
            IconButton(onClick = onRedo, enabled = canRedo, modifier = Modifier.size(40.dp).testTag("redo_button")) {
                Icon(
                    Icons.AutoMirrored.Rounded.Redo,
                    contentDescription = "Redo",
                    tint = if (canRedo) StudioTextPrimary else StudioTextMuted
                )
            }
            IconButton(onClick = onSave, modifier = Modifier.size(40.dp).testTag("save_button")) {
                Icon(Icons.Rounded.Save, contentDescription = "Save locally", tint = StudioCyan)
            }
            Surface(
                color = StudioCoral,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onExport)
                    .testTag("open_export_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = "Export", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Text("Export", style = MaterialTheme.typography.labelMedium, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun VerticalToolRail(
    activeTool: EditorTool,
    onSelectTool: (EditorTool) -> Unit
) {
    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .width(56.dp)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            EditorTool.entries.forEach { tool ->
                val isSelected = activeTool == tool
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) StudioCoral.copy(alpha = 0.22f) else Color.Transparent)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.dp,
                            color = if (isSelected) StudioCoral else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectTool(tool) }
                        .testTag("tool_${tool.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = toolIcon(tool),
                            contentDescription = tool.label,
                            tint = if (isSelected) StudioCoral else StudioTextSecondary,
                            modifier = Modifier.size(19.dp)
                        )
                        Text(
                            text = tool.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) StudioCoral else StudioTextMuted,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InspectorHost(
    viewModel: StudioViewModel,
    uiState: StudioUiState,
    localAssets: List<LocalAssetEntity>,
    onImportImage: () -> Unit,
    onImportSvg: () -> Unit,
    onImportAudio: () -> Unit,
    onRequestRecordVoice: () -> Unit,
    onCloseMobile: (() -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurfaceVariant)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            InspectorTab.entries.forEach { tab ->
                val sel = uiState.activeInspectorTab == tab
                Surface(
                    color = if (sel) StudioCoral else StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.setInspectorTab(tab) }
                ) {
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (sel) Color.Black else StudioTextSecondary,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                    )
                }
            }
            if (onCloseMobile != null) {
                IconButton(onClick = onCloseMobile, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close inspector", tint = StudioTextSecondary)
                }
            }
        }
        HorizontalDivider(color = StudioBorder)

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (uiState.activeInspectorTab) {
                InspectorTab.LAYERS -> LayersInspectorPanel(
                    uiState = uiState,
                    onSelectLayer = { viewModel.selectLayer(it) },
                    onAddLayer = { viewModel.addLayer(it) },
                    onDeleteLayer = { viewModel.deleteLayer(it) },
                    onToggleVisibility = { viewModel.toggleLayerVisibility(it) },
                    onToggleLock = { viewModel.toggleLayerLock(it) },
                    onMoveOrder = { id, up -> viewModel.moveLayerOrder(id, up) },
                    onUpdateOpacity = { id, op -> viewModel.updateLayerOpacity(id, op) },
                    onUpdateParallax = { id, p -> viewModel.updateLayerParallax(id, p) },
                    onApplyMotionPreset = { viewModel.applyMotionPresetToSelectedLayer(it) },
                    onClearCel = { viewModel.clearCurrentCel() },
                    onClearMotionPath = { viewModel.clearMotionPath() }
                )
                InspectorTab.PROPS -> PropertiesInspectorPanel(
                    uiState = uiState,
                    onSetPrimaryColor = { viewModel.setPrimaryColor(it) },
                    onSetGradientColor = { viewModel.setGradientColor(it) },
                    onToggleGradient = { viewModel.toggleGradient(it) },
                    onSetBrushSize = { viewModel.setBrushSize(it) },
                    onSetBrushOpacity = { viewModel.setBrushOpacity(it) },
                    onToggleFillShapes = { viewModel.toggleFillShapes(it) },
                    onSetPolygonSides = { viewModel.setPolygonSides(it) },
                    onSetEasing = { viewModel.setActiveEasing(it) },
                    onNudgeTransform = { dx, dy, dr, ds -> viewModel.nudgeSelectedLayerTransform(dx, dy, dr, ds, true) },
                    onInsertKeyframe = { viewModel.insertOrUpdateKeyframeAtCurrentFrame() },
                    onDeleteKeyframe = { viewModel.deleteKeyframeAtCurrentFrame() }
                )
                InspectorTab.CHARACTER -> CharacterCreatorPanel(
                    uiState = uiState,
                    onApplyCharacter = { spec, asNew -> viewModel.upsertCharacterLayer(spec, asNew) },
                    onSaveTemplate = { viewModel.saveCharacterTemplate(it) },
                    onKeyframeExpressionPose = { exp, pose -> viewModel.setCharacterFrameExpressionOrPose(exp, pose) }
                )
                InspectorTab.RIG -> RiggingInspectorPanel(
                    uiState = uiState,
                    onAddRigLayer = {
                        viewModel.addLayer(LayerType.RIG)
                        viewModel.selectTool(EditorTool.RIG_EDIT)
                    },
                    onInsertMascotRig = { viewModel.insertSavedRig(RigSolver.createCartoonMascotRig()) },
                    onSelectBone = { viewModel.selectBone(it) },
                    onAddChildBone = { viewModel.addChildBoneToRig(it) },
                    onApplyPosePreset = { viewModel.applyRigPosePreset(it) },
                    onToggleIk = { viewModel.toggleRigIkMode() },
                    onToggleSkin = { viewModel.toggleRigSkinMesh() },
                    onSaveRigTemplate = { viewModel.saveRigTemplate() }
                )
                InspectorTab.SCENE -> SceneCameraInspectorPanel(
                    uiState = uiState,
                    onSelectScene = { viewModel.selectScene(it) },
                    onAddScene = { viewModel.addScene("Scene ${(uiState.activeProject?.scenes?.size ?: 0) + 1}") },
                    onDeleteScene = { viewModel.deleteScene(it) },
                    onSetDuration = { viewModel.setSceneDuration(it) },
                    onSetBackgroundTemplate = { viewModel.setSceneBackgroundTemplate(it) },
                    onSetTransition = { viewModel.setSceneTransition(it) },
                    onUpdateCamera = { px, py, z, r -> viewModel.updateCameraKeyframeAtCurrentFrame(px, py, z, r) },
                    onResetCamera = { viewModel.resetCameraKeyframes() }
                )
                InspectorTab.AUDIO -> AudioStudioInspectorPanel(
                    uiState = uiState,
                    onRequestRecordVoice = onRequestRecordVoice,
                    onStopVoiceRecording = { viewModel.stopVoiceRecording() },
                    onImportAudio = onImportAudio,
                    onAddBuiltInPreset = { viewModel.addBuiltInAudioPreset(it) },
                    onPreviewTrack = { viewModel.previewAudioTrack(it) },
                    onUpdateTrack = { viewModel.updateAudioTrack(it) },
                    onDeleteTrack = { viewModel.deleteAudioTrack(it) }
                )
                InspectorTab.ASSETS -> AssetsLibraryPanel(
                    uiState = uiState,
                    localAssets = localAssets,
                    onImportImage = onImportImage,
                    onImportSvg = onImportSvg,
                    onInsertProp = { viewModel.insertProceduralProp(it) },
                    onInsertLocalImage = { path, name -> viewModel.insertLocalImageFile(path, name) },
                    onInsertSavedCharacter = { viewModel.upsertCharacterLayer(it, true) },
                    onInsertSavedRig = { viewModel.insertSavedRig(it) }
                )
            }
        }
    }
}

private fun toolIcon(tool: EditorTool): ImageVector = when (tool) {
    EditorTool.PENCIL -> Icons.Rounded.Create
    EditorTool.BRUSH -> Icons.Rounded.Brush
    EditorTool.AIRBRUSH -> Icons.Rounded.Grain
    EditorTool.ERASER -> Icons.Rounded.AutoFixHigh
    EditorTool.BUCKET -> Icons.Rounded.FormatColorFill
    EditorTool.PEN_BEZIER -> Icons.Rounded.Gesture
    EditorTool.LINE -> Icons.Rounded.HorizontalRule
    EditorTool.RECTANGLE -> Icons.Rounded.CropSquare
    EditorTool.CIRCLE -> Icons.Rounded.Circle
    EditorTool.POLYGON -> Icons.Rounded.ChangeHistory
    EditorTool.TEXT -> Icons.Rounded.TextFields
    EditorTool.EYEDROPPER -> Icons.Rounded.Colorize
    EditorTool.SELECT -> Icons.Rounded.OpenWith
    EditorTool.RIG_EDIT -> Icons.Rounded.AccessibilityNew
    EditorTool.MOTION_PATH -> Icons.Rounded.Timeline
    EditorTool.HAND_PAN -> Icons.Rounded.PanTool
}
