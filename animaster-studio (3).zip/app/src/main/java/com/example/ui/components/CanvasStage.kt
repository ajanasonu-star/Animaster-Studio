package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.ShapeKind
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.engine.InterpolationEngine
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.CanvasBackdrop
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioUiState
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

@Composable
fun CanvasStage(
    uiState: StudioUiState,
    onCommitStroke: (DrawStroke) -> Unit,
    onCommitShape: (VectorShape) -> Unit,
    onPaintBucket: (Float, Float) -> Unit,
    onPickColor: (Float, Float) -> Unit,
    onAddText: (String, Float, Float) -> Unit,
    onNudgeLayerTransform: (Float, Float, Boolean) -> Unit,
    onSelectLayer: (String) -> Unit,
    onSelectBone: (String?) -> Unit,
    onDragRigBone: (String, Vec2, Boolean) -> Unit,
    onAddMotionPathPoint: (Vec2) -> Unit,
    onUpdateViewport: (Float, Float, Float) -> Unit,
    onResetViewport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return

    var activeStroke by remember { mutableStateOf<DrawStroke?>(null) }
    var activeShape by remember { mutableStateOf<VectorShape?>(null) }
    var pendingTextPos by remember { mutableStateOf<Vec2?>(null) }
    var textDraft by remember { mutableStateOf("") }

    val latestState by rememberUpdatedState(uiState)
    val latestCommitStroke by rememberUpdatedState(onCommitStroke)
    val latestCommitShape by rememberUpdatedState(onCommitShape)
    val latestPaintBucket by rememberUpdatedState(onPaintBucket)
    val latestPickColor by rememberUpdatedState(onPickColor)
    val latestNudge by rememberUpdatedState(onNudgeLayerTransform)
    val latestSelectLayer by rememberUpdatedState(onSelectLayer)
    val latestSelectBone by rememberUpdatedState(onSelectBone)
    val latestDragBone by rememberUpdatedState(onDragRigBone)
    val latestAddMotionPath by rememberUpdatedState(onAddMotionPathPoint)
    val latestUpdateViewport by rememberUpdatedState(onUpdateViewport)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasBackdrop)
            .clipToBounds()
            .testTag("animation_canvas_stage")
    ) {
        val density = LocalDensity.current
        val viewW = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
        val viewH = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)
        val projW = project.width.toFloat()
        val projH = project.height.toFloat()

        val baseScale = min((viewW * 0.92f) / projW, (viewH * 0.92f) / projH)
        val totalScale = baseScale * uiState.canvasZoom
        val stageW = projW * totalScale
        val stageH = projH * totalScale
        val originX = (viewW - stageW) / 2f + uiState.canvasPanX
        val originY = (viewH - stageH) / 2f + uiState.canvasPanY

        val latestOriginX by rememberUpdatedState(originX)
        val latestOriginY by rememberUpdatedState(originY)
        val latestTotalScale by rememberUpdatedState(totalScale)

        fun toStageWorld(offset: Offset): Vec2 {
            val st = latestState
            val sc = st.activeScene
            val rawX = (offset.x - latestOriginX) / latestTotalScale
            val rawY = (offset.y - latestOriginY) / latestTotalScale
            if (sc == null) return Vec2(rawX, rawY)

            // Invert active camera transform so touches align 1:1 with canvas ink
            val cam = InterpolationEngine.evaluateCamera(sc, st.currentFrame)
            val cx = projW / 2f
            val cy = projH / 2f
            val dx = rawX - cx
            val dy = rawY - cy
            val rad = Math.toRadians((-cam.rotationDeg).toDouble())
            val rx = (dx * cos(rad) - dy * sin(rad)).toFloat() / cam.zoom.coerceAtLeast(0.1f)
            val ry = (dx * sin(rad) + dy * cos(rad)).toFloat() / cam.zoom.coerceAtLeast(0.1f)
            return Vec2(rx + cx + cam.panX, ry + cy + cam.panY)
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val firstDown = awaitFirstDown(requireUnconsumed = false)
                        val startPos = firstDown.position
                        val startStage = toStageWorld(startPos)
                        val st0 = latestState
                        val tool = st0.activeTool

                        var isMultiTouch = false
                        var hasDragged = false
                        var lastPos = startPos
                        var draggingBoneId: String? = null
                        var selectUndoRecorded = false

                        // Prepare initial drawing / rig / shape state on finger down
                        when (tool) {
                            EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                activeStroke = DrawStroke(
                                    tool = tool.name,
                                    points = listOf(startStage),
                                    colorArgb = if (tool == EditorTool.ERASER) 0xFFFB7185L else st0.primaryColorArgb,
                                    gradientEndArgb = if (st0.useGradient && tool != EditorTool.ERASER) st0.gradientColorArgb else null,
                                    strokeWidth = st0.brushSize,
                                    opacity = st0.brushOpacity
                                )
                            }
                            EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                val kind = when (tool) {
                                    EditorTool.LINE -> ShapeKind.LINE
                                    EditorTool.RECTANGLE -> ShapeKind.RECTANGLE
                                    EditorTool.CIRCLE -> ShapeKind.CIRCLE
                                    else -> ShapeKind.POLYGON
                                }
                                activeShape = VectorShape(
                                    kind = kind.name,
                                    startX = startStage.x,
                                    startY = startStage.y,
                                    endX = startStage.x,
                                    endY = startStage.y,
                                    polygonSides = st0.polygonSides,
                                    strokeColorArgb = st0.primaryColorArgb,
                                    fillColorArgb = if (st0.fillShapes && kind != ShapeKind.LINE) st0.primaryColorArgb else null,
                                    gradientEndArgb = if (st0.useGradient) st0.gradientColorArgb else null,
                                    strokeWidth = st0.brushSize.coerceAtLeast(2f),
                                    opacity = st0.brushOpacity
                                )
                            }
                            EditorTool.RIG_EDIT -> {
                                val sc = st0.activeScene
                                val rigLayer = st0.selectedLayer?.takeIf { it.rig != null }
                                    ?: sc?.layers?.lastOrNull { it.rig != null && it.visible }
                                val rig = rigLayer?.rig
                                if (rigLayer != null && rig != null) {
                                    if (st0.selectedLayerId != rigLayer.id) {
                                        latestSelectLayer(rigLayer.id)
                                    }
                                    val angles = InterpolationEngine.evaluateRigAngles(rig, st0.currentFrame)
                                    val solved = RigSolver.solveForwardKinematics(rig, angles)
                                    val nearest = solved.minByOrNull { hypot(it.end.x - startStage.x, it.end.y - startStage.y) }
                                    if (nearest != null && hypot(nearest.end.x - startStage.x, nearest.end.y - startStage.y) < 95f) {
                                        draggingBoneId = nearest.bone.id
                                        latestSelectBone(nearest.bone.id)
                                        latestDragBone(nearest.bone.id, startStage, true)
                                    }
                                }
                            }
                            else -> Unit
                        }

                        while (true) {
                            val event = awaitPointerEvent()
                            val activePointers = event.changes.filter { it.pressed }
                            if (activePointers.isEmpty()) break

                            // Seamless 2-finger pinch-to-zoom & pan on canvas
                            if (activePointers.size >= 2) {
                                if (!isMultiTouch) {
                                    isMultiTouch = true
                                    activeStroke = null
                                    activeShape = null
                                    draggingBoneId = null
                                }
                                val zoomChange = event.calculateZoom()
                                val panChange = event.calculatePan()
                                if (zoomChange != 1f || panChange != Offset.Zero) {
                                    val cur = latestState
                                    latestUpdateViewport(
                                        (cur.canvasZoom * zoomChange).coerceIn(0.4f, 4.5f),
                                        cur.canvasPanX + panChange.x,
                                        cur.canvasPanY + panChange.y
                                    )
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                                continue
                            }

                            if (isMultiTouch) continue

                            val change = activePointers.first()
                            val pos = change.position
                            val delta = pos - lastPos
                            if (hypot(pos.x - startPos.x, pos.y - startPos.y) > 4f) {
                                hasDragged = true
                            }
                            lastPos = pos
                            val pt = toStageWorld(pos)

                            when (tool) {
                                EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                    activeStroke = activeStroke?.let { s ->
                                        val prev = s.points.lastOrNull()
                                        if (prev == null || hypot(pt.x - prev.x, pt.y - prev.y) >= 2.5f) {
                                            s.copy(points = s.points + pt)
                                        } else s
                                    }
                                    change.consume()
                                }
                                EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                    activeShape = activeShape?.copy(endX = pt.x, endY = pt.y)
                                    change.consume()
                                }
                                EditorTool.HAND_PAN -> {
                                    if (delta != Offset.Zero) {
                                        val cur = latestState
                                        latestUpdateViewport(
                                            cur.canvasZoom,
                                            cur.canvasPanX + delta.x,
                                            cur.canvasPanY + delta.y
                                        )
                                        change.consume()
                                    }
                                }
                                EditorTool.SELECT -> {
                                    if (delta != Offset.Zero) {
                                        val firstMove = !selectUndoRecorded
                                        selectUndoRecorded = true
                                        latestNudge(delta.x / latestTotalScale, delta.y / latestTotalScale, firstMove)
                                        change.consume()
                                    }
                                }
                                EditorTool.RIG_EDIT -> {
                                    draggingBoneId?.let { bid ->
                                        latestDragBone(bid, pt, false)
                                        change.consume()
                                    }
                                }
                                else -> Unit
                            }
                        }

                        // Gesture ended: commit stroke/shape or trigger tap-based tools
                        if (!isMultiTouch) {
                            when (tool) {
                                EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                    activeStroke?.let { if (it.points.isNotEmpty()) latestCommitStroke(it) }
                                }
                                EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                    activeShape?.let { shape ->
                                        val dist = hypot(shape.endX - shape.startX, shape.endY - shape.startY)
                                        val finalShape = if (dist < 6f) {
                                            shape.copy(endX = shape.startX + 120f, endY = shape.startY + 90f)
                                        } else shape
                                        latestCommitShape(finalShape)
                                    }
                                }
                                EditorTool.BUCKET -> if (!hasDragged) latestPaintBucket(startStage.x, startStage.y)
                                EditorTool.EYEDROPPER -> if (!hasDragged) latestPickColor(startStage.x, startStage.y)
                                EditorTool.TEXT -> if (!hasDragged) {
                                    textDraft = ""
                                    pendingTextPos = startStage
                                }
                                EditorTool.MOTION_PATH -> latestAddMotionPath(startStage)
                                else -> Unit
                            }
                        }
                        activeStroke = null
                        activeShape = null
                    }
                }
        ) {
            drawIntoCanvas { composeCanvas ->
                val nc = composeCanvas.nativeCanvas
                nc.save()
                nc.translate(originX, originY)
                nc.scale(totalScale, totalScale)
                nc.clipRect(0f, 0f, projW, projH)

                SceneRenderer.renderScene(
                    canvas = nc,
                    scene = scene,
                    frame = uiState.currentFrame,
                    projectWidth = projW,
                    projectHeight = projH,
                    onionSkin = uiState.onionSkinEnabled && !uiState.isPlaying,
                    ghostFrames = uiState.ghostFramesEnabled && !uiState.isPlaying,
                    showRigBones = uiState.showRigOverlay && !uiState.isPlaying,
                    showMotionPaths = uiState.showMotionPaths && !uiState.isPlaying,
                    selectedLayerId = uiState.selectedLayer?.id,
                    selectedBoneId = uiState.selectedBoneId,
                    activePreviewStroke = activeStroke,
                    activePreviewShape = activeShape
                )
                nc.restore()
            }

            // Stage Frame Border
            drawRect(
                color = if (uiState.isPlaying) StudioCoral else if (uiState.activeTool == EditorTool.SELECT) StudioCyan else StudioBorder,
                topLeft = Offset(originX, originY),
                size = Size(stageW, stageH),
                style = Stroke(width = 2.5f)
            )
        }

        // Top-Left Stage HUD Badge
        Surface(
            color = StudioSurface.copy(alpha = 0.88f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = uiState.activeTool.label.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioCoral
                )
                Text(
                    text = "• ${uiState.selectedLayer?.name ?: "No Layer"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextSecondary
                )
            }
        }

        // Bottom-Right Floating Zoom Controls
        Surface(
            color = StudioSurface.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom - 0.25f).coerceAtLeast(0.4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(Icons.Rounded.Remove, contentDescription = "Zoom out", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "${(uiState.canvasZoom * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioCyan
                )
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom + 0.25f).coerceAtMost(4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Zoom in", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = onResetViewport,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Reset zoom", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }
    }

    // Text Insertion Dialog when tapping stage with TEXT tool
    pendingTextPos?.let { pos ->
        AlertDialog(
            onDismissRequest = { pendingTextPos = null },
            containerColor = StudioSurface,
            title = { Text("Add Text to Stage", color = StudioTextPrimary) },
            text = {
                OutlinedTextField(
                    value = textDraft,
                    onValueChange = { textDraft = it },
                    label = { Text("Caption or dialogue") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    onAddText(textDraft, pos.x, pos.y)
                    pendingTextPos = null
                }) { Text("Place Text") }
            },
            dismissButton = {
                TextButton(onClick = { pendingTextPos = null }) { Text("Cancel") }
            }
        )
    }
}
