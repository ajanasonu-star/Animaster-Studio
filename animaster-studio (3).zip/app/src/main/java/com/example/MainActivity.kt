package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.EditorWorkspaceScreen
import com.example.ui.screens.ProjectHubScreen
import com.example.ui.theme.AnimasterStudioTheme
import com.example.ui.viewmodel.StudioViewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnimasterStudioTheme {
                AnimasterAppRoot()
            }
        }
    }
}

@Composable
private fun AnimasterAppRoot(
    viewModel: StudioViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val recoverySnapshot by viewModel.recoverySnapshot.collectAsStateWithLifecycle()
    val localAssets by viewModel.localAssets.collectAsStateWithLifecycle()

    // Zero-permission Android Photo Picker for PNG/JPG import
    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importImageFromUri(uri)
    }

    // SAF OpenDocument for SVG import
    val importSvgLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importSvgFromUri(uri)
    }

    // SAF OpenDocument for Audio file import
    val importAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Audio Track"
            viewModel.importAudioFromUri(uri, name)
        }
    }

    // SAF OpenDocument for Project JSON import
    val importProjectLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importProjectFromUri(uri)
    }

    // SAF CreateDocument for Project JSON backup export
    val exportProjectJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) viewModel.exportProjectJsonToUri(uri)
    }

    // SAF CreateDocument for saving rendered PNG / ZIP / GIF / MP4 / WebM to any folder on the phone
    var pendingExportSaveFile by remember { mutableStateOf<File?>(null) }
    val saveExportToDeviceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val src = pendingExportSaveFile
        pendingExportSaveFile = null
        if (uri != null && src != null) {
            viewModel.saveExportFileToUri(src, uri)
        }
    }

    // Runtime RECORD_AUDIO permission launcher for Voice Recording
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startVoiceRecording()
        } else {
            viewModel.showToast("Microphone permission is needed to record voice")
        }
    }

    if (uiState.activeProject == null) {
        ProjectHubScreen(
            projects = projects,
            recoverySnapshot = recoverySnapshot,
            statusBanner = uiState.statusBanner,
            onOpenProject = { viewModel.openProject(it) },
            onCreateProject = { name, w, h, fps, tpl ->
                viewModel.createNewProject(name, w, h, fps, tpl)
            },
            onDeleteProject = { viewModel.deleteProject(it) },
            onImportProject = { importProjectLauncher.launch(arrayOf("application/json", "*/*")) },
            onRecoverAutosave = { viewModel.recoverAutosave(it) },
            onDismissRecovery = { viewModel.dismissRecovery() }
        )
    } else {
        EditorWorkspaceScreen(
            viewModel = viewModel,
            uiState = uiState,
            localAssets = localAssets,
            onBackToHub = { viewModel.closeProjectToHub() },
            onImportImage = {
                pickImageLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onImportSvg = { importSvgLauncher.launch(arrayOf("image/svg+xml", "text/xml", "*/*")) },
            onImportAudio = { importAudioLauncher.launch(arrayOf("audio/*")) },
            onRequestRecordVoice = {
                val hasPerm = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (hasPerm) {
                    viewModel.startVoiceRecording()
                } else {
                    recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            },
            onExportProjectJson = {
                val safe = (uiState.activeProject?.name ?: "project").replace(Regex("[^A-Za-z0-9_\\-]"), "_")
                exportProjectJsonLauncher.launch("${safe}.animaster.json")
            },
            onSaveExportedToDevice = { file, _ ->
                pendingExportSaveFile = file
                saveExportToDeviceLauncher.launch(file.name)
            },
            onShareExportedFile = { file, mime ->
                runCatching {
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Share Exported Animation"))
                }.onFailure {
                    viewModel.showToast("Could not open share sheet")
                }
            }
        )
    }
}
