package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.AnimationProject
import com.example.data.model.AnimationScene
import com.example.data.model.ExportFormat
import com.example.data.model.ExportSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExportResult(
    val success: Boolean,
    val file: File? = null,
    val format: ExportFormat = ExportFormat.GIF,
    val savedGalleryPath: String? = null,
    val message: String
)

/**
 * 100% Local Offline Export Engine supporting PNG, PNG Sequence (ZIP),
 * Animated GIF (built-in GIF89a LZW encoder), MP4 (H.264 MediaCodec), and WebM (VP8 MediaCodec).
 */
class ExportEngine(private val context: Context) {

    private val exportDir: File by lazy {
        File(context.filesDir, "exports").apply { mkdirs() }
    }

    suspend fun copyExportFileToUri(sourceFile: File, targetUri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                FileInputStream(sourceFile).use { input -> input.copyTo(out) }
            }
            true
        }.getOrDefault(false)
    }

    suspend fun exportScene(
        project: AnimationProject,
        scene: AnimationScene,
        settings: ExportSettings,
        currentFrame: Int,
        onProgress: (Float, String) -> Unit
    ): ExportResult = withContext(Dispatchers.IO) {
        val safeName = project.name.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "animaster" }
        val stamp = System.currentTimeMillis() % 100000
        val outWidth = (settings.width / 2) * 2
        val outHeight = (settings.height / 2) * 2
        val startF = settings.startFrame.coerceIn(0, (scene.durationFrames - 1).coerceAtLeast(0))
        val endF = settings.endFrame.coerceIn(startF, (scene.durationFrames - 1).coerceAtLeast(0))

        try {
            val outFile = when (settings.format) {
                ExportFormat.PNG -> {
                    onProgress(0.3f, "Rendering PNG frame ${currentFrame + 1}...")
                    val file = File(exportDir, "${safeName}_frame${currentFrame + 1}_$stamp.png")
                    val bmp = SceneRenderer.renderSceneToBitmap(
                        scene, currentFrame, outWidth, outHeight, project.width, project.height
                    )
                    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    bmp.recycle()
                    onProgress(1f, "PNG exported!")
                    file
                }

                ExportFormat.PNG_SEQUENCE -> {
                    val file = File(exportDir, "${safeName}_sequence_$stamp.zip")
                    val total = (endF - startF + 1).coerceAtLeast(1)
                    ZipOutputStream(BufferedOutputStream(FileOutputStream(file))).use { zos ->
                        for (f in startF..endF) {
                            val idx = f - startF + 1
                            onProgress(idx.toFloat() / total, "Rendering frame $idx / $total...")
                            val bmp = SceneRenderer.renderSceneToBitmap(
                                scene, f, outWidth, outHeight, project.width, project.height
                            )
                            val entry = ZipEntry(String.format("frame_%04d.png", idx))
                            zos.putNextEntry(entry)
                            bmp.compress(Bitmap.CompressFormat.PNG, 100, zos)
                            zos.closeEntry()
                            bmp.recycle()
                        }
                    }
                    onProgress(1f, "PNG sequence archived!")
                    file
                }

                ExportFormat.GIF -> {
                    val file = File(exportDir, "${safeName}_$stamp.gif")
                    val total = (endF - startF + 1).coerceAtLeast(1)
                    val delayCs = (100 / settings.fps.coerceIn(4, 50)).coerceAtLeast(2)
                    val gifW = outWidth.coerceAtMost(640)
                    val gifH = ((gifW.toFloat() / outWidth) * outHeight).toInt().coerceAtLeast(32)

                    FileOutputStream(file).use { fos ->
                        val encoder = LocalGifEncoder(fos, gifW, gifH, delayCs)
                        encoder.writeHeader()
                        for (f in startF..endF) {
                            val idx = f - startF + 1
                            onProgress(idx.toFloat() / total, "Encoding GIF frame $idx / $total...")
                            val bmp = SceneRenderer.renderSceneToBitmap(
                                scene, f, gifW, gifH, project.width, project.height
                            )
                            encoder.addFrame(bmp)
                            bmp.recycle()
                        }
                        encoder.finish()
                    }
                    onProgress(1f, "Animated GIF encoded!")
                    file
                }

                ExportFormat.MP4 -> {
                    val file = File(exportDir, "${safeName}_$stamp.mp4")
                    encodeVideoLocal(
                        file = file,
                        mimeType = MediaFormat.MIMETYPE_VIDEO_AVC,
                        muxerFormat = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4,
                        project = project,
                        scene = scene,
                        width = outWidth,
                        height = outHeight,
                        fps = settings.fps,
                        quality = settings.quality,
                        startF = startF,
                        endF = endF,
                        onProgress = onProgress
                    )
                    file
                }

                ExportFormat.WEBM -> {
                    val file = File(exportDir, "${safeName}_$stamp.webm")
                    encodeVideoLocal(
                        file = file,
                        mimeType = MediaFormat.MIMETYPE_VIDEO_VP8,
                        muxerFormat = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM,
                        project = project,
                        scene = scene,
                        width = outWidth,
                        height = outHeight,
                        fps = settings.fps,
                        quality = settings.quality,
                        startF = startF,
                        endF = endF,
                        onProgress = onProgress
                    )
                    file
                }
            }

            val savedPath = saveToDeviceMediaStore(outFile, settings.format)
            ExportResult(
                success = true,
                file = outFile,
                format = settings.format,
                savedGalleryPath = savedPath,
                message = "Exported ${outFile.name} (${(outFile.length() / 1024).coerceAtLeast(1)} KB)"
            )
        } catch (e: Exception) {
            ExportResult(
                success = false,
                format = settings.format,
                message = "Export failed: ${e.localizedMessage ?: "Unsupported codec on device"}"
            )
        }
    }

    private fun encodeVideoLocal(
        file: File,
        mimeType: String,
        muxerFormat: Int,
        project: AnimationProject,
        scene: AnimationScene,
        width: Int,
        height: Int,
        fps: Int,
        quality: Int,
        startF: Int,
        endF: Int,
        onProgress: (Float, String) -> Unit
    ) {
        val alignedW = ((width / 16) * 16).coerceAtLeast(160)
        val alignedH = ((height / 16) * 16).coerceAtLeast(160)
        val bitrate = (alignedW * alignedH * fps * (0.08f + quality / 500f)).toInt().coerceIn(500_000, 6_000_000)

        val format = MediaFormat.createVideoFormat(mimeType, alignedW, alignedH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val codec = MediaCodec.createEncoderByType(mimeType)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val muxer = MediaMuxer(file.absolutePath, muxerFormat)
        val bufferInfo = MediaCodec.BufferInfo()
        var trackIndex = -1
        var muxerStarted = false

        fun drainEncoder(endOfStream: Boolean) {
            while (true) {
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) break
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (!muxerStarted) {
                            trackIndex = muxer.addTrack(codec.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                    }
                    outIndex >= 0 -> {
                        val encoded = codec.getOutputBuffer(outIndex)
                        if (encoded != null && bufferInfo.size > 0 && muxerStarted) {
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                encoded.position(bufferInfo.offset)
                                encoded.limit(bufferInfo.offset + bufferInfo.size)
                                muxer.writeSampleData(trackIndex, encoded, bufferInfo)
                            }
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
        }

        val total = (endF - startF + 1).coerceAtLeast(1)
        val frameDurationUs = 1_000_000L / fps.coerceAtLeast(1)
        try {
            for (f in startF..endF) {
                val idx = f - startF
                onProgress((idx + 1).toFloat() / total, "Encoding video frame ${idx + 1} / $total...")
                val bmp = SceneRenderer.renderSceneToBitmap(
                    scene, f, alignedW, alignedH, project.width, project.height
                )

                val inIdx = codec.dequeueInputBuffer(25_000)
                if (inIdx >= 0) {
                    val inputImage = runCatching { codec.getInputImage(inIdx) }.getOrNull()
                    if (inputImage != null) {
                        fillYuv420ImageFromBitmap(inputImage, bmp, alignedW, alignedH)
                        val byteSize = alignedW * alignedH * 3 / 2
                        codec.queueInputBuffer(inIdx, 0, byteSize, idx * frameDurationUs, 0)
                    } else {
                        val yuv = bitmapToNv12(bmp, alignedW, alignedH)
                        val inBuf = codec.getInputBuffer(inIdx)
                        inBuf?.clear()
                        inBuf?.put(yuv)
                        codec.queueInputBuffer(inIdx, 0, yuv.size, idx * frameDurationUs, 0)
                    }
                }
                bmp.recycle()
                drainEncoder(false)
            }
            val eosIdx = codec.dequeueInputBuffer(25_000)
            if (eosIdx >= 0) {
                codec.queueInputBuffer(eosIdx, 0, 0, total * frameDurationUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drainEncoder(true)
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
        onProgress(1f, "Video export complete!")
    }

    /**
     * Writes RGB pixels into a MediaCodec YUV_420_888 Input Image using each plane's exact
     * rowStride & pixelStride so BOTH planar (I420) and semi-planar (NV12) encoders work cleanly.
     */
    private fun fillYuv420ImageFromBitmap(image: Image, bitmap: Bitmap, w: Int, h: Int) {
        val argb = IntArray(w * h)
        bitmap.getPixels(argb, 0, w, 0, 0, w, h)

        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuf = yPlane.buffer
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer

        val yRowStride = yPlane.rowStride
        val yPixStride = yPlane.pixelStride
        val uRowStride = uPlane.rowStride
        val uPixStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixStride = vPlane.pixelStride

        for (j in 0 until h) {
            for (i in 0 until w) {
                val px = argb[j * w + i]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF

                val y = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255)
                val yPos = j * yRowStride + i * yPixStride
                if (yPos < yBuf.capacity()) yBuf.put(yPos, y.toByte())

                if (j % 2 == 0 && i % 2 == 0) {
                    val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val cx = i / 2
                    val cy = j / 2
                    val uPos = cy * uRowStride + cx * uPixStride
                    val vPos = cy * vRowStride + cx * vPixStride
                    if (uPos < uBuf.capacity()) uBuf.put(uPos, u.toByte())
                    if (vPos < vBuf.capacity()) vBuf.put(vPos, v.toByte())
                }
            }
        }
    }

    private fun bitmapToNv12(bitmap: Bitmap, w: Int, h: Int): ByteArray {
        val argb = IntArray(w * h)
        bitmap.getPixels(argb, 0, w, 0, 0, w, h)
        val yuv = ByteArray(w * h * 3 / 2)
        var yIndex = 0
        var uvIndex = w * h
        for (j in 0 until h) {
            for (i in 0 until w) {
                val px = argb[j * w + i]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                yuv[yIndex++] = y.coerceIn(0, 255).toByte()
                if (j % 2 == 0 && i % 2 == 0) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    if (uvIndex + 1 < yuv.size) {
                        yuv[uvIndex++] = u.coerceIn(0, 255).toByte()
                        yuv[uvIndex++] = v.coerceIn(0, 255).toByte()
                    }
                }
            }
        }
        return yuv
    }

    private fun saveToDeviceMediaStore(file: File, format: ExportFormat): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return file.absolutePath
        val resolver = context.contentResolver

        // Save images/GIFs to Gallery (Pictures/AnimasterStudio), videos to Movies/AnimasterStudio, ZIP to Downloads
        val (collection, relPath, label) = when (format) {
            ExportFormat.PNG, ExportFormat.GIF -> Triple(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                "${Environment.DIRECTORY_PICTURES}/AnimasterStudio",
                "Pictures/AnimasterStudio/${file.name}"
            )
            ExportFormat.MP4, ExportFormat.WEBM -> Triple(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                "${Environment.DIRECTORY_MOVIES}/AnimasterStudio",
                "Movies/AnimasterStudio/${file.name}"
            )
            ExportFormat.PNG_SEQUENCE -> Triple(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                "${Environment.DIRECTORY_DOWNLOADS}/AnimasterStudio",
                "Downloads/AnimasterStudio/${file.name}"
            )
        }

        return runCatching {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, format.mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
            }
            val uri = resolver.insert(collection, values) ?: return null
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { input -> input.copyTo(out) }
            }
            label
        }.getOrNull()
    }
}

/**
 * Pure Kotlin Animated GIF89a + LZW Encoder (zero native/external dependencies).
 */
private class LocalGifEncoder(
    private val out: OutputStream,
    private val width: Int,
    private val height: Int,
    private val delayCentiseconds: Int
) {
    private val palette = ByteArray(256 * 3)

    init {
        var idx = 0
        for (r in 0..5) {
            for (g in 0..5) {
                for (b in 0..5) {
                    palette[idx++] = (r * 51).toByte()
                    palette[idx++] = (g * 51).toByte()
                    palette[idx++] = (b * 51).toByte()
                }
            }
        }
        for (i in 0 until 40) {
            val v = (i * 255 / 39).toByte()
            palette[idx++] = v
            palette[idx++] = v
            palette[idx++] = v
        }
    }

    fun writeHeader() {
        out.write("GIF89a".toByteArray())
        writeShortLE(width)
        writeShortLE(height)
        out.write(0xF7)
        out.write(0x00)
        out.write(0x00)
        out.write(palette)

        // Netscape 2.0 Application Extension for infinite looping
        out.write(0x21)
        out.write(0xFF)
        out.write(11)
        out.write("NETSCAPE2.0".toByteArray())
        out.write(3)
        out.write(1)
        writeShortLE(0)
        out.write(0)
    }

    fun addFrame(bitmap: Bitmap) {
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val indexed = ByteArray(pixels.size)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val ri = (r * 5 + 127) / 255
            val gi = (g * 5 + 127) / 255
            val bi = (b * 5 + 127) / 255
            indexed[i] = (ri * 36 + gi * 6 + bi).toByte()
        }

        out.write(0x21)
        out.write(0xF9)
        out.write(4)
        out.write(0x04)
        writeShortLE(delayCentiseconds)
        out.write(0x00)
        out.write(0x00)

        out.write(0x2C)
        writeShortLE(0)
        writeShortLE(0)
        writeShortLE(width)
        writeShortLE(height)
        out.write(0x00)

        val minCodeSize = 8
        out.write(minCodeSize)
        writeLzwEncoded(indexed, minCodeSize)
        out.write(0x00)
    }

    fun finish() {
        out.write(0x3B)
        out.flush()
    }

    private fun writeShortLE(v: Int) {
        out.write(v and 0xFF)
        out.write((v shr 8) and 0xFF)
    }

    private fun writeLzwEncoded(data: ByteArray, minCodeSize: Int) {
        val clearCode = 1 shl minCodeSize
        val eoiCode = clearCode + 1
        var codeSize = minCodeSize + 1
        var nextCode = eoiCode + 1
        val maxTableSize = 4096

        val table = HashMap<Int, Int>(4096)
        val subBlock = ByteArray(255)
        var subBlockLen = 0
        var bitBuf = 0
        var bitCount = 0

        fun flushSubBlock() {
            if (subBlockLen > 0) {
                out.write(subBlockLen)
                out.write(subBlock, 0, subBlockLen)
                subBlockLen = 0
            }
        }

        fun emitCode(code: Int) {
            bitBuf = bitBuf or (code shl bitCount)
            bitCount += codeSize
            while (bitCount >= 8) {
                subBlock[subBlockLen++] = (bitBuf and 0xFF).toByte()
                bitBuf = bitBuf ushr 8
                bitCount -= 8
                if (subBlockLen == 255) flushSubBlock()
            }
        }

        emitCode(clearCode)
        if (data.isEmpty()) {
            emitCode(eoiCode)
            if (bitCount > 0) {
                subBlock[subBlockLen++] = (bitBuf and 0xFF).toByte()
            }
            flushSubBlock()
            return
        }

        var prefix = data[0].toInt() and 0xFF
        for (i in 1 until data.size) {
            val k = data[i].toInt() and 0xFF
            val key = (prefix shl 8) or k
            val existing = table[key]
            if (existing != null) {
                prefix = existing
            } else {
                emitCode(prefix)
                if (nextCode < maxTableSize) {
                    table[key] = nextCode++
                    if (nextCode > (1 shl codeSize) && codeSize < 12) {
                        codeSize++
                    }
                } else {
                    emitCode(clearCode)
                    table.clear()
                    codeSize = minCodeSize + 1
                    nextCode = eoiCode + 1
                }
                prefix = k
            }
        }
        emitCode(prefix)
        emitCode(eoiCode)
        if (bitCount > 0) {
            subBlock[subBlockLen++] = (bitBuf and 0xFF).toByte()
        }
        flushSubBlock()
    }
}
