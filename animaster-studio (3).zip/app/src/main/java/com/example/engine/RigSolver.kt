package com.example.engine

import com.example.data.model.RigBone
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class SolvedBone(
    val bone: RigBone,
    val start: Vec2,
    val end: Vec2,
    val worldAngleDeg: Float
)

object RigSolver {

    /**
     * Computes Forward Kinematics (FK) world coordinates for every bone in the rig.
     */
    fun solveForwardKinematics(
        rig: SkeletalRig,
        angleOverrides: Map<String, Float> = emptyMap()
    ): List<SolvedBone> {
        val boneMap = rig.bones.associateBy { it.id }
        val solved = LinkedHashMap<String, SolvedBone>()

        fun resolve(bone: RigBone): SolvedBone {
            solved[bone.id]?.let { return it }
            val localAngle = angleOverrides[bone.id] ?: bone.localAngleDeg
            val parentSolved = bone.parentId?.let { pid -> boneMap[pid]?.let { resolve(it) } }
            val start = parentSolved?.end ?: Vec2(rig.rootX, rig.rootY)
            val worldAngleDeg = (parentSolved?.worldAngleDeg ?: 0f) + localAngle
            val rad = Math.toRadians(worldAngleDeg.toDouble())
            val end = Vec2(
                x = start.x + (cos(rad) * bone.length).toFloat(),
                y = start.y + (sin(rad) * bone.length).toFloat()
            )
            val result = SolvedBone(bone, start, end, worldAngleDeg)
            solved[bone.id] = result
            return result
        }

        rig.bones.forEach { resolve(it) }
        return rig.bones.mapNotNull { solved[it.id] }
    }

    /**
     * Solves 2-bone analytical Inverse Kinematics (IK) when dragging a child bone's tip
     * toward [target], returning updated local angles for parent + child bones.
     * Falls back to 1-bone FK aiming if the bone has no parent.
     */
    fun solveDragTarget(
        rig: SkeletalRig,
        boneId: String,
        target: Vec2,
        currentAngles: Map<String, Float>,
        useIk: Boolean
    ): Map<String, Float> {
        val solvedList = solveForwardKinematics(rig, currentAngles)
        val solvedMap = solvedList.associateBy { it.bone.id }
        val targetSolved = solvedMap[boneId] ?: return currentAngles
        val bone = targetSolved.bone
        val parentSolved = bone.parentId?.let { solvedMap[it] }

        // 1-bone FK aim when IK disabled or root bone
        if (!useIk || parentSolved == null || parentSolved.bone.parentId == null) {
            val dx = target.x - targetSolved.start.x
            val dy = target.y - targetSolved.start.y
            val desiredWorld = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            val parentWorld = parentSolved?.worldAngleDeg ?: 0f
            return currentAngles + (bone.id to normalizeAngle(desiredWorld - parentWorld))
        }

        // 2-bone analytical IK on (parentBone -> bone)
        val grandParentWorld = parentSolved.bone.parentId?.let { solvedMap[it]?.worldAngleDeg } ?: 0f
        val rootPos = parentSolved.start
        val l1 = parentSolved.bone.length.coerceAtLeast(1f)
        val l2 = bone.length.coerceAtLeast(1f)
        val dx = target.x - rootPos.x
        val dy = target.y - rootPos.y
        val dist = hypot(dx, dy).coerceIn(kotlin.math.abs(l1 - l2) + 1f, l1 + l2 - 0.5f)

        val baseAngle = atan2(dy.toDouble(), dx.toDouble())
        val cosA = ((l1 * l1 + dist * dist - l2 * l2) / (2f * l1 * dist)).toDouble().coerceIn(-1.0, 1.0)
        val cosB = ((l1 * l1 + l2 * l2 - dist * dist) / (2f * l1 * l2)).toDouble().coerceIn(-1.0, 1.0)
        val angleA = acos(cosA)
        val angleB = acos(cosB)

        // Preserve bend sign from current local angle
        val bendSign = if ((currentAngles[bone.id] ?: bone.localAngleDeg) >= 0f) 1.0 else -1.0
        val worldParent = Math.toDegrees(baseAngle - bendSign * angleA).toFloat()
        val localParent = normalizeAngle(worldParent - grandParentWorld)
        val localChild = normalizeAngle(Math.toDegrees(bendSign * (PI - angleB)).toFloat())

        return currentAngles + mapOf(
            parentSolved.bone.id to localParent,
            bone.id to localChild
        )
    }

    private fun normalizeAngle(deg: Float): Float {
        var a = deg % 360f
        if (a > 180f) a -= 360f
        if (a < -180f) a += 360f
        return a
    }

    fun createHumanoidRig(
        name: String = "Hero Rig",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Spine", parentId = null, length = 95f, localAngleDeg = -90f, thickness = 26f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "neck", name = "Head", parentId = "spine", length = 62f, localAngleDeg = 0f, thickness = 38f, colorArgb = 0xFFF5C6A5L),
            RigBone(id = "arm_l_up", name = "L Upper Arm", parentId = "spine", length = 68f, localAngleDeg = -135f, thickness = 16f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "arm_l_low", name = "L Forearm", parentId = "arm_l_up", length = 62f, localAngleDeg = 28f, thickness = 14f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "arm_r_up", name = "R Upper Arm", parentId = "spine", length = 68f, localAngleDeg = 135f, thickness = 16f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "arm_r_low", name = "R Forearm", parentId = "arm_r_up", length = 62f, localAngleDeg = -28f, thickness = 14f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "leg_l_up", name = "L Thigh", parentId = null, length = 82f, localAngleDeg = 105f, thickness = 20f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_l_low", name = "L Shin", parentId = "leg_l_up", length = 78f, localAngleDeg = -12f, thickness = 16f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_r_up", name = "R Thigh", parentId = null, length = 82f, localAngleDeg = 75f, thickness = 20f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_r_low", name = "R Shin", parentId = "leg_r_up", length = 78f, localAngleDeg = 12f, thickness = 16f, colorArgb = 0xFFA78BFAL)
        )
        return SkeletalRig(name = name, rootX = rootX, rootY = rootY, bones = bones)
    }

    fun createCartoonMascotRig(rootX: Float = 640f, rootY: Float = 420f): SkeletalRig {
        val bones = listOf(
            RigBone(id = "body", name = "Body", parentId = null, length = 70f, localAngleDeg = -90f, thickness = 42f, colorArgb = 0xFFFBBF24L),
            RigBone(id = "head", name = "Head", parentId = "body", length = 54f, localAngleDeg = 0f, thickness = 48f, colorArgb = 0xFFFDE68AL),
            RigBone(id = "ear_l", name = "L Ear", parentId = "head", length = 42f, localAngleDeg = -35f, thickness = 14f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "ear_r", name = "R Ear", parentId = "head", length = 42f, localAngleDeg = 35f, thickness = 14f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "arm_l", name = "L Arm", parentId = "body", length = 52f, localAngleDeg = -125f, thickness = 14f, colorArgb = 0xFF34D399L),
            RigBone(id = "arm_r", name = "R Arm", parentId = "body", length = 52f, localAngleDeg = 125f, thickness = 14f, colorArgb = 0xFF34D399L),
            RigBone(id = "leg_l", name = "L Leg", parentId = null, length = 55f, localAngleDeg = 110f, thickness = 16f, colorArgb = 0xFF38BDF8L),
            RigBone(id = "leg_r", name = "R Leg", parentId = null, length = 55f, localAngleDeg = 70f, thickness = 16f, colorArgb = 0xFF38BDF8L)
        )
        return SkeletalRig(name = "Cartoon Mascot", rootX = rootX, rootY = rootY, bones = bones)
    }

    fun presetPoseAngles(poseName: String): Map<String, Float> = when (poseName) {
        "WAVE" -> mapOf(
            "spine" to -86f,
            "neck" to 8f,
            "arm_r_up" to 32f,
            "arm_r_low" to -52f,
            "arm_l_up" to -145f,
            "arm_l_low" to 18f
        )
        "WALK_A" -> mapOf(
            "spine" to -84f,
            "arm_l_up" to -110f,
            "arm_l_low" to 35f,
            "arm_r_up" to 158f,
            "arm_r_low" to -22f,
            "leg_l_up" to 125f,
            "leg_l_low" to -18f,
            "leg_r_up" to 58f,
            "leg_r_low" to 28f
        )
        "WALK_B" -> mapOf(
            "spine" to -94f,
            "arm_l_up" to -160f,
            "arm_l_low" to 22f,
            "arm_r_up" to 105f,
            "arm_r_low" to -35f,
            "leg_l_up" to 62f,
            "leg_l_low" to 25f,
            "leg_r_up" to 122f,
            "leg_r_low" to -15f
        )
        "JUMP" -> mapOf(
            "spine" to -90f,
            "arm_l_up" to -42f,
            "arm_l_low" to -20f,
            "arm_r_up" to 42f,
            "arm_r_low" to 20f,
            "leg_l_up" to 132f,
            "leg_l_low" to -65f,
            "leg_r_up" to 48f,
            "leg_r_low" to 65f
        )
        else -> mapOf(
            "spine" to -90f,
            "neck" to 0f,
            "arm_l_up" to -135f,
            "arm_l_low" to 28f,
            "arm_r_up" to 135f,
            "arm_r_low" to -28f,
            "leg_l_up" to 105f,
            "leg_l_low" to -12f,
            "leg_r_up" to 75f,
            "leg_r_low" to 12f
        )
    }
}
