package com.example.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.LruCache
import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationScene
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterSpec
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.FrameContent
import com.example.data.model.ImportedImageItem
import com.example.data.model.LayerType
import com.example.data.model.ShapeKind
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Deterministic high-performance 2D Canvas renderer shared between the live editor
 * and the offline PNG / GIF / MP4 / WebM export pipeline.
 */
object SceneRenderer {

    private val bitmapCache = object : LruCache<String, Bitmap>(24) {}

    fun getCachedBitmap(path: String): Bitmap? {
        if (path.isBlank()) return null
        bitmapCache.get(path)?.let { if (!it.isRecycled) return it }
        return runCatching {
            val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            BitmapFactory.decodeFile(path, opts)?.also { bitmapCache.put(path, it) }
        }.getOrNull()
    }

    fun renderSceneToBitmap(
        scene: AnimationScene,
        frame: Int,
        outWidth: Int,
        outHeight: Int,
        projectWidth: Int,
        projectHeight: Int,
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = false,
        showMotionPaths: Boolean = false,
        selectedLayerId: String? = null
    ): Bitmap {
        val bmp = Bitmap.createBitmap(outWidth.coerceAtLeast(16), outHeight.coerceAtLeast(16), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val sx = outWidth.toFloat() / projectWidth.toFloat()
        val sy = outHeight.toFloat() / projectHeight.toFloat()
        canvas.scale(sx, sy)
        renderScene(
            canvas = canvas,
            scene = scene,
            frame = frame,
            projectWidth = projectWidth.toFloat(),
            projectHeight = projectHeight.toFloat(),
            onionSkin = onionSkin,
            ghostFrames = ghostFrames,
            showRigBones = showRigBones,
            showMotionPaths = showMotionPaths,
            selectedLayerId = selectedLayerId,
            activePreviewStroke = null,
            activePreviewShape = null
        )
        return bmp
    }

    fun renderScene(
        canvas: Canvas,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Float,
        projectHeight: Float,
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = true,
        showMotionPaths: Boolean = true,
        selectedLayerId: String? = null,
        selectedBoneId: String? = null,
        activePreviewStroke: DrawStroke? = null,
        activePreviewShape: VectorShape? = null
    ) {
        val camera = InterpolationEngine.evaluateCamera(scene, frame)

        // 1. Render background template with subtle camera parallax
        drawBackgroundTemplate(
            canvas = canvas,
            templateName = scene.backgroundTemplate,
            bgColorArgb = scene.backgroundColorArgb,
            w = projectWidth,
            h = projectHeight,
            panX = camera.panX * 0.35f,
            panY = camera.panY * 0.35f
        )

        // 2. Render onion skinning (past = violet, future = cyan) & ghost frames
        if (onionSkin || ghostFrames) {
            val offsets = if (ghostFrames) listOf(-3, -2, -1, 1, 2) else listOf(-1, 1)
            for (delta in offsets) {
                val targetF = frame + delta
                if (targetF in 0 until scene.durationFrames) {
                    val alpha = if (kotlin.math.abs(delta) == 1) 0.28f else 0.14f
                    val tint = if (delta < 0) 0xFFA78BFAL else 0xFF2DD4BFL
                    scene.layers.filter { it.visible }.forEach { layer ->
                        drawLayerAtFrame(
                            canvas = canvas,
                            scene = scene,
                            layer = layer,
                            frame = targetF,
                            camera = camera,
                            projectWidth = projectWidth,
                            projectHeight = projectHeight,
                            overrideAlpha = alpha,
                            tintColorArgb = tint,
                            showRigOverlay = false,
                            selectedBoneId = null
                        )
                    }
                }
            }
        }

        // 3. Render current frame layers (bottom to top)
        scene.layers.filter { it.visible }.forEach { layer ->
            drawLayerAtFrame(
                canvas = canvas,
                scene = scene,
                layer = layer,
                frame = frame,
                camera = camera,
                projectWidth = projectWidth,
                projectHeight = projectHeight,
                overrideAlpha = null,
                tintColorArgb = null,
                showRigOverlay = showRigBones,
                selectedBoneId = if (layer.id == selectedLayerId) selectedBoneId else null
            )

            // Draw motion path overlay if requested
            if (showMotionPaths && layer.motionPath.size >= 2) {
                drawMotionPathOverlay(canvas, layer.motionPath, layer.id == selectedLayerId)
            }
        }

        // 4. Render live in-progress stroke / shape preview in camera space
        if (activePreviewStroke != null || activePreviewShape != null) {
            canvas.save()
            applyCameraTransform(canvas, camera, projectWidth, projectHeight, 1f)
            activePreviewStroke?.let { drawStroke(canvas, it, 1f, null) }
            activePreviewShape?.let { drawVectorShape(canvas, it, 1f, null) }
            canvas.restore()
        }
    }

    private fun applyCameraTransform(
        canvas: Canvas,
        camera: EvaluatedCamera,
        w: Float,
        h: Float,
        parallax: Float
    ) {
        canvas.translate(w / 2f, h / 2f)
        canvas.rotate(camera.rotationDeg)
        val effectiveZoom = 1f + (camera.zoom - 1f) * parallax
        canvas.scale(effectiveZoom, effectiveZoom)
        canvas.translate(-w / 2f - camera.panX * parallax, -h / 2f - camera.panY * parallax)
    }

    private fun drawLayerAtFrame(
        canvas: Canvas,
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        camera: EvaluatedCamera,
        projectWidth: Float,
        projectHeight: Float,
        overrideAlpha: Float?,
        tintColorArgb: Long?,
        showRigOverlay: Boolean,
        selectedBoneId: String?
    ) {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val combinedAlpha = ((overrideAlpha ?: (layer.opacity * tf.opacity))).coerceIn(0f, 1f)
        if (combinedAlpha <= 0.01f) return

        canvas.save()
        applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)

        // Apply layer transform around canvas center
        canvas.translate(projectWidth / 2f + tf.x, projectHeight / 2f + tf.y)
        canvas.rotate(tf.rotationDeg)
        canvas.scale(tf.scaleX, tf.scaleY)
        canvas.translate(-projectWidth / 2f, -projectHeight / 2f)

        val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
        if (content != null) {
            drawFrameContent(canvas, content, combinedAlpha, tintColorArgb)
        }

        if (layer.type == LayerType.CHARACTER.name) {
            val charSpec = content?.characterOverride ?: layer.character
            if (charSpec != null) {
                drawCharacter(canvas, charSpec, combinedAlpha, tintColorArgb)
            }
        }

        if (layer.type == LayerType.RIG.name && layer.rig != null) {
            val angles = InterpolationEngine.evaluateRigAngles(layer.rig, frame)
            drawSkeletalRig(
                canvas = canvas,
                rig = layer.rig,
                angles = angles,
                alpha = combinedAlpha,
                tintColorArgb = tintColorArgb,
                showOverlay = showRigOverlay,
                selectedBoneId = selectedBoneId
            )
        }

        canvas.restore()
    }

    private fun drawFrameContent(
        canvas: Canvas,
        content: FrameContent,
        alpha: Float,
        tintColorArgb: Long?
    ) {
        content.images.forEach { img -> drawImportedImage(canvas, img, alpha) }
        content.shapes.forEach { shape -> drawVectorShape(canvas, shape, alpha, tintColorArgb) }
        content.strokes.forEach { stroke -> drawStroke(canvas, stroke, alpha, tintColorArgb) }
        content.texts.forEach { textItem -> drawTextItem(canvas, textItem, alpha, tintColorArgb) }
    }

    private fun drawImportedImage(canvas: Canvas, item: ImportedImageItem, layerAlpha: Float) {
        val bmp = getCachedBitmap(item.filePath) ?: return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (layerAlpha * item.opacity * 255).toInt().coerceIn(0, 255)
        }
        canvas.save()
        canvas.translate(item.x, item.y)
        canvas.rotate(item.rotationDeg)
        val dst = RectF(-item.width / 2f, -item.height / 2f, item.width / 2f, item.height / 2f)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
    }

    private fun drawStroke(canvas: Canvas, stroke: DrawStroke, layerAlpha: Float, tintColorArgb: Long?) {
        if (stroke.points.isEmpty()) return
        val effectiveAlpha = (layerAlpha * stroke.opacity * 255).toInt().coerceIn(0, 255)
        val baseColor = (tintColorArgb ?: stroke.colorArgb).toInt()

        if (stroke.tool == EditorTool.AIRBRUSH.name) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = baseColor
                style = Paint.Style.FILL
                alpha = (effectiveAlpha * 0.25f).toInt().coerceIn(8, 255)
            }
            val spread = stroke.strokeWidth * 1.4f
            val rng = Random(stroke.id.hashCode())
            stroke.points.forEach { pt ->
                repeat(10) {
                    val a = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * spread
                    canvas.drawCircle(
                        pt.x + cos(a) * r,
                        pt.y + sin(a) * r,
                        (stroke.strokeWidth * 0.14f).coerceAtLeast(1.5f),
                        dotPaint
                    )
                }
            }
            return
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = baseColor
            style = if (stroke.isClosedBezier) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
            strokeWidth = if (stroke.tool == EditorTool.PENCIL.name) {
                (stroke.strokeWidth * 0.55f).coerceAtLeast(1.5f)
            } else {
                stroke.strokeWidth
            }
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = effectiveAlpha
        }

        if (stroke.gradientEndArgb != null && tintColorArgb == null && stroke.points.size >= 2) {
            val first = stroke.points.first()
            val last = stroke.points.last()
            paint.shader = LinearGradient(
                first.x, first.y, last.x, last.y,
                stroke.colorArgb.toInt(),
                stroke.gradientEndArgb.toInt(),
                Shader.TileMode.CLAMP
            )
        }

        if (stroke.points.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(stroke.points[0].x, stroke.points[0].y, paint.strokeWidth / 2f, paint)
            return
        }

        val path = Path().apply {
            moveTo(stroke.points[0].x, stroke.points[0].y)
            for (i in 1 until stroke.points.size) {
                val prev = stroke.points[i - 1]
                val curr = stroke.points[i]
                val midX = (prev.x + curr.x) / 2f
                val midY = (prev.y + curr.y) / 2f
                quadTo(prev.x, prev.y, midX, midY)
            }
            val last = stroke.points.last()
            lineTo(last.x, last.y)
            if (stroke.isClosedBezier) close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawVectorShape(canvas: Canvas, shape: VectorShape, layerAlpha: Float, tintColorArgb: Long?) {
        val alphaInt = (layerAlpha * shape.opacity * 255).toInt().coerceIn(0, 255)
        val kind = runCatching { ShapeKind.valueOf(shape.kind) }.getOrDefault(ShapeKind.RECTANGLE)
        val rect = RectF(
            min(shape.startX, shape.endX),
            min(shape.startY, shape.endY),
            kotlin.math.max(shape.startX, shape.endX),
            kotlin.math.max(shape.startY, shape.endY)
        )

        canvas.save()
        if (shape.rotationDeg != 0f) {
            canvas.rotate(shape.rotationDeg, rect.centerX(), rect.centerY())
        }

        val fillPaint = shape.fillColorArgb?.let { fillHex ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = (tintColorArgb ?: fillHex).toInt()
                alpha = alphaInt
                if (shape.gradientEndArgb != null && tintColorArgb == null) {
                    shader = LinearGradient(
                        rect.left, rect.top, rect.right, rect.bottom,
                        fillHex.toInt(), shape.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                    )
                }
            }
        }

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: shape.strokeColorArgb).toInt()
            strokeWidth = shape.strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (kind) {
            ShapeKind.LINE -> canvas.drawLine(shape.startX, shape.startY, shape.endX, shape.endY, strokePaint)
            ShapeKind.RECTANGLE -> {
                fillPaint?.let { canvas.drawRoundRect(rect, 10f, 10f, it) }
                if (shape.strokeWidth > 0f) canvas.drawRoundRect(rect, 10f, 10f, strokePaint)
            }
            ShapeKind.FILL_BACKDROP -> {
                fillPaint?.let { canvas.drawRect(rect, it) }
            }
            ShapeKind.CIRCLE -> {
                fillPaint?.let { canvas.drawOval(rect, it) }
                if (shape.strokeWidth > 0f) canvas.drawOval(rect, strokePaint)
            }
            ShapeKind.POLYGON -> {
                val sides = shape.polygonSides.coerceIn(3, 12)
                val cx = rect.centerX()
                val cy = rect.centerY()
                val rx = rect.width() / 2f
                val ry = rect.height() / 2f
                val path = Path()
                for (i in 0 until sides) {
                    val angle = (i * 2.0 * PI / sides) - PI / 2.0
                    val px = cx + (cos(angle) * rx).toFloat()
                    val py = cy + (sin(angle) * ry).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                fillPaint?.let { canvas.drawPath(path, it) }
                if (shape.strokeWidth > 0f) canvas.drawPath(path, strokePaint)
            }
        }
        canvas.restore()
    }

    private fun drawTextItem(canvas: Canvas, item: CanvasTextItem, layerAlpha: Float, tintColorArgb: Long?) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (tintColorArgb ?: item.colorArgb).toInt()
            textSize = item.fontSize
            typeface = if (item.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            alpha = (layerAlpha * 255).toInt().coerceIn(0, 255)
        }
        canvas.drawText(item.text, item.x, item.y, paint)
    }

    fun drawCharacter(canvas: Canvas, c: CharacterSpec, layerAlpha: Float, tintColorArgb: Long?) {
        val alphaInt = (layerAlpha * 255).toInt().coerceIn(0, 255)
        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 4.5f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        canvas.save()
        canvas.translate(c.x, c.y)
        canvas.scale(c.scale, c.scale)

        // Pose offsets
        val legSpread = when (c.pose) {
            "WALK_A" -> 34f
            "WALK_B" -> -34f
            "JUMP" -> 42f
            "HERO" -> 28f
            else -> 18f
        }
        val bodyBob = when (c.pose) {
            "JUMP" -> -36f
            "SIT" -> 28f
            "WALK_A", "WALK_B" -> -6f
            else -> 0f
        }
        canvas.translate(0f, bodyBob)

        // Shadow
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((alphaInt * 0.28f).toInt(), 0, 0, 0)
        }
        canvas.drawOval(RectF(-58f, 152f - bodyBob, 58f, 174f - bodyBob), shadowPaint)

        // Cape behind body if CAPE shirt style
        if (c.shirtStyle == "CAPE") {
            val capePath = Path().apply {
                moveTo(-36f, -6f)
                lineTo(36f, -6f)
                lineTo(66f, 118f)
                lineTo(-66f, 118f)
                close()
            }
            canvas.drawPath(capePath, pFill(c.shirtColorArgb))
            canvas.drawPath(capePath, outline)
        }

        // Legs
        val pantsPaint = pFill(c.pantsColorArgb)
        val legL = RectF(-30f - legSpread * 0.4f, 68f, -6f - legSpread * 0.2f, if (c.pose == "SIT") 124f else 156f)
        val legR = RectF(6f + legSpread * 0.2f, 68f, 30f + legSpread * 0.4f, if (c.pose == "SIT") 124f else 156f)
        canvas.drawRoundRect(legL, 12f, 12f, pantsPaint)
        canvas.drawRoundRect(legL, 12f, 12f, outline)
        canvas.drawRoundRect(legR, 12f, 12f, pantsPaint)
        canvas.drawRoundRect(legR, 12f, 12f, outline)

        // Torso / Shirt
        val shirtPaint = pFill(c.shirtColorArgb)
        val torso = RectF(-42f, -14f, 42f, 82f)
        canvas.drawRoundRect(torso, 24f, 24f, shirtPaint)
        canvas.drawRoundRect(torso, 24f, 24f, outline)

        // Arms based on pose
        val skinPaint = pFill(c.skinToneArgb)
        val armPaint = pFill(c.shirtColorArgb)
        val leftArmAngle = when (c.pose) {
            "JUMP" -> -140f
            "HERO" -> -25f
            "WALK_A" -> 28f
            "WALK_B" -> -28f
            else -> 18f
        }
        val rightArmAngle = when (c.pose) {
            "WAVE" -> -135f
            "JUMP" -> 140f
            "HERO" -> 25f
            "WALK_A" -> -28f
            "WALK_B" -> 28f
            else -> -18f
        }

        // Left arm
        canvas.save()
        canvas.translate(-40f, 4f)
        canvas.rotate(leftArmAngle)
        canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, armPaint)
        canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, outline)
        canvas.drawCircle(0f, 70f, 11f, skinPaint)
        canvas.drawCircle(0f, 70f, 11f, outline)
        canvas.restore()

        // Right arm
        canvas.save()
        canvas.translate(40f, 4f)
        canvas.rotate(rightArmAngle)
        canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, armPaint)
        canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, outline)
        canvas.drawCircle(0f, 70f, 11f, skinPaint)
        canvas.drawCircle(0f, 70f, 11f, outline)
        canvas.restore()

        // Scarf accessory
        if (c.accessory == "SCARF") {
            val scarfPaint = pFill(0xFFFB7185L)
            canvas.drawRoundRect(RectF(-38f, -18f, 38f, 4f), 10f, 10f, scarfPaint)
            canvas.drawRoundRect(RectF(12f, -6f, 32f, 42f), 8f, 8f, scarfPaint)
            canvas.drawRoundRect(RectF(-38f, -18f, 38f, 4f), 10f, 10f, outline)
        }

        // Head
        val headRect = when (c.faceShape) {
            "ROUND" -> RectF(-56f, -124f, 56f, -14f)
            "SQUARE" -> RectF(-52f, -124f, 52f, -14f)
            "CHIBI" -> RectF(-64f, -132f, 64f, -12f)
            else -> RectF(-50f, -128f, 50f, -12f)
        }
        val headRadius = if (c.faceShape == "SQUARE") 22f else 54f
        canvas.drawRoundRect(headRect, headRadius, headRadius, skinPaint)
        canvas.drawRoundRect(headRect, headRadius, headRadius, outline)

        // Hair
        val hairPaint = pFill(c.hairColorArgb)
        when (c.hairStyle) {
            "SPIKY" -> {
                val spikes = Path().apply {
                    moveTo(-54f, -84f)
                    lineTo(-64f, -126f); lineTo(-34f, -118f)
                    lineTo(-22f, -154f); lineTo(0f, -128f)
                    lineTo(24f, -152f); lineTo(36f, -118f)
                    lineTo(64f, -124f); lineTo(54f, -84f)
                    quadTo(0f, -108f, -54f, -84f)
                    close()
                }
                canvas.drawPath(spikes, hairPaint)
                canvas.drawPath(spikes, outline)
            }
            "BOB" -> {
                canvas.drawArc(RectF(-60f, -138f, 60f, -26f), 180f, 180f, true, hairPaint)
                canvas.drawRoundRect(RectF(-60f, -92f, -42f, -22f), 12f, 12f, hairPaint)
                canvas.drawRoundRect(RectF(42f, -92f, 60f, -22f), 12f, 12f, hairPaint)
                canvas.drawArc(RectF(-60f, -138f, 60f, -26f), 180f, 180f, false, outline)
            }
            "PONYTAIL" -> {
                canvas.drawOval(RectF(36f, -120f, 84f, -58f), hairPaint)
                canvas.drawOval(RectF(36f, -120f, 84f, -58f), outline)
                canvas.drawArc(RectF(-58f, -138f, 58f, -46f), 180f, 180f, true, hairPaint)
                canvas.drawArc(RectF(-58f, -138f, 58f, -46f), 180f, 180f, false, outline)
            }
            "CURLY" -> {
                for (i in -2..2) {
                    canvas.drawCircle(i * 22f, -124f + kotlin.math.abs(i) * 6f, 22f, hairPaint)
                    canvas.drawCircle(i * 22f, -124f + kotlin.math.abs(i) * 6f, 22f, outline)
                }
            }
            "MOHAWK" -> {
                val mohawk = Path().apply {
                    moveTo(-16f, -118f); lineTo(-24f, -162f)
                    lineTo(0f, -150f); lineTo(24f, -162f)
                    lineTo(16f, -118f); close()
                }
                canvas.drawPath(mohawk, hairPaint)
                canvas.drawPath(mohawk, outline)
            }
        }

        // Eyes & Expression
        val eyePaint = pFill(c.eyeColorArgb)
        val whitePaint = pFill(0xFFFFFFFFL)
        val eyeY = -68f
        listOf(-20f, 20f).forEachIndexed { idx, ex ->
            val isWinkRight = c.expression == "WINK" && idx == 1
            if (isWinkRight) {
                canvas.drawArc(RectF(ex - 11f, eyeY - 6f, ex + 11f, eyeY + 8f), 200f, 140f, false, outline)
            } else {
                when (c.eyeStyle) {
                    "DOT" -> canvas.drawCircle(ex, eyeY, 6f, pFill(0xFF0F172AL))
                    "COOL" -> {
                        canvas.drawRoundRect(RectF(ex - 14f, eyeY - 8f, ex + 14f, eyeY + 8f), 6f, 6f, pFill(0xFF0F172AL))
                    }
                    "STAR" -> {
                        canvas.drawCircle(ex, eyeY, 12f, whitePaint)
                        canvas.drawCircle(ex, eyeY, 8f, eyePaint)
                        canvas.drawCircle(ex - 3f, eyeY - 3f, 3.5f, whitePaint)
                        canvas.drawCircle(ex, eyeY, 12f, outline)
                    }
                    else -> {
                        canvas.drawOval(RectF(ex - 11f, eyeY - 13f, ex + 11f, eyeY + 13f), whitePaint)
                        canvas.drawCircle(ex, eyeY + 1f, 7.5f, eyePaint)
                        canvas.drawCircle(ex, eyeY + 1f, 4f, pFill(0xFF0F172AL))
                        canvas.drawCircle(ex - 3f, eyeY - 4f, 3f, whitePaint)
                        canvas.drawOval(RectF(ex - 11f, eyeY - 13f, ex + 11f, eyeY + 13f), outline)
                    }
                }
            }
            // Eyebrows based on expression
            val browLift = when (c.expression) {
                "SURPRISED" -> -7f
                "ANGRY" -> 4f
                else -> 0f
            }
            val tilt = when (c.expression) {
                "ANGRY" -> if (idx == 0) 6f else -6f
                "SAD" -> if (idx == 0) -5f else 5f
                else -> 0f
            }
            canvas.drawLine(ex - 10f, eyeY - 18f + browLift - tilt, ex + 10f, eyeY - 18f + browLift + tilt, outline)
        }

        // Mouth based on expression / style
        val mouthY = -36f
        when {
            c.expression == "SURPRISED" || c.mouthStyle == "O_SHAPE" -> {
                canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), pFill(0xFFBE123CL))
                canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), outline)
            }
            c.expression == "TALKING" || c.mouthStyle == "OPEN" -> {
                canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 14f), 0f, 180f, true, pFill(0xFFBE123CL))
                canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 14f), 0f, 180f, true, outline)
            }
            c.expression == "SAD" || c.expression == "ANGRY" -> {
                canvas.drawArc(RectF(-14f, mouthY, 14f, mouthY + 14f), 195f, 150f, false, outline)
            }
            c.mouthStyle == "CAT" -> {
                canvas.drawArc(RectF(-14f, mouthY - 4f, 0f, mouthY + 8f), 0f, 180f, false, outline)
                canvas.drawArc(RectF(0f, mouthY - 4f, 14f, mouthY + 8f), 0f, 180f, false, outline)
            }
            else -> {
                canvas.drawArc(RectF(-15f, mouthY - 10f, 15f, mouthY + 10f), 15f, 150f, false, outline)
            }
        }

        // Accessories on head
        when (c.accessory) {
            "GLASSES" -> {
                val frame = Paint(outline).apply { strokeWidth = 4f }
                canvas.drawRoundRect(RectF(-35f, eyeY - 15f, -5f, eyeY + 15f), 6f, 6f, frame)
                canvas.drawRoundRect(RectF(5f, eyeY - 15f, 35f, eyeY + 15f), 6f, 6f, frame)
                canvas.drawLine(-5f, eyeY, 5f, eyeY, frame)
            }
            "HEADPHONES" -> {
                val hpPaint = pFill(0xFF2DD4BFL)
                canvas.drawArc(RectF(-64f, -140f, 64f, -44f), 180f, 180f, false, Paint(outline).apply {
                    color = 0xFF2DD4BFL.toInt(); strokeWidth = 8f
                })
                canvas.drawRoundRect(RectF(-70f, -88f, -52f, -52f), 8f, 8f, hpPaint)
                canvas.drawRoundRect(RectF(52f, -88f, 70f, -52f), 8f, 8f, hpPaint)
            }
            "CROWN" -> {
                val crown = Path().apply {
                    moveTo(-26f, -126f); lineTo(-30f, -158f); lineTo(-10f, -142f)
                    lineTo(0f, -166f); lineTo(10f, -142f); lineTo(30f, -158f)
                    lineTo(26f, -126f); close()
                }
                canvas.drawPath(crown, pFill(0xFFFBBF24L))
                canvas.drawPath(crown, outline)
            }
            "HAT" -> {
                val hatPaint = pFill(0xFF334155L)
                canvas.drawRoundRect(RectF(-64f, -126f, 64f, -112f), 6f, 6f, hatPaint)
                canvas.drawRoundRect(RectF(-40f, -164f, 40f, -122f), 14f, 14f, hatPaint)
                canvas.drawRoundRect(RectF(-64f, -126f, 64f, -112f), 6f, 6f, outline)
            }
        }

        canvas.restore()
    }

    private fun drawSkeletalRig(
        canvas: Canvas,
        rig: SkeletalRig,
        angles: Map<String, Float>,
        alpha: Float,
        tintColorArgb: Long?,
        showOverlay: Boolean,
        selectedBoneId: String?
    ) {
        val solved = RigSolver.solveForwardKinematics(rig, angles)
        val alphaInt = (alpha * 255).toInt().coerceIn(0, 255)

        // 1. Draw stylized animated limb/skin capsules
        if (rig.showSkinMesh) {
            solved.forEach { sb ->
                val limbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = (tintColorArgb ?: sb.bone.colorArgb).toInt()
                    strokeWidth = sb.bone.thickness
                    strokeCap = Paint.Cap.ROUND
                    style = Paint.Style.STROKE
                    this.alpha = alphaInt
                }
                canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbPaint)
                if (sb.bone.name.contains("Head", ignoreCase = true)) {
                    val headFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = (tintColorArgb ?: sb.bone.colorArgb).toInt()
                        style = Paint.Style.FILL
                        this.alpha = alphaInt
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, sb.bone.thickness * 0.72f, headFill)
                }
            }
        }

        // 2. Draw technical rig bone widgets & IK joints
        if (showOverlay && tintColorArgb == null) {
            solved.forEach { sb ->
                val isSelected = sb.bone.id == selectedBoneId
                val boneColor = if (isSelected) 0xFFFF6B35.toInt() else 0xFF2DD4BF.toInt()
                val bonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = boneColor
                    style = Paint.Style.STROKE
                    strokeWidth = if (isSelected) 3.5f else 2.2f
                }
                // Tapered kite-bone polygon
                val dx = sb.end.x - sb.start.x
                val dy = sb.end.y - sb.start.y
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val ux = dx / len
                val uy = dy / len
                val px = -uy
                val py = ux
                val midX = sb.start.x + dx * 0.22f
                val midY = sb.start.y + dy * 0.22f
                val w = (len * 0.12f).coerceIn(5f, 12f)

                val bonePath = Path().apply {
                    moveTo(sb.start.x, sb.start.y)
                    lineTo(midX + px * w, midY + py * w)
                    lineTo(sb.end.x, sb.end.y)
                    lineTo(midX - px * w, midY - py * w)
                    close()
                }
                canvas.drawPath(bonePath, bonePaint)

                // Joint handle circle
                val jointFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (isSelected) 0xFFFF6B35.toInt() else 0xFFFFFFFF.toInt()
                    style = Paint.Style.FILL
                }
                canvas.drawCircle(sb.end.x, sb.end.y, if (isSelected) 8.5f else 6f, jointFill)
                canvas.drawCircle(sb.end.x, sb.end.y, if (isSelected) 8.5f else 6f, bonePaint)
            }
            // Root hub
            val rootPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFBBF24.toInt()
                style = Paint.Style.FILL
            }
            canvas.drawCircle(rig.rootX, rig.rootY, 9f, rootPaint)
        }
    }

    private fun drawMotionPathOverlay(canvas: Canvas, points: List<Vec2>, isSelected: Boolean) {
        val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isSelected) 0xFFFF6B35.toInt() else 0xFFA78BFA.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
            pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
        }
        val path = Path().apply {
            moveTo(points[0].x, points[0].y)
            for (i in 1 until points.size) lineTo(points[i].x, points[i].y)
        }
        canvas.drawPath(path, pathPaint)
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFBBF24.toInt()
            style = Paint.Style.FILL
        }
        points.forEach { canvas.drawCircle(it.x, it.y, 5.5f, dotPaint) }
    }

    private fun drawBackgroundTemplate(
        canvas: Canvas,
        templateName: String,
        bgColorArgb: Long,
        w: Float,
        h: Float,
        panX: Float,
        panY: Float
    ) {
        val template = runCatching { BackgroundTemplate.valueOf(templateName) }.getOrDefault(BackgroundTemplate.SOLID)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (template) {
            BackgroundTemplate.SOLID -> {
                paint.color = bgColorArgb.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            BackgroundTemplate.GRID_PAPER -> {
                paint.color = 0xFFF8FAFC.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                val gridPaint = Paint().apply {
                    color = 0xFFCBD5E1.toInt()
                    strokeWidth = 1.5f
                }
                val step = 64f
                var x = 0f
                while (x <= w) { canvas.drawLine(x, 0f, x, h, gridPaint); x += step }
                var y = 0f
                while (y <= h) { canvas.drawLine(0f, y, w, y, gridPaint); y += step }
                val centerPaint = Paint().apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f }
                canvas.drawLine(w / 2f, 0f, w / 2f, h, centerPaint)
                canvas.drawLine(0f, h / 2f, w, h / 2f, centerPaint)
            }
            BackgroundTemplate.SUNNY_MEADOW -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF38BDF8.toInt(), 0xFFBAE6FD.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.82f - panX * 0.2f, h * 0.2f - panY * 0.2f, 64f, paint)
                paint.color = 0xFF22C55E.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.62f, w * 0.7f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF16A34A.toInt()
                canvas.drawOval(RectF(w * 0.35f - panX * 0.7f, h * 0.66f, w * 1.25f - panX * 0.7f, h * 1.35f), paint)
            }
            BackgroundTemplate.CYBERPUNK_CITY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF090D1A.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Horizon glow
                paint.shader = LinearGradient(0f, h * 0.55f, 0f, h, 0x44FF6B35, 0x00000000, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, h * 0.55f, w, h, paint)
                paint.shader = null
                // Skyline silhouette buildings
                val bWidths = listOf(110f, 85f, 140f, 95f, 130f, 105f, 150f, 90f, 135f, 120f)
                val bHeights = listOf(260f, 380f, 220f, 420f, 300f, 360f, 250f, 410f, 290f, 330f)
                var bx = -40f - panX * 0.6f
                bWidths.forEachIndexed { idx, bw ->
                    val bh = bHeights[idx]
                    paint.color = 0xFF0F172A.toInt()
                    canvas.drawRect(bx, h - bh, bx + bw - 8f, h, paint)
                    // Neon accent windows
                    paint.color = if (idx % 2 == 0) 0xAA2DD4BF.toInt() else 0xAAFF6B35.toInt()
                    var wy = h - bh + 20f
                    while (wy < h - 60f) {
                        canvas.drawRect(bx + 14f, wy, bx + bw - 26f, wy + 7f, paint)
                        wy += 26f
                    }
                    bx += bw
                }
                // Floor grid
                paint.color = 0xFF151922.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
                paint.color = 0x552DD4BF
                paint.strokeWidth = 2f
                canvas.drawLine(0f, h * 0.78f, w, h * 0.78f, paint)
            }
            BackgroundTemplate.COZY_STUDIO -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF292524.toInt(), 0xFF1C1917.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF44403C.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0x33FBBF24
                canvas.drawCircle(w * 0.5f, h * 0.35f, 280f, paint)
            }
            BackgroundTemplate.OUTER_SPACE -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0xFF030712.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val rng = Random(42)
                paint.color = 0xFFFFFFFF.toInt()
                repeat(70) {
                    val sx = rng.nextFloat() * w
                    val sy = rng.nextFloat() * h
                    val sr = 1.5f + rng.nextFloat() * 2.5f
                    canvas.drawCircle(sx, sy, sr, paint)
                }
                paint.color = 0xFF7C3AED.toInt()
                canvas.drawCircle(w * 0.78f - panX * 0.3f, h * 0.28f, 74f, paint)
                paint.color = 0x552DD4BF
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 10f
                canvas.drawOval(RectF(w * 0.78f - 125f - panX * 0.3f, h * 0.28f - 24f, w * 0.78f + 125f - panX * 0.3f, h * 0.28f + 24f), paint)
            }
            BackgroundTemplate.SUNSET_DESERT -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f, 0xFF7C2D12.toInt(), 0xFFFB923C.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.5f, h * 0.58f, 92f, paint)
                paint.color = 0xFF9A3412.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.5f, h * 0.65f, w * 0.75f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF7C2D12.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.7f, w * 1.2f - panX * 0.7f, h * 1.35f), paint)
            }
        }
    }

    /**
     * Parses basic SVG geometric elements (<rect>, <circle>, <line>) from an imported SVG string
     * completely offline without external libraries.
     */
    fun parseSimpleSvgShapes(svgContent: String, canvasW: Float, canvasH: Float): List<VectorShape> {
        val shapes = mutableListOf<VectorShape>()
        val cx = canvasW / 2f
        val cy = canvasH / 2f

        fun extractAttr(tag: String, attr: String): Float? {
            val regex = Regex("""$attr\s*=\s*["']([0-9.\-]+)["']""")
            return regex.find(tag)?.groupValues?.getOrNull(1)?.toFloatOrNull()
        }

        Regex("<rect[^>]+>").findAll(svgContent).forEach { match ->
            val tag = match.value
            val x = extractAttr(tag, "x") ?: 0f
            val y = extractAttr(tag, "y") ?: 0f
            val w = extractAttr(tag, "width") ?: 120f
            val h = extractAttr(tag, "height") ?: 80f
            shapes.add(
                VectorShape(
                    kind = ShapeKind.RECTANGLE.name,
                    startX = cx - 150f + x,
                    startY = cy - 100f + y,
                    endX = cx - 150f + x + w,
                    endY = cy - 100f + y + h,
                    strokeColorArgb = 0xFF2DD4BFL,
                    fillColorArgb = 0x662DD4BF,
                    strokeWidth = 4f
                )
            )
        }
        Regex("<circle[^>]+>").findAll(svgContent).forEach { match ->
            val tag = match.value
            val x = extractAttr(tag, "cx") ?: 80f
            val y = extractAttr(tag, "cy") ?: 80f
            val r = extractAttr(tag, "r") ?: 50f
            shapes.add(
                VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = cx - 150f + x - r,
                    startY = cy - 100f + y - r,
                    endX = cx - 150f + x + r,
                    endY = cy - 100f + y + r,
                    strokeColorArgb = 0xFFFF6B35L,
                    fillColorArgb = 0x66FF6B35,
                    strokeWidth = 4f
                )
            )
        }
        Regex("<line[^>]+>").findAll(svgContent).forEach { match ->
            val tag = match.value
            val x1 = extractAttr(tag, "x1") ?: 0f
            val y1 = extractAttr(tag, "y1") ?: 0f
            val x2 = extractAttr(tag, "x2") ?: 120f
            val y2 = extractAttr(tag, "y2") ?: 120f
            shapes.add(
                VectorShape(
                    kind = ShapeKind.LINE.name,
                    startX = cx - 150f + x1,
                    startY = cy - 100f + y1,
                    endX = cx - 150f + x2,
                    endY = cy - 100f + y2,
                    strokeColorArgb = 0xFFFBBF24L,
                    strokeWidth = 5f
                )
            )
        }
        return shapes
    }
}
