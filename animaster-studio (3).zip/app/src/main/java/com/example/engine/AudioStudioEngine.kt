package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

enum class BuiltInAudioPreset(val title: String, val kind: AudioTrackKind, val durationSec: Float) {
    SFX_POP("Cartoon Pop", AudioTrackKind.SFX, 0.35f),
    SFX_BOING("Spring Boing", AudioTrackKind.SFX, 0.75f),
    SFX_WHOOSH("Fast Whoosh", AudioTrackKind.SFX, 0.55f),
    SFX_SPARKLE("Magic Chime", AudioTrackKind.SFX, 0.9f),
    SFX_FOOTSTEP("Soft Step", AudioTrackKind.SFX, 0.25f),
    MUSIC_SYNTH_LOOP("Studio Synth Loop", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_PLAYFUL_BEAT("Playful Marimba", AudioTrackKind.MUSIC, 3.2f)
}

class AudioStudioEngine(private val context: Context) {

    private val audioDir: File by lazy {
        File(context.filesDir, "audio").apply { mkdirs() }
    }

    private var activeRecorder: AudioRecord? = null
    @Volatile
    private var isRecordingFlag = false
    private val activePlayers = mutableListOf<MediaPlayer>()

    @SuppressLint("MissingPermission")
    suspend fun recordVoiceToWav(
        onAmplitude: (Float) -> Unit,
        onFinished: (AudioTrackItem?) -> Unit
    ) = withContext(Dispatchers.IO) {
        val sampleRate = 22050
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, encoding).coerceAtLeast(2048)

        val recorder = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, encoding, minBuf * 2)
        }.getOrNull()

        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        activeRecorder = recorder
        isRecordingFlag = true
        val pcmStream = ByteArrayOutputStream()
        val buffer = ShortArray(1024)

        try {
            recorder.startRecording()
            while (isRecordingFlag && isActive) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    var peak = 0
                    val byteBuf = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until read) {
                        val s = buffer[i]
                        byteBuf.putShort(s)
                        val a = abs(s.toInt())
                        if (a > peak) peak = a
                    }
                    pcmStream.write(byteBuf.array())
                    val norm = (peak / 32768f).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main) { onAmplitude(norm) }
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
            activeRecorder = null
            isRecordingFlag = false
        }

        val pcmBytes = pcmStream.toByteArray()
        if (pcmBytes.size < 400) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        val file = File(audioDir, "voice_${System.currentTimeMillis()}.wav")
        writeWavFile(file, pcmBytes, sampleRate)
        val durationMs = ((pcmBytes.size / 2.0) / sampleRate * 1000.0).toLong().coerceAtLeast(200L)
        val peaks = extractPeaksFromPcm16(pcmBytes, 48)
        val track = AudioTrackItem(
            id = UUID.randomUUID().toString(),
            name = "Voice Take ${(System.currentTimeMillis() % 1000)}",
            filePath = file.absolutePath,
            kind = AudioTrackKind.VOICE.name,
            startFrame = 0,
            durationMs = durationMs,
            trimStartMs = 0L,
            trimEndMs = durationMs,
            volume = 0.95f,
            fadeInMs = 50L,
            fadeOutMs = 80L,
            waveformPeaks = peaks
        )
        withContext(Dispatchers.Main) { onFinished(track) }
    }

    fun stopVoiceRecording() {
        isRecordingFlag = false
    }

    suspend fun synthesizeBuiltInPreset(preset: BuiltInAudioPreset, startFrame: Int): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val sampleRate = 22050
            val totalSamples = (sampleRate * preset.durationSec).toInt()
            val pcm = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
            val rng = Random(preset.ordinal * 997 + 13)

            for (i in 0 until totalSamples) {
                val t = i.toFloat() / sampleRate.toFloat()
                val progress = i.toFloat() / totalSamples.toFloat()
                val sample = when (preset) {
                    BuiltInAudioPreset.SFX_POP -> {
                        val freq = 220f + 560f * progress
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 14f)
                    }
                    BuiltInAudioPreset.SFX_BOING -> {
                        val freq = 140f + 240f * sin(2.0 * PI * 9.0 * t).toFloat()
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 3.2f)
                    }
                    BuiltInAudioPreset.SFX_WHOOSH -> {
                        val env = sin(PI * progress).toFloat()
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.45f
                        val tone = sin(2.0 * PI * (180f + 420f * progress) * t).toFloat() * 0.35f
                        (noise + tone) * env
                    }
                    BuiltInAudioPreset.SFX_SPARKLE -> {
                        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f)
                        val noteIdx = (progress * notes.size).toInt().coerceIn(0, notes.lastIndex)
                        val localT = t - (noteIdx * (preset.durationSec / notes.size))
                        val env = exp(-localT.coerceAtLeast(0f) * 8f)
                        (sin(2.0 * PI * notes[noteIdx] * t) + 0.4 * sin(4.0 * PI * notes[noteIdx] * t)).toFloat() * 0.6f * env
                    }
                    BuiltInAudioPreset.SFX_FOOTSTEP -> {
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.5f
                        val thud = sin(2.0 * PI * (95f - 45f * progress) * t).toFloat() * 0.6f
                        (noise + thud) * exp(-t * 22f)
                    }
                    BuiltInAudioPreset.MUSIC_SYNTH_LOOP -> {
                        val stepDur = 0.2f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val chord = floatArrayOf(261.63f, 329.63f, 392.0f, 329.63f, 220.0f, 261.63f, 349.23f, 392.0f)
                        val f = chord[step % chord.size]
                        val bass = sin(2.0 * PI * (f / 2f) * t).toFloat() * 0.32f
                        val lead = sin(2.0 * PI * f * t).toFloat() * exp(-localT * 6.5f) * 0.45f
                        (bass + lead) * (1f - 0.1f * progress)
                    }
                    BuiltInAudioPreset.MUSIC_PLAYFUL_BEAT -> {
                        val stepDur = 0.16f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val scale = floatArrayOf(392f, 440f, 523.25f, 587.33f, 659.25f, 587.33f, 523.25f, 440f)
                        val f = scale[step % scale.size]
                        sin(2.0 * PI * f * t).toFloat() * exp(-localT * 11f) * 0.65f
                    }
                }
                val s16 = (sample.coerceIn(-0.98f, 0.98f) * 32000f).toInt().toShort()
                pcm.putShort(s16)
            }

            val pcmBytes = pcm.array()
            val file = File(audioDir, "preset_${preset.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(file, pcmBytes, sampleRate)
            val durationMs = (preset.durationSec * 1000L).toLong()
            AudioTrackItem(
                id = UUID.randomUUID().toString(),
                name = preset.title,
                filePath = file.absolutePath,
                kind = preset.kind.name,
                startFrame = startFrame,
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                volume = 0.85f,
                fadeInMs = 40L,
                fadeOutMs = 100L,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 44)
            )
        }

    suspend fun importAudioUri(uri: Uri, displayName: String, startFrame: Int): AudioTrackItem? =
        withContext(Dispatchers.IO) {
            val outFile = File(audioDir, "import_${System.currentTimeMillis()}.audio")
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(outFile.absolutePath)
                val durationMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.coerceAtLeast(300L) ?: 3000L
                mmr.release()

                val bytes = outFile.readBytes()
                val peaks = if (bytes.size > 44 && String(bytes.copyOfRange(0, 4)) == "RIFF") {
                    extractPeaksFromPcm16(bytes.copyOfRange(44, bytes.size), 48)
                } else {
                    extractApproximatePeaks(bytes, 48)
                }

                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    name = displayName.substringBeforeLast('.').ifBlank { "Imported Audio" },
                    filePath = outFile.absolutePath,
                    kind = AudioTrackKind.MUSIC.name,
                    startFrame = startFrame,
                    durationMs = durationMs,
                    trimStartMs = 0L,
                    trimEndMs = durationMs,
                    volume = 0.85f,
                    fadeInMs = 80L,
                    fadeOutMs = 120L,
                    waveformPeaks = peaks
                )
            }.getOrNull()
        }

    fun previewTrack(track: AudioTrackItem) {
        stopAllPlayback()
        if (track.muted || track.filePath.isBlank()) return
        val file = File(track.filePath)
        if (!file.exists()) return
        runCatching {
            val mp = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setVolume(track.volume, track.volume)
                if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                setOnCompletionListener {
                    it.release()
                    activePlayers.remove(it)
                }
                start()
            }
            activePlayers.add(mp)
        }
    }

    fun triggerTracksForFrame(tracks: List<AudioTrackItem>, frame: Int) {
        tracks.filter { !it.muted && it.startFrame == frame && it.filePath.isNotBlank() }.forEach { track ->
            val file = File(track.filePath)
            if (file.exists()) {
                runCatching {
                    val mp = MediaPlayer().apply {
                        setDataSource(file.absolutePath)
                        prepare()
                        setVolume(track.volume, track.volume)
                        if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                        setOnCompletionListener {
                            it.release()
                            activePlayers.remove(it)
                        }
                        start()
                    }
                    activePlayers.add(mp)
                }
            }
        }
    }

    fun stopAllPlayback() {
        val copy = activePlayers.toList()
        activePlayers.clear()
        copy.forEach { mp ->
            runCatching {
                if (mp.isPlaying) mp.stop()
                mp.release()
            }
        }
    }

    private fun writeWavFile(file: File, pcmData: ByteArray, sampleRate: Int) {
        val channels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + dataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1) // PCM
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort((channels * bitsPerSample / 8).toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray())
            putInt(dataSize)
        }
        FileOutputStream(file).use { out ->
            out.write(header.array())
            out.write(pcmData)
        }
    }

    private fun extractPeaksFromPcm16(pcmBytes: ByteArray, bars: Int): List<Float> {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return List(bars) { 0.15f }
        val step = (sampleCount / bars).coerceAtLeast(1)
        val bb = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)
        val peaks = mutableListOf<Float>()
        for (b in 0 until bars) {
            var maxAmp = 0
            val start = b * step
            val end = ((b + 1) * step).coerceAtMost(sampleCount)
            for (s in start until end) {
                val v = abs(bb.getShort(s * 2).toInt())
                if (v > maxAmp) maxAmp = v
            }
            peaks.add((maxAmp / 32768f).coerceIn(0.08f, 1f))
        }
        return peaks
    }

    private fun extractApproximatePeaks(bytes: ByteArray, bars: Int): List<Float> {
        if (bytes.isEmpty()) return List(bars) { 0.25f }
        val step = (bytes.size / bars).coerceAtLeast(1)
        return List(bars) { b ->
            val idx = (b * step).coerceIn(0, bytes.lastIndex)
            val norm = abs(bytes[idx].toInt()) / 128f
            norm.coerceIn(0.15f, 0.95f)
        }
    }
}
