package com.example

import com.example.data.model.AnimationLayer
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.CharacterViewAngle
import com.example.data.model.EasingType
import com.example.data.model.EyePackStyle
import com.example.data.model.FrameContent
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.engine.InterpolationEngine
import com.example.engine.MotionPreset
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.engine.StoryboardTemplate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot

class AnimasterEngineTest {

    @Test
    fun interpolation_easingAndKeyframes() {
        val layer = AnimationLayer(
            keyframes = listOf(
                TransformKeyframe(frame = 0, x = 0f, y = 0f, scaleX = 1f, easing = EasingType.LINEAR.name),
                TransformKeyframe(frame = 10, x = 100f, y = -50f, scaleX = 2f, easing = EasingType.LINEAR.name)
            )
        )
        val mid = InterpolationEngine.evaluateLayerTransform(layer, frame = 5, totalFrames = 20)
        assertEquals(50f, mid.x, 0.01f)
        assertEquals(-25f, mid.y, 0.01f)
        assertEquals(1.5f, mid.scaleX, 0.01f)

        // SNAP easing holds 0 until t >= 0.999f
        assertEquals(0f, InterpolationEngine.applyEasing(0.5f, EasingType.SNAP.name), 0.001f)
        assertEquals(1f, InterpolationEngine.applyEasing(1f, EasingType.SNAP.name), 0.001f)
    }

    @Test
    fun interpolation_puppetRootAndAutoLipSync() {
        val rig = RigSolver.createHumanoidRig(rootX = 300f, rootY = 400f).copy(
            rootKeyframes = listOf(
                PuppetRootKeyframe(
                    frame = 0, rootX = 200f, rootY = 400f, scale = 1f,
                    flippedHorizontal = false, eyePack = EyePackStyle.AUTO_BLINK.name,
                    mouthPhoneme = MouthPhoneme.REST.name, easing = EasingType.LINEAR.name
                ),
                PuppetRootKeyframe(
                    frame = 10, rootX = 600f, rootY = 300f, scale = 1.5f,
                    flippedHorizontal = true, eyePack = EyePackStyle.HAPPY.name,
                    mouthPhoneme = MouthPhoneme.A.name, easing = EasingType.LINEAR.name
                )
            )
        )
        val mid = InterpolationEngine.evaluatePuppetRoot(rig, frame = 5)
        assertEquals(400f, mid.rootX, 0.01f)
        assertEquals(350f, mid.rootY, 0.01f)
        assertEquals(1.25f, mid.scale, 0.01f)
        assertFalse(mid.flippedHorizontal)

        val end = InterpolationEngine.evaluatePuppetRoot(rig, frame = 10)
        assertTrue(end.flippedHorizontal)
        assertEquals(EyePackStyle.HAPPY.name, end.eyePack)
        assertEquals(MouthPhoneme.A.name, end.mouthPhoneme)

        val quietTrack = AudioTrackItem(
            kind = AudioTrackKind.VOICE.name,
            startFrame = 0,
            trimStartMs = 0L,
            trimEndMs = 1000L,
            waveformPeaks = listOf(0.05f, 0.40f, 0.85f)
        )
        assertEquals(MouthPhoneme.REST, InterpolationEngine.evaluateLipSyncPhoneme(listOf(quietTrack), frame = 0, fps = 24))
        assertEquals(MouthPhoneme.A, InterpolationEngine.evaluateLipSyncPhoneme(listOf(quietTrack), frame = 20, fps = 24))
    }

    @Test
    fun rigSolver_fkTwoBoneIkAndAutoWalk() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 400f)
        val fk = RigSolver.solveForwardKinematics(rig)
        assertEquals(rig.bones.size, fk.size)

        val currentAngles = rig.bones.associate { it.id to it.localAngleDeg }
        val target = Vec2(600f, 340f)
        val solvedAngles = RigSolver.solveDragTarget(rig, "arm_r_low", target, currentAngles, useIk = true)
        val fkAfter = RigSolver.solveForwardKinematics(rig, solvedAngles)
        val hand = fkAfter.first { it.bone.id == "arm_r_low" }
        assertTrue(hypot(hand.end.x - target.x, hand.end.y - target.y) < 35f)

        val walkA = RigSolver.computeAutoWalkPose(travelX = 24f)
        val walkB = RigSolver.computeAutoWalkPose(travelX = 120f)
        assertNotEquals(walkA["leg_l_up"], walkB["leg_l_up"])
        assertNotEquals(walkA["arm_r_up"], walkB["arm_r_up"])
    }

    @Test
    fun proceduralTemplatesCameraToolsAndSvgParser() {
        val proj = ProceduralSmartTools.createProjectFromTemplate("Test", 1280, 720, 24, StoryboardTemplate.THREE_ACT_STORY)
        assertEquals(3, proj.scenes.size)

        val heroProj = ProceduralSmartTools.createProjectFromTemplate("Hero", 1280, 720, 24, StoryboardTemplate.HERO_DEMO)
        assertEquals(96, heroProj.scenes.first().durationFrames)
        assertTrue(heroProj.scenes.first().layers.count { it.rig != null } >= 2)

        val rigLayer = heroProj.scenes.first().layers.first { it.rig != null }
        val followed = ProceduralSmartTools.applyCameraFollowCharacter(heroProj.scenes.first(), rigLayer.id, 1280, 720)
        assertTrue(followed.cameraKeyframes.size >= 4)

        val shaken = ProceduralSmartTools.applyCameraShake(heroProj.scenes.first(), startFrame = 12, intensity = 24f)
        assertTrue(shaken.cameraKeyframes.size >= 6)

        val movedLayer = ProceduralSmartTools.applyMotionPreset(AnimationLayer(), MotionPreset.BOUNCE_LOOP, 36)
        assertTrue(movedLayer.keyframes.size >= 3)

        val svg = """<svg><rect x="10" y="20" width="100" height="50"/><circle cx="60" cy="60" r="30"/></svg>"""
        val shapes = SceneRenderer.parseSimpleSvgShapes(svg, 1280f, 720f)
        assertEquals(2, shapes.size)
    }

    @Test
    fun voiceChangerDsp_andHorrorStoryTemplate() {
        val sampleRate = 22050
        val input = ShortArray(4096) { i ->
            (kotlin.math.sin(2.0 * kotlin.math.PI * 220.0 * i / sampleRate) * 16000.0).toInt().toShort()
        }
        val chipmunk = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.CHIPMUNK
        )
        val monster = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.DEEP_MONSTER
        )
        val ghost = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.GHOST_ECHO
        )
        val robot = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.ROBOT
        )
        assertTrue(chipmunk.size < input.size)
        assertTrue(monster.size > input.size)
        assertTrue(ghost.size > input.size)
        assertEquals(input.size, robot.size)

        val horror = ProceduralSmartTools.createProjectFromTemplate(
            "Haunted Ep 1", 1280, 720, 24, StoryboardTemplate.HORROR_STORY
        )
        val sc = horror.scenes.first()
        assertTrue(sc.backgroundScrollSpeed > 0f)
        assertTrue(sc.subtitles.size >= 2)
        assertTrue(sc.layers.any { it.opacity < 0.7f && it.rig != null })
    }

    @Test
    fun animatedTextModel_supportsAllKineticOptions() {
        val item = com.example.data.model.CanvasTextItem(
            text = "SUBSCRIBE\nNOW!",
            x = 640f,
            y = 220f,
            fontSize = 72f,
            colorArgb = 0xFFFFE066L,
            gradientEndArgb = 0xFFFF6B35L,
            fontStyle = com.example.data.model.TextFontStyle.BOLD_CARTOON.name,
            boxStyle = com.example.data.model.TextBoxStyle.YOUTUBE_PILL.name,
            inAnimation = com.example.data.model.TextInAnimation.TYPEWRITER.name,
            loopAnimation = com.example.data.model.TextLoopAnimation.WAVE.name,
            outAnimation = com.example.data.model.TextOutAnimation.POP_OUT.name,
            startFrame = 10,
            endFrame = 80
        )
        assertEquals(10, item.startFrame)
        assertEquals(80, item.endFrame)
        assertEquals(9, com.example.data.model.TextInAnimation.entries.size)
        assertEquals(8, com.example.data.model.TextLoopAnimation.entries.size)
        assertEquals(5, com.example.data.model.TextOutAnimation.entries.size)
    }

    @Test
    fun humanAutoRig_extremityIk_turnaroundAndHandProps() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 420f)
        val expectedIds = setOf(
            "pelvis", "waist", "spine", "neck_base", "neck",
            "shoulder_l", "shoulder_r",
            "arm_l_up", "arm_l_low", "hand_l",
            "arm_r_up", "arm_r_low", "hand_r",
            "hip_l", "hip_r",
            "leg_l_up", "leg_l_low", "foot_l",
            "leg_r_up", "leg_r_low", "foot_r"
        )
        assertEquals(21, rig.bones.size)
        assertEquals(expectedIds, rig.bones.map { it.id }.toSet())
        assertTrue(rig.bones.all { it.minAngleDeg == -720f && it.maxAngleDeg == 720f })

        // Pulling hand_r with IK enabled should drive arm_r_up & arm_r_low smoothly
        val initialAngles = rig.bones.associate { it.id to it.localAngleDeg }
        val handTarget = Vec2(620f, 340f)
        val ikAngles = RigSolver.solveDragTarget(rig, "hand_r", handTarget, initialAngles, useIk = true)
        val fkAfterHand = RigSolver.solveForwardKinematics(rig, ikAngles)
        val wristEnd = fkAfterHand.first { it.bone.id == "arm_r_low" }.end
        assertTrue(hypot(wristEnd.x - handTarget.x, wristEnd.y - handTarget.y) < 40f)

        // Auto-rigging an older/minimal rig upgrades it to full 21-bone connected human skeleton while preserving turnaround & hand props
        val minimalRig = rig.copy(
            bones = rig.bones.take(3),
            viewAngle = com.example.data.model.CharacterViewAngle.SIDE_RIGHT.name,
            leftHandProp = com.example.data.model.HandPropKind.LANTERN.name,
            rightHandProp = com.example.data.model.HandPropKind.SWORD.name
        )
        val autoRigged = RigSolver.autoRigHumanoid(minimalRig)
        assertEquals(21, autoRigged.bones.size)
        assertEquals(com.example.data.model.CharacterViewAngle.SIDE_RIGHT.name, autoRigged.viewAngle)
        assertEquals(com.example.data.model.HandPropKind.LANTERN.name, autoRigged.leftHandProp)
        assertEquals(com.example.data.model.HandPropKind.SWORD.name, autoRigged.rightHandProp)

        // 4-view turnaround propagates accurately across puppet root keyframes
        val turnaroundRig = autoRigged.copy(
            rootKeyframes = listOf(
                PuppetRootKeyframe(
                    frame = 0, rootX = 400f, rootY = 420f,
                    viewAngle = com.example.data.model.CharacterViewAngle.FRONT.name
                ),
                PuppetRootKeyframe(
                    frame = 12, rootX = 520f, rootY = 420f,
                    viewAngle = com.example.data.model.CharacterViewAngle.SIDE_LEFT.name
                ),
                PuppetRootKeyframe(
                    frame = 24, rootX = 640f, rootY = 420f,
                    viewAngle = com.example.data.model.CharacterViewAngle.BACK.name
                )
            )
        )
        assertEquals(
            com.example.data.model.CharacterViewAngle.FRONT.name,
            InterpolationEngine.evaluatePuppetRoot(turnaroundRig, frame = 4).viewAngle
        )
        assertEquals(
            com.example.data.model.CharacterViewAngle.SIDE_LEFT.name,
            InterpolationEngine.evaluatePuppetRoot(turnaroundRig, frame = 15).viewAngle
        )
        assertEquals(
            com.example.data.model.CharacterViewAngle.BACK.name,
            InterpolationEngine.evaluatePuppetRoot(turnaroundRig, frame = 30).viewAngle
        )
        assertEquals(8, com.example.data.model.CharacterViewAngle.entries.size)
        assertEquals(10, com.example.data.model.HandPropKind.entries.size)
    }

    @Test
    fun nonHumanRigs_customBones_facialExpressions_andCameraDirector() {
        val bird = RigSolver.createBirdWingedRig()
        assertEquals("BIRD", bird.rigCategory)
        assertTrue(bird.bones.any { it.id == "wing_l_tip" })
        assertTrue(bird.bones.any { it.id == "wing_r_tip" })
        assertTrue(RigSolver.presetPoseAngles("FLAP_UP").containsKey("wing_l_in"))
        assertTrue(RigSolver.presetPoseAngles("FLAP_DOWN").containsKey("wing_r_in"))

        val quad = RigSolver.createQuadrupedAnimalRig()
        assertEquals("QUADRUPED", quad.rigCategory)
        assertEquals(12, quad.bones.size)

        val customObj = RigSolver.createCustomObjectRig()
        assertEquals("CUSTOM_OBJECT", customObj.rigCategory)
        val (expandedRig, addedBone) = RigSolver.addCustomBoneAtPoint(
            rig = customObj,
            parentBoneId = "tip_1",
            tapWorldPoint = Vec2(780f, 320f)
        )
        assertEquals(customObj.bones.size + 1, expandedRig.bones.size)
        assertEquals("tip_1", addedBone.parentId)
        assertTrue(addedBone.length in 22f..260f)

        // Unrestricted mesh & face overlay alignment defaults on SkeletalRig
        assertEquals(1.0f, bird.singleMeshScale, 0.001f)
        assertEquals(1.0f, bird.faceOverlayScale, 0.001f)

        // New live animated expression enums
        assertTrue(EyePackStyle.entries.contains(EyePackStyle.LAUGHING))
        assertTrue(EyePackStyle.entries.contains(EyePackStyle.SCARED_HORROR))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.TALKING_LOOP))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.LAUGHING))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.CRYING))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.SCARED))

        // Camera Director Dolly Zoom & Pan Across presets
        val proj = ProceduralSmartTools.createProjectFromTemplate("CamTest", 1280, 720, 24, StoryboardTemplate.HERO_DEMO)
        val scene = proj.scenes.first()
        val dolly = ProceduralSmartTools.applyCameraDollyZoom(scene, startFrame = 0, targetZoom = 2.0f)
        assertTrue(dolly.cameraKeyframes.size >= 2)
        assertTrue(InterpolationEngine.evaluateCamera(dolly, frame = 36).zoom > 1.8f)

        val panned = ProceduralSmartTools.applyCameraPanAcross(scene, startFrame = 0, logicalWidth = 1280)
        val startCam = InterpolationEngine.evaluateCamera(panned, frame = 0)
        val endCam = InterpolationEngine.evaluateCamera(panned, frame = 48)
        assertTrue(startCam.panX < 0f && endCam.panX > 0f)
    }

    @Test
    fun smoothMotionPathFollowing_forObjectsAndRiggedPuppets() {
        val curvedPath = listOf(
            Vec2(120f, 500f),
            Vec2(420f, 260f),
            Vec2(820f, 520f),
            Vec2(1140f, 300f)
        )
        val s0 = InterpolationEngine.sampleSmoothPath(curvedPath, 0f)
        val sMid = InterpolationEngine.sampleSmoothPath(curvedPath, 0.5f)
        val s1 = InterpolationEngine.sampleSmoothPath(curvedPath, 1f)
        assertEquals(120f, s0.position.x, 1.5f)
        assertEquals(500f, s0.position.y, 1.5f)
        assertEquals(1140f, s1.position.x, 1.5f)
        assertEquals(300f, s1.position.y, 1.5f)
        assertTrue(sMid.position.x in 420f..820f)
        assertTrue(sMid.totalLength > 1000f)

        // Rigged puppet smoothly follows the exact path coordinates & auto-walks along traveled distance
        val rig = RigSolver.createHumanoidRig(rootX = 640f, rootY = 400f).copy(autoWalkWhenDragged = true)
        val rigLayer = AnimationLayer(
            name = "Hero",
            type = LayerType.RIG.name,
            rig = rig,
            motionPath = curvedPath,
            motionPathOrientToPath = true,
            motionPathEasing = EasingType.LINEAR.name
        )
        val rootStart = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, frame = 0, totalFrames = 49)
        val rootMid = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, frame = 24, totalFrames = 49)
        val rootEnd = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, frame = 48, totalFrames = 49)
        assertEquals(120f, rootStart.rootX, 2f)
        assertEquals(500f, rootStart.rootY, 2f)
        assertEquals(1140f, rootEnd.rootX, 2f)
        assertEquals(300f, rootEnd.rootY, 2f)
        assertTrue(rootMid.rootX > rootStart.rootX && rootMid.rootX < rootEnd.rootX)
        // Moving left-to-right should face right (flippedHorizontal = false)
        assertEquals(false, rootMid.flippedHorizontal)

        // Non-rig drawing/object aligns directly ON the drawn path instead of drifting off-screen
        val shapeLayer = AnimationLayer(
            name = "Ball",
            type = LayerType.DRAWING.name,
            frames = mapOf(
                "0" to FrameContent(
                    shapes = listOf(VectorShape(startX = 600f, startY = 300f, endX = 680f, endY = 380f))
                )
            ),
            motionPath = curvedPath,
            motionPathOrientToPath = true,
            motionPathEasing = EasingType.LINEAR.name
        )
        val tfStart = InterpolationEngine.evaluateLayerTransform(shapeLayer, frame = 0, totalFrames = 49)
        val tfEnd = InterpolationEngine.evaluateLayerTransform(shapeLayer, frame = 48, totalFrames = 49)
        // Visual center was (640, 340); at frame 0 it moves directly to (120, 500) -> delta (-520, +160)
        assertEquals(120f - 640f, tfStart.x, 2f)
        assertEquals(500f - 340f, tfStart.y, 2f)
        assertEquals(1140f - 640f, tfEnd.x, 2f)
        assertEquals(300f - 340f, tfEnd.y, 2f)
    }

    @Test
    fun extraVariableRigAndCustomAssetGrafting_worksOnAllAreas() {
        val hero = RigSolver.createHumanoidRig()
        // Attach a Sword extra variable rig onto Right Hand
        val (withHandProp, handBone) = RigSolver.createExtraVariableBone(
            rig = hero,
            area = com.example.engine.RigAttachmentArea.RIGHT_HAND,
            propKind = com.example.data.model.HandPropKind.SWORD
        )
        assertEquals("hand_r", handBone.parentId)
        assertTrue(handBone.isExtraRigBone)
        assertEquals(com.example.data.model.HandPropKind.SWORD.name, handBone.attachedPropKind)

        // Attach an extra variable rig bone onto Left Leg / Foot
        val (withLegRig, legBone) = RigSolver.createExtraVariableBone(
            rig = withHandProp,
            area = com.example.engine.RigAttachmentArea.LEFT_LEG
        )
        assertEquals("foot_l", legBone.parentId)
        assertTrue(legBone.isExtraRigBone)

        // Create a multi-bone Reusable Custom Asset and graft it onto Chest/Back (e.g. wings/cape)
        val customAsset = RigSolver.createCustomAssetStarterRig(name = "Jetpack Wings")
        assertEquals("ASSET", customAsset.rigCategory)
        assertEquals(2, customAsset.bones.size)

        val (graftedHero, rootAttached) = RigSolver.graftCustomAssetOntoRig(
            targetRig = withLegRig,
            assetRig = customAsset,
            area = com.example.engine.RigAttachmentArea.CHEST_BACK
        )
        assertEquals(withLegRig.bones.size + customAsset.bones.size, graftedHero.bones.size)
        assertEquals("spine", rootAttached?.parentId)
        val solved = RigSolver.solveForwardKinematics(graftedHero)
        assertEquals(graftedHero.bones.size, solved.size)
    }

    @Test
    fun exactDrawingCoordinateMapping_hasZeroOffsetUnderTransformsAndParallax() {
        val projW = 1280f
        val projH = 720f
        val originX = 48.5f
        val originY = 92.25f
        val totalScale = 0.78f
        val cam = com.example.engine.EvaluatedCamera(
            panX = 115f,
            panY = -64f,
            zoom = 1.45f,
            rotationDeg = 18f
        )
        val layerTf = com.example.engine.EvaluatedTransform(
            x = -85f,
            y = 42f,
            rotationDeg = -27f,
            scaleX = 1.35f,
            scaleY = 0.85f,
            opacity = 1f
        )
        val bgShiftX = -140f

        listOf(0.65f, 1.0f, 1.35f).forEach { parallax ->
            // Simulate user touching at exact pixel (30f, 30f), (450f, 290f), (910f, 520f)
            listOf(Vec2(30f, 30f), Vec2(450f, 290f), Vec2(910f, 520f)).forEach { touchPx ->
                val localPt = InterpolationEngine.canvasPxToLayerLocal(
                    canvasPxX = touchPx.x,
                    canvasPxY = touchPx.y,
                    projectWidth = projW,
                    projectHeight = projH,
                    originX = originX,
                    originY = originY,
                    totalScale = totalScale,
                    camera = cam,
                    parallax = parallax,
                    layerTransform = layerTf,
                    bgAutoShiftX = bgShiftX
                )
                val renderedPx = InterpolationEngine.layerLocalToCanvasPx(
                    localPt = localPt,
                    projectWidth = projW,
                    projectHeight = projH,
                    originX = originX,
                    originY = originY,
                    totalScale = totalScale,
                    camera = cam,
                    parallax = parallax,
                    layerTransform = layerTf,
                    bgAutoShiftX = bgShiftX
                )
                assertEquals("X must match touch pixel exactly (parallax=$parallax)", touchPx.x, renderedPx.x, 0.05f)
                assertEquals("Y must match touch pixel exactly (parallax=$parallax)", touchPx.y, renderedPx.y, 0.05f)
            }
        }
    }

    @Test
    fun expandedWeatherAndSunlightVfxTypes_areAvailable() {
        val vfx = com.example.data.model.SceneVfxType.entries
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.STORM))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.HEAVY_RAIN))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.HIGH_SUNLIGHT))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.GOLDEN_HOUR))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.RAINBOW))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.AURORA))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.AUTUMN_LEAVES))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.STARLIGHT))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.FIRE_EMBERS))
        assertTrue(vfx.size >= 20)
    }

    @Test
    fun stretchRig_ikNanGuards_andIndependentBoneLengthKeyframes() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 400f)
        val angles = rig.bones.associate { it.id to it.localAngleDeg }
        val lengths = rig.bones.associate { it.id to it.length }

        // Guard against NaN / Infinity / zero-distance targets
        val nanSolved = RigSolver.solveDragTarget(rig, "hand_r", Vec2(Float.NaN, Float.POSITIVE_INFINITY), angles, useIk = true)
        assertTrue(nanSolved.values.all { it.isFinite() })

        val zeroDistSolved = RigSolver.solveDragTarget(rig, "arm_r_low", Vec2(500f, 400f), angles, useIk = true)
        assertTrue(zeroDistSolved.values.all { it.isFinite() })

        // Stretch Rig stretches bone length cleanly toward far drag target (rubber-hose / horror arm)
        val farTarget = Vec2(820f, 340f)
        val (stAngles, stLengths) = RigSolver.solveStretchDragTarget(
            rig = rig,
            boneId = "arm_r_low",
            target = farTarget,
            currentAngles = angles,
            currentLengths = lengths
        )
        assertTrue(stAngles.values.all { it.isFinite() })
        assertTrue(stLengths.values.all { it.isFinite() })
        val origLen = rig.bones.first { it.id == "arm_r_low" }.length
        assertTrue((stLengths["arm_r_low"] ?: 0f) > origLen)

        // Bone length keyframes interpolate smoothly across frames
        val animatedRig = rig.copy(
            boneLengthKeyframes = mapOf(
                "0" to mapOf("arm_r_low" to 60f),
                "10" to mapOf("arm_r_low" to 160f)
            )
        )
        val midLengths = InterpolationEngine.evaluateBoneLengths(animatedRig, frame = 5)
        assertEquals(110f, midLengths["arm_r_low"] ?: 0f, 0.5f)
    }

    @Test
    fun indianBengaliPresets_handGestures_eyebrows_andEightViewAngles() {
        val names = ProceduralSmartTools.characterPresets.map { it.name }
        assertTrue(names.any { it.contains("Zamindar", ignoreCase = true) })
        assertTrue(names.any { it.contains("Village Didi", ignoreCase = true) })
        assertTrue(names.any { it.contains("Grandma Dida", ignoreCase = true) })
        assertTrue(names.any { it.contains("Tantrik", ignoreCase = true) || it.contains("Sage", ignoreCase = true) })
        assertTrue(names.any { it.contains("Petni", ignoreCase = true) || it.contains("Ghost", ignoreCase = true) })

        assertTrue(com.example.data.model.HandGesturePose.entries.size >= 11)
        assertTrue(com.example.data.model.HandGesturePose.entries.contains(com.example.data.model.HandGesturePose.PALM_FRONT))
        assertTrue(com.example.data.model.HandGesturePose.entries.contains(com.example.data.model.HandGesturePose.PALM_BACK))
        assertTrue(com.example.data.model.HandGesturePose.entries.contains(com.example.data.model.HandGesturePose.PALM_UP_OPEN))
        assertTrue(com.example.data.model.HandGesturePose.entries.contains(com.example.data.model.HandGesturePose.CUPPED_DRINKING_WATER))
        assertEquals(4, com.example.data.model.EyebrowStyle.entries.size)
        assertTrue(com.example.data.model.CharacterViewAngle.entries.contains(com.example.data.model.CharacterViewAngle.BACK_LEFT_34))
        assertTrue(com.example.data.model.CharacterViewAngle.entries.contains(com.example.data.model.CharacterViewAngle.BACK_RIGHT_34))
        assertTrue(com.example.data.model.CharacterViewAngle.entries.contains(com.example.data.model.CharacterViewAngle.FRONT_LEFT_34))
        assertTrue(com.example.data.model.CharacterViewAngle.entries.contains(com.example.data.model.CharacterViewAngle.FRONT_RIGHT_34))

        // Hand gesture & eyebrow propagate via PuppetRootKeyframe
        val rig = RigSolver.createHumanoidRig().copy(
            rootKeyframes = listOf(
                PuppetRootKeyframe(
                    frame = 0,
                    rootX = 400f,
                    rootY = 400f,
                    leftHandGesture = com.example.data.model.HandGesturePose.NAMASTE.name,
                    rightHandGesture = com.example.data.model.HandGesturePose.POINTING.name,
                    eyebrowStyle = com.example.data.model.EyebrowStyle.ANGRY.name,
                    scaleX = 1.4f,
                    scaleY = 0.7f
                )
            )
        )
        val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame = 3)
        assertEquals(com.example.data.model.HandGesturePose.NAMASTE.name, eval.leftHandGesture)
        assertEquals(com.example.data.model.HandGesturePose.POINTING.name, eval.rightHandGesture)
        assertEquals(com.example.data.model.EyebrowStyle.ANGRY.name, eval.eyebrowStyle)
        assertEquals(1.4f, eval.scaleX, 0.01f)
        assertEquals(0.7f, eval.scaleY, 0.01f)
    }

    @Test
    fun frameVisibilityRanges_celStudioNonHolding_targetedLoops_andAutoActions() {
        // Visibility ranges cleanly hide/show layers on specified intervals
        val rangedLayer = AnimationLayer(
            visibilityRanges = listOf(com.example.data.model.FrameVisibilityRange(startFrame = 10, endFrame = 25))
        )
        assertFalse(InterpolationEngine.isLayerVisibleAtFrame(rangedLayer, 9))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(rangedLayer, 10))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(rangedLayer, 25))
        assertFalse(InterpolationEngine.isLayerVisibleAtFrame(rangedLayer, 26))

        // Cel Studio layer does NOT hold prior frame's solid drawing when advancing to blank Frame 2
        val celLayer = AnimationLayer(
            isCelFrameByFrame = true,
            frames = mapOf("0" to FrameContent(shapes = listOf(VectorShape(startX = 10f, startY = 10f, endX = 80f, endY = 80f))))
        )
        assertTrue(InterpolationEngine.resolveFrameContent(celLayer, frame = 0, holdPrevious = true)?.shapes?.isNotEmpty() == true)
        assertEquals(null, InterpolationEngine.resolveFrameContent(celLayer, frame = 1, holdPrevious = true))

        // Targeted Loops override poses inside frame range without corrupting outside frames
        val loopedRig = RigSolver.createHumanoidRig()
        val loopedLayer = AnimationLayer(
            type = LayerType.RIG.name,
            rig = loopedRig,
            targetedLoops = listOf(
                com.example.data.model.TargetedLoopClip(
                    loopType = com.example.data.model.TargetedLoopType.AUTO_WALK.name,
                    startFrame = 10,
                    endFrame = 30
                )
            )
        )
        val walkF12 = InterpolationEngine.evaluateRigAnglesWithPath(loopedLayer, loopedRig, frame = 12, totalFrames = 96)
        val walkF18 = InterpolationEngine.evaluateRigAnglesWithPath(loopedLayer, loopedRig, frame = 18, totalFrames = 96)
        assertNotEquals(walkF12["leg_l_up"], walkF18["leg_l_up"])

        // All 4 One-Tap Auto-Actions populate multi-frame squash/stretch & pose keyframes
        val baseRigLayer = AnimationLayer(type = LayerType.RIG.name, rig = RigSolver.createHumanoidRig())
        val testScene = com.example.data.model.AnimationScene(durationFrames = 96, layers = listOf(baseRigLayer))
        com.example.engine.AutoActionKind.entries.forEach { kind ->
            val updatedScene = ProceduralSmartTools.applyAutoActionToLayer(testScene, baseRigLayer.id, startFrame = 4, action = kind)
            val generated = updatedScene.layers.first { it.id == baseRigLayer.id }
            assertTrue("${kind.name} must generate pose keyframes", (generated.rig?.poseKeyframes?.size ?: 0) >= 3)
            assertTrue("${kind.name} must generate root keyframes", (generated.rig?.rootKeyframes?.size ?: 0) >= 3)
        }
    }

    @Test
    fun audioResampling_converts22050HzTo44100HzCleanly() {
        val src = ShortArray(1000) { i -> (kotlin.math.sin(i * 0.1) * 12000.0).toInt().toShort() }
        val resampled = com.example.engine.AudioStudioEngine.resampleMonoPcm16(src, 22050, 44100)
        assertEquals(2000, resampled.size)
        val same = com.example.engine.AudioStudioEngine.resampleMonoPcm16(src, 44100, 44100)
        assertEquals(1000, same.size)
    }

    @Test
    fun squishStretch_partBehaviors_andCharacterBehaviorPresets_workAndPersist() {
        // 1. Image Squish & Stretch baseScaleX/baseScaleY reshape single-mesh rect cleanly
        val normalRig = RigSolver.createHumanoidRig().copy(singleMeshWidth = 200f, singleMeshHeight = 300f)
        val wideRig = normalRig.copy(baseScaleX = 1.5f, baseScaleY = 0.6f)
        val rootEval = InterpolationEngine.evaluatePuppetRoot(wideRig, 0)
        val normalBounds = com.example.engine.SceneRenderer.computeSingleMeshBounds(normalRig, rootEval)
        val wideBounds = com.example.engine.SceneRenderer.computeSingleMeshBounds(wideRig, rootEval)
        val normalW = normalBounds[2] - normalBounds[0]
        val normalH = normalBounds[3] - normalBounds[1]
        val wideW = wideBounds[2] - wideBounds[0]
        val wideH = wideBounds[3] - wideBounds[1]
        assertEquals(normalW * 1.5f, wideW, 0.5f)
        assertEquals(normalH * 0.6f, wideH, 0.5f)

        // 2. All 4 Per-Bone Part Behavior Presets configure exact physics/smoothness/stretch flags
        val sampleBone = normalRig.bones.first()
        val rigid = RigSolver.applyPartBehaviorPreset(sampleBone, com.example.data.model.PartBehaviorPreset.RIGID)
        assertEquals(0f, rigid.meshBendSmoothness, 0.001f)
        assertEquals(0f, rigid.springStiffness, 0.001f)
        assertFalse(rigid.allowElasticStretch)

        val cloth = RigSolver.applyPartBehaviorPreset(sampleBone, com.example.data.model.PartBehaviorPreset.SOFT_CLOTH)
        assertEquals(0.65f, cloth.meshBendSmoothness, 0.01f)

        val spring = RigSolver.applyPartBehaviorPreset(sampleBone, com.example.data.model.PartBehaviorPreset.BOUNCY_SPRING)
        assertTrue(spring.springStiffness >= 0.7f)

        val elastic = RigSolver.applyPartBehaviorPreset(sampleBone, com.example.data.model.PartBehaviorPreset.ELASTIC_RUBBER)
        assertTrue(elastic.allowElasticStretch)

        // 3. All 5 Whole-Character Behavior Presets propagate through keyframes & drive distinct acting/limb tension
        assertEquals(5, com.example.data.model.CharacterBehaviorPreset.entries.size)
        val horrorRig = normalRig.copy(
            behaviorPreset = com.example.data.model.CharacterBehaviorPreset.HORROR_GHOSTLY.name,
            rootKeyframes = listOf(
                PuppetRootKeyframe(frame = 0, behaviorPreset = com.example.data.model.CharacterBehaviorPreset.NORMAL_CALM.name),
                PuppetRootKeyframe(frame = 12, behaviorPreset = com.example.data.model.CharacterBehaviorPreset.HORROR_GHOSTLY.name)
            )
        )
        assertEquals(com.example.data.model.CharacterBehaviorPreset.NORMAL_CALM.name, InterpolationEngine.evaluatePuppetRoot(horrorRig, 0).behaviorPreset)
        assertEquals(com.example.data.model.CharacterBehaviorPreset.HORROR_GHOSTLY.name, InterpolationEngine.evaluatePuppetRoot(horrorRig, 15).behaviorPreset)
        val calmArmLen = InterpolationEngine.evaluateBoneLengths(horrorRig, 0)["arm_r_low"] ?: 0f
        val horrorArmLen = InterpolationEngine.evaluateBoneLengths(horrorRig, 15)["arm_r_low"] ?: 0f
        assertTrue("Horror mood must apply elongated limb tension", horrorArmLen > calmArmLen)

        // Distinct walk poses for Angry vs Elderly
        val angryWalk = RigSolver.computeAutoWalkPose(40f, com.example.data.model.CharacterBehaviorPreset.ANGRY_STRICT.name)
        val elderlyWalk = RigSolver.computeAutoWalkPose(40f, com.example.data.model.CharacterBehaviorPreset.ELDERLY_WEAK.name)
        assertNotEquals(angryWalk["spine"], elderlyWalk["spine"])
    }

    @Test
    fun partLayerZOrder_autoHumanOrder_keyframedSwitching_andJsonPersistence_workCleanly() {
        // 1. Exact View-Aware Anatomical Auto Human Layer Order:
        // Right Side View: Far Limbs (_l) < Body (spine) < Head (neck) < Near Limbs (_r) < Held Prop
        val base = RigSolver.createHumanoidRig()
        val withExtras = base.copy(
            viewAngle = CharacterViewAngle.SIDE_RIGHT.name,
            bones = base.bones + listOf(
                com.example.data.model.RigBone(id = "front_hair", name = "Front Hair / Hat", parentId = "neck", zOrder = 0),
                com.example.data.model.RigBone(id = "held_sword", name = "Held Sword Prop", parentId = "hand_r", attachedPropKind = "SWORD", isExtraRigBone = true, zOrder = 0)
            )
        )
        val ordered = RigSolver.applyAutoHumanLayerOrder(withExtras, CharacterViewAngle.SIDE_RIGHT)
        val z = ordered.bones.associate { it.id to it.zOrder }
        assertTrue(z["hand_l"]!! < z["spine"]!!)
        assertTrue(z["leg_l_up"]!! < z["spine"]!!)
        assertTrue(z["spine"]!! < z["neck"]!!)
        assertTrue(z["neck"]!! < z["front_hair"]!!)
        assertTrue(z["front_hair"]!! < z["leg_r_up"]!!)
        assertTrue(z["leg_r_up"]!! < z["hand_r"]!!)
        assertTrue(z["hand_r"]!! < z["held_sword"]!!)

        // 2. All 4 Z-Order actions: Send to Back, Bring to Front, Bring Forward (+1), Send Backward (-1)
        val sentBack = RigSolver.adjustBoneZOrder(ordered.bones, "hand_r", com.example.engine.BoneZOrderAction.SEND_TO_BACK)
        val minZ = sentBack.minOf { it.zOrder }
        assertEquals(minZ, sentBack.first { it.id == "hand_r" }.zOrder)

        val broughtForward = RigSolver.adjustBoneZOrder(sentBack, "hand_r", com.example.engine.BoneZOrderAction.BRING_FORWARD)
        assertTrue(broughtForward.first { it.id == "hand_r" }.zOrder > minZ)

        val broughtTop = RigSolver.adjustBoneZOrder(broughtForward, "spine", com.example.engine.BoneZOrderAction.BRING_TO_FRONT)
        val maxZ = broughtTop.maxOf { it.zOrder }
        assertEquals(maxZ, broughtTop.first { it.id == "spine" }.zOrder)

        val sentBackOne = RigSolver.adjustBoneZOrder(broughtTop, "spine", com.example.engine.BoneZOrderAction.SEND_BACKWARD)
        assertTrue(sentBackOne.first { it.id == "spine" }.zOrder < maxZ)

        // 3. Keyframeable Front/Back Switching across timeline frames (hand behind back at F0 -> front of chest at F12)
        val behindMap = ordered.bones.associate { it.id to it.zOrder } + ("hand_r" to 0)
        val frontMap = ordered.bones.associate { it.id to it.zOrder } + ("hand_r" to 99)
        val keyframedRig = ordered.copy(
            boneZOrderKeyframes = mapOf(
                "0" to behindMap,
                "12" to frontMap
            )
        )
        val evalF5 = InterpolationEngine.evaluateBoneZOrders(keyframedRig, frame = 5)
        val evalF15 = InterpolationEngine.evaluateBoneZOrders(keyframedRig, frame = 15)
        assertTrue("Hand should remain behind torso before F12", evalF5["hand_r"]!! < evalF5["spine"]!!)
        assertTrue("Hand should switch in front of torso at/after F12", evalF15["hand_r"]!! > evalF15["spine"]!!)

        // 4. Moshi JSON persistence round-trip preserves zOrder & boneZOrderKeyframes
        val moshi = com.squareup.moshi.Moshi.Builder()
            .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
            .build()
        val adapter = moshi.adapter(com.example.data.model.SkeletalRig::class.java)
        val json = adapter.toJson(keyframedRig)
        val restored = adapter.fromJson(json)
        org.junit.Assert.assertNotNull(restored)
        assertEquals(keyframedRig.bones.first { it.id == "neck" }.zOrder, restored!!.bones.first { it.id == "neck" }.zOrder)
        assertEquals(99, restored.boneZOrderKeyframes["12"]?.get("hand_r"))
    }

    @Test
    fun customEyeMouthSlots_smart8ViewFit_andFrameSecondTimingIntervals() {
        val baseRig = RigSolver.createHumanoidRig(rootX = 640f, rootY = 360f).copy(
            customEyeSlots = mapOf(
                com.example.data.model.CustomEyeSlot.OPEN_NORMAL.name to "/tmp/eye_open.png",
                com.example.data.model.CustomEyeSlot.CRYING_TEARS.name to "/tmp/eye_cry.png"
            ),
            customMouthSlots = mapOf(
                com.example.data.model.CustomMouthSlot.CLOSED_IDLE.name to "/tmp/mouth_closed.png",
                com.example.data.model.CustomMouthSlot.WIDE_OPEN_LOUD.name to "/tmp/mouth_wide.png"
            ),
            perAngleFaceFit = mapOf(
                CharacterViewAngle.FRONT_RIGHT_34.name to com.example.data.model.FaceAngleAdjustment(
                    offsetX = 18f,
                    offsetY = -4f,
                    scaleX = 0.88f,
                    scaleY = 1.02f,
                    rotationDeg = 6f,
                    eyeScale = 1.15f,
                    mouthOffsetY = 5f,
                    isManualOverride = true
                )
            ),
            facialTiming = com.example.data.model.FacialTimingConfig(
                useSecondsUnit = true,
                lipSyncIntervalSec = 0.25f, // 6f @ 24fps
                blinkIntervalSec = 2.0f,    // 48f @ 24fps
                blinkDurationSec = 0.125f,  // 3f @ 24fps
                emotionLoopSpeedSec = 0.5f  // 12f @ 24fps
            )
        )

        // 1. Smart 8-View Perspective Auto-Adjust & Back Visibility
        val frontTf = com.example.engine.SceneRenderer.resolveViewAwareFaceTransform(baseRig, CharacterViewAngle.FRONT)
        assertTrue(frontTf.visible)
        assertEquals(1.0f, frontTf.scaleX, 0.01f)

        val sideTf = com.example.engine.SceneRenderer.resolveViewAwareFaceTransform(baseRig, CharacterViewAngle.SIDE_RIGHT)
        assertTrue(sideTf.visible)
        assertTrue("Side view should foreshorten Scale X", sideTf.scaleX < 0.75f)
        assertTrue("Side view should shift horizontally", sideTf.offsetX > 0f)

        val back34Tf = com.example.engine.SceneRenderer.resolveViewAwareFaceTransform(baseRig, CharacterViewAngle.BACK_LEFT_34)
        assertTrue(back34Tf.visible)
        assertTrue(back34Tf.isBack34Peek)

        val backTf = com.example.engine.SceneRenderer.resolveViewAwareFaceTransform(baseRig, CharacterViewAngle.BACK)
        assertFalse("Full Back view must hide front facial overlay", backTf.visible)

        // 2. Per-Angle Manual Fine-Tune Lock smoothly refines on top of smart 3/4 auto-perspective
        val locked34 = com.example.engine.SceneRenderer.resolveViewAwareFaceTransform(baseRig, CharacterViewAngle.FRONT_RIGHT_34)
        assertTrue(locked34.visible)
        assertEquals(12f + 18f, locked34.offsetX, 0.01f)
        assertEquals(0.86f * 0.88f, locked34.scaleX, 0.01f)
        assertEquals(6f, locked34.rotationDeg, 0.01f)
        assertEquals(1.15f, locked34.eyeScale, 0.01f)
        assertEquals(5f, locked34.mouthOffsetY, 0.01f)

        // 3. Manual Frame & Second Timing Intervals
        assertEquals(6, com.example.engine.AudioStudioEngine.resolveLipSyncIntervalFrames(baseRig.facialTiming, 24))
        assertEquals(48, com.example.engine.AudioStudioEngine.resolveBlinkIntervalFrames(baseRig.facialTiming, 24))
        assertEquals(3, com.example.engine.AudioStudioEngine.resolveBlinkDurationFrames(baseRig.facialTiming, 24))
        assertEquals(12, com.example.engine.AudioStudioEngine.resolveEmotionCycleFrames(baseRig.facialTiming, 24))

        assertEquals(
            com.example.engine.AudioStudioEngine.BlinkPhase.HALF_BLINK,
            com.example.engine.AudioStudioEngine.evaluateBlinkPhase(frame = 0, fps = 24, timing = baseRig.facialTiming)
        )
        assertEquals(
            com.example.engine.AudioStudioEngine.BlinkPhase.CLOSED,
            com.example.engine.AudioStudioEngine.evaluateBlinkPhase(frame = 1, fps = 24, timing = baseRig.facialTiming)
        )
        assertEquals(
            com.example.engine.AudioStudioEngine.BlinkPhase.OPEN,
            com.example.engine.AudioStudioEngine.evaluateBlinkPhase(frame = 10, fps = 24, timing = baseRig.facialTiming)
        )

        // 4. Moshi JSON persistence round-trip preserves all Custom Eye/Mouth slots, Per-Angle Locks & Timing
        val moshi = com.squareup.moshi.Moshi.Builder()
            .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
            .build()
        val adapter = moshi.adapter(com.example.data.model.SkeletalRig::class.java)
        val restored = adapter.fromJson(adapter.toJson(baseRig))
        org.junit.Assert.assertNotNull(restored)
        assertEquals("/tmp/eye_cry.png", restored!!.customEyeSlots[com.example.data.model.CustomEyeSlot.CRYING_TEARS.name])
        assertEquals("/tmp/mouth_wide.png", restored.customMouthSlots[com.example.data.model.CustomMouthSlot.WIDE_OPEN_LOUD.name])
        assertTrue(restored.perAngleFaceFit[CharacterViewAngle.FRONT_RIGHT_34.name]?.isManualOverride == true)
        assertTrue(restored.facialTiming.useSecondsUnit)
        assertEquals(0.25f, restored.facialTiming.lipSyncIntervalSec, 0.001f)
    }

    @Test
    fun proRigging_meshPinning_continuous360Rotation_headLock_8AngleConfig_and5Fingers() {
        val base = RigSolver.createHumanoidRig(rootX = 640f, rootY = 380f)

        // 1. Default bone parts are 100% rigid (zero automatic bending) and Head (neck) stretch is locked
        val neckBone = base.bones.first { it.id == "neck" }
        assertFalse("Head/neck bone must disallow length stretch", neckBone.allowLengthStretch)
        val initialAngles = base.bones.associate { it.id to it.localAngleDeg }
        val initialLengths = base.bones.associate { it.id to it.length }
        val (_, stretchLengths) = RigSolver.solveStretchDragTarget(
            rig = base,
            boneId = "neck",
            target = Vec2(640f, 40f),
            currentAngles = initialAngles,
            currentLengths = initialLengths
        )
        assertEquals("Head bone length must remain locked during stretch drag", neckBone.length, stretchLengths["neck"] ?: 0f, 0.01f)

        // 2. Full 360-degree continuous unwrapped joint rotation across ±180 boundary
        val unwrapped = RigSolver.unwrapAngleNear(targetDeg = -170f, prevDeg = 175f)
        assertEquals(190f, unwrapped, 0.01f)
        val unwrappedNeg = RigSolver.unwrapAngleNear(targetDeg = 170f, prevDeg = -175f)
        assertEquals(-190f, unwrappedNeg, 0.01f)

        // 3. Per-Bone Lock prevents drag mutation
        val lockedRig = base.copy(bones = base.bones.map { if (it.id == "arm_r_up") it.copy(locked = true) else it })
        val afterLockedDrag = RigSolver.solveDragTarget(
            rig = lockedRig,
            boneId = "arm_r_up",
            target = Vec2(900f, 200f),
            currentAngles = initialAngles,
            useIk = false
        )
        assertEquals(initialAngles["arm_r_up"]!!, afterLockedDrag["arm_r_up"]!!, 0.001f)

        // 4. Point-to-Point Mesh Pinning creates localized cloth bridge vertices between Bone A and Bone B
        val pin = com.example.data.model.MeshPinLink(
            boneAId = "spine",
            localAnchorA = Vec2(0.8f, 0.2f),
            boneBId = "arm_r_up",
            localAnchorB = Vec2(0.2f, -0.2f),
            radiusPx = 28f,
            clothStiffness = 0.8f
        )
        val fk = RigSolver.solveForwardKinematics(base).associateBy { it.bone.id }
        val ptA = RigSolver.resolvePinWorldPoint(fk["spine"]!!, pin.localAnchorA)
        val ptB = RigSolver.resolvePinWorldPoint(fk["arm_r_up"]!!, pin.localAnchorB)
        assertTrue(ptA.x.isFinite() && ptB.y.isFinite())
        val verts = RigSolver.computePinnedClothBridgeVertices(pin, fk["spine"]!!, fk["arm_r_up"]!!)
        assertTrue(verts.size >= 8)
        assertTrue(verts.all { it.isFinite() })

        // 5. Per-View 8-Angle Custom Artwork & Rig Config saves and restores angle-specific overrides
        val frontEdited = base.copy(
            viewAngle = CharacterViewAngle.FRONT.name,
            singleMeshImagePath = "/tmp/front_body.png"
        )
        val switchedToSide = RigSolver.switchRigToPerAngleConfig(frontEdited, CharacterViewAngle.SIDE_LEFT)
            .copy(singleMeshImagePath = "/tmp/side_left_body.png")
        val backToFront = RigSolver.switchRigToPerAngleConfig(switchedToSide, CharacterViewAngle.FRONT)
        assertEquals("/tmp/front_body.png", backToFront.singleMeshImagePath)
        val backToSide = RigSolver.switchRigToPerAngleConfig(backToFront, CharacterViewAngle.SIDE_LEFT)
        assertEquals("/tmp/side_left_body.png", backToSide.singleMeshImagePath)

        // 6. Articulated 5-Finger Hand creation is idempotent and attaches to hand_r
        val withFingers = RigSolver.addArticulatedFiveFingers(base, isRightHand = true)
        assertEquals(base.bones.size + 5, withFingers.bones.size)
        assertTrue(withFingers.bones.any { it.id == "finger_r_thumb" && it.parentId == "hand_r" })
        val idempotent = RigSolver.addArticulatedFiveFingers(withFingers, isRightHand = true)
        assertEquals(withFingers.bones.size, idempotent.bones.size)
    }

    @Test
    fun separateMoodAutoDubbing_detachableLimbs_propSockets_formMorph_batchColor_andPcProPlayer() {
        // 1. Separate Eye/Mouth Mood Auto-Dubbing: speaking -> frames 3..6; silent pause -> frames 1..2 (preserving emotion)
        val voiceTrack = AudioTrackItem(
            kind = AudioTrackKind.VOICE.name,
            startFrame = 0,
            trimStartMs = 0L,
            trimEndMs = 1000L,
            waveformPeaks = listOf(0.01f, 0.02f, 0.45f, 0.88f, 0.01f)
        )
        val silentFrameIdx = com.example.engine.AudioStudioEngine.evaluateMouthMoodFrame(
            audioTracks = listOf(voiceTrack),
            frame = 0,
            fps = 24,
            timing = com.example.data.model.FacialTimingConfig()
        )
        val loudFrameIdx = com.example.engine.AudioStudioEngine.evaluateMouthMoodFrame(
            audioTracks = listOf(voiceTrack),
            frame = 16,
            fps = 24,
            timing = com.example.data.model.FacialTimingConfig()
        )
        assertTrue("Silent pause must select frames 1..2", silentFrameIdx in 1..2)
        assertTrue("Active speech must select frames 3..6", loudFrameIdx in 3..6)

        val (nodDeg, chinBounceY) = com.example.engine.AudioStudioEngine.evaluateDialogueHeadBounce(
            audioTracks = listOf(voiceTrack),
            frame = 16,
            fps = 24,
            enabled = true
        )
        assertTrue("Dialogue head bounce must produce nonzero nod/chin bounce during speech", nodDeg != 0f || chinBounceY > 0f)

        // 2. Detachable / Severed Bone with Gravity Fall
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 300f).copy(
            detachedBoneKeyframes = listOf(
                com.example.data.model.DetachedBoneKeyframe(
                    frame = 10,
                    boneId = "neck",
                    detached = true,
                    worldX = 500f,
                    worldY = 180f,
                    rotationDeg = -90f,
                    gravityFall = true
                )
            ),
            handPropSocketKeyframes = listOf(
                com.example.data.model.HandPropSocketKeyframe(
                    frame = 0,
                    isRightHand = true,
                    propKind = com.example.data.model.HandPropKind.SWORD.name
                ),
                com.example.data.model.HandPropSocketKeyframe(
                    frame = 12,
                    isRightHand = true,
                    propKind = com.example.data.model.HandPropKind.NONE.name
                )
            )
        )
        assertTrue(InterpolationEngine.evaluateDetachedBones(rig, frame = 5).isEmpty())
        val fallenF10 = InterpolationEngine.evaluateDetachedBones(rig, frame = 10)["neck"]!!
        val fallenF20 = InterpolationEngine.evaluateDetachedBones(rig, frame = 20)["neck"]!!
        assertTrue("Gravity fall must drop severed bone downward over time", fallenF20.worldY > fallenF10.worldY)

        // 3. Variable Hand Prop Socket switching
        assertEquals(com.example.data.model.HandPropKind.SWORD.name, InterpolationEngine.evaluateHandPropSocket(rig, true, 4).first)
        assertEquals(com.example.data.model.HandPropKind.NONE.name, InterpolationEngine.evaluateHandPropSocket(rig, true, 15).first)

        // 4. Prop Grab Target, Same-Track Form Morph, Instant Hide
        val propLayer = AnimationLayer(
            propGrabKeyframes = listOf(
                com.example.data.model.PropGrabKeyframe(frame = 5, targetLayerId = "hero_layer", targetBoneId = "hand_r"),
                com.example.data.model.PropGrabKeyframe(frame = 15, targetLayerId = null, targetBoneId = null)
            ),
            formMorphKeyframes = listOf(
                com.example.data.model.CharacterFormKeyframe(frame = 8, formName = "Demon Form", transitionFx = "FLASH", transitionDurationFrames = 6)
            ),
            visibilityKeyframes = listOf(
                com.example.data.model.InstantVisibilityKeyframe(frame = 20, visible = false),
                com.example.data.model.InstantVisibilityKeyframe(frame = 26, visible = true)
            )
        )
        assertEquals("hand_r", InterpolationEngine.evaluatePropGrabTarget(propLayer, 8)?.targetBoneId)
        assertEquals(null, InterpolationEngine.evaluatePropGrabTarget(propLayer, 18)?.targetBoneId)

        val morphF10 = InterpolationEngine.evaluateFormMorph(propLayer, 10)
        assertEquals("Demon Form", morphF10?.form?.formName)
        assertTrue("Transition FX progress should be active during burst window", (morphF10?.transitionProgress ?: 0f) in 0.01f..1f)

        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(propLayer, 19))
        assertFalse(InterpolationEngine.isLayerVisibleAtFrame(propLayer, 20))
        assertFalse(InterpolationEngine.isLayerVisibleAtFrame(propLayer, 25))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(propLayer, 26))

        // 5. Universal Multi-Frame Batch Color / Hue Shift
        val origContent = FrameContent(
            shapes = listOf(VectorShape(strokeColorArgb = 0xFFFF0000L, fillColorArgb = 0xFF00FF00L))
        )
        val shifted = InterpolationEngine.applyBatchColorShiftToFrameContent(origContent, hueDeltaDeg = 120f)
        assertNotEquals(origContent.shapes.first().strokeColorArgb, shifted.shapes.first().strokeColorArgb)

        // 6. Hardware-Gated PC Pro Export Offline HTML5 WebGL2 Player Generator
        val html = com.example.engine.PcProCinemaRenderer.generateOfflineHtml5WebGl2Player(
            projectName = "Village Ghost Story",
            width = 1920,
            height = 1080,
            fps = 60,
            frameCount = 120,
            sceneNames = listOf("Scene 1"),
            settings = com.example.data.model.ExportSettings(isPcProMode = true, pcProRayCastShadows = true)
        )
        assertTrue(html.contains("webgl2"))
        assertTrue(html.contains("Village Ghost Story"))
        assertTrue(html.contains("1920"))
    }

    @Test
    fun masterUpgrade_rigPosition_shoulders_anatomicalZOrder_faceLayers_vnTimeline_andOneShotAudio() {
        // 1. Module 1: Complete Human Skeleton (Pelvis -> Waist -> Chest -> Neck -> Head; Shoulders & Hips) + Rig Position + Lock + zero angle limits
        val rig = RigSolver.createHumanoidRig(rootX = 640f, rootY = 400f)
        assertEquals(null, rig.bones.first { it.id == "pelvis" }.parentId)
        assertEquals("pelvis", rig.bones.first { it.id == "waist" }.parentId)
        assertEquals("waist", rig.bones.first { it.id == "spine" }.parentId)
        assertEquals("spine", rig.bones.first { it.id == "neck_base" }.parentId)
        assertEquals("neck_base", rig.bones.first { it.id == "neck" }.parentId)
        assertTrue(rig.bones.any { it.id == "shoulder_l" && it.parentId == "spine" })
        assertTrue(rig.bones.any { it.id == "shoulder_r" && it.parentId == "spine" })
        assertEquals("shoulder_l", rig.bones.first { it.id == "arm_l_up" }.parentId)
        assertEquals("shoulder_r", rig.bones.first { it.id == "arm_r_up" }.parentId)
        assertTrue(rig.bones.any { it.id == "hip_l" && it.parentId == "pelvis" })
        assertTrue(rig.bones.any { it.id == "hip_r" && it.parentId == "pelvis" })
        assertEquals("hip_l", rig.bones.first { it.id == "leg_l_up" }.parentId)
        assertEquals("hip_r", rig.bones.first { it.id == "leg_r_up" }.parentId)
        assertTrue(rig.bones.all { it.minAngleDeg <= -720f && it.maxAngleDeg >= 720f })

        val nudged = RigSolver.nudgeBoneJointPivot(rig, "shoulder_r", dxPx = 6f, dyPx = -4f)
        val shR = nudged.bones.first { it.id == "shoulder_r" }
        assertEquals(6f, shR.basePivotOffsetX, 0.01f)
        assertEquals(-4f, shR.basePivotOffsetY, 0.01f)

        // Lock Base Rig Position prevents any pivot drift!
        val locked = nudged.copy(baseRigPositionLocked = true)
        val triedMove = RigSolver.nudgeBoneJointPivot(locked, "shoulder_r", dxPx = 50f, dyPx = 50f)
        assertEquals(6f, triedMove.bones.first { it.id == "shoulder_r" }.basePivotOffsetX, 0.01f)

        // 2. Module 2: Exact Anatomical Z-Order per View Side (Front, Left Side, Right Side, Back)
        val frontZ = RigSolver.applyAutoHumanLayerOrder(rig, CharacterViewAngle.FRONT).bones.associate { it.id to it.zOrder }
        assertTrue("Front: Head > Body", frontZ["neck"]!! > frontZ["spine"]!!)
        assertTrue("Front: Body > Hands & Legs", frontZ["spine"]!! > frontZ["hand_r"]!! && frontZ["spine"]!! > frontZ["leg_r_up"]!!)

        val leftSideZ = RigSolver.applyAutoHumanLayerOrder(rig, CharacterViewAngle.SIDE_LEFT).bones.associate { it.id to it.zOrder }
        assertTrue("Left Side: Near Hand/Leg (_l) > Head", leftSideZ["hand_l"]!! > leftSideZ["neck"]!! && leftSideZ["leg_l_up"]!! > leftSideZ["neck"]!!)
        assertTrue("Left Side: Head > Body > Far Limbs (_r)", leftSideZ["neck"]!! > leftSideZ["spine"]!! && leftSideZ["spine"]!! > leftSideZ["hand_r"]!!)

        val backZ = RigSolver.applyAutoHumanLayerOrder(rig, CharacterViewAngle.BACK).bones.associate { it.id to it.zOrder }
        assertTrue("Back: Limbs > Body > Head", backZ["hand_r"]!! > backZ["spine"]!! && backZ["spine"]!! > backZ["neck"]!!)

        // 3. Dedicated Face Making Layers (Eyes, Brows, Nose, Mouth — no separate ear layers) + JSON round-trip persistence
        val withFaceLayers = rig.copy(
            faceLayers = com.example.data.model.FaceLayersConfig(
                nose = com.example.data.model.FaceFeatureTransform(offsetX = -3f, offsetY = 2f, scale = 1.1f),
                leftBrowImagePath = "/tmp/brow_l.png",
                mouthBuilderFrames = listOf("/tmp/mouth_f1.png", "/tmp/mouth_f2.png"),
                eyeBuilderFrames = listOf("/tmp/eye_f1.png", "/tmp/eye_f2.png")
            )
        )
        val moshi = com.squareup.moshi.Moshi.Builder()
            .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
            .build()
        val rigAdapter = moshi.adapter(com.example.data.model.SkeletalRig::class.java)
        val restoredRig = rigAdapter.fromJson(rigAdapter.toJson(withFaceLayers))!!
        assertEquals("/tmp/brow_l.png", restoredRig.faceLayers.leftBrowImagePath)
        assertEquals(2, restoredRig.faceLayers.mouthBuilderFrames.size)
        assertEquals(2, restoredRig.faceLayers.eyeBuilderFrames.size)
        assertEquals(-3f, restoredRig.faceLayers.nose.offsetX, 0.01f)

        // 4. Pure Frame-by-Frame Visibility (layers never unexpectedly disappear from clip bounds)
        val frameLayer = AnimationLayer(
            name = "Hero Layer",
            clipStartFrame = 12,
            clipEndFrame = 36,
            clipInAnimation = com.example.data.model.ClipAnimationPreset.FADE.name,
            clipOutAnimation = com.example.data.model.ClipAnimationPreset.POP.name,
            clipAnimationFrames = 8
        )
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(frameLayer, 0))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(frameLayer, 12))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(frameLayer, 36))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(frameLayer, 50))
        val fadeStart = InterpolationEngine.evaluateLayerTransform(frameLayer, 12, 96)
        val fadeMid = InterpolationEngine.evaluateLayerTransform(frameLayer, 24, 96)
        assertTrue("FADE In animation starts transparent and reaches full opacity", fadeStart.opacity < fadeMid.opacity)

        // Continuous Background remains visible on every frame (0..totalFrames)
        val bgLayer = AnimationLayer(type = LayerType.BACKGROUND.name, clipStartFrame = 0, clipEndFrame = -1)
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(bgLayer, 0))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(bgLayer, 1))
        assertTrue(InterpolationEngine.isLayerVisibleAtFrame(bgLayer, 95))

        // 5. Module 5: Strict One-Shot Audio Track defaults & WAV PCM round-trip (no unwanted looping!)
        val audioDefault = AudioTrackItem(name = "Dialogue 1", startFrame = 10, endFrame = 40)
        assertFalse("Imported/created audio clips MUST default to loopClip = false (strict One-Shot)", audioDefault.loopClip)
        val tmpWav = java.io.File.createTempFile("animaster_oneshot_test", ".wav")
        try {
            val sr = 44100
            val oneShotSamples = ShortArray(sr / 4) { 12000 } // 0.25s tone
            val dataBytes = oneShotSamples.size * 2
            val wavBuf = java.nio.ByteBuffer.allocate(44 + dataBytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            wavBuf.put("RIFF".toByteArray())
            wavBuf.putInt(36 + dataBytes)
            wavBuf.put("WAVE".toByteArray())
            wavBuf.put("fmt ".toByteArray())
            wavBuf.putInt(16)
            wavBuf.putShort(1)
            wavBuf.putShort(1)
            wavBuf.putInt(sr)
            wavBuf.putInt(sr * 2)
            wavBuf.putShort(2)
            wavBuf.putShort(16)
            wavBuf.put("data".toByteArray())
            wavBuf.putInt(dataBytes)
            oneShotSamples.forEach { wavBuf.putShort(it) }
            tmpWav.writeBytes(wavBuf.array())

            val parsed = com.example.engine.AudioStudioEngine.parseWavPcm16(tmpWav.readBytes())!!
            assertEquals(sr, parsed.sampleRate)
            assertEquals(oneShotSamples.size, parsed.samples.size)

            val trackOneShot = AudioTrackItem(
                filePath = tmpWav.absolutePath,
                startFrame = 0,
                endFrame = 48,
                durationMs = 250L,
                trimStartMs = 0L,
                trimEndMs = 250L,
                loopClip = false
            )
            val mixedOneShot = com.example.engine.AudioStudioEngine.mixTracksToPcm16(
                tracks = listOf(trackOneShot),
                totalFrames = 48, // 2.0s timeline
                fps = 24,
                targetSampleRate = sr
            )!!
            // After 0.35s (well past the 0.25s clip), One-Shot mix MUST be strictly silent (zero looping!)
            val tailSlice = mixedOneShot.copyOfRange((sr * 0.35).toInt(), (sr * 1.5).toInt())
            assertTrue("One-Shot audio must NEVER repeat past its natural duration", tailSlice.all { it == 0.toShort() })

            // When loopClip = true is explicitly enabled, audio repeats cleanly inside [startFrame, endFrame]
            val mixedLooped = com.example.engine.AudioStudioEngine.mixTracksToPcm16(
                tracks = listOf(trackOneShot.copy(loopClip = true)),
                totalFrames = 48,
                fps = 24,
                targetSampleRate = sr
            )!!
            val loopedTailSlice = mixedLooped.copyOfRange((sr * 0.35).toInt(), (sr * 1.0).toInt())
            assertTrue("Explicitly looped audio must repeat within clip bounds", loopedTailSlice.any { it != 0.toShort() })
        } finally {
            tmpWav.delete()
        }
    }

    @Test
    fun unifiedFixesFrontL34MirrorStrictFkAndKeyframedCharSwapWork() {
        val rig = RigSolver.createHumanoidRig(name = "Hero", rootX = 640f, rootY = 420f)
        val baseAngles = rig.bones.associate { it.id to it.localAngleDeg }

        // 1. Front-L 3/4 is an EXACT horizontal mirror of Front-R 3/4 around rootX (zero limbs folded upward onto chest!)
        val solvedRight = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = baseAngles,
            rootX = 640f,
            rootY = 420f,
            scale = 1f,
            flippedHorizontal = false
        ).associateBy { it.bone.id }

        val solvedLeft = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = baseAngles,
            rootX = 640f,
            rootY = 420f,
            scale = 1f,
            flippedHorizontal = true
        ).associateBy { it.bone.id }

        for (boneId in listOf("shoulder_l", "shoulder_r", "arm_l_up", "arm_l_low", "hand_l", "arm_r_up", "arm_r_low", "hand_r", "leg_l_up", "leg_l_low", "foot_l", "leg_r_up", "leg_r_low", "foot_r")) {
            val r = solvedRight[boneId]!!
            val l = solvedLeft[boneId]!!
            // Exact mirror across x = 640f and IDENTICAL vertical Y positions!
            assertEquals("Mirrored X start for $boneId", 640f - (r.start.x - 640f), l.start.x, 0.25f)
            assertEquals("Mirrored X end for $boneId", 640f - (r.end.x - 640f), l.end.x, 0.25f)
            assertEquals("Identical Y start for $boneId", r.start.y, l.start.y, 0.25f)
            assertEquals("Identical Y end for $boneId", r.end.y, l.end.y, 0.25f)
        }
        // Arms and legs must extend DOWNWARD (end.y > start.y), never folded upward onto the chest!
        assertTrue("Left upper arm hangs downward in Front-L 3/4", solvedLeft["arm_l_up"]!!.end.y > solvedLeft["arm_l_up"]!!.start.y)
        assertTrue("Right upper arm hangs downward in Front-L 3/4", solvedLeft["arm_r_up"]!!.end.y > solvedLeft["arm_r_up"]!!.start.y)
        assertTrue("Left thigh hangs downward in Front-L 3/4", solvedLeft["leg_l_up"]!!.end.y > solvedLeft["leg_l_up"]!!.start.y)
        assertTrue("Right thigh hangs downward in Front-L 3/4", solvedLeft["leg_r_up"]!!.end.y > solvedLeft["leg_r_up"]!!.start.y)

        // 2. Strict Hierarchical FK via Prisma 3D Rotation Ring:
        // Rotating arm_r_up by +45° modifies ONLY arm_r_up localAngle; parent stays 100% stationary,
        // and child bones (arm_r_low, hand_r) keep localAngle delta = 0 while swinging rigidly!
        assertFalse("ikEnabled must default to false for strict FK", rig.ikEnabled)
        val rotatedAngles = RigSolver.rotateBoneLocalAngleFk(
            rig = rig,
            boneId = "arm_r_up",
            currentAngles = baseAngles,
            deltaAngleDeg = 45f
        )
        assertEquals(baseAngles["arm_r_up"]!! + 45f, rotatedAngles["arm_r_up"]!!, 0.01f)
        assertEquals("Parent shoulder_r localAngle unchanged", baseAngles["shoulder_r"]!!, rotatedAngles["shoulder_r"]!!, 0.01f)
        assertEquals("Child arm_r_low localAngle delta = 0", baseAngles["arm_r_low"]!!, rotatedAngles["arm_r_low"]!!, 0.01f)
        assertEquals("Grandchild hand_r localAngle delta = 0", baseAngles["hand_r"]!!, rotatedAngles["hand_r"]!!, 0.01f)

        val solvedAfterRot = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = rotatedAngles,
            rootX = 640f,
            rootY = 420f,
            scale = 1f,
            flippedHorizontal = false
        ).associateBy { it.bone.id }

        // Parent shoulder_r start & end are 100% stationary
        assertEquals(solvedRight["shoulder_r"]!!.end.x, solvedAfterRot["shoulder_r"]!!.end.x, 0.01f)
        assertEquals(solvedRight["shoulder_r"]!!.end.y, solvedAfterRot["shoulder_r"]!!.end.y, 0.01f)
        // Child arm_r_low worldAngle increased by EXACTLY +45° (rigid swing with zero extra elbow bend!)
        assertEquals(solvedRight["arm_r_low"]!!.worldAngleDeg + 45f, solvedAfterRot["arm_r_low"]!!.worldAngleDeg, 0.05f)
        assertEquals(solvedRight["hand_r"]!!.worldAngleDeg + 45f, solvedAfterRot["hand_r"]!!.worldAngleDeg, 0.05f)

        // 3. Keyframed Character Swap (Step-Hold Interpolation + Stage Transform/Pose Preservation + Moshi JSON Round-Trip)
        val charA = RigSolver.createRiggedCharacterFromSpec(ProceduralSmartTools.characterPresets[0], rootX = 500f, rootY = 400f).copy(
            id = "char_a",
            poseKeyframes = mapOf("0" to rotatedAngles)
        )
        val charB = RigSolver.createRiggedCharacterFromSpec(ProceduralSmartTools.characterPresets[1], rootX = 100f, rootY = 100f).copy(
            id = "char_b"
        )
        val swapLayer = AnimationLayer(
            name = "Hero Track",
            type = LayerType.CHARACTER.name,
            rig = charA,
            characterSwapKeyframes = mapOf(20 to "char_b"),
            characterSwapRigs = mapOf("char_b" to charB)
        )

        // Before frame 20 -> renders original charA
        org.junit.Assert.assertNull(InterpolationEngine.evaluateCharacterSwapId(swapLayer, 19))
        val rigAt19 = InterpolationEngine.resolveEffectiveRigAtFrame(swapLayer, 19)!!
        assertEquals("char_a", rigAt19.id)

        // At frame 20 and frame 35 (Step-Hold) -> renders charB artwork/appearance while preserving charA's stage root & animated poseKeyframes!
        assertEquals("char_b", InterpolationEngine.evaluateCharacterSwapId(swapLayer, 20))
        assertEquals("char_b", InterpolationEngine.evaluateCharacterSwapId(swapLayer, 35))
        val rigAt25 = InterpolationEngine.resolveEffectiveRigAtFrame(swapLayer, 25)!!
        assertEquals(charB.characterAppearance?.name, rigAt25.characterAppearance?.name)
        assertEquals("Stage rootX preserved from base rig", 500f, rigAt25.rootX, 0.01f)
        assertEquals("Stage rootY preserved from base rig", 400f, rigAt25.rootY, 0.01f)
        assertEquals("Animated poseKeyframes preserved on swap", rotatedAngles["arm_r_up"]!!, rigAt25.poseKeyframes["0"]!!["arm_r_up"]!!, 0.01f)

        // Moshi JSON round-trip preserves characterSwapKeyframes & characterSwapRigs
        val moshi = com.squareup.moshi.Moshi.Builder()
            .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
            .build()
        val layerAdapter = moshi.adapter(AnimationLayer::class.java)
        val restoredLayer = layerAdapter.fromJson(layerAdapter.toJson(swapLayer))!!
        assertEquals("char_b", restoredLayer.characterSwapKeyframes[20])
        assertEquals(charB.name, restoredLayer.characterSwapRigs["char_b"]?.name)
    }

    @Test
    fun unifiedFourModuleUpgrade_coreLock_propGrabRotateDetach_andCodeCharacterBuilder() {
        // 1. Module 1: Fixed Structural Core Bones (Pelvis, Waist, Chest, Shoulders, Hips) + Optional Unlock Core
        val rig = RigSolver.createHumanoidRig(name = "Seamless Hero", rootX = 640f, rootY = 420f)
        assertFalse("unlockCoreBones must default to false", rig.unlockCoreBones)
        for (coreId in listOf("pelvis", "waist", "spine", "shoulder_l", "shoulder_r", "hip_l", "hip_r")) {
            val b = rig.bones.first { it.id == coreId }
            assertTrue("$coreId must be structurally fixed by default", RigSolver.isBoneStructurallyFixed(rig, b))
        }
        for (limbId in listOf("neck", "arm_l_up", "arm_l_low", "hand_l", "arm_r_up", "arm_r_low", "hand_r", "leg_l_up", "leg_l_low", "foot_l", "leg_r_up", "leg_r_low", "foot_r")) {
            val b = rig.bones.first { it.id == limbId }
            assertFalse("$limbId must remain freely poseable", RigSolver.isBoneStructurallyFixed(rig, b))
        }

        val baseAngles = rig.bones.associate { it.id to it.localAngleDeg }
        // Attempting to rotate a structurally fixed core bone while locked must be a no-op
        val blockedShoulderRot = RigSolver.rotateBoneLocalAngleFk(rig, "shoulder_r", baseAngles, deltaAngleDeg = 40f)
        assertEquals(baseAngles["shoulder_r"]!!, blockedShoulderRot["shoulder_r"]!!, 0.01f)
        val blockedWaistRot = RigSolver.rotateBoneLocalAngleFk(rig, "waist", baseAngles, deltaAngleDeg = 30f)
        assertEquals(baseAngles["waist"]!!, blockedWaistRot["waist"]!!, 0.01f)

        // Enabling Unlock Core allows rotating core bones normally
        val unlockedRig = rig.copy(unlockCoreBones = true)
        val allowedShoulderRot = RigSolver.rotateBoneLocalAngleFk(unlockedRig, "shoulder_r", baseAngles, deltaAngleDeg = 40f)
        assertEquals(baseAngles["shoulder_r"]!! + 40f, allowedShoulderRot["shoulder_r"]!!, 0.01f)

        // 2. Module 3: Rigid Bone-Local Child Prop Grab (Zero Jump), Child Swing, Independent Prop Rotation While Held, & Clean Detach (Zero Auto-Drop)
        val armRotatedAngles = RigSolver.rotateBoneLocalAngleFk(rig, "arm_r_up", baseAngles, deltaAngleDeg = 45f)
        val hostRig = rig.copy(
            poseKeyframes = mapOf(
                "0" to baseAngles,
                "10" to armRotatedAngles
            )
        )
        val hostLayer = AnimationLayer(id = "hero_1", name = "Hero", type = LayerType.CHARACTER.name, rig = hostRig)
        val pivot = Vec2(640f, 360f)

        // Solve host hand_r at frame 0 to compute exact zero-jump bone-local grab
        val solvedF0 = RigSolver.solveForwardKinematics(hostRig, baseAngles, rootX = 640f, rootY = 420f).associateBy { it.bone.id }
        val handF0 = solvedF0["hand_r"]!!
        val initialPropWorldX = 760f
        val initialPropWorldY = 390f
        val initialPropAngle = 15f
        val dx0 = initialPropWorldX - handF0.end.x
        val dy0 = initialPropWorldY - handF0.end.y
        val negRad = Math.toRadians(-handF0.worldAngleDeg.toDouble())
        val localOffX = (dx0 * kotlin.math.cos(negRad) - dy0 * kotlin.math.sin(negRad)).toFloat()
        val localOffY = (dx0 * kotlin.math.sin(negRad) + dy0 * kotlin.math.cos(negRad)).toFloat()

        // Prop is grabbed at F0, rotated independently by +30° at F10 while STILL HELD, then cleanly detached at F15
        val propLayerHeld = AnimationLayer(
            id = "sword_prop",
            name = "Sword",
            type = LayerType.DRAWING.name,
            keyframes = listOf(
                TransformKeyframe(frame = 0, x = initialPropWorldX - pivot.x, y = initialPropWorldY - pivot.y, rotationDeg = initialPropAngle),
                TransformKeyframe(frame = 10, x = initialPropWorldX - pivot.x, y = initialPropWorldY - pivot.y, rotationDeg = initialPropAngle + 30f)
            ),
            propGrabKeyframes = listOf(
                com.example.data.model.PropGrabKeyframe(
                    frame = 0,
                    targetLayerId = hostLayer.id,
                    targetBoneId = "hand_r",
                    offsetX = localOffX,
                    offsetY = localOffY,
                    rotationOffsetDeg = -handF0.worldAngleDeg,
                    useBoneLocalSpace = true
                )
            )
        )
        val sceneWithHeld = com.example.data.model.AnimationScene(durationFrames = 40, layers = listOf(hostLayer, propLayerHeld))

        // At F0 (grab frame): ZERO jump in position or angle!
        val worldAtGrab = InterpolationEngine.resolvePropWorldTransform(sceneWithHeld, propLayerHeld, pivot, frame = 0)
        assertTrue("Prop must be attached at F0", worldAtGrab.isAttached)
        assertEquals("Zero X jump on Grab", initialPropWorldX, worldAtGrab.worldX, 0.25f)
        assertEquals("Zero Y jump on Grab", initialPropWorldY, worldAtGrab.worldY, 0.25f)
        assertEquals("Zero Angle jump on Grab", initialPropAngle, worldAtGrab.worldAngleDeg, 0.25f)

        // At F10: arm rotated +45° AND prop independently rotated +30° -> total worldAngle = 15 + 45 + 30 = 90°!
        val worldAtF10 = InterpolationEngine.resolvePropWorldTransform(sceneWithHeld, propLayerHeld, pivot, frame = 10)
        assertTrue("Prop still attached at F10", worldAtF10.isAttached)
        assertEquals("Rigid child swing (+45°) + independent prop rotation (+30°)", initialPropAngle + 45f + 30f, worldAtF10.worldAngleDeg, 0.35f)
        // Distance from hand_r tip to prop center stays strictly rigid!
        val solvedF10 = RigSolver.solveForwardKinematics(hostRig, armRotatedAngles, rootX = 640f, rootY = 420f).associateBy { it.bone.id }
        val handF10 = solvedF10["hand_r"]!!
        val distAtF0 = kotlin.math.hypot(dx0.toDouble(), dy0.toDouble()).toFloat()
        val distAtF10 = kotlin.math.hypot((worldAtF10.worldX - handF10.end.x).toDouble(), (worldAtF10.worldY - handF10.end.y).toDouble()).toFloat()
        assertEquals("Bone-local distance from hand tip remains strictly rigid", distAtF0, distAtF10, 0.35f)

        // Clean Release at F15: records exact world coordinates & angle with ZERO auto-drop/gravity at F25!
        val worldBeforeRelease = InterpolationEngine.resolvePropWorldTransform(sceneWithHeld, propLayerHeld, pivot, frame = 15)
        val releasedLayer = propLayerHeld.copy(
            keyframes = propLayerHeld.keyframes + TransformKeyframe(
                frame = 15,
                x = worldBeforeRelease.worldX - pivot.x,
                y = worldBeforeRelease.worldY - pivot.y,
                rotationDeg = worldBeforeRelease.worldAngleDeg
            ),
            propGrabKeyframes = propLayerHeld.propGrabKeyframes + com.example.data.model.PropGrabKeyframe(
                frame = 15,
                targetLayerId = null,
                targetBoneId = null,
                useBoneLocalSpace = false
            )
        )
        val sceneReleased = sceneWithHeld.copy(layers = listOf(hostLayer, releasedLayer))
        val worldAtRelease = InterpolationEngine.resolvePropWorldTransform(sceneReleased, releasedLayer, pivot, frame = 15)
        val worldAfterRelease = InterpolationEngine.resolvePropWorldTransform(sceneReleased, releasedLayer, pivot, frame = 30)
        assertFalse("Prop detached at F15", worldAtRelease.isAttached)
        assertEquals("Zero X jump on Release", worldBeforeRelease.worldX, worldAtRelease.worldX, 0.25f)
        assertEquals("Zero Y jump on Release", worldBeforeRelease.worldY, worldAtRelease.worldY, 0.25f)
        assertEquals("Zero Angle jump on Release", worldBeforeRelease.worldAngleDeg, worldAtRelease.worldAngleDeg, 0.25f)
        assertEquals("No auto-drop: X stays frozen after Release", worldAtRelease.worldX, worldAfterRelease.worldX, 0.1f)
        assertEquals("No auto-drop: Y stays frozen after Release", worldAtRelease.worldY, worldAfterRelease.worldY, 0.1f)

        // 3. Module 4: "Create Character by Code" JSON + SVG Vector Path (M/L/Q/C/Z) Parser & Moshi Persistence
        val parsed = com.example.engine.CharacterCodeParser.parseCharacterCode(
            com.example.engine.CharacterCodeParser.DEFAULT_TEMPLATE_JSON
        )
        assertTrue("Default Cyber Nova template must parse cleanly", parsed.rig != null && parsed.error == null)
        val codedRig = parsed.rig!!
        assertEquals("Cyber Nova", codedRig.name)
        assertEquals(2, codedRig.characterAppearance?.customCodePaths?.size)

        // Validate SVG path command parser handles M/L/Q/C/Z cleanly on pure JVM
        val parsedOps = com.example.engine.CharacterCodeParser.parseSvgPathOps("M -20 -10 L 20 -10 Q 0 15 -20 -10 C -10 5 10 5 0 18 Z")
        assertEquals(5, parsedOps.size)
        assertTrue(parsedOps[0] is com.example.engine.CharacterCodeParser.SvgPathOp.MoveTo)
        assertTrue(parsedOps[1] is com.example.engine.CharacterCodeParser.SvgPathOp.LineTo)
        assertTrue(parsedOps[2] is com.example.engine.CharacterCodeParser.SvgPathOp.QuadTo)
        assertTrue(parsedOps[3] is com.example.engine.CharacterCodeParser.SvgPathOp.CubicTo)
        assertTrue(parsedOps[4] is com.example.engine.CharacterCodeParser.SvgPathOp.Close)

        // Invalid JSON produces clear user-facing error
        val badParse = com.example.engine.CharacterCodeParser.parseCharacterCode("{ broken json")
        assertTrue("Malformed JSON must return error message", badParse.rig == null && !badParse.error.isNullOrBlank())

        // Moshi round-trip preserves CodedVectorPath list & unlockCoreBones flag
        val moshi = com.squareup.moshi.Moshi.Builder()
            .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
            .build()
        val rigAdapter = moshi.adapter(com.example.data.model.SkeletalRig::class.java)
        val roundTripped = rigAdapter.fromJson(rigAdapter.toJson(codedRig))!!
        assertEquals(2, roundTripped.characterAppearance?.customCodePaths?.size)
        assertFalse(roundTripped.unlockCoreBones)
    }

    @Test
    fun unifiedSixModuleUiAndEngineMasterFix_sideViews_boneLock_shrink_propAttach_andFullRangePlayback() {
        // 1. Default autoWalkWhenDragged = false + Strict Manual Keyframe Priority + Per-Bone Lock
        val rig = RigSolver.createHumanoidRig(name = "Studio Hero", rootX = 640f, rootY = 420f)
        assertFalse("autoWalkWhenDragged must default to false", rig.autoWalkWhenDragged)
        val baseAngles = rig.bones.associate { it.id to it.localAngleDeg }

        // Lock arm_r_up via lockedBoneIds -> rotation, drag, stretch, AND procedural Auto-Walk must NOT move arm_r_up!
        val lockedRig = rig.copy(
            lockedBoneIds = listOf("arm_r_up"),
            autoWalkWhenDragged = true
        )
        assertTrue(RigSolver.isBoneLocked(lockedRig, lockedRig.bones.first { it.id == "arm_r_up" }))
        assertFalse(RigSolver.isBoneLocked(lockedRig, lockedRig.bones.first { it.id == "arm_l_up" }))

        val afterLockedRot = RigSolver.rotateBoneLocalAngleFk(lockedRig, "arm_r_up", baseAngles, deltaAngleDeg = 55f)
        assertEquals("Locked bone refuses FK rotation", baseAngles["arm_r_up"]!!, afterLockedRot["arm_r_up"]!!, 0.01f)

        val afterLockedDrag = RigSolver.solveDragTarget(
            rig = lockedRig,
            boneId = "arm_r_up",
            target = Vec2(900f, 120f),
            currentAngles = baseAngles,
            useIk = false
        )
        assertEquals("Locked bone refuses direct drag", baseAngles["arm_r_up"]!!, afterLockedDrag["arm_r_up"]!!, 0.01f)

        val (afterLockedStretchAngles, afterLockedStretchLengths) = RigSolver.solveStretchDragTarget(
            rig = lockedRig,
            boneId = "arm_r_up",
            target = Vec2(950f, 600f),
            currentAngles = baseAngles,
            currentLengths = emptyMap()
        )
        assertEquals("Locked bone refuses stretch rotation", baseAngles["arm_r_up"]!!, afterLockedStretchAngles["arm_r_up"]!!, 0.01f)
        assertFalse("Locked bone refuses stretch length change", afterLockedStretchLengths.containsKey("arm_r_up"))

        // Strict manual priority: once a manual poseKeyframe exists, even if autoWalkWhenDragged = true,
        // Auto-Walk NEVER overrides the user's manual limb pose when moving the root!
        val manualArmPose = baseAngles.toMutableMap().apply { put("arm_l_up", 110f); put("leg_l_up", 125f) }
        val manualRigWithWalkFlag = rig.copy(
            autoWalkWhenDragged = true,
            poseKeyframes = mapOf("0" to manualArmPose),
            rootKeyframes = listOf(
                com.example.data.model.PuppetRootKeyframe(frame = 0, rootX = 400f, rootY = 420f),
                com.example.data.model.PuppetRootKeyframe(frame = 20, rootX = 800f, rootY = 420f)
            )
        )
        val manualLayer = AnimationLayer(id = "manual_hero", name = "Manual", type = LayerType.CHARACTER.name, rig = manualRigWithWalkFlag)
        val evaluatedManualAt10 = InterpolationEngine.evaluateRigAnglesWithPath(
            layer = manualLayer,
            rig = manualRigWithWalkFlag,
            frame = 10,
            totalFrames = 40,
            fps = 24
        )
        assertEquals("Manual pose keyframe takes strict priority over Auto-Walk", 110f, evaluatedManualAt10["arm_l_up"]!!, 0.05f)
        assertEquals("Manual leg keyframe never overwritten by Auto-Walk", 125f, evaluatedManualAt10["leg_l_up"]!!, 0.05f)

        // 2. Smooth Bone Shrinking (0.2x..2.5x) via solveStretchDragTarget
        val armBone = rig.bones.first { it.id == "arm_r_up" }
        val solvedBase = RigSolver.solveForwardKinematics(rig, baseAngles, rootX = 640f, rootY = 420f).associateBy { it.bone.id }
        val armStart = solvedBase["arm_r_up"]!!.start
        // Pull almost directly on top of pivot -> shrinks smoothly down to min 0.2x (never stuck at 1.0x!)
        val (_, shrunkLengths) = RigSolver.solveStretchDragTarget(
            rig = rig,
            boneId = "arm_r_up",
            target = Vec2(armStart.x + 2f, armStart.y + 2f),
            currentAngles = baseAngles,
            currentLengths = emptyMap()
        )
        val expectedMinLen = (armBone.length * 0.2f).coerceAtLeast(6f)
        assertEquals("Bone shrinks smoothly down to 0.2x", expectedMinLen, shrunkLengths["arm_r_up"]!!, 0.5f)
        assertTrue("Shrunk length is strictly shorter than base length", shrunkLengths["arm_r_up"]!! < armBone.length * 0.5f)

        // Pull very far -> caps at 2.5x
        val (_, stretchedLengths) = RigSolver.solveStretchDragTarget(
            rig = rig,
            boneId = "arm_r_up",
            target = Vec2(armStart.x + 900f, armStart.y),
            currentAngles = baseAngles,
            currentLengths = emptyMap()
        )
        assertEquals("Bone stretch caps at 2.5x", armBone.length * 2.5f, stretchedLengths["arm_r_up"]!!, 0.5f)

        // 3. True Full-Body Side & 3/4 Views: Foreshortened Shoulder/Hip Sockets & Forward-Pointing Shoes
        val solvedFront = RigSolver.solveForwardKinematics(
            rig = rig, angleOverrides = baseAngles, rootX = 640f, rootY = 420f,
            viewAngle = com.example.data.model.CharacterViewAngle.FRONT
        ).associateBy { it.bone.id }
        val solvedSideRight = RigSolver.solveForwardKinematics(
            rig = rig, angleOverrides = baseAngles, rootX = 640f, rootY = 420f,
            viewAngle = com.example.data.model.CharacterViewAngle.SIDE_RIGHT
        ).associateBy { it.bone.id }
        val solvedSideLeft = RigSolver.solveForwardKinematics(
            rig = rig, angleOverrides = baseAngles, rootX = 640f, rootY = 420f,
            flippedHorizontal = true,
            viewAngle = com.example.data.model.CharacterViewAngle.SIDE_LEFT
        ).associateBy { it.bone.id }

        val frontShoulderSpan = kotlin.math.abs(solvedFront["shoulder_r"]!!.end.x - solvedFront["shoulder_l"]!!.end.x)
        val sideShoulderSpan = kotlin.math.abs(solvedSideRight["shoulder_r"]!!.end.x - solvedSideRight["shoulder_l"]!!.end.x)
        assertTrue(
            "Side view shoulders must foreshorten dramatically onto torso centerline (front=$frontShoulderSpan, side=$sideShoulderSpan)",
            sideShoulderSpan < frontShoulderSpan * 0.30f
        )
        // Both feet point RIGHT in SIDE_RIGHT (end.x > start.x) and LEFT in SIDE_LEFT (end.x < start.x)
        assertTrue("Right shoe points right in Side Right", solvedSideRight["foot_r"]!!.end.x > solvedSideRight["foot_r"]!!.start.x)
        assertTrue("Left shoe points right in Side Right", solvedSideRight["foot_l"]!!.end.x > solvedSideRight["foot_l"]!!.start.x)
        assertTrue("Right shoe points left in Side Left", solvedSideLeft["foot_r"]!!.end.x < solvedSideLeft["foot_r"]!!.start.x)
        assertTrue("Left shoe points left in Side Left", solvedSideLeft["foot_l"]!!.end.x < solvedSideLeft["foot_l"]!!.start.x)

        // 4. Generalized "Attach to Bone" (e.g., Hat locked to Head `neck` bone) with isBoneLocked = true & Clean Detach
        val headRotatedAngles = RigSolver.rotateBoneLocalAngleFk(rig, "neck", baseAngles, deltaAngleDeg = 28f)
        val heroHeadRig = rig.copy(
            poseKeyframes = mapOf("0" to baseAngles, "12" to headRotatedAngles)
        )
        val heroLayer = AnimationLayer(id = "hero_hat_host", name = "Hero", type = LayerType.CHARACTER.name, rig = heroHeadRig)
        val pivot = Vec2(640f, 360f)
        val headF0 = RigSolver.solveForwardKinematics(heroHeadRig, baseAngles, rootX = 640f, rootY = 420f).first { it.bone.id == "neck" }
        val hatStartX = headF0.end.x
        val hatStartY = headF0.end.y - 42f
        val dxHat = hatStartX - headF0.end.x
        val dyHat = hatStartY - headF0.end.y
        val negRadHat = Math.toRadians(-headF0.worldAngleDeg.toDouble())
        val hatLocalX = (dxHat * kotlin.math.cos(negRadHat) - dyHat * kotlin.math.sin(negRadHat)).toFloat()
        val hatLocalY = (dxHat * kotlin.math.sin(negRadHat) + dyHat * kotlin.math.cos(negRadHat)).toFloat()

        val hatLayer = AnimationLayer(
            id = "prop_hat",
            name = "Hat",
            type = LayerType.DRAWING.name,
            keyframes = listOf(TransformKeyframe(frame = 0, x = hatStartX - pivot.x, y = hatStartY - pivot.y, rotationDeg = 0f)),
            propGrabKeyframes = listOf(
                com.example.data.model.PropGrabKeyframe(
                    frame = 0,
                    targetLayerId = heroLayer.id,
                    targetBoneId = "neck",
                    offsetX = hatLocalX,
                    offsetY = hatLocalY,
                    rotationOffsetDeg = -headF0.worldAngleDeg,
                    useBoneLocalSpace = true,
                    isBoneLocked = true
                )
            )
        )
        val hatScene = com.example.data.model.AnimationScene(
            durationFrames = 40,
            cameraKeyframes = listOf(
                com.example.data.model.CameraKeyframe(frame = 0, zoom = 1.0f, panX = 0f),
                com.example.data.model.CameraKeyframe(frame = 20, zoom = 1.6f, panX = 120f)
            ),
            layers = listOf(
                heroLayer.copy(
                    rig = heroHeadRig.copy(
                        rootKeyframes = listOf(
                            com.example.data.model.PuppetRootKeyframe(
                                frame = 0,
                                rootX = 640f,
                                rootY = 420f,
                                activeEyeMood = com.example.data.model.FaceMoodCategory.NORMAL.name
                            ),
                            com.example.data.model.PuppetRootKeyframe(
                                frame = 12,
                                rootX = 760f,
                                rootY = 420f,
                                activeEyeMood = com.example.data.model.FaceMoodCategory.CRYING.name
                            )
                        )
                    )
                ),
                hatLayer
            )
        )

        val hatAt0 = InterpolationEngine.resolvePropWorldTransform(hatScene, hatLayer, pivot, frame = 0)
        assertTrue(hatAt0.isAttached)
        assertEquals("Zero X jump when attaching Hat to Head", hatStartX, hatAt0.worldX, 0.25f)
        assertEquals("Zero Y jump when attaching Hat to Head", hatStartY, hatAt0.worldY, 0.25f)

        // 5. Full-Scene Play Range Evaluation across [rangeStart=4 .. rangeEnd=16]:
        // Motion Path, Mood/Face, Camera Zoom, and Attached Prop ALL evaluate together cleanly on every frame!
        val evaluatedHeroLayer = hatScene.layers[0]
        val rootAt12 = InterpolationEngine.evaluatePuppetRoot(evaluatedHeroLayer.rig!!, frame = 12)
        assertEquals("Motion Path X evaluated inside Play Range", 760f, rootAt12.rootX, 0.1f)
        assertEquals("Mood keyframe evaluated inside Play Range", com.example.data.model.FaceMoodCategory.CRYING.name, rootAt12.activeEyeMood)

        val camAt12 = InterpolationEngine.evaluateCamera(hatScene, frame = 12)
        assertTrue("Camera zoom interpolated inside Play Range", camAt12.zoom > 1.25f)

        val hatAt12 = InterpolationEngine.resolvePropWorldTransform(hatScene, hatLayer, pivot, frame = 12)
        assertTrue("Hat remains attached to Head inside Play Range", hatAt12.isAttached)
        assertEquals("Hat tilts by exact Head rotation (+28°)", 28f, hatAt12.worldAngleDeg, 0.35f)
        assertTrue("Hat translates horizontally with Hero motion path", hatAt12.worldX > hatStartX + 80f)
    }
}


