package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VerticalAlignBottom
import androidx.compose.material.icons.rounded.VerticalAlignTop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.TextButton
import com.example.engine.AudioStudioEngine
import com.example.engine.BoneZOrderAction
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.CustomActionClip
import com.example.data.model.EyebrowStyle
import com.example.data.model.FacialTimingConfig
import com.example.data.model.HandGesturePose
import com.example.data.model.HandPropKind
import com.example.data.model.LayerType
import com.example.data.model.PartBehaviorPreset
import com.example.data.model.RigBone
import com.example.data.model.SkeletalRig
import com.example.engine.AutoActionKind
import com.example.engine.InterpolationEngine
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigAttachmentArea
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.CanvasBackdrop
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CharacterCreatorPanel(
    uiState: StudioUiState,
    onApplyCharacter: (CharacterSpec, Boolean) -> Unit,
    onAutoRigCharacter: (CharacterSpec) -> Unit,
    onSaveTemplate: (CharacterSpec) -> Unit,
    onKeyframeExpressionPose: (String?, String?) -> Unit,
    onOpenCreateByCode: () -> Unit = {}
) {
    val activeChar = uiState.selectedLayer?.character
    var draft by remember(activeChar?.id) {
        mutableStateOf(activeChar ?: ProceduralSmartTools.characterPresets.first())
    }

    LaunchedEffect(activeChar) {
        if (activeChar != null) draft = activeChar
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Live Character Preview Stage
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CanvasBackdrop)
                    .border(1.dp, StudioBorder, RoundedCornerShape(14.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawIntoCanvas { c ->
                        val nc = c.nativeCanvas
                        nc.save()
                        val previewChar = draft.copy(x = size.width / 2f, y = size.height * 0.56f, scale = 0.52f)
                        SceneRenderer.drawCharacter(nc, previewChar, 1f, null)
                        nc.restore()
                    }
                }
                Surface(
                    color = StudioEmerald.copy(alpha = 0.22f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioEmerald),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clickable(onClick = onOpenCreateByCode)
                        .testTag("character_panel_create_by_code_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = "Create by Code", tint = StudioEmerald, modifier = Modifier.size(14.dp))
                        Text("Create by Code", style = MaterialTheme.typography.labelSmall, color = StudioEmerald, fontWeight = FontWeight.Bold)
                    }
                }
                Surface(
                    color = StudioSurfaceVariant.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clickable { draft = ProceduralSmartTools.randomizeCharacter() }
                        .testTag("randomize_character_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.Casino, contentDescription = "Randomize", tint = StudioCyan, modifier = Modifier.size(15.dp))
                        Text("Randomize", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                    }
                }
            }
        }

        // 8-View Turnaround Generator (incl. 3/4 Front & 3/4 Back Dialogue Angles)
        item {
            Text("8-View Turnaround Angle (incl. 3/4 Back)", style = MaterialTheme.typography.labelSmall, color = StudioAmber, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CharacterViewAngle.entries.forEach { angle ->
                    FilterChip(
                        selected = draft.viewAngle == angle.name,
                        onClick = { draft = draft.copy(viewAngle = angle.name) },
                        label = { Text(angle.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("char_view_${angle.name.lowercase()}")
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Character Behavior / Mood Preset", style = MaterialTheme.typography.labelSmall, color = StudioViolet, fontWeight = FontWeight.Bold)
            val activeCharMood = runCatching { CharacterBehaviorPreset.valueOf(draft.behaviorPreset) }
                .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
            Text(activeCharMood.subtitle, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                CharacterBehaviorPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = draft.behaviorPreset == preset.name,
                        onClick = {
                            draft = when (preset) {
                                CharacterBehaviorPreset.NORMAL_CALM -> draft.copy(behaviorPreset = preset.name, expression = "NEUTRAL", eyebrowStyle = EyebrowStyle.NORMAL.name, postureSlouch = 0f)
                                CharacterBehaviorPreset.ANGRY_STRICT -> draft.copy(behaviorPreset = preset.name, expression = "ANGRY", eyebrowStyle = EyebrowStyle.ANGRY.name, postureSlouch = 0.08f)
                                CharacterBehaviorPreset.HORROR_GHOSTLY -> draft.copy(behaviorPreset = preset.name, expression = "SURPRISED", eyebrowStyle = EyebrowStyle.RAISED.name, postureSlouch = 0.14f)
                                CharacterBehaviorPreset.HAPPY_PLAYFUL -> draft.copy(behaviorPreset = preset.name, expression = "HAPPY", eyebrowStyle = EyebrowStyle.RAISED.name, postureSlouch = 0f)
                                CharacterBehaviorPreset.ELDERLY_WEAK -> draft.copy(behaviorPreset = preset.name, expression = "SAD", eyebrowStyle = EyebrowStyle.WORRIED.name, postureSlouch = 0.68f)
                            }
                        },
                        label = { Text(preset.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("char_behavior_${preset.name.lowercase()}")
                    )
                }
            }
        }

        // Character Presets & Name
        item {
            OutlinedTextField(
                value = draft.name,
                onValueChange = { draft = draft.copy(name = it) },
                label = { Text("Character Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text("Quick Presets", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ProceduralSmartTools.characterPresets.forEach { preset ->
                    FilterChip(
                        selected = draft.name == preset.name,
                        onClick = { draft = preset.copy(x = draft.x, y = draft.y, viewAngle = draft.viewAngle) },
                        label = { Text(preset.name, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Expression & Pose
        item {
            Text("Facial Expression", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("HAPPY", "NEUTRAL", "SURPRISED", "ANGRY", "SAD", "WINK", "TALKING").forEach { exp ->
                    FilterChip(
                        selected = draft.expression == exp,
                        onClick = {
                            draft = draft.copy(expression = exp)
                            if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) {
                                onKeyframeExpressionPose(exp, null)
                            }
                        },
                        label = { Text(exp, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Character Pose", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("IDLE", "WAVE", "WALK_A", "WALK_B", "JUMP", "HERO", "SIT").forEach { pose ->
                    FilterChip(
                        selected = draft.pose == pose,
                        onClick = {
                            draft = draft.copy(pose = pose)
                            if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) {
                                onKeyframeExpressionPose(null, pose)
                            }
                        },
                        label = { Text(pose, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Face, Eyes, Hair, Traditional Indian/Bengali Outfits, Accessories & Body Build (Module 4)
        item {
            OptionRow("Face", listOf("OVAL", "ROUND", "SQUARE", "CHIBI"), draft.faceShape) { draft = draft.copy(faceShape = it) }
            OptionRow("Eyes", listOf("ANIME", "DOT", "CARTOON", "COOL", "STAR"), draft.eyeStyle) { draft = draft.copy(eyeStyle = it) }
            OptionRow(
                "Hair (incl. Traditional)",
                listOf("SPIKY", "BOB", "PONYTAIL", "CURLY", "MOHAWK", "BALD", "BRAID_BENI", "TRADITIONAL_BUN", "SAGE_JATA", "LONG_GHOST"),
                draft.hairStyle
            ) { draft = draft.copy(hairStyle = it) }
            OptionRow(
                "Outfit (Modern & Traditional Indian/Bengali)",
                listOf("HOODIE", "TEE", "JACKET", "CAPE", "TUNIC", "PANJABI_DHOTI", "KURTA_PAJAMA", "SAREE", "SALWAR_KAMEEZ", "TANTRIK_ROBE", "VILLAGE_GHOST"),
                draft.shirtStyle
            ) { draft = draft.copy(shirtStyle = it) }
            OptionRow(
                "Accessory",
                listOf("NONE", "GLASSES", "HEADPHONES", "CROWN", "ROYAL_CROWN", "SCARF", "DUPATTA_SHAWL", "RUDRAKSHA_MALA", "HAT"),
                draft.accessory
            ) { draft = draft.copy(accessory = it) }
            OptionRow(
                "Facial Hair",
                listOf("NONE", "THICK_MUSTACHE", "SAGE_BEARD", "GOATEE"),
                draft.facialHair
            ) { draft = draft.copy(facialHair = it) }
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = draft.hasBindi,
                    onClick = { draft = draft.copy(hasBindi = !draft.hasBindi) },
                    label = { Text("Bindi", style = MaterialTheme.typography.labelSmall) }
                )
                FilterChip(
                    selected = draft.hasBangles,
                    onClick = { draft = draft.copy(hasBangles = !draft.hasBangles) },
                    label = { Text("Bangles", style = MaterialTheme.typography.labelSmall) }
                )
            }
            Spacer(Modifier.height(6.dp))
            Text("Body Build & Posture", style = MaterialTheme.typography.labelSmall, color = StudioCyan, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Belly ${(draft.bellyPlumpness * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                Slider(
                    value = draft.bellyPlumpness.coerceIn(0f, 1f),
                    onValueChange = { draft = draft.copy(bellyPlumpness = it) },
                    valueRange = 0f..1f,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Shoulders ${String.format("%.2fx", draft.shoulderWidth)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                Slider(
                    value = draft.shoulderWidth.coerceIn(0.6f, 1.8f),
                    onValueChange = { draft = draft.copy(shoulderWidth = it) },
                    valueRange = 0.6f..1.8f,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Torso ${String.format("%.2fx", draft.torsoScale)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                Slider(
                    value = draft.torsoScale.coerceIn(0.7f, 1.5f),
                    onValueChange = { draft = draft.copy(torsoScale = it) },
                    valueRange = 0.7f..1.5f,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Slouch ${(draft.postureSlouch * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                Slider(
                    value = draft.postureSlouch.coerceIn(0f, 1f),
                    onValueChange = { draft = draft.copy(postureSlouch = it) },
                    valueRange = 0f..1f,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Skin, Hair & Outfit Colors
        item {
            ColorRow("Skin Tone", listOf(0xFFFFDFC4L, 0xFFF5C6A5L, 0xFFE0AC69L, 0xFFC68642L, 0xFF8D5524L), draft.skinToneArgb) {
                draft = draft.copy(skinToneArgb = it)
            }
            ColorRow("Hair Color", listOf(0xFF1F2937L, 0xFF7C2D12L, 0xFF4C1D95L, 0xFFEC4899L, 0xFF0284C7L, 0xFFF59E0BL), draft.hairColorArgb) {
                draft = draft.copy(hairColorArgb = it)
            }
            ColorRow("Shirt Color", listOf(0xFFFF6B35L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFBBF24L, 0xFF10B981L, 0xFFFB7185L), draft.shirtColorArgb) {
                draft = draft.copy(shirtColorArgb = it)
            }
        }

        // Apply / Auto-Rig / Save Actions
        item {
            Button(
                onClick = { onAutoRigCharacter(draft) },
                colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth().testTag("auto_rig_character_button")
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Auto-Rig Human (14 Bones) & Add to Scene", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onApplyCharacter(draft, false) },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    modifier = Modifier.weight(1f).testTag("apply_character_button")
                ) {
                    Text(
                        if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) "Update Layer" else "Insert Static",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedButton(
                    onClick = { onSaveTemplate(draft) },
                    modifier = Modifier.testTag("save_character_template_button")
                ) {
                    Icon(Icons.Rounded.BookmarkAdd, contentDescription = "Save template", modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(4.dp))
            OutlinedButton(
                onClick = { onApplyCharacter(draft, true) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add as New Character Layer", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RiggingInspectorPanel(
    uiState: StudioUiState,
    customAssets: List<SkeletalRig> = emptyList(),
    customActions: List<CustomActionClip> = emptyList(),
    onAddRigLayer: () -> Unit,
    onAutoRigSelectedLayer: () -> Unit,
    onInsertMascotRig: () -> Unit,
    onSetViewAngle: (CharacterViewAngle) -> Unit,
    onSetHandProp: (isRightHand: Boolean, prop: HandPropKind) -> Unit,
    onImportHandPropPng: (isRightHand: Boolean) -> Unit,
    onAddExtraRigBone: (area: RigAttachmentArea, propKind: HandPropKind?) -> Unit = { _, _ -> },
    onImportExtraRigPng: (area: RigAttachmentArea) -> Unit = {},
    onAttachCustomAsset: (asset: SkeletalRig, area: RigAttachmentArea) -> Unit = { _, _ -> },
    onOpenCustomAssetMaker: () -> Unit = {},
    onUpdateBone: (boneId: String, (RigBone) -> RigBone) -> Unit = { _, _ -> },
    onDeleteBone: (boneId: String) -> Unit = {},
    onSelectBone: (String) -> Unit,
    onAddChildBone: (String) -> Unit,
    onApplyPosePreset: (String) -> Unit,
    onToggleIk: () -> Unit,
    onToggleSkin: () -> Unit,
    onSaveRigTemplate: () -> Unit,
    onToggleStretchRig: () -> Unit = {},
    onToggleLiveRecord: () -> Unit = {},
    onSetHandGesture: (isRightHand: Boolean, pose: HandGesturePose) -> Unit = { _, _ -> },
    onSetEyebrow: (EyebrowStyle) -> Unit = {},
    onToggleAutoDialogue: () -> Unit = {},
    onApplyAutoAction: (AutoActionKind) -> Unit = {},
    onApplyCustomAction: (CustomActionClip) -> Unit = {},
    onDeleteCustomAction: (String) -> Unit = {},
    onUpdateBoneScaleAndSpring: (boneId: String, length: Float?, widthScale: Float?, lengthScale: Float?, stiffness: Float?, damping: Float?) -> Unit = { _, _, _, _, _, _ -> },
    onApplyBonePartBehavior: (boneId: String, preset: PartBehaviorPreset) -> Unit = { _, _ -> },
    onSetBehaviorPreset: (CharacterBehaviorPreset) -> Unit = {},
    onAdjustBoneZOrder: (boneId: String, action: BoneZOrderAction) -> Unit = { _, _ -> },
    onApplyAutoHumanLayerOrder: () -> Unit = {},
    onClearZOrderKeyframe: () -> Unit = {},
    onUpdateFacialTiming: ((FacialTimingConfig) -> FacialTimingConfig) -> Unit = {},
    onToggleBoneLock: (boneId: String) -> Unit = {},
    onToggleDetachBone: (boneId: String, gravityFall: Boolean) -> Unit = { _, _ -> },
    onSetPropGrabTarget: (targetLayerId: String?, targetBoneId: String?) -> Unit = { _, _ -> },
    onAddFormMorph: (formName: String, spec: CharacterSpec?, transitionFx: String) -> Unit = { _, _, _ -> },
    onSetLayerOpacityKf: (Float) -> Unit = {},
    onToggleInstantVisibilityKf: (Boolean) -> Unit = {},
    onSetCameraShakeFlash: (shake: Float?, flashAlpha: Float?, flashColor: Long?) -> Unit = { _, _, _ -> },
    onToggleUnlockCore: () -> Unit = {}
) {
    val rig = uiState.selectedLayer?.rig
    var newBoneName by remember { mutableStateOf("Tail / Prop") }
    var editingRightHand by remember { mutableStateOf(true) }
    var selectedAttachArea by remember { mutableStateOf(RigAttachmentArea.RIGHT_HAND) }
    var pendingDeleteActionClip by remember { mutableStateOf<CustomActionClip?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (rig == null) {
            item {
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.AccessibilityNew, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(34.dp))
                        Text("Auto-Rig Human Skeleton", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        Text(
                            "Automatically rig the selected character/image layer into 14 human joints (Head, Spine, Arms, Hands, Legs, Feet) with 2-Bone IK!",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                        Button(
                            onClick = onAutoRigSelectedLayer,
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                            modifier = Modifier.fillMaxWidth().testTag("auto_rig_selected_layer_btn")
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Auto-Rig Selected Layer (Human)", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onAddRigLayer,
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth().testTag("create_humanoid_rig_button")
                        ) {
                            Text("Create New Humanoid Rig", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = onInsertMascotRig, modifier = Modifier.fillMaxWidth()) {
                            Text("Create Cartoon Mascot Rig")
                        }
                    }
                }
            }

            // Module 7: Non-Rig Layer Parent Socket / Grab Target (attach prop/mug/sword to any character's hand!)
            item {
                val scene = uiState.activeScene
                val rigLayers = scene?.layers?.filter { it.rig != null && it.id != uiState.selectedLayer?.id }.orEmpty()
                if (rigLayers.isNotEmpty()) {
                    Surface(
                        color = StudioSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.55f)),
                        modifier = Modifier.fillMaxWidth().testTag("prop_grab_socket_card")
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("PROP GRAB SOCKET (PARENT TO HAND)", style = MaterialTheme.typography.labelMedium, color = StudioAmber, fontWeight = FontWeight.Bold)
                            Text(
                                "Attach this prop layer to a character's hand/head at F${uiState.currentFrame + 1}, then tap Release on a later frame to drop it!",
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary
                            )
                            rigLayers.forEach { host ->
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FilterChip(
                                        selected = false,
                                        onClick = { onSetPropGrabTarget(host.id, "arm_r_low") },
                                        label = { Text("${host.name} R-Hand", style = MaterialTheme.typography.labelSmall) }
                                    )
                                    FilterChip(
                                        selected = false,
                                        onClick = { onSetPropGrabTarget(host.id, "arm_l_low") },
                                        label = { Text("L-Hand", style = MaterialTheme.typography.labelSmall) }
                                    )
                                    FilterChip(
                                        selected = false,
                                        onClick = { onSetPropGrabTarget(host.id, "neck") },
                                        label = { Text("Head", style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = { onSetPropGrabTarget(null, null) },
                                modifier = Modifier.fillMaxWidth().testTag("release_prop_grab_btn")
                            ) {
                                Text("Release / Detach Prop at F${uiState.currentFrame + 1}", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                            }
                        }
                    }
                }
            }
        } else {
            item {
                Button(
                    onClick = onAutoRigSelectedLayer,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth().testTag("upgrade_human_autorig_btn")
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Auto-Rig Human (14 Separate Joints + IK)", fontWeight = FontWeight.Bold)
                }
            }

            // Module 2 & 8: Live "Stretch Rig" & "Live Record" Quick Toggles
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onToggleStretchRig,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.stretchRigMode) StudioCoral else StudioSurfaceVariant,
                            contentColor = if (uiState.stretchRigMode) Color.White else StudioCoral
                        ),
                        modifier = Modifier.weight(1f).testTag("rig_panel_stretch_toggle")
                    ) {
                        Text(if (uiState.stretchRigMode) "Stretch Rig: ON" else "Stretch Rig", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onToggleLiveRecord,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.liveRecordMode) Color(0xFFDC2626) else StudioSurfaceVariant,
                            contentColor = if (uiState.liveRecordMode) Color.White else StudioTextPrimary
                        ),
                        modifier = Modifier.weight(1f).testTag("rig_panel_live_rec_toggle")
                    ) {
                        Text(if (uiState.liveRecordMode) "● Live Rec ON" else "Live Record", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Module 1: Seamless Fixed Core Torso / Shoulders Lock (with optional Unlock Core toggle)
            item {
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (rig.unlockCoreBones) StudioAmber else StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Unlock Core (Pelvis/Waist/Shoulders/Hips)",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (rig.unlockCoreBones) StudioAmber else StudioTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (rig.unlockCoreBones) {
                                    "Core torso & shoulder joints unlocked for manual posing"
                                } else {
                                    "Locked by default — seamless torso, handles on Head/Arms/Legs only"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary
                            )
                        }
                        Switch(
                            checked = rig.unlockCoreBones,
                            onCheckedChange = { onToggleUnlockCore() },
                            modifier = Modifier.testTag("rig_panel_unlock_core_switch")
                        )
                    }
                }
            }

            // 8-View Turnaround Angle (Keyframeable per frame! Includes 3/4 Front & 3/4 Back Dialogue Angles)
            item {
                val rootEval = InterpolationEngine.evaluatePuppetRoot(rig, uiState.currentFrame)
                Text("8-View Turnaround (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CharacterViewAngle.entries.forEach { angle ->
                        FilterChip(
                            selected = rootEval.viewAngle == angle.name,
                            onClick = { onSetViewAngle(angle) },
                            label = { Text(angle.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("rig_view_${angle.name.lowercase()}")
                        )
                    }
                }
            }

            // Whole-Character Acting Behavior / Mood Preset (Keyframeable per frame!)
            item {
                val rootEval = InterpolationEngine.evaluatePuppetRoot(rig, uiState.currentFrame)
                val activeMood = runCatching { CharacterBehaviorPreset.valueOf(rootEval.behaviorPreset) }
                    .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Character Behavior / Mood (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioViolet, fontWeight = FontWeight.Bold)
                Text(activeMood.subtitle, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    CharacterBehaviorPreset.entries.forEach { preset ->
                        FilterChip(
                            selected = rootEval.behaviorPreset == preset.name,
                            onClick = { onSetBehaviorPreset(preset) },
                            label = { Text(preset.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("rig_behavior_${preset.name.lowercase()}")
                        )
                    }
                }
            }

            // Module 4 & 6: Hand Gestures, Eyebrow Acting & Auto-Dialogue Acting
            item {
                val rootEval = InterpolationEngine.evaluatePuppetRoot(rig, uiState.currentFrame)
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Hand Gestures (${if (editingRightHand) "Right" else "Left"} Hand • F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioCyan)
                val activeGesture = if (editingRightHand) rootEval.rightHandGesture else rootEval.leftHandGesture
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    HandGesturePose.entries.forEach { pose ->
                        FilterChip(
                            selected = activeGesture == pose.name,
                            onClick = { onSetHandGesture(editingRightHand, pose) },
                            label = { Text(pose.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("hand_gesture_${pose.name.lowercase()}")
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Eyebrow Acting (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioViolet)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    EyebrowStyle.entries.forEach { brow ->
                        FilterChip(
                            selected = rootEval.eyebrowStyle == brow.name,
                            onClick = { onSetEyebrow(brow) },
                            label = { Text(brow.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("eyebrow_${brow.name.lowercase()}")
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Auto-Dialogue Acting (Head bob + talk gestures)", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary, modifier = Modifier.weight(1f))
                    Switch(checked = rig.autoDialogueActing, onCheckedChange = { onToggleAutoDialogue() })
                }
                Spacer(Modifier.height(8.dp))
                FacialTimingIntervalCard(
                    timing = rig.facialTiming,
                    fps = uiState.activeProject?.fps ?: 24,
                    onUpdateTiming = onUpdateFacialTiming
                )
            }

            // Module 8: One-Tap Auto-Actions & Reusable Custom Action Library
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("One-Tap Auto-Actions (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioCoral)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AutoActionKind.entries.forEach { kind ->
                        FilterChip(
                            selected = false,
                            onClick = { onApplyAutoAction(kind) },
                            label = { Text(kind.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("auto_action_${kind.name.lowercase()}")
                        )
                    }
                }
                if (customActions.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Saved Custom Actions (${customActions.size})", style = MaterialTheme.typography.labelMedium, color = StudioEmerald, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        customActions.forEach { clip ->
                            Surface(
                                color = StudioSurfaceVariant,
                                shape = RoundedCornerShape(9.dp),
                                border = BorderStroke(1.dp, StudioEmerald.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(9.dp))
                                    .clickable { onApplyCustomAction(clip) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(start = 8.dp, end = 2.dp, top = 4.dp, bottom = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("${clip.name} (${clip.durationFrames}f)", style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary)
                                    IconButton(
                                        onClick = { pendingDeleteActionClip = clip },
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete custom action", tint = StudioRose, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Attach Anything to Left or Right Hand (Built-in Props + Custom PNG Import!)
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Attach Item to Hand", style = MaterialTheme.typography.titleSmall, color = StudioEmerald)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = !editingRightHand,
                            onClick = { editingRightHand = false },
                            label = { Text("L-Hand", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = editingRightHand,
                            onClick = { editingRightHand = true },
                            label = { Text("R-Hand", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                val activeProp = if (editingRightHand) rig.rightHandProp else rig.leftHandProp
                val hasCustomPng = !(if (editingRightHand) rig.rightHandCustomImagePath else rig.leftHandCustomImagePath).isNullOrBlank()
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    HandPropKind.entries.forEach { prop ->
                        FilterChip(
                            selected = !hasCustomPng && activeProp == prop.name,
                            onClick = { onSetHandProp(editingRightHand, prop) },
                            label = { Text(prop.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("hand_prop_${prop.name.lowercase()}")
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(
                    onClick = { onImportHandPropPng(editingRightHand) },
                    modifier = Modifier.fillMaxWidth().testTag("import_png_to_hand_btn")
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (hasCustomPng) "Replace Custom PNG in ${if (editingRightHand) "Right" else "Left"} Hand"
                        else "Import Custom PNG into ${if (editingRightHand) "Right" else "Left"} Hand",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            // Extra Variable Rig & Attachments on ANY Body Area (Hands, Legs, Foot, Head, Chest, Hip, or Selected Bone!)
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth().testTag("extra_variable_rig_card")
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Rounded.Extension, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(16.dp))
                                Text(
                                    "Extra Variable Rig (Any Body Area)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = StudioCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            "Add movable extra rig bones + objects, custom PNGs, or saved Custom Assets onto Hands, Legs, Feet, Head, Chest, or Hip.",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextSecondary
                        )

                        // Area Picker Chips
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            RigAttachmentArea.entries.forEach { area ->
                                FilterChip(
                                    selected = selectedAttachArea == area,
                                    onClick = { selectedAttachArea = area },
                                    label = { Text(area.shortLabel, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("extra_rig_area_${area.name.lowercase()}")
                                )
                            }
                        }

                        // Primary Actions for Selected Area: Blank Variable Bone or Custom PNG
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { onAddExtraRigBone(selectedAttachArea, null) },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                                modifier = Modifier.weight(1f).testTag("add_extra_bone_btn")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("+ Rig Bone", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { onImportExtraRigPng(selectedAttachArea) },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                                modifier = Modifier.weight(1f).testTag("add_extra_png_rig_btn")
                            ) {
                                Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("+ PNG Object", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Quick Built-in Animated Prop Attached as Independent Extra Variable Bone
                        Text(
                            "Quick Attach Prop to ${selectedAttachArea.label}:",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioAmber
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            HandPropKind.entries.filter { it != HandPropKind.NONE }.forEach { prop ->
                                FilterChip(
                                    selected = false,
                                    onClick = { onAddExtraRigBone(selectedAttachArea, prop) },
                                    label = { Text("+ ${prop.label}", style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("extra_rig_prop_${prop.name.lowercase()}")
                                )
                            }
                        }

                        // Attach User's Saved Custom Rigged Assets directly onto the chosen body area!
                        HorizontalDivider(color = StudioBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "My Custom Assets (${customAssets.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = StudioEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            OutlinedButton(
                                onClick = onOpenCustomAssetMaker,
                                modifier = Modifier.testTag("open_custom_asset_maker_from_rig_btn")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("Make Asset", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                            }
                        }
                        if (customAssets.isEmpty()) {
                            Text(
                                "Tap \"Make Asset\" to build & rig your own reusable objects/props (sword, cape, wings, skateboard, custom PNG) and attach them to any area!",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        } else {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                customAssets.forEach { asset ->
                                    FilterChip(
                                        selected = false,
                                        onClick = { onAttachCustomAsset(asset, selectedAttachArea) },
                                        label = { Text("+ ${asset.name} (${asset.bones.size}b)", style = MaterialTheme.typography.labelSmall) },
                                        modifier = Modifier.testTag("attach_custom_asset_${asset.id}")
                                    )
                                }
                            }
                        }

                        // Live Tuning Sliders for Currently Selected Extra Variable Bone
                        val selBone = rig.bones.firstOrNull { it.id == uiState.selectedBoneId }
                        if (selBone != null && (selBone.isExtraRigBone || !selBone.boundImagePath.isNullOrBlank() || !selBone.attachedPropKind.isNullOrBlank())) {
                            HorizontalDivider(color = StudioBorder)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Tune: ${selBone.name}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StudioAmber,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(
                                    onClick = { onDeleteBone(selBone.id) },
                                    modifier = Modifier.size(28.dp).testTag("delete_extra_bone_${selBone.id}")
                                ) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete extra rig bone", tint = StudioRose, modifier = Modifier.size(17.dp))
                                }
                            }
                            Text(
                                "Object Scale: ${String.format("%.2fx", selBone.imageScale)} • Bone Len: ${selBone.length.toInt()}px",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextSecondary
                            )
                            Slider(
                                value = selBone.imageScale.coerceIn(0.1f, 6.0f),
                                onValueChange = { sc -> onUpdateBone(selBone.id) { it.copy(imageScale = sc) } },
                                valueRange = 0.1f..6.0f,
                                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan)
                            )
                            Slider(
                                value = selBone.length.coerceIn(18f, 260f),
                                onValueChange = { len -> onUpdateBone(selBone.id) { it.copy(length = len) } },
                                valueRange = 18f..260f,
                                colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber)
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("2-Bone Inverse Kinematics (IK)", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                    Switch(checked = rig.ikEnabled, onCheckedChange = { onToggleIk() })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Show Stylized Limb Mesh", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                    Switch(checked = rig.showSkinMesh, onCheckedChange = { onToggleSkin() })
                }
            }

            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Keyframe Pose Presets (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("IDLE", "WAVE", "WALK_A", "WALK_B", "JUMP").forEach { pose ->
                        FilterChip(
                            selected = false,
                            onClick = { onApplyPosePreset(pose) },
                            label = { Text(pose, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Add Child Bone", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = newBoneName,
                        onValueChange = { newBoneName = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { onAddChildBone(newBoneName) },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioCoral)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add bone", modifier = Modifier.size(18.dp))
                    }
                }
            }

            item {
                val zOrdersAtFrame = remember(rig, uiState.currentFrame) {
                    InterpolationEngine.evaluateBoneZOrders(rig, uiState.currentFrame)
                }
                val hasZKeyHere = rig.boneZOrderKeyframes.containsKey(uiState.currentFrame.toString())
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Part Layers / Z-Order (Front → Back • F${uiState.currentFrame + 1})",
                            style = MaterialTheme.typography.titleSmall,
                            color = StudioCyan
                        )
                        Text(
                            if (hasZKeyHere) "Z-Order Keyframed on F${uiState.currentFrame + 1}" else "Tap +1 / -1 on any limb to keyframe Front/Back switch",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (hasZKeyHere) StudioAmber else StudioTextMuted
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (hasZKeyHere) {
                            OutlinedButton(
                                onClick = onClearZOrderKeyframe,
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("inspector_clear_z_keyframe_btn")
                            ) {
                                Text("Clear Z-Key", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                            }
                        }
                        OutlinedButton(onClick = onSaveRigTemplate) {
                            Text("Save Rig", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    onClick = onApplyAutoHumanLayerOrder,
                    modifier = Modifier.fillMaxWidth().testTag("inspector_auto_human_zorder_btn")
                ) {
                    Icon(Icons.Rounded.Layers, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Auto Human Layer Order (Natural Back → Front)", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }
            }

            val zOrdersNow = InterpolationEngine.evaluateBoneZOrders(rig, uiState.currentFrame)
            val frontToBackBones = rig.bones.withIndex()
                .sortedWith(compareByDescending<IndexedValue<RigBone>> { zOrdersNow[it.value.id] ?: it.value.zOrder }.thenByDescending { it.index })
                .map { it.value }

            items(frontToBackBones, key = { it.id }) { bone ->
                val isSel = uiState.selectedBoneId == bone.id
                val curZ = zOrdersNow[bone.id] ?: bone.zOrder
                Surface(
                    color = if (isSel) StudioSurfaceElevated else StudioSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (isSel) StudioCoral else StudioBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectBone(bone.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(bone.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                            Text(
                                text = "Z:$curZ • Parent: ${bone.parentId ?: "Root"} • ${bone.length.toInt()}px",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            IconButton(
                                onClick = { onAdjustBoneZOrder(bone.id, BoneZOrderAction.BRING_FORWARD) },
                                modifier = Modifier.size(28.dp).testTag("stage_bone_z_up_${bone.id}")
                            ) {
                                Icon(Icons.Rounded.ArrowUpward, contentDescription = "Bring forward +1", tint = StudioCyan, modifier = Modifier.size(15.dp))
                            }
                            IconButton(
                                onClick = { onAdjustBoneZOrder(bone.id, BoneZOrderAction.SEND_BACKWARD) },
                                modifier = Modifier.size(28.dp).testTag("stage_bone_z_down_${bone.id}")
                            ) {
                                Icon(Icons.Rounded.ArrowDownward, contentDescription = "Send backward -1", tint = StudioAmber, modifier = Modifier.size(15.dp))
                            }
                            if (bone.isExtraRigBone) {
                                IconButton(
                                    onClick = { onDeleteBone(bone.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete extra bone", tint = StudioRose, modifier = Modifier.size(15.dp))
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .size(11.dp)
                                    .clip(CircleShape)
                                    .background(Color(bone.colorArgb))
                            )
                        }
                    }
                }
            }

            // Modules 2 & 9 + Keyframeable Z-Order + Per-Bone Part Behavior Presets
            item {
                val selBone = rig.bones.firstOrNull { it.id == uiState.selectedBoneId }
                if (selBone != null) {
                    val selZ = InterpolationEngine.evaluateBoneZOrders(rig, uiState.currentFrame)[selBone.id] ?: selBone.zOrder
                    HorizontalDivider(color = StudioBorder)
                    Spacer(Modifier.height(6.dp))
                    Text("Selected Bone: ${selBone.name} (Z:$selZ • F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                    Spacer(Modifier.height(4.dp))
                    // Module 7 & 11: Per-Bone Lock + Detach / Sever Bone (Horror / Action Gravity Fall)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selBone.locked,
                            onClick = { onToggleBoneLock(selBone.id) },
                            label = { Text(if (selBone.locked) "Bone Locked" else "Lock Bone", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("stage_bone_lock_chip")
                        )
                        val isDetached = InterpolationEngine.evaluateDetachedBones(rig, uiState.currentFrame).containsKey(selBone.id)
                        FilterChip(
                            selected = isDetached,
                            onClick = { onToggleDetachBone(selBone.id, true) },
                            label = { Text(if (isDetached) "Reattach Bone" else "Detach / Sever (Gravity)", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("stage_detach_bone_chip")
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onAdjustBoneZOrder(selBone.id, BoneZOrderAction.BRING_TO_FRONT) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f).testTag("inspector_z_front_btn")
                        ) {
                            Icon(Icons.Rounded.VerticalAlignTop, contentDescription = "Bring to Front", tint = StudioCyan, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("Front", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                        }
                        OutlinedButton(
                            onClick = { onAdjustBoneZOrder(selBone.id, BoneZOrderAction.BRING_FORWARD) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f).testTag("inspector_z_fwd_btn")
                        ) {
                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Bring Forward +1", tint = StudioEmerald, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("+1", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                        }
                        OutlinedButton(
                            onClick = { onAdjustBoneZOrder(selBone.id, BoneZOrderAction.SEND_BACKWARD) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f).testTag("inspector_z_back1_btn")
                        ) {
                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Send Backward -1", tint = StudioAmber, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("-1", style = MaterialTheme.typography.labelSmall, color = StudioAmber)
                        }
                        OutlinedButton(
                            onClick = { onAdjustBoneZOrder(selBone.id, BoneZOrderAction.SEND_TO_BACK) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f).testTag("inspector_z_bottom_btn")
                        ) {
                            Icon(Icons.Rounded.VerticalAlignBottom, contentDescription = "Send to Back", tint = StudioCoral, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("Back", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val curPartPreset = runCatching { PartBehaviorPreset.valueOf(selBone.partBehaviorPreset) }
                        .getOrDefault(PartBehaviorPreset.RIGID)
                    Text("Part Behavior Preset: ${curPartPreset.label} (${curPartPreset.subtitle})", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PartBehaviorPreset.entries.forEach { preset ->
                            FilterChip(
                                selected = selBone.partBehaviorPreset == preset.name,
                                onClick = { onApplyBonePartBehavior(selBone.id, preset) },
                                label = { Text(preset.label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("inspector_part_behavior_${preset.name.lowercase()}")
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Length ${selBone.length.toInt()}px", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(96.dp))
                        Slider(
                            value = selBone.length.coerceIn(12f, 360f),
                            onValueChange = { onUpdateBoneScaleAndSpring(selBone.id, it, null, null, null, null) },
                            valueRange = 12f..360f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Limb W ${String.format("%.2fx", selBone.limbWidthScale)}", style = MaterialTheme.typography.labelSmall, color = StudioViolet, modifier = Modifier.width(96.dp))
                        Slider(
                            value = selBone.limbWidthScale.coerceIn(0.25f, 3.5f),
                            onValueChange = { onUpdateBoneScaleAndSpring(selBone.id, null, it, null, null, null) },
                            valueRange = 0.25f..3.5f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Limb L ${String.format("%.2fx", selBone.limbLengthScale)}", style = MaterialTheme.typography.labelSmall, color = StudioCyan, modifier = Modifier.width(96.dp))
                        Slider(
                            value = selBone.limbLengthScale.coerceIn(0.25f, 3.5f),
                            onValueChange = { onUpdateBoneScaleAndSpring(selBone.id, null, null, it, null, null) },
                            valueRange = 0.25f..3.5f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Spring ${(selBone.springStiffness * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioEmerald, modifier = Modifier.width(96.dp))
                        Slider(
                            value = selBone.springStiffness.coerceIn(0f, 1f),
                            onValueChange = { onUpdateBoneScaleAndSpring(selBone.id, null, null, null, it, null) },
                            valueRange = 0f..1f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Damping ${(selBone.springDamping * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(96.dp))
                        Slider(
                            value = selBone.springDamping.coerceIn(0.05f, 1f),
                            onValueChange = { onUpdateBoneScaleAndSpring(selBone.id, null, null, null, null, it) },
                            valueRange = 0.05f..1f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Module 9: Same-Track Character Form Morph, Smooth Opacity Fade & Instant Hide (works on ANY layer!)
        item {
            val layer = uiState.selectedLayer
            if (layer != null) {
                val evalT = InterpolationEngine.evaluateLayerTransform(layer, uiState.currentFrame, uiState.activeScene?.durationFrames ?: 24)
                val isVisNow = InterpolationEngine.isLayerVisibleAtFrame(layer, uiState.currentFrame)
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioViolet.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("form_morph_and_fade_card")
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("FORM MORPH, OPACITY FADE & INSTANT HIDE (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.labelMedium, color = StudioViolet, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            ProceduralSmartTools.characterPresets.take(4).forEachIndexed { i, spec ->
                                FilterChip(
                                    selected = false,
                                    onClick = { onAddFormMorph(spec.name, spec, if (i % 2 == 0) "FLASH" else "SMOKE") },
                                    label = { Text("Morph → ${spec.name}", style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Opacity ${(evalT.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioCyan, modifier = Modifier.width(90.dp))
                            Slider(
                                value = evalT.opacity.coerceIn(0f, 1f),
                                onValueChange = { onSetLayerOpacityKf(it) },
                                valueRange = 0f..1f,
                                modifier = Modifier.weight(1f).testTag("layer_opacity_fade_slider")
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = isVisNow,
                                onClick = { onToggleInstantVisibilityKf(true) },
                                label = { Text("Instant Show", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("instant_show_kf_btn")
                            )
                            FilterChip(
                                selected = !isVisNow,
                                onClick = { onToggleInstantVisibilityKf(false) },
                                label = { Text("Instant Hide (0f)", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("instant_hide_kf_btn")
                            )
                        }
                    }
                }
            }
        }

        // Module 11: Keyframeable Camera Shake & Action Impact Flash FX
        item {
            val scene = uiState.activeScene
            if (scene != null) {
                val cam = InterpolationEngine.evaluateCamera(scene, uiState.currentFrame)
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("camera_shake_flash_card")
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("CAMERA SHAKE & ACTION IMPACT FLASH (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.labelMedium, color = StudioCoral, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Shake ${cam.shakeIntensity.toInt()}px", style = MaterialTheme.typography.labelSmall, color = StudioAmber, modifier = Modifier.width(86.dp))
                            Slider(
                                value = cam.shakeIntensity.coerceIn(0f, 30f),
                                onValueChange = { onSetCameraShakeFlash(it, null, null) },
                                valueRange = 0f..30f,
                                modifier = Modifier.weight(1f).testTag("camera_shake_slider")
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onSetCameraShakeFlash(16f, 0.72f, 0xFFFFFFFFL) }, modifier = Modifier.weight(1f)) {
                                Text("Impact Flash", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                            }
                            OutlinedButton(onClick = { onSetCameraShakeFlash(22f, 0.65f, 0xFFFF1744L) }, modifier = Modifier.weight(1f)) {
                                Text("Horror Flash", style = MaterialTheme.typography.labelSmall, color = StudioRose)
                            }
                            OutlinedButton(onClick = { onSetCameraShakeFlash(0f, 0f, 0xFFFFFFFFL) }) {
                                Text("Clear", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDeleteActionClip?.let { clip ->
        AlertDialog(
            onDismissRequest = { pendingDeleteActionClip = null },
            containerColor = StudioSurfaceElevated,
            title = { Text("Delete Custom Action?", color = StudioTextPrimary) },
            text = { Text("Permanently remove \"${clip.name}\" from your Custom Action Library?", color = StudioTextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCustomAction(clip.id)
                        pendingDeleteActionClip = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRose)
                ) { Text("Delete", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteActionClip = null }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OptionRow(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            options.forEach { opt ->
                FilterChip(
                    selected = selected == opt,
                    onClick = { onSelect(opt) },
                    label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                )
            }
        }
    }
}

@Composable
fun FacialTimingIntervalCard(
    timing: FacialTimingConfig,
    fps: Int,
    onUpdateTiming: ((FacialTimingConfig) -> FacialTimingConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val safeFps = fps.coerceIn(1, 120)
    val useSec = timing.useSecondsUnit
    val resolvedLipFrames = AudioStudioEngine.resolveLipSyncIntervalFrames(timing, safeFps)
    val resolvedBlinkFrames = AudioStudioEngine.resolveBlinkIntervalFrames(timing, safeFps)
    val resolvedBlinkDurFrames = AudioStudioEngine.resolveBlinkDurationFrames(timing, safeFps)
    val resolvedEmotionFrames = AudioStudioEngine.resolveEmotionCycleFrames(timing, safeFps)

    Surface(
        color = StudioSurfaceVariant,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.5f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("facial_timing_interval_card")
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Timer, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(16.dp))
                    Text(
                        "Lip-Sync, Blink & Emotion Speed",
                        style = MaterialTheme.typography.titleSmall,
                        color = StudioAmber,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(
                    onClick = { onUpdateTiming { FacialTimingConfig(useSecondsUnit = it.useSecondsUnit) } },
                    modifier = Modifier.size(30.dp).testTag("facial_timing_reset_btn")
                ) {
                    Icon(Icons.Rounded.RestartAlt, contentDescription = "Reset Facial Timing", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                }
            }

            // Unit Switcher: Frames vs Seconds
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Interval Unit ($safeFps fps)",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    FilterChip(
                        selected = !useSec,
                        onClick = { onUpdateTiming { it.copy(useSecondsUnit = false) } },
                        label = { Text("Frames", style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("facial_timing_unit_frames")
                    )
                    FilterChip(
                        selected = useSec,
                        onClick = { onUpdateTiming { it.copy(useSecondsUnit = true) } },
                        label = { Text("Seconds", style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("facial_timing_unit_seconds")
                    )
                }
            }

            // 1. Lip-Sync Change Interval
            val lipDisplay = if (useSec) {
                "${String.format("%.2fs", timing.lipSyncIntervalSec)} (${resolvedLipFrames}f)"
            } else {
                "${timing.lipSyncIntervalFrames}f (${String.format("%.2fs", timing.lipSyncIntervalFrames.toFloat() / safeFps)})"
            }
            Text(
                "Lip-Sync Change Interval: $lipDisplay",
                style = MaterialTheme.typography.labelSmall,
                color = StudioCoral,
                fontWeight = FontWeight.SemiBold
            )
            if (useSec) {
                Slider(
                    value = timing.lipSyncIntervalSec.coerceIn(0.05f, 10.0f),
                    onValueChange = { s -> onUpdateTiming { it.copy(lipSyncIntervalSec = s) } },
                    valueRange = 0.05f..10.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                    modifier = Modifier.testTag("lip_sync_interval_slider")
                )
            } else {
                Slider(
                    value = timing.lipSyncIntervalFrames.coerceIn(1, 120).toFloat(),
                    onValueChange = { f -> onUpdateTiming { it.copy(lipSyncIntervalFrames = f.toInt().coerceIn(1, 120)) } },
                    valueRange = 1f..120f,
                    colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                    modifier = Modifier.testTag("lip_sync_interval_slider")
                )
            }

            // 2. Auto-Blink Interval
            val blinkDisplay = if (useSec) {
                "${String.format("%.2fs", timing.blinkIntervalSec)} (${resolvedBlinkFrames}f)"
            } else {
                "${timing.blinkIntervalFrames}f (${String.format("%.2fs", timing.blinkIntervalFrames.toFloat() / safeFps)})"
            }
            Text(
                "Auto-Blink Interval: $blinkDisplay",
                style = MaterialTheme.typography.labelSmall,
                color = StudioCyan,
                fontWeight = FontWeight.SemiBold
            )
            if (useSec) {
                Slider(
                    value = timing.blinkIntervalSec.coerceIn(0.15f, 10.0f),
                    onValueChange = { s -> onUpdateTiming { it.copy(blinkIntervalSec = s) } },
                    valueRange = 0.15f..10.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                    modifier = Modifier.testTag("blink_interval_slider")
                )
            } else {
                Slider(
                    value = timing.blinkIntervalFrames.coerceIn(1, 120).toFloat(),
                    onValueChange = { f -> onUpdateTiming { it.copy(blinkIntervalFrames = f.toInt().coerceIn(1, 120)) } },
                    valueRange = 1f..120f,
                    colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                    modifier = Modifier.testTag("blink_interval_slider")
                )
            }

            // 3. Auto-Blink Hold Duration
            val blinkDurDisplay = if (useSec) {
                "${String.format("%.2fs", timing.blinkDurationSec)} (${resolvedBlinkDurFrames}f)"
            } else {
                "${timing.blinkDurationFrames}f (${String.format("%.2fs", timing.blinkDurationFrames.toFloat() / safeFps)})"
            }
            Text(
                "Blink Closed Duration: $blinkDurDisplay",
                style = MaterialTheme.typography.labelSmall,
                color = StudioEmerald,
                fontWeight = FontWeight.SemiBold
            )
            if (useSec) {
                Slider(
                    value = timing.blinkDurationSec.coerceIn(0.05f, 1.5f),
                    onValueChange = { s -> onUpdateTiming { it.copy(blinkDurationSec = s) } },
                    valueRange = 0.05f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = StudioEmerald, activeTrackColor = StudioEmerald),
                    modifier = Modifier.testTag("blink_duration_slider")
                )
            } else {
                Slider(
                    value = timing.blinkDurationFrames.coerceIn(1, 24).toFloat(),
                    onValueChange = { f -> onUpdateTiming { it.copy(blinkDurationFrames = f.toInt().coerceIn(1, 24)) } },
                    valueRange = 1f..24f,
                    colors = SliderDefaults.colors(thumbColor = StudioEmerald, activeTrackColor = StudioEmerald),
                    modifier = Modifier.testTag("blink_duration_slider")
                )
            }

            // 4. Emotion Loop Speed (Crying Tears / Laughing Bounce Cycle)
            val emoDisplay = if (useSec) {
                "${String.format("%.2fs", timing.emotionLoopSpeedSec)} (${resolvedEmotionFrames}f)"
            } else {
                "${timing.emotionLoopSpeedFrames}f (${String.format("%.2fs", timing.emotionLoopSpeedFrames.toFloat() / safeFps)})"
            }
            Text(
                "Emotion Loop Speed (Cry / Laugh): $emoDisplay",
                style = MaterialTheme.typography.labelSmall,
                color = StudioViolet,
                fontWeight = FontWeight.SemiBold
            )
            if (useSec) {
                Slider(
                    value = timing.emotionLoopSpeedSec.coerceIn(0.05f, 10.0f),
                    onValueChange = { s -> onUpdateTiming { it.copy(emotionLoopSpeedSec = s) } },
                    valueRange = 0.05f..10.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet),
                    modifier = Modifier.testTag("emotion_loop_speed_slider")
                )
            } else {
                Slider(
                    value = timing.emotionLoopSpeedFrames.coerceIn(1, 120).toFloat(),
                    onValueChange = { f -> onUpdateTiming { it.copy(emotionLoopSpeedFrames = f.toInt().coerceIn(1, 120)) } },
                    valueRange = 1f..120f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet),
                    modifier = Modifier.testTag("emotion_loop_speed_slider")
                )
            }
        }
    }
}

@Composable
private fun ColorRow(label: String, colors: List<Long>, selected: Long, onSelect: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.forEach { argb ->
                val isSel = selected == argb
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .border(if (isSel) 2.5.dp else 1.dp, if (isSel) StudioViolet else StudioBorder, CircleShape)
                        .clickable { onSelect(argb) }
                )
            }
        }
    }
}
