package com.example.engine

import android.graphics.RectF
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.EyePackStyle
import com.example.data.model.HandPropKind
import com.example.data.model.MeshPinLink
import com.example.data.model.MouthPhoneme
import com.example.data.model.PartBehaviorPreset
import com.example.data.model.RigBone
import com.example.data.model.RigViewAngleConfig
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import java.util.UUID
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class RigAttachmentArea(
    val label: String,
    val shortLabel: String,
    val candidateBoneIds: List<String>,
    val defaultAngleDeg: Float
) {
    RIGHT_HAND("Right Hand", "R-Hand", listOf("hand_r", "arm_r_low", "arm_r_up"), -35f),
    LEFT_HAND("Left Hand", "L-Hand", listOf("hand_l", "arm_l_low", "arm_l_up"), 35f),
    RIGHT_LEG("Right Leg / Foot", "R-Leg", listOf("foot_r", "leg_r_low", "leg_r_up"), 15f),
    LEFT_LEG("Left Leg / Foot", "L-Leg", listOf("foot_l", "leg_l_low", "leg_l_up"), -15f),
    HEAD("Head / Hat / Hair", "Head", listOf("neck"), -15f),
    CHEST_BACK("Chest / Wings / Cape", "Chest", listOf("spine"), 145f),
    HIP_WAIST("Hip / Tail / Waist", "Hip", emptyList(), 155f),
    SELECTED_BONE("Selected Bone", "Selected", emptyList(), 25f)
}

enum class BoneZOrderAction {
    BRING_FORWARD,
    SEND_BACKWARD,
    BRING_TO_FRONT,
    SEND_TO_BACK
}

data class SolvedBone(
    val bone: RigBone,
    val start: Vec2,
    val end: Vec2,
    val worldAngleDeg: Float
)

data class EvaluatedDetachedBone(
    val boneId: String,
    val worldX: Float,
    val worldY: Float,
    val worldAngleDeg: Float
)

object RigSolver {

    /**
     * Computes Forward Kinematics (FK) world coordinates for every bone in the rig,
     * honoring animated root position, independent X/Y squash-stretch scale, bone-length overrides,
     * individual limb length scales, per-bone spring physics sway, detached/severed bones, and horizontal mirroring.
     */
    fun solveForwardKinematics(
        rig: SkeletalRig,
        angleOverrides: Map<String, Float> = emptyMap(),
        rootX: Float = rig.rootX,
        rootY: Float = rig.rootY,
        scale: Float = rig.scale,
        flippedHorizontal: Boolean = rig.flippedHorizontal,
        lengthOverrides: Map<String, Float> = emptyMap(),
        scaleX: Float = rig.scaleX,
        scaleY: Float = rig.scaleY,
        frame: Int = 0,
        detachedBones: Map<String, EvaluatedDetachedBone> = emptyMap(),
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT
    ): List<SolvedBone> {
        val boneMap = rig.bones.associateBy { it.id }
        val solved = LinkedHashMap<String, SolvedBone>()
        // Track pure unflipped world angles separately so horizontal mirroring (Front-L 3/4, Left Side)
        // NEVER double-mirrors child bones (shoulders/arms/hips/legs stay cleanly mirrored around rootX!).
        val unflippedWorldAngles = HashMap<String, Float>()
        val safeScale = if (scale.isFinite()) scale.coerceIn(0.05f, 10f) else 1f
        val safeSx = if (scaleX.isFinite()) scaleX.coerceIn(0.15f, 6f) else 1f
        val safeSy = if (scaleY.isFinite()) scaleY.coerceIn(0.15f, 6f) else 1f
        val safeRootX = if (rootX.isFinite()) rootX else 640f
        val safeRootY = if (rootY.isFinite()) rootY else 390f
        val isSideView = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isThreeQuarterView = viewAngle == CharacterViewAngle.FRONT_LEFT_34 ||
            viewAngle == CharacterViewAngle.FRONT_RIGHT_34 ||
            viewAngle == CharacterViewAngle.BACK_LEFT_34 ||
            viewAngle == CharacterViewAngle.BACK_RIGHT_34

        fun resolve(bone: RigBone): SolvedBone {
            solved[bone.id]?.let { return it }
            val fixedCore = isBoneStructurallyFixed(rig, bone)
            // In true Side view, point BOTH feet in the facing direction (+X unflipped / -X when flipped)
            // whenever the foot is at its default Front rest angle (still honors explicit manual ankle poses).
            val isSideFootDefault = isSideView && (bone.id == "foot_l" || bone.id == "foot_r")
            val defaultLocalAngle = if (isSideFootDefault) {
                -kotlin.math.abs(bone.localAngleDeg)
            } else {
                bone.localAngleDeg
            }
            val overrideVal = angleOverrides[bone.id]
            val rawLocal = when {
                fixedCore -> defaultLocalAngle
                overrideVal == null -> defaultLocalAngle
                isSideFootDefault && kotlin.math.abs(overrideVal - bone.localAngleDeg) < 0.5f -> defaultLocalAngle
                else -> overrideVal
            }
            val safeLocal = if (rawLocal.isFinite()) rawLocal else defaultLocalAngle
            // Secondary physics spring/sway for hair, tails, dupattas, capes, or any spring-enabled bone
            val springSway = if (bone.springStiffness > 0.01f && !fixedCore && !isBoneLocked(rig, bone)) {
                val freq = 0.24 + bone.springStiffness.coerceIn(0f, 1f) * 0.36
                val amp = (1f - bone.springDamping.coerceIn(0.1f, 0.96f)) * 22f * bone.springStiffness.coerceIn(0f, 1f)
                (sin(frame * freq + (bone.id.hashCode() and 0xFF) * 0.17) * amp).toFloat()
            } else 0f

            val detached = detachedBones[bone.id]
            val start: Vec2
            val unflippedWorldDeg: Float
            val flipSign = if (flippedHorizontal && detached == null) -1f else 1f
            val baseOffX = bone.basePivotOffsetX * safeScale * safeSx * flipSign
            val baseOffY = bone.basePivotOffsetY * safeScale * safeSy
            if (detached != null) {
                start = Vec2(detached.worldX, detached.worldY)
                unflippedWorldDeg = detached.worldAngleDeg + springSway
            } else {
                val parentSolved = bone.parentId?.let { pid -> boneMap[pid]?.let { resolve(it) } }
                val parentUnflippedAngle = bone.parentId?.let { pid -> unflippedWorldAngles[pid] } ?: 0f
                val rawAnchor = parentSolved?.end ?: Vec2(safeRootX, safeRootY)
                start = Vec2(rawAnchor.x + baseOffX, rawAnchor.y + baseOffY)
                unflippedWorldDeg = parentUnflippedAngle + safeLocal + springSway
            }
            unflippedWorldAngles[bone.id] = unflippedWorldDeg

            val rad = Math.toRadians(unflippedWorldDeg.toDouble())
            val allowStretch = bone.allowLengthStretch && bone.id != "neck"
            val rawLen = if (allowStretch) {
                lengthOverrides[bone.id] ?: (bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f))
            } else {
                bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f)
            }
            // True Full-Body Side & 3/4 perspective foreshortening for shoulder/hip sockets
            val viewLengthScale = when {
                isSideView && (bone.id == "shoulder_l" || bone.id == "shoulder_r") -> 0.16f
                isSideView && (bone.id == "hip_l" || bone.id == "hip_r") -> 0.18f
                isThreeQuarterView && bone.id == "shoulder_l" -> 0.58f
                isThreeQuarterView && bone.id == "shoulder_r" -> 0.88f
                isThreeQuarterView && bone.id == "hip_l" -> 0.62f
                isThreeQuarterView && bone.id == "hip_r" -> 0.90f
                else -> 1.0f
            }
            val scaledRawLen = rawLen * viewLengthScale
            val minSafeLen = if (viewLengthScale < 0.5f) 2f else 6f
            val effectiveLen = if (scaledRawLen.isFinite()) scaledRawLen.coerceIn(minSafeLen, 450f) else bone.length.coerceAtLeast(10f)
            val dx = (cos(rad) * effectiveLen * safeScale * safeSx).toFloat() * flipSign
            val dy = (sin(rad) * effectiveLen * safeScale * safeSy).toFloat()
            val end = Vec2(
                if (dx.isFinite()) start.x + dx else start.x,
                if (dy.isFinite()) start.y + dy else start.y
            )
            val displayAngle = if (dx == 0f && dy == 0f) unflippedWorldDeg else Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            val finalAngle = if (displayAngle.isFinite()) (if (flippedHorizontal && detached == null) displayAngle else unflippedWorldDeg) else 0f
            val result = SolvedBone(bone, start, end, finalAngle)
            solved[bone.id] = result
            return result
        }

        rig.bones.forEach { resolve(it) }
        return rig.bones.mapNotNull { solved[it.id] }
    }

    val STRUCTURAL_CORE_BONE_IDS: Set<String> = setOf(
        "pelvis", "waist", "spine", "shoulder_l", "shoulder_r", "hip_l", "hip_r"
    )

    /**
     * Returns true when [bone] is a structurally fixed core bone (Pelvis, Waist, Chest,
     * Shoulder L/R, Hip L/R) and the user has not explicitly enabled `Unlock Core` on [rig].
     */
    fun isBoneStructurallyFixed(rig: SkeletalRig, bone: RigBone): Boolean {
        if (rig.unlockCoreBones) return false
        return bone.isStructuralFixed || bone.id in STRUCTURAL_CORE_BONE_IDS
    }

    /**
     * Returns true when [bone] is explicitly locked by the user via either `bone.locked` or `rig.lockedBoneIds`.
     * Locked bones cannot be rotated, dragged, stretched, or overwritten by Auto-Walk.
     */
    fun isBoneLocked(rig: SkeletalRig, bone: RigBone): Boolean {
        return bone.locked || bone.id in rig.lockedBoneIds
    }

    /**
     * Strict Hierarchical Forward Kinematics (FK) single-bone rotation for the Prisma 3D-style
     * circular rotation ring:
     * - Modifies ONLY [boneId]'s localAngle (`localAngle += deltaAngleDeg`, unrestricted `-720°..+720°`).
     * - Parent bones remain 100% stationary.
     * - Child bones keep their own localAngles completely unchanged (`delta = 0`) and swing rigidly
     *   with the rotating parent bone via [solveForwardKinematics].
     */
    fun rotateBoneLocalAngleFk(
        rig: SkeletalRig,
        boneId: String,
        currentAngles: Map<String, Float>,
        deltaAngleDeg: Float
    ): Map<String, Float> {
        if (!deltaAngleDeg.isFinite()) return currentAngles
        val bone = rig.bones.firstOrNull { it.id == boneId } ?: return currentAngles
        if (isBoneLocked(rig, bone) || isBoneStructurallyFixed(rig, bone)) return currentAngles
        val prevLocal = currentAngles[boneId] ?: bone.localAngleDeg
        val nextLocal = (prevLocal + deltaAngleDeg).coerceIn(-720f, 720f)
        if (!nextLocal.isFinite()) return currentAngles
        return currentAngles + (boneId to nextLocal)
    }

    /**
     * Solves 2-bone analytical Inverse Kinematics (IK) with strict NaN & zero-division guards:
     * target distance is strictly clamped to [abs(L1 - L2) + 0.01f, L1 + L2 - 0.01f] and all
     * acos/atan2 calls are validated so limbs NEVER vanish when stretched.
     */
    fun solveDragTarget(
        rig: SkeletalRig,
        boneId: String,
        target: Vec2,
        currentAngles: Map<String, Float>,
        useIk: Boolean,
        rootX: Float = rig.rootX,
        rootY: Float = rig.rootY,
        scale: Float = rig.scale,
        flippedHorizontal: Boolean = rig.flippedHorizontal,
        lengthOverrides: Map<String, Float> = emptyMap(),
        scaleX: Float = rig.scaleX,
        scaleY: Float = rig.scaleY,
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT
    ): Map<String, Float> {
        if (!target.x.isFinite() || !target.y.isFinite()) return currentAngles
        val safeScale = if (scale.isFinite()) scale.coerceIn(0.05f, 10f) else 1f
        val safeSx = if (scaleX.isFinite()) scaleX.coerceIn(0.15f, 6f) else 1f
        val safeSy = if (scaleY.isFinite()) scaleY.coerceIn(0.15f, 6f) else 1f
        val avgAxisScale = ((safeSx + safeSy) * 0.5f).coerceAtLeast(0.15f)

        // Mirror target into unflipped local puppet coordinate space so math stays clean
        val localTarget = if (flippedHorizontal) {
            Vec2(rootX - (target.x - rootX), target.y)
        } else {
            target
        }

        // If user drags an extremity bone (hand_l/hand_r/foot_l/foot_r) with IK enabled,
        // redirect 2-bone IK cleanly to the forearm/shin chain so pulling the hand pulls the whole arm naturally!
        val effectiveBoneId = if (useIk) {
            when (boneId) {
                "hand_l" -> if (rig.bones.any { it.id == "arm_l_low" }) "arm_l_low" else boneId
                "hand_r" -> if (rig.bones.any { it.id == "arm_r_low" }) "arm_r_low" else boneId
                "foot_l" -> if (rig.bones.any { it.id == "leg_l_low" }) "leg_l_low" else boneId
                "foot_r" -> if (rig.bones.any { it.id == "leg_r_low" }) "leg_r_low" else boneId
                else -> boneId
            }
        } else boneId

        val solvedList = solveForwardKinematics(
            rig = rig,
            angleOverrides = currentAngles,
            rootX = rootX,
            rootY = rootY,
            scale = safeScale,
            flippedHorizontal = false,
            lengthOverrides = lengthOverrides,
            scaleX = safeSx,
            scaleY = safeSy,
            viewAngle = viewAngle
        )
        val solvedMap = solvedList.associateBy { it.bone.id }
        val targetSolved = solvedMap[effectiveBoneId] ?: return currentAngles
        val bone = targetSolved.bone
        if (isBoneLocked(rig, bone) || isBoneStructurallyFixed(rig, bone)) return currentAngles
        val parentSolved = bone.parentId?.let { solvedMap[it] }

        // 1-bone FK aim with continuous 360-degree unwrapped angle tracking (zero ±180° wrap-around locking!)
        if (!useIk || parentSolved == null || parentSolved.bone.parentId == null || parentSolved.bone.locked) {
            val dx = localTarget.x - targetSolved.start.x
            val dy = localTarget.y - targetSolved.start.y
            if (hypot(dx, dy) < 0.001f) return currentAngles
            val desiredWorld = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            if (!desiredWorld.isFinite()) return currentAngles
            val parentWorld = parentSolved?.worldAngleDeg ?: 0f
            val prevLocal = currentAngles[bone.id] ?: bone.localAngleDeg
            val continuous = unwrapAngleNear(desiredWorld - parentWorld, prevLocal)
                .coerceIn(-720f, 720f)
            return if (continuous.isFinite()) currentAngles + (bone.id to continuous) else currentAngles
        }

        // 2-bone analytical IK on (parentBone -> bone) with strict NaN, triangle-inequality & continuous unwrap guards
        val grandParentWorld = parentSolved.bone.parentId?.let { solvedMap[it]?.worldAngleDeg } ?: 0f
        val rootPos = parentSolved.start
        val rawL1 = (lengthOverrides[parentSolved.bone.id] ?: (parentSolved.bone.length * parentSolved.bone.limbLengthScale)) * safeScale * avgAxisScale
        val rawL2 = (lengthOverrides[bone.id] ?: (bone.length * bone.limbLengthScale)) * safeScale * avgAxisScale
        val l1 = if (rawL1.isFinite()) rawL1.coerceAtLeast(1f) else 10f
        val l2 = if (rawL2.isFinite()) rawL2.coerceAtLeast(1f) else 10f

        val dx = localTarget.x - rootPos.x
        val dy = localTarget.y - rootPos.y
        val rawDist = hypot(dx, dy)
        if (!rawDist.isFinite() || rawDist < 0.0001f) return currentAngles

        val minReach = kotlin.math.abs(l1 - l2) + 0.01f
        val maxReach = (l1 + l2 - 0.01f).coerceAtLeast(minReach + 0.01f)
        val dist = rawDist.coerceIn(minReach, maxReach)

        val baseAngle = atan2(dy.toDouble(), dx.toDouble())
        val denomA = (2.0 * l1 * dist).coerceAtLeast(1e-5)
        val denomB = (2.0 * l1 * l2).coerceAtLeast(1e-5)
        val cosA = ((l1.toDouble() * l1 + dist.toDouble() * dist - l2.toDouble() * l2) / denomA).coerceIn(-1.0, 1.0)
        val cosB = ((l1.toDouble() * l1 + l2.toDouble() * l2 - dist.toDouble() * dist) / denomB).coerceIn(-1.0, 1.0)
        val angleA = acos(cosA)
        val angleB = acos(cosB)
        if (!baseAngle.isFinite() || !angleA.isFinite() || !angleB.isFinite()) return currentAngles

        val prevParentLocal = currentAngles[parentSolved.bone.id] ?: parentSolved.bone.localAngleDeg
        val prevChildLocal = currentAngles[bone.id] ?: bone.localAngleDeg
        // Zero forced bend-direction lock: evaluate both elbow/knee solutions and choose the closest continuous one
        val candPosParent = unwrapAngleNear(Math.toDegrees(baseAngle - angleA).toFloat() - grandParentWorld, prevParentLocal)
        val candPosChild = unwrapAngleNear(Math.toDegrees(PI - angleB).toFloat(), prevChildLocal)
        val candNegParent = unwrapAngleNear(Math.toDegrees(baseAngle + angleA).toFloat() - grandParentWorld, prevParentLocal)
        val candNegChild = unwrapAngleNear(Math.toDegrees(-(PI - angleB)).toFloat(), prevChildLocal)
        val distPos = kotlin.math.abs(candPosParent - prevParentLocal) + kotlin.math.abs(candPosChild - prevChildLocal)
        val distNeg = kotlin.math.abs(candNegParent - prevParentLocal) + kotlin.math.abs(candNegChild - prevChildLocal)
        val (rawParent, rawChild) = if (distPos <= distNeg) (candPosParent to candPosChild) else (candNegParent to candNegChild)
        val localParent = rawParent.coerceIn(-720f, 720f)
        val localChild = rawChild.coerceIn(-720f, 720f)

        if (!localParent.isFinite() || !localChild.isFinite()) return currentAngles
        return currentAngles + mapOf(
            parentSolved.bone.id to localParent,
            bone.id to localChild
        )
    }

    /**
     * Master Upgrade Module 1: Rig Position Mode — moves a joint's exact anatomical base pivot
     * directly onto the artwork (unless [SkeletalRig.baseRigPositionLocked] is true).
     */
    fun repositionBoneJointPivot(
        rig: SkeletalRig,
        boneId: String,
        targetWorldPos: Vec2
    ): SkeletalRig {
        if (rig.baseRigPositionLocked || !targetWorldPos.x.isFinite() || !targetWorldPos.y.isFinite()) return rig
        val safeScale = rig.scale.coerceIn(0.05f, 10f)
        val safeSx = rig.scaleX.coerceIn(0.15f, 6f)
        val safeSy = rig.scaleY.coerceIn(0.15f, 6f)
        val flipSign = if (rig.flippedHorizontal) -1f else 1f
        val fkMap = solveForwardKinematics(rig).associateBy { it.bone.id }
        val targetBone = rig.bones.firstOrNull { it.id == boneId } ?: return rig
        val parentEnd = targetBone.parentId?.let { fkMap[it]?.end } ?: Vec2(rig.rootX, rig.rootY)
        val newOffX = ((targetWorldPos.x - parentEnd.x) / (safeScale * safeSx * flipSign)).coerceIn(-400f, 400f)
        val newOffY = ((targetWorldPos.y - parentEnd.y) / (safeScale * safeSy)).coerceIn(-400f, 400f)
        return rig.copy(
            bones = rig.bones.map { b ->
                if (b.id == boneId) b.copy(basePivotOffsetX = newOffX, basePivotOffsetY = newOffY) else b
            }
        )
    }

    /**
     * Nudges a bone's base pivot offset by exact pixel deltas (e.g. 1px micro-nudge in Rig Position Mode).
     */
    fun nudgeBoneJointPivot(
        rig: SkeletalRig,
        boneId: String,
        dxPx: Float,
        dyPx: Float
    ): SkeletalRig {
        if (rig.baseRigPositionLocked) return rig
        return rig.copy(
            bones = rig.bones.map { b ->
                if (b.id == boneId) {
                    b.copy(
                        basePivotOffsetX = (b.basePivotOffsetX + dxPx).coerceIn(-400f, 400f),
                        basePivotOffsetY = (b.basePivotOffsetY + dyPx).coerceIn(-400f, 400f)
                    )
                } else b
            }
        )
    }

    /**
     * Live "Stretch Rig" solver (Module 2 & 7):
     * Dynamically aims AND stretches/shrinks non-head middle limbs.
     * Head bone (`neck`) and any bone with `allowLengthStretch = false` strictly lock length and rotate smoothly.
     */
    fun solveStretchDragTarget(
        rig: SkeletalRig,
        boneId: String,
        target: Vec2,
        currentAngles: Map<String, Float>,
        currentLengths: Map<String, Float>,
        rootX: Float = rig.rootX,
        rootY: Float = rig.rootY,
        scale: Float = rig.scale,
        flippedHorizontal: Boolean = rig.flippedHorizontal,
        scaleX: Float = rig.scaleX,
        scaleY: Float = rig.scaleY,
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT
    ): Pair<Map<String, Float>, Map<String, Float>> {
        if (!target.x.isFinite() || !target.y.isFinite()) return currentAngles to currentLengths
        val safeScale = if (scale.isFinite()) scale.coerceIn(0.05f, 10f) else 1f
        val safeSx = if (scaleX.isFinite()) scaleX.coerceIn(0.15f, 6f) else 1f
        val safeSy = if (scaleY.isFinite()) scaleY.coerceIn(0.15f, 6f) else 1f
        val localTarget = if (flippedHorizontal) Vec2(rootX - (target.x - rootX), target.y) else target

        val solvedMap = solveForwardKinematics(
            rig = rig,
            angleOverrides = currentAngles,
            rootX = rootX,
            rootY = rootY,
            scale = safeScale,
            flippedHorizontal = false,
            lengthOverrides = currentLengths,
            scaleX = safeSx,
            scaleY = safeSy,
            viewAngle = viewAngle
        ).associateBy { it.bone.id }

        val targetSolved = solvedMap[boneId] ?: return currentAngles to currentLengths
        val bone = targetSolved.bone
        if (isBoneLocked(rig, bone) || isBoneStructurallyFixed(rig, bone)) return currentAngles to currentLengths
        val parentWorld = bone.parentId?.let { solvedMap[it]?.worldAngleDeg } ?: 0f

        val dx = (localTarget.x - targetSolved.start.x) / (safeScale * safeSx)
        val dy = (localTarget.y - targetSolved.start.y) / (safeScale * safeSy)
        val rawLen = hypot(dx, dy)
        if (!rawLen.isFinite() || rawLen < 0.01f) return currentAngles to currentLengths

        val desiredWorld = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (!desiredWorld.isFinite()) return currentAngles to currentLengths
        val prevLocal = currentAngles[bone.id] ?: bone.localAngleDeg
        val continuousAngle = unwrapAngleNear(desiredWorld - parentWorld, prevLocal)
            .coerceIn(-720f, 720f)
        if (!continuousAngle.isFinite()) return currentAngles to currentLengths

        // Lock Head bone length so stretching/shrinking affects ONLY non-head limbs cleanly (0.2x..2.5x base length)!
        val canStretch = bone.allowLengthStretch && bone.id != "neck"
        val updatedLengths = if (canStretch) {
            val minLen = (bone.length * 0.2f).coerceAtLeast(6f)
            val maxLen = (bone.length * 2.5f).coerceAtLeast(minLen + 10f)
            currentLengths + (bone.id to rawLen.coerceIn(minLen, maxLen))
        } else {
            currentLengths
        }
        return (currentAngles + (bone.id to continuousAngle)) to updatedLengths
    }

    /**
     * Applies one of the 4 instant Per-Bone / Part Behavior Presets cleanly.
     */
    fun applyPartBehaviorPreset(bone: RigBone, preset: PartBehaviorPreset): RigBone {
        return when (preset) {
            PartBehaviorPreset.RIGID -> bone.copy(
                partBehaviorPreset = preset.name,
                meshBendSmoothness = 0f,
                springStiffness = 0f,
                springDamping = 0.90f,
                allowElasticStretch = false
            )
            PartBehaviorPreset.SOFT_CLOTH -> bone.copy(
                partBehaviorPreset = preset.name,
                meshBendSmoothness = 0.65f,
                springStiffness = 0.22f,
                springDamping = 0.72f,
                allowElasticStretch = false
            )
            PartBehaviorPreset.BOUNCY_SPRING -> bone.copy(
                partBehaviorPreset = preset.name,
                meshBendSmoothness = 0.35f,
                springStiffness = 0.75f,
                springDamping = 0.38f,
                allowElasticStretch = false
            )
            PartBehaviorPreset.ELASTIC_RUBBER -> bone.copy(
                partBehaviorPreset = preset.name,
                meshBendSmoothness = 0.80f,
                springStiffness = 0.42f,
                springDamping = 0.55f,
                allowElasticStretch = true
            )
        }
    }

    /**
     * Generates smooth alternating walking limb angles driven by horizontal travel distance
     * and adapted to the active Whole-Character Behavior / Mood Preset.
     */
    fun computeAutoWalkPose(
        travelX: Float,
        behaviorPresetName: String = CharacterBehaviorPreset.NORMAL_CALM.name
    ): Map<String, Float> {
        val mood = runCatching { CharacterBehaviorPreset.valueOf(behaviorPresetName) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
        return when (mood) {
            CharacterBehaviorPreset.ANGRY_STRICT -> {
                val phase = (travelX / 34f).toDouble() // Fast heavy steps
                val swing = sin(phase).toFloat()
                val lift = cos(phase).toFloat()
                mapOf(
                    "pelvis" to -90f,
                    "waist" to (6f + swing * 4f), // Tense forward lean
                    "spine" to (2f + swing * 2f),
                    "neck" to (-8f - swing * 4f),
                    "arm_l_up" to (-52f + swing * 38f),
                    "arm_l_low" to (38f + kotlin.math.max(0f, swing) * 26f),
                    "arm_r_up" to (52f + swing * 38f),
                    "arm_r_low" to (-44f - kotlin.math.max(0f, -swing) * 22f),
                    "leg_l_up" to (-62f - swing * 42f),
                    "leg_l_low" to (-14f - kotlin.math.max(0f, lift) * 34f),
                    "leg_r_up" to (62f + swing * 42f),
                    "leg_r_low" to (14f + kotlin.math.max(0f, -lift) * 34f)
                )
            }
            CharacterBehaviorPreset.HORROR_GHOSTLY -> {
                val phase = (travelX / 66f).toDouble() // Gliding eerie float
                val sway = sin(phase).toFloat()
                mapOf(
                    "pelvis" to -90f,
                    "waist" to (-4f + sway * 4f),
                    "spine" to (sway * 2f),
                    "neck" to (12f + sway * 10f),
                    "arm_l_up" to (-42f + sway * 14f),
                    "arm_l_low" to (36f + sway * 12f),
                    "arm_r_up" to (42f - sway * 14f),
                    "arm_r_low" to (-36f - sway * 12f),
                    "leg_l_up" to (-60f + sway * 10f),
                    "leg_l_low" to (-16f + sway * 8f),
                    "leg_r_up" to (60f - sway * 10f),
                    "leg_r_low" to (16f - sway * 8f)
                )
            }
            CharacterBehaviorPreset.HAPPY_PLAYFUL -> {
                val phase = (travelX / 40f).toDouble() // Bouncy energetic walk
                val swing = sin(phase).toFloat()
                val lift = cos(phase).toFloat()
                mapOf(
                    "pelvis" to -90f,
                    "waist" to (swing * 5f),
                    "spine" to (swing * 3f),
                    "neck" to (-swing * 8f),
                    "arm_l_up" to (-64f + swing * 42f),
                    "arm_l_low" to (32f + kotlin.math.max(0f, swing) * 26f),
                    "arm_r_up" to (64f + swing * 42f),
                    "arm_r_low" to (-32f - kotlin.math.max(0f, -swing) * 26f),
                    "leg_l_up" to (-60f - swing * 38f),
                    "leg_l_low" to (-14f - kotlin.math.max(0f, lift) * 36f),
                    "leg_r_up" to (60f + swing * 38f),
                    "leg_r_low" to (14f + kotlin.math.max(0f, -lift) * 36f)
                )
            }
            CharacterBehaviorPreset.ELDERLY_WEAK -> {
                val phase = (travelX / 68f).toDouble() // Slow careful short steps
                val swing = sin(phase).toFloat()
                val lift = cos(phase).toFloat()
                mapOf(
                    "pelvis" to -90f,
                    "waist" to (10f + swing * 2f), // Hunched posture slouch
                    "spine" to (6f + swing * 1.5f),
                    "neck" to (-14f - swing * 2f),
                    "arm_l_up" to (-70f + swing * 12f),
                    "arm_l_low" to (36f + kotlin.math.max(0f, swing) * 8f),
                    "arm_r_up" to (70f + swing * 12f),
                    "arm_r_low" to (-36f - kotlin.math.max(0f, -swing) * 8f),
                    "leg_l_up" to (-62f - swing * 16f),
                    "leg_l_low" to (-8f - kotlin.math.max(0f, lift) * 14f),
                    "leg_r_up" to (62f + swing * 16f),
                    "leg_r_low" to (8f + kotlin.math.max(0f, -lift) * 14f)
                )
            }
            CharacterBehaviorPreset.NORMAL_CALM -> {
                val phase = (travelX / 48f).toDouble()
                val swing = sin(phase).toFloat()
                val lift = cos(phase).toFloat()
                mapOf(
                    "pelvis" to -90f,
                    "waist" to (swing * 3f),
                    "spine" to (swing * 1.5f),
                    "neck" to (-swing * 3f),
                    "arm_l_up" to (-58f + swing * 28f),
                    "arm_l_low" to (24f + kotlin.math.max(0f, swing) * 20f),
                    "arm_r_up" to (58f + swing * 28f),
                    "arm_r_low" to (-24f - kotlin.math.max(0f, -swing) * 20f),
                    "leg_l_up" to (-56f - swing * 32f),
                    "leg_l_low" to (-10f - kotlin.math.max(0f, lift) * 26f),
                    "leg_r_up" to (56f + swing * 32f),
                    "leg_r_low" to (10f + kotlin.math.max(0f, -lift) * 26f)
                )
            }
        }
    }

    /**
     * True 2D Linear Blend Skinning (LBS) for Canvas.drawBitmapMesh.
     * Respects each bone's [PartBehaviorPreset]:
     * - RIGID: ultra-focused rigid local transform with zero skewing/neighbor pull
     * - SOFT_CLOTH: 65% smooth multi-bone blend for natural folds
     * - BOUNCY_SPRING: medium smooth bend with spring follow-through
     * - ELASTIC_RUBBER: dynamic stretch-axis scaling with squash-and-stretch volume conservation
     */
    fun computeDeformedMeshVertices(
        restBones: List<SolvedBone>,
        currentBones: List<SolvedBone>,
        meshRect: RectF,
        cols: Int = 8,
        rows: Int = 8
    ): FloatArray {
        val verts = FloatArray((cols + 1) * (rows + 1) * 2)
        val restMap = restBones.associateBy { it.bone.id }
        val pairs = currentBones.mapNotNull { cur -> restMap[cur.bone.id]?.let { rest -> rest to cur } }

        var idx = 0
        for (r in 0..rows) {
            val vFrac = r.toFloat() / rows.toFloat()
            val restY = meshRect.top + vFrac * meshRect.height()
            for (c in 0..cols) {
                val uFrac = c.toFloat() / cols.toFloat()
                val restX = meshRect.left + uFrac * meshRect.width()

                if (pairs.isEmpty()) {
                    verts[idx++] = restX
                    verts[idx++] = restY
                    continue
                }

                // If the closest bone is marked RIGID and very close, lock strictly to that bone (zero neighbor pull!)
                var nearestDist = Float.MAX_VALUE
                var nearestPair: Pair<SolvedBone, SolvedBone>? = null
                for (pair in pairs) {
                    val d = pointToSegmentDist(restX, restY, pair.first.start.x, pair.first.start.y, pair.first.end.x, pair.first.end.y)
                    if (d < nearestDist) {
                        nearestDist = d
                        nearestPair = pair
                    }
                }
                val nearestPreset = nearestPair?.second?.bone?.partBehaviorPreset?.let {
                    runCatching { PartBehaviorPreset.valueOf(it) }.getOrDefault(PartBehaviorPreset.RIGID)
                } ?: PartBehaviorPreset.RIGID

                if (nearestPair != null && nearestPreset == PartBehaviorPreset.RIGID && nearestPair.second.bone.meshBendSmoothness <= 0.05f && nearestDist < 54f) {
                    val (restB, curB) = nearestPair
                    val restAngle = atan2((restB.end.y - restB.start.y).toDouble(), (restB.end.x - restB.start.x).toDouble())
                    val curAngle = atan2((curB.end.y - curB.start.y).toDouble(), (curB.end.x - curB.start.x).toDouble())
                    val dTheta = curAngle - restAngle
                    val rx = restX - restB.start.x
                    val ry = restY - restB.start.y
                    val cosT = cos(dTheta).toFloat()
                    val sinT = sin(dTheta).toFloat()
                    verts[idx++] = curB.start.x + (rx * cosT - ry * sinT)
                    verts[idx++] = curB.start.y + (rx * sinT + ry * cosT)
                    continue
                }

                var sumX = 0f
                var sumY = 0f
                var sumW = 0f

                for ((restB, curB) in pairs) {
                    val dist = pointToSegmentDist(restX, restY, restB.start.x, restB.start.y, restB.end.x, restB.end.y)
                    val preset = runCatching { PartBehaviorPreset.valueOf(curB.bone.partBehaviorPreset) }
                        .getOrDefault(PartBehaviorPreset.RIGID)
                    val smoothness = curB.bone.meshBendSmoothness.coerceIn(0f, 1f)
                    val spreadSq = when (preset) {
                        PartBehaviorPreset.RIGID -> 520f + smoothness * 800f
                        PartBehaviorPreset.SOFT_CLOTH -> 2600f + smoothness * 1400f // 65% smooth multi-bone cloth bend
                        PartBehaviorPreset.BOUNCY_SPRING -> 1650f + smoothness * 900f
                        PartBehaviorPreset.ELASTIC_RUBBER -> 2400f + smoothness * 1600f
                    }
                    val w = 1f / ((dist * dist) / spreadSq + 0.06f)

                    val restAngle = atan2((restB.end.y - restB.start.y).toDouble(), (restB.end.x - restB.start.x).toDouble())
                    val curAngle = atan2((curB.end.y - curB.start.y).toDouble(), (curB.end.x - curB.start.x).toDouble())
                    val dTheta = curAngle - restAngle

                    val rx = restX - restB.start.x
                    val ry = restY - restB.start.y

                    val (tx, ty) = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || curB.bone.allowElasticStretch) {
                        val restLen = hypot(restB.end.x - restB.start.x, restB.end.y - restB.start.y).coerceAtLeast(1f)
                        val curLen = hypot(curB.end.x - curB.start.x, curB.end.y - curB.start.y).coerceAtLeast(1f)
                        val stretch = (curLen / restLen).coerceIn(0.35f, 3.2f)
                        val invSquash = (1f / kotlin.math.sqrt(stretch)).coerceIn(0.45f, 1.85f)
                        // Transform vertex into rest bone local coords, scale along bone axis & inverse-squash perp, rotate to cur bone
                        val rCos = cos(-restAngle).toFloat()
                        val rSin = sin(-restAngle).toFloat()
                        val localAlong = (rx * rCos - ry * rSin) * stretch
                        val localPerp = (rx * rSin + ry * rCos) * invSquash
                        val cCos = cos(curAngle).toFloat()
                        val cSin = sin(curAngle).toFloat()
                        (curB.start.x + localAlong * cCos - localPerp * cSin) to
                            (curB.start.y + localAlong * cSin + localPerp * cCos)
                    } else {
                        val cosT = cos(dTheta).toFloat()
                        val sinT = sin(dTheta).toFloat()
                        (curB.start.x + (rx * cosT - ry * sinT)) to
                            (curB.start.y + (rx * sinT + ry * cosT))
                    }

                    sumX += tx * w
                    sumY += ty * w
                    sumW += w
                }

                verts[idx++] = if (sumW > 0f && sumX.isFinite()) sumX / sumW else restX
                verts[idx++] = if (sumW > 0f && sumY.isFinite()) sumY / sumW else restY
            }
        }
        return verts
    }

    private fun pointToSegmentDist(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq <= 0.001f) return hypot(px - x1, py - y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lenSq).coerceIn(0f, 1f)
        val projX = x1 + t * dx
        val projY = y1 + t * dy
        return hypot(px - projX, py - projY)
    }

    fun normalizeAngle(deg: Float): Float {
        var a = deg % 360f
        if (a > 180f) a -= 360f
        if (a < -180f) a += 360f
        return a
    }

    /**
     * Unwraps [targetDeg] to the closest continuous revolution relative to [prevDeg],
     * eliminating ±180° atan2 wrap-around snapping for butter-smooth full 360° limb rotations.
     */
    fun unwrapAngleNear(targetDeg: Float, prevDeg: Float): Float {
        val delta = normalizeAngle(targetDeg - prevDeg)
        return prevDeg + delta
    }

    /**
     * Resolves a bone-local normalized anchor (u along bone 0..1, v perpendicular in -1..1)
     * into exact world coordinates for Point-to-Point Mesh Pinning.
     */
    fun resolvePinWorldPoint(bone: SolvedBone, localAnchor: Vec2): Vec2 {
        val dx = bone.end.x - bone.start.x
        val dy = bone.end.y - bone.start.y
        val len = hypot(dx, dy).coerceAtLeast(1f)
        val ux = dx / len
        val uy = dy / len
        val px = -uy
        val py = ux
        val along = localAnchor.x.coerceIn(-0.4f, 1.4f) * len
        val perp = localAnchor.y.coerceIn(-1.5f, 1.5f) * (bone.bone.thickness.coerceAtLeast(14f))
        return Vec2(
            x = bone.start.x + ux * along + px * perp,
            y = bone.start.y + uy * along + py * perp
        )
    }

    /**
     * Module 1: Computes localized rubber-cloth bridge mesh vertices ONLY between two pinned anchors
     * (Image A on Bone 1 -> Image B on Bone 2), producing smooth saree/sleeve/elbow fabric stretching
     * while all unpinned bone PNGs remain 100% rigid.
     */
    fun computePinnedClothBridgeVertices(
        pin: MeshPinLink,
        boneA: SolvedBone,
        boneB: SolvedBone,
        cols: Int = 6,
        rows: Int = 4
    ): FloatArray {
        val pA = resolvePinWorldPoint(boneA, pin.localAnchorA)
        val pB = resolvePinWorldPoint(boneB, pin.localAnchorB)
        val dx = pB.x - pA.x
        val dy = pB.y - pA.y
        val dist = hypot(dx, dy).coerceAtLeast(1f)
        val ux = dx / dist
        val uy = dy / dist
        val nx = -uy
        val ny = ux
        val halfWidth = (pin.radiusPx * 0.45f).coerceIn(10f, 80f)
        val stiffness = pin.clothStiffness.coerceIn(0.1f, 1f)
        // Subtle natural fabric catenary sag & waist pinch when stretched
        val stretchFactor = (dist / (pin.radiusPx.coerceAtLeast(16f) * 1.4f)).coerceIn(0.6f, 2.6f)
        val pinch = (1f / kotlin.math.sqrt(stretchFactor)).coerceIn(0.55f, 1.25f)
        val sag = (1f - stiffness) * dist * 0.14f

        val verts = FloatArray((cols + 1) * (rows + 1) * 2)
        var idx = 0
        for (r in 0..rows) {
            val vFrac = r.toFloat() / rows.toFloat()
            val perpFrac = (vFrac - 0.5f) * 2f // -1..+1
            for (c in 0..cols) {
                val uFrac = c.toFloat() / cols.toFloat()
                val midCurve = sin(uFrac * PI).toFloat() // 0 at anchors, 1 at center
                val localHalfW = halfWidth * (1f - (1f - pinch) * midCurve)
                val cx = pA.x + dx * uFrac
                val cy = pA.y + dy * uFrac + sag * midCurve
                verts[idx++] = cx + nx * perpFrac * localHalfW
                verts[idx++] = cy + ny * perpFrac * localHalfW
            }
        }
        return verts
    }

    /**
     * Module 8: Adds 5 articulated finger child bones (Thumb, Index, Middle, Ring, Pinky)
     * directly onto the Left or Right Hand bone for expressive hand & water-cupping animation.
     */
    fun addArticulatedFiveFingers(rig: SkeletalRig, isRightHand: Boolean): SkeletalRig {
        val parentHandId = if (isRightHand) "hand_r" else "hand_l"
        val resolvedParent = if (rig.bones.any { it.id == parentHandId }) {
            parentHandId
        } else {
            rig.bones.firstOrNull { it.id.contains(if (isRightHand) "arm_r" else "arm_l") }?.id
                ?: rig.bones.firstOrNull()?.id
        }
        val sideTag = if (isRightHand) "r" else "l"
        val sideLabel = if (isRightHand) "R" else "L"
        val dirSign = if (isRightHand) 1f else -1f
        val skinColor = rig.characterAppearance?.skinToneArgb ?: 0xFFF5C6A5L
        val baseZ = (rig.bones.firstOrNull { it.id == resolvedParent }?.zOrder ?: 12) + 1

        val fingerSpecs = listOf(
            Triple("finger_${sideTag}_thumb", "$sideLabel Thumb", -42f * dirSign to 16f),
            Triple("finger_${sideTag}_index", "$sideLabel Index", -18f * dirSign to 22f),
            Triple("finger_${sideTag}_middle", "$sideLabel Middle", 0f to 24f),
            Triple("finger_${sideTag}_ring", "$sideLabel Ring", 18f * dirSign to 21f),
            Triple("finger_${sideTag}_pinky", "$sideLabel Pinky", 36f * dirSign to 17f)
        )
        val existingIds = rig.bones.map { it.id }.toSet()
        val newBones = fingerSpecs.mapIndexedNotNull { idx, (id, label, angleAndLen) ->
            if (id in existingIds) return@mapIndexedNotNull null
            RigBone(
                id = id,
                name = label,
                parentId = resolvedParent,
                length = angleAndLen.second,
                localAngleDeg = angleAndLen.first,
                thickness = 6f,
                colorArgb = skinColor,
                isExtraRigBone = true,
                partBehaviorPreset = PartBehaviorPreset.RIGID.name,
                zOrder = baseZ + idx,
                allowLengthStretch = false
            )
        }
        if (newBones.isEmpty()) return rig
        return rig.copy(bones = rig.bones + newBones)
    }

    /**
     * Module 2: Switches Character & Rig Studio between any of the 8 turnaround views,
     * saving current custom PNGs, bone lengths, angles, Z-orders, and pivots for the outgoing angle
     * and restoring the target angle's saved layout (if previously configured).
     */
    fun switchRigToPerAngleConfig(rig: SkeletalRig, targetAngle: CharacterViewAngle): SkeletalRig {
        if (rig.viewAngle == targetAngle.name) return rig
        val currentSnapshot = RigViewAngleConfig(
            viewAngle = rig.viewAngle,
            singleMeshImagePath = rig.singleMeshImagePath,
            boneImagePaths = rig.bones.mapNotNull { b -> b.boundImagePath?.let { b.id to it } }.toMap(),
            boneLengths = rig.bones.associate { it.id to it.length },
            boneLocalAngles = rig.bones.associate { it.id to it.localAngleDeg },
            boneZOrders = rig.bones.associate { it.id to it.zOrder },
            bonePivotOffsets = rig.bones.associate { it.id to Vec2(it.pivotOffsetX, it.pivotOffsetY) }
        )
        val updatedConfigs = rig.perAngleRigConfigs + (rig.viewAngle to currentSnapshot)
        val targetCfg = updatedConfigs[targetAngle.name]
        val updatedBones = if (targetCfg != null) {
            rig.bones.map { b ->
                val savedPivot = targetCfg.bonePivotOffsets[b.id]
                b.copy(
                    boundImagePath = targetCfg.boneImagePaths[b.id] ?: b.boundImagePath,
                    length = targetCfg.boneLengths[b.id] ?: b.length,
                    localAngleDeg = targetCfg.boneLocalAngles[b.id] ?: b.localAngleDeg,
                    zOrder = targetCfg.boneZOrders[b.id] ?: b.zOrder,
                    pivotOffsetX = savedPivot?.x ?: b.pivotOffsetX,
                    pivotOffsetY = savedPivot?.y ?: b.pivotOffsetY
                )
            }
        } else {
            rig.bones
        }
        val baseResult = rig.copy(
            viewAngle = targetAngle.name,
            singleMeshImagePath = targetCfg?.singleMeshImagePath ?: rig.singleMeshImagePath,
            bones = updatedBones,
            perAngleRigConfigs = updatedConfigs,
            characterAppearance = rig.characterAppearance?.copy(viewAngle = targetAngle.name)
        )
        // If no saved per-angle Z-order exists for this view yet, auto-apply exact anatomical view Z-order!
        return if (targetCfg == null) applyAutoHumanLayerOrder(baseResult, targetAngle) else baseResult
    }

    /**
     * Full 16-Bone Anatomical Human Auto-Rig (with Dedicated Left & Right Shoulder Bones):
     * Spine -> Neck/Head (stretch-locked)
     * Spine -> Shoulder L -> Upper Arm L -> Forearm L -> Hand L
     * Spine -> Shoulder R -> Upper Arm R -> Forearm R -> Hand R
     * Hip -> Thigh L/R -> Shin L/R -> Foot L/R
     * Every joint is 100% unrestricted (-720..+720) with exact per-view anatomical Z-Order!
     */
    fun createHumanoidRig(
        name: String = "Hero Rig",
        rootX: Float = 640f,
        rootY: Float = 400f,
        characterAppearance: CharacterSpec? = null
    ): SkeletalRig {
        val shirtColor = characterAppearance?.shirtColorArgb ?: 0xFFFF6B35L
        val skinColor = characterAppearance?.skinToneArgb ?: 0xFFF5C6A5L
        val pantsColor = characterAppearance?.pantsColorArgb ?: 0xFF312E81L
        val shoeColor = 0xFF1E293BL
        val initialView = characterAppearance?.viewAngle ?: CharacterViewAngle.FRONT.name

        // Complete Connected Human Skeleton:
        // Central Spine & Waist: Pelvis (root) -> Waist -> Chest (spine) -> Neck (neck_base) -> Head (neck)
        // Upper Limbs: Chest -> Shoulder L/R -> Upper Arm L/R -> Forearm L/R -> Hand L/R
        // Lower Limbs: Pelvis -> Hip L/R -> Thigh L/R -> Shin (Knee) L/R -> Foot (Ankle) L/R
        // All joints are 100% unrestricted (-720°..+720°).
        val bones = listOf(
            RigBone(id = "pelvis", name = "Pelvis", parentId = null, length = 16f, localAngleDeg = -90f, thickness = 34f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 10, isStructuralFixed = true),
            RigBone(id = "waist", name = "Waist", parentId = "pelvis", length = 34f, localAngleDeg = 0f, thickness = 34f, colorArgb = shirtColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 11, isStructuralFixed = true),
            RigBone(id = "spine", name = "Chest", parentId = "waist", length = 48f, localAngleDeg = 0f, thickness = 38f, colorArgb = shirtColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 12, isStructuralFixed = true),
            RigBone(id = "neck_base", name = "Neck", parentId = "spine", length = 18f, localAngleDeg = 0f, thickness = 16f, colorArgb = skinColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 15, isStructuralFixed = true),
            RigBone(id = "neck", name = "Head", parentId = "neck_base", length = 54f, localAngleDeg = 0f, thickness = 44f, colorArgb = skinColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 16, allowLengthStretch = false),
            RigBone(id = "shoulder_l", name = "Shoulder L", parentId = "spine", length = 24f, localAngleDeg = -90f, thickness = 18f, colorArgb = shirtColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 11, isStructuralFixed = true),
            RigBone(id = "arm_l_up", name = "Upper Arm L", parentId = "shoulder_l", length = 56f, localAngleDeg = -58f, thickness = 18f, colorArgb = shirtColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 4),
            RigBone(id = "arm_l_low", name = "Forearm L", parentId = "arm_l_up", length = 50f, localAngleDeg = 22f, thickness = 15f, colorArgb = skinColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 5),
            RigBone(id = "hand_l", name = "Hand L", parentId = "arm_l_low", length = 22f, localAngleDeg = 8f, thickness = 16f, colorArgb = skinColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 6),
            RigBone(id = "shoulder_r", name = "Shoulder R", parentId = "spine", length = 24f, localAngleDeg = 90f, thickness = 18f, colorArgb = shirtColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 11, isStructuralFixed = true),
            RigBone(id = "arm_r_up", name = "Upper Arm R", parentId = "shoulder_r", length = 56f, localAngleDeg = 58f, thickness = 18f, colorArgb = shirtColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 7),
            RigBone(id = "arm_r_low", name = "Forearm R", parentId = "arm_r_up", length = 50f, localAngleDeg = -22f, thickness = 15f, colorArgb = skinColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 8),
            RigBone(id = "hand_r", name = "Hand R", parentId = "arm_r_low", length = 22f, localAngleDeg = -8f, thickness = 16f, colorArgb = skinColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 9),
            RigBone(id = "hip_l", name = "Hip L", parentId = "pelvis", length = 18f, localAngleDeg = -110f, thickness = 22f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 10, isStructuralFixed = true),
            RigBone(id = "leg_l_up", name = "Thigh L", parentId = "hip_l", length = 76f, localAngleDeg = -56f, thickness = 22f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 1),
            RigBone(id = "leg_l_low", name = "Shin L", parentId = "leg_l_up", length = 68f, localAngleDeg = -10f, thickness = 18f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 2),
            RigBone(id = "foot_l", name = "Foot L", parentId = "leg_l_low", length = 24f, localAngleDeg = -75f, thickness = 16f, colorArgb = shoeColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 3),
            RigBone(id = "hip_r", name = "Hip R", parentId = "pelvis", length = 18f, localAngleDeg = 110f, thickness = 22f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 10, isStructuralFixed = true),
            RigBone(id = "leg_r_up", name = "Thigh R", parentId = "hip_r", length = 76f, localAngleDeg = 56f, thickness = 22f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 1),
            RigBone(id = "leg_r_low", name = "Shin R", parentId = "leg_r_up", length = 68f, localAngleDeg = 10f, thickness = 18f, colorArgb = pantsColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 2),
            RigBone(id = "foot_r", name = "Foot R", parentId = "leg_r_low", length = 24f, localAngleDeg = 75f, thickness = 16f, colorArgb = shoeColor, minAngleDeg = -720f, maxAngleDeg = 720f, zOrder = 3)
        )
        return applyAutoHumanLayerOrder(
            SkeletalRig(
                name = name,
                rootX = rootX,
                rootY = rootY,
                viewAngle = initialView,
                bones = bones,
                characterAppearance = characterAppearance,
                eyePack = characterAppearance?.eyePack ?: EyePackStyle.AUTO_BLINK.name,
                mouthPhoneme = characterAppearance?.mouthPhoneme ?: MouthPhoneme.AUTO_LIPSYNC.name
            )
        )
    }

    /**
     * Master Upgrade Module 2: Exact Anatomical Z-Order Layering per View Side
     * (Higher value = Topmost / Layer 1 drawn in front; Lower value = Bottommost drawn behind):
     *
     * - FRONT / 3/4 FRONT:
     *   Layer 1 (Top): Head & Face (neck, head, hair)
     *   Layer 2 (Mid): Body (pelvis, waist, chest/spine, shoulders, hips)
     *   Layer 3 (Bottom): Hands & Legs (arms, hands, fingers, thighs, shins, feet)
     *
     * - SIDE LEFT / SIDE RIGHT:
     *   Layer 1 (Top): Near Hand & Near Leg
     *   Layer 2: Head, Near Ear & Side Face
     *   Layer 3: Body (pelvis, waist, chest/spine, shoulders, hips)
     *   Layer 4 (Bottom): Far Hand & Far Leg
     *
     * - BACK / 3/4 BACK:
     *   Layer 1 (Top): Hands & Legs
     *   Layer 2: Body
     *   Layer 3 (Bottom): Head & Ears
     */
    fun computeAutoHumanPriority(
        bone: RigBone,
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT
    ): Int {
        val id = bone.id.lowercase()
        val n = bone.name.lowercase()
        val isLeftLimb = id.startsWith("arm_l") || id == "hand_l" || id.startsWith("finger_l") ||
            id.startsWith("leg_l") || id == "foot_l" || id.startsWith("wing_l") || id == "claw_l"
        val isRightLimb = id.startsWith("arm_r") || id == "hand_r" || id.startsWith("finger_r") ||
            id.startsWith("leg_r") || id == "foot_r" || id.startsWith("wing_r") || id == "claw_r"
        val isBody = id == "pelvis" || id == "waist" || id == "spine" || id == "root_body" ||
            id == "shoulder_l" || id == "shoulder_r" || id == "hip_l" || id == "hip_r" ||
            n.contains("torso") || n.contains("spine") || n.contains("body") || n.contains("chest") ||
            n.contains("waist") || n.contains("pelvis") || n.contains("shirt") || n.contains("saree") ||
            n.contains("skirt") || n.contains("outfit")
        val isHead = id == "neck" || id == "neck_base" || n.contains("head") || n.contains("face") || n.contains("beak")
        val isHairHat = n.contains("hair") || n.contains("hat") || n.contains("cap") || n.contains("crown") ||
            n.contains("turban") || n.contains("pagri") || n.contains("glasses")
        val isHeldProp = !bone.attachedPropKind.isNullOrBlank() || bone.isExtraRigBone ||
            n.contains("prop") || n.contains("sword") || n.contains("stick") || n.contains("mic") ||
            n.contains("lamp") || n.contains("phone") || n.contains("bag") || n.contains("weapon")

        if (isHeldProp) return 95

        return when (viewAngle) {
            CharacterViewAngle.FRONT, CharacterViewAngle.FRONT_LEFT_34, CharacterViewAngle.FRONT_RIGHT_34 -> when {
                isHairHat -> 85
                isHead -> if (id == "neck_base") 76 else 80 // Layer 1 (Top): Head & Face
                isBody -> when (id) {
                    "spine" -> 54
                    "waist" -> 52
                    "pelvis" -> 50
                    else -> 48
                } // Layer 2: Body (Chest, Waist, Pelvis, Shoulders, Hips)
                isLeftLimb || isRightLimb -> {
                    // Layer 3 (Bottom): Hands & Legs
                    when {
                        id.startsWith("leg_") || id.startsWith("foot_") -> 20
                        id.startsWith("arm_") -> 26
                        id.startsWith("hand_") || id.startsWith("finger_") -> 30
                        else -> 24
                    }
                }
                else -> 40
            }
            CharacterViewAngle.SIDE_RIGHT -> when {
                // Layer 1 (Top): Near Hand & Near Leg (Right side)
                isRightLimb -> if (id.startsWith("hand_") || id.startsWith("finger_") || id.startsWith("arm_")) 84 else 80
                // Layer 2: Head, Near Ear & Side Face
                isHairHat -> 68
                isHead -> if (id == "neck_base") 62 else 64
                // Layer 3: Body
                isBody -> 44
                // Layer 4 (Bottom): Far Hand & Far Leg (Left side)
                isLeftLimb -> if (id.startsWith("leg_") || id.startsWith("foot_")) 20 else 14
                else -> 40
            }
            CharacterViewAngle.SIDE_LEFT -> when {
                // Layer 1 (Top): Near Hand & Near Leg (Left side)
                isLeftLimb -> if (id.startsWith("hand_") || id.startsWith("finger_") || id.startsWith("arm_")) 84 else 80
                // Layer 2: Head, Near Ear & Side Face
                isHairHat -> 68
                isHead -> if (id == "neck_base") 62 else 64
                // Layer 3: Body
                isBody -> 44
                // Layer 4 (Bottom): Far Hand & Far Leg (Right side)
                isRightLimb -> if (id.startsWith("leg_") || id.startsWith("foot_")) 20 else 14
                else -> 40
            }
            CharacterViewAngle.BACK, CharacterViewAngle.BACK_LEFT_34, CharacterViewAngle.BACK_RIGHT_34 -> when {
                // Layer 1 (Top): Hands & Legs
                isLeftLimb || isRightLimb ->
                    if (id.startsWith("hand_") || id.startsWith("finger_") || id.startsWith("arm_")) 82 else 76
                // Layer 2: Body
                isBody -> 50
                // Layer 3 (Bottom): Head & Ears
                isHairHat -> 24
                isHead -> if (id == "neck_base") 22 else 20
                else -> 40
            }
        }
    }

    /**
     * 1-tap "Auto Human Layer Order" preset assigning clean sequential Z-Orders
     * matching exact anatomical Front / Side-L / Side-R / Back view ordering!
     */
    fun applyAutoHumanLayerOrder(
        rig: SkeletalRig,
        viewAngleOverride: CharacterViewAngle? = null
    ): SkeletalRig {
        val viewAngle = viewAngleOverride
            ?: runCatching { CharacterViewAngle.valueOf(rig.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
        val ranked = rig.bones.withIndex().sortedWith(
            compareBy<IndexedValue<RigBone>>({ computeAutoHumanPriority(it.value, viewAngle) }, { it.index })
        )
        val zMap = ranked.mapIndexed { rankIdx, iv -> iv.value.id to (rankIdx + 1) }.toMap()
        return rig.copy(
            bones = rig.bones.map { b -> b.copy(zOrder = zMap[b.id] ?: b.zOrder) }
        )
    }

    /**
     * Computes updated bone Z-order map for Bring Forward (+1), Send Backward (-1),
     * Bring to Front (Top), or Send to Back (Bottom).
     */
    fun adjustBoneZOrderMap(
        bones: List<RigBone>,
        currentZOrders: Map<String, Int>,
        boneId: String,
        action: BoneZOrderAction
    ): Map<String, Int> {
        if (bones.none { it.id == boneId }) return currentZOrders
        val mutable = bones.associate { it.id to (currentZOrders[it.id] ?: it.zOrder) }.toMutableMap()
        // Sort ascending: index 0 = Back (lowest z), lastIndex = Front (highest z)
        val sortedAsc = bones.sortedWith(compareBy<RigBone>({ mutable[it.id] ?: it.zOrder }, { bones.indexOf(it) }))
        val idx = sortedAsc.indexOfFirst { it.id == boneId }
        if (idx < 0) return mutable
        val curZ = mutable[boneId] ?: 0
        when (action) {
            BoneZOrderAction.BRING_FORWARD -> {
                if (idx < sortedAsc.lastIndex) {
                    val aboveId = sortedAsc[idx + 1].id
                    val aboveZ = mutable[aboveId] ?: curZ
                    if (aboveZ == curZ) {
                        mutable[boneId] = curZ + 1
                    } else {
                        // Swap ranks so 1 tap always visibly moves forward above immediate neighbor
                        mutable[boneId] = aboveZ
                        mutable[aboveId] = curZ
                    }
                } else {
                    mutable[boneId] = curZ + 1
                }
            }
            BoneZOrderAction.SEND_BACKWARD -> {
                if (idx > 0) {
                    val belowId = sortedAsc[idx - 1].id
                    val belowZ = mutable[belowId] ?: curZ
                    if (belowZ == curZ) {
                        mutable[boneId] = curZ - 1
                    } else {
                        mutable[boneId] = belowZ
                        mutable[belowId] = curZ
                    }
                } else {
                    mutable[boneId] = curZ - 1
                }
            }
            BoneZOrderAction.BRING_TO_FRONT -> {
                val maxZ = mutable.values.maxOrNull() ?: 0
                mutable[boneId] = if (curZ == maxZ && sortedAsc.count { (mutable[it.id] ?: 0) == maxZ } == 1) maxZ else maxZ + 1
            }
            BoneZOrderAction.SEND_TO_BACK -> {
                val minZ = mutable.values.minOrNull() ?: 0
                mutable[boneId] = if (curZ == minZ && sortedAsc.count { (mutable[it.id] ?: 0) == minZ } == 1) minZ else minZ - 1
            }
        }
        return mutable
    }

    fun adjustBoneZOrder(bones: List<RigBone>, boneId: String, action: BoneZOrderAction): List<RigBone> {
        val current = bones.associate { it.id to it.zOrder }
        val updated = adjustBoneZOrderMap(bones, current, boneId, action)
        return bones.map { b -> b.copy(zOrder = updated[b.id] ?: b.zOrder) }
    }

    /**
     * Automatically upgrades/fits a full 14-bone human skeleton onto ANY existing rig or imported PNG character,
     * preserving existing PNG part bindings, single-mesh image, hand props, view angle, and facial packs.
     */
    fun autoRigHumanoid(existing: SkeletalRig): SkeletalRig {
        val base = createHumanoidRig(
            name = existing.name,
            rootX = existing.rootX,
            rootY = existing.rootY,
            characterAppearance = existing.characterAppearance
        )
        val oldMap = existing.bones.associateBy { it.id }
        val mergedBones = base.bones.map { b ->
            val old = oldMap[b.id]
            if (old != null) {
                b.copy(
                    boundImagePath = old.boundImagePath,
                    imageScale = old.imageScale,
                    pivotOffsetX = old.pivotOffsetX,
                    pivotOffsetY = old.pivotOffsetY,
                    imageRotationOffsetDeg = old.imageRotationOffsetDeg,
                    baseScaleX = old.baseScaleX,
                    baseScaleY = old.baseScaleY,
                    partBehaviorPreset = old.partBehaviorPreset,
                    meshBendSmoothness = old.meshBendSmoothness,
                    allowElasticStretch = old.allowElasticStretch,
                    springStiffness = old.springStiffness,
                    springDamping = old.springDamping,
                    zOrder = if (old.zOrder != 0) old.zOrder else b.zOrder
                )
            } else b
        }
        return existing.copy(
            bones = mergedBones,
            ikEnabled = true,
            showSkinMesh = true
        )
    }

    fun createRiggedCharacterFromSpec(spec: CharacterSpec, rootX: Float = 640f, rootY: Float = 410f): SkeletalRig {
        return createHumanoidRig(
            name = spec.name,
            rootX = rootX,
            rootY = rootY,
            characterAppearance = spec
        )
    }

    fun createCartoonMascotRig(rootX: Float = 640f, rootY: Float = 420f): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Body", parentId = null, length = 70f, localAngleDeg = -90f, thickness = 44f, colorArgb = 0xFFFBBF24L),
            RigBone(id = "neck", name = "Head", parentId = "spine", length = 56f, localAngleDeg = 0f, thickness = 50f, colorArgb = 0xFFFDE68AL, allowLengthStretch = false),
            RigBone(id = "ear_l", name = "L Ear", parentId = "neck", length = 42f, localAngleDeg = -35f, thickness = 14f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "ear_r", name = "R Ear", parentId = "neck", length = 42f, localAngleDeg = 35f, thickness = 14f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "arm_l_up", name = "L Arm", parentId = "spine", length = 54f, localAngleDeg = -125f, thickness = 15f, colorArgb = 0xFF34D399L),
            RigBone(id = "arm_r_up", name = "R Arm", parentId = "spine", length = 54f, localAngleDeg = 125f, thickness = 15f, colorArgb = 0xFF34D399L),
            RigBone(id = "leg_l_up", name = "L Leg", parentId = null, length = 56f, localAngleDeg = 110f, thickness = 17f, colorArgb = 0xFF38BDF8L),
            RigBone(id = "leg_r_up", name = "R Leg", parentId = null, length = 56f, localAngleDeg = 70f, thickness = 17f, colorArgb = 0xFF38BDF8L)
        )
        return applyAutoHumanLayerOrder(SkeletalRig(name = "Cartoon Mascot", rootX = rootX, rootY = rootY, bones = bones, rigCategory = "CUSTOM_OBJECT"))
    }

    /**
     * Non-Human Bird / Winged Creature Starter Rig:
     * Body, Head/Beak, Left & Right 2-bone flapping wings, Tail feathers, and Legs.
     */
    fun createBirdWingedRig(
        name: String = "Bird / Winged Rig",
        rootX: Float = 640f,
        rootY: Float = 380f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Body", parentId = null, length = 74f, localAngleDeg = -15f, thickness = 34f, colorArgb = 0xFF38BDF8L),
            RigBone(id = "neck", name = "Head / Beak", parentId = "spine", length = 52f, localAngleDeg = -25f, thickness = 30f, colorArgb = 0xFFFBBF24L, allowLengthStretch = false),
            RigBone(id = "wing_l_in", name = "L Wing Inner", parentId = "spine", length = 78f, localAngleDeg = -105f, thickness = 18f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "wing_l_tip", name = "L Wing Tip", parentId = "wing_l_in", length = 70f, localAngleDeg = -25f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "wing_r_in", name = "R Wing Inner", parentId = "spine", length = 78f, localAngleDeg = -65f, thickness = 18f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "wing_r_tip", name = "R Wing Tip", parentId = "wing_r_in", length = 70f, localAngleDeg = 20f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "tail_base", name = "Tail Base", parentId = null, length = 64f, localAngleDeg = 165f, thickness = 16f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "tail_tip", name = "Tail Fan", parentId = "tail_base", length = 48f, localAngleDeg = 10f, thickness = 14f, colorArgb = 0xFFC084FCL),
            RigBone(id = "claw_l", name = "L Claw", parentId = null, length = 46f, localAngleDeg = 105f, thickness = 12f, colorArgb = 0xFFF59E0BL),
            RigBone(id = "claw_r", name = "R Claw", parentId = null, length = 46f, localAngleDeg = 75f, thickness = 12f, colorArgb = 0xFFF59E0BL)
        )
        return applyAutoHumanLayerOrder(
            SkeletalRig(
                name = name,
                rootX = rootX,
                rootY = rootY,
                bones = bones,
                ikEnabled = true,
                showSkinMesh = true,
                rigCategory = "BIRD"
            )
        )
    }

    /**
     * Non-Human Quadruped Animal Starter Rig (Dog, Cat, Horse, Monster, Dragon):
     * Spine, Neck/Head, 2-bone Tail, and 4 articulated 2-bone legs.
     */
    fun createQuadrupedAnimalRig(
        name: String = "Animal Quadruped Rig",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Torso Spine", parentId = null, length = 115f, localAngleDeg = 0f, thickness = 34f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "neck", name = "Head / Snout", parentId = "spine", length = 68f, localAngleDeg = -42f, thickness = 32f, colorArgb = 0xFFFBBF24L, allowLengthStretch = false),
            RigBone(id = "tail_base", name = "Tail Base", parentId = null, length = 58f, localAngleDeg = -145f, thickness = 14f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "tail_tip", name = "Tail Tip", parentId = "tail_base", length = 52f, localAngleDeg = -20f, thickness = 11f, colorArgb = 0xFFC084FCL),
            RigBone(id = "leg_fl_up", name = "Front-L Upper", parentId = "spine", length = 64f, localAngleDeg = 82f, thickness = 17f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "leg_fl_low", name = "Front-L Paw", parentId = "leg_fl_up", length = 56f, localAngleDeg = 12f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "leg_fr_up", name = "Front-R Upper", parentId = "spine", length = 64f, localAngleDeg = 98f, thickness = 17f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "leg_fr_low", name = "Front-R Paw", parentId = "leg_fr_up", length = 56f, localAngleDeg = -10f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "leg_bl_up", name = "Back-L Upper", parentId = null, length = 66f, localAngleDeg = 104f, thickness = 18f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_bl_low", name = "Back-L Paw", parentId = "leg_bl_up", length = 58f, localAngleDeg = -18f, thickness = 14f, colorArgb = 0xFFC084FCL),
            RigBone(id = "leg_br_up", name = "Back-R Upper", parentId = null, length = 66f, localAngleDeg = 86f, thickness = 18f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_br_low", name = "Back-R Paw", parentId = "leg_br_up", length = 58f, localAngleDeg = 14f, thickness = 14f, colorArgb = 0xFFC084FCL)
        )
        return applyAutoHumanLayerOrder(
            SkeletalRig(
                name = name,
                rootX = rootX,
                rootY = rootY,
                bones = bones,
                ikEnabled = true,
                showSkinMesh = true,
                rigCategory = "QUADRUPED"
            )
        )
    }

    /**
     * Minimal Custom Object / Creature Rig ready for tap-anywhere custom bone placement on any PNG.
     */
    fun createCustomObjectRig(
        name: String = "Custom Object Rig",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "root_body", name = "Core Bone", parentId = null, length = 82f, localAngleDeg = -90f, thickness = 22f, colorArgb = 0xFF2DD4BFL, zOrder = 1),
            RigBone(id = "tip_1", name = "Tip Bone", parentId = "root_body", length = 68f, localAngleDeg = 15f, thickness = 16f, colorArgb = 0xFFFBBF24L, zOrder = 2)
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            bones = bones,
            ikEnabled = true,
            showSkinMesh = true,
            rigCategory = "CUSTOM_OBJECT"
        )
    }

    /**
     * Adds a custom parent-child bone directly to where the user tapped on the canvas!
     * Computes exact local angle and length relative to the selected parent bone tip (or root).
     */
    fun addCustomBoneAtPoint(
        rig: SkeletalRig,
        parentBoneId: String?,
        tapWorldPoint: Vec2,
        angleOverrides: Map<String, Float> = emptyMap(),
        flippedHorizontal: Boolean = false
    ): Pair<SkeletalRig, RigBone> {
        val localTap = if (flippedHorizontal) {
            Vec2(rig.rootX - (tapWorldPoint.x - rig.rootX), tapWorldPoint.y)
        } else {
            tapWorldPoint
        }
        val solved = solveForwardKinematics(rig, angleOverrides, rig.rootX, rig.rootY, rig.scale, false)
        val parentSolved = parentBoneId?.let { pid -> solved.firstOrNull { it.bone.id == pid } }
        val start = parentSolved?.end ?: Vec2(rig.rootX, rig.rootY)
        val parentWorldDeg = parentSolved?.worldAngleDeg ?: 0f

        val dx = localTap.x - start.x
        val dy = localTap.y - start.y
        val worldLen = hypot(dx, dy).coerceAtLeast(24f)
        val boneLen = (worldLen / rig.scale.coerceAtLeast(0.1f)).coerceIn(22f, 260f)
        val worldDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        val localDeg = normalizeAngle(worldDeg - parentWorldDeg)

        val nextIdx = rig.bones.size + 1
        val bonePalette = listOf(0xFF2DD4BFL, 0xFFFBBF24L, 0xFFA78BFAL, 0xFFFF6B35L, 0xFF34D399L, 0xFF38BDF8L)
        val nextZ = (rig.bones.maxOfOrNull { it.zOrder } ?: 0) + 1
        val newBone = RigBone(
            name = "Bone $nextIdx",
            parentId = parentSolved?.bone?.id,
            length = boneLen,
            localAngleDeg = localDeg,
            thickness = 15f,
            colorArgb = bonePalette[nextIdx % bonePalette.size],
            zOrder = nextZ
        )
        return rig.copy(bones = rig.bones + newBone) to newBone
    }

    /**
     * Starter rig for building reusable Custom Rigged Assets & Props (animated sword, wings, cape, skateboard,
     * umbrella, creature attachment, custom PNG prop with articulated bones).
     */
    fun createCustomAssetStarterRig(
        name: String = "My Custom Asset",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(
                id = "asset_base",
                name = "Asset Base",
                parentId = null,
                length = 72f,
                localAngleDeg = -90f,
                thickness = 18f,
                colorArgb = 0xFF2DD4BFL,
                isExtraRigBone = true,
                zOrder = 1
            ),
            RigBone(
                id = "asset_tip",
                name = "Asset Tip",
                parentId = "asset_base",
                length = 58f,
                localAngleDeg = 12f,
                thickness = 14f,
                colorArgb = 0xFFFBBF24L,
                isExtraRigBone = true,
                zOrder = 2
            )
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            bones = bones,
            ikEnabled = true,
            showSkinMesh = true,
            rigCategory = "ASSET"
        )
    }

    /**
     * Resolves which bone ID on [rig] corresponds to the requested [area] (Hands, Legs, Head, Chest, Hip, or Selected Bone).
     */
    fun resolveAttachmentParentBoneId(
        rig: SkeletalRig,
        area: RigAttachmentArea,
        selectedBoneId: String?
    ): String? {
        if (area == RigAttachmentArea.HIP_WAIST) return null
        if (area == RigAttachmentArea.SELECTED_BONE) {
            return selectedBoneId?.takeIf { id -> rig.bones.any { it.id == id } } ?: rig.bones.firstOrNull()?.id
        }
        val existingIds = rig.bones.map { it.id }.toSet()
        for (candidate in area.candidateBoneIds) {
            if (candidate in existingIds) return candidate
        }
        return selectedBoneId?.takeIf { it in existingIds } ?: rig.bones.firstOrNull()?.id
    }

    /**
     * Attaches a new extra variable articulated rig bone onto ANY body area (Hand, Leg, Foot, Head, Chest, Hip, or Selected Bone),
     * optionally carrying a built-in prop graphic or imported custom PNG that bends, scales, and rotates independently!
     */
    fun createExtraVariableBone(
        rig: SkeletalRig,
        area: RigAttachmentArea,
        selectedBoneId: String? = null,
        name: String? = null,
        length: Float = 68f,
        propKind: HandPropKind? = null,
        imagePath: String? = null,
        imageScale: Float = 1.0f
    ): Pair<SkeletalRig, RigBone> {
        val parentId = resolveAttachmentParentBoneId(rig, area, selectedBoneId)
        val extraCount = rig.bones.count { it.isExtraRigBone } + 1
        val propLabel = propKind?.takeIf { it != HandPropKind.NONE }?.label
        val resolvedName = name?.takeIf { it.isNotBlank() }
            ?: when {
                propLabel != null -> "${area.shortLabel}: $propLabel"
                !imagePath.isNullOrBlank() -> "${area.shortLabel} PNG #$extraCount"
                else -> "${area.shortLabel} Rig #$extraCount"
            }
        val palette = listOf(0xFFFBBF24L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFF6B35L, 0xFF34D399L, 0xFF38BDF8L)
        val nextZ = (rig.bones.maxOfOrNull { it.zOrder } ?: 0) + 1
        val newBone = RigBone(
            id = "extra_${UUID.randomUUID().toString().take(8)}",
            name = resolvedName,
            parentId = parentId,
            length = length.coerceIn(18f, 260f),
            localAngleDeg = area.defaultAngleDeg,
            thickness = 14f,
            colorArgb = palette[extraCount % palette.size],
            boundImagePath = imagePath,
            imageScale = imageScale.coerceIn(0.1f, 6.0f),
            attachedPropKind = propKind?.takeIf { it != HandPropKind.NONE }?.name,
            isExtraRigBone = true,
            zOrder = nextZ
        )
        return rig.copy(bones = rig.bones + newBone) to newBone
    }

    /**
     * Grafts a full multi-bone reusable Custom Asset onto ANY body area of [targetRig],
     * remapping bone IDs uniquely and parenting the asset's root bones onto the target socket bone!
     */
    fun graftCustomAssetOntoRig(
        targetRig: SkeletalRig,
        assetRig: SkeletalRig,
        area: RigAttachmentArea,
        selectedBoneId: String? = null
    ): Pair<SkeletalRig, RigBone?> {
        val socketParentId = resolveAttachmentParentBoneId(targetRig, area, selectedBoneId)
        val prefix = "att_${UUID.randomUUID().toString().take(6)}_"

        val sourceBones = if (assetRig.bones.isNotEmpty()) {
            assetRig.bones
        } else {
            listOf(
                RigBone(
                    id = "root",
                    name = assetRig.name,
                    parentId = null,
                    length = 72f,
                    localAngleDeg = area.defaultAngleDeg,
                    boundImagePath = assetRig.singleMeshImagePath,
                    imageScale = assetRig.singleMeshScale.coerceIn(0.1f, 6.0f),
                    isExtraRigBone = true
                )
            )
        }

        val idMap = sourceBones.associate { it.id to "$prefix${it.id}" }
        val graftedBones = sourceBones.mapIndexed { idx, bone ->
            val mappedParent = if (bone.parentId == null) {
                socketParentId
            } else {
                idMap[bone.parentId] ?: socketParentId
            }
            // If the asset used a single-mesh PNG and this is its first root bone without its own bound PNG, carry it along!
            val carriedImage = bone.boundImagePath
                ?: if (idx == 0 && !assetRig.singleMeshImagePath.isNullOrBlank()) assetRig.singleMeshImagePath else null
            val carriedScale = if (bone.boundImagePath == null && carriedImage != null) {
                (assetRig.singleMeshScale * 1.4f).coerceIn(0.2f, 6.0f)
            } else {
                bone.imageScale
            }
            bone.copy(
                id = idMap.getValue(bone.id),
                name = if (idx == 0) "${area.shortLabel}: ${assetRig.name}" else "${assetRig.name} • ${bone.name}",
                parentId = mappedParent,
                boundImagePath = carriedImage,
                imageScale = carriedScale,
                isExtraRigBone = true
            )
        }
        return targetRig.copy(bones = targetRig.bones + graftedBones) to graftedBones.firstOrNull()
    }

    fun presetPoseAngles(poseName: String): Map<String, Float> = when (poseName) {
        "WAVE" -> mapOf(
            "pelvis" to -90f,
            "waist" to 4f,
            "spine" to 0f,
            "neck_base" to 0f,
            "neck" to 8f,
            "arm_r_up" to -52f,
            "arm_r_low" to -52f,
            "arm_l_up" to -58f,
            "arm_l_low" to 18f
        )
        "WALK_A" -> mapOf(
            "pelvis" to -90f,
            "waist" to 5f,
            "spine" to 1f,
            "arm_l_up" to -32f,
            "arm_l_low" to 35f,
            "arm_r_up" to 82f,
            "arm_r_low" to -22f,
            "leg_l_up" to -34f,
            "leg_l_low" to -18f,
            "leg_r_up" to 34f,
            "leg_r_low" to 28f
        )
        "WALK_B" -> mapOf(
            "pelvis" to -90f,
            "waist" to -4f,
            "spine" to -1f,
            "arm_l_up" to -82f,
            "arm_l_low" to 22f,
            "arm_r_up" to 32f,
            "arm_r_low" to -35f,
            "leg_l_up" to -84f,
            "leg_l_low" to 25f,
            "leg_r_up" to 84f,
            "leg_r_low" to -15f
        )
        "JUMP" -> mapOf(
            "pelvis" to -90f,
            "waist" to 0f,
            "spine" to 0f,
            "arm_l_up" to 48f,
            "arm_l_low" to -20f,
            "arm_r_up" to -48f,
            "arm_r_low" to 20f,
            "leg_l_up" to -32f,
            "leg_l_low" to -65f,
            "leg_r_up" to 32f,
            "leg_r_low" to 65f
        )
        "SIT" -> mapOf(
            "pelvis" to -90f,
            "waist" to 2f,
            "spine" to 0f,
            "arm_l_up" to -45f,
            "arm_l_low" to -20f,
            "arm_r_up" to 45f,
            "arm_r_low" to 20f,
            "leg_l_up" to -10f,
            "leg_l_low" to -80f,
            "leg_r_up" to 10f,
            "leg_r_low" to 80f
        )
        "FLAP_UP" -> mapOf(
            "wing_l_in" to -135f,
            "wing_l_tip" to -15f,
            "wing_r_in" to -45f,
            "wing_r_tip" to 15f,
            "tail_base" to 155f
        )
        "FLAP_DOWN" -> mapOf(
            "wing_l_in" to 145f,
            "wing_l_tip" to 35f,
            "wing_r_in" to 35f,
            "wing_r_tip" to -35f,
            "tail_base" to 178f
        )
        else -> mapOf(
            "pelvis" to -90f,
            "waist" to 0f,
            "spine" to 0f,
            "neck_base" to 0f,
            "neck" to 0f,
            "shoulder_l" to -90f,
            "shoulder_r" to 90f,
            "hip_l" to -110f,
            "hip_r" to 110f,
            "arm_l_up" to -58f,
            "arm_l_low" to 22f,
            "arm_r_up" to 58f,
            "arm_r_low" to -22f,
            "leg_l_up" to -56f,
            "leg_l_low" to -10f,
            "leg_r_up" to 56f,
            "leg_r_low" to 10f
        )
    }
}
