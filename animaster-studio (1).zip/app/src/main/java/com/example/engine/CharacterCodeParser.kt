package com.example.engine

import android.graphics.Path
import com.example.data.model.CharacterSpec
import com.example.data.model.CodedVectorPath
import com.example.data.model.SkeletalRig
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class CharacterCodeParseResult(
    val spec: CharacterSpec? = null,
    val rig: SkeletalRig? = null,
    val error: String? = null
)

/**
 * Offline JSON + SVG-style Vector Path (M/L/Q/C/Z) parser for the "Create Character by Code" Builder.
 * Converts structured JSON definitions and custom vector path strings into a full Animaster
 * [CharacterSpec] + rigged [SkeletalRig] ready for real-time canvas preview, stage animation, and Swap Char.
 */
object CharacterCodeParser {

    val DEFAULT_TEMPLATE_JSON: String = """
{
  "name": "Cyber Nova",
  "skinColor": "#F5C6A5",
  "hairStyle": "SPIKY",
  "hairColor": "#1E293B",
  "eyeStyle": "ANIME",
  "eyeColor": "#06B6D4",
  "mouthStyle": "SMILE",
  "shirtStyle": "HOODIE",
  "shirtColor": "#2563EB",
  "pantsColor": "#0F172A",
  "accessory": "GLASSES",
  "paths": [
    {
      "attachTo": "HEAD",
      "fill": "#FFD600",
      "stroke": "#0F172A",
      "strokeWidth": 2.5,
      "d": "M -18 -42 L -6 -62 L 0 -46 L 6 -62 L 18 -42 Q 0 -36 -18 -42 Z"
    },
    {
      "attachTo": "TORSO",
      "fill": "#38BDF8",
      "stroke": "#0F172A",
      "strokeWidth": 2.5,
      "d": "M 0 -22 L 14 0 L 0 22 L -14 0 Z"
    }
  ]
}
    """.trimIndent()

    val ROYAL_WIZARD_TEMPLATE_JSON: String = """
{
  "name": "Royal Wizard",
  "skinColor": "#E8B490",
  "hairStyle": "LONG",
  "hairColor": "#E2E8F0",
  "eyeStyle": "ROUND",
  "eyeColor": "#A855F7",
  "mouthStyle": "SMILE",
  "shirtStyle": "KURTA",
  "shirtColor": "#6D28D9",
  "pantsColor": "#312E81",
  "accessory": "CROWN",
  "paths": [
    {
      "attachTo": "HEAD",
      "fill": "#7C3AED",
      "stroke": "#FACC15",
      "strokeWidth": 3.0,
      "d": "M -34 -34 Q 0 -46 34 -34 L 4 -92 C -2 -82 -16 -60 -34 -34 Z"
    },
    {
      "attachTo": "TORSO",
      "fill": "#FACC15",
      "stroke": "#1E1B4B",
      "strokeWidth": 2.0,
      "d": "M 0 -20 L 6 -6 L 20 -6 L 9 4 L 13 18 L 0 9 L -13 18 L -9 4 L -20 -6 L -6 -6 Z"
    }
  ]
}
    """.trimIndent()

    val CAPE_NINJA_TEMPLATE_JSON: String = """
{
  "name": "Shadow Striker",
  "skinColor": "#F0C09A",
  "hairStyle": "SPIKY",
  "hairColor": "#0F172A",
  "eyeStyle": "ANIME",
  "eyeColor": "#EF4444",
  "mouthStyle": "COOL",
  "shirtStyle": "JACKET",
  "shirtColor": "#18181B",
  "pantsColor": "#09090B",
  "accessory": "HEADBAND",
  "paths": [
    {
      "attachTo": "HEAD",
      "fill": "#EF4444",
      "stroke": "#09090B",
      "strokeWidth": 2.5,
      "d": "M -36 -22 Q 0 -30 36 -22 L 36 -10 Q 0 -18 -36 -10 Z"
    },
    {
      "attachTo": "TORSO",
      "fill": "#DC2626",
      "stroke": "#09090B",
      "strokeWidth": 2.5,
      "d": "M -24 -28 C -10 -12 10 -12 24 -28 L 16 14 Q 0 26 -16 14 Z"
    }
  ]
}
    """.trimIndent()

    fun parseColorHex(raw: String?, fallback: Long): Long {
        if (raw.isNullOrBlank()) return fallback
        val cleaned = raw.trim().removePrefix("#").removePrefix("0x").removePrefix("0X")
        val parsed = cleaned.toLongOrNull(16) ?: return fallback
        return when (cleaned.length) {
            6 -> 0xFF000000L or parsed
            8 -> parsed
            3 -> {
                val r = ((parsed shr 8) and 0xF) * 17
                val g = ((parsed shr 4) and 0xF) * 17
                val b = (parsed and 0xF) * 17
                0xFF000000L or (r shl 16) or (g shl 8) or b
            }
            else -> fallback
        }
    }

    private val jsonMapAdapter by lazy {
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
        val type = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
        moshi.adapter<Map<String, Any?>>(type)
    }

    private fun Map<*, *>.optStr(key: String, fallback: String): String {
        val v = this[key] ?: return fallback
        return v.toString().trim().ifBlank { fallback }
    }

    private fun Map<*, *>.optNum(key: String, fallback: Double): Double {
        val v = this[key] ?: return fallback
        return when (v) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: fallback
            else -> fallback
        }
    }

    /**
     * Parses a JSON character definition with optional custom `paths` (`M/L/Q/C/Z` vector paths)
     * into a [CharacterSpec] and rigged [SkeletalRig].
     */
    fun parseCharacterCode(code: String): CharacterCodeParseResult {
        val trimmed = code.trim()
        if (trimmed.isEmpty()) {
            return CharacterCodeParseResult(error = "Enter JSON character code to preview.")
        }
        return try {
            val json = jsonMapAdapter.fromJson(trimmed)
                ?: return CharacterCodeParseResult(error = "Expected a JSON object {...}")
            val name = json.optStr("name", "Coded Hero")
            val skinColor = parseColorHex(json.optStr("skinColor", ""), 0xFFF5C6A5L)
            val hairStyle = json.optStr("hairStyle", "SPIKY").uppercase()
            val hairColor = parseColorHex(json.optStr("hairColor", ""), 0xFF1E293BL)
            val eyeStyle = json.optStr("eyeStyle", "ANIME").uppercase()
            val eyeColor = parseColorHex(json.optStr("eyeColor", ""), 0xFF06B6D4L)
            val mouthStyle = json.optStr("mouthStyle", "SMILE").uppercase()
            val faceShape = json.optStr("faceShape", "OVAL").uppercase()
            val shirtStyle = json.optStr("shirtStyle", "HOODIE").uppercase()
            val shirtColor = parseColorHex(json.optStr("shirtColor", ""), 0xFF2563EBL)
            val pantsColor = parseColorHex(json.optStr("pantsColor", ""), 0xFF0F172AL)
            val accessory = json.optStr("accessory", "NONE").uppercase()
            val shoulderWidth = json.optNum("shoulderWidth", 1.0).toFloat().coerceIn(0.65f, 1.55f)
            val bellyPlumpness = json.optNum("bellyPlumpness", 0.0).toFloat().coerceIn(0f, 1f)

            val parsedPaths = mutableListOf<CodedVectorPath>()
            val pathsRaw = json["paths"] as? List<*>
            if (pathsRaw != null) {
                for (item in pathsRaw) {
                    val obj = item as? Map<*, *> ?: continue
                    val d = obj.optStr("d", "")
                    if (d.isEmpty()) continue
                    val fillHex = obj.optStr("fill", "#FFD600")
                    val strokeHex = obj.optStr("stroke", "#0F172A")
                    val strokeW = obj.optNum("strokeWidth", 2.5).toFloat().coerceIn(0f, 24f)
                    val attachTo = obj.optStr("attachTo", "HEAD").uppercase()
                        .let { if (it == "TORSO" || it == "BODY") "TORSO" else "HEAD" }
                    parsedPaths += CodedVectorPath(
                        d = d,
                        fillColorArgb = if (fillHex.equals("none", ignoreCase = true)) 0x00000000L else parseColorHex(fillHex, 0xFFFFD600L),
                        strokeColorArgb = if (strokeHex.equals("none", ignoreCase = true)) 0x00000000L else parseColorHex(strokeHex, 0xFF0F172AL),
                        strokeWidth = strokeW,
                        attachTo = attachTo
                    )
                }
            }

            val spec = CharacterSpec(
                name = name,
                skinToneArgb = skinColor,
                faceShape = faceShape,
                eyeStyle = eyeStyle,
                eyeColorArgb = eyeColor,
                mouthStyle = mouthStyle,
                hairStyle = hairStyle,
                hairColorArgb = hairColor,
                shirtStyle = shirtStyle,
                shirtColorArgb = shirtColor,
                pantsColorArgb = pantsColor,
                accessory = accessory,
                shoulderWidth = shoulderWidth,
                bellyPlumpness = bellyPlumpness,
                customCodePaths = parsedPaths
            )
            val rig = RigSolver.createRiggedCharacterFromSpec(spec, rootX = 640f, rootY = 420f)
            CharacterCodeParseResult(spec = spec, rig = rig, error = null)
        } catch (e: Exception) {
            CharacterCodeParseResult(error = e.message?.take(120) ?: "Invalid JSON syntax")
        }
    }

    sealed class SvgPathOp {
        data class MoveTo(val x: Float, val y: Float) : SvgPathOp()
        data class LineTo(val x: Float, val y: Float) : SvgPathOp()
        data class QuadTo(val cx: Float, val cy: Float, val x: Float, val y: Float) : SvgPathOp()
        data class CubicTo(val c1x: Float, val c1y: Float, val c2x: Float, val c2y: Float, val x: Float, val y: Float) : SvgPathOp()
        data object Close : SvgPathOp()
    }

    /**
     * Pure-Kotlin SVG path command parser (`M/m`, `L/l`, `H/h`, `V/v`, `Q/q`, `C/c`, `Z/z`).
     */
    fun parseSvgPathOps(d: String): List<SvgPathOp> {
        if (d.isBlank()) return emptyList()
        val tokenRegex = Regex("[MmLlHhVvQqCcZz]|[-+]?(?:\\d+\\.\\d*|\\.\\d+|\\d+)(?:[eE][-+]?\\d+)?")
        val tokens = tokenRegex.findAll(d).map { it.value }.toList()
        if (tokens.isEmpty()) return emptyList()

        val ops = mutableListOf<SvgPathOp>()
        var i = 0
        var cmd = ' '
        var curX = 0f
        var curY = 0f
        var startX = 0f
        var startY = 0f
        var hasMove = false

        fun nextFloat(): Float? {
            if (i >= tokens.size) return null
            val v = tokens[i].toFloatOrNull() ?: return null
            i++
            return v
        }

        while (i < tokens.size) {
            val t = tokens[i]
            if (t.length == 1 && t[0].isLetter()) {
                cmd = t[0]
                i++
                if (cmd == 'Z' || cmd == 'z') {
                    if (hasMove) {
                        ops += SvgPathOp.Close
                        curX = startX
                        curY = startY
                    }
                    continue
                }
            } else if (cmd == ' ') {
                break
            }

            when (cmd) {
                'M', 'm' -> {
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    curX = if (cmd == 'm') curX + x else x
                    curY = if (cmd == 'm') curY + y else y
                    startX = curX
                    startY = curY
                    ops += SvgPathOp.MoveTo(curX, curY)
                    hasMove = true
                    cmd = if (cmd == 'm') 'l' else 'L'
                }
                'L', 'l' -> {
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    curX = if (cmd == 'l') curX + x else x
                    curY = if (cmd == 'l') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(curX, curY)
                        startX = curX; startY = curY; hasMove = true
                    } else {
                        ops += SvgPathOp.LineTo(curX, curY)
                    }
                }
                'H', 'h' -> {
                    val x = nextFloat() ?: break
                    curX = if (cmd == 'h') curX + x else x
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(curX, curY)
                        startX = curX; startY = curY; hasMove = true
                    } else {
                        ops += SvgPathOp.LineTo(curX, curY)
                    }
                }
                'V', 'v' -> {
                    val y = nextFloat() ?: break
                    curY = if (cmd == 'v') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(curX, curY)
                        startX = curX; startY = curY; hasMove = true
                    } else {
                        ops += SvgPathOp.LineTo(curX, curY)
                    }
                }
                'Q', 'q' -> {
                    val cx = nextFloat() ?: break
                    val cy = nextFloat() ?: break
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    val qcx = if (cmd == 'q') curX + cx else cx
                    val qcy = if (cmd == 'q') curY + cy else cy
                    val qx = if (cmd == 'q') curX + x else x
                    val qy = if (cmd == 'q') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(qcx, qcy); startX = qcx; startY = qcy; hasMove = true
                    }
                    ops += SvgPathOp.QuadTo(qcx, qcy, qx, qy)
                    curX = qx; curY = qy
                }
                'C', 'c' -> {
                    val c1x = nextFloat() ?: break
                    val c1y = nextFloat() ?: break
                    val c2x = nextFloat() ?: break
                    val c2y = nextFloat() ?: break
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    val ac1x = if (cmd == 'c') curX + c1x else c1x
                    val ac1y = if (cmd == 'c') curY + c1y else c1y
                    val ac2x = if (cmd == 'c') curX + c2x else c2x
                    val ac2y = if (cmd == 'c') curY + c2y else c2y
                    val ax = if (cmd == 'c') curX + x else x
                    val ay = if (cmd == 'c') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(ac1x, ac1y); startX = ac1x; startY = ac1y; hasMove = true
                    }
                    ops += SvgPathOp.CubicTo(ac1x, ac1y, ac2x, ac2y, ax, ay)
                    curX = ax; curY = ay
                }
                else -> i++
            }
        }
        return if (hasMove) ops else emptyList()
    }

    /**
     * Parses SVG-style path commands (`M/m`, `L/l`, `H/h`, `V/v`, `Q/q`, `C/c`, `Z/z`)
     * into an [android.graphics.Path]. Returns null if the string has no valid commands.
     */
    fun parseSvgPathData(d: String): Path? {
        val ops = parseSvgPathOps(d)
        if (ops.isEmpty()) return null
        val path = Path()
        for (op in ops) {
            when (op) {
                is SvgPathOp.MoveTo -> path.moveTo(op.x, op.y)
                is SvgPathOp.LineTo -> path.lineTo(op.x, op.y)
                is SvgPathOp.QuadTo -> path.quadTo(op.cx, op.cy, op.x, op.y)
                is SvgPathOp.CubicTo -> path.cubicTo(op.c1x, op.c1y, op.c2x, op.c2y, op.x, op.y)
                is SvgPathOp.Close -> path.close()
            }
        }
        return path
    }
}

