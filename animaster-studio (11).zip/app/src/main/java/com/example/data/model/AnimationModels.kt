package com.example.data.model

import com.squareup.moshi.JsonClass
import java.util.UUID

enum class ScreenMode(val label: String) {
    AUTO_RESPONSIVE("Auto-Fit Responsive"),
    LOCK_LANDSCAPE("Lock Landscape"),
    LOCK_PORTRAIT("Lock Portrait")
}

data class DisplaySettings(
    val screenMode: ScreenMode = ScreenMode.AUTO_RESPONSIVE,
    val uiScale: Float = 1.0f
)

enum class EditorTool(val label: String, val shortcut: String) {
    PENCIL("Pencil", "P"),
    BRUSH("Brush", "B"),
    AIRBRUSH("Airbrush", "A"),
    ERASER("Eraser", "E"),
    BUCKET("Fill", "G"),
    PEN_BEZIER("Bezier", "N"),
    LINE("Line", "L"),
    RECTANGLE("Rect", "R"),
    CIRCLE("Circle", "C"),
    POLYGON("Poly", "Y"),
    TEXT("Text", "T"),
    EYEDROPPER("Picker", "I"),
    SELECT("Select", "V"),
    RIG_EDIT("Puppet", "K"),
    MOTION_PATH("Path", "M"),
    HAND_PAN("Pan", "H")
}

enum class LayerType(val displayName: String) {
    DRAWING("Vector & Raster"),
    CHARACTER("Character"),
    RIG("Rigged Puppet"),
    VIDEO("Video Layer"),
    BACKGROUND("Background"),
    FOREGROUND("Foreground")
}

enum class EasingType(val displayName: String) {
    EASE_IN_OUT("Smooth"),
    LINEAR("Linear"),
    BOUNCE("Bounce"),
    SNAP("Snap"),
    EASE_IN("Ease In"),
    EASE_OUT("Ease Out")
}

enum class SceneTransition(val displayName: String) {
    CUT("Cut"),
    FADE("Crossfade"),
    SLIDE_LEFT("Slide Left"),
    ZOOM_IN("Zoom In")
}

enum class BackgroundTemplate(val displayName: String) {
    SOLID("Solid Canvas"),
    PASTEL_SKY("Pastel Sky"),
    ZAMINDAR_VERANDA("Zamindar Veranda"),
    VILLAGE_HUT_POND("Village Hut & Pond"),
    ROYAL_DARBAR("Royal Darbar Hall"),
    VILLAGE_ROAD("Village Road"),
    HAUNTED_FOREST_MULTIPLANE("Haunted Forest 3D"),
    TRADITIONAL_ROOM("Traditional Room"),
    CHERRY_BLOSSOM("Sakura Park"),
    TWILIGHT_DREAM("Twilight Glow"),
    HAUNTED_FOREST("Haunted Forest"),
    SPOOKY_MANSION("Spooky Mansion"),
    COMIC_BURST("Comic Burst"),
    CLASSROOM_STAGE("School Stage"),
    SUNNY_MEADOW("Sunny Meadow"),
    CYBERPUNK_CITY("Neon City"),
    COZY_STUDIO("Cozy Studio"),
    OUTER_SPACE("Deep Space"),
    SUNSET_DESERT("Sunset Dunes"),
    GRID_PAPER("Animator Grid")
}

enum class SceneVfxType(val displayName: String) {
    FIREFLIES("Fireflies"),
    FLOWER_PETALS("Sakura Petals"),
    SUNBEAMS("Soft Sunbeams"),
    HIGH_SUNLIGHT("High Sunlight"),
    GOLDEN_HOUR("Golden Sun Glow"),
    STORM("Thunderstorm"),
    RAIN("Rain"),
    HEAVY_RAIN("Heavy Rain + Splashes"),
    LIGHTNING_FLASH("Lightning"),
    SNOW("Snow"),
    RAINBOW("Rainbow Arc"),
    AURORA("Northern Aurora"),
    AUTUMN_LEAVES("Wind & Leaves"),
    STARLIGHT("Twinkling Stars"),
    FIRE_EMBERS("Fire Embers"),
    SPOOKY_FOG("Spooky Fog"),
    VIGNETTE_HORROR("Horror Vignette"),
    SPEED_LINES("Anime Speed Lines"),
    CONFETTI_POP("YouTube Confetti"),
    CINEMA_BARS("Cinema Bars");
    val label: String get() = displayName
}

enum class SceneColorGrade(val displayName: String) {
    NONE("Normal"),
    HORROR_COLD("Horror Cold"),
    NIGHT_BLUE("Midnight"),
    WARM_SUNSET("Warm Glow"),
    VINTAGE_VHS("Retro VHS"),
    NOIR_BW("Noir B&W");
    val label: String get() = displayName
}

enum class VoiceEffectType(val displayName: String) {
    NORMAL("Normal"),
    CHIPMUNK("Cartoon Kid"),
    DEEP_MONSTER("Deep Monster"),
    GHOST_ECHO("Ghost Echo"),
    ROBOT("Robot");
    val label: String get() = displayName
}

enum class SubtitleStyle(val displayName: String) {
    YOUTUBE_BOLD("YouTube Bold"),
    HORROR_DRIP("Horror Red"),
    COMIC_BOX("Comic Box"),
    CINEMATIC("Cinema Clean");
    val label: String get() = displayName
}

enum class TextFontStyle(val displayName: String) {
    BOLD_CARTOON("Cartoon Bold"),
    SERIF_HORROR("Horror Serif"),
    MONO_TECH("Tech Mono"),
    CLASSIC_CLEAN("Clean Sans"),
    COMIC_ITALIC("Comic Italic");
    val label: String get() = displayName
}

enum class TextBoxStyle(val displayName: String) {
    NONE("None"),
    OUTLINE_GLOW("Neon Glow"),
    COMIC_BANNER("Comic Box"),
    SPEECH_BUBBLE("Speech Bubble"),
    YOUTUBE_PILL("YouTube Pill"),
    HORROR_BLOOD("Horror Slash");
    val label: String get() = displayName
}

enum class TextInAnimation(val displayName: String) {
    NONE("None"),
    POP_BOUNCE("Pop Bounce"),
    TYPEWRITER("Typewriter"),
    SLIDE_UP("Slide Up"),
    SLIDE_LEFT("Slide Left"),
    ZOOM_SLAM("Zoom Slam"),
    DROP_LETTERS("Letter Drop"),
    SPIN_POP("Spin Pop"),
    FADE_IN("Fade In");
    val label: String get() = displayName
}

enum class TextLoopAnimation(val displayName: String) {
    NONE("Static"),
    WAVE("Wave Letters"),
    BOUNCE("Bounce"),
    FLOAT("Ghost Float"),
    SHAKE_HORROR("Horror Shake"),
    GLITCH("Cyber Glitch"),
    PULSE("Pulse"),
    RAINBOW("Rainbow Glow");
    val label: String get() = displayName
}

enum class TextOutAnimation(val displayName: String) {
    NONE("None"),
    FADE_OUT("Fade Out"),
    POP_OUT("Pop Out"),
    SLIDE_DOWN("Slide Down"),
    ZOOM_OUT("Zoom Out");
    val label: String get() = displayName
}

enum class CharacterViewAngle(val displayName: String) {
    FRONT("Front"),
    FRONT_LEFT_34("Front-L 3/4"),
    SIDE_LEFT("Left Side"),
    BACK_LEFT_34("Back-L 3/4"),
    BACK("Back"),
    BACK_RIGHT_34("Back-R 3/4"),
    SIDE_RIGHT("Right Side"),
    FRONT_RIGHT_34("Front-R 3/4");
    val label: String get() = displayName
}

enum class HandGesturePose(val displayName: String) {
    RELAXED("Relaxed"),
    OPEN_PALM("Open Palm"),
    POINTING("Pointing"),
    NAMASTE("Namaste"),
    FIST("Fist"),
    THUMBS_UP("Thumbs Up"),
    HOLDING_PROP("Hold Prop");
    val label: String get() = displayName
}

enum class EyebrowStyle(val displayName: String) {
    NORMAL("Normal"),
    ANGRY("Angry Furrowed"),
    RAISED("Raised Surprised"),
    WORRIED("Worried / Sad");
    val label: String get() = displayName
}

enum class TargetedLoopType(val displayName: String) {
    TALKING_LOOP("Talking Loop"),
    AUTO_WALK("Auto-Walk Cycle"),
    CRYING_LOOP("Crying Loop"),
    LAUGHING_LOOP("Laughing Loop"),
    IDLE_BREATHING("Idle Breathing"),
    HORROR_TWITCH("Horror Twitch");
    val label: String get() = displayName
}

enum class PartBehaviorPreset(val displayName: String, val subtitle: String) {
    RIGID("Rigid", "Face / Hand / Prop"),
    SOFT_CLOTH("Soft Cloth", "Shirt / Saree / Skirt"),
    BOUNCY_SPRING("Bouncy Spring", "Hair / Tail / Wings"),
    ELASTIC_RUBBER("Elastic Rubber", "Horror / Stretch");
    val label: String get() = displayName
}

enum class CharacterBehaviorPreset(val displayName: String, val subtitle: String) {
    NORMAL_CALM("Normal / Calm", "Balanced posture, natural blink, relaxed walk"),
    ANGRY_STRICT("Angry / Strict", "Furrowed brows, sharp gestures, fast heavy steps"),
    HORROR_GHOSTLY("Horror / Ghostly", "Eerie twitch, floating sway, rim glow, tense limbs"),
    HAPPY_PLAYFUL("Happy / Playful", "Bouncy energetic walk, smile, lively hand waves"),
    ELDERLY_WEAK("Elderly / Weak", "Hunched slouch, slow careful steps, subtle tremor");
    val label: String get() = displayName
}

enum class HandPropKind(val displayName: String) {
    NONE("Empty"),
    SWORD("Sword"),
    MIC("YouTube Mic"),
    FLASHLIGHT("Flashlight"),
    MAGIC_WAND("Magic Wand"),
    PHONE("Phone"),
    HORROR_AXE("Horror Axe"),
    LANTERN("Ghost Lantern"),
    COFFEE("Coffee Cup"),
    SIGN("Sub Sign");
    val label: String get() = displayName
}

enum class EyePackStyle(val displayName: String) {
    AUTO_BLINK("Auto-Blink"),
    HAPPY("Happy"),
    LAUGHING("Laughing"),
    ANGRY("Angry"),
    SAD_TEARS("Crying Tears"),
    SCARED_HORROR("Scared / Horror"),
    SURPRISED("Surprised"),
    WINK("Wink"),
    SIDE_LOOK("Side-Look");
    val label: String get() = displayName
}

enum class MouthPhoneme(val displayName: String) {
    AUTO_LIPSYNC("Auto Lip-Sync"),
    TALKING_LOOP("Talking Loop"),
    LAUGHING("Laughing"),
    CRYING("Crying"),
    SCARED("Scared"),
    REST("Rest"),
    A("A (Wide)"),
    E("E (Smile)"),
    I("I (Teeth)"),
    O("O (Round)"),
    U("U (Pucker)"),
    SMILE("Big Smile"),
    SHOCK("Shock");
    val label: String get() = displayName
}

enum class ShapeKind {
    LINE, RECTANGLE, CIRCLE, POLYGON, FILL_BACKDROP
}

enum class AudioTrackKind(val displayName: String) {
    VOICE("Voice"),
    SFX("SFX"),
    MUSIC("Music")
}

enum class ExportFormat(val label: String, val ext: String, val mime: String) {
    PNG("PNG Frame", "png", "image/png"),
    PNG_SEQUENCE("PNG Sequence (ZIP)", "zip", "application/zip"),
    GIF("Animated GIF", "gif", "image/gif"),
    MP4("MP4 Video (H.264)", "mp4", "video/mp4"),
    WEBM("WebM Video (VP8)", "webm", "video/webm")
}

@JsonClass(generateAdapter = true)
data class Vec2(
    val x: Float,
    val y: Float
)

@JsonClass(generateAdapter = true)
data class DrawStroke(
    val id: String = UUID.randomUUID().toString(),
    val tool: String = EditorTool.BRUSH.name,
    val points: List<Vec2> = emptyList(),
    val colorArgb: Long = 0xFFFFFFFFL,
    val gradientEndArgb: Long? = null,
    val strokeWidth: Float = 8f,
    val opacity: Float = 1f,
    val isClosedBezier: Boolean = false
)

@JsonClass(generateAdapter = true)
data class VectorShape(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = ShapeKind.RECTANGLE.name,
    val startX: Float = 0f,
    val startY: Float = 0f,
    val endX: Float = 100f,
    val endY: Float = 100f,
    val polygonSides: Int = 5,
    val strokeColorArgb: Long = 0xFFFFFFFFL,
    val fillColorArgb: Long? = null,
    val gradientEndArgb: Long? = null,
    val strokeWidth: Float = 5f,
    val opacity: Float = 1f,
    val rotationDeg: Float = 0f
)

@JsonClass(generateAdapter = true)
data class CanvasTextItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "EPISODE 1!",
    val x: Float = 640f,
    val y: Float = 220f,
    val fontSize: Float = 68f,
    val colorArgb: Long = 0xFFFFE066L,
    val gradientEndArgb: Long? = null,
    val strokeColorArgb: Long = 0xFF0F172AL,
    val strokeWidth: Float = 8f,
    val isBold: Boolean = true,
    val shadowEnabled: Boolean = true,
    val glowEnabled: Boolean = false,
    val fontStyle: String = TextFontStyle.BOLD_CARTOON.name,
    val boxStyle: String = TextBoxStyle.NONE.name,
    val boxColorArgb: Long = 0xDD0F172AL,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f,
    val startFrame: Int = 0,
    val endFrame: Int = 9999,
    val inAnimation: String = TextInAnimation.POP_BOUNCE.name,
    val inDurationFrames: Int = 12,
    val loopAnimation: String = TextLoopAnimation.NONE.name,
    val loopSpeed: Float = 1f,
    val outAnimation: String = TextOutAnimation.FADE_OUT.name,
    val outDurationFrames: Int = 10,
    val visible: Boolean = true
)

@JsonClass(generateAdapter = true)
data class ImportedImageItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Image",
    val filePath: String = "",
    val x: Float = 320f,
    val y: Float = 180f,
    val width: Float = 320f,
    val height: Float = 240f,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f
)

@JsonClass(generateAdapter = true)
data class CharacterSpec(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nova",
    val x: Float = 640f,
    val y: Float = 380f,
    val scale: Float = 1f,
    val skinToneArgb: Long = 0xFFF5C6A5L,
    val faceShape: String = "OVAL",
    val eyeStyle: String = "ANIME",
    val eyeColorArgb: Long = 0xFF2DD4BFL,
    val mouthStyle: String = "SMILE",
    val expression: String = "HAPPY",
    val hairStyle: String = "SPIKY",
    val hairColorArgb: Long = 0xFF252B3AL,
    val shirtStyle: String = "HOODIE",
    val shirtColorArgb: Long = 0xFFFF6B35L,
    val pantsColorArgb: Long = 0xFF1E293BL,
    val accessory: String = "NONE",
    val pose: String = "IDLE",
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    // Module 4: Body Build & Traditional Indian/Bengali Story Character Styling
    val bellyPlumpness: Float = 0f,       // 0f..1f
    val shoulderWidth: Float = 1.0f,      // 0.65f..1.55f
    val torsoScale: Float = 1.0f,         // 0.7f..1.45f
    val postureSlouch: Float = 0f,        // 0f..1f (hunched elderly/sage posture)
    val facialHair: String = "NONE",      // NONE, MUSTACHE, THICK_MUSTACHE, SAGE_BEARD, ROYAL_BEARD
    val hasBindi: Boolean = false,
    val bindiColorArgb: Long = 0xFFDC2626L,
    val hasBangles: Boolean = false,
    val banglesColorArgb: Long = 0xFFFACC15L,
    val dupattaColorArgb: Long = 0xFFF59E0BL,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    // Character Designer Squish & Stretch base proportions + Acting Mood Behavior
    val baseScaleX: Float = 1.0f,
    val baseScaleY: Float = 1.0f,
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name
)

@JsonClass(generateAdapter = true)
data class RigBone(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Bone",
    val parentId: String? = null,
    val length: Float = 75f,
    val localAngleDeg: Float = -90f,
    val thickness: Float = 18f,
    val colorArgb: Long = 0xFF2DD4BFL,
    // Anatomical joint limits for realistic human bending
    val minAngleDeg: Float = -180f,
    val maxAngleDeg: Float = 180f,
    // Segmented PNG Part Binding
    val boundImagePath: String? = null,
    val imageScale: Float = 1.0f,
    val pivotOffsetX: Float = 0f,
    val pivotOffsetY: Float = 0f,
    val imageRotationOffsetDeg: Float = 0f,
    // Extra variable rig attachment support (built-in prop or custom rigged asset bone on any area)
    val attachedPropKind: String? = null,
    val isExtraRigBone: Boolean = false,
    // Module 2 & 9: Individual Limb Scaling (Width X & Length Y) + Per-Bone Spring Physics
    val limbWidthScale: Float = 1.0f,
    val limbLengthScale: Float = 1.0f,
    val springStiffness: Float = 0f,      // 0f = off, >0f = secondary physics sway
    val springDamping: Float = 0.65f,     // 0.1f..1.0f
    // Image Squish & Stretch (X/Y Axis Reshaping) + Part Behavior Preset
    val baseScaleX: Float = 1.0f,
    val baseScaleY: Float = 1.0f,
    val partBehaviorPreset: String = PartBehaviorPreset.RIGID.name,
    val meshBendSmoothness: Float = 0f,
    val allowElasticStretch: Boolean = false,
    // Per-Part Draw Order / Z-Order (Higher = Front / Top, Lower = Back / Bottom)
    val zOrder: Int = 0
)

@JsonClass(generateAdapter = true)
data class PuppetRootKeyframe(
    val frame: Int = 0,
    val rootX: Float = 640f,
    val rootY: Float = 390f,
    val scale: Float = 1f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val flippedHorizontal: Boolean = false,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name,
    val easing: String = EasingType.EASE_IN_OUT.name
)

@JsonClass(generateAdapter = true)
data class SkeletalRig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Hero Rig",
    val rootX: Float = 640f,
    val rootY: Float = 390f,
    val scale: Float = 1f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val pivotMode: String = "CENTER",     // "CENTER" or "BOTTOM_FEET"
    val flippedHorizontal: Boolean = false,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val autoWalkWhenDragged: Boolean = true,
    val autoDialogueActing: Boolean = false,
    val bones: List<RigBone> = emptyList(),
    // Map of frameIndex (as String for Moshi JSON) -> Map<boneId, angleDeg>
    val poseKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    // Module 2: Live Stretch Rig bone-length keyframes (frameIndex -> Map<boneId, boneLength>)
    val boneLengthKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    // Keyframeable Front/Back Z-Order switching during animation (frameIndex -> Map<boneId, zOrder>)
    val boneZOrderKeyframes: Map<String, Map<String, Int>> = emptyMap(),
    val rootKeyframes: List<PuppetRootKeyframe> = emptyList(),
    val showSkinMesh: Boolean = true,
    val ikEnabled: Boolean = true,
    // Optional Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh)
    val singleMeshImagePath: String? = null,
    val singleMeshWidth: Float = 260f,
    val singleMeshHeight: Float = 360f,
    // Optional Procedural Character Appearance bound directly to this skeleton
    val characterAppearance: CharacterSpec? = null,
    // Modular Facial Rig attached to Head bone
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    // Module 4: Independent Left & Right Hand Gestures
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    // Hand-Held Props & Custom PNG Attachments (follow left/right hand bones automatically)
    val leftHandProp: String = HandPropKind.NONE.name,
    val rightHandProp: String = HandPropKind.NONE.name,
    val leftHandCustomImagePath: String? = null,
    val rightHandCustomImagePath: String? = null,
    val handPropScale: Float = 1.0f,
    // Keep custom PNG faces clean unless user explicitly overlays modular cartoon face
    val showFaceOverlayOnCustomImage: Boolean = false,
    // Unrestricted single-mesh PNG transform (0.05x to 8.0x scale + free X/Y offset + Squish/Stretch baseScaleX/Y)
    val singleMeshScale: Float = 1.0f,
    val singleMeshOffsetX: Float = 0f,
    val singleMeshOffsetY: Float = 0f,
    val baseScaleX: Float = 1.0f,
    val baseScaleY: Float = 1.0f,
    // Whole-Character Acting Behavior / Mood Preset
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name,
    // Modular Facial Rig positioning & scaling on imported PNG characters (locked to Head bone)
    val faceOverlayOffsetX: Float = 0f,
    val faceOverlayOffsetY: Float = 0f,
    val faceOverlayScale: Float = 1.0f,
    // Rig archetype: HUMAN, BIRD, QUADRUPED, CUSTOM_OBJECT, ASSET
    val rigCategory: String = "HUMAN"
)

@JsonClass(generateAdapter = true)
data class FrameVisibilityRange(
    val startFrame: Int = 0,
    val endFrame: Int = 9999
)

@JsonClass(generateAdapter = true)
data class TargetedLoopClip(
    val id: String = UUID.randomUUID().toString(),
    val loopType: String = TargetedLoopType.TALKING_LOOP.name,
    val startFrame: Int = 0,
    val endFrame: Int = 24
)

@JsonClass(generateAdapter = true)
data class CustomActionClip(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Custom Action",
    val durationFrames: Int = 24,
    // Relative frame offset ("0", "4", ...) -> boneId -> angleDeg
    val poseKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    val boneLengthKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    val boneZOrderKeyframes: Map<String, Map<String, Int>> = emptyMap(),
    // Relative root offsets & expression changes
    val rootKeyframes: List<PuppetRootKeyframe> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class FrameContent(
    val strokes: List<DrawStroke> = emptyList(),
    val shapes: List<VectorShape> = emptyList(),
    val texts: List<CanvasTextItem> = emptyList(),
    val images: List<ImportedImageItem> = emptyList(),
    val characterOverride: CharacterSpec? = null
)

@JsonClass(generateAdapter = true)
data class TransformKeyframe(
    val frame: Int = 0,
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val opacity: Float = 1f,
    val easing: String = EasingType.EASE_IN_OUT.name
)

@JsonClass(generateAdapter = true)
data class CameraKeyframe(
    val frame: Int = 0,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val rotationDeg: Float = 0f,
    val easing: String = EasingType.EASE_IN_OUT.name
)

@JsonClass(generateAdapter = true)
data class AnimationLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Layer 1",
    val type: String = LayerType.DRAWING.name,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val opacity: Float = 1f,
    val parallaxDepth: Float = 1f,
    val frames: Map<String, FrameContent> = emptyMap(),
    val keyframes: List<TransformKeyframe> = emptyList(),
    val motionPath: List<Vec2> = emptyList(),
    val motionPathStartFrame: Int = 0,
    val motionPathEndFrame: Int = -1,
    val motionPathOrientToPath: Boolean = false,
    val motionPathEasing: String = EasingType.EASE_IN_OUT.name,
    val character: CharacterSpec? = null,
    val rig: SkeletalRig? = null,
    // Video background/reference layer
    val videoFilePath: String? = null,
    val videoDurationMs: Long = 0L,
    // Module 1, 7, 8, 9 enhancements
    val pivotMode: String = "CENTER",
    val isCelFrameByFrame: Boolean = false,
    val visibilityRanges: List<FrameVisibilityRange> = emptyList(),
    val targetedLoops: List<TargetedLoopClip> = emptyList(),
    val groundShadowEnabled: Boolean = false,
    val rimLightColorArgb: Long? = null,
    val maskToLayerBelow: Boolean = false,
    val motionBlurStrength: Float = 0f
)

@JsonClass(generateAdapter = true)
data class SubtitleCue(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Wait... did you hear that?!",
    val speakerName: String = "",
    val startFrame: Int = 0,
    val endFrame: Int = 48,
    val colorArgb: Long = 0xFFFFE066L,
    val style: String = SubtitleStyle.YOUTUBE_BOLD.name
)

@JsonClass(generateAdapter = true)
data class AnimationScene(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Scene 1",
    val durationFrames: Int = 96,
    val backgroundColorArgb: Long = 0xFF141824L,
    val backgroundTemplate: String = BackgroundTemplate.PASTEL_SKY.name,
    val backgroundScrollSpeed: Float = 0f,
    val backgroundDepthBlur: Float = 0f,
    val foregroundPlaneEnabled: Boolean = true,
    val colorGrade: String = SceneColorGrade.NONE.name,
    val transition: String = SceneTransition.FADE.name,
    val activeVfx: List<String> = emptyList(),
    val subtitles: List<SubtitleCue> = emptyList(),
    val animatedTexts: List<CanvasTextItem> = emptyList(),
    val layers: List<AnimationLayer> = emptyList(),
    val cameraKeyframes: List<CameraKeyframe> = listOf(CameraKeyframe(frame = 0)),
    // Module 9: Camera Follow, Directional Spotlight & Channel Brand Watermark
    val cameraFollowLayerId: String? = null,
    val spotlightEnabled: Boolean = false,
    val spotlightX: Float = 0.5f,
    val spotlightY: Float = 0.22f,
    val spotlightRadius: Float = 0.48f,
    val spotlightIntensity: Float = 0.65f,
    val spotlightColorArgb: Long = 0xFFFFF3C4L,
    val watermarkText: String = "",
    val watermarkImagePath: String? = null,
    val watermarkOpacity: Float = 0.65f,
    val watermarkCorner: String = "BOTTOM_RIGHT"
)

@JsonClass(generateAdapter = true)
data class AudioTrackItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Track 1",
    val filePath: String = "",
    val originalFilePath: String = "",
    val kind: String = AudioTrackKind.SFX.name,
    val voiceEffect: String = VoiceEffectType.NORMAL.name,
    val startFrame: Int = 0,
    val durationMs: Long = 2000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 2000L,
    val volume: Float = 0.85f,
    val fadeInMs: Long = 100L,
    val fadeOutMs: Long = 150L,
    val muted: Boolean = false,
    val autoDuckMusic: Boolean = false,
    val waveformPeaks: List<Float> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AnimationProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Animation",
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 24,
    val scenes: List<AnimationScene> = emptyList(),
    val activeSceneId: String = "",
    val audioTracks: List<AudioTrackItem> = emptyList(),
    val savedCharacters: List<CharacterSpec> = emptyList(),
    val savedRigs: List<SkeletalRig> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class ProjectSummary(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val sceneCount: Int,
    val updatedAt: Long,
    val isRecoverySnapshot: Boolean = false
)

data class ExportSettings(
    val format: ExportFormat = ExportFormat.MP4,
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 24,
    val quality: Int = 85,
    val startFrame: Int = 0,
    val endFrame: Int = 47,
    val transparentBackground: Boolean = false,
    val exportAllScenes: Boolean = false,
    val includeAudio: Boolean = true
)
