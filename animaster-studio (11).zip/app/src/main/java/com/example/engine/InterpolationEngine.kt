package com.example.engine

import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.CameraKeyframe
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterViewAngle
import com.example.data.model.EasingType
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FrameContent
import com.example.data.model.HandGesturePose
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.SkeletalRig
import com.example.data.model.TargetedLoopType
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import kotlin.math.hypot
import kotlin.math.pow

data class EvaluatedTransform(
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val opacity: Float = 1f
)

data class EvaluatedCamera(
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val rotationDeg: Float = 0f
)

data class EvaluatedPuppetRoot(
    val rootX: Float,
    val rootY: Float,
    val scale: Float,
    val flippedHorizontal: Boolean,
    val eyePack: String,
    val mouthPhoneme: String,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name
)

object InterpolationEngine {

    /**
     * Module 8: Checks both global track visibility AND per-track Frame Visibility Ranges
     * so characters/objects appear cleanly during their scene role and vanish off-stage outside it.
     */
    fun isLayerVisibleAtFrame(layer: AnimationLayer, frame: Int): Boolean {
        if (!layer.visible) return false
        if (layer.visibilityRanges.isEmpty()) return true
        return layer.visibilityRanges.any { range -> frame in range.startFrame..range.endFrame }
    }

    fun applyEasing(t: Float, easingName: String): Float {
        val clamped = t.coerceIn(0f, 1f)
        val easing = runCatching { EasingType.valueOf(easingName) }.getOrDefault(EasingType.EASE_IN_OUT)
        return when (easing) {
            EasingType.LINEAR -> clamped
            EasingType.SNAP -> if (clamped < 0.99f) 0f else 1f
            EasingType.EASE_IN -> clamped * clamped * clamped
            EasingType.EASE_OUT -> 1f - (1f - clamped).pow(3)
            EasingType.EASE_IN_OUT -> if (clamped < 0.5f) {
                4f * clamped * clamped * clamped
            } else {
                1f - (-2f * clamped + 2f).pow(3) / 2f
            }
            EasingType.BOUNCE -> bounceOut(clamped)
        }
    }

    private fun bounceOut(x: Float): Float {
        val n1 = 7.5625f
        val d1 = 2.75f
        return when {
            x < 1f / d1 -> n1 * x * x
            x < 2f / d1 -> {
                val t = x - 1.5f / d1
                n1 * t * t + 0.75f
            }
            x < 2.5f / d1 -> {
                val t = x - 2.25f / d1
                n1 * t * t + 0.9375f
            }
            else -> {
                val t = x - 2.625f / d1
                n1 * t * t + 0.984375f
            }
        }
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    data class PathSample(
        val position: Vec2,
        val tangentAngleDeg: Float,
        val distanceTraveled: Float,
        val totalLength: Float,
        val dx: Float,
        val dy: Float
    )

    fun evaluateMotionPathProgress(layer: AnimationLayer, frame: Int, totalFrames: Int): Float {
        if (layer.motionPath.size < 2 || totalFrames <= 1) return 0f
        val startF = layer.motionPathStartFrame.coerceIn(0, (totalFrames - 1).coerceAtLeast(0))
        val endF = if (layer.motionPathEndFrame > startF) {
            layer.motionPathEndFrame.coerceAtMost(totalFrames - 1)
        } else {
            (totalFrames - 1).coerceAtLeast(startF + 1)
        }
        val rawT = when {
            frame <= startF -> 0f
            frame >= endF -> 1f
            else -> (frame - startF).toFloat() / (endF - startF).coerceAtLeast(1).toFloat()
        }
        return applyEasing(rawT, layer.motionPathEasing).coerceIn(0f, 1f)
    }

    /**
     * Computes the un-transformed visual center of a non-rig layer (character, PNG image, shape, or drawing)
     * so motion path following glides the object directly ON the drawn curve instead of off-screen.
     */
    fun computeLayerVisualCenter(layer: AnimationLayer, frame: Int): Vec2? {
        layer.character?.let { c -> return Vec2(c.x, c.y) }
        val content = resolveFrameContent(layer, frame, holdPrevious = true) ?: return null
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        fun include(x: Float, y: Float) {
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }
        content.images.forEach { img ->
            include(img.x - img.width / 2f, img.y - img.height / 2f)
            include(img.x + img.width / 2f, img.y + img.height / 2f)
        }
        content.shapes.filter { it.kind != com.example.data.model.ShapeKind.FILL_BACKDROP.name }.forEach { s ->
            include(s.startX, s.startY); include(s.endX, s.endY)
        }
        content.strokes.forEach { st -> st.points.forEach { include(it.x, it.y) } }
        content.texts.forEach { t -> include(t.x, t.y) }
        if (!minX.isFinite()) return null
        return Vec2((minX + maxX) / 2f, (minY + maxY) / 2f)
    }

    fun evaluateLayerTransform(layer: AnimationLayer, frame: Int, totalFrames: Int): EvaluatedTransform {
        var base = if (layer.keyframes.isEmpty()) {
            EvaluatedTransform()
        } else {
            val sorted = layer.keyframes.sortedBy { it.frame }
            when {
                frame <= sorted.first().frame -> sorted.first().toEvaluated()
                frame >= sorted.last().frame -> sorted.last().toEvaluated()
                else -> {
                    val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                    val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                    val next = sorted[nextIdx]
                    if (prev.frame == next.frame) {
                        next.toEvaluated()
                    } else {
                        val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                        val eased = applyEasing(rawT, prev.easing)
                        EvaluatedTransform(
                            x = lerp(prev.x, next.x, eased),
                            y = lerp(prev.y, next.y, eased),
                            rotationDeg = lerp(prev.rotationDeg, next.rotationDeg, eased),
                            scaleX = lerp(prev.scaleX, next.scaleX, eased),
                            scaleY = lerp(prev.scaleY, next.scaleY, eased),
                            opacity = lerp(prev.opacity, next.opacity, eased)
                        )
                    }
                }
            }
        }

        // For RIG layers, motion path moves the puppet root directly in evaluatePuppetRootWithPath (avoid double-offsetting!).
        val isRigLayer = layer.type == com.example.data.model.LayerType.RIG.name && layer.rig != null
        if (!isRigLayer && layer.motionPath.size >= 2 && totalFrames > 1) {
            val progress = evaluateMotionPathProgress(layer, frame, totalFrames)
            val sample = sampleSmoothPath(layer.motionPath, progress)
            val anchor = computeLayerVisualCenter(layer, frame) ?: layer.motionPath.first()
            base = base.copy(
                x = base.x + (sample.position.x - anchor.x),
                y = base.y + (sample.position.y - anchor.y),
                rotationDeg = if (layer.motionPathOrientToPath) {
                    base.rotationDeg + sample.tangentAngleDeg
                } else {
                    base.rotationDeg
                }
            )
        }
        return base
    }

    fun evaluatePuppetRoot(rig: SkeletalRig, frame: Int): EvaluatedPuppetRoot {
        if (rig.rootKeyframes.isEmpty()) {
            return EvaluatedPuppetRoot(
                rootX = rig.rootX,
                rootY = rig.rootY,
                scale = rig.scale,
                flippedHorizontal = rig.flippedHorizontal,
                eyePack = rig.eyePack,
                mouthPhoneme = rig.mouthPhoneme,
                viewAngle = rig.viewAngle,
                scaleX = rig.scaleX,
                scaleY = rig.scaleY,
                eyebrowStyle = rig.eyebrowStyle,
                leftHandGesture = rig.leftHandGesture,
                rightHandGesture = rig.rightHandGesture,
                behaviorPreset = rig.behaviorPreset
            )
        }
        val sorted = rig.rootKeyframes.sortedBy { it.frame }
        return when {
            frame <= sorted.first().frame -> sorted.first().toEvaluated()
            frame >= sorted.last().frame -> sorted.last().toEvaluated()
            else -> {
                val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                val next = sorted[nextIdx]
                if (prev.frame == next.frame) {
                    next.toEvaluated()
                } else {
                    val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                    val eased = applyEasing(rawT, prev.easing)
                    EvaluatedPuppetRoot(
                        rootX = lerp(prev.rootX, next.rootX, eased),
                        rootY = lerp(prev.rootY, next.rootY, eased),
                        scale = lerp(prev.scale, next.scale, eased).coerceIn(0.1f, 10f),
                        flippedHorizontal = prev.flippedHorizontal,
                        eyePack = prev.eyePack,
                        mouthPhoneme = prev.mouthPhoneme,
                        viewAngle = prev.viewAngle,
                        scaleX = lerp(prev.scaleX, next.scaleX, eased).coerceIn(0.15f, 6f),
                        scaleY = lerp(prev.scaleY, next.scaleY, eased).coerceIn(0.15f, 6f),
                        eyebrowStyle = prev.eyebrowStyle,
                        leftHandGesture = prev.leftHandGesture,
                        rightHandGesture = prev.rightHandGesture,
                        behaviorPreset = prev.behaviorPreset
                    )
                }
            }
        }
    }

    /**
     * Evaluates a rigged puppet's root transform while smoothly gliding directly along [layer.motionPath]
     * AND applying Targeted Loop facial overrides (Talking/Crying/Laughing) + Auto-Dialogue Hand Gestures.
     */
    fun evaluatePuppetRootWithPath(
        layer: AnimationLayer,
        rig: SkeletalRig,
        frame: Int,
        totalFrames: Int,
        audioTracks: List<AudioTrackItem> = emptyList(),
        fps: Int = 24
    ): EvaluatedPuppetRoot {
        var result = evaluatePuppetRoot(rig, frame)
        if (layer.motionPath.size >= 2 && totalFrames > 1) {
            val progress = evaluateMotionPathProgress(layer, frame, totalFrames)
            val sample = sampleSmoothPath(layer.motionPath, progress)
            val shouldAutoFlip = (layer.motionPathOrientToPath || rig.autoWalkWhenDragged) && kotlin.math.abs(sample.dx) > 0.25f
            val autoFlipped = if (shouldAutoFlip) sample.dx < 0f else result.flippedHorizontal
            result = result.copy(
                rootX = sample.position.x,
                rootY = sample.position.y,
                flippedHorizontal = autoFlipped
            )
        }

        // Apply active Targeted Loop expression overrides inside selected frame ranges (Module 8)
        layer.targetedLoops.filter { frame in it.startFrame..it.endFrame }.forEach { clip ->
            when (runCatching { TargetedLoopType.valueOf(clip.loopType) }.getOrNull()) {
                TargetedLoopType.TALKING_LOOP -> {
                    result = result.copy(mouthPhoneme = MouthPhoneme.TALKING_LOOP.name)
                }
                TargetedLoopType.CRYING_LOOP -> {
                    result = result.copy(
                        eyePack = EyePackStyle.SAD_TEARS.name,
                        mouthPhoneme = MouthPhoneme.CRYING.name,
                        eyebrowStyle = EyebrowStyle.WORRIED.name
                    )
                }
                TargetedLoopType.LAUGHING_LOOP -> {
                    result = result.copy(
                        eyePack = EyePackStyle.LAUGHING.name,
                        mouthPhoneme = MouthPhoneme.LAUGHING.name
                    )
                }
                TargetedLoopType.HORROR_TWITCH -> {
                    result = result.copy(
                        eyePack = EyePackStyle.SCARED_HORROR.name,
                        mouthPhoneme = MouthPhoneme.SCARED.name
                    )
                }
                else -> Unit
            }
        }

        // Module 4 & 6: Auto-Dialogue Acting cycles natural open-palm / pointing hand gestures while speaking
        if (rig.autoDialogueActing) {
            val speakingFromAudio = audioTracks.isNotEmpty() &&
                evaluateLipSyncPhoneme(audioTracks, frame, fps) != MouthPhoneme.REST
            val speakingFromMouth = result.mouthPhoneme == MouthPhoneme.TALKING_LOOP.name
            if (speakingFromAudio || speakingFromMouth) {
                val gestureCycle = (frame / 14) % 3
                val autoRight = when (gestureCycle) {
                    0 -> HandGesturePose.OPEN_PALM.name
                    1 -> HandGesturePose.POINTING.name
                    else -> HandGesturePose.OPEN_PALM.name
                }
                val autoLeft = if (gestureCycle == 2) HandGesturePose.OPEN_PALM.name else result.leftHandGesture
                result = result.copy(rightHandGesture = autoRight, leftHandGesture = autoLeft)
            }
        }
        // Whole-Character Acting Behavior Preset root motion (floating hover, bouncy step, tremor)
        val activeMood = runCatching { CharacterBehaviorPreset.valueOf(result.behaviorPreset) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
        when (activeMood) {
            CharacterBehaviorPreset.HORROR_GHOSTLY -> {
                val hoverY = kotlin.math.sin(frame * 0.16).toFloat() * 14f
                val driftX = kotlin.math.cos(frame * 0.11).toFloat() * 4f
                result = result.copy(rootX = result.rootX + driftX, rootY = result.rootY + hoverY)
            }
            CharacterBehaviorPreset.HAPPY_PLAYFUL -> {
                val bounceY = -kotlin.math.abs(kotlin.math.sin(frame * 0.34).toFloat()) * 9f
                result = result.copy(rootY = result.rootY + bounceY)
            }
            CharacterBehaviorPreset.ELDERLY_WEAK -> {
                val tremorX = kotlin.math.sin(frame * 1.9).toFloat() * 1.1f
                result = result.copy(rootX = result.rootX + tremorX)
            }
            else -> Unit
        }

        return result
    }

    /**
     * Evaluates interpolated bone lengths (Module 2 Live Stretch Rig keyframes + Horror elongated limb tension).
     */
    fun evaluateBoneLengths(rig: SkeletalRig, frame: Int): Map<String, Float> {
        val mood = runCatching { CharacterBehaviorPreset.valueOf(evaluatePuppetRoot(rig, frame).behaviorPreset) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
        val defaultLengths = rig.bones.associate { bone ->
            val horrorTension = if (mood == CharacterBehaviorPreset.HORROR_GHOSTLY &&
                (bone.id == "arm_l_low" || bone.id == "arm_r_low" || bone.id == "hand_l" || bone.id == "hand_r" || bone.id == "neck")
            ) 1.18f else 1.0f
            bone.id to (bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f) * horrorTension)
        }
        if (rig.boneLengthKeyframes.isEmpty()) return defaultLengths

        val sortedFrames = rig.boneLengthKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        if (sortedFrames.isEmpty()) return defaultLengths

        rig.boneLengthKeyframes[frame.toString()]?.let { exact ->
            return defaultLengths + exact
        }

        return when {
            frame < sortedFrames.first() -> defaultLengths + (rig.boneLengthKeyframes[sortedFrames.first().toString()] ?: emptyMap())
            frame > sortedFrames.last() -> defaultLengths + (rig.boneLengthKeyframes[sortedFrames.last().toString()] ?: emptyMap())
            else -> {
                val nextIdx = sortedFrames.indexOfFirst { it >= frame }
                val prevF = sortedFrames[(nextIdx - 1).coerceAtLeast(0)]
                val nextF = sortedFrames[nextIdx]
                val prevMap = rig.boneLengthKeyframes[prevF.toString()] ?: emptyMap()
                val nextMap = rig.boneLengthKeyframes[nextF.toString()] ?: emptyMap()
                val t = applyEasing((frame - prevF).toFloat() / (nextF - prevF).coerceAtLeast(1).toFloat(), EasingType.EASE_IN_OUT.name)
                rig.bones.associate { bone ->
                    val baseLen = defaultLengths[bone.id] ?: (bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f))
                    val a = prevMap[bone.id] ?: baseLen
                    val b = nextMap[bone.id] ?: baseLen
                    bone.id to lerp(a, b, t).coerceIn(8f, 420f)
                }
            }
        }
    }

    /**
     * Evaluates active per-bone Z-Order (Front/Back draw order) at [frame].
     * Uses clean step-hold between Z-order keyframes so limbs switch front/back on exact frames without flickering.
     */
    fun evaluateBoneZOrders(rig: SkeletalRig, frame: Int): Map<String, Int> {
        val base = rig.bones.associate { it.id to it.zOrder }
        if (rig.boneZOrderKeyframes.isEmpty()) return base
        val sortedFrames = rig.boneZOrderKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        if (sortedFrames.isEmpty()) return base

        rig.boneZOrderKeyframes[frame.toString()]?.let { exact ->
            return base + exact
        }
        val activeKf = sortedFrames.lastOrNull { it <= frame } ?: return base
        return base + (rig.boneZOrderKeyframes[activeKf.toString()] ?: emptyMap())
    }

    fun getBoneZOrderKeyframeFrames(rig: SkeletalRig): Set<Int> {
        return rig.boneZOrderKeyframes.keys.mapNotNull { it.toIntOrNull() }.toSet()
    }

    /**
     * Evaluates bone angles for a rigged puppet, smoothly layering automatic walk/flap cycles along [layer.motionPath],
     * Targeted Action Loops (Auto-Walk, Idle Breathing, Horror Twitch), and Auto-Dialogue head-bobbing & arm acting!
     */
    fun evaluateRigAnglesWithPath(
        layer: AnimationLayer,
        rig: SkeletalRig,
        frame: Int,
        totalFrames: Int,
        audioTracks: List<AudioTrackItem> = emptyList(),
        fps: Int = 24
    ): Map<String, Float> {
        var angles = evaluateRigAngles(rig, frame)
        val existingIds = rig.bones.map { it.id }.toSet()

        // Apply posture slouch from CharacterSpec if configured (Module 4)
        val slouch = rig.characterAppearance?.postureSlouch?.coerceIn(0f, 1f) ?: 0f
        if (slouch > 0.02f && "spine" in existingIds) {
            angles = angles + ("spine" to ((angles["spine"] ?: -90f) + slouch * 22f))
            if ("neck" in existingIds) {
                angles = angles + ("neck" to ((angles["neck"] ?: 0f) - slouch * 14f))
            }
        }

        val evalRoot = evaluatePuppetRoot(rig, frame)
        val activeMood = runCatching { CharacterBehaviorPreset.valueOf(evalRoot.behaviorPreset) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)

        if (layer.motionPath.size >= 2 && totalFrames > 1 && rig.autoWalkWhenDragged && rig.poseKeyframes.size < 2) {
            val progress = evaluateMotionPathProgress(layer, frame, totalFrames)
            val sample = sampleSmoothPath(layer.motionPath, progress)
            if (sample.totalLength >= 4f) {
                angles = when (rig.rigCategory) {
                    "BIRD" -> {
                        val phase = (sample.distanceTraveled / 34f).toDouble()
                        val flap = kotlin.math.sin(phase).toFloat()
                        angles + mapOf(
                            "wing_l_in" to (-90f + flap * 52f),
                            "wing_l_tip" to (-15f + flap * 28f),
                            "wing_r_in" to (-90f - flap * 52f),
                            "wing_r_tip" to (15f - flap * 28f),
                            "tail_base" to (165f + flap * 10f)
                        ).filterKeys { it in existingIds }
                    }
                    "QUADRUPED" -> {
                        val phase = (sample.distanceTraveled / 38f).toDouble()
                        val swing = kotlin.math.sin(phase).toFloat()
                        angles + mapOf(
                            "leg_fl_up" to (82f + swing * 28f),
                            "leg_fr_up" to (98f - swing * 28f),
                            "leg_bl_up" to (104f - swing * 28f),
                            "leg_br_up" to (86f + swing * 28f),
                            "tail_base" to (-145f + swing * 16f)
                        ).filterKeys { it in existingIds }
                    }
                    else -> {
                        val walkPose = RigSolver.computeAutoWalkPose(sample.distanceTraveled, activeMood.name)
                        angles + walkPose.filterKeys { it in existingIds }
                    }
                }
            }
        }

        // Apply Targeted Loop body motion inside selected frame ranges (Module 8)
        layer.targetedLoops.filter { frame in it.startFrame..it.endFrame }.forEach { clip ->
            val localF = frame - clip.startFrame
            when (runCatching { TargetedLoopType.valueOf(clip.loopType) }.getOrNull()) {
                TargetedLoopType.AUTO_WALK -> {
                    val walkPose = RigSolver.computeAutoWalkPose(localF * 16f, activeMood.name)
                    angles = angles + walkPose.filterKeys { it in existingIds }
                }
                TargetedLoopType.IDLE_BREATHING -> {
                    val breath = kotlin.math.sin(localF * 0.24).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("spine" in existingIds) delta["spine"] = (angles["spine"] ?: -90f) + breath * 2.5f
                    if ("neck" in existingIds) delta["neck"] = (angles["neck"] ?: 0f) - breath * 2.2f
                    if ("arm_l_up" in existingIds) delta["arm_l_up"] = (angles["arm_l_up"] ?: -138f) - breath * 3.5f
                    if ("arm_r_up" in existingIds) delta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) + breath * 3.5f
                    angles = angles + delta
                }
                TargetedLoopType.HORROR_TWITCH -> {
                    val jitter = if (localF % 7 == 0 || localF % 11 == 0) 24f else kotlin.math.sin(localF * 1.4).toFloat() * 7f
                    val delta = mutableMapOf<String, Float>()
                    if ("neck" in existingIds) delta["neck"] = (angles["neck"] ?: 0f) + jitter
                    if ("arm_l_low" in existingIds) delta["arm_l_low"] = (angles["arm_l_low"] ?: 22f) + jitter * 0.6f
                    if ("arm_r_low" in existingIds) delta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - jitter * 0.6f
                    angles = angles + delta
                }
                else -> Unit
            }
        }

        // Whole-Character Acting Behavior Preset continuous idle/mood body language!
        val moodDelta = mutableMapOf<String, Float>()
        when (activeMood) {
            CharacterBehaviorPreset.NORMAL_CALM -> Unit
            CharacterBehaviorPreset.ANGRY_STRICT -> {
                val jab = kotlin.math.sin(frame * 0.45).toFloat()
                if ("spine" in existingIds) moodDelta["spine"] = (angles["spine"] ?: -90f) + 6f
                if ("neck" in existingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) - 5f + jab * 3f
                if ("arm_r_up" in existingIds) moodDelta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) - 18f + jab * 8f
                if ("arm_r_low" in existingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 24f + jab * 14f
            }
            CharacterBehaviorPreset.HORROR_GHOSTLY -> {
                val twitch = if (frame % 9 == 0 || frame % 13 == 0) 18f else kotlin.math.sin(frame * 0.7).toFloat() * 5f
                val floatSway = kotlin.math.sin(frame * 0.18).toFloat()
                if ("neck" in existingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) + 10f + twitch
                if ("arm_l_up" in existingIds) moodDelta["arm_l_up"] = (angles["arm_l_up"] ?: -138f) + 18f + floatSway * 10f
                if ("arm_r_up" in existingIds) moodDelta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) - 18f - floatSway * 10f
                if ("arm_l_low" in existingIds) moodDelta["arm_l_low"] = (angles["arm_l_low"] ?: 22f) + twitch * 0.45f
                if ("arm_r_low" in existingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - twitch * 0.45f
            }
            CharacterBehaviorPreset.HAPPY_PLAYFUL -> {
                val wave = kotlin.math.sin(frame * 0.42).toFloat()
                if ("neck" in existingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) + wave * 7f
                if ("arm_r_up" in existingIds) moodDelta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) - 42f + wave * 12f
                if ("arm_r_low" in existingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 38f + wave * 24f
            }
            CharacterBehaviorPreset.ELDERLY_WEAK -> {
                val tremor = kotlin.math.sin(frame * 2.1).toFloat() * 2.6f
                if ("spine" in existingIds) moodDelta["spine"] = (angles["spine"] ?: -90f) + 16f
                if ("neck" in existingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) - 11f + tremor
                if ("arm_l_low" in existingIds) moodDelta["arm_l_low"] = (angles["arm_l_low"] ?: 22f) + 14f + tremor
                if ("arm_r_low" in existingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 14f - tremor
            }
        }
        if (moodDelta.isNotEmpty()) angles = angles + moodDelta

        // Module 6: Auto-Dialogue Acting subtle head-bobbing + conversational arm cadence when voice speaks
        if (rig.autoDialogueActing) {
            val speaking = (audioTracks.isNotEmpty() && evaluateLipSyncPhoneme(audioTracks, frame, fps) != MouthPhoneme.REST) ||
                rig.mouthPhoneme == MouthPhoneme.TALKING_LOOP.name ||
                layer.targetedLoops.any { frame in it.startFrame..it.endFrame && it.loopType == TargetedLoopType.TALKING_LOOP.name }
            if (speaking) {
                val bob = kotlin.math.sin(frame * 0.55).toFloat()
                val gestureWave = kotlin.math.sin(frame * 0.28).toFloat()
                val delta = mutableMapOf<String, Float>()
                if ("neck" in existingIds) delta["neck"] = (angles["neck"] ?: 0f) + bob * 6.5f
                if ("arm_r_low" in existingIds) delta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 18f + gestureWave * 14f
                angles = angles + delta
            }
        }
        return angles
    }

    fun evaluateCamera(scene: AnimationScene, frame: Int, projectWidth: Float = 1280f, projectHeight: Float = 720f): EvaluatedCamera {
        val sorted = scene.cameraKeyframes.sortedBy { it.frame }
        val baseCam = if (sorted.isEmpty()) {
            EvaluatedCamera()
        } else {
            when {
                frame <= sorted.first().frame -> sorted.first().toEvaluated()
                frame >= sorted.last().frame -> sorted.last().toEvaluated()
                else -> {
                    val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                    val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                    val next = sorted[nextIdx]
                    if (prev.frame == next.frame) {
                        next.toEvaluated()
                    } else {
                        val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                        val eased = applyEasing(rawT, prev.easing)
                        EvaluatedCamera(
                            panX = lerp(prev.panX, next.panX, eased),
                            panY = lerp(prev.panY, next.panY, eased),
                            zoom = lerp(prev.zoom, next.zoom, eased).coerceIn(0.25f, 4f),
                            rotationDeg = lerp(prev.rotationDeg, next.rotationDeg, eased)
                        )
                    }
                }
            }
        }

        // Module 9: Camera Follow Character tracks the target layer/puppet smoothly!
        val followId = scene.cameraFollowLayerId
        if (!followId.isNullOrBlank()) {
            val targetLayer = scene.layers.firstOrNull { it.id == followId }
            if (targetLayer != null) {
                val targetPos = if (targetLayer.rig != null) {
                    val pRoot = evaluatePuppetRootWithPath(targetLayer, targetLayer.rig, frame, scene.durationFrames)
                    Vec2(pRoot.rootX, pRoot.rootY - 40f * pRoot.scale)
                } else {
                    val tf = evaluateLayerTransform(targetLayer, frame, scene.durationFrames)
                    val center = computeLayerVisualCenter(targetLayer, frame) ?: Vec2(projectWidth / 2f, projectHeight / 2f)
                    Vec2(center.x + tf.x, center.y + tf.y)
                }
                return baseCam.copy(
                    panX = baseCam.panX + (targetPos.x - projectWidth / 2f) * 0.85f,
                    panY = baseCam.panY + (targetPos.y - projectHeight / 2f) * 0.65f
                )
            }
        }
        return baseCam
    }

    fun evaluateRigAngles(rig: SkeletalRig, frame: Int): Map<String, Float> {
        val defaultAngles = rig.bones.associate { it.id to it.localAngleDeg }
        if (rig.poseKeyframes.isEmpty()) return defaultAngles

        val sortedFrames = rig.poseKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        if (sortedFrames.isEmpty()) return defaultAngles

        val exact = rig.poseKeyframes[frame.toString()]
        if (exact != null) return defaultAngles + exact

        return when {
            frame < sortedFrames.first() -> defaultAngles + (rig.poseKeyframes[sortedFrames.first().toString()] ?: emptyMap())
            frame > sortedFrames.last() -> defaultAngles + (rig.poseKeyframes[sortedFrames.last().toString()] ?: emptyMap())
            else -> {
                val nextIdx = sortedFrames.indexOfFirst { it >= frame }
                val prevF = sortedFrames[(nextIdx - 1).coerceAtLeast(0)]
                val nextF = sortedFrames[nextIdx]
                val prevMap = rig.poseKeyframes[prevF.toString()] ?: emptyMap()
                val nextMap = rig.poseKeyframes[nextF.toString()] ?: emptyMap()
                val t = applyEasing((frame - prevF).toFloat() / (nextF - prevF).coerceAtLeast(1).toFloat(), EasingType.EASE_IN_OUT.name)
                rig.bones.associate { bone ->
                    val a = prevMap[bone.id] ?: bone.localAngleDeg
                    val b = nextMap[bone.id] ?: bone.localAngleDeg
                    bone.id to lerpAngle(a, b, t)
                }
            }
        }
    }

    /**
     * Evaluates voiceover audio waveform energy at [frame] to drive Auto Lip-Sync talking mouths.
     */
    fun evaluateLipSyncPhoneme(
        audioTracks: List<AudioTrackItem>,
        frame: Int,
        fps: Int
    ): MouthPhoneme {
        val voiceTracks = audioTracks.filter { !it.muted && it.waveformPeaks.isNotEmpty() }
            .sortedByDescending { it.kind == AudioTrackKind.VOICE.name }
        if (voiceTracks.isEmpty()) return MouthPhoneme.REST

        var maxEnergy = 0f
        for (track in voiceTracks) {
            val clipFrames = (((track.trimEndMs - track.trimStartMs).coerceAtLeast(200L) / 1000f) * fps.coerceAtLeast(1)).toInt().coerceAtLeast(1)
            if (frame >= track.startFrame && frame < track.startFrame + clipFrames) {
                val rel = (frame - track.startFrame).toFloat() / clipFrames.toFloat()
                val idx = (rel * track.waveformPeaks.size).toInt().coerceIn(0, track.waveformPeaks.lastIndex)
                val energy = track.waveformPeaks[idx] * track.volume
                if (energy > maxEnergy) maxEnergy = energy
            }
        }
        return when {
            maxEnergy < 0.14f -> MouthPhoneme.REST
            maxEnergy < 0.30f -> if (frame % 2 == 0) MouthPhoneme.I else MouthPhoneme.U
            maxEnergy < 0.52f -> if (frame % 3 == 0) MouthPhoneme.E else MouthPhoneme.O
            else -> MouthPhoneme.A
        }
    }

    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        var diff = (b - a) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return a + diff * t
    }

    fun resolveFrameContent(layer: AnimationLayer, frame: Int, holdPrevious: Boolean = true): FrameContent? {
        layer.frames[frame.toString()]?.let { return it }
        // Module 7: Frame-by-Frame Cel Studio layers automatically hide previous frame's solid drawing!
        if (!holdPrevious || layer.isCelFrameByFrame) return null
        val prevKey = layer.frames.keys
            .mapNotNull { it.toIntOrNull() }
            .filter { it < frame }
            .maxOrNull() ?: return null
        return layer.frames[prevKey.toString()]
    }

    /**
     * Generates dense Catmull-Rom spline points from user control waypoints for butter-smooth motion curves.
     */
    fun buildSmoothSplinePoints(points: List<Vec2>, subdivisionsPerSegment: Int = 12): List<Vec2> {
        if (points.size <= 2) return points
        val out = ArrayList<Vec2>((points.size - 1) * subdivisionsPerSegment + 1)
        val n = points.size
        for (i in 0 until n - 1) {
            val p0 = points[(i - 1).coerceAtLeast(0)]
            val p1 = points[i]
            val p2 = points[i + 1]
            val p3 = points[(i + 2).coerceAtMost(n - 1)]
            val steps = subdivisionsPerSegment.coerceAtLeast(2)
            for (s in 0 until steps) {
                val u = s.toFloat() / steps.toFloat()
                out.add(evalCatmullRom(p0, p1, p2, p3, u))
            }
        }
        out.add(points.last())
        return out
    }

    private fun evalCatmullRom(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2, t: Float): Vec2 {
        val t2 = t * t
        val t3 = t2 * t
        val x = 0.5f * (
            (2f * p1.x) +
                (-p0.x + p2.x) * t +
                (2f * p0.x - 5f * p1.x + 4f * p2.x - p3.x) * t2 +
                (-p0.x + 3f * p1.x - 3f * p2.x + p3.x) * t3
            )
        val y = 0.5f * (
            (2f * p1.y) +
                (-p0.y + p2.y) * t +
                (2f * p0.y - 5f * p1.y + 4f * p2.y - p3.y) * t2 +
                (-p0.y + 3f * p1.y - 3f * p2.y + p3.y) * t3
            )
        return Vec2(x, y)
    }

    /**
     * Arc-length parameterized Catmull-Rom smooth spline sampler.
     * Guarantees constant, jitter-free velocity along curves + smooth tangent angle & arc distance.
     */
    fun sampleSmoothPath(points: List<Vec2>, t: Float): PathSample {
        if (points.isEmpty()) return PathSample(Vec2(0f, 0f), 0f, 0f, 0f, 1f, 0f)
        if (points.size == 1) return PathSample(points.first(), 0f, 0f, 0f, 1f, 0f)
        val dense = buildSmoothSplinePoints(points, subdivisionsPerSegment = 14)
        val lengths = FloatArray(dense.size - 1)
        var total = 0f
        for (i in 0 until dense.size - 1) {
            val d = hypot(dense[i + 1].x - dense[i].x, dense[i + 1].y - dense[i].y)
            lengths[i] = d
            total += d
        }
        if (total <= 0.001f) return PathSample(dense.first(), 0f, 0f, 0f, 1f, 0f)
        val clampedT = t.coerceIn(0f, 1f)
        val target = total * clampedT
        var acc = 0f
        for (i in lengths.indices) {
            if (acc + lengths[i] >= target || i == lengths.lastIndex) {
                val segLen = lengths[i]
                val segT = if (segLen > 0.0001f) ((target - acc) / segLen).coerceIn(0f, 1f) else 0f
                val pos = Vec2(
                    lerp(dense[i].x, dense[i + 1].x, segT),
                    lerp(dense[i].y, dense[i + 1].y, segT)
                )
                val dx = dense[i + 1].x - dense[i].x
                val dy = dense[i + 1].y - dense[i].y
                val tangent = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                return PathSample(
                    position = pos,
                    tangentAngleDeg = tangent,
                    distanceTraveled = target,
                    totalLength = total,
                    dx = dx,
                    dy = dy
                )
            }
            acc += lengths[i]
        }
        val lastDx = dense.last().x - dense[dense.lastIndex - 1].x
        val lastDy = dense.last().y - dense[dense.lastIndex - 1].y
        return PathSample(
            position = dense.last(),
            tangentAngleDeg = Math.toDegrees(kotlin.math.atan2(lastDy.toDouble(), lastDx.toDouble())).toFloat(),
            distanceTraveled = total,
            totalLength = total,
            dx = lastDx,
            dy = lastDy
        )
    }

    fun samplePolyline(points: List<Vec2>, t: Float): Vec2 {
        return sampleSmoothPath(points, t).position
    }

    /**
     * Computes horizontal background auto-scroll shift matching SceneRenderer.drawLayerAtFrame.
     */
    fun computeBgScrollShiftX(
        layer: AnimationLayer,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Float
    ): Float {
        if (layer.type != LayerType.BACKGROUND.name || scene.backgroundScrollSpeed == 0f || projectWidth <= 0f) {
            return 0f
        }
        val raw = -(frame * scene.backgroundScrollSpeed * 2.5f * layer.parallaxDepth)
        return ((raw % projectWidth) + projectWidth) % projectWidth - projectWidth * 0.5f
    }

    /**
     * Exact forward transform from Layer local coordinates to Compose Canvas pixel coordinates.
     * Matches CanvasStage viewport + SceneRenderer.applyCameraTransform + drawLayerAtFrame 1:1.
     */
    fun layerLocalToCanvasPx(
        localPt: Vec2,
        projectWidth: Float,
        projectHeight: Float,
        originX: Float,
        originY: Float,
        totalScale: Float,
        camera: EvaluatedCamera,
        parallax: Float,
        layerTransform: EvaluatedTransform,
        bgAutoShiftX: Float = 0f
    ): Vec2 {
        val halfW = projectWidth / 2f
        val halfH = projectHeight / 2f

        // 1. Layer transform around stage center
        val lx1 = (localPt.x - halfW) * layerTransform.scaleX
        val ly1 = (localPt.y - halfH) * layerTransform.scaleY
        val radL = Math.toRadians(layerTransform.rotationDeg.toDouble())
        val cosL = kotlin.math.cos(radL)
        val sinL = kotlin.math.sin(radL)
        val lx2 = (lx1 * cosL - ly1 * sinL).toFloat()
        val ly2 = (lx1 * sinL + ly1 * cosL).toFloat()
        val worldX = lx2 + halfW + layerTransform.x + bgAutoShiftX
        val worldY = ly2 + halfH + layerTransform.y

        // 2. Camera transform with layer parallax
        val effZoom = (1f + (camera.zoom - 1f) * parallax).coerceAtLeast(0.05f)
        val cx1 = (worldX - halfW - camera.panX * parallax) * effZoom
        val cy1 = (worldY - halfH - camera.panY * parallax) * effZoom
        val radC = Math.toRadians(camera.rotationDeg.toDouble())
        val cosC = kotlin.math.cos(radC)
        val sinC = kotlin.math.sin(radC)
        val stageX = (cx1 * cosC - cy1 * sinC).toFloat() + halfW
        val stageY = (cx1 * sinC + cy1 * cosC).toFloat() + halfH

        // 3. Stage viewport transform to raw Canvas pixels
        return Vec2(
            x = stageX * totalScale + originX,
            y = stageY * totalScale + originY
        )
    }

    /**
     * Exact inverse transform from Compose Canvas pixel coordinates to Stage World coordinates (accounting for parallax).
     */
    fun canvasPxToStageWorld(
        canvasPxX: Float,
        canvasPxY: Float,
        projectWidth: Float,
        projectHeight: Float,
        originX: Float,
        originY: Float,
        totalScale: Float,
        camera: EvaluatedCamera,
        parallax: Float = 1f
    ): Vec2 {
        val safeScale = totalScale.coerceAtLeast(0.0001f)
        val stageX = (canvasPxX - originX) / safeScale
        val stageY = (canvasPxY - originY) / safeScale
        val halfW = projectWidth / 2f
        val halfH = projectHeight / 2f

        val dx = stageX - halfW
        val dy = stageY - halfH
        val radCInv = Math.toRadians((-camera.rotationDeg).toDouble())
        val cosC = kotlin.math.cos(radCInv)
        val sinC = kotlin.math.sin(radCInv)
        val effZoom = (1f + (camera.zoom - 1f) * parallax).coerceAtLeast(0.05f)
        val rx = (dx * cosC - dy * sinC).toFloat() / effZoom
        val ry = (dx * sinC + dy * cosC).toFloat() / effZoom
        return Vec2(
            x = rx + halfW + camera.panX * parallax,
            y = ry + halfH + camera.panY * parallax
        )
    }

    /**
     * Exact mathematical inverse of [layerLocalToCanvasPx].
     * Guarantees finger touches land at the exact drawn pixel even when zoomed, panned, rotated, or on parallax/transformed layers.
     */
    fun canvasPxToLayerLocal(
        canvasPxX: Float,
        canvasPxY: Float,
        projectWidth: Float,
        projectHeight: Float,
        originX: Float,
        originY: Float,
        totalScale: Float,
        camera: EvaluatedCamera,
        parallax: Float,
        layerTransform: EvaluatedTransform,
        bgAutoShiftX: Float = 0f
    ): Vec2 {
        val world = canvasPxToStageWorld(
            canvasPxX = canvasPxX,
            canvasPxY = canvasPxY,
            projectWidth = projectWidth,
            projectHeight = projectHeight,
            originX = originX,
            originY = originY,
            totalScale = totalScale,
            camera = camera,
            parallax = parallax
        )
        val halfW = projectWidth / 2f
        val halfH = projectHeight / 2f

        val tx = world.x - (halfW + layerTransform.x + bgAutoShiftX)
        val ty = world.y - (halfH + layerTransform.y)
        val radLInv = Math.toRadians((-layerTransform.rotationDeg).toDouble())
        val cosL = kotlin.math.cos(radLInv)
        val sinL = kotlin.math.sin(radLInv)
        val rx = (tx * cosL - ty * sinL).toFloat()
        val ry = (tx * sinL + ty * cosL).toFloat()

        val sx = if (kotlin.math.abs(layerTransform.scaleX) < 0.001f) {
            if (layerTransform.scaleX < 0f) -0.001f else 0.001f
        } else layerTransform.scaleX
        val sy = if (kotlin.math.abs(layerTransform.scaleY) < 0.001f) {
            if (layerTransform.scaleY < 0f) -0.001f else 0.001f
        } else layerTransform.scaleY

        return Vec2(
            x = rx / sx + halfW,
            y = ry / sy + halfH
        )
    }

    private fun TransformKeyframe.toEvaluated() = EvaluatedTransform(
        x = x, y = y, rotationDeg = rotationDeg, scaleX = scaleX, scaleY = scaleY, opacity = opacity
    )

    private fun CameraKeyframe.toEvaluated() = EvaluatedCamera(
        panX = panX, panY = panY, zoom = zoom, rotationDeg = rotationDeg
    )

    private fun PuppetRootKeyframe.toEvaluated() = EvaluatedPuppetRoot(
        rootX = rootX,
        rootY = rootY,
        scale = scale,
        flippedHorizontal = flippedHorizontal,
        eyePack = eyePack,
        mouthPhoneme = mouthPhoneme,
        viewAngle = viewAngle,
        scaleX = scaleX,
        scaleY = scaleY,
        eyebrowStyle = eyebrowStyle,
        leftHandGesture = leftHandGesture,
        rightHandGesture = rightHandGesture,
        behaviorPreset = behaviorPreset
    )
}
