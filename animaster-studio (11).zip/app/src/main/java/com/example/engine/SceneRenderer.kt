package com.example.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.util.LruCache
import android.graphics.BlurMaskFilter
import android.graphics.PorterDuffXfermode
import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FrameContent
import com.example.data.model.HandGesturePose
import com.example.data.model.HandPropKind
import com.example.data.model.ImportedImageItem
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PartBehaviorPreset
import com.example.data.model.RigBone
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneVfxType
import com.example.data.model.ShapeKind
import com.example.data.model.SkeletalRig
import com.example.data.model.SubtitleCue
import com.example.data.model.SubtitleStyle
import com.example.data.model.TextBoxStyle
import com.example.data.model.TextFontStyle
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.TextOutAnimation
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Deterministic high-performance 2D Canvas renderer shared between the live editor,
 * Character & Rig Studio, and the offline PNG / GIF / MP4 / WebM export pipeline.
 */
object SceneRenderer {

    private val bitmapCache = object : LruCache<String, Bitmap>(32) {}
    private val videoFrameCache = object : LruCache<String, Bitmap>(16) {}

    private const val MAX_BITMAP_DIM = 2048

    fun getCachedBitmap(path: String): Bitmap? {
        if (path.isBlank()) return null
        bitmapCache.get(path)?.let { if (!it.isRecycled) return it }
        val file = File(path)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        return runCatching {
            // Module 10: OOM-safe bounds check + power-of-2 downsampling capped at 2048px
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, boundsOpts)
            val rawW = boundsOpts.outWidth
            val rawH = boundsOpts.outHeight
            if (rawW <= 0 || rawH <= 0) return@runCatching null
            var sampleSize = 1
            while ((rawW / sampleSize) > MAX_BITMAP_DIM || (rawH / sampleSize) > MAX_BITMAP_DIM) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inSampleSize = sampleSize
            }
            BitmapFactory.decodeFile(path, decodeOpts)?.also { bitmapCache.put(path, it) }
        }.getOrNull()
    }

    private fun getCachedVideoFrame(path: String, timeUs: Long): Bitmap? {
        if (path.isBlank()) return null
        val file = File(path)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        // Bucket video frame lookups to 100ms intervals for smooth scrubbing performance
        val bucketUs = (timeUs / 100_000L) * 100_000L
        val key = "$path@$bucketUs"
        videoFrameCache.get(key)?.let { if (!it.isRecycled) return it }
        return runCatching {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(path)
                val bmp = mmr.getFrameAtTime(bucketUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                bmp?.also { videoFrameCache.put(key, it) }
            } finally {
                runCatching { mmr.release() }
            }
        }.getOrNull()
    }

    fun renderSceneToBitmap(
        scene: AnimationScene,
        frame: Int,
        outWidth: Int,
        outHeight: Int,
        projectWidth: Int,
        projectHeight: Int,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = false,
        showMotionPaths: Boolean = false,
        selectedLayerId: String? = null,
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false
    ): Bitmap {
        val bmp = Bitmap.createBitmap(outWidth.coerceAtLeast(16), outHeight.coerceAtLeast(16), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (transparentBackground && !chromaKeyGreen) {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        }
        val sx = outWidth.toFloat() / projectWidth.toFloat()
        val sy = outHeight.toFloat() / projectHeight.toFloat()
        canvas.scale(sx, sy)
        renderScene(
            canvas = canvas,
            scene = scene,
            frame = frame,
            projectWidth = projectWidth.toFloat(),
            projectHeight = projectHeight.toFloat(),
            fps = fps,
            audioTracks = audioTracks,
            onionSkin = onionSkin,
            ghostFrames = ghostFrames,
            showRigBones = showRigBones,
            showMotionPaths = showMotionPaths,
            showSelectionBox = false,
            selectedLayerId = if (showRigBones) selectedLayerId else null,
            selectedBoneId = null,
            selectedTextId = null,
            transparentBackground = transparentBackground,
            chromaKeyGreen = chromaKeyGreen
        )
        return bmp
    }

    fun renderScene(
        canvas: Canvas,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Float,
        projectHeight: Float,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = true,
        showMotionPaths: Boolean = true,
        showSelectionBox: Boolean = false,
        showCameraFrame: Boolean = false,
        selectedLayerId: String? = null,
        selectedBoneId: String? = null,
        selectedTextId: String? = null,
        activePreviewStroke: DrawStroke? = null,
        activePreviewShape: VectorShape? = null,
        activePreviewMotionPath: List<Vec2>? = null,
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false,
        celOnionNext: Boolean = true,
        celOnionOpacity: Float = 0.34f
    ) {
        val camera = InterpolationEngine.evaluateCamera(scene, frame, projectWidth, projectHeight)

        // 1. Background (with automatic continuous scroll + optional Background Depth Blur)
        val scrollOffsetX = frame * scene.backgroundScrollSpeed * 2.5f
        val bgPanX = camera.panX * 0.35f + scrollOffsetX
        val bgPanY = camera.panY * 0.35f
        if (chromaKeyGreen) {
            canvas.drawColor(Color.rgb(0, 255, 0))
        } else if (!transparentBackground) {
            drawBackgroundTemplate(
                canvas = canvas,
                templateName = scene.backgroundTemplate,
                bgColorArgb = scene.backgroundColorArgb,
                w = projectWidth,
                h = projectHeight,
                panX = bgPanX,
                panY = bgPanY,
                frame = frame
            )
            // Soft atmospheric Depth-of-Field blur veil when Background Depth Blur > 0
            if (scene.backgroundDepthBlur > 0.02f) {
                val blurStrength = scene.backgroundDepthBlur.coerceIn(0f, 1f)
                val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(
                        projectWidth * 0.5f,
                        projectHeight * 0.45f,
                        hypot(projectWidth, projectHeight) * 0.7f,
                        Color.argb((blurStrength * 42f).toInt(), 255, 255, 255),
                        Color.argb((blurStrength * 115f).toInt(), 15, 23, 42),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, projectWidth, projectHeight, veilPaint)
            }
        }

        // Visible layers at this exact frame (respecting Module 8 Frame-Range Visibility!)
        val activeVisibleLayers = scene.layers.filter { layer ->
            layer.visible && InterpolationEngine.isLayerVisibleAtFrame(layer, frame)
        }

        // 2. Onion-Skin Watermark Trail (both Standard Studio AND Module 7 Cel Studio Auto-Hide Onion Watermark)
        if (onionSkin || ghostFrames) {
            val offsets = if (ghostFrames) listOf(-3, -2, -1, 1, 2) else if (celOnionNext) listOf(-1, 1) else listOf(-1)
            for (delta in offsets) {
                val targetF = frame + delta
                if (targetF in 0 until scene.durationFrames) {
                    scene.layers.filter {
                        it.visible && it.type != LayerType.VIDEO.name &&
                            InterpolationEngine.isLayerVisibleAtFrame(it, targetF)
                    }.forEach { layer ->
                        val isCel = layer.isCelFrameByFrame
                        val alpha = when {
                            isCel && delta == -1 -> celOnionOpacity.coerceIn(0.12f, 0.65f)
                            isCel && delta == 1 -> (celOnionOpacity * 0.72f).coerceIn(0.10f, 0.50f)
                            kotlin.math.abs(delta) == 1 -> 0.25f
                            else -> 0.14f
                        }
                        val tint = when {
                            isCel && delta < 0 -> 0xFFFB7185L // Rose-red previous cel watermark
                            isCel && delta > 0 -> 0xFF22D3EEL // Cyan next cel watermark
                            delta < 0 -> 0xFFA78BFAL
                            else -> 0xFF2DD4BFL
                        }
                        drawLayerAtFrame(
                            canvas = canvas,
                            scene = scene,
                            layer = layer,
                            frame = targetF,
                            fps = fps,
                            audioTracks = audioTracks,
                            camera = camera,
                            projectWidth = projectWidth,
                            projectHeight = projectHeight,
                            overrideAlpha = alpha,
                            tintColorArgb = tint,
                            showRigOverlay = showRigBones && !isCel,
                            isSelectedLayer = false,
                            selectedBoneId = null,
                            maskLayerBelow = null,
                            allowEffects = false
                        )
                    }
                }
            }
        }

        // 3. Current Frame Layers (Mid-ground -> Multi-Plane Foreground Props -> Foreground Overlays)
        val midLayers = activeVisibleLayers.filter { it.parallaxDepth <= 1.15f }
        val foreLayers = activeVisibleLayers.filter { it.parallaxDepth > 1.15f }

        fun renderLayerList(list: List<AnimationLayer>, allOrdered: List<AnimationLayer>) {
            list.forEach { layer ->
                val isSel = layer.id == selectedLayerId
                val idxInAll = allOrdered.indexOfFirst { it.id == layer.id }
                val belowLayer = if (layer.maskToLayerBelow && idxInAll > 0) allOrdered[idxInAll - 1] else null

                drawLayerAtFrame(
                    canvas = canvas,
                    scene = scene,
                    layer = layer,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    camera = camera,
                    projectWidth = projectWidth,
                    projectHeight = projectHeight,
                    overrideAlpha = null,
                    tintColorArgb = null,
                    showRigOverlay = showRigBones,
                    isSelectedLayer = isSel,
                    selectedBoneId = if (isSel) selectedBoneId else null,
                    maskLayerBelow = belowLayer,
                    allowEffects = true
                )

                // Direct On-Canvas Touch Handles for ANY selected layer (Characters, Rigs, PNGs, Props, Drawings) in SELECT mode
                if (showSelectionBox && isSel) {
                    val bounds = computeLayerBounds(layer, frame, scene.durationFrames, projectWidth, projectHeight)
                    if (bounds != null) {
                        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
                        canvas.save()
                        applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)
                        drawSelectionTouchHandles(canvas, bounds, tf.rotationDeg, layer.pivotMode)
                        canvas.restore()
                    }
                }

                if (showMotionPaths && layer.motionPath.size >= 2) {
                    canvas.save()
                    applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)
                    drawMotionPathOverlay(
                        canvas = canvas,
                        points = layer.motionPath,
                        isSelected = isSel,
                        currentProgress = InterpolationEngine.evaluateMotionPathProgress(layer, frame, scene.durationFrames)
                    )
                    canvas.restore()
                }
            }
        }

        renderLayerList(midLayers, activeVisibleLayers)

        // 3b. Multi-Plane Foreground Architecture / Trees (rendered IN FRONT of mid-ground characters!)
        if (scene.foregroundPlaneEnabled && !transparentBackground && !chromaKeyGreen) {
            drawBackgroundForegroundPlane(
                canvas = canvas,
                templateName = scene.backgroundTemplate,
                w = projectWidth,
                h = projectHeight,
                panX = camera.panX * 1.25f + scrollOffsetX * 1.35f,
                panY = camera.panY * 1.15f,
                frame = frame
            )
        }

        renderLayerList(foreLayers, activeVisibleLayers)

        // 4. Aesthetic, Weather & Horror Scene VFX Overlays
        if (scene.activeVfx.isNotEmpty() && !chromaKeyGreen) {
            drawSceneVfx(canvas, scene.activeVfx, projectWidth, projectHeight, frame)
        }

        // 4a. Directional Spotlight / Sunlight Cone (Module 9)
        if (scene.spotlightEnabled && !chromaKeyGreen) {
            drawDirectionalSpotlight(canvas, scene, projectWidth, projectHeight)
        }

        // 4b. Cinematic Color Grading Filter (Horror Cold, Midnight, Retro VHS, Noir B&W, Warm Glow)
        if (!chromaKeyGreen && !transparentBackground && scene.colorGrade != SceneColorGrade.NONE.name) {
            drawColorGradeOverlay(canvas, scene.colorGrade, projectWidth, projectHeight, frame)
        }

        // 4c. Dynamic YouTube Subtitles & Captions Track
        if (scene.subtitles.isNotEmpty()) {
            drawSubtitles(canvas, scene.subtitles, frame, projectWidth, projectHeight)
        }

        // 4d. Kinetic Animated Text & Title Layers (visible across scene timeline)
        if (scene.animatedTexts.isNotEmpty()) {
            scene.animatedTexts.filter { it.visible }.forEach { textItem ->
                drawTextItem(
                    canvas = canvas,
                    item = textItem,
                    frame = frame,
                    layerAlpha = 1f,
                    tintColorArgb = null,
                    isSelected = (textItem.id == selectedTextId)
                )
            }
        }

        // 4e. Channel Brand Watermark / Logo (rendered cleanly on BOTH preview and export!)
        if (!scene.watermarkText.isNullOrBlank() || !scene.watermarkImagePath.isNullOrBlank()) {
            drawChannelWatermark(canvas, scene, projectWidth, projectHeight)
        }

        // 5. Live in-progress stroke / shape / motion path preview (exact selected layer transform for 0px offset!)
        val previewLayer = scene.layers.firstOrNull { it.id == selectedLayerId }
        if (activePreviewStroke != null || activePreviewShape != null) {
            canvas.save()
            val parallax = previewLayer?.parallaxDepth ?: 1f
            applyCameraTransform(canvas, camera, projectWidth, projectHeight, parallax)
            if (previewLayer != null) {
                val tf = InterpolationEngine.evaluateLayerTransform(previewLayer, frame, scene.durationFrames)
                val bgShiftX = InterpolationEngine.computeBgScrollShiftX(previewLayer, scene, frame, projectWidth)
                val pivot = computeLayerPivot(previewLayer, frame, scene.durationFrames, projectWidth, projectHeight)
                canvas.translate(pivot.x + tf.x + bgShiftX, pivot.y + tf.y)
                canvas.rotate(tf.rotationDeg)
                canvas.scale(tf.scaleX, tf.scaleY)
                canvas.translate(-pivot.x, -pivot.y)
            }
            activePreviewStroke?.let { drawStroke(canvas, it, 1f, null) }
            activePreviewShape?.let { drawVectorShape(canvas, it, 1f, null) }
            canvas.restore()
        }
        if (activePreviewMotionPath != null && activePreviewMotionPath.size >= 2) {
            canvas.save()
            applyCameraTransform(canvas, camera, projectWidth, projectHeight, previewLayer?.parallaxDepth ?: 1f)
            drawMotionPathOverlay(canvas, activePreviewMotionPath, isSelected = true, currentProgress = null)
            canvas.restore()
        }

        // 6. Visual Camera Motion Director Viewfinder Frame (editor HUD only; never on export!)
        if (showCameraFrame) {
            drawCameraViewportFrame(canvas, camera, projectWidth, projectHeight)
        }
    }

    private fun drawDirectionalSpotlight(
        canvas: Canvas,
        scene: AnimationScene,
        w: Float,
        h: Float
    ) {
        val sx = (scene.spotlightX.coerceIn(0f, 1f)) * w
        val sy = (scene.spotlightY.coerceIn(0f, 1f)) * h
        val r = (scene.spotlightRadius.coerceIn(0.15f, 1.5f)) * max(w, h) * 0.65f
        val intensity = scene.spotlightIntensity.coerceIn(0.05f, 1f)
        val cInt = scene.spotlightColorArgb.toInt()
        val cr = Color.red(cInt); val cg = Color.green(cInt); val cb = Color.blue(cInt)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        // Subtle theatrical darkening outside the spotlight cone
        paint.shader = RadialGradient(
            sx, sy, r * 1.45f,
            intArrayOf(
                Color.argb((intensity * 115f).toInt().coerceIn(0, 255), cr, cg, cb),
                Color.argb((intensity * 45f).toInt().coerceIn(0, 255), cr, cg, cb),
                Color.argb((intensity * 105f).toInt().coerceIn(0, 255), 2, 6, 23)
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    private fun drawChannelWatermark(
        canvas: Canvas,
        scene: AnimationScene,
        w: Float,
        h: Float
    ) {
        val op = (scene.watermarkOpacity.coerceIn(0.08f, 1f) * 255f).toInt()
        val margin = 26f
        val corner = scene.watermarkCorner.uppercase()
        val logoBmp = scene.watermarkImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        val text = scene.watermarkText.trim()

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            alpha = op
            textSize = (min(w, h) * 0.036f).coerceIn(18f, 36f)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(4f, 1.5f, 1.5f, Color.argb((op * 0.8f).toInt(), 0, 0, 0))
        }
        val logoSize = if (logoBmp != null) 46f else 0f
        val textW = if (text.isNotEmpty()) textPaint.measureText(text) else 0f
        val gap = if (logoBmp != null && text.isNotEmpty()) 10f else 0f
        val totalW = logoSize + gap + textW
        val totalH = max(logoSize, textPaint.textSize * 1.15f)

        val left = when (corner) {
            "TOP_LEFT", "BOTTOM_LEFT" -> margin
            else -> w - margin - totalW
        }
        val top = when (corner) {
            "TOP_LEFT", "TOP_RIGHT" -> margin
            else -> h - margin - totalH
        }

        // Subtle dark translucent badge behind channel brand
        val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((op * 0.42f).toInt(), 10, 14, 24)
        }
        canvas.drawRoundRect(
            RectF(left - 12f, top - 8f, left + totalW + 12f, top + totalH + 8f),
            12f, 12f, pillPaint
        )

        var curX = left
        if (logoBmp != null) {
            val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = op }
            canvas.drawBitmap(logoBmp, null, RectF(curX, top + (totalH - logoSize) / 2f, curX + logoSize, top + (totalH + logoSize) / 2f), lp)
            curX += logoSize + gap
        }
        if (text.isNotEmpty()) {
            canvas.drawText(text, curX, top + totalH * 0.72f, textPaint)
        }
    }

    private fun drawCameraViewportFrame(canvas: Canvas, camera: EvaluatedCamera, w: Float, h: Float) {
        val margin = 16f
        val rect = RectF(margin, margin, w - margin, h - margin)

        // Subtle rule-of-thirds guides
        val thirdPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x44FBBF24
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }
        canvas.drawLine(w / 3f, margin, w / 3f, h - margin, thirdPaint)
        canvas.drawLine(w * 2f / 3f, margin, w * 2f / 3f, h - margin, thirdPaint)
        canvas.drawLine(margin, h / 3f, w - margin, h / 3f, thirdPaint)
        canvas.drawLine(margin, h * 2f / 3f, w - margin, h * 2f / 3f, thirdPaint)

        // Outer cinematic amber border + corner viewfinder brackets
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCFBBF24.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRect(rect, framePaint)

        val bracketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFF6B35.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
        }
        val bLen = 42f
        // Top-Left
        canvas.drawLine(rect.left, rect.top, rect.left + bLen, rect.top, bracketPaint)
        canvas.drawLine(rect.left, rect.top, rect.left, rect.top + bLen, bracketPaint)
        // Top-Right
        canvas.drawLine(rect.right - bLen, rect.top, rect.right, rect.top, bracketPaint)
        canvas.drawLine(rect.right, rect.top, rect.right, rect.top + bLen, bracketPaint)
        // Bottom-Left
        canvas.drawLine(rect.left, rect.bottom - bLen, rect.left, rect.bottom, bracketPaint)
        canvas.drawLine(rect.left, rect.bottom, rect.left + bLen, rect.bottom, bracketPaint)
        // Bottom-Right
        canvas.drawLine(rect.right - bLen, rect.bottom, rect.right, rect.bottom, bracketPaint)
        canvas.drawLine(rect.right, rect.bottom - bLen, rect.right, rect.bottom, bracketPaint)

        // Center crosshair
        val cx = w / 2f
        val cy = h / 2f
        canvas.drawLine(cx - 16f, cy, cx + 16f, cy, framePaint)
        canvas.drawLine(cx, cy - 16f, cx, cy + 16f, framePaint)

        // Live Camera Telemetry Pill
        val label = String.format(
            Locale.US,
            "CAM %.2fx  •  PAN (%d, %d)  •  TILT %d°",
            camera.zoom, camera.panX.toInt(), camera.panY.toInt(), camera.rotationDeg.toInt()
        )
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFBBF24.toInt()
            textSize = 20f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val tw = textPaint.measureText(label) + 28f
        val pill = RectF(cx - tw / 2f, rect.bottom - 42f, cx + tw / 2f, rect.bottom - 10f)
        val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC0D0F14.toInt() }
        canvas.drawRoundRect(pill, 12f, 12f, pillBg)
        canvas.drawRoundRect(pill, 12f, 12f, framePaint)
        canvas.drawText(label, cx, pill.centerY() + 7f, textPaint)
    }

    /**
     * Computes raw untransformed visual bounds of a layer's artwork/rig so Module 1
     * Center-Pivot vs Bottom-Feet scaling NEVER jumps up or down on stage!
     */
    fun computeRawLayerContentBounds(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int
    ): RectF? {
        val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        fun include(x: Float, y: Float) {
            if (!x.isFinite() || !y.isFinite()) return
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }

        content?.strokes?.forEach { s -> s.points.forEach { include(it.x, it.y) } }
        content?.shapes?.filter { it.kind != ShapeKind.FILL_BACKDROP.name }?.forEach { s ->
            include(s.startX, s.startY); include(s.endX, s.endY)
        }
        content?.images?.forEach { img ->
            include(img.x - img.width / 2f, img.y - img.height / 2f)
            include(img.x + img.width / 2f, img.y + img.height / 2f)
        }
        content?.texts?.forEach { t ->
            val tb = computeTextBounds(t)
            include(tb.left, tb.top); include(tb.right, tb.bottom)
        }
        layer.character?.let { c ->
            include(c.x - 90f * c.scale, c.y - 170f * c.scale)
            include(c.x + 90f * c.scale, c.y + 170f * c.scale)
        }
        layer.rig?.let { rig ->
            val pRoot = InterpolationEngine.evaluatePuppetRootWithPath(layer, rig, frame, totalFrames)
            val angles = InterpolationEngine.evaluateRigAnglesWithPath(layer, rig, frame, totalFrames)
            val lengths = InterpolationEngine.evaluateBoneLengths(rig, frame)
            val viewAngle = runCatching { CharacterViewAngle.valueOf(pRoot.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
            val effFlip = isLeftFacingView(viewAngle, pRoot.flippedHorizontal)
            val solved = RigSolver.solveForwardKinematics(
                rig = rig,
                angleOverrides = angles,
                rootX = pRoot.rootX,
                rootY = pRoot.rootY,
                scale = pRoot.scale,
                flippedHorizontal = effFlip,
                lengthOverrides = lengths,
                scaleX = pRoot.scaleX,
                scaleY = pRoot.scaleY,
                frame = frame
            )
            solved.forEach { sb ->
                include(sb.start.x - 28f * pRoot.scale * pRoot.scaleX, sb.start.y - 28f * pRoot.scale * pRoot.scaleY)
                include(sb.end.x + 28f * pRoot.scale * pRoot.scaleX, sb.end.y + 28f * pRoot.scale * pRoot.scaleY)
            }
            if (!rig.singleMeshImagePath.isNullOrBlank()) {
                val mRect = computeSingleMeshRect(rig, pRoot)
                include(mRect.left, mRect.top)
                include(mRect.right, mRect.bottom)
            }
        }
        if (!minX.isFinite() || !minY.isFinite()) return null
        return RectF(minX, minY, maxX, maxY)
    }

    fun computeLayerPivot(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int,
        projectWidth: Float,
        projectHeight: Float
    ): Vec2 {
        val raw = computeRawLayerContentBounds(layer, frame, totalFrames)
            ?: return Vec2(projectWidth / 2f, projectHeight / 2f)
        return if (layer.pivotMode == "BOTTOM_FEET") {
            Vec2(raw.centerX(), raw.bottom)
        } else {
            Vec2(raw.centerX(), raw.centerY())
        }
    }

    fun computeLayerBounds(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int,
        projectWidth: Float,
        projectHeight: Float
    ): RectF? {
        val raw = computeRawLayerContentBounds(layer, frame, totalFrames) ?: return null
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, totalFrames)
        val pivot = if (layer.pivotMode == "BOTTOM_FEET") {
            Vec2(raw.centerX(), raw.bottom)
        } else {
            Vec2(raw.centerX(), raw.centerY())
        }
        val sx = tf.scaleX
        val sy = tf.scaleY
        val tx1 = (raw.left - pivot.x) * sx + pivot.x + tf.x
        val ty1 = (raw.top - pivot.y) * sy + pivot.y + tf.y
        val tx2 = (raw.right - pivot.x) * sx + pivot.x + tf.x
        val ty2 = (raw.bottom - pivot.y) * sy + pivot.y + tf.y
        return RectF(min(tx1, tx2) - 16f, min(ty1, ty2) - 16f, max(tx1, tx2) + 16f, max(ty1, ty2) + 16f)
    }

    fun isLeftFacingView(viewAngle: CharacterViewAngle, flippedHorizontal: Boolean): Boolean {
        val leftFacing = viewAngle == CharacterViewAngle.SIDE_LEFT ||
            viewAngle == CharacterViewAngle.FRONT_LEFT_34 ||
            viewAngle == CharacterViewAngle.BACK_LEFT_34
        return if (leftFacing) !flippedHorizontal else flippedHorizontal
    }

    fun isLeftFacingView(viewAngleName: String, flippedHorizontal: Boolean): Boolean {
        val parsed = runCatching { CharacterViewAngle.valueOf(viewAngleName) }.getOrDefault(CharacterViewAngle.FRONT)
        return isLeftFacingView(parsed, flippedHorizontal)
    }

    data class BoundPartBoxInfo(
        val center: Vec2,
        val topLeft: Vec2,
        val topRight: Vec2,
        val bottomLeft: Vec2,
        val bottomRight: Vec2,
        val edgeLeft: Vec2,
        val edgeRight: Vec2,
        val edgeTop: Vec2,
        val edgeBottom: Vec2,
        val halfW: Float,
        val halfH: Float,
        val rotRad: Float
    )

    /** Pure-Kotlin [left, top, right, bottom] bounds for single-mesh PNG (JVM unit-test safe). */
    fun computeSingleMeshBounds(rig: SkeletalRig, puppetRoot: EvaluatedPuppetRoot): FloatArray {
        val effectiveScaleX = puppetRoot.scale * puppetRoot.scaleX * rig.baseScaleX.coerceIn(0.1f, 5.0f) * rig.singleMeshScale.coerceIn(0.05f, 8.0f)
        val effectiveScaleY = puppetRoot.scale * puppetRoot.scaleY * rig.baseScaleY.coerceIn(0.1f, 5.0f) * rig.singleMeshScale.coerceIn(0.05f, 8.0f)
        val halfW = (rig.singleMeshWidth * effectiveScaleX) / 2f
        val halfH = (rig.singleMeshHeight * effectiveScaleY) / 2f
        val cx = puppetRoot.rootX + rig.singleMeshOffsetX * puppetRoot.scale * puppetRoot.scaleX
        val cy = puppetRoot.rootY + rig.singleMeshOffsetY * puppetRoot.scale * puppetRoot.scaleY
        return floatArrayOf(
            cx - halfW,
            cy - halfH * 1.15f,
            cx + halfW,
            cy + halfH * 0.85f
        )
    }

    fun computeSingleMeshRect(rig: SkeletalRig, puppetRoot: EvaluatedPuppetRoot): RectF {
        val b = computeSingleMeshBounds(rig, puppetRoot)
        return RectF(b[0], b[1], b[2], b[3])
    }

    fun computeBoundBonePartBox(
        sb: SolvedBone,
        scale: Float,
        effectiveFlipped: Boolean
    ): BoundPartBoxInfo? {
        val partPath = sb.bone.boundImagePath?.takeIf { it.isNotBlank() } ?: return null
        val partBmp = getCachedBitmap(partPath) ?: return null
        val preset = runCatching { PartBehaviorPreset.valueOf(sb.bone.partBehaviorPreset) }
            .getOrDefault(PartBehaviorPreset.RIGID)
        val rawBoneLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y)
        val baseLen = if (preset == PartBehaviorPreset.RIGID) (sb.bone.length * scale).coerceAtLeast(16f) else rawBoneLen
        val stretchRatio = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
            (rawBoneLen / (sb.bone.length * scale).coerceAtLeast(1f)).coerceIn(0.4f, 3.0f)
        } else 1f
        val squashW = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
            (1f / kotlin.math.sqrt(stretchRatio)).coerceIn(0.5f, 1.8f)
        } else 1f
        val drawH = (baseLen * 1.25f * sb.bone.imageScale * sb.bone.limbLengthScale.coerceIn(0.3f, 3.0f) * sb.bone.baseScaleY.coerceIn(0.1f, 5.0f)).coerceAtLeast(24f)
        val aspect = partBmp.width.toFloat() / partBmp.height.coerceAtLeast(1).toFloat()
        val drawW = (drawH / sb.bone.baseScaleY.coerceIn(0.1f, 5.0f) * aspect * sb.bone.limbWidthScale.coerceIn(0.3f, 3.0f) * sb.bone.baseScaleX.coerceIn(0.1f, 5.0f) * squashW).coerceAtLeast(20f)
        val rotDeg = Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat() - 90f + sb.bone.imageRotationOffsetDeg
        val rotRad = Math.toRadians(rotDeg.toDouble()).toFloat()
        val cosR = cos(rotRad.toDouble()).toFloat()
        val sinR = sin(rotRad.toDouble()).toFloat()
        val flipX = if (effectiveFlipped) -1f else 1f
        val left = -drawW / 2f + sb.bone.pivotOffsetX * scale
        val right = drawW / 2f + sb.bone.pivotOffsetX * scale
        val top = -drawH * 0.12f + sb.bone.pivotOffsetY * scale
        val bottom = drawH * 0.88f + sb.bone.pivotOffsetY * scale
        fun toWorld(lx: Float, ly: Float): Vec2 {
            val fx = lx * flipX
            return Vec2(
                sb.start.x + fx * cosR - ly * sinR,
                sb.start.y + fx * sinR + ly * cosR
            )
        }
        val midX = (left + right) * 0.5f
        val midY = (top + bottom) * 0.5f
        return BoundPartBoxInfo(
            center = toWorld(midX, midY),
            topLeft = toWorld(left, top),
            topRight = toWorld(right, top),
            bottomLeft = toWorld(left, bottom),
            bottomRight = toWorld(right, bottom),
            edgeLeft = toWorld(left, midY),
            edgeRight = toWorld(right, midY),
            edgeTop = toWorld(midX, top),
            edgeBottom = toWorld(midX, bottom),
            halfW = drawW * 0.5f,
            halfH = drawH * 0.5f,
            rotRad = rotRad
        )
    }

    fun computeFaceOverlayWorldCenter(
        rig: SkeletalRig,
        puppetRoot: EvaluatedPuppetRoot,
        angles: Map<String, Float>
    ): Vec2 {
        val viewAngle = runCatching { CharacterViewAngle.valueOf(puppetRoot.viewAngle) }
            .getOrDefault(CharacterViewAngle.FRONT)
        val effFlip = isLeftFacingView(viewAngle, puppetRoot.flippedHorizontal)
        val solved = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = angles,
            rootX = puppetRoot.rootX,
            rootY = puppetRoot.rootY,
            scale = puppetRoot.scale,
            flippedHorizontal = effFlip,
            scaleX = puppetRoot.scaleX,
            scaleY = puppetRoot.scaleY
        )
        val headBone = solved.firstOrNull { it.bone.id == "neck" || it.bone.name.contains("Head", ignoreCase = true) }
        val baseX = if (headBone != null) (headBone.start.x + headBone.end.x * 2f) / 3f else puppetRoot.rootX
        val baseY = if (headBone != null) (headBone.start.y + headBone.end.y * 2f) / 3f else puppetRoot.rootY - 90f * puppetRoot.scale * puppetRoot.scaleY
        val flipSign = if (effFlip) -1f else 1f
        return Vec2(
            baseX + rig.faceOverlayOffsetX * puppetRoot.scale * puppetRoot.scaleX * flipSign,
            baseY + rig.faceOverlayOffsetY * puppetRoot.scale * puppetRoot.scaleY
        )
    }

    private fun drawSelectionTouchHandles(
        canvas: Canvas,
        rect: RectF,
        rotationDeg: Float = 0f,
        pivotMode: String = "CENTER"
    ) {
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF2DD4BF.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
        }
        canvas.drawRect(rect, boxPaint)

        val whiteStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3.2f }

        // Pivot indicator crosshair (True Center vs Bottom-Feet)
        val pivX = rect.centerX()
        val pivY = if (pivotMode == "BOTTOM_FEET") rect.bottom else rect.centerY()
        val pivPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFBBF24.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 2.6f
        }
        canvas.drawCircle(pivX, pivY, 7f, pivPaint)
        canvas.drawLine(pivX - 11f, pivY, pivX + 11f, pivY, pivPaint)
        canvas.drawLine(pivX, pivY - 11f, pivX, pivY + 11f, pivPaint)

        // Prominent Top 360-Degree Rotation Handle with Glow Halo
        val rotX = rect.centerX()
        val rotY = rect.top - 52f
        val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFF6B35.toInt()
            strokeWidth = 3.5f
        }
        canvas.drawLine(rect.centerX(), rect.top, rotX, rotY, stemPaint)
        val rotGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FF6B35; style = Paint.Style.FILL }
        val rotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
        canvas.drawCircle(rotX, rotY, 26f, rotGlow)
        canvas.drawCircle(rotX, rotY, 17f, rotFill)
        canvas.drawCircle(rotX, rotY, 17f, whiteStroke)
        val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 2.6f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawArc(RectF(rotX - 8f, rotY - 8f, rotX + 8f, rotY + 8f), -45f, 250f, false, arcPaint)
        if (kotlin.math.abs(rotationDeg) > 0.5f) {
            val degPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFFE066.toInt()
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.LEFT
            }
            canvas.drawText("${rotationDeg.toInt()}°", rotX + 24f, rotY + 6f, degPaint)
        }

        // 4 Prominent Corner Uniform Resize Handles with Touch Halos
        val cornerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x442DD4BF; style = Paint.Style.FILL }
        val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt(); style = Paint.Style.FILL }
        listOf(
            Vec2(rect.left, rect.top),
            Vec2(rect.right, rect.top),
            Vec2(rect.left, rect.bottom),
            Vec2(rect.right, rect.bottom)
        ).forEach { corner ->
            canvas.drawCircle(corner.x, corner.y, 22f, cornerGlow)
            canvas.drawCircle(corner.x, corner.y, 13.5f, handleFill)
            canvas.drawCircle(corner.x, corner.y, 13.5f, whiteStroke)
        }

        // Module 2: 4 Edge Mid-Point Squash & Stretch Handles (Left/Right = Scale X, Top/Bottom = Scale Y)
        val edgeXFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA78BFA.toInt(); style = Paint.Style.FILL }
        val edgeYFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFBBF24.toInt(); style = Paint.Style.FILL }
        // Left & Right (Width Squash/Stretch)
        listOf(Vec2(rect.left, rect.centerY()), Vec2(rect.right, rect.centerY())).forEach { p ->
            val pill = RectF(p.x - 7f, p.y - 16f, p.x + 7f, p.y + 16f)
            canvas.drawRoundRect(pill, 7f, 7f, edgeXFill)
            canvas.drawRoundRect(pill, 7f, 7f, whiteStroke)
        }
        // Top & Bottom (Height Squash/Stretch)
        listOf(Vec2(rect.centerX(), rect.top), Vec2(rect.centerX(), rect.bottom)).forEach { p ->
            val pill = RectF(p.x - 16f, p.y - 7f, p.x + 16f, p.y + 7f)
            canvas.drawRoundRect(pill, 7f, 7f, edgeYFill)
            canvas.drawRoundRect(pill, 7f, 7f, whiteStroke)
        }
    }

    private fun applyCameraTransform(
        canvas: Canvas,
        camera: EvaluatedCamera,
        w: Float,
        h: Float,
        parallax: Float
    ) {
        canvas.translate(w / 2f, h / 2f)
        canvas.rotate(camera.rotationDeg)
        val effectiveZoom = 1f + (camera.zoom - 1f) * parallax
        canvas.scale(effectiveZoom, effectiveZoom)
        canvas.translate(-w / 2f - camera.panX * parallax, -h / 2f - camera.panY * parallax)
    }

    private fun drawLayerAtFrame(
        canvas: Canvas,
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        camera: EvaluatedCamera,
        projectWidth: Float,
        projectHeight: Float,
        overrideAlpha: Float?,
        tintColorArgb: Long?,
        showRigOverlay: Boolean,
        isSelectedLayer: Boolean,
        selectedBoneId: String?,
        maskLayerBelow: AnimationLayer? = null,
        allowEffects: Boolean = true
    ) {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val combinedAlpha = ((overrideAlpha ?: (layer.opacity * tf.opacity))).coerceIn(0f, 1f)
        if (combinedAlpha <= 0.01f) return

        // Module 9: Directional Motion Blur & Speed Afterimages (trailing faded ghosts from previous frames)
        if (allowEffects && overrideAlpha == null && layer.motionBlurStrength > 0.03f && frame > 0) {
            val strength = layer.motionBlurStrength.coerceIn(0f, 1f)
            val steps = if (strength > 0.55f) 3 else 2
            for (k in steps downTo 1) {
                val prevF = (frame - k).coerceAtLeast(0)
                val ghostAlpha = combinedAlpha * strength * (0.34f / k)
                if (ghostAlpha > 0.02f) {
                    drawLayerCore(
                        canvas = canvas,
                        scene = scene,
                        layer = layer,
                        frame = prevF,
                        fps = fps,
                        audioTracks = audioTracks,
                        camera = camera,
                        projectWidth = projectWidth,
                        projectHeight = projectHeight,
                        combinedAlpha = ghostAlpha,
                        tintColorArgb = tintColorArgb,
                        showRigOverlay = false,
                        isSelectedLayer = false,
                        selectedBoneId = null,
                        drawContactShadow = false,
                        rimLightColorArgb = null
                    )
                }
            }
        }

        // Module 9: Layer Masking / Clip to Layer Below (PorterDuff DST_IN offscreen composite)
        if (allowEffects && maskLayerBelow != null && overrideAlpha == null) {
            val saveCount = canvas.saveLayer(0f, 0f, projectWidth, projectHeight, null)
            drawLayerCore(
                canvas = canvas,
                scene = scene,
                layer = layer,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                camera = camera,
                projectWidth = projectWidth,
                projectHeight = projectHeight,
                combinedAlpha = combinedAlpha,
                tintColorArgb = tintColorArgb,
                showRigOverlay = false,
                isSelectedLayer = isSelectedLayer,
                selectedBoneId = selectedBoneId,
                drawContactShadow = layer.groundShadowEnabled,
                rimLightColorArgb = layer.rimLightColorArgb
            )
            val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            val maskSave = canvas.saveLayer(0f, 0f, projectWidth, projectHeight, maskPaint)
            drawLayerCore(
                canvas = canvas,
                scene = scene,
                layer = maskLayerBelow,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                camera = camera,
                projectWidth = projectWidth,
                projectHeight = projectHeight,
                combinedAlpha = 1f,
                tintColorArgb = null,
                showRigOverlay = false,
                isSelectedLayer = false,
                selectedBoneId = null,
                drawContactShadow = false,
                rimLightColorArgb = null
            )
            canvas.restoreToCount(maskSave)
            canvas.restoreToCount(saveCount)
            // Keep rig overlay unclipped when editing
            if (showRigOverlay && layer.type == LayerType.RIG.name && layer.rig != null) {
                drawLayerCore(
                    canvas = canvas,
                    scene = scene,
                    layer = layer,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    camera = camera,
                    projectWidth = projectWidth,
                    projectHeight = projectHeight,
                    combinedAlpha = 0f,
                    tintColorArgb = null,
                    showRigOverlay = true,
                    isSelectedLayer = isSelectedLayer,
                    selectedBoneId = selectedBoneId,
                    drawContactShadow = false,
                    rimLightColorArgb = null
                )
            }
            return
        }

        drawLayerCore(
            canvas = canvas,
            scene = scene,
            layer = layer,
            frame = frame,
            fps = fps,
            audioTracks = audioTracks,
            camera = camera,
            projectWidth = projectWidth,
            projectHeight = projectHeight,
            combinedAlpha = combinedAlpha,
            tintColorArgb = tintColorArgb,
            showRigOverlay = showRigOverlay,
            isSelectedLayer = isSelectedLayer,
            selectedBoneId = selectedBoneId,
            drawContactShadow = allowEffects && overrideAlpha == null && layer.groundShadowEnabled,
            rimLightColorArgb = if (allowEffects && overrideAlpha == null) layer.rimLightColorArgb else null
        )
    }

    private fun drawLayerCore(
        canvas: Canvas,
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        camera: EvaluatedCamera,
        projectWidth: Float,
        projectHeight: Float,
        combinedAlpha: Float,
        tintColorArgb: Long?,
        showRigOverlay: Boolean,
        isSelectedLayer: Boolean,
        selectedBoneId: String?,
        drawContactShadow: Boolean,
        rimLightColorArgb: Long?
    ) {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val rawBounds = computeRawLayerContentBounds(layer, frame, scene.durationFrames)
        val pivot = when {
            rawBounds == null -> Vec2(projectWidth / 2f, projectHeight / 2f)
            layer.pivotMode == "BOTTOM_FEET" -> Vec2(rawBounds.centerX(), rawBounds.bottom)
            else -> Vec2(rawBounds.centerX(), rawBounds.centerY())
        }

        canvas.save()
        applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)

        // Seamless horizontal background scrolling for custom Background layers
        val bgAutoShiftX = InterpolationEngine.computeBgScrollShiftX(layer, scene, frame, projectWidth)

        // True Center or Bottom-Feet Pivot Transform (Module 1: scaling NEVER jumps vertically!)
        canvas.translate(pivot.x + tf.x + bgAutoShiftX, pivot.y + tf.y)
        canvas.rotate(tf.rotationDeg)
        canvas.scale(tf.scaleX, tf.scaleY)
        canvas.translate(-pivot.x, -pivot.y)

        // Module 9: Automatic Ground Contact Shadow underneath layer bounds/feet
        if (drawContactShadow && rawBounds != null && combinedAlpha > 0.05f) {
            val shadowW = (rawBounds.width() * 0.42f).coerceIn(32f, 220f)
            val shadowH = (shadowW * 0.24f).coerceIn(10f, 36f)
            val sx = rawBounds.centerX()
            val sy = rawBounds.bottom + 4f
            val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    sx, sy, shadowW,
                    Color.argb((combinedAlpha * 115f).toInt().coerceIn(0, 255), 2, 6, 23),
                    Color.TRANSPARENT,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawOval(RectF(sx - shadowW, sy - shadowH, sx + shadowW, sy + shadowH), shadowPaint)
        }

        // Video Background / Reference Layer
        if (layer.type == LayerType.VIDEO.name && !layer.videoFilePath.isNullOrBlank() && combinedAlpha > 0.01f) {
            val timeUs = ((frame.toDouble() / fps.coerceAtLeast(1)) * 1_000_000.0).toLong()
            val vBmp = getCachedVideoFrame(layer.videoFilePath, timeUs)
            if (vBmp != null) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = (combinedAlpha * 255).toInt().coerceIn(0, 255)
                }
                canvas.drawBitmap(vBmp, null, RectF(0f, 0f, projectWidth, projectHeight), p)
            }
        }

        // Helper to draw layer visual payload (reused for optional Rim Light edge glow pass!)
        fun drawPayload(drawAlpha: Float, drawTint: Long?, overlayBones: Boolean) {
            val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
            if (content != null && drawAlpha > 0.01f) {
                val filteredContent = if (layer.type == LayerType.RIG.name && layer.rig != null && content.images.isNotEmpty()) {
                    val rigPaths = buildSet {
                        layer.rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let(::add)
                        layer.rig.bones.mapNotNull { it.boundImagePath?.takeIf { p -> p.isNotBlank() } }.forEach(::add)
                    }
                    if (rigPaths.isNotEmpty()) {
                        content.copy(images = content.images.filterNot { it.filePath in rigPaths })
                    } else content
                } else content
                drawFrameContent(canvas, filteredContent, drawAlpha, drawTint, frame)
            }

            if (layer.type == LayerType.CHARACTER.name && drawAlpha > 0.01f) {
                val charSpec = content?.characterOverride ?: layer.character
                if (charSpec != null) {
                    drawCharacter(canvas, charSpec, drawAlpha, drawTint, frame, fps, audioTracks)
                }
            }

            if (layer.type == LayerType.RIG.name && layer.rig != null) {
                val puppetRoot = InterpolationEngine.evaluatePuppetRootWithPath(layer, layer.rig, frame, scene.durationFrames, audioTracks = audioTracks, fps = fps)
                val angles = InterpolationEngine.evaluateRigAnglesWithPath(layer, layer.rig, frame, scene.durationFrames, audioTracks = audioTracks, fps = fps)
                drawSkeletalRig(
                    canvas = canvas,
                    rig = layer.rig,
                    puppetRoot = puppetRoot,
                    angles = angles,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    alpha = drawAlpha,
                    tintColorArgb = drawTint,
                    showOverlay = overlayBones,
                    isSelectedPuppet = isSelectedLayer,
                    selectedBoneId = selectedBoneId
                )
            }
        }

        // Module 9: Subtle Back Rim Light Glow pass behind character/object
        if (rimLightColorArgb != null && combinedAlpha > 0.05f) {
            canvas.save()
            canvas.translate(-6f, -5f)
            drawPayload(combinedAlpha * 0.42f, rimLightColorArgb, false)
            canvas.restore()
            canvas.save()
            canvas.translate(6f, -3f)
            drawPayload(combinedAlpha * 0.28f, rimLightColorArgb, false)
            canvas.restore()
        }

        drawPayload(combinedAlpha, tintColorArgb, showRigOverlay)

        canvas.restore()
    }

    private fun drawFrameContent(
        canvas: Canvas,
        content: FrameContent,
        alpha: Float,
        tintColorArgb: Long?,
        frame: Int = 0
    ) {
        content.images.forEach { img -> drawImportedImage(canvas, img, alpha, tintColorArgb) }
        content.shapes.forEach { shape -> drawVectorShape(canvas, shape, alpha, tintColorArgb) }
        content.strokes.forEach { stroke -> drawStroke(canvas, stroke, alpha, tintColorArgb) }
        content.texts.forEach { textItem -> drawTextItem(canvas, textItem, frame, alpha, tintColorArgb, false) }
    }

    private fun drawImportedImage(canvas: Canvas, item: ImportedImageItem, layerAlpha: Float, tintColorArgb: Long?) {
        val bmp = getCachedBitmap(item.filePath) ?: return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (layerAlpha * item.opacity * 255).toInt().coerceIn(0, 255)
            if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
        }
        canvas.save()
        canvas.translate(item.x, item.y)
        canvas.rotate(item.rotationDeg)
        val dst = RectF(-item.width / 2f, -item.height / 2f, item.width / 2f, item.height / 2f)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
    }

    private fun buildTintColorFilter(tintArgb: Long): ColorMatrixColorFilter {
        val r = Color.red(tintArgb.toInt()) / 255f
        val g = Color.green(tintArgb.toInt()) / 255f
        val b = Color.blue(tintArgb.toInt()) / 255f
        return ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    r, 0f, 0f, 0f, 30f,
                    0f, g, 0f, 0f, 30f,
                    0f, 0f, b, 0f, 30f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    private fun drawStroke(canvas: Canvas, stroke: DrawStroke, layerAlpha: Float, tintColorArgb: Long?) {
        if (stroke.points.isEmpty()) return
        val effectiveAlpha = (layerAlpha * stroke.opacity * 255).toInt().coerceIn(0, 255)
        val baseColor = (tintColorArgb ?: stroke.colorArgb).toInt()

        if (stroke.tool == EditorTool.AIRBRUSH.name) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = baseColor
                style = Paint.Style.FILL
                alpha = (effectiveAlpha * 0.25f).toInt().coerceIn(8, 255)
            }
            val spread = stroke.strokeWidth * 1.4f
            val rng = Random(stroke.id.hashCode())
            stroke.points.forEach { pt ->
                repeat(10) {
                    val a = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * spread
                    canvas.drawCircle(
                        pt.x + cos(a) * r,
                        pt.y + sin(a) * r,
                        (stroke.strokeWidth * 0.14f).coerceAtLeast(1.5f),
                        dotPaint
                    )
                }
            }
            return
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = baseColor
            style = if (stroke.isClosedBezier) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
            strokeWidth = if (stroke.tool == EditorTool.PENCIL.name) {
                (stroke.strokeWidth * 0.55f).coerceAtLeast(1.5f)
            } else {
                stroke.strokeWidth
            }
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = effectiveAlpha
        }

        if (stroke.gradientEndArgb != null && tintColorArgb == null && stroke.points.size >= 2) {
            val first = stroke.points.first()
            val last = stroke.points.last()
            paint.shader = LinearGradient(
                first.x, first.y, last.x, last.y,
                stroke.colorArgb.toInt(),
                stroke.gradientEndArgb.toInt(),
                Shader.TileMode.CLAMP
            )
        }

        if (stroke.points.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(stroke.points[0].x, stroke.points[0].y, paint.strokeWidth / 2f, paint)
            return
        }

        val path = Path().apply {
            moveTo(stroke.points[0].x, stroke.points[0].y)
            for (i in 1 until stroke.points.size) {
                val prev = stroke.points[i - 1]
                val curr = stroke.points[i]
                val midX = (prev.x + curr.x) / 2f
                val midY = (prev.y + curr.y) / 2f
                quadTo(prev.x, prev.y, midX, midY)
            }
            val last = stroke.points.last()
            lineTo(last.x, last.y)
            if (stroke.isClosedBezier) close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawVectorShape(canvas: Canvas, shape: VectorShape, layerAlpha: Float, tintColorArgb: Long?) {
        val alphaInt = (layerAlpha * shape.opacity * 255).toInt().coerceIn(0, 255)
        val kind = runCatching { ShapeKind.valueOf(shape.kind) }.getOrDefault(ShapeKind.RECTANGLE)
        val rect = RectF(
            min(shape.startX, shape.endX),
            min(shape.startY, shape.endY),
            max(shape.startX, shape.endX),
            max(shape.startY, shape.endY)
        )

        canvas.save()
        if (shape.rotationDeg != 0f) canvas.rotate(shape.rotationDeg, rect.centerX(), rect.centerY())

        val fillPaint = shape.fillColorArgb?.let { fillHex ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = (tintColorArgb ?: fillHex).toInt()
                alpha = alphaInt
                if (shape.gradientEndArgb != null && tintColorArgb == null) {
                    shader = LinearGradient(
                        rect.left, rect.top, rect.right, rect.bottom,
                        fillHex.toInt(), shape.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                    )
                }
            }
        }

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: shape.strokeColorArgb).toInt()
            strokeWidth = shape.strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (kind) {
            ShapeKind.LINE -> canvas.drawLine(shape.startX, shape.startY, shape.endX, shape.endY, strokePaint)
            ShapeKind.RECTANGLE -> {
                fillPaint?.let { canvas.drawRoundRect(rect, 10f, 10f, it) }
                if (shape.strokeWidth > 0f) canvas.drawRoundRect(rect, 10f, 10f, strokePaint)
            }
            ShapeKind.FILL_BACKDROP -> fillPaint?.let { canvas.drawRect(rect, it) }
            ShapeKind.CIRCLE -> {
                fillPaint?.let { canvas.drawOval(rect, it) }
                if (shape.strokeWidth > 0f) canvas.drawOval(rect, strokePaint)
            }
            ShapeKind.POLYGON -> {
                val sides = shape.polygonSides.coerceIn(3, 12)
                val cx = rect.centerX(); val cy = rect.centerY()
                val rx = rect.width() / 2f; val ry = rect.height() / 2f
                val path = Path()
                for (i in 0 until sides) {
                    val angle = (i * 2.0 * PI / sides) - PI / 2.0
                    val px = cx + (cos(angle) * rx).toFloat()
                    val py = cy + (sin(angle) * ry).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                fillPaint?.let { canvas.drawPath(path, it) }
                if (shape.strokeWidth > 0f) canvas.drawPath(path, strokePaint)
            }
        }
        canvas.restore()
    }

    private fun resolveTextTypeface(fontStyleName: String, fallbackBold: Boolean): Typeface {
        return when (runCatching { TextFontStyle.valueOf(fontStyleName) }.getOrNull()) {
            TextFontStyle.BOLD_CARTOON -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            TextFontStyle.SERIF_HORROR -> Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            TextFontStyle.MONO_TECH -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            TextFontStyle.CLASSIC_CLEAN -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            TextFontStyle.COMIC_ITALIC -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            null -> if (fallbackBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    fun computeTextBounds(item: CanvasTextItem): RectF {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = item.fontSize.coerceIn(16f, 220f)
            typeface = resolveTextTypeface(item.fontStyle, item.isBold)
        }
        val lines = item.text.ifBlank { "Text" }.split("\n")
        val maxW = lines.maxOfOrNull { paint.measureText(it) }?.coerceAtLeast(80f) ?: 120f
        val lineH = item.fontSize * 1.18f
        val totalH = (lines.size * lineH).coerceAtLeast(item.fontSize)
        val padX = 34f
        val padY = 24f
        return RectF(
            item.x - maxW / 2f - padX,
            item.y - totalH / 2f - padY,
            item.x + maxW / 2f + padX,
            item.y + totalH / 2f + padY
        )
    }

    private fun drawTextItem(
        canvas: Canvas,
        item: CanvasTextItem,
        frame: Int,
        layerAlpha: Float,
        tintColorArgb: Long?,
        isSelected: Boolean
    ) {
        if (item.text.isBlank()) return
        if (frame < item.startFrame || frame > item.endFrame) return

        val inAnim = runCatching { TextInAnimation.valueOf(item.inAnimation) }.getOrDefault(TextInAnimation.NONE)
        val loopAnim = runCatching { TextLoopAnimation.valueOf(item.loopAnimation) }.getOrDefault(TextLoopAnimation.NONE)
        val outAnim = runCatching { TextOutAnimation.valueOf(item.outAnimation) }.getOrDefault(TextOutAnimation.NONE)
        val boxStyle = runCatching { TextBoxStyle.valueOf(item.boxStyle) }.getOrDefault(TextBoxStyle.NONE)

        val localFrame = (frame - item.startFrame).coerceAtLeast(0)
        val inDur = item.inDurationFrames.coerceAtLeast(1)
        val inT = (localFrame.toFloat() / inDur.toFloat()).coerceIn(0f, 1f)

        val remainingFrames = if (item.endFrame < 9000) (item.endFrame - frame).coerceAtLeast(0) else 9999
        val outDur = item.outDurationFrames.coerceAtLeast(1)
        val outT = if (outAnim != TextOutAnimation.NONE && remainingFrames < outDur) {
            1f - (remainingFrames.toFloat() / outDur.toFloat()).coerceIn(0f, 1f)
        } else 0f

        var animDx = 0f
        var animDy = 0f
        var animScaleX = 1f
        var animScaleY = 1f
        var animRot = 0f
        var animAlpha = (layerAlpha * item.opacity).coerceIn(0f, 1f)
        var visibleText = item.text

        // 1. Entrance Animation
        when (inAnim) {
            TextInAnimation.POP_BOUNCE -> {
                if (inT < 1f) {
                    val sc = when {
                        inT < 0.55f -> (inT / 0.55f) * 1.26f
                        inT < 0.80f -> 1.26f - ((inT - 0.55f) / 0.25f) * 0.34f
                        else -> 0.92f + ((inT - 0.80f) / 0.20f) * 0.08f
                    }
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (inT * 2.5f).coerceIn(0f, 1f)
                }
            }
            TextInAnimation.TYPEWRITER -> {
                if (inT < 1f) {
                    val count = (item.text.length * inT).toInt().coerceIn(1, item.text.length)
                    val caret = if ((localFrame / 3) % 2 == 0) "|" else ""
                    visibleText = item.text.take(count) + caret
                }
            }
            TextInAnimation.SLIDE_UP -> {
                val ease = 1f - (1f - inT) * (1f - inT) * (1f - inT)
                animDy += (1f - ease) * 110f
                animAlpha *= ease
            }
            TextInAnimation.SLIDE_LEFT -> {
                val ease = 1f - (1f - inT) * (1f - inT) * (1f - inT)
                animDx += (1f - ease) * 190f
                animAlpha *= ease
            }
            TextInAnimation.ZOOM_SLAM -> {
                if (inT < 1f) {
                    val sc = 2.6f - 1.6f * (inT * inT)
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (inT * 2f).coerceIn(0f, 1f)
                } else if (localFrame - inDur in 0..4) {
                    val amp = (5 - (localFrame - inDur)) * 4f
                    animDx += if (localFrame % 2 == 0) amp else -amp
                    animDy += if (localFrame % 3 == 0) -amp * 0.6f else amp * 0.6f
                }
            }
            TextInAnimation.SPIN_POP -> {
                val ease = 1f - (1f - inT) * (1f - inT)
                animScaleX *= ease.coerceAtLeast(0.05f)
                animScaleY *= ease.coerceAtLeast(0.05f)
                animRot += (1f - ease) * -360f
                animAlpha *= ease
            }
            TextInAnimation.FADE_IN -> {
                animAlpha *= inT
            }
            TextInAnimation.DROP_LETTERS, TextInAnimation.NONE -> Unit
        }

        // 2. Continuous Loop Animation
        val spd = item.loopSpeed.coerceIn(0.25f, 3f)
        val phase = localFrame * 0.28f * spd
        when (loopAnim) {
            TextLoopAnimation.BOUNCE -> {
                val b = kotlin.math.abs(sin(phase.toDouble())).toFloat()
                animDy -= b * 24f
                animScaleX *= (1.06f - b * 0.10f)
                animScaleY *= (0.94f + b * 0.12f)
            }
            TextLoopAnimation.FLOAT -> {
                animDy += sin(phase.toDouble() * 0.6).toFloat() * 14f
                animRot += cos(phase.toDouble() * 0.45).toFloat() * 3.5f
            }
            TextLoopAnimation.SHAKE_HORROR -> {
                val rng = Random(frame * 97 + item.id.hashCode())
                animDx += (rng.nextFloat() - 0.5f) * 14f * spd
                animDy += (rng.nextFloat() - 0.5f) * 12f * spd
                animRot += (rng.nextFloat() - 0.5f) * 4.5f
            }
            TextLoopAnimation.PULSE -> {
                val p = 1f + 0.11f * sin(phase.toDouble() * 1.1).toFloat()
                animScaleX *= p
                animScaleY *= p
            }
            TextLoopAnimation.GLITCH -> {
                if ((frame % 9) in 0..2) {
                    val rng = Random(frame * 131)
                    animDx += (rng.nextFloat() - 0.5f) * 12f
                }
            }
            TextLoopAnimation.WAVE, TextLoopAnimation.RAINBOW, TextLoopAnimation.NONE -> Unit
        }

        // 3. Exit Animation
        if (outT > 0f) {
            when (outAnim) {
                TextOutAnimation.FADE_OUT -> animAlpha *= (1f - outT)
                TextOutAnimation.POP_OUT -> {
                    val sc = (1f - outT).coerceAtLeast(0.01f)
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.SLIDE_DOWN -> {
                    animDy += outT * outT * 110f
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.ZOOM_OUT -> {
                    val sc = 1f + outT * 1.3f
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.NONE -> Unit
            }
        }

        val alphaInt = (animAlpha * 255f).toInt().coerceIn(0, 255)
        if (alphaInt <= 2) return

        val tf = resolveTextTypeface(item.fontStyle, item.isBold)
        val textSizePx = item.fontSize.coerceIn(16f, 220f)
        val lines = visibleText.split("\n")

        val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textSizePx
            typeface = tf
        }
        val maxLineW = lines.maxOfOrNull { measurePaint.measureText(it) }?.coerceAtLeast(40f) ?: 80f
        val lineHeight = textSizePx * 1.18f
        val totalTextH = lines.size * lineHeight

        canvas.save()
        canvas.translate(item.x + animDx, item.y + animDy)
        canvas.rotate(item.rotationDeg + animRot)
        canvas.scale(animScaleX, animScaleY)

        // 4. Optional Box / Banner / Speech Bubble Backdrop
        val boxPadX = 28f
        val boxPadY = 18f
        val boxRect = RectF(
            -maxLineW / 2f - boxPadX,
            -totalTextH / 2f - boxPadY,
            maxLineW / 2f + boxPadX,
            totalTextH / 2f + boxPadY
        )
        when (boxStyle) {
            TextBoxStyle.COMIC_BANNER -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = item.boxColorArgb.toInt()
                    alpha = (alphaInt * 0.92f).toInt()
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                    color = item.colorArgb.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 14f, 14f, bg)
                canvas.drawRoundRect(boxRect, 14f, 14f, brd)
            }
            TextBoxStyle.YOUTUBE_PILL -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (item.boxColorArgb == 0xDD0F172AL) 0xEEEF4444.toInt() else item.boxColorArgb.toInt()
                    alpha = alphaInt
                }
                val radius = boxRect.height() * 0.5f
                canvas.drawRoundRect(boxRect, radius, radius, bg)
            }
            TextBoxStyle.SPEECH_BUBBLE -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFAFFFFFF.toInt()
                    alpha = alphaInt
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                    color = 0xFF0F172AL.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 26f, 26f, bg)
                canvas.drawRoundRect(boxRect, 26f, 26f, brd)
                val tail = Path().apply {
                    moveTo(-18f, boxRect.bottom - 2f)
                    lineTo(-34f, boxRect.bottom + 28f)
                    lineTo(10f, boxRect.bottom - 2f)
                    close()
                }
                canvas.drawPath(tail, bg)
                canvas.drawPath(tail, brd)
            }
            TextBoxStyle.HORROR_BLOOD -> {
                val slash = Path().apply {
                    moveTo(boxRect.left - 18f, boxRect.top + 8f)
                    lineTo(boxRect.right + 22f, boxRect.top - 6f)
                    lineTo(boxRect.right + 8f, boxRect.bottom + 6f)
                    lineTo(boxRect.left - 26f, boxRect.bottom - 4f)
                    close()
                }
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xE622050A.toInt()
                    alpha = alphaInt
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                    color = 0xFFEF4444.toInt()
                    alpha = alphaInt
                }
                canvas.drawPath(slash, bg)
                canvas.drawPath(slash, brd)
            }
            TextBoxStyle.OUTLINE_GLOW -> {
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 14f
                    color = item.colorArgb.toInt()
                    alpha = (alphaInt * 0.35f).toInt()
                }
                val crisp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 3.5f
                    color = item.colorArgb.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 18f, 18f, glow)
                canvas.drawRoundRect(boxRect, 18f, 18f, crisp)
            }
            TextBoxStyle.NONE -> Unit
        }

        // 5. Prepare Fill, Stroke, Shadow & Glow Paints
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textSizePx
            typeface = tf
            textAlign = Paint.Align.CENTER
            style = Paint.Style.FILL
            color = (tintColorArgb ?: item.colorArgb).toInt()
            alpha = alphaInt
        }

        if (tintColorArgb == null) {
            if (loopAnim == TextLoopAnimation.RAINBOW) {
                val shift = (frame * 6f * spd) % 360f
                val c1 = Color.HSVToColor(alphaInt, floatArrayOf(shift, 0.85f, 1f))
                val c2 = Color.HSVToColor(alphaInt, floatArrayOf((shift + 120f) % 360f, 0.85f, 1f))
                val c3 = Color.HSVToColor(alphaInt, floatArrayOf((shift + 240f) % 360f, 0.85f, 1f))
                fillPaint.shader = LinearGradient(
                    -maxLineW / 2f, 0f, maxLineW / 2f, 0f,
                    intArrayOf(c1, c2, c3), null, Shader.TileMode.CLAMP
                )
            } else if (item.gradientEndArgb != null) {
                fillPaint.shader = LinearGradient(
                    0f, -totalTextH / 2f, 0f, totalTextH / 2f,
                    item.colorArgb.toInt(), item.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                )
            }
        }

        val strokePaint = if (item.strokeWidth > 0.5f) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.STROKE
                strokeWidth = item.strokeWidth
                strokeJoin = Paint.Join.ROUND
                color = (tintColorArgb ?: item.strokeColorArgb).toInt()
                alpha = alphaInt
            }
        } else null

        val shadowPaint = if (item.shadowEnabled) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.FILL
                color = 0xAA000000.toInt()
                alpha = (alphaInt * 0.65f).toInt()
            }
        } else null

        val glowPaint = if (item.glowEnabled || boxStyle == TextBoxStyle.OUTLINE_GLOW) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.STROKE
                strokeWidth = item.strokeWidth + 14f
                strokeJoin = Paint.Join.ROUND
                color = (tintColorArgb ?: item.colorArgb).toInt()
                alpha = (alphaInt * 0.34f).toInt()
            }
        } else null

        val perCharMode = (loopAnim == TextLoopAnimation.WAVE) || (inAnim == TextInAnimation.DROP_LETTERS && inT < 1f)
        val startBaselineY = -totalTextH / 2f + textSizePx * 0.88f

        lines.forEachIndexed { lineIdx, line ->
            val baseY = startBaselineY + lineIdx * lineHeight

            // Cyber Glitch RGB chromatic ghosts
            if (loopAnim == TextLoopAnimation.GLITCH && (frame % 9) in 0..2 && tintColorArgb == null) {
                val cyanP = Paint(fillPaint).apply { shader = null; color = 0xAA22D3EE.toInt() }
                val pinkP = Paint(fillPaint).apply { shader = null; color = 0xAAFB7185.toInt() }
                canvas.drawText(line, -7f, baseY - 2f, cyanP)
                canvas.drawText(line, 7f, baseY + 2f, pinkP)
            }

            if (perCharMode) {
                val lineW = measurePaint.measureText(line)
                var curX = -lineW / 2f
                line.forEachIndexed { charIdx, ch ->
                    val chStr = ch.toString()
                    val chW = measurePaint.measureText(chStr)
                    val cx = curX + chW / 2f
                    var cy = baseY
                    var chAlpha = alphaInt

                    if (loopAnim == TextLoopAnimation.WAVE) {
                        cy += sin((phase + charIdx * 0.55f).toDouble()).toFloat() * (textSizePx * 0.22f)
                    }
                    if (inAnim == TextInAnimation.DROP_LETTERS && inT < 1f) {
                        val charDelay = charIdx.toFloat() / (line.length.coerceAtLeast(1) + 2).toFloat()
                        val ct = ((inT - charDelay * 0.55f) / 0.45f).coerceIn(0f, 1f)
                        val drop = (1f - ct) * (1f - ct) * 110f
                        cy -= drop
                        chAlpha = (alphaInt * ct).toInt().coerceIn(0, 255)
                    }

                    if (chAlpha > 2) {
                        shadowPaint?.let {
                            it.alpha = (chAlpha * 0.65f).toInt()
                            canvas.drawText(chStr, cx + 5f, cy + 6f, it)
                        }
                        glowPaint?.let {
                            it.alpha = (chAlpha * 0.34f).toInt()
                            canvas.drawText(chStr, cx, cy, it)
                        }
                        strokePaint?.let {
                            it.alpha = chAlpha
                            canvas.drawText(chStr, cx, cy, it)
                        }
                        fillPaint.alpha = chAlpha
                        canvas.drawText(chStr, cx, cy, fillPaint)
                    }
                    curX += chW
                }
            } else {
                shadowPaint?.let { canvas.drawText(line, 5f, baseY + 6f, it) }
                glowPaint?.let { canvas.drawText(line, 0f, baseY, it) }
                strokePaint?.let { canvas.drawText(line, 0f, baseY, it) }
                canvas.drawText(line, 0f, baseY, fillPaint)
            }
        }

        // 6. Editor Selection Frame (only when selected & not playing/exporting)
        if (isSelected) {
            val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 3f
                color = 0xFF2DD4BF.toInt()
                pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
            }
            val selRect = RectF(boxRect.left - 8f, boxRect.top - 8f, boxRect.right + 8f, boxRect.bottom + 8f)
            canvas.drawRoundRect(selRect, 12f, 12f, selPaint)
            val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt() }
            canvas.drawCircle(selRect.left, selRect.top, 7f, dotFill)
            canvas.drawCircle(selRect.right, selRect.top, 7f, dotFill)
            canvas.drawCircle(selRect.left, selRect.bottom, 7f, dotFill)
            canvas.drawCircle(selRect.right, selRect.bottom, 7f, dotFill)
        }

        canvas.restore()
    }

    /**
     * Live Frame-Animated Facial Expressions (Talking Loop, Audio Lip-Sync, Crying Tears,
     * Laughing, Auto-Blinking, Angry, Scared/Horror, Surprised) rendered at head coordinates.
     */
    fun drawModularFaceRig(
        canvas: Canvas,
        eyePackName: String,
        mouthPhonemeName: String,
        eyeColorArgb: Long,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        alphaInt: Int,
        tintColorArgb: Long?,
        isSideProfile: Boolean = false,
        eyebrowStyleName: String = EyebrowStyle.NORMAL.name
    ) {
        val eyePack = runCatching { EyePackStyle.valueOf(eyePackName) }.getOrDefault(EyePackStyle.AUTO_BLINK)
        val eyebrowStyle = runCatching { EyebrowStyle.valueOf(eyebrowStyleName) }.getOrDefault(EyebrowStyle.NORMAL)
        val requestedMouth = runCatching { MouthPhoneme.valueOf(mouthPhonemeName) }.getOrDefault(MouthPhoneme.AUTO_LIPSYNC)
        val safeFps = fps.coerceAtLeast(1)

        // Resolve live frame-animated mouth phoneme (Continuous Talking Loop OR Audio Lip-Sync)
        val activeMouth = when (requestedMouth) {
            MouthPhoneme.AUTO_LIPSYNC -> InterpolationEngine.evaluateLipSyncPhoneme(audioTracks, frame, safeFps)
            MouthPhoneme.TALKING_LOOP -> {
                val talkCycle = listOf(
                    MouthPhoneme.REST, MouthPhoneme.A, MouthPhoneme.E, MouthPhoneme.O,
                    MouthPhoneme.I, MouthPhoneme.A, MouthPhoneme.U, MouthPhoneme.E
                )
                val stepFrames = (safeFps / 7).coerceAtLeast(2)
                talkCycle[(frame / stepFrames) % talkCycle.size]
            }
            else -> requestedMouth
        }

        fun fill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        // Subtle animated head emotion motion (joyful laugh bounce / crying sob / horror tremble)
        val isLaughing = eyePack == EyePackStyle.LAUGHING || requestedMouth == MouthPhoneme.LAUGHING
        val isCrying = eyePack == EyePackStyle.SAD_TEARS || requestedMouth == MouthPhoneme.CRYING
        val isScared = eyePack == EyePackStyle.SCARED_HORROR || requestedMouth == MouthPhoneme.SCARED
        val timeRad = (frame.toDouble() / safeFps) * 2.0 * PI

        val faceJitterX = when {
            isScared -> sin(frame * 2.4).toFloat() * 2.2f
            isCrying -> sin(frame * 1.3).toFloat() * 1.1f
            else -> 0f
        }
        val faceBounceY = when {
            isLaughing -> -kotlin.math.abs(sin(timeRad * 3.4)).toFloat() * 5.2f
            isCrying -> sin(timeRad * 2.1).toFloat() * 2.4f
            else -> 0f
        }

        canvas.save()
        canvas.translate(faceJitterX, faceBounceY)

        // Periodic natural blink every ~2.4 seconds (multi-frame smooth blink)
        val blinkPeriod = (safeFps * 2.4f).toInt().coerceAtLeast(18)
        val blinkPhase = frame % blinkPeriod
        val isBlinkingNow = eyePack == EyePackStyle.AUTO_BLINK && blinkPhase in 0..2

        val eyeY = -8f
        val eyeXs = if (isSideProfile) listOf(18f) else listOf(-18f, 18f)
        eyeXs.forEachIndexed { idx, ex ->
            when {
                isBlinkingNow || (eyePack == EyePackStyle.WINK && (isSideProfile || idx == 1)) -> {
                    canvas.drawArc(RectF(ex - 9f, eyeY - 4f, ex + 9f, eyeY + 8f), 195f, 150f, false, stroke)
                }
                eyePack == EyePackStyle.HAPPY || eyePack == EyePackStyle.LAUGHING -> {
                    val squintLift = if (isLaughing) sin(timeRad * 6.8).toFloat() * 1.6f else 0f
                    canvas.drawArc(
                        RectF(ex - 11f, eyeY - 7f + squintLift, ex + 11f, eyeY + 9f + squintLift),
                        195f, 150f, false, stroke
                    )
                    if (isLaughing) {
                        // Rosy happy blush cheeks
                        canvas.drawOval(
                            RectF(ex - 9f, eyeY + 9f, ex + 9f, eyeY + 17f),
                            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = (tintColorArgb ?: 0xFFFF7AA2L).toInt()
                                alpha = (alphaInt * 0.48f).toInt()
                            }
                        )
                    }
                }
                else -> {
                    val pupilShiftX = when {
                        isScared -> sin(frame * 1.9 + idx).toFloat() * 2.0f
                        isSideProfile -> 3.5f
                        eyePack == EyePackStyle.SIDE_LOOK -> 4.5f
                        else -> 0f
                    }
                    val pupilShiftY = if (isScared) cos(frame * 2.3 + idx).toFloat() * 1.6f else 0f
                    val eyePulse = if (eyePack == EyePackStyle.SURPRISED) 1f + 0.06f * sin(timeRad * 4.0).toFloat() else 1f
                    val eyeR = (when (eyePack) {
                        EyePackStyle.SURPRISED, EyePackStyle.SCARED_HORROR -> 13f
                        else -> 10.5f
                    }) * eyePulse
                    val eyeRx = if (isSideProfile) eyeR * 0.78f else eyeR
                    canvas.drawOval(RectF(ex - eyeRx, eyeY - eyeR * 1.15f, ex + eyeRx, eyeY + eyeR * 1.15f), fill(0xFFFFFFFFL))

                    val irisR = when (eyePack) {
                        EyePackStyle.SCARED_HORROR -> 3.6f
                        EyePackStyle.SURPRISED -> 5.2f
                        else -> 6.8f
                    }
                    canvas.drawCircle(ex + pupilShiftX, eyeY + 1f + pupilShiftY, irisR, fill(eyeColorArgb))
                    canvas.drawCircle(ex + pupilShiftX, eyeY + 1f + pupilShiftY, irisR * 0.55f, fill(0xFF0F172AL))
                    canvas.drawCircle(ex - 2.5f + pupilShiftX * 0.5f, eyeY - 3.5f, 2.6f, fill(0xFFFFFFFFL))
                    canvas.drawOval(RectF(ex - eyeRx, eyeY - eyeR * 1.15f, ex + eyeRx, eyeY + eyeR * 1.15f), stroke)

                    // Live Animated Falling Tear Drops (Crying Loop)
                    if (isCrying) {
                        // Glossy tear pool at lower eyelid
                        canvas.drawOval(RectF(ex - 8f, eyeY + 7f, ex + 8f, eyeY + 13f), fill(0xFF7DD3FCL))
                        val drop1 = ((frame * 5 + idx * 11) % 34).toFloat()
                        val drop2 = ((frame * 5 + 17 + idx * 7) % 34).toFloat()
                        val tearPaint = fill(0xFF38BDF8L)
                        canvas.drawOval(RectF(ex - 4.2f, eyeY + 11f + drop1, ex + 4.2f, eyeY + 23f + drop1), tearPaint)
                        canvas.drawOval(RectF(ex - 2.8f + (if (idx == 0) -4f else 4f), eyeY + 10f + drop2, ex + 2.8f + (if (idx == 0) -4f else 4f), eyeY + 19f + drop2), tearPaint)
                    }

                    // Animated Horror Sweat Drop
                    if (isScared && (isSideProfile || idx == 1)) {
                        val sweatDrop = ((frame * 3) % 18).toFloat()
                        canvas.drawOval(RectF(ex + 13f, eyeY - 12f + sweatDrop, ex + 19f, eyeY - 2f + sweatDrop), fill(0xFF7DD3FCL))
                    }
                }
            }
            val browTremble = when {
                isCrying -> sin(frame * 1.6 + idx).toFloat() * 1.6f
                eyePack == EyePackStyle.ANGRY -> sin(frame * 2.1).toFloat() * 1.1f
                isScared -> sin(frame * 2.6).toFloat() * 1.5f
                else -> 0f
            }
            val browLift = when {
                eyebrowStyle == EyebrowStyle.RAISED -> -8.5f
                eyebrowStyle == EyebrowStyle.ANGRY -> 2.5f
                eyebrowStyle == EyebrowStyle.WORRIED -> -2.5f
                eyePack == EyePackStyle.SURPRISED || eyePack == EyePackStyle.SCARED_HORROR -> -7f
                eyePack == EyePackStyle.LAUGHING -> -3f
                else -> 0f
            } + browTremble
            val tilt = when {
                eyebrowStyle == EyebrowStyle.ANGRY -> if (idx == 0 && !isSideProfile) 7.5f else -7.5f
                eyebrowStyle == EyebrowStyle.WORRIED -> if (idx == 0 && !isSideProfile) -6.5f else 6.5f
                eyebrowStyle == EyebrowStyle.RAISED -> if (idx == 0 && !isSideProfile) -2f else 2f
                eyePack == EyePackStyle.ANGRY -> if (idx == 0 && !isSideProfile) 6.5f else -6.5f
                eyePack == EyePackStyle.SAD_TEARS || eyePack == EyePackStyle.SCARED_HORROR -> if (idx == 0 && !isSideProfile) -5.5f else 5.5f
                else -> 0f
            }
            canvas.drawLine(ex - 8.5f, eyeY - 17f + browLift - tilt, ex + 8.5f, eyeY - 17f + browLift + tilt, stroke)
        }

        // Animated Mouth (Talking Loop, Lip-Sync, Laughing, Crying, Scared, or Manual Phoneme)
        val mouthX = if (isSideProfile) 24f else 0f
        val mouthScaleX = if (isSideProfile) 0.72f else 1f
        val mouthY = 18f
        val mouthFill = fill(0xFFBE123CL)
        val tongueFill = fill(0xFFFB7185L)
        val teethFill = fill(0xFFFFFFFFL)
        canvas.save()
        canvas.translate(mouthX, 0f)
        canvas.scale(mouthScaleX, 1f)
        when (activeMouth) {
            MouthPhoneme.LAUGHING -> {
                val openPulse = 1f + 0.22f * kotlin.math.abs(sin(timeRad * 4.5)).toFloat()
                val rect = RectF(-18f, mouthY - 8f, 18f, mouthY + 14f * openPulse)
                canvas.drawArc(rect, 0f, 180f, true, mouthFill)
                canvas.drawRect(RectF(-14f, mouthY - 1f, 14f, mouthY + 4f), teethFill)
                canvas.drawOval(RectF(-9f, mouthY + 5f * openPulse, 9f, mouthY + 13f * openPulse), tongueFill)
                canvas.drawArc(rect, 0f, 180f, true, stroke)
            }
            MouthPhoneme.CRYING -> {
                val sobPulse = 1f + 0.18f * sin(timeRad * 3.8).toFloat()
                val tremble = sin(frame * 2.2).toFloat() * 1.4f
                val cryRect = RectF(-15f, mouthY - 4f + tremble, 15f, mouthY + 15f * sobPulse + tremble)
                canvas.drawArc(cryRect, 180f, 180f, true, mouthFill)
                canvas.drawArc(cryRect, 180f, 180f, true, stroke)
            }
            MouthPhoneme.SCARED -> {
                val shake = sin(frame * 3.1).toFloat() * 2f
                val scaredRect = RectF(-13f, mouthY - 9f + shake, 13f, mouthY + 13f + shake)
                canvas.drawRoundRect(scaredRect, 8f, 8f, mouthFill)
                canvas.drawRect(RectF(-9f, mouthY - 7f + shake, 9f, mouthY - 2f + shake), teethFill)
                canvas.drawRect(RectF(-9f, mouthY + 6f + shake, 9f, mouthY + 10f + shake), teethFill)
                canvas.drawRoundRect(scaredRect, 8f, 8f, stroke)
            }
            MouthPhoneme.REST -> {
                canvas.drawArc(RectF(-12f, mouthY - 5f, 12f, mouthY + 6f), 15f, 150f, false, stroke)
            }
            MouthPhoneme.SMILE -> {
                canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 12f), 0f, 180f, true, teethFill)
                canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 12f), 0f, 180f, true, stroke)
            }
            MouthPhoneme.A -> {
                canvas.drawOval(RectF(-14f, mouthY - 8f, 14f, mouthY + 14f), mouthFill)
                canvas.drawRect(RectF(-10f, mouthY - 7f, 10f, mouthY - 2f), teethFill)
                canvas.drawOval(RectF(-14f, mouthY - 8f, 14f, mouthY + 14f), stroke)
            }
            MouthPhoneme.E -> {
                canvas.drawRoundRect(RectF(-16f, mouthY - 5f, 16f, mouthY + 7f), 6f, 6f, mouthFill)
                canvas.drawLine(-13f, mouthY, 13f, mouthY, Paint(stroke).apply { color = Color.WHITE; strokeWidth = 3f })
                canvas.drawRoundRect(RectF(-16f, mouthY - 5f, 16f, mouthY + 7f), 6f, 6f, stroke)
            }
            MouthPhoneme.I -> {
                canvas.drawRoundRect(RectF(-14f, mouthY - 4f, 14f, mouthY + 4f), 4f, 4f, teethFill)
                canvas.drawRoundRect(RectF(-14f, mouthY - 4f, 14f, mouthY + 4f), 4f, 4f, stroke)
            }
            MouthPhoneme.O -> {
                canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), mouthFill)
                canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), stroke)
            }
            MouthPhoneme.U -> {
                canvas.drawCircle(0f, mouthY + 1f, 6.5f, mouthFill)
                canvas.drawCircle(0f, mouthY + 1f, 6.5f, stroke)
            }
            MouthPhoneme.SHOCK -> {
                canvas.drawOval(RectF(-12f, mouthY - 11f, 12f, mouthY + 15f), mouthFill)
                canvas.drawOval(RectF(-12f, mouthY - 11f, 12f, mouthY + 15f), stroke)
            }
            else -> {
                canvas.drawArc(RectF(-12f, mouthY - 5f, 12f, mouthY + 6f), 15f, 150f, false, stroke)
            }
        }
        canvas.restore()
        canvas.restore()
    }

    fun drawCharacter(
        canvas: Canvas,
        c: CharacterSpec,
        layerAlpha: Float,
        tintColorArgb: Long?,
        frame: Int = 0,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList()
    ) {
        val alphaInt = (layerAlpha * 255).toInt().coerceIn(0, 255)
        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 4.5f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        canvas.save()
        canvas.translate(c.x, c.y)
        val viewAngle = runCatching { CharacterViewAngle.valueOf(c.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val isBack = viewAngle == CharacterViewAngle.BACK
        val sideFlipX = if (viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.BACK_LEFT_34) -1f else 1f
        canvas.scale(c.scale * c.baseScaleX.coerceIn(0.1f, 5.0f) * sideFlipX, c.scale * c.baseScaleY.coerceIn(0.1f, 5.0f))

        val legSpread = when (c.pose) {
            "WALK_A" -> 34f; "WALK_B" -> -34f; "JUMP" -> 42f; "HERO" -> 28f; else -> 18f
        }
        val bodyBob = when (c.pose) {
            "JUMP" -> -36f; "SIT" -> 28f; "WALK_A", "WALK_B" -> -6f; else -> 0f
        }
        canvas.translate(0f, bodyBob)

        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((alphaInt * 0.28f).toInt(), 0, 0, 0)
        }
        canvas.drawOval(RectF(-58f, 152f - bodyBob, 58f, 174f - bodyBob), shadowPaint)

        val pantsPaint = pFill(c.pantsColorArgb)
        val shirtPaint = pFill(c.shirtColorArgb)
        val skinPaint = pFill(c.skinToneArgb)
        val dupattaPaint = pFill(c.dupattaColorArgb)
        val leftArmAngle = when (c.pose) { "JUMP" -> -140f; "HERO" -> -25f; "WALK_A" -> 28f; "WALK_B" -> -28f; else -> 18f }
        val rightArmAngle = when (c.pose) { "WAVE" -> -135f; "JUMP" -> 140f; "HERO" -> 25f; "WALK_A" -> -28f; "WALK_B" -> 28f; else -> -18f }

        val torsoHalfW = (if (isSide) 28f else if (isFront34 || isBack34) 36f else 42f) * c.shoulderWidth.coerceIn(0.7f, 1.5f)
        val bellyExtra = c.bellyPlumpness.coerceIn(0f, 1f) * 20f
        val torsoHScale = c.torsoScale.coerceIn(0.75f, 1.4f)

        if (c.shirtStyle == "CAPE" && !isBack && !isBack34) {
            val capePath = if (isSide) {
                Path().apply { moveTo(-24f, -4f); lineTo(4f, -4f); lineTo(-14f, 118f); lineTo(-58f, 118f); close() }
            } else {
                Path().apply { moveTo(-36f, -6f); lineTo(36f, -6f); lineTo(66f, 118f); lineTo(-66f, 118f); close() }
            }
            canvas.drawPath(capePath, shirtPaint); canvas.drawPath(capePath, outline)
        }

        if (isSide) {
            // Far arm behind torso
            canvas.save()
            canvas.translate(8f, 6f); canvas.rotate(-leftArmAngle)
            canvas.drawRoundRect(RectF(-10f, 0f, 10f, 66f), 10f, 10f, shirtPaint)
            canvas.drawRoundRect(RectF(-10f, 0f, 10f, 66f), 10f, 10f, outline)
            canvas.drawCircle(0f, 68f, 10f, skinPaint); canvas.drawCircle(0f, 68f, 10f, outline)
            canvas.restore()

            val legFar = RectF(-14f - legSpread * 0.45f, 68f, 10f - legSpread * 0.25f, if (c.pose == "SIT") 124f else 156f)
            val legNear = RectF(-8f + legSpread * 0.25f, 68f, 16f + legSpread * 0.45f, if (c.pose == "SIT") 124f else 156f)
            canvas.drawRoundRect(legFar, 12f, 12f, pantsPaint); canvas.drawRoundRect(legFar, 12f, 12f, outline)
            canvas.drawRoundRect(legNear, 12f, 12f, pantsPaint); canvas.drawRoundRect(legNear, 12f, 12f, outline)

            val torso = RectF(-torsoHalfW, -14f * torsoHScale, torsoHalfW + bellyExtra, 82f * torsoHScale)
            canvas.drawRoundRect(torso, 22f, 22f, shirtPaint); canvas.drawRoundRect(torso, 22f, 22f, outline)
            drawTraditionalTorsoDetails(canvas, c, torso, shirtPaint, pantsPaint, dupattaPaint, outline, isBack = false)

            canvas.save()
            canvas.translate(-4f, 6f); canvas.rotate(rightArmAngle)
            canvas.drawRoundRect(RectF(-11f, 0f, 11f, 68f), 10f, 10f, shirtPaint)
            canvas.drawRoundRect(RectF(-11f, 0f, 11f, 68f), 10f, 10f, outline)
            canvas.drawCircle(0f, 70f, 10.5f, skinPaint); canvas.drawCircle(0f, 70f, 10.5f, outline)
            canvas.restore()
        } else {
            val legL = RectF(-30f - legSpread * 0.4f, 68f, -6f - legSpread * 0.2f, if (c.pose == "SIT") 124f else 156f)
            val legR = RectF(6f + legSpread * 0.2f, 68f, 30f + legSpread * 0.4f, if (c.pose == "SIT") 124f else 156f)
            if (c.shirtStyle == "SAREE" || c.shirtStyle == "PANJABI_DHOTI" || c.shirtStyle == "VILLAGE_GHOST") {
                val drapeRect = RectF(-36f - bellyExtra * 0.4f, 64f, 36f + bellyExtra * 0.4f, 152f)
                canvas.drawRoundRect(drapeRect, 14f, 14f, pantsPaint)
                canvas.drawRoundRect(drapeRect, 14f, 14f, outline)
                // Pleat line
                canvas.drawLine(0f, 68f, 0f, 150f, outline)
            } else {
                canvas.drawRoundRect(legL, 12f, 12f, pantsPaint); canvas.drawRoundRect(legL, 12f, 12f, outline)
                canvas.drawRoundRect(legR, 12f, 12f, pantsPaint); canvas.drawRoundRect(legR, 12f, 12f, outline)
            }

            val torso = RectF(-torsoHalfW - bellyExtra * 0.5f, -14f * torsoHScale, torsoHalfW + bellyExtra * 0.5f, 82f * torsoHScale)
            canvas.drawRoundRect(torso, 24f + bellyExtra * 0.4f, 24f + bellyExtra * 0.4f, shirtPaint)
            canvas.drawRoundRect(torso, 24f + bellyExtra * 0.4f, 24f + bellyExtra * 0.4f, outline)
            drawTraditionalTorsoDetails(canvas, c, torso, shirtPaint, pantsPaint, dupattaPaint, outline, isBack = isBack || isBack34)

            listOf(Triple(-torsoHalfW, leftArmAngle, 1f), Triple(torsoHalfW, rightArmAngle, 1f)).forEach { (ax, ang, _) ->
                canvas.save()
                canvas.translate(ax, 4f); canvas.rotate(ang)
                canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, shirtPaint)
                canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, outline)
                if (c.hasBangles) {
                    val bPaint = pFill(c.banglesColorArgb)
                    canvas.drawRect(-12f, 52f, 12f, 57f, bPaint)
                    canvas.drawRect(-12f, 58f, 12f, 62f, bPaint)
                }
                canvas.drawCircle(0f, 70f, 11f, skinPaint); canvas.drawCircle(0f, 70f, 11f, outline)
                canvas.restore()
            }

            if ((isBack || isBack34) && c.shirtStyle == "CAPE") {
                val capePath = Path().apply {
                    moveTo(-38f, -8f); lineTo(38f, -8f); lineTo(62f, 124f); lineTo(-62f, 124f); close()
                }
                canvas.drawPath(capePath, shirtPaint); canvas.drawPath(capePath, outline)
            }
            if ((isBack || isBack34) && c.shirtStyle == "HOODIE") {
                canvas.drawArc(RectF(-30f, -20f, 30f, 28f), 0f, 180f, true, shirtPaint)
                canvas.drawArc(RectF(-30f, -20f, 30f, 28f), 0f, 180f, true, outline)
            }
        }

        // Head + Hair + Modular Face (All 8 Turnaround Angles!)
        canvas.save()
        canvas.translate(0f, -66f * torsoHScale)
        drawHeadSculpt(canvas, c, skinPaint, pFill(c.hairColorArgb), outline, alphaInt, tintColorArgb, frame, fps, audioTracks, viewAngle)
        canvas.restore()

        canvas.restore()
    }

    private fun drawTraditionalTorsoDetails(
        canvas: Canvas,
        c: CharacterSpec,
        torso: RectF,
        shirtPaint: Paint,
        pantsPaint: Paint,
        dupattaPaint: Paint,
        outline: Paint,
        isBack: Boolean
    ) {
        when (c.shirtStyle) {
            "SAREE" -> {
                // Diagonal Saree Pallu / Anchhal drape across chest or back
                val pallu = Path().apply {
                    if (isBack) {
                        moveTo(torso.left + 8f, torso.top + 4f)
                        lineTo(torso.left + 32f, torso.top + 4f)
                        lineTo(torso.right - 8f, torso.bottom + 26f)
                        lineTo(torso.right - 34f, torso.bottom + 26f)
                    } else {
                        moveTo(torso.left + 6f, torso.top + 4f)
                        lineTo(torso.left + 30f, torso.top + 4f)
                        lineTo(torso.right - 4f, torso.bottom)
                        lineTo(torso.right - 28f, torso.bottom)
                    }
                    close()
                }
                canvas.drawPath(pallu, dupattaPaint)
                canvas.drawPath(pallu, outline)
            }
            "SALWAR_KAMEEZ" -> {
                // U-drape Dupatta scarf across shoulders
                val dup = Path().apply {
                    moveTo(torso.left + 6f, torso.top + 4f)
                    quadTo(torso.centerX(), torso.bottom - 14f, torso.right - 6f, torso.top + 4f)
                }
                val dupStroke = Paint(dupattaPaint).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 14f
                    strokeCap = Paint.Cap.ROUND
                }
                canvas.drawPath(dup, dupStroke)
            }
            "PANJABI_DHOTI", "KURTA_PAJAMA" -> {
                // Classic Kurta / Panjabi placket & collar border + longer hem
                val hemRect = RectF(torso.left - 3f, torso.bottom - 10f, torso.right + 3f, torso.bottom + 22f)
                canvas.drawRoundRect(hemRect, 10f, 10f, shirtPaint)
                canvas.drawRoundRect(hemRect, 10f, 10f, outline)
                if (!isBack) {
                    canvas.drawLine(torso.centerX(), torso.top + 4f, torso.centerX(), torso.centerY() + 6f, outline)
                    canvas.drawCircle(torso.centerX(), torso.top + 18f, 3f, dupattaPaint)
                    canvas.drawCircle(torso.centerX(), torso.top + 32f, 3f, dupattaPaint)
                }
                if (c.shirtStyle == "PANJABI_DHOTI") {
                    // Folded Uttariyo / Zamindar shawl over shoulder
                    val shawl = RectF(torso.left + 4f, torso.top + 2f, torso.left + 22f, torso.bottom + 14f)
                    canvas.drawRoundRect(shawl, 6f, 6f, dupattaPaint)
                    canvas.drawRoundRect(shawl, 6f, 6f, outline)
                }
            }
            "TANTRIK_ROBE" -> {
                // Rudraksha bead mala necklace
                for (i in -3..3) {
                    val mx = torso.centerX() + i * 9f
                    val my = torso.top + 24f + (12f - kotlin.math.abs(i) * 3.5f)
                    canvas.drawCircle(mx, my, 4.5f, dupattaPaint)
                    canvas.drawCircle(mx, my, 4.5f, outline)
                }
            }
            "VILLAGE_GHOST" -> {
                // Tattered spectral hem strips
                val ragged = Path().apply {
                    moveTo(torso.left, torso.bottom - 4f)
                    lineTo(torso.left - 8f, torso.bottom + 26f)
                    lineTo(torso.centerX() - 12f, torso.bottom + 12f)
                    lineTo(torso.centerX(), torso.bottom + 32f)
                    lineTo(torso.centerX() + 14f, torso.bottom + 12f)
                    lineTo(torso.right + 8f, torso.bottom + 24f)
                    lineTo(torso.right, torso.bottom - 4f)
                    close()
                }
                canvas.drawPath(ragged, shirtPaint)
            }
        }
    }

    private fun drawHeadSculpt(
        canvas: Canvas,
        c: CharacterSpec,
        skinPaint: Paint,
        hairPaint: Paint,
        outline: Paint,
        alphaInt: Int,
        tintColorArgb: Long?,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT,
        eyebrowStyleName: String = EyebrowStyle.NORMAL.name
    ) {
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val isBack = viewAngle == CharacterViewAngle.BACK

        val headRect = when {
            isSide -> RectF(-42f, -56f, 44f, 52f)
            isFront34 || isBack34 -> RectF(-46f, -56f, 46f, 52f)
            c.faceShape == "ROUND" -> RectF(-54f, -56f, 54f, 52f)
            c.faceShape == "SQUARE" -> RectF(-50f, -56f, 50f, 52f)
            c.faceShape == "CHIBI" -> RectF(-60f, -62f, 60f, 54f)
            else -> RectF(-48f, -58f, 48f, 52f)
        }
        val r = if (c.faceShape == "SQUARE") 20f else 50f

        if (isSide) {
            val nosePath = Path().apply {
                moveTo(38f, -10f); lineTo(54f, 4f); lineTo(40f, 12f); close()
            }
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawPath(nosePath, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
            canvas.drawPath(nosePath, outline)
            canvas.drawOval(RectF(-16f, -6f, 0f, 16f), skinPaint)
            canvas.drawOval(RectF(-16f, -6f, 0f, 16f), outline)
        } else if (isBack34) {
            // Module 3: 3/4 Back Dialogue Angle — ear & cheek profile hint + full back-of-head hair!
            val cheekProfile = Path().apply {
                moveTo(36f, -20f)
                quadTo(52f, -2f, 44f, 24f)
                quadTo(34f, 42f, 18f, 46f)
                close()
            }
            canvas.drawPath(cheekProfile, skinPaint)
            canvas.drawPath(cheekProfile, outline)
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
            // Prominent near ear facing camera slightly turned away
            canvas.drawOval(RectF(6f, -4f, 24f, 20f), skinPaint)
            canvas.drawOval(RectF(6f, -4f, 24f, 20f), outline)
        } else if (isFront34) {
            // 3/4 Front Dialogue Angle — subtle nose bridge & near/far ear depth
            canvas.drawCircle(-44f, 2f, 10f, skinPaint); canvas.drawCircle(-44f, 2f, 10f, outline)
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
            val nose34 = Path().apply { moveTo(18f, -6f); lineTo(28f, 5f); lineTo(18f, 11f) }
            canvas.drawPath(nose34, outline)
        } else {
            canvas.drawCircle(-49f, 2f, 11f, skinPaint); canvas.drawCircle(-49f, 2f, 11f, outline)
            canvas.drawCircle(49f, 2f, 11f, skinPaint); canvas.drawCircle(49f, 2f, 11f, outline)
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
        }

        fun drawTraditionalBackHair(shiftX: Float) {
            when (c.hairStyle) {
                "BRAID_BENI" -> {
                    // Authentic Bengali / Indian long woven braid ("Beni") hanging down back
                    for (seg in 0..4) {
                        val cy = 36f + seg * 20f
                        val sw = (17f - seg * 1.8f).coerceAtLeast(7f)
                        canvas.drawOval(RectF(shiftX - sw, cy - 12f, shiftX + sw, cy + 12f), hairPaint)
                        canvas.drawOval(RectF(shiftX - sw, cy - 12f, shiftX + sw, cy + 12f), outline)
                    }
                    // Red ribbon tie at braid tip
                    val rib = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFDC2626.toInt(); alpha = alphaInt }
                    canvas.drawRoundRect(RectF(shiftX - 10f, 118f, shiftX + 10f, 128f), 4f, 4f, rib)
                }
                "TRADITIONAL_BUN" -> {
                    // Classic Bengali Khopa / Traditional Bun at back of head
                    canvas.drawCircle(shiftX, 22f, 25f, hairPaint)
                    canvas.drawCircle(shiftX, 22f, 25f, outline)
                    // White jasmine gajra garland arc
                    val gajra = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFFFFFBF0.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; alpha = alphaInt
                    }
                    canvas.drawArc(RectF(shiftX - 23f, 0f, shiftX + 23f, 44f), 200f, 140f, false, gajra)
                }
                "SAGE_JATA" -> {
                    // Top-knot dreadlocks bun for Tantrik / Sage
                    canvas.drawCircle(shiftX, -70f, 22f, hairPaint)
                    canvas.drawCircle(shiftX, -70f, 22f, outline)
                    canvas.drawRoundRect(RectF(shiftX - 42f, -10f, shiftX + 42f, 76f), 18f, 18f, hairPaint)
                }
                "LONG_GHOST" -> {
                    // Long flowing dark hair hanging below shoulders
                    val hairFlow = Path().apply {
                        moveTo(headRect.left - 8f, -14f)
                        lineTo(headRect.left - 18f, 116f)
                        lineTo(headRect.centerX() - 16f, 96f)
                        lineTo(headRect.centerX(), 124f)
                        lineTo(headRect.centerX() + 18f, 98f)
                        lineTo(headRect.right + 16f, 114f)
                        lineTo(headRect.right + 8f, -14f)
                        close()
                    }
                    canvas.drawPath(hairFlow, hairPaint)
                    canvas.drawPath(hairFlow, outline)
                }
            }
        }

        if (isBack || isBack34) {
            // Back & 3/4-Back full hair coverage (3/4 Back leaves slight cheek edge visible on right!)
            val backHairRect = if (isBack34) {
                RectF(headRect.left - 6f, headRect.top - 8f, headRect.right - 12f, headRect.bottom - 2f)
            } else {
                RectF(headRect.left - 5f, headRect.top - 8f, headRect.right + 5f, headRect.bottom - 4f)
            }
            canvas.drawRoundRect(backHairRect, 48f, 48f, hairPaint)
            canvas.drawRoundRect(backHairRect, 48f, 48f, outline)
            val backCenterX = if (isBack34) -12f else 0f
            drawTraditionalBackHair(backCenterX)
            when (c.hairStyle) {
                "SPIKY" -> {
                    val spikes = Path().apply {
                        moveTo(-54f, -14f); lineTo(-66f, -58f); lineTo(-34f, -52f)
                        lineTo(-20f, -86f); lineTo(0f, -62f); lineTo(22f, -84f)
                        lineTo(36f, -52f); lineTo(66f, -58f); lineTo(54f, -14f); close()
                    }
                    canvas.drawPath(spikes, hairPaint); canvas.drawPath(spikes, outline)
                }
                "PONYTAIL" -> {
                    canvas.drawOval(RectF(backCenterX - 22f, -12f, backCenterX + 22f, 66f), hairPaint)
                    canvas.drawOval(RectF(backCenterX - 22f, -12f, backCenterX + 22f, 66f), outline)
                }
                "CURLY" -> {
                    for (i in -2..2) {
                        canvas.drawCircle(i * 22f, -54f + kotlin.math.abs(i) * 6f, 22f, hairPaint)
                        canvas.drawCircle(i * 22f, -54f + kotlin.math.abs(i) * 6f, 22f, outline)
                    }
                }
                "MOHAWK" -> {
                    val mohawk = Path().apply {
                        moveTo(-16f, -52f); lineTo(-22f, -94f); lineTo(0f, -82f); lineTo(22f, -94f); lineTo(16f, -52f); close()
                    }
                    canvas.drawPath(mohawk, hairPaint); canvas.drawPath(mohawk, outline)
                }
            }
        } else {
            // Front, 3/4 Front & Side Profile Hair
            if (c.hairStyle == "BRAID_BENI" || c.hairStyle == "TRADITIONAL_BUN" || c.hairStyle == "LONG_GHOST" || c.hairStyle == "SAGE_JATA") {
                if (c.hairStyle == "LONG_GHOST") {
                    canvas.drawRoundRect(RectF(-56f, -34f, -36f, 92f), 12f, 12f, hairPaint)
                    canvas.drawRoundRect(RectF(36f, -34f, 56f, 92f), 12f, 12f, hairPaint)
                } else if (c.hairStyle == "BRAID_BENI") {
                    // Visible side braid resting over shoulder
                    val bx = if (isSide) -38f else -42f
                    for (seg in 0..3) {
                        canvas.drawOval(RectF(bx - 11f, 22f + seg * 18f, bx + 11f, 40f + seg * 18f), hairPaint)
                        canvas.drawOval(RectF(bx - 11f, 22f + seg * 18f, bx + 11f, 40f + seg * 18f), outline)
                    }
                } else if (c.hairStyle == "TRADITIONAL_BUN") {
                    val bx = if (isSide) -52f else 0f
                    val by = if (isSide) 8f else -68f
                    canvas.drawCircle(bx, by, 20f, hairPaint); canvas.drawCircle(bx, by, 20f, outline)
                } else if (c.hairStyle == "SAGE_JATA") {
                    canvas.drawCircle(0f, -72f, 22f, hairPaint); canvas.drawCircle(0f, -72f, 22f, outline)
                }
                // Classic parted hairline arch
                canvas.drawArc(RectF(-52f, -66f, 52f, 18f), 185f, 170f, true, hairPaint)
                canvas.drawArc(RectF(-52f, -66f, 52f, 18f), 185f, 170f, false, outline)
            } else {
                when (c.hairStyle) {
                    "SPIKY" -> {
                        val spikes = if (isSide) {
                            Path().apply {
                                moveTo(-44f, 14f); lineTo(-58f, -18f); lineTo(-46f, -44f)
                                lineTo(-34f, -74f); lineTo(-8f, -62f); lineTo(18f, -80f)
                                lineTo(38f, -48f); lineTo(48f, -24f)
                                quadTo(4f, -38f, -18f, 16f); close()
                            }
                        } else {
                            Path().apply {
                                moveTo(-52f, -18f); lineTo(-62f, -58f); lineTo(-32f, -50f)
                                lineTo(-20f, -84f); lineTo(0f, -60f); lineTo(22f, -82f)
                                lineTo(34f, -50f); lineTo(62f, -56f); lineTo(52f, -18f)
                                quadTo(0f, -42f, -52f, -18f); close()
                            }
                        }
                        canvas.drawPath(spikes, hairPaint); canvas.drawPath(spikes, outline)
                    }
                    "BOB" -> {
                        if (isSide) {
                            canvas.drawArc(RectF(-50f, -68f, 48f, 40f), 140f, 220f, true, hairPaint)
                            canvas.drawRoundRect(RectF(-50f, -26f, -12f, 46f), 14f, 14f, hairPaint)
                            canvas.drawArc(RectF(-50f, -68f, 48f, 40f), 140f, 220f, false, outline)
                        } else {
                            canvas.drawArc(RectF(-58f, -70f, 58f, 40f), 180f, 180f, true, hairPaint)
                            canvas.drawRoundRect(RectF(-58f, -24f, -40f, 42f), 12f, 12f, hairPaint)
                            canvas.drawRoundRect(RectF(40f, -24f, 58f, 42f), 12f, 12f, hairPaint)
                            canvas.drawArc(RectF(-58f, -70f, 58f, 40f), 180f, 180f, false, outline)
                        }
                    }
                    "PONYTAIL" -> {
                        val ponyRect = if (isSide) RectF(-78f, -44f, -32f, 18f) else RectF(36f, -54f, 82f, 6f)
                        canvas.drawOval(ponyRect, hairPaint); canvas.drawOval(ponyRect, outline)
                        canvas.drawArc(RectF(-52f, -68f, 50f, 20f), 180f, 180f, true, hairPaint)
                        canvas.drawArc(RectF(-52f, -68f, 50f, 20f), 180f, 180f, false, outline)
                    }
                    "CURLY" -> {
                        for (i in -2..2) {
                            canvas.drawCircle(i * (if (isSide) 17f else 22f), -56f + kotlin.math.abs(i) * 6f, 21f, hairPaint)
                            canvas.drawCircle(i * (if (isSide) 17f else 22f), -56f + kotlin.math.abs(i) * 6f, 21f, outline)
                        }
                    }
                    "MOHAWK" -> {
                        val mohawk = Path().apply {
                            moveTo(-16f, -52f); lineTo(-24f, -94f); lineTo(0f, -82f); lineTo(24f, -94f); lineTo(16f, -52f); close()
                        }
                        canvas.drawPath(mohawk, hairPaint); canvas.drawPath(mohawk, outline)
                    }
                }
            }

            // Shift face slightly forward on 3/4 Front angle for authentic depth!
            canvas.save()
            if (isFront34) canvas.translate(10f, 0f)
            drawModularFaceRig(
                canvas = canvas,
                eyePackName = c.eyePack,
                mouthPhonemeName = c.mouthPhoneme,
                eyeColorArgb = c.eyeColorArgb,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                alphaInt = alphaInt,
                tintColorArgb = tintColorArgb,
                isSideProfile = isSide,
                eyebrowStyleName = eyebrowStyleName
            )

            // Module 4: Traditional Bindi / Tilak
            if (c.hasBindi) {
                val bindiP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = (tintColorArgb ?: c.bindiColorArgb).toInt()
                    alpha = alphaInt
                }
                val bx = if (isSide) 34f else 0f
                canvas.drawCircle(bx, -23f, 5.2f, bindiP)
            }

            // Module 4: Traditional Facial Hair (Mustache, Thick Zamindar Mustache, Sage Beard, Royal Beard)
            val mx = if (isSide) 24f else 0f
            when (c.facialHair) {
                "MUSTACHE" -> {
                    val m = Path().apply {
                        moveTo(mx, 10f); quadTo(mx - 16f, 6f, mx - 24f, 16f)
                        quadTo(mx - 10f, 18f, mx, 14f)
                        quadTo(mx + 10f, 18f, mx + 24f, 16f)
                        quadTo(mx + 16f, 6f, mx, 10f); close()
                    }
                    canvas.drawPath(m, hairPaint); canvas.drawPath(m, outline)
                }
                "THICK_MUSTACHE" -> {
                    val m = Path().apply {
                        moveTo(mx, 8f); quadTo(mx - 18f, 2f, mx - 34f, 16f)
                        quadTo(mx - 26f, 24f, mx - 14f, 19f)
                        lineTo(mx, 16f)
                        lineTo(mx + 14f, 19f)
                        quadTo(mx + 26f, 24f, mx + 34f, 16f)
                        quadTo(mx + 18f, 2f, mx, 8f); close()
                    }
                    canvas.drawPath(m, hairPaint); canvas.drawPath(m, outline)
                }
                "SAGE_BEARD", "ROYAL_BEARD" -> {
                    val len = if (c.facialHair == "SAGE_BEARD") 68f else 48f
                    val beard = Path().apply {
                        moveTo(mx - 34f, 14f)
                        quadTo(mx - 30f, len, mx, len + 12f)
                        quadTo(mx + 30f, len, mx + 34f, 14f)
                        quadTo(mx, 28f, mx - 34f, 14f)
                        close()
                    }
                    canvas.drawPath(beard, hairPaint); canvas.drawPath(beard, outline)
                }
            }
            canvas.restore()
        }

        // Accessories (adapt cleanly across all 8 turnaround angles)
        fun pAcc(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL; color = (tintColorArgb ?: argb).toInt(); alpha = alphaInt
        }
        when (c.accessory) {
            "GLASSES" -> if (!isBack && !isBack34) {
                val f = Paint(outline).apply { strokeWidth = 3.8f }
                val gShift = if (isFront34) 10f else 0f
                if (isSide) {
                    canvas.drawRoundRect(RectF(8f, -22f, 34f, 6f), 6f, 6f, f)
                    canvas.drawLine(-8f, -8f, 8f, -8f, f)
                } else {
                    canvas.drawRoundRect(RectF(-34f + gShift, -22f, -4f + gShift, 6f), 6f, 6f, f)
                    canvas.drawRoundRect(RectF(4f + gShift, -22f, 34f + gShift, 6f), 6f, 6f, f)
                    canvas.drawLine(-4f + gShift, -8f, 4f + gShift, -8f, f)
                }
            }
            "HEADPHONES" -> {
                canvas.drawArc(RectF(-56f, -72f, 56f, 22f), 180f, 180f, false, Paint(outline).apply {
                    color = (tintColorArgb ?: 0xFF2DD4BFL).toInt(); strokeWidth = 8f
                })
                if (isSide) {
                    canvas.drawRoundRect(RectF(-20f, -18f, 6f, 20f), 10f, 10f, pAcc(0xFF2DD4BFL))
                } else {
                    canvas.drawRoundRect(RectF(-68f, -22f, -50f, 14f), 8f, 8f, pAcc(0xFF2DD4BFL))
                    canvas.drawRoundRect(RectF(50f, -22f, 68f, 14f), 8f, 8f, pAcc(0xFF2DD4BFL))
                }
            }
            "CROWN", "ROYAL_CROWN" -> {
                val crown = Path().apply {
                    moveTo(-30f, -56f); lineTo(-36f, -92f); lineTo(-14f, -74f)
                    lineTo(0f, -104f); lineTo(14f, -74f); lineTo(36f, -92f); lineTo(30f, -56f); close()
                }
                canvas.drawPath(crown, pAcc(0xFFFBBF24L)); canvas.drawPath(crown, outline)
                canvas.drawCircle(0f, -70f, 5f, pAcc(0xFFEF4444L))
            }
            "HAT" -> {
                canvas.drawRoundRect(RectF(-58f, -58f, 58f, -44f), 6f, 6f, pAcc(0xFF334155L))
                canvas.drawRoundRect(RectF(-36f, -94f, 36f, -54f), 14f, 14f, pAcc(0xFF334155L))
                canvas.drawRoundRect(RectF(-58f, -58f, 58f, -44f), 6f, 6f, outline)
            }
        }
    }

    /**
     * Renders a complete Skeletal Rig Puppet with:
     * 1) 4-View Turnaround support (Front, Left Side, Right Side, Back),
     * 2) Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh) if singleMeshImagePath is set,
     * 3) Segmented Bone-to-Image PNG Part Binding (boundImagePath per bone),
     * 4) Bound Procedural Cartoon Character 14-bone limbs, hands, feet & head with Modular Eyes & Auto Lip-Sync,
     * 5) Built-in Hand Props & Custom PNG attachments bound directly to Left & Right Hands,
     * 6) Color-coded Toontastic/TweenCraft IK Limb Handles + Central Root Move Handle.
     */
    fun drawSkeletalRig(
        canvas: Canvas,
        rig: SkeletalRig,
        puppetRoot: EvaluatedPuppetRoot,
        angles: Map<String, Float>,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        alpha: Float,
        tintColorArgb: Long?,
        showOverlay: Boolean,
        isSelectedPuppet: Boolean,
        selectedBoneId: String?,
        highlightMeshBox: Boolean = false,
        highlightFaceTarget: Boolean = false
    ) {
        val viewAngle = runCatching { CharacterViewAngle.valueOf(puppetRoot.viewAngle) }
            .getOrDefault(CharacterViewAngle.FRONT)
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val isBack = viewAngle == CharacterViewAngle.BACK
        val isAnyBack = isBack || isBack34
        val isSideOr34 = isSide || isFront34 || isBack34
        val effectiveFlipped = isLeftFacingView(viewAngle, puppetRoot.flippedHorizontal)
        val lengthOverrides = InterpolationEngine.evaluateBoneLengths(rig, frame)

        val meshBmp = rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        val hasSingleMesh = meshBmp != null
        val hasBoundParts = rig.bones.any { !it.boundImagePath.isNullOrBlank() && getCachedBitmap(it.boundImagePath) != null }
        val hasCharacterSpec = rig.characterAppearance != null
        val hasAssignedArtwork = hasSingleMesh || hasBoundParts || hasCharacterSpec

        val effRigScaleX = puppetRoot.scaleX * (if (hasSingleMesh) 1f else rig.baseScaleX.coerceIn(0.1f, 5.0f))
        val effRigScaleY = puppetRoot.scaleY * (if (hasSingleMesh) 1f else rig.baseScaleY.coerceIn(0.1f, 5.0f))

        val solved = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = angles,
            rootX = puppetRoot.rootX,
            rootY = puppetRoot.rootY,
            scale = puppetRoot.scale,
            flippedHorizontal = effectiveFlipped,
            lengthOverrides = lengthOverrides,
            scaleX = effRigScaleX,
            scaleY = effRigScaleY,
            frame = frame
        )
        val alphaInt = (alpha * 255).toInt().coerceIn(0, 255)
        val scale = puppetRoot.scale
        val scaleX = effRigScaleX
        val scaleY = effRigScaleY

        val isHorrorMood = puppetRoot.behaviorPreset == CharacterBehaviorPreset.HORROR_GHOSTLY.name
        if (hasAssignedArtwork && tintColorArgb == null && (alpha in 0.12f..0.84f || isHorrorMood)) {
            val auraColor = if (isHorrorMood) 0x66A5F3FC else 0x557DD3FC
            val auraZero = if (isHorrorMood) 0x00A5F3FC else 0x007DD3FC
            val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    puppetRoot.rootX,
                    puppetRoot.rootY - 40f * scale * scaleY,
                    168f * scale,
                    auraColor,
                    auraZero,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY - 40f * scale * scaleY, 168f * scale, auraPaint)
        }

        // A. Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh) with Unrestricted Scale (0.05x–8.0x) & Free X/Y Squash/Stretch
        if (meshBmp != null) {
            val restSolved = RigSolver.solveForwardKinematics(
                rig = rig,
                angleOverrides = emptyMap(),
                rootX = puppetRoot.rootX,
                rootY = puppetRoot.rootY,
                scale = scale,
                flippedHorizontal = effectiveFlipped,
                scaleX = scaleX,
                scaleY = scaleY
            )
            val meshRect = computeSingleMeshRect(rig, puppetRoot)
            val verts = RigSolver.computeDeformedMeshVertices(restSolved, solved, meshRect, 8, 8)
            val meshPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                this.alpha = alphaInt
                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
            }
            canvas.drawBitmapMesh(meshBmp, 8, 8, verts, 0, null, 0, meshPaint)

            if (showOverlay && highlightMeshBox && tintColorArgb == null) {
                val boxP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFFA78BFA.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 3.5f
                    pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
                }
                canvas.drawRect(meshRect, boxP)
                val cornerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA78BFA.toInt(); style = Paint.Style.FILL }
                val cornerStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f }
                listOf(
                    Vec2(meshRect.left, meshRect.top),
                    Vec2(meshRect.right, meshRect.top),
                    Vec2(meshRect.left, meshRect.bottom),
                    Vec2(meshRect.right, meshRect.bottom)
                ).forEach { c ->
                    canvas.drawCircle(c.x, c.y, 13f, cornerFill)
                    canvas.drawCircle(c.x, c.y, 13f, cornerStroke)
                }
                // 4 Edge Mid-Point Squish & Stretch Handles (Left/Right = Cyan Scale X, Top/Bottom = Coral Scale Y)
                val edgeXFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF06B6D4.toInt(); style = Paint.Style.FILL }
                val edgeYFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
                val midX = meshRect.centerX()
                val midY = meshRect.centerY()
                // Left & Right pill handles
                listOf(meshRect.left, meshRect.right).forEach { ex ->
                    val pill = RectF(ex - 9f, midY - 18f, ex + 9f, midY + 18f)
                    canvas.drawRoundRect(pill, 6f, 6f, edgeXFill)
                    canvas.drawRoundRect(pill, 6f, 6f, cornerStroke)
                }
                // Top & Bottom pill handles
                listOf(meshRect.top, meshRect.bottom).forEach { ey ->
                    val pill = RectF(midX - 18f, ey - 9f, midX + 18f, ey + 9f)
                    canvas.drawRoundRect(pill, 6f, 6f, edgeYFill)
                    canvas.drawRoundRect(pill, 6f, 6f, cornerStroke)
                }
            }
        }

        // B. Depth-ordered limbs/torso for ALL 8 Turnaround Angles (including 3/4 Front & 3/4 Back!)
        val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.8f * scale
            strokeCap = Paint.Cap.ROUND
            this.alpha = alphaInt
        }

        val evaluatedZOrders = InterpolationEngine.evaluateBoneZOrders(rig, frame)
        val hasExplicitZOrders = rig.boneZOrderKeyframes.isNotEmpty() || rig.bones.any { it.zOrder != 0 }

        fun fallbackBoneDepthOrder(boneId: String): Int {
            return when {
                isBack34 -> when {
                    boneId.contains("_r") -> 0 // Far arm/leg tucked behind back
                    boneId.startsWith("leg") || boneId.startsWith("foot") -> 1
                    boneId == "spine" -> 2
                    boneId == "neck" -> 3
                    else -> 4 // Near left/shoulder arm in foreground of 3/4 back
                }
                isSide || isFront34 -> when {
                    boneId.contains("_l") -> 0 // Far arm/leg behind torso
                    boneId == "spine" -> 1
                    boneId == "neck" -> 2
                    else -> 3 // Near arm/leg in front of torso
                }
                isBack -> when {
                    boneId.startsWith("leg") || boneId.startsWith("foot") -> 0
                    boneId.startsWith("arm") || boneId.startsWith("hand") -> 1
                    boneId == "spine" -> 2
                    else -> 3
                }
                else -> when {
                    boneId.startsWith("leg") || boneId.startsWith("foot") -> 0
                    boneId == "spine" -> 1
                    boneId == "neck" -> 2
                    else -> 3
                }
            }
        }

        fun resolvedZ(bone: RigBone): Int {
            return if (hasExplicitZOrders) {
                evaluatedZOrders[bone.id] ?: bone.zOrder
            } else {
                fallbackBoneDepthOrder(bone.id) * 10
            }
        }

        // Unified Z-Order render queue (strictly sorted by zOrder ascending: Back -> Front, for both live preview & MP4/PNG export)
        class RigRenderQueueItem(val zOrder: Int, val subOrder: Int, val draw: () -> Unit)
        val renderQueue = ArrayList<RigRenderQueueItem>(solved.size + 6)

        val leftHandBone = solved.firstOrNull { it.bone.id == "hand_l" }
            ?: solved.firstOrNull { it.bone.id == "arm_l_low" }
        val rightHandBone = solved.firstOrNull { it.bone.id == "hand_r" }
            ?: solved.firstOrNull { it.bone.id == "arm_r_low" }
        val headBone = solved.firstOrNull { it.bone.id == "neck" || it.bone.name.contains("Head", ignoreCase = true) }

        if (rig.showSkinMesh) {
            solved.forEachIndexed { idx, sb ->
                val boneZ = resolvedZ(sb.bone)
                val tieOrder = fallbackBoneDepthOrder(sb.bone.id) * 100 + idx
                renderQueue += RigRenderQueueItem(zOrder = boneZ, subOrder = tieOrder) {
                    val partPath = sb.bone.boundImagePath
                    if (!partPath.isNullOrBlank()) {
                        val partBmp = getCachedBitmap(partPath)
                        if (partBmp != null) {
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                                this.alpha = alphaInt
                                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                            }
                            val preset = runCatching { PartBehaviorPreset.valueOf(sb.bone.partBehaviorPreset) }
                                .getOrDefault(PartBehaviorPreset.RIGID)
                            val rawBoneLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y)
                            val baseLen = if (preset == PartBehaviorPreset.RIGID) {
                                (sb.bone.length * scale).coerceAtLeast(16f) // Rigid locks exact scale/rotation with zero distortion
                            } else rawBoneLen
                            val stretchRatio = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
                                (rawBoneLen / (sb.bone.length * scale).coerceAtLeast(1f)).coerceIn(0.4f, 3.0f)
                            } else 1f
                            val squashW = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
                                (1f / kotlin.math.sqrt(stretchRatio)).coerceIn(0.5f, 1.8f)
                            } else 1f
                            val partScaleX = sb.bone.baseScaleX.coerceIn(0.1f, 5.0f)
                            val partScaleY = sb.bone.baseScaleY.coerceIn(0.1f, 5.0f)
                            val drawH = (baseLen * 1.25f * sb.bone.imageScale * sb.bone.limbLengthScale.coerceIn(0.3f, 3.0f) * partScaleY).coerceAtLeast(24f)
                            val aspect = partBmp.width.toFloat() / partBmp.height.coerceAtLeast(1).toFloat()
                            val drawW = ((drawH / partScaleY) * aspect * sb.bone.limbWidthScale.coerceIn(0.3f, 3.0f) * partScaleX * squashW).coerceAtLeast(20f)
                            val rotDeg = Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat()

                            canvas.save()
                            canvas.translate(sb.start.x, sb.start.y)
                            canvas.rotate(rotDeg - 90f + sb.bone.imageRotationOffsetDeg)
                            if (effectiveFlipped) canvas.scale(-1f, 1f)
                            val dst = RectF(
                                -drawW / 2f + sb.bone.pivotOffsetX * scale,
                                -drawH * 0.12f + sb.bone.pivotOffsetY * scale,
                                drawW / 2f + sb.bone.pivotOffsetX * scale,
                                drawH * 0.88f + sb.bone.pivotOffsetY * scale
                            )
                            if (preset == PartBehaviorPreset.SOFT_CLOTH) {
                                // 65% Smooth Cloth Multi-Bone Bend Mesh for Shirts, Sarees & Skirts
                                val cols = 4
                                val rows = 4
                                val meshVerts = FloatArray((cols + 1) * (rows + 1) * 2)
                                val deltaBend = ((sb.worldAngleDeg - sb.bone.localAngleDeg).coerceIn(-65f, 65f) / 65f) * (sb.bone.meshBendSmoothness.coerceIn(0.2f, 1f))
                                val wavePhase = frame * 0.22
                                var vi = 0
                                for (r in 0..rows) {
                                    val vf = r.toFloat() / rows.toFloat()
                                    val bendX = (vf * vf) * drawW * 0.22f * deltaBend + sin(wavePhase + vf * 2.2).toFloat() * (vf * drawW * 0.05f)
                                    val y = dst.top + vf * dst.height()
                                    for (c in 0..cols) {
                                        val uf = c.toFloat() / cols.toFloat()
                                        meshVerts[vi++] = dst.left + uf * dst.width() + bendX
                                        meshVerts[vi++] = y
                                    }
                                }
                                canvas.drawBitmapMesh(partBmp, cols, rows, meshVerts, 0, null, 0, imgPaint)
                            } else {
                                canvas.drawBitmap(partBmp, null, dst, imgPaint)
                            }
                            // Draw Squish/Stretch Bounding Box + 4 Corners + 4 Edge Mid-Point Handles for selected Bone Part PNG!
                            if (showOverlay && highlightMeshBox && tintColorArgb == null && sb.bone.id == selectedBoneId) {
                                val boxP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = 0xFF2DD4BF.toInt()
                                    style = Paint.Style.STROKE
                                    strokeWidth = 3f
                                    pathEffect = DashPathEffect(floatArrayOf(10f, 6f), 0f)
                                }
                                canvas.drawRect(dst, boxP)
                                val cornerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA78BFA.toInt(); style = Paint.Style.FILL }
                                val edgeXFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF06B6D4.toInt(); style = Paint.Style.FILL }
                                val edgeYFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
                                val strokeW = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.5f }
                                listOf(
                                    dst.left to dst.top, dst.right to dst.top,
                                    dst.left to dst.bottom, dst.right to dst.bottom
                                ).forEach { (cx, cy) ->
                                    canvas.drawCircle(cx, cy, 11f, cornerFill)
                                    canvas.drawCircle(cx, cy, 11f, strokeW)
                                }
                                val mx = dst.centerX()
                                val my = dst.centerY()
                                listOf(dst.left, dst.right).forEach { ex ->
                                    val pill = RectF(ex - 7.5f, my - 14f, ex + 7.5f, my + 14f)
                                    canvas.drawRoundRect(pill, 5f, 5f, edgeXFill)
                                    canvas.drawRoundRect(pill, 5f, 5f, strokeW)
                                }
                                listOf(dst.top, dst.bottom).forEach { ey ->
                                    val pill = RectF(mx - 14f, ey - 7.5f, mx + 14f, ey + 7.5f)
                                    canvas.drawRoundRect(pill, 5f, 5f, edgeYFill)
                                    canvas.drawRoundRect(pill, 5f, 5f, strokeW)
                                }
                            }
                            canvas.restore()
                        }
                    } else if (!hasSingleMesh && hasCharacterSpec) {
                        val isHead = sb.bone.id == "neck" || sb.bone.name.contains("Head", ignoreCase = true)
                        if (!isHead) {
                            val charSpec = rig.characterAppearance
                            val isFarSideLimb = (isSide || isFront34) && sb.bone.id.contains("_l") || (isBack34 && sb.bone.id.contains("_r"))
                            val widthScale = sb.bone.limbWidthScale.coerceIn(0.3f, 3.0f)
                            val bodyFactor = if (sb.bone.id == "spine") {
                                (if (isSide) 0.78f else 1f) * charSpec.shoulderWidth.coerceIn(0.7f, 1.5f) * (1f + charSpec.bellyPlumpness.coerceIn(0f, 1f) * 0.45f)
                            } else 1f
                            val effectiveThickness = sb.bone.thickness * bodyFactor * widthScale
                            val baseFillColor = if (isFarSideLimb && tintColorArgb == null) {
                                darkenArgb(sb.bone.colorArgb, 0.82f)
                            } else {
                                (tintColorArgb ?: sb.bone.colorArgb).toInt()
                            }

                            val limbOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = (tintColorArgb ?: 0xFF0F172AL).toInt()
                                strokeWidth = (effectiveThickness + 6f) * scale * ((scaleX + scaleY) * 0.5f)
                                strokeCap = Paint.Cap.ROUND
                                style = Paint.Style.STROKE
                                this.alpha = alphaInt
                            }
                            val limbFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = baseFillColor
                                strokeWidth = effectiveThickness * scale * ((scaleX + scaleY) * 0.5f)
                                strokeCap = Paint.Cap.ROUND
                                style = Paint.Style.STROKE
                                this.alpha = alphaInt
                            }
                            canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbOutline)
                            canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbFill)

                            // Module 4: Body Build (Belly) + Traditional Indian/Bengali Outfit details on Spine!
                            if (sb.bone.id == "spine") {
                                val midX = (sb.start.x + sb.end.x) * 0.5f
                                val midY = (sb.start.y + sb.end.y) * 0.5f
                                val spineLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y)
                                val spineAng = Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat() + 90f
                                canvas.save()
                                canvas.translate(midX, midY)
                                canvas.rotate(spineAng)
                                if (charSpec.bellyPlumpness > 0.1f) {
                                    val bellyR = (18f + charSpec.bellyPlumpness * 22f) * scale
                                    val bellyP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = baseFillColor; this.alpha = alphaInt }
                                    canvas.drawOval(RectF(-bellyR * 1.15f, -bellyR * 0.35f, bellyR * 1.15f, bellyR * 1.15f), bellyP)
                                    canvas.drawOval(RectF(-bellyR * 1.15f, -bellyR * 0.35f, bellyR * 1.15f, bellyR * 1.15f), outlinePaint)
                                }
                                val dupP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: charSpec.dupattaColorArgb).toInt(); this.alpha = alphaInt }
                                val shP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = baseFillColor; this.alpha = alphaInt }
                                val ptP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: charSpec.pantsColorArgb).toInt(); this.alpha = alphaInt }
                                val halfW = (effectiveThickness * 0.55f * scale).coerceAtLeast(18f * scale)
                                val tRect = RectF(-halfW, -spineLen * 0.5f, halfW, spineLen * 0.5f)
                                drawTraditionalTorsoDetails(canvas, charSpec, tRect, shP, ptP, dupP, outlinePaint, isBack = isAnyBack)
                                canvas.restore()
                            }

                            if (isAnyBack && sb.bone.id == "spine" && charSpec.shirtStyle == "HOODIE") {
                                val hoodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    style = Paint.Style.FILL; color = baseFillColor; this.alpha = alphaInt
                                }
                                canvas.drawCircle(sb.end.x, sb.end.y + 8f * scale, 22f * scale, hoodPaint)
                                canvas.drawCircle(sb.end.x, sb.end.y + 8f * scale, 22f * scale, outlinePaint)
                            }

                            // Traditional Bangles on forearms near wrists
                            if (charSpec.hasBangles && (sb.bone.id == "arm_l_low" || sb.bone.id == "arm_r_low")) {
                                val bPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = (tintColorArgb ?: charSpec.banglesColorArgb).toInt()
                                    style = Paint.Style.STROKE
                                    strokeWidth = 5f * scale
                                    this.alpha = alphaInt
                                }
                                val wx = sb.start.x + (sb.end.x - sb.start.x) * 0.82f
                                val wy = sb.start.y + (sb.end.y - sb.start.y) * 0.82f
                                canvas.drawCircle(wx, wy, 9.5f * scale, bPaint)
                            }

                            // Module 4: Expressive Cartoon Hand Gestures on hand_l & hand_r!
                            if (sb.bone.id == "hand_l" || sb.bone.id == "hand_r") {
                                val gestureName = if (sb.bone.id == "hand_l") puppetRoot.leftHandGesture else puppetRoot.rightHandGesture
                                drawExpressiveCartoonHand(
                                    canvas = canvas,
                                    handBone = sb,
                                    gestureName = gestureName,
                                    skinColor = baseFillColor,
                                    outlinePaint = outlinePaint,
                                    scale = scale,
                                    flipped = effectiveFlipped,
                                    alphaInt = alphaInt
                                )
                            }
                        }
                    }

                    // Render attached built-in prop graphic on ANY extra variable rig bone
                    val extraProp = sb.bone.attachedPropKind
                    if (!extraProp.isNullOrBlank() && extraProp != HandPropKind.NONE.name) {
                        drawHandProp(
                            canvas = canvas,
                            handBone = sb,
                            propKindName = extraProp,
                            customImagePath = null,
                            propScale = sb.bone.imageScale * scale,
                            flipped = effectiveFlipped,
                            alphaInt = alphaInt,
                            tintColorArgb = tintColorArgb,
                            frame = frame
                        )
                    }
                }
            }
        }

        // C. Head Sculpt + Modular Pre-Animated Eyes, Eyebrow Acting & Auto Lip-Sync snapped to Head bone Z-Order!
        if (headBone != null) {
            val headZ = resolvedZ(headBone.bone)
            renderQueue += RigRenderQueueItem(zOrder = headZ, subOrder = 950) {
                val headAngle = Math.toDegrees(
                    atan2((headBone.end.y - headBone.start.y).toDouble(), (headBone.end.x - headBone.start.x).toDouble())
                ).toFloat() + 90f
                val headCenterX = (headBone.start.x + headBone.end.x * 2f) / 3f
                val headCenterY = (headBone.start.y + headBone.end.y * 2f) / 3f

                canvas.save()
                canvas.translate(headCenterX, headCenterY)
                canvas.rotate(headAngle)
                canvas.scale(if (effectiveFlipped) -scale * scaleX else scale * scaleX, scale * scaleY)

                val spec = rig.characterAppearance?.copy(
                    eyePack = puppetRoot.eyePack,
                    mouthPhoneme = puppetRoot.mouthPhoneme,
                    viewAngle = viewAngle.name
                )
                if (spec != null && headBone.bone.boundImagePath.isNullOrBlank() && !hasSingleMesh) {
                    val skinP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: spec.skinToneArgb).toInt(); this.alpha = alphaInt }
                    val hairP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: spec.hairColorArgb).toInt(); this.alpha = alphaInt }
                    drawHeadSculpt(
                        canvas, spec, skinP, hairP, outlinePaint, alphaInt, tintColorArgb,
                        frame, fps, audioTracks, viewAngle, puppetRoot.eyebrowStyle
                    )
                } else if (hasAssignedArtwork && rig.showFaceOverlayOnCustomImage && !isAnyBack) {
                    val faceScale = rig.faceOverlayScale.coerceIn(0.2f, 4.0f)
                    canvas.save()
                    canvas.translate(rig.faceOverlayOffsetX, rig.faceOverlayOffsetY)
                    canvas.scale(faceScale, faceScale)
                    drawModularFaceRig(
                        canvas = canvas,
                        eyePackName = puppetRoot.eyePack,
                        mouthPhonemeName = puppetRoot.mouthPhoneme,
                        eyeColorArgb = rig.characterAppearance?.eyeColorArgb ?: 0xFF2DD4BFL,
                        frame = frame,
                        fps = fps,
                        audioTracks = audioTracks,
                        alphaInt = alphaInt,
                        tintColorArgb = tintColorArgb,
                        isSideProfile = isSide,
                        eyebrowStyleName = puppetRoot.eyebrowStyle
                    )
                    if (showOverlay && highlightFaceTarget && tintColorArgb == null) {
                        val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFF06B6D4.toInt()
                            style = Paint.Style.STROKE
                            strokeWidth = 3f / faceScale
                            pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
                        }
                        canvas.drawCircle(0f, 4f, 42f, guideP)
                    }
                    canvas.restore()
                }
                canvas.restore()
            }
        } else if (hasAssignedArtwork && rig.showFaceOverlayOnCustomImage && !isAnyBack) {
            val fallbackFaceZ = (rig.bones.maxOfOrNull { resolvedZ(it) } ?: 8) + 1
            renderQueue += RigRenderQueueItem(zOrder = fallbackFaceZ, subOrder = 950) {
                val faceScale = rig.faceOverlayScale.coerceIn(0.2f, 4.0f)
                canvas.save()
                canvas.translate(puppetRoot.rootX + rig.faceOverlayOffsetX * scale * scaleX, puppetRoot.rootY - 90f * scale * scaleY + rig.faceOverlayOffsetY * scale * scaleY)
                canvas.scale((if (effectiveFlipped) -scale * scaleX else scale * scaleX) * faceScale, scale * scaleY * faceScale)
                drawModularFaceRig(
                    canvas = canvas,
                    eyePackName = puppetRoot.eyePack,
                    mouthPhonemeName = puppetRoot.mouthPhoneme,
                    eyeColorArgb = rig.characterAppearance?.eyeColorArgb ?: 0xFF2DD4BFL,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    alphaInt = alphaInt,
                    tintColorArgb = tintColorArgb,
                    isSideProfile = isSide,
                    eyebrowStyleName = puppetRoot.eyebrowStyle
                )
                if (showOverlay && highlightFaceTarget && tintColorArgb == null) {
                    val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF06B6D4.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 3f / faceScale
                        pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
                    }
                    canvas.drawCircle(0f, 4f, 42f, guideP)
                }
                canvas.restore()
            }
        }

        // C2. Hand-Held Props & Custom PNG Attachments sorted directly on top of their respective hand bones' Z-Order!
        if (leftHandBone != null && (rig.leftHandProp != HandPropKind.NONE.name || !rig.leftHandCustomImagePath.isNullOrBlank())) {
            val leftPropZ = resolvedZ(leftHandBone.bone)
            renderQueue += RigRenderQueueItem(zOrder = leftPropZ, subOrder = 980) {
                drawHandProp(
                    canvas = canvas,
                    handBone = leftHandBone,
                    propKindName = rig.leftHandProp,
                    customImagePath = rig.leftHandCustomImagePath,
                    propScale = rig.handPropScale * scale,
                    flipped = effectiveFlipped,
                    alphaInt = alphaInt,
                    tintColorArgb = tintColorArgb,
                    frame = frame
                )
            }
        }
        if (rightHandBone != null && (rig.rightHandProp != HandPropKind.NONE.name || !rig.rightHandCustomImagePath.isNullOrBlank())) {
            val rightPropZ = resolvedZ(rightHandBone.bone)
            renderQueue += RigRenderQueueItem(zOrder = rightPropZ, subOrder = 990) {
                drawHandProp(
                    canvas = canvas,
                    handBone = rightHandBone,
                    propKindName = rig.rightHandProp,
                    customImagePath = rig.rightHandCustomImagePath,
                    propScale = rig.handPropScale * scale,
                    flipped = effectiveFlipped,
                    alphaInt = alphaInt,
                    tintColorArgb = tintColorArgb,
                    frame = frame
                )
            }
        }

        // Execute strictly sorted Back -> Front draw passes (identical for live preview & MP4/PNG export!)
        renderQueue.sortedWith(compareBy<RigRenderQueueItem>({ it.zOrder }, { it.subOrder })).forEach { it.draw() }

        // D. Skeleton Wireframe & Color-Coded Toontastic/TweenCraft IK Handles with Glowing Touch Halos
        if (showOverlay) {
            val parentIds = rig.bones.mapNotNull { it.parentId }.toSet()
            solved.forEach { sb ->
                val isSelectedBone = sb.bone.id == selectedBoneId && tintColorArgb == null
                val isLeafBone = sb.bone.id !in parentIds
                val isEndEffector = isLeafBone || sb.bone.id.startsWith("hand_") || sb.bone.id.startsWith("foot_") || sb.bone.id == "neck"
                val limbAccent = when {
                    tintColorArgb != null -> tintColorArgb.toInt()
                    isSelectedBone -> 0xFFFF6B35.toInt()
                    sb.bone.id.startsWith("hand_") || sb.bone.id.startsWith("wing_") -> 0xFF06B6D4.toInt()
                    sb.bone.id.startsWith("arm") -> 0xFF2DD4BF.toInt()
                    sb.bone.id.startsWith("foot_") || sb.bone.id.startsWith("tail") -> 0xFFC084FC.toInt()
                    sb.bone.id.startsWith("leg") -> 0xFFA78BFA.toInt()
                    else -> 0xFFFBBF24.toInt()
                }

                val bonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = limbAccent
                    style = Paint.Style.STROKE
                    strokeWidth = if (isSelectedBone) 4.4f else 2.6f
                    this.alpha = if (tintColorArgb != null) (alphaInt * 1.4f).toInt().coerceAtMost(180) else 240
                }
                val dx = sb.end.x - sb.start.x
                val dy = sb.end.y - sb.start.y
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val ux = dx / len; val uy = dy / len
                val px = -uy; val py = ux
                val midX = sb.start.x + dx * 0.22f
                val midY = sb.start.y + dy * 0.22f
                val w = (len * 0.11f).coerceIn(3.5f, 10.5f)

                val bonePath = Path().apply {
                    moveTo(sb.start.x, sb.start.y)
                    lineTo(midX + px * w, midY + py * w)
                    lineTo(sb.end.x, sb.end.y)
                    lineTo(midX - px * w, midY - py * w)
                    close()
                }
                canvas.drawPath(bonePath, bonePaint)

                if (tintColorArgb == null && isSelectedPuppet) {
                    val handleRadius = when {
                        isSelectedBone -> 15.5f
                        isEndEffector -> 13f
                        else -> 9.5f
                    }
                    // Glowing touch halo so users can easily spot and grab IK joints on mobile!
                    val haloRadius = if (isSelectedBone) 28f else if (isEndEffector) 22f else 15f
                    val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                        this.alpha = if (isSelectedBone) 95 else 52
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, haloRadius, haloPaint)

                    val jointFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                    }
                    val ringStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.WHITE
                        style = Paint.Style.STROKE
                        strokeWidth = if (isSelectedBone) 3.4f else if (isEndEffector) 2.8f else 2f
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, handleRadius, jointFill)
                    canvas.drawCircle(sb.end.x, sb.end.y, handleRadius, ringStroke)
                } else {
                    val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                        this.alpha = if (tintColorArgb != null) (alphaInt * 1.5f).toInt().coerceAtMost(190) else 220
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, 5.5f, dot)
                }
            }

            // Central Root / Hip Move Handle (Prominent Glowing 1-Finger Drag Ring)
            if (tintColorArgb == null && isSelectedPuppet) {
                val outerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0x38FF6B35
                    style = Paint.Style.FILL
                }
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0x66FF6B35
                    style = Paint.Style.FILL
                }
                val rootFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFFFF6B35.toInt()
                    style = Paint.Style.FILL
                }
                val rootRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.STROKE
                    strokeWidth = 3.2f
                }
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 34f, outerGlow)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 24f, glow)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 17f, rootFill)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 17f, rootRing)
                canvas.drawLine(puppetRoot.rootX - 8f, puppetRoot.rootY, puppetRoot.rootX + 8f, puppetRoot.rootY, rootRing)
                canvas.drawLine(puppetRoot.rootX, puppetRoot.rootY - 8f, puppetRoot.rootX, puppetRoot.rootY + 8f, rootRing)
            }
        }
    }

    private fun darkenArgb(argb: Long, factor: Float): Int {
        val c = argb.toInt()
        val r = (Color.red(c) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(c) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(c) * factor).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(c), r, g, b)
    }

    /**
     * Module 4: Renders 7 Expressive Cartoon Hand Gestures (Relaxed, Open Palm / Talking,
     * Pointing Finger, Namaste / Folded Hands, Fist, Thumbs Up, Holding Prop) snapped to hand bones!
     */
    private fun drawExpressiveCartoonHand(
        canvas: Canvas,
        handBone: SolvedBone,
        gestureName: String,
        skinColor: Int,
        outlinePaint: Paint,
        scale: Float,
        flipped: Boolean,
        alphaInt: Int
    ) {
        val pose = runCatching { HandGesturePose.valueOf(gestureName) }.getOrDefault(HandGesturePose.RELAXED)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = skinColor
            alpha = alphaInt
        }
        val handOutline = Paint(outlinePaint).apply { strokeWidth = 2.6f * scale }
        val angleDeg = Math.toDegrees(
            atan2((handBone.end.y - handBone.start.y).toDouble(), (handBone.end.x - handBone.start.x).toDouble())
        ).toFloat()

        canvas.save()
        canvas.translate(handBone.end.x, handBone.end.y)
        canvas.rotate(angleDeg)
        canvas.scale(scale, if (flipped) -scale else scale)

        when (pose) {
            HandGesturePose.RELAXED -> {
                canvas.drawOval(RectF(-10f, -9f, 12f, 9f), fill)
                canvas.drawOval(RectF(-10f, -9f, 12f, 9f), handOutline)
            }
            HandGesturePose.OPEN_PALM -> {
                // Expressive splayed cartoon palm + 4 fingers + thumb for storytelling dialogue
                canvas.drawOval(RectF(-9f, -10f, 10f, 10f), fill)
                listOf(-12f to 18f, -5f to 22f, 3f to 21f, 10f to 17f).forEach { (fy, fx) ->
                    canvas.drawRoundRect(RectF(2f, fy - 3f, fx, fy + 3f), 3f, 3f, fill)
                    canvas.drawRoundRect(RectF(2f, fy - 3f, fx, fy + 3f), 3f, 3f, handOutline)
                }
                // Thumb
                canvas.drawRoundRect(RectF(-4f, -18f, 6f, -7f), 3f, 3f, fill)
                canvas.drawRoundRect(RectF(-4f, -18f, 6f, -7f), 3f, 3f, handOutline)
                canvas.drawOval(RectF(-9f, -10f, 10f, 10f), handOutline)
            }
            HandGesturePose.POINTING -> {
                // Curled palm + extended index pointing finger
                canvas.drawCircle(0f, 2f, 10f, fill)
                canvas.drawRoundRect(RectF(4f, -9f, 26f, -2f), 3.5f, 3.5f, fill)
                canvas.drawRoundRect(RectF(4f, -9f, 26f, -2f), 3.5f, 3.5f, handOutline)
                canvas.drawCircle(0f, 2f, 10f, handOutline)
            }
            HandGesturePose.NAMASTE -> {
                // Respectful Indian / Bengali folded upright palm blade
                val palm = Path().apply {
                    moveTo(-8f, -4f); lineTo(18f, -14f); lineTo(24f, -6f); lineTo(12f, 10f); lineTo(-8f, 8f); close()
                }
                canvas.drawPath(palm, fill); canvas.drawPath(palm, handOutline)
                canvas.drawLine(0f, -2f, 18f, -8f, handOutline)
            }
            HandGesturePose.FIST -> {
                canvas.drawRoundRect(RectF(-11f, -11f, 13f, 11f), 6f, 6f, fill)
                canvas.drawRoundRect(RectF(-11f, -11f, 13f, 11f), 6f, 6f, handOutline)
                canvas.drawLine(-4f, -2f, 10f, -2f, handOutline)
                canvas.drawLine(-4f, 4f, 10f, 4f, handOutline)
            }
            HandGesturePose.THUMBS_UP -> {
                canvas.drawRoundRect(RectF(-10f, -6f, 11f, 11f), 5f, 5f, fill)
                canvas.drawRoundRect(RectF(-4f, -24f, 5f, -3f), 4f, 4f, fill)
                canvas.drawRoundRect(RectF(-4f, -24f, 5f, -3f), 4f, 4f, handOutline)
                canvas.drawRoundRect(RectF(-10f, -6f, 11f, 11f), 5f, 5f, handOutline)
            }
            HandGesturePose.HOLDING_PROP -> {
                canvas.drawCircle(0f, 0f, 11.5f, fill)
                canvas.drawCircle(0f, 0f, 11.5f, handOutline)
                canvas.drawArc(RectF(-8f, -8f, 8f, 8f), 20f, 140f, false, handOutline)
            }
        }
        canvas.restore()
    }

    /**
     * Renders any built-in Hand Prop or Custom Imported PNG attached directly to a character's Left or Right Hand bone!
     */
    private fun drawHandProp(
        canvas: Canvas,
        handBone: SolvedBone,
        propKindName: String,
        customImagePath: String?,
        propScale: Float,
        flipped: Boolean,
        alphaInt: Int,
        tintColorArgb: Long?,
        frame: Int
    ) {
        val propKind = runCatching { HandPropKind.valueOf(propKindName) }.getOrDefault(HandPropKind.NONE)
        if (propKind == HandPropKind.NONE && customImagePath.isNullOrBlank()) return

        val boneAngleDeg = Math.toDegrees(
            atan2((handBone.end.y - handBone.start.y).toDouble(), (handBone.end.x - handBone.start.x).toDouble())
        ).toFloat()

        canvas.save()
        canvas.translate(handBone.end.x, handBone.end.y)
        canvas.rotate(boneAngleDeg + 90f)
        canvas.scale(if (flipped) -propScale else propScale, propScale)

        // Custom imported PNG takes priority when attached
        if (!customImagePath.isNullOrBlank()) {
            val bmp = getCachedBitmap(customImagePath)
            if (bmp != null) {
                val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = alphaInt
                    if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                }
                val maxDim = 92f
                val aspect = bmp.width.toFloat() / bmp.height.coerceAtLeast(1).toFloat()
                val drawW = if (aspect >= 1f) maxDim else maxDim * aspect
                val drawH = if (aspect >= 1f) maxDim / aspect else maxDim
                canvas.drawBitmap(bmp, null, RectF(-drawW / 2f, -drawH * 0.85f, drawW / 2f, drawH * 0.15f), imgPaint)
            }
            canvas.restore()
            return
        }

        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (propKind) {
            HandPropKind.SWORD -> {
                val blade = Path().apply {
                    moveTo(-7f, -12f); lineTo(-6f, -94f); lineTo(0f, -112f); lineTo(6f, -94f); lineTo(7f, -12f); close()
                }
                canvas.drawPath(blade, pFill(0xFFE2E8F0L)); canvas.drawPath(blade, outline)
                canvas.drawLine(0f, -14f, 0f, -96f, Paint(outline).apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f })
                canvas.drawRoundRect(RectF(-18f, -16f, 18f, -7f), 4f, 4f, pFill(0xFFFBBF24L))
                canvas.drawRoundRect(RectF(-18f, -16f, 18f, -7f), 4f, 4f, outline)
                canvas.drawRoundRect(RectF(-5f, -7f, 5f, 16f), 4f, 4f, pFill(0xFF78350FL))
                canvas.drawRoundRect(RectF(-5f, -7f, 5f, 16f), 4f, 4f, outline)
            }
            HandPropKind.MIC -> {
                canvas.drawRoundRect(RectF(-5f, -34f, 5f, 14f), 4f, 4f, pFill(0xFF1E293BL))
                canvas.drawRoundRect(RectF(-5f, -34f, 5f, 14f), 4f, 4f, outline)
                canvas.drawCircle(0f, -44f, 14f, pFill(0xFF94A3B8L))
                canvas.drawCircle(0f, -44f, 14f, outline)
                canvas.drawLine(-13f, -44f, 13f, -44f, Paint(outline).apply { strokeWidth = 2.5f })
                canvas.drawCircle(0f, -16f, 3f, pFill(0xFFEF4444L))
            }
            HandPropKind.FLASHLIGHT -> {
                if (tintColorArgb == null) {
                    val beam = Path().apply {
                        moveTo(-10f, -42f); lineTo(10f, -42f); lineTo(58f, -210f); lineTo(-58f, -210f); close()
                    }
                    val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = LinearGradient(0f, -42f, 0f, -210f, 0x88FEF08A.toInt(), 0x00FEF08A, Shader.TileMode.CLAMP)
                    }
                    canvas.drawPath(beam, beamPaint)
                }
                canvas.drawRoundRect(RectF(-7f, -32f, 7f, 16f), 5f, 5f, pFill(0xFF334155L))
                canvas.drawRoundRect(RectF(-7f, -32f, 7f, 16f), 5f, 5f, outline)
                canvas.drawRoundRect(RectF(-12f, -44f, 12f, -30f), 4f, 4f, pFill(0xFFFBBF24L))
                canvas.drawRoundRect(RectF(-12f, -44f, 12f, -30f), 4f, 4f, outline)
            }
            HandPropKind.MAGIC_WAND -> {
                canvas.drawRoundRect(RectF(-4f, -72f, 4f, 14f), 3f, 3f, pFill(0xFF7C3AEDL))
                canvas.drawRoundRect(RectF(-4f, -72f, 4f, 14f), 3f, 3f, outline)
                val pulse = 1f + 0.14f * sin(frame * 0.35).toFloat()
                canvas.save()
                canvas.translate(0f, -78f); canvas.scale(pulse, pulse)
                if (tintColorArgb == null) {
                    canvas.drawCircle(0f, 0f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FDE047 })
                }
                val star = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 16f else 7f
                    val a = (i * PI / 5.0) - PI / 2.0
                    val sx = (cos(a) * r).toFloat(); val sy = (sin(a) * r).toFloat()
                    if (i == 0) star.moveTo(sx, sy) else star.lineTo(sx, sy)
                }
                star.close()
                canvas.drawPath(star, pFill(0xFFFDE047L)); canvas.drawPath(star, outline)
                canvas.restore()
            }
            HandPropKind.PHONE -> {
                canvas.drawRoundRect(RectF(-15f, -46f, 15f, 4f), 6f, 6f, pFill(0xFF0F172AL))
                canvas.drawRoundRect(RectF(-15f, -46f, 15f, 4f), 6f, 6f, outline)
                canvas.drawRoundRect(RectF(-12f, -41f, 12f, -4f), 3f, 3f, pFill(0xFF38BDF8L))
                canvas.drawCircle(0f, -1f, 2f, pFill(0xFF94A3B8L))
            }
            HandPropKind.HORROR_AXE -> {
                canvas.drawRoundRect(RectF(-5f, -88f, 5f, 18f), 4f, 4f, pFill(0xFF57534EL))
                canvas.drawRoundRect(RectF(-5f, -88f, 5f, 18f), 4f, 4f, outline)
                val axeHead = Path().apply {
                    moveTo(2f, -84f); quadTo(36f, -92f, 36f, -54f); quadTo(18f, -52f, 2f, -64f); close()
                }
                canvas.drawPath(axeHead, pFill(0xFFCBD5E1L)); canvas.drawPath(axeHead, outline)
                val edgeTint = Path().apply {
                    moveTo(24f, -86f); quadTo(36f, -72f, 32f, -56f); lineTo(24f, -60f); close()
                }
                canvas.drawPath(edgeTint, pFill(0xFFDC2626L))
            }
            HandPropKind.LANTERN -> {
                if (tintColorArgb == null) {
                    val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = RadialGradient(0f, -26f, 64f, 0x88FB923C.toInt(), 0x00FB923C, Shader.TileMode.CLAMP)
                    }
                    canvas.drawCircle(0f, -26f, 64f, glow)
                }
                canvas.drawArc(RectF(-10f, -56f, 10f, -38f), 180f, 180f, false, outline)
                canvas.drawRoundRect(RectF(-15f, -44f, 15f, -10f), 6f, 6f, pFill(0xFFFEF08AL))
                canvas.drawRoundRect(RectF(-15f, -44f, 15f, -10f), 6f, 6f, outline)
                canvas.drawRect(RectF(-18f, -48f, 18f, -42f), pFill(0xFF1E293BL))
                canvas.drawRect(RectF(-18f, -12f, 18f, -6f), pFill(0xFF1E293BL))
            }
            HandPropKind.COFFEE -> {
                canvas.drawRoundRect(RectF(-13f, -34f, 13f, 2f), 5f, 5f, pFill(0xFFFFFFFFL))
                canvas.drawRoundRect(RectF(-13f, -34f, 13f, 2f), 5f, 5f, outline)
                canvas.drawRect(RectF(-12f, -22f, 12f, -10f), pFill(0xFFB45309L))
                canvas.drawRoundRect(RectF(-15f, -40f, 15f, -32f), 4f, 4f, pFill(0xFF334155L))
                canvas.drawRoundRect(RectF(-15f, -40f, 15f, -32f), 4f, 4f, outline)
            }
            HandPropKind.SIGN -> {
                canvas.drawRoundRect(RectF(-4f, -44f, 4f, 14f), 3f, 3f, pFill(0xFF92400EL))
                canvas.drawRoundRect(RectF(-4f, -44f, 4f, 14f), 3f, 3f, outline)
                canvas.drawRoundRect(RectF(-38f, -86f, 38f, -40f), 10f, 10f, pFill(0xFFEF4444L))
                canvas.drawRoundRect(RectF(-38f, -86f, 38f, -40f), 10f, 10f, outline)
                val subText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = 18f
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    alpha = alphaInt
                }
                canvas.drawText("SUB!", 0f, -57f, subText)
            }
            HandPropKind.NONE -> Unit
        }
        canvas.restore()
    }

    private fun drawMotionPathOverlay(
        canvas: Canvas,
        points: List<Vec2>,
        isSelected: Boolean,
        currentProgress: Float? = null
    ) {
        if (points.size < 2) return
        val smoothPts = InterpolationEngine.buildSmoothSplinePoints(points, subdivisionsPerSegment = 12)
        val path = Path().apply {
            moveTo(smoothPts[0].x, smoothPts[0].y)
            for (i in 1 until smoothPts.size) lineTo(smoothPts[i].x, smoothPts[i].y)
        }

        // Soft glow under path for visibility over dark & bright cartoons
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isSelected) 0x55FF6B35 else 0x44A78BFA
            style = Paint.Style.STROKE
            strokeWidth = 9f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        canvas.drawPath(path, glowPaint)

        val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isSelected) 0xFFFF6B35.toInt() else 0xFFA78BFA.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            strokeCap = Paint.Cap.ROUND
            pathEffect = DashPathEffect(floatArrayOf(14f, 9f), 0f)
        }
        canvas.drawPath(path, pathPaint)

        // Direction chevrons at 25%, 50%, 75% along the smooth curve
        val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFE066.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
            strokeCap = Paint.Cap.ROUND
        }
        listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
            val s = InterpolationEngine.sampleSmoothPath(points, frac)
            canvas.save()
            canvas.translate(s.position.x, s.position.y)
            canvas.rotate(s.tangentAngleDeg)
            canvas.drawLine(-8f, -6f, 4f, 0f, arrowPaint)
            canvas.drawLine(-8f, 6f, 4f, 0f, arrowPaint)
            canvas.restore()
        }

        // Start (emerald) & End (coral) anchor dots + subtle intermediate waypoints
        val waypointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xBBFBBF24.toInt(); style = Paint.Style.FILL }
        val step = (points.size / 14).coerceAtLeast(1)
        for (i in 1 until points.lastIndex step step) {
            canvas.drawCircle(points[i].x, points[i].y, 4.5f, waypointPaint)
        }
        val startPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF34D399.toInt(); style = Paint.Style.FILL }
        val endPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFB7185.toInt(); style = Paint.Style.FILL }
        val whiteStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.5f }
        canvas.drawCircle(points.first().x, points.first().y, 8f, startPaint)
        canvas.drawCircle(points.first().x, points.first().y, 8f, whiteStroke)
        canvas.drawCircle(points.last().x, points.last().y, 8f, endPaint)
        canvas.drawCircle(points.last().x, points.last().y, 8f, whiteStroke)

        // Live playhead marker showing exact position along path at current frame
        if (currentProgress != null) {
            val curSample = InterpolationEngine.sampleSmoothPath(points, currentProgress)
            val markerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x662DD4BF; style = Paint.Style.FILL }
            val markerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt(); style = Paint.Style.FILL }
            canvas.drawCircle(curSample.position.x, curSample.position.y, 15f, markerGlow)
            canvas.drawCircle(curSample.position.x, curSample.position.y, 8f, markerFill)
            canvas.drawCircle(curSample.position.x, curSample.position.y, 8f, whiteStroke)
        }
    }

    private fun drawSceneVfx(
        canvas: Canvas,
        activeVfx: List<String>,
        w: Float,
        h: Float,
        frame: Int
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        activeVfx.forEach { name ->
            when (runCatching { SceneVfxType.valueOf(name) }.getOrNull()) {
                SceneVfxType.FIREFLIES -> {
                    val rng = Random(101)
                    repeat(28) { i ->
                        val bx = rng.nextFloat() * w
                        val by = rng.nextFloat() * h
                        val fx = (bx + sin((frame + i * 7) * 0.08) * 38f).toFloat()
                        val fy = (by + cos((frame + i * 5) * 0.06) * 28f).toFloat()
                        val pulse = (0.45f + 0.55f * sin((frame + i * 11) * 0.16).toFloat()).coerceIn(0.15f, 1f)
                        paint.style = Paint.Style.FILL
                        paint.color = Color.argb((pulse * 80).toInt(), 251, 191, 36)
                        canvas.drawCircle(fx, fy, 16f, paint)
                        paint.color = Color.argb((pulse * 240).toInt(), 254, 240, 138)
                        canvas.drawCircle(fx, fy, 4.5f, paint)
                    }
                }
                SceneVfxType.FLOWER_PETALS -> {
                    val rng = Random(202)
                    repeat(32) { i ->
                        val startX = rng.nextFloat() * w
                        val startY = rng.nextFloat() * h
                        val px = (startX + frame * (2.5f + i % 3) + sin((frame + i * 9) * 0.12) * 24f).toFloat() % (w + 40f) - 20f
                        val py = (startY + frame * (4.2f + (i % 4))) % (h + 40f) - 20f
                        paint.style = Paint.Style.FILL
                        paint.color = if (i % 2 == 0) 0xDDF9A8D4.toInt() else 0xDDFBCFE8.toInt()
                        canvas.save()
                        canvas.translate(px, py)
                        canvas.rotate((frame * 5 + i * 25).toFloat())
                        canvas.drawOval(RectF(-9f, -5f, 9f, 5f), paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.SUNBEAMS -> {
                    paint.style = Paint.Style.FILL
                    val beamAlpha = (36 + 12 * sin(frame * 0.06)).toInt()
                    paint.shader = LinearGradient(0f, 0f, w * 0.7f, h, Color.argb(beamAlpha, 254, 240, 138), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    listOf(0.12f, 0.36f, 0.62f).forEach { startFrac ->
                        val p = Path().apply {
                            moveTo(w * startFrac, 0f)
                            lineTo(w * (startFrac + 0.12f), 0f)
                            lineTo(w * (startFrac + 0.34f), h)
                            lineTo(w * (startFrac + 0.16f), h)
                            close()
                        }
                        canvas.drawPath(p, paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.HIGH_SUNLIGHT -> {
                    val sunX = w * 0.84f
                    val sunY = h * 0.16f
                    val pulse = (1f + 0.06f * sin(frame * 0.08)).toFloat()

                    // Warm atmospheric sunlight wash
                    paint.style = Paint.Style.FILL
                    paint.shader = RadialGradient(
                        sunX, sunY, max(w, h) * 0.95f,
                        intArrayOf(0x99FFFBEB.toInt(), 0x55FDE047, 0x22FB923C, 0x00FDE047),
                        floatArrayOf(0f, 0.22f, 0.55f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null

                    // Rotating volumetric golden god-rays radiating from sun orb
                    val rayCount = 12
                    val rayLen = hypot(w, h) * 1.05f
                    val baseRot = (frame * 0.45f) % 360f
                    paint.shader = RadialGradient(
                        sunX, sunY, rayLen * 0.78f,
                        0x4AFEF08A, 0x00FEF08A, Shader.TileMode.CLAMP
                    )
                    for (i in 0 until rayCount) {
                        val angleDeg = baseRot + i * (360f / rayCount)
                        val a1 = Math.toRadians((angleDeg - 6.5f).toDouble())
                        val a2 = Math.toRadians((angleDeg + 6.5f).toDouble())
                        val rayPath = Path().apply {
                            moveTo(sunX, sunY)
                            lineTo(sunX + cos(a1).toFloat() * rayLen, sunY + sin(a1).toFloat() * rayLen)
                            lineTo(sunX + cos(a2).toFloat() * rayLen, sunY + sin(a2).toFloat() * rayLen)
                            close()
                        }
                        canvas.drawPath(rayPath, paint)
                    }
                    paint.shader = null

                    // Radiant sun corona & crisp bright core
                    paint.shader = RadialGradient(
                        sunX, sunY, 130f * pulse,
                        intArrayOf(0xFFFFFFFF.toInt(), 0xEEFEF08A.toInt(), 0x44FACC15, 0x00FACC15),
                        floatArrayOf(0f, 0.34f, 0.68f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawCircle(sunX, sunY, 130f * pulse, paint)
                    paint.shader = null

                    // Cinematic circular lens-flare bokeh rings along diagonal towards bottom-left
                    val centerX = w * 0.5f
                    val centerY = h * 0.5f
                    val dx = centerX - sunX
                    val dy = centerY - sunY
                    listOf(
                        Triple(0.45f, 34f, 0x38FEF08A),
                        Triple(0.85f, 22f, 0x35FDBA74),
                        Triple(1.22f, 52f, 0x2AFDE047),
                        Triple(1.55f, 18f, 0x40FFFFFF)
                    ).forEach { (frac, r, col) ->
                        val fx = sunX + dx * frac + sin(frame * 0.05 + frac * 4f).toFloat() * 4f
                        val fy = sunY + dy * frac
                        paint.style = Paint.Style.FILL
                        paint.color = col
                        canvas.drawCircle(fx, fy, r * pulse, paint)
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 2f
                        paint.color = 0x44FFFBEB
                        canvas.drawCircle(fx, fy, r * pulse, paint)
                    }
                }
                SceneVfxType.GOLDEN_HOUR -> {
                    paint.style = Paint.Style.FILL
                    paint.shader = LinearGradient(
                        0f, 0f, 0f, h,
                        intArrayOf(0x55FB923C, 0x3AFBBF24, 0x18FDE68A, 0x38EA580C),
                        floatArrayOf(0f, 0.38f, 0.72f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null
                    // Shimmering floating golden bokeh dust motes
                    val rng = Random(808)
                    repeat(30) { i ->
                        val mx = ((rng.nextFloat() * w + frame * (0.8f + i % 3) + sin((frame + i * 9) * 0.07) * 18f).toFloat() % w + w) % w
                        val my = ((rng.nextFloat() * h - frame * (0.5f + (i % 2) * 0.6f)) % h + h) % h
                        val glow = (0.4f + 0.6f * sin((frame + i * 13) * 0.12).toFloat()).coerceIn(0.2f, 1f)
                        paint.color = Color.argb((glow * 95).toInt(), 254, 240, 138)
                        canvas.drawCircle(mx, my, 5f + (i % 6) * 2.5f, paint)
                    }
                }
                SceneVfxType.STORM -> {
                    // 1. Dark storm atmospheric tint
                    paint.style = Paint.Style.FILL
                    paint.shader = LinearGradient(
                        0f, 0f, 0f, h,
                        intArrayOf(0x880F172A.toInt(), 0x441E293B, 0x220F172A),
                        floatArrayOf(0f, 0.45f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null

                    // 2. Rolling dark storm clouds across the top sky
                    val cloudDrift = (frame * 2.8f) % (w + 320f)
                    for (i in 0..6) {
                        val cx = ((i * (w / 5f) + cloudDrift) % (w + 320f)) - 160f
                        val cy = h * (0.06f + (i % 2) * 0.05f)
                        paint.shader = RadialGradient(
                            cx, cy, 175f,
                            0xC81E293B.toInt(), 0x001E293B, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(cx - 210f, cy - 85f, cx + 210f, cy + 75f), paint)
                    }
                    paint.shader = null

                    // 3. Heavy wind-driven slanted storm rain sheets
                    paint.style = Paint.Style.STROKE
                    val rng = Random(909)
                    repeat(110) { i ->
                        val depth = if (i % 3 == 0) 1.35f else 0.85f
                        val rx = ((rng.nextFloat() * w - frame * 18f * depth) % w + w) % w
                        val ry = ((rng.nextFloat() * h + frame * 36f * depth) % h + h) % h
                        paint.strokeWidth = 1.6f * depth
                        paint.color = if (depth > 1f) 0xAABAE6FD.toInt() else 0x6694A3B8
                        canvas.drawLine(rx, ry, rx - 18f * depth, ry + 42f * depth, paint)
                    }

                    // 4. Driving wind mist streaks
                    paint.strokeWidth = 2.4f
                    paint.color = 0x33E2E8F0
                    repeat(10) { i ->
                        val wy = h * (0.18f + (i * 0.08f))
                        val wx = ((w - ((frame * (24f + i * 3) + i * 190f) % (w + 240f))) + 120f)
                        canvas.drawLine(wx, wy, wx - 110f, wy + 18f, paint)
                    }

                    // 5. Ground rain splashes
                    paint.strokeWidth = 1.8f
                    paint.color = 0x88BAE6FD.toInt()
                    repeat(18) { i ->
                        val phase = ((frame + i * 5) % 10) / 10f
                        val sx = ((rng.nextFloat() * w + (frame / 10) * 73f) % w + w) % w
                        val sy = h * (0.86f + (i % 4) * 0.032f)
                        val r = 4f + phase * 16f
                        paint.alpha = ((1f - phase) * 160).toInt().coerceIn(0, 255)
                        canvas.drawOval(RectF(sx - r, sy - r * 0.32f, sx + r, sy + r * 0.32f), paint)
                    }
                    paint.alpha = 255

                    // 6. Periodic thunder & branching lightning bolts
                    val cycle = frame % 44
                    if (cycle == 10 || cycle == 12 || cycle == 33) {
                        paint.style = Paint.Style.FILL
                        paint.color = if (cycle == 10) 0x77E0F2FE else 0x44FFFFFF
                        canvas.drawRect(0f, 0f, w, h, paint)

                        val boltX = if (cycle == 33) w * 0.28f else w * 0.68f
                        val mainBolt = Path().apply {
                            moveTo(boltX, 0f)
                            lineTo(boltX - 32f, h * 0.19f)
                            lineTo(boltX + 20f, h * 0.24f)
                            lineTo(boltX - 42f, h * 0.52f)
                            lineTo(boltX + 14f, h * 0.56f)
                            lineTo(boltX - 24f, h * 0.84f)
                        }
                        val branchBolt = Path().apply {
                            moveTo(boltX + 20f, h * 0.24f)
                            lineTo(boltX + 68f, h * 0.42f)
                            lineTo(boltX + 46f, h * 0.55f)
                        }
                        paint.style = Paint.Style.STROKE
                        paint.strokeCap = Paint.Cap.ROUND
                        paint.strokeWidth = 11f
                        paint.color = 0x8838BDF8.toInt()
                        canvas.drawPath(mainBolt, paint)
                        paint.strokeWidth = 6f
                        canvas.drawPath(branchBolt, paint)
                        paint.strokeWidth = 4f
                        paint.color = Color.WHITE
                        canvas.drawPath(mainBolt, paint)
                        paint.strokeWidth = 2.5f
                        canvas.drawPath(branchBolt, paint)
                    }
                }
                SceneVfxType.RAIN -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.2f
                    paint.color = 0x99BAE6FD.toInt()
                    val rng = Random(303)
                    repeat(62) { i ->
                        val rx = ((rng.nextFloat() * w - frame * 6.5f) % w + w) % w
                        val ry = ((rng.nextFloat() * h + frame * 26f) % h + h) % h
                        canvas.drawLine(rx, ry, rx - 8f, ry + 30f, paint)
                    }
                    // Subtle ground splash ripples
                    paint.strokeWidth = 1.5f
                    repeat(10) { i ->
                        val phase = ((frame + i * 6) % 12) / 12f
                        val sx = ((rng.nextFloat() * w) % w + w) % w
                        val sy = h * (0.88f + (i % 3) * 0.03f)
                        val r = 3f + phase * 12f
                        paint.color = Color.argb(((1f - phase) * 140).toInt().coerceIn(0, 255), 186, 230, 253)
                        canvas.drawOval(RectF(sx - r, sy - r * 0.3f, sx + r, sy + r * 0.3f), paint)
                    }
                }
                SceneVfxType.HEAVY_RAIN -> {
                    // Cool misty rain atmosphere
                    paint.style = Paint.Style.FILL
                    paint.color = 0x260C4A6E
                    canvas.drawRect(0f, 0f, w, h, paint)

                    paint.style = Paint.Style.STROKE
                    val rng = Random(1101)
                    repeat(130) { i ->
                        val near = i % 3 == 0
                        val spd = if (near) 38f else 24f
                        val rx = ((rng.nextFloat() * w - frame * (if (near) 12f else 7f)) % w + w) % w
                        val ry = ((rng.nextFloat() * h + frame * spd) % h + h) % h
                        paint.strokeWidth = if (near) 2.8f else 1.5f
                        paint.color = if (near) 0xBBE0F2FE.toInt() else 0x777DD3FC
                        canvas.drawLine(rx, ry, rx - (if (near) 13f else 8f), ry + (if (near) 44f else 26f), paint)
                    }
                    // Animated puddle splash rings along lower ground
                    repeat(22) { i ->
                        val phase = ((frame + i * 4) % 9) / 9f
                        val sx = ((rng.nextFloat() * w + (frame / 9) * 51f) % w + w) % w
                        val sy = h * (0.84f + (i % 5) * 0.03f)
                        val r = 4f + phase * 18f
                        paint.strokeWidth = 2f
                        paint.color = Color.argb(((1f - phase) * 195).toInt().coerceIn(0, 255), 224, 242, 254)
                        canvas.drawOval(RectF(sx - r, sy - r * 0.3f, sx + r, sy + r * 0.3f), paint)
                    }
                }
                SceneVfxType.SNOW -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xDDFFFFFF.toInt()
                    val rng = Random(404)
                    repeat(54) { i ->
                        val sx = ((rng.nextFloat() * w + sin((frame + i * 5) * 0.07) * 30f).toFloat() % w + w) % w
                        val sy = (rng.nextFloat() * h + frame * (2.5f + i % 3)) % h
                        canvas.drawCircle(sx, sy, 2.5f + (i % 4), paint)
                    }
                }
                SceneVfxType.RAINBOW -> {
                    val shimmer = (0.78f + 0.22f * sin(frame * 0.08)).toFloat()
                    val rainbowBandColors = intArrayOf(
                        0xFFEF4444.toInt(),
                        0xFFF97316.toInt(),
                        0xFFFACC15.toInt(),
                        0xFF22C55E.toInt(),
                        0xFF38BDF8.toInt(),
                        0xFF6366F1.toInt(),
                        0xFFA855F7.toInt()
                    )
                    paint.style = Paint.Style.STROKE
                    val bandW = min(w, h) * 0.028f
                    val baseR = min(w, h) * 0.72f
                    val cx = w * 0.5f
                    val cy = h * 0.88f
                    rainbowBandColors.forEachIndexed { idx, col ->
                        val r = baseR - idx * bandW
                        paint.strokeWidth = bandW + 1.5f
                        paint.color = col
                        paint.alpha = (88 * shimmer).toInt().coerceIn(30, 140)
                        canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 185f, 170f, false, paint)
                    }
                    paint.alpha = 255
                }
                SceneVfxType.AURORA -> {
                    paint.style = Paint.Style.FILL
                    val bands = listOf(
                        Triple(0x5534D399, 0.14f, 0.05f),
                        Triple(0x4A22D3EE, 0.22f, 0.07f),
                        Triple(0x45A855F7, 0.19f, 0.04f)
                    )
                    bands.forEachIndexed { bIdx, (col, yFrac, speed) ->
                        val path = Path()
                        val baseY = h * yFrac
                        val ribbonH = h * 0.24f
                        path.moveTo(0f, baseY)
                        val steps = 16
                        for (s in 0..steps) {
                            val x = w * (s.toFloat() / steps)
                            val wave = sin(s * 0.65 + frame * speed + bIdx * 1.9).toFloat() * (h * 0.06f)
                            path.lineTo(x, baseY + wave)
                        }
                        for (s in steps downTo 0) {
                            val x = w * (s.toFloat() / steps)
                            val wave = sin(s * 0.65 + frame * speed + bIdx * 1.9 + 0.6).toFloat() * (h * 0.05f)
                            path.lineTo(x, baseY + ribbonH + wave)
                        }
                        path.close()
                        paint.shader = LinearGradient(
                            0f, baseY - 20f, 0f, baseY + ribbonH + 20f,
                            intArrayOf(0x00000000, col, 0x00000000),
                            floatArrayOf(0f, 0.45f, 1f),
                            Shader.TileMode.CLAMP
                        )
                        canvas.drawPath(path, paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.AUTUMN_LEAVES -> {
                    // Swirling translucent breeze ribbons
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.5f
                    paint.color = 0x44F8FAFC
                    repeat(5) { i ->
                        val gy = h * (0.20f + i * 0.15f)
                        val gx = ((frame * (12f + i * 2) + i * 230f) % (w + 260f)) - 130f
                        val gust = Path().apply {
                            moveTo(gx - 90f, gy)
                            quadTo(gx - 20f, gy - 26f, gx + 60f, gy + 6f)
                            quadTo(gx + 100f, gy + 20f, gx + 125f, gy - 12f)
                        }
                        canvas.drawPath(gust, paint)
                    }
                    // Tumbling autumn leaves
                    val leafColors = intArrayOf(
                        0xEEF97316.toInt(),
                        0xEEF59E0B.toInt(),
                        0xEEDC2626.toInt(),
                        0xEEEAB308.toInt()
                    )
                    paint.style = Paint.Style.FILL
                    val rng = Random(1202)
                    repeat(34) { i ->
                        val lx = ((rng.nextFloat() * w + frame * (5.5f + i % 4)) % (w + 50f)) - 25f
                        val ly = ((rng.nextFloat() * h + frame * (2.6f + i % 3) + sin((frame + i * 7) * 0.14) * 26f).toFloat() % (h + 50f)) - 25f
                        paint.color = leafColors[i % leafColors.size]
                        canvas.save()
                        canvas.translate(lx, ly)
                        canvas.rotate((frame * (6f + i % 4) + i * 33f) % 360f)
                        val leaf = Path().apply {
                            moveTo(-11f, 0f)
                            quadTo(0f, -9f, 12f, 0f)
                            quadTo(0f, 9f, -11f, 0f)
                            close()
                        }
                        canvas.drawPath(leaf, paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.STARLIGHT -> {
                    val rng = Random(1303)
                    paint.style = Paint.Style.FILL
                    repeat(42) { i ->
                        val sx = rng.nextFloat() * w
                        val sy = rng.nextFloat() * h * 0.78f
                        val twinkle = (0.3f + 0.7f * sin((frame + i * 9) * 0.22).toFloat()).coerceIn(0.15f, 1f)
                        val r = (3.5f + (i % 4) * 2.2f) * twinkle
                        paint.color = Color.argb((twinkle * 245).toInt(), 255, 251, 235)
                        // 4-point cartoon sparkle star
                        val star = Path().apply {
                            moveTo(sx, sy - r * 1.6f)
                            lineTo(sx + r * 0.42f, sy - r * 0.42f)
                            lineTo(sx + r * 1.6f, sy)
                            lineTo(sx + r * 0.42f, sy + r * 0.42f)
                            lineTo(sx, sy + r * 1.6f)
                            lineTo(sx - r * 0.42f, sy + r * 0.42f)
                            lineTo(sx - r * 1.6f, sy)
                            lineTo(sx - r * 0.42f, sy - r * 0.42f)
                            close()
                        }
                        canvas.drawPath(star, paint)
                    }
                    // Shooting star every 36 frames
                    val shootFrame = frame % 36
                    if (shootFrame in 4..16) {
                        val t = (shootFrame - 4) / 12f
                        val headX = w * (0.18f + t * 0.62f)
                        val headY = h * (0.10f + t * 0.28f)
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 3.5f
                        paint.strokeCap = Paint.Cap.ROUND
                        paint.shader = LinearGradient(
                            headX, headY, headX - 110f, headY - 48f,
                            0xFFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP
                        )
                        canvas.drawLine(headX, headY, headX - 110f, headY - 48f, paint)
                        paint.shader = null
                    }
                }
                SceneVfxType.FIRE_EMBERS -> {
                    // Subtle warm furnace glow along bottom
                    paint.style = Paint.Style.FILL
                    paint.shader = LinearGradient(
                        0f, h, 0f, h * 0.62f,
                        0x55EA580C, 0x00EA580C, Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, h * 0.62f, w, h, paint)
                    paint.shader = null

                    val rng = Random(1404)
                    repeat(45) { i ->
                        val ex = ((rng.nextFloat() * w + sin((frame + i * 6) * 0.11) * 32f).toFloat() % w + w) % w
                        val ey = ((rng.nextFloat() * h - frame * (4.2f + i % 4)) % h + h) % h
                        val life = (ey / h).coerceIn(0.1f, 1f)
                        val r = 2.2f + (i % 4) * 1.2f
                        paint.color = Color.argb((life * 110).toInt(), 249, 115, 22)
                        canvas.drawCircle(ex, ey, r * 3.1f, paint)
                        paint.color = Color.argb((life * 245).toInt(), 254, 240, 138)
                        canvas.drawCircle(ex, ey, r, paint)
                    }
                }
                SceneVfxType.SPOOKY_FOG -> {
                    paint.style = Paint.Style.FILL
                    val drift1 = (frame * 2.4f) % (w + 380f)
                    val drift2 = (frame * 1.3f) % (w + 420f)
                    for (i in 0..5) {
                        val fx = ((i * (w / 4f) + drift1) % (w + 360f)) - 180f
                        val fy = h * (0.76f + (i % 2) * 0.08f)
                        paint.shader = RadialGradient(
                            fx, fy, 190f,
                            0x48CBD5E1, 0x00CBD5E1, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(fx - 220f, fy - 75f, fx + 220f, fy + 75f), paint)
                    }
                    for (i in 0..3) {
                        val fx = w - (((i * (w / 3f) + drift2) % (w + 360f)) - 180f)
                        val fy = h * 0.88f
                        paint.shader = RadialGradient(
                            fx, fy, 220f,
                            0x55E2E8F0, 0x00E2E8F0, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(fx - 260f, fy - 90f, fx + 260f, fy + 90f), paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.LIGHTNING_FLASH -> {
                    val cycle = frame % 48
                    if (cycle == 14 || cycle == 16 || cycle == 39) {
                        paint.style = Paint.Style.FILL
                        paint.color = if (cycle == 14) 0x88E0F2FE.toInt() else 0x55FFFFFF.toInt()
                        canvas.drawRect(0f, 0f, w, h, paint)

                        val boltX = if (cycle == 39) w * 0.25f else w * 0.72f
                        val boltPath = Path().apply {
                            moveTo(boltX, 0f)
                            lineTo(boltX - 28f, h * 0.22f)
                            lineTo(boltX + 18f, h * 0.26f)
                            lineTo(boltX - 36f, h * 0.56f)
                            lineTo(boltX + 12f, h * 0.58f)
                            lineTo(boltX - 18f, h * 0.82f)
                        }
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 10f
                        paint.color = 0x9938BDF8.toInt()
                        canvas.drawPath(boltPath, paint)
                        paint.strokeWidth = 4f
                        paint.color = Color.WHITE
                        canvas.drawPath(boltPath, paint)
                    }
                }
                SceneVfxType.VIGNETTE_HORROR -> {
                    paint.style = Paint.Style.FILL
                    val r = hypot(w, h) * 0.62f
                    paint.shader = RadialGradient(
                        w / 2f, h / 2f, r,
                        intArrayOf(0x00000000, 0x22000000, 0xCC020617.toInt()),
                        floatArrayOf(0.38f, 0.72f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null
                }
                SceneVfxType.CONFETTI_POP -> {
                    paint.style = Paint.Style.FILL
                    val colors = intArrayOf(
                        0xFFFF6B35.toInt(), 0xFF2DD4BF.toInt(), 0xFFFBBF24.toInt(),
                        0xFFA78BFA.toInt(), 0xFFFB7185.toInt(), 0xFF34D399.toInt()
                    )
                    val rng = Random(707)
                    repeat(46) { i ->
                        val cx = (rng.nextFloat() * w + sin((frame + i * 7) * 0.1) * 28f).toFloat()
                        val cy = (rng.nextFloat() * h + frame * (4.5f + i % 4)) % h
                        paint.color = colors[i % colors.size]
                        canvas.save()
                        canvas.translate(cx, cy)
                        canvas.rotate((frame * (7f + i % 5) + i * 25f) % 360f)
                        canvas.drawRect(-7f, -4f, 7f, 4f, paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.CINEMA_BARS -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xFF000000.toInt()
                    val barH = h * 0.105f
                    canvas.drawRect(0f, 0f, w, barH, paint)
                    canvas.drawRect(0f, h - barH, w, h, paint)
                }
                SceneVfxType.SPEED_LINES -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 3f
                    paint.color = 0xAAFFFFFF.toInt()
                    val cx = w / 2f; val cy = h / 2f
                    val outerR = hypot(cx, cy) * 1.15f
                    val rng = Random(505 + frame / 2)
                    repeat(36) {
                        val a = rng.nextFloat() * 2f * PI.toFloat()
                        val innerR = outerR * (0.48f + rng.nextFloat() * 0.22f)
                        canvas.drawLine(
                            cx + cos(a) * innerR, cy + sin(a) * innerR,
                            cx + cos(a) * outerR, cy + sin(a) * outerR,
                            paint
                        )
                    }
                }
                null -> Unit
            }
        }
    }

    private fun drawColorGradeOverlay(
        canvas: Canvas,
        gradeName: String,
        w: Float,
        h: Float,
        frame: Int
    ) {
        val grade = runCatching { SceneColorGrade.valueOf(gradeName) }.getOrDefault(SceneColorGrade.NONE)
        if (grade == SceneColorGrade.NONE) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (grade) {
            SceneColorGrade.HORROR_COLD -> {
                paint.color = 0x380B253A
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0x3304141D, 0x44020617, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.NIGHT_BLUE -> {
                paint.color = 0x480F172A
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.WARM_SUNSET -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0x30FB923C, 0x26F43F5E, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.VINTAGE_VHS -> {
                paint.color = 0x2278350F
                canvas.drawRect(0f, 0f, w, h, paint)
                val linePaint = Paint().apply { color = 0x22000000; strokeWidth = 2f }
                var y = 0f
                while (y < h) {
                    canvas.drawLine(0f, y, w, y, linePaint)
                    y += 6f
                }
                // Rolling VHS tracking bar + REC timestamp
                val trackY = (frame * 11f) % h
                paint.color = 0x1EFFFFFF
                canvas.drawRect(0f, trackY, w, trackY + 18f, paint)
                val recPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xDDFF3B30.toInt()
                    textSize = (h * 0.036f).coerceIn(18f, 34f)
                    typeface = Typeface.MONOSPACE
                }
                if ((frame / 12) % 2 == 0) {
                    canvas.drawCircle(38f, 40f, 9f, recPaint)
                }
                recPaint.color = 0xEEFFFFFF.toInt()
                canvas.drawText("PLAY  VHS", 56f, 48f, recPaint)
            }
            SceneColorGrade.NOIR_BW -> {
                paint.color = 0x660B0F17
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w, h) * 0.58f,
                    0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.NONE -> Unit
        }
    }

    private fun drawSubtitles(
        canvas: Canvas,
        subtitles: List<SubtitleCue>,
        frame: Int,
        w: Float,
        h: Float
    ) {
        val active = subtitles.lastOrNull { frame in it.startFrame..it.endFrame } ?: return
        val subStyle = runCatching { SubtitleStyle.valueOf(active.style) }.getOrDefault(SubtitleStyle.YOUTUBE_BOLD)
        val ageFrames = (frame - active.startFrame).coerceAtLeast(0)
        // Snappy YouTube pop-in bounce over the first 4 frames
        val popScale = when (ageFrames) {
            0 -> 0.82f
            1 -> 1.08f
            2 -> 0.98f
            else -> 1f
        }
        val baseTextSize = (min(w, h) * 0.064f).coerceIn(26f, 64f)
        val displayLine = if (active.speakerName.isNotBlank()) "${active.speakerName}: ${active.text}" else active.text
        val centerX = w / 2f
        val baseY = h * 0.88f

        canvas.save()
        canvas.translate(centerX, baseY)
        canvas.scale(popScale, popScale)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = baseTextSize
            typeface = when (subStyle) {
                SubtitleStyle.YOUTUBE_BOLD, SubtitleStyle.COMIC_BOX -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                SubtitleStyle.HORROR_DRIP -> Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
                SubtitleStyle.CINEMATIC -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
        }
        val textW = textPaint.measureText(displayLine)

        when (subStyle) {
            SubtitleStyle.COMIC_BOX -> {
                val padX = 24f; val padY = 14f
                val boxRect = RectF(-textW / 2f - padX, -baseTextSize - padY * 0.4f, textW / 2f + padX, padY)
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE0F172A.toInt() }
                val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = active.colorArgb.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                }
                canvas.drawRoundRect(boxRect, 14f, 14f, bg)
                canvas.drawRoundRect(boxRect, 14f, 14f, border)
            }
            SubtitleStyle.CINEMATIC -> {
                val padX = 22f; val padY = 10f
                val boxRect = RectF(-textW / 2f - padX, -baseTextSize - padY * 0.3f, textW / 2f + padX, padY)
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA000000.toInt() }
                canvas.drawRoundRect(boxRect, 8f, 8f, bg)
            }
            else -> Unit
        }

        // Crisp dark outline + shadow
        val strokePaint = Paint(textPaint).apply {
            color = 0xFF000000.toInt()
            style = Paint.Style.STROKE
            strokeWidth = if (subStyle == SubtitleStyle.YOUTUBE_BOLD || subStyle == SubtitleStyle.HORROR_DRIP) 10f else 5f
            strokeJoin = Paint.Join.ROUND
        }
        canvas.drawText(displayLine, 0f, 0f, strokePaint)

        textPaint.style = Paint.Style.FILL
        textPaint.color = if (subStyle == SubtitleStyle.HORROR_DRIP) 0xFFFF3B5C.toInt() else active.colorArgb.toInt()
        canvas.drawText(displayLine, 0f, 0f, textPaint)
        canvas.restore()
    }

    private fun drawBackgroundTemplate(
        canvas: Canvas,
        templateName: String,
        bgColorArgb: Long,
        w: Float,
        h: Float,
        panX: Float,
        panY: Float,
        frame: Int
    ) {
        val template = runCatching { BackgroundTemplate.valueOf(templateName) }.getOrDefault(BackgroundTemplate.SOLID)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (template) {
            BackgroundTemplate.SOLID -> {
                paint.color = bgColorArgb.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            BackgroundTemplate.PASTEL_SKY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF93C5FD.toInt(), 0xFFFBCFE8.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Soft pastel drifting clouds
                paint.color = 0xEEFFFFFF.toInt()
                val drift = (frame * 0.8f) % (w + 260f)
                listOf(0.18f to 0.22f, 0.56f to 0.16f, 0.84f to 0.28f).forEach { (xf, yf) ->
                    val cx = (w * xf + drift) % (w + 180f) - 90f - panX * 0.25f
                    val cy = h * yf - panY * 0.2f
                    canvas.drawCircle(cx - 38f, cy, 32f, paint)
                    canvas.drawCircle(cx, cy - 14f, 44f, paint)
                    canvas.drawCircle(cx + 40f, cy, 34f, paint)
                }
                paint.color = 0xFF86EFAC.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.68f, w * 0.8f - panX * 0.5f, h * 1.35f), paint)
                paint.color = 0xFF4ADE80.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.72f, w * 1.3f - panX * 0.7f, h * 1.4f), paint)
            }
            BackgroundTemplate.CHERRY_BLOSSOM -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(w * 0.08f - panX * 0.4f, h * 0.35f, w * 0.13f - panX * 0.4f, h * 0.85f, paint)
                paint.color = 0xFFF472B6.toInt()
                canvas.drawCircle(w * 0.12f - panX * 0.4f, h * 0.28f, 125f, paint)
                paint.color = 0xFFFBCFE8.toInt()
                canvas.drawCircle(w * 0.22f - panX * 0.4f, h * 0.32f, 95f, paint)
                paint.color = 0xFF6EE7B7.toInt()
                canvas.drawRect(0f, h * 0.76f, w, h, paint)
            }
            BackgroundTemplate.TWILIGHT_DREAM -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF312E81.toInt(), 0xFFEC4899.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFEF08A.toInt()
                canvas.drawCircle(w * 0.76f - panX * 0.2f, h * 0.24f, 54f, paint)
                paint.color = 0xFF1E1B4B.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.6f, h * 0.66f, w * 1.15f - panX * 0.6f, h * 1.38f), paint)
            }
            BackgroundTemplate.HAUNTED_FOREST -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF040914.toInt(), 0xFF132238.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Eerie glowing full moon
                val moonX = w * 0.74f - (panX * 0.12f) % (w * 0.5f)
                paint.shader = RadialGradient(moonX, h * 0.22f, 150f, 0x55BAE6FD, 0x00BAE6FD, Shader.TileMode.CLAMP)
                canvas.drawCircle(moonX, h * 0.22f, 150f, paint)
                paint.shader = null
                paint.color = 0xFFE2E8F0.toInt()
                canvas.drawCircle(moonX, h * 0.22f, 58f, paint)
                // Seamlessly wrapping silhouettes of twisted dead trees
                val span = w + 320f
                paint.color = 0xFF070D19.toInt()
                for (i in 0..8) {
                    val tx = (((i * (span / 8f) - panX * 0.65f) % span) + span) % span - 160f
                    val treeH = h * (0.48f + (i % 3) * 0.12f)
                    val trunkW = 24f + (i % 3) * 8f
                    canvas.drawRect(tx - trunkW / 2f, h - treeH, tx + trunkW / 2f, h * 0.84f, paint)
                    // Spooky crooked branches
                    val branchP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF070D19.toInt()
                        strokeWidth = 9f
                        strokeCap = Paint.Cap.ROUND
                    }
                    canvas.drawLine(tx, h - treeH * 0.72f, tx - 56f, h - treeH * 0.88f, branchP)
                    canvas.drawLine(tx, h - treeH * 0.60f, tx + 62f, h - treeH * 0.78f, branchP)
                }
                // Dark misty ground
                paint.color = 0xFF020617.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
            }
            BackgroundTemplate.SPOOKY_MANSION -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF1A1025.toInt(), 0xFF0B0712.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Repeating haunted hallway pillars & gothic arched windows
                val span = w + 320f
                for (i in 0..4) {
                    val wx = (((i * (span / 4f) - panX * 0.6f) % span) + span) % span - 140f
                    // Gothic moonlight window
                    paint.color = 0xFF1E293B.toInt()
                    canvas.drawRoundRect(RectF(wx - 44f, h * 0.16f, wx + 44f, h * 0.54f), 44f, 44f, paint)
                    paint.color = 0xFF334155.toInt()
                    canvas.drawRect(wx - 3f, h * 0.16f, wx + 3f, h * 0.54f, paint)
                    canvas.drawRect(wx - 44f, h * 0.36f, wx + 44f, h * 0.38f, paint)
                    // Flickering wall torch glow
                    val flicker = 0.85f + 0.15f * sin((frame + i * 7) * 0.6).toFloat()
                    paint.shader = RadialGradient(
                        wx + 110f, h * 0.42f, 90f * flicker,
                        0x66F59E0B, 0x00F59E0B, Shader.TileMode.CLAMP
                    )
                    canvas.drawCircle(wx + 110f, h * 0.42f, 90f * flicker, paint)
                    paint.shader = null
                }
                paint.color = 0xFF1C1329.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0xFF3B0764.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h * 0.77f, paint)
            }
            BackgroundTemplate.COMIC_BURST -> {
                paint.shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w, h) * 0.6f,
                    0xFFFEF08A.toInt(), 0xFFFF6B35.toInt(), Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val cx = w / 2f; val cy = h / 2f
                val r = hypot(w, h)
                val rotOffset = frame * 0.8f
                paint.color = 0x33FFFFFF
                for (i in 0 until 16) {
                    val a1 = Math.toRadians((i * 22.5 + rotOffset))
                    val a2 = Math.toRadians((i * 22.5 + 10.0 + rotOffset))
                    val tri = Path().apply {
                        moveTo(cx, cy)
                        lineTo(cx + (cos(a1) * r).toFloat(), cy + (sin(a1) * r).toFloat())
                        lineTo(cx + (cos(a2) * r).toFloat(), cy + (sin(a2) * r).toFloat())
                        close()
                    }
                    canvas.drawPath(tri, paint)
                }
            }
            BackgroundTemplate.CLASSROOM_STAGE -> {
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                // Classic green chalkboard
                val bx = w * 0.14f - panX * 0.35f
                paint.color = 0xFF78350F.toInt()
                canvas.drawRoundRect(RectF(bx - 12f, h * 0.14f - 12f, bx + w * 0.72f + 12f, h * 0.58f + 12f), 14f, 14f, paint)
                paint.color = 0xFF14532D.toInt()
                canvas.drawRect(bx, h * 0.14f, bx + w * 0.72f, h * 0.58f, paint)
                // Wooden floor
                paint.color = 0xFFB45309.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0xFF92400E.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h * 0.76f, paint)
            }
            BackgroundTemplate.GRID_PAPER -> {
                paint.color = 0xFFF8FAFC.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                val gridPaint = Paint().apply { color = 0xFFCBD5E1.toInt(); strokeWidth = 1.5f }
                var x = 0f; while (x <= w) { canvas.drawLine(x, 0f, x, h, gridPaint); x += 64f }
                var y = 0f; while (y <= h) { canvas.drawLine(0f, y, w, y, gridPaint); y += 64f }
                val centerPaint = Paint().apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f }
                canvas.drawLine(w / 2f, 0f, w / 2f, h, centerPaint)
                canvas.drawLine(0f, h / 2f, w, h / 2f, centerPaint)
            }
            BackgroundTemplate.SUNNY_MEADOW -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF38BDF8.toInt(), 0xFFBAE6FD.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.82f - panX * 0.2f, h * 0.2f - panY * 0.2f, 64f, paint)
                paint.color = 0xFF22C55E.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.62f, w * 0.7f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF16A34A.toInt()
                canvas.drawOval(RectF(w * 0.35f - panX * 0.7f, h * 0.66f, w * 1.25f - panX * 0.7f, h * 1.35f), paint)
            }
            BackgroundTemplate.CYBERPUNK_CITY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF090D1A.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.shader = LinearGradient(0f, h * 0.55f, 0f, h, 0x44FF6B35, 0x00000000, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, h * 0.55f, w, h, paint)
                paint.shader = null
                val bWidths = listOf(110f, 85f, 140f, 95f, 130f, 105f, 150f, 90f, 135f, 120f)
                val bHeights = listOf(260f, 380f, 220f, 420f, 300f, 360f, 250f, 410f, 290f, 330f)
                var bx = -40f - panX * 0.6f
                bWidths.forEachIndexed { idx, bw ->
                    val bh = bHeights[idx]
                    paint.color = 0xFF0F172A.toInt()
                    canvas.drawRect(bx, h - bh, bx + bw - 8f, h, paint)
                    paint.color = if (idx % 2 == 0) 0xAA2DD4BF.toInt() else 0xAAFF6B35.toInt()
                    var wy = h - bh + 20f
                    while (wy < h - 60f) { canvas.drawRect(bx + 14f, wy, bx + bw - 26f, wy + 7f, paint); wy += 26f }
                    bx += bw
                }
                paint.color = 0xFF151922.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
                paint.color = 0x552DD4BF; paint.strokeWidth = 2f
                canvas.drawLine(0f, h * 0.78f, w, h * 0.78f, paint)
            }
            BackgroundTemplate.COZY_STUDIO -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF292524.toInt(), 0xFF1C1917.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF44403C.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0x33FBBF24
                canvas.drawCircle(w * 0.5f, h * 0.35f, 280f, paint)
            }
            BackgroundTemplate.OUTER_SPACE -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0xFF030712.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val rng = Random(42)
                paint.color = 0xFFFFFFFF.toInt()
                repeat(70) { canvas.drawCircle(rng.nextFloat() * w, rng.nextFloat() * h, 1.5f + rng.nextFloat() * 2.5f, paint) }
                paint.color = 0xFF7C3AED.toInt()
                canvas.drawCircle(w * 0.78f - panX * 0.3f, h * 0.28f, 74f, paint)
                paint.color = 0x552DD4BF; paint.style = Paint.Style.STROKE; paint.strokeWidth = 10f
                canvas.drawOval(RectF(w * 0.78f - 125f - panX * 0.3f, h * 0.28f - 24f, w * 0.78f + 125f - panX * 0.3f, h * 0.28f + 24f), paint)
            }
            BackgroundTemplate.SUNSET_DESERT -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f, 0xFF7C2D12.toInt(), 0xFFFB923C.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.5f, h * 0.58f, 92f, paint)
                paint.color = 0xFF9A3412.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.5f, h * 0.65f, w * 0.75f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF7C2D12.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.7f, w * 1.2f - panX * 0.7f, h * 1.35f), paint)
            }
            // Module 9: 6 Multi-Plane South Asian / Folk & Horror Story Backdrops
            BackgroundTemplate.ZAMINDAR_VERANDA -> {
                // Warm courtyard sunlight + ochre mansion wall + arched heritage doorways
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f, 0xFFFEF3C7.toInt(), 0xFFF59E0B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Heritage cream-ochre wall with terracotta molding
                paint.color = 0xFFFEF9C3.toInt()
                canvas.drawRect(0f, h * 0.14f, w, h * 0.72f, paint)
                paint.color = 0xFFB45309.toInt()
                canvas.drawRect(0f, 0f, w, h * 0.16f, paint)
                // Repeating Mughal/Bengali wooden louvered arches
                val span = w + 320f
                for (i in 0..4) {
                    val ax = (((i * (span / 4f) - panX * 0.5f) % span) + span) % span - 120f
                    paint.color = 0xFF14532D.toInt()
                    canvas.drawRoundRect(RectF(ax - 55f, h * 0.24f, ax + 55f, h * 0.70f), 55f, 55f, paint)
                    paint.color = 0xFF166534.toInt()
                    canvas.drawRect(ax - 44f, h * 0.38f, ax + 44f, h * 0.70f, paint)
                }
                // Red oxide traditional veranda floor
                paint.color = 0xFF991B1B.toInt()
                canvas.drawRect(0f, h * 0.70f, w, h, paint)
                paint.color = 0xFF7F1D1D.toInt()
                canvas.drawRect(0f, h * 0.70f, w, h * 0.73f, paint)
            }
            BackgroundTemplate.VILLAGE_HUT_POND -> {
                // Golden Bengali village sky + distant palms + thatched mud hut + shimmering pond
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.65f, 0xFF38BDF8.toInt(), 0xFFFEF08A.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Distant green village treeline
                paint.color = 0xFF15803D.toInt()
                canvas.drawOval(RectF(-w * 0.1f - panX * 0.3f, h * 0.45f, w * 0.65f - panX * 0.3f, h * 0.92f), paint)
                paint.color = 0xFF16A34A.toInt()
                canvas.drawOval(RectF(w * 0.4f - panX * 0.35f, h * 0.48f, w * 1.2f - panX * 0.35f, h * 0.95f), paint)
                // Thatched Mud Hut on left-midground
                val hx = w * 0.28f - panX * 0.55f
                paint.color = 0xFFD6B98C.toInt()
                canvas.drawRect(hx - 110f, h * 0.48f, hx + 110f, h * 0.74f, paint)
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(hx - 28f, h * 0.56f, hx + 28f, h * 0.74f, paint)
                val roof = Path().apply {
                    moveTo(hx - 140f, h * 0.50f); lineTo(hx, h * 0.30f); lineTo(hx + 140f, h * 0.50f); close()
                }
                paint.color = 0xFFB45309.toInt()
                canvas.drawPath(roof, paint)
                // Village earth bank + Pond with animated water ripples
                paint.color = 0xFF4ADE80.toInt()
                canvas.drawRect(0f, h * 0.70f, w, h, paint)
                paint.color = 0xFF0284C7.toInt()
                canvas.drawOval(RectF(w * 0.48f - panX * 0.6f, h * 0.73f, w * 1.15f - panX * 0.6f, h * 1.15f), paint)
                paint.color = 0x88BAE6FD.toInt()
                val ripple = sin(frame * 0.15).toFloat() * 14f
                canvas.drawRect(w * 0.64f + ripple - panX * 0.6f, h * 0.82f, w * 0.84f + ripple - panX * 0.6f, h * 0.835f, paint)
            }
            BackgroundTemplate.ROYAL_DARBAR -> {
                // Deep crimson & gold royal Indian palace hall + carved archways + carpet runner
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.74f, 0xFF450A0A.toInt(), 0xFF991B1B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Ornate gold arch back wall
                paint.color = 0xFFD97706.toInt()
                canvas.drawRoundRect(RectF(w * 0.24f - panX * 0.4f, h * 0.12f, w * 0.76f - panX * 0.4f, h * 0.74f), 140f, 140f, paint)
                paint.color = 0xFF7F1D1D.toInt()
                canvas.drawRoundRect(RectF(w * 0.28f - panX * 0.4f, h * 0.17f, w * 0.72f - panX * 0.4f, h * 0.74f), 120f, 120f, paint)
                // Royal throne platform
                paint.color = 0xFFF59E0B.toInt()
                canvas.drawRoundRect(RectF(w * 0.41f - panX * 0.45f, h * 0.40f, w * 0.59f - panX * 0.45f, h * 0.70f), 18f, 18f, paint)
                // Marble floor + red royal carpet
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, h * 0.72f, w, h, paint)
                val carpet = Path().apply {
                    moveTo(w * 0.36f, h * 0.72f); lineTo(w * 0.64f, h * 0.72f)
                    lineTo(w * 0.78f, h); lineTo(w * 0.22f, h); close()
                }
                paint.color = 0xFFB91C1C.toInt()
                canvas.drawPath(carpet, paint)
            }
            BackgroundTemplate.VILLAGE_ROAD -> {
                // Bright countryside sky + green paddy fields + winding dusty village road
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.58f, 0xFF60A5FA.toInt(), 0xFFDBEAFE.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF22C55E.toInt()
                canvas.drawRect(0f, h * 0.54f, w, h, paint)
                // Winding ochre mud road
                val road = Path().apply {
                    moveTo(w * 0.42f - panX * 0.4f, h * 0.54f)
                    lineTo(w * 0.58f - panX * 0.4f, h * 0.54f)
                    lineTo(w * 0.86f - panX * 0.7f, h)
                    lineTo(w * 0.14f - panX * 0.7f, h)
                    close()
                }
                paint.color = 0xFFD97706.toInt()
                canvas.drawPath(road, paint)
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, h * 0.72f, w, h * 0.735f, paint)
            }
            BackgroundTemplate.HAUNTED_FOREST_MULTIPLANE -> {
                // Deep midnight teal haunted woods + large eerie moon + distant dead silhouettes
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF020617.toInt(), 0xFF0F2942.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val moonX = w * 0.52f - panX * 0.12f
                paint.shader = RadialGradient(moonX, h * 0.26f, 180f, 0x66E0F2FE, 0x00E0F2FE, Shader.TileMode.CLAMP)
                canvas.drawCircle(moonX, h * 0.26f, 180f, paint)
                paint.shader = null
                paint.color = 0xFFF1F5F9.toInt()
                canvas.drawCircle(moonX, h * 0.26f, 64f, paint)
                paint.color = 0xFF091324.toInt()
                val span = w + 320f
                for (i in 0..7) {
                    val tx = (((i * (span / 7f) - panX * 0.45f) % span) + span) % span - 140f
                    canvas.drawRect(tx - 16f, h * 0.24f, tx + 16f, h * 0.80f, paint)
                }
                paint.color = 0xFF020617.toInt()
                canvas.drawRect(0f, h * 0.76f, w, h, paint)
            }
            BackgroundTemplate.TRADITIONAL_ROOM -> {
                // Warm cream traditional Indian home interior with wall frame, wooden window & woven mat
                paint.color = 0xFFFEF3C7.toInt()
                canvas.drawRect(0f, 0f, w, h * 0.72f, paint)
                // Wooden window showing evening sky
                val wx = w * 0.58f - panX * 0.4f
                paint.color = 0xFF78350F.toInt()
                canvas.drawRoundRect(RectF(wx - 92f, h * 0.16f, wx + 92f, h * 0.48f), 8f, 8f, paint)
                paint.color = 0xFF38BDF8.toInt()
                canvas.drawRect(wx - 78f, h * 0.19f, wx + 78f, h * 0.45f, paint)
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(wx - 4f, h * 0.19f, wx + 4f, h * 0.45f, paint)
                canvas.drawRect(wx - 78f, h * 0.31f, wx + 78f, h * 0.33f, paint)
                // Terracotta floor + woven Madur mat
                paint.color = 0xFFC2410C.toInt()
                canvas.drawRect(0f, h * 0.72f, w, h, paint)
                paint.color = 0xFFEA580C.toInt()
                canvas.drawRoundRect(RectF(w * 0.18f - panX * 0.5f, h * 0.80f, w * 0.82f - panX * 0.5f, h * 0.94f), 10f, 10f, paint)
            }
        }
    }

    /**
     * Module 9: Multi-Plane Foreground Props (pillars, trees, columns, curtains) rendered AFTER
     * mid-ground characters so characters naturally walk BEHIND foreground architecture & foliage!
     */
    private fun drawBackgroundForegroundPlane(
        canvas: Canvas,
        templateName: String,
        w: Float,
        h: Float,
        panX: Float,
        panY: Float,
        frame: Int
    ) {
        val template = runCatching { BackgroundTemplate.valueOf(templateName) }.getOrDefault(BackgroundTemplate.SOLID)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val sway = sin(frame * 0.08).toFloat() * 6f
        when (template) {
            BackgroundTemplate.ZAMINDAR_VERANDA -> {
                // Tall foreground Zamindar veranda pillars on left & right edges
                listOf(w * 0.08f, w * 0.92f).forEach { baseX ->
                    val px = baseX - panX * 0.25f
                    paint.color = 0xFFE2D9C5.toInt()
                    canvas.drawRect(px - 34f, 0f, px + 34f, h, paint)
                    paint.color = 0xFFB45309.toInt()
                    canvas.drawRect(px - 44f, 0f, px + 44f, h * 0.12f, paint)
                    canvas.drawRect(px - 44f, h * 0.86f, px + 44f, h, paint)
                }
            }
            BackgroundTemplate.VILLAGE_HUT_POND, BackgroundTemplate.VILLAGE_ROAD -> {
                // Foreground silhouetted banana / mango foliage framing left & right edges
                paint.color = 0xDD14532D.toInt()
                canvas.drawOval(RectF(-70f - panX * 0.2f + sway, h * 0.62f, 150f - panX * 0.2f + sway, h * 1.1f), paint)
                canvas.drawOval(RectF(w - 150f - panX * 0.2f - sway, h * 0.64f, w + 70f - panX * 0.2f - sway, h * 1.12f), paint)
                paint.color = 0xCC166534.toInt()
                canvas.drawOval(RectF(-40f + sway, -60f, 220f + sway, 130f), paint)
            }
            BackgroundTemplate.ROYAL_DARBAR -> {
                // Golden Darbar foreground pillars + velvet red side curtains
                listOf(w * 0.06f, w * 0.94f).forEach { baseX ->
                    val px = baseX - panX * 0.2f
                    paint.color = 0xFFB45309.toInt()
                    canvas.drawRect(px - 36f, 0f, px + 36f, h, paint)
                    paint.color = 0xFFF59E0B.toInt()
                    canvas.drawRect(px - 14f, 0f, px + 14f, h, paint)
                }
            }
            BackgroundTemplate.HAUNTED_FOREST_MULTIPLANE, BackgroundTemplate.HAUNTED_FOREST -> {
                // Dark foreground gnarled tree trunks framing the left & right camera edges!
                paint.color = 0xF0020617.toInt()
                canvas.drawRect(-12f - panX * 0.2f, 0f, 76f - panX * 0.2f, h, paint)
                canvas.drawRect(w - 76f - panX * 0.2f, 0f, w + 12f - panX * 0.2f, h, paint)
                val branchP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xF0020617.toInt(); strokeWidth = 14f; strokeCap = Paint.Cap.ROUND
                }
                canvas.drawLine(64f, h * 0.22f, 190f + sway, h * 0.08f, branchP)
                canvas.drawLine(w - 64f, h * 0.28f, w - 185f - sway, h * 0.14f, branchP)
            }
            BackgroundTemplate.TRADITIONAL_ROOM -> {
                // Wooden doorway frame edges
                paint.color = 0xFF5C2D0C.toInt()
                canvas.drawRect(0f, 0f, 44f, h, paint)
                canvas.drawRect(w - 44f, 0f, w, h, paint)
                canvas.drawRect(0f, 0f, w, 34f, paint)
            }
            else -> Unit
        }
    }

    fun parseSimpleSvgShapes(svgContent: String, canvasW: Float, canvasH: Float): List<VectorShape> {
        val shapes = mutableListOf<VectorShape>()
        val cx = canvasW / 2f; val cy = canvasH / 2f
        fun extractAttr(tag: String, attr: String): Float? =
            Regex("""$attr\s*=\s*["']([0-9.\-]+)["']""").find(tag)?.groupValues?.getOrNull(1)?.toFloatOrNull()

        Regex("<rect[^>]+>").findAll(svgContent).forEach { m ->
            val x = extractAttr(m.value, "x") ?: 0f; val y = extractAttr(m.value, "y") ?: 0f
            val w = extractAttr(m.value, "width") ?: 120f; val h = extractAttr(m.value, "height") ?: 80f
            shapes.add(VectorShape(kind = ShapeKind.RECTANGLE.name, startX = cx - 150f + x, startY = cy - 100f + y, endX = cx - 150f + x + w, endY = cy - 100f + y + h, strokeColorArgb = 0xFF2DD4BFL, fillColorArgb = 0x662DD4BF, strokeWidth = 4f))
        }
        Regex("<circle[^>]+>").findAll(svgContent).forEach { m ->
            val x = extractAttr(m.value, "cx") ?: 80f; val y = extractAttr(m.value, "cy") ?: 80f
            val r = extractAttr(m.value, "r") ?: 50f
            shapes.add(VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 150f + x - r, startY = cy - 100f + y - r, endX = cx - 150f + x + r, endY = cy - 100f + y + r, strokeColorArgb = 0xFFFF6B35L, fillColorArgb = 0x66FF6B35, strokeWidth = 4f))
        }
        Regex("<line[^>]+>").findAll(svgContent).forEach { m ->
            val x1 = extractAttr(m.value, "x1") ?: 0f; val y1 = extractAttr(m.value, "y1") ?: 0f
            val x2 = extractAttr(m.value, "x2") ?: 120f; val y2 = extractAttr(m.value, "y2") ?: 120f
            shapes.add(VectorShape(kind = ShapeKind.LINE.name, startX = cx - 150f + x1, startY = cy - 100f + y1, endX = cx - 150f + x2, endY = cy - 100f + y2, strokeColorArgb = 0xFFFBBF24L, strokeWidth = 5f))
        }
        return shapes
    }
}
