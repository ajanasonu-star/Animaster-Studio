package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneTransition
import com.example.data.model.SceneVfxType
import com.example.data.model.SubtitleStyle
import com.example.data.model.VoiceEffectType
import com.example.engine.BuiltInAudioPreset
import com.example.engine.InterpolationEngine
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SceneCameraInspectorPanel(
    uiState: StudioUiState,
    onSelectScene: (String) -> Unit,
    onAddScene: () -> Unit,
    onDeleteScene: (String) -> Unit,
    onSetDuration: (Int) -> Unit,
    onAddFrames: (Int) -> Unit,
    onSetBackgroundTemplate: (BackgroundTemplate) -> Unit,
    onSetBackgroundScrollSpeed: (Float) -> Unit,
    onSetColorGrade: (SceneColorGrade) -> Unit,
    onToggleVfx: (SceneVfxType) -> Unit,
    onAddSubtitle: (text: String, speaker: String, durationFrames: Int, style: SubtitleStyle, colorArgb: Long) -> Unit,
    onDeleteSubtitle: (String) -> Unit,
    onSetTransition: (SceneTransition) -> Unit,
    onUpdateCamera: (Float, Float, Float, Float) -> Unit,
    onToggleCameraFrame: () -> Unit = {},
    onToggleCameraHud: () -> Unit = {},
    onCameraFollowSelected: () -> Unit,
    onCameraDollyZoom: () -> Unit = {},
    onCameraPanAcross: () -> Unit = {},
    onCameraShake: () -> Unit,
    onJumpToFrame: (Int) -> Unit = {},
    onDeleteCameraKeyframe: (Int) -> Unit = {},
    onResetCamera: () -> Unit,
    onSetDepthBlur: (Float) -> Unit = {},
    onToggleForegroundPlane: () -> Unit = {},
    onSetCameraFollowLayer: (String?) -> Unit = {},
    onUpdateSpotlight: (enabled: Boolean?, x: Float?, y: Float?, radius: Float?, intensity: Float?, colorArgb: Long?) -> Unit = { _, _, _, _, _, _ -> },
    onUpdateWatermark: (text: String?, opacity: Float?, corner: String?, clear: Boolean) -> Unit = { _, _, _, _ -> },
    onImportWatermarkLogo: () -> Unit = {}
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val cam = InterpolationEngine.evaluateCamera(scene, uiState.currentFrame)

    var subtitleText by remember { mutableStateOf("") }
    var subtitleSpeaker by remember { mutableStateOf("") }
    var subtitleStyle by remember { mutableStateOf(SubtitleStyle.YOUTUBE_BOLD) }
    var subtitleDuration by remember { mutableIntStateOf(36) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Scenes list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Scenes (${project.scenes.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                OutlinedButton(onClick = onAddScene, modifier = Modifier.testTag("add_scene_button")) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("New Scene", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                project.scenes.forEach { s ->
                    val active = s.id == scene.id
                    Surface(
                        color = if (active) StudioSurfaceElevated else StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (active) StudioCoral else StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectScene(s.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(s.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                Text("${s.durationFrames} frames • ${s.layers.size} layers", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                            }
                            if (project.scenes.size > 1) {
                                IconButton(onClick = { onDeleteScene(s.id) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete scene", tint = StudioRose, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Unlimited Duration, Aesthetic Backdrops & VFX
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text(
                "Scene Duration: ${scene.durationFrames} frames (${String.format("%.1fs", scene.durationFrames.toFloat() / project.fps.coerceAtLeast(1))})",
                style = MaterialTheme.typography.labelMedium,
                color = StudioTextPrimary
            )
            Slider(
                value = scene.durationFrames.toFloat().coerceIn(12f, 2000f),
                onValueChange = { onSetDuration(it.toInt()) },
                valueRange = 12f..2000f,
                colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(10, 50, 100).forEach { delta ->
                    OutlinedButton(
                        onClick = { onAddFrames(delta) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("+$delta F", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Background, Horror & Pastel Backdrops", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BackgroundTemplate.entries.forEach { tpl ->
                    FilterChip(
                        selected = scene.backgroundTemplate == tpl.name,
                        onClick = { onSetBackgroundTemplate(tpl) },
                        label = { Text(tpl.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Auto-Scroll BG: ${String.format("%.1f", scene.backgroundScrollSpeed)} px/f",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioCyan
                )
                if (scene.backgroundScrollSpeed != 0f) {
                    OutlinedButton(onClick = { onSetBackgroundScrollSpeed(0f) }) {
                        Text("Stop", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Slider(
                value = scene.backgroundScrollSpeed.coerceIn(-8f, 8f),
                onValueChange = { onSetBackgroundScrollSpeed(it) },
                valueRange = -8f..8f,
                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                modifier = Modifier.testTag("scene_bg_scroll_slider")
            )
            // Module 9: Multi-Plane Depth Foreground & Background Depth Blur
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Multi-Plane Foreground (Pillars/Trees)", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                Switch(checked = scene.foregroundPlaneEnabled, onCheckedChange = { onToggleForegroundPlane() })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Depth Blur ${(scene.backgroundDepthBlur * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioViolet, modifier = Modifier.width(96.dp))
                Slider(
                    value = scene.backgroundDepthBlur.coerceIn(0f, 1f),
                    onValueChange = onSetDepthBlur,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet),
                    modifier = Modifier.weight(1f).testTag("scene_depth_blur_slider")
                )
            }
            Spacer(Modifier.height(8.dp))
            Text("Cinematic Color Grading", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneColorGrade.entries.forEach { grade ->
                    FilterChip(
                        selected = scene.colorGrade == grade.name,
                        onClick = { onSetColorGrade(grade) },
                        label = { Text(grade.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("scene_grade_${grade.name.lowercase()}")
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Weather, Sunlight & Cinematic VFX", style = MaterialTheme.typography.titleSmall, color = StudioViolet)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneVfxType.entries.forEach { vfx ->
                    val active = vfx.name in scene.activeVfx
                    FilterChip(
                        selected = active,
                        onClick = { onToggleVfx(vfx) },
                        label = { Text(vfx.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("scene_vfx_${vfx.name.lowercase()}")
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Scene Transition", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneTransition.entries.forEach { tr ->
                    FilterChip(
                        selected = scene.transition == tr.name,
                        onClick = { onSetTransition(tr) },
                        label = { Text(tr.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Dynamic YouTube Subtitles & Captions Creator
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("YouTube Subtitles & Captions (${scene.subtitles.size})", style = MaterialTheme.typography.titleSmall, color = StudioCoral)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = subtitleSpeaker,
                onValueChange = { subtitleSpeaker = it },
                label = { Text("Speaker (optional, e.g. GHOST)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = subtitleText,
                onValueChange = { subtitleText = it },
                label = { Text("Caption line (e.g. Wait... who's there?!)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("subtitle_text_input")
            )
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SubtitleStyle.entries.forEach { st ->
                    FilterChip(
                        selected = subtitleStyle == st,
                        onClick = { subtitleStyle = st },
                        label = { Text(st.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Hold ${subtitleDuration}F", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(68.dp))
                Slider(
                    value = subtitleDuration.toFloat(),
                    onValueChange = { subtitleDuration = it.toInt() },
                    valueRange = 12f..120f,
                    modifier = Modifier.weight(1f)
                )
            }
            Button(
                onClick = {
                    val color = when (subtitleStyle) {
                        SubtitleStyle.HORROR_DRIP -> 0xFFFF3B5CL
                        SubtitleStyle.YOUTUBE_BOLD -> 0xFFFFE066L
                        SubtitleStyle.COMIC_BOX -> 0xFF38BDF8L
                        SubtitleStyle.CINEMATIC -> 0xFFFFFFFFL
                    }
                    onAddSubtitle(subtitleText, subtitleSpeaker, subtitleDuration, subtitleStyle, color)
                    subtitleText = ""
                },
                enabled = subtitleText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                modifier = Modifier.fillMaxWidth().testTag("add_subtitle_button")
            ) {
                Text("+ Add Caption at F${uiState.currentFrame + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            if (scene.subtitles.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    scene.subtitles.forEach { cue ->
                        Surface(
                            color = StudioSurfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, StudioBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (cue.speakerName.isNotBlank()) "${cue.speakerName}: ${cue.text}" else cue.text,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = StudioTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "F${cue.startFrame + 1}–F${cue.endFrame + 1} • ${cue.style}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioTextMuted
                                    )
                                }
                                IconButton(onClick = { onDeleteSubtitle(cue.id) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete caption", tint = StudioRose, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Cinematic Camera Motion Director
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Videocam, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(18.dp))
                    Text("Camera Motion Director (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                }
                IconButton(onClick = onResetCamera, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.RestartAlt, contentDescription = "Reset camera", tint = StudioTextSecondary)
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = uiState.showCameraFrame,
                    onClick = onToggleCameraFrame,
                    label = { Text("View Frame", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("camera_toggle_frame_btn")
                )
                FilterChip(
                    selected = uiState.showCameraHud,
                    onClick = onToggleCameraHud,
                    label = { Text("On-Stage HUD", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("camera_toggle_hud_btn")
                )
            }
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onCameraFollowSelected,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber, contentColor = Color.Black),
                    modifier = Modifier.testTag("camera_follow_char_btn")
                ) {
                    Text("Follow Char", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCameraDollyZoom,
                    modifier = Modifier.testTag("camera_dolly_zoom_btn")
                ) {
                    Text("Dolly Zoom", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }
                OutlinedButton(
                    onClick = onCameraPanAcross,
                    modifier = Modifier.testTag("camera_pan_across_btn")
                ) {
                    Text("Pan Across", style = MaterialTheme.typography.labelSmall, color = StudioViolet)
                }
                OutlinedButton(
                    onClick = onCameraShake,
                    modifier = Modifier.testTag("camera_shake_btn")
                ) {
                    Text("Handheld Shake", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                }
            }
            Spacer(Modifier.height(6.dp))
            CameraSlider("Zoom ${String.format("%.2fx", cam.zoom)}", cam.zoom, 0.3f..4.0f) {
                onUpdateCamera(cam.panX, cam.panY, it, cam.rotationDeg)
            }
            CameraSlider("Pan X ${cam.panX.toInt()}", cam.panX, -800f..800f) {
                onUpdateCamera(it, cam.panY, cam.zoom, cam.rotationDeg)
            }
            CameraSlider("Pan Y ${cam.panY.toInt()}", cam.panY, -600f..600f) {
                onUpdateCamera(cam.panX, it, cam.zoom, cam.rotationDeg)
            }
            CameraSlider("Tilt ${cam.rotationDeg.toInt()}°", cam.rotationDeg, -180f..180f) {
                onUpdateCamera(cam.panX, cam.panY, cam.zoom, it)
            }
            if (scene.cameraKeyframes.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Camera Keyframes (${scene.cameraKeyframes.size}) • Ease In-Out",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextMuted
                )
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scene.cameraKeyframes.forEach { kf ->
                        Surface(
                            color = if (kf.frame == uiState.currentFrame) StudioAmber.copy(alpha = 0.22f) else StudioSurfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (kf.frame == uiState.currentFrame) StudioAmber else StudioBorder),
                            modifier = Modifier.clickable { onJumpToFrame(kf.frame) }
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 8.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    "F${kf.frame + 1} (${String.format("%.1fx", kf.zoom)})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioTextPrimary
                                )
                                if (scene.cameraKeyframes.size > 1) {
                                    IconButton(
                                        onClick = { onDeleteCameraKeyframe(kf.frame) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete camera keyframe", tint = StudioRose, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Module 9: Live Camera Auto-Follow Character
            Spacer(Modifier.height(8.dp))
            Text("Live Camera Follow Target", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = scene.cameraFollowLayerId == null,
                    onClick = { onSetCameraFollowLayer(null) },
                    label = { Text("Off", style = MaterialTheme.typography.labelSmall) }
                )
                scene.layers.filter { it.rig != null || it.character != null }.forEach { chLayer ->
                    FilterChip(
                        selected = scene.cameraFollowLayerId == chLayer.id,
                        onClick = { onSetCameraFollowLayer(chLayer.id) },
                        label = { Text(chLayer.name, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Module 9: Directional Spotlight & Channel Brand Watermark / Logo
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Directional Spotlight", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                Switch(
                    checked = scene.spotlightEnabled,
                    onCheckedChange = { onUpdateSpotlight(it, null, null, null, null, null) }
                )
            }
            if (scene.spotlightEnabled) {
                CameraSlider("Spot X ${(scene.spotlightX * 100).toInt()}%", scene.spotlightX, 0f..1f) {
                    onUpdateSpotlight(null, it, null, null, null, null)
                }
                CameraSlider("Spot Y ${(scene.spotlightY * 100).toInt()}%", scene.spotlightY, 0f..1f) {
                    onUpdateSpotlight(null, null, it, null, null, null)
                }
                CameraSlider("Radius ${(scene.spotlightRadius * 100).toInt()}%", scene.spotlightRadius, 0.15f..1f) {
                    onUpdateSpotlight(null, null, null, it, null, null)
                }
                CameraSlider("Power ${(scene.spotlightIntensity * 100).toInt()}%", scene.spotlightIntensity, 0.1f..1f) {
                    onUpdateSpotlight(null, null, null, null, it, null)
                }
            }

            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Channel Brand Watermark / Logo (Visible on Export)", style = MaterialTheme.typography.titleSmall, color = StudioEmerald)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = scene.watermarkText,
                onValueChange = { onUpdateWatermark(it, null, null, false) },
                label = { Text("Channel Name / @Handle") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("scene_watermark_input")
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onImportWatermarkLogo, modifier = Modifier.weight(1f)) {
                    Text(if (scene.watermarkImagePath.isNullOrBlank()) "+ Logo PNG" else "Replace Logo", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }
                if (scene.watermarkText.isNotBlank() || !scene.watermarkImagePath.isNullOrBlank()) {
                    OutlinedButton(onClick = { onUpdateWatermark(null, null, null, true) }) {
                        Text("Clear", style = MaterialTheme.typography.labelSmall, color = StudioRose)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("TOP_LEFT" to "Top-L", "TOP_RIGHT" to "Top-R", "BOTTOM_LEFT" to "Bot-L", "BOTTOM_RIGHT" to "Bot-R").forEach { (key, lbl) ->
                    FilterChip(
                        selected = scene.watermarkCorner == key,
                        onClick = { onUpdateWatermark(null, null, key, false) },
                        label = { Text(lbl, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            CameraSlider("Opacity ${(scene.watermarkOpacity * 100).toInt()}%", scene.watermarkOpacity, 0.1f..1f) {
                onUpdateWatermark(null, it, null, false)
            }
        }
    }
}

@Composable
private fun CameraSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
            modifier = Modifier.weight(1f)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AudioStudioInspectorPanel(
    uiState: StudioUiState,
    onRequestRecordVoice: () -> Unit,
    onStopVoiceRecording: () -> Unit,
    onImportAudio: () -> Unit,
    onAddBuiltInPreset: (BuiltInAudioPreset) -> Unit,
    onPreviewTrack: (AudioTrackItem) -> Unit,
    onUpdateTrack: (AudioTrackItem) -> Unit,
    onApplyVoiceEffect: (AudioTrackItem, VoiceEffectType) -> Unit,
    onDeleteTrack: (String) -> Unit,
    onToggleAutoDuck: (String) -> Unit = {}
) {
    val project = uiState.activeProject ?: return
    var pendingDeleteTrack by remember { mutableStateOf<AudioTrackItem?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Voice Recording & Import
        item {
            Text("Voice & Audio Import", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (uiState.isRecordingVoice) onStopVoiceRecording() else onRequestRecordVoice()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isRecordingVoice) StudioRose else StudioCoral
                    ),
                    modifier = Modifier.weight(1f).testTag("voice_record_button")
                ) {
                    Icon(
                        if (uiState.isRecordingVoice) Icons.Rounded.Stop else Icons.Rounded.Mic,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (uiState.isRecordingVoice) "Stop Rec" else "Record Voice", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onImportAudio,
                    modifier = Modifier.weight(1f).testTag("import_audio_button")
                ) {
                    Icon(Icons.Rounded.AudioFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Import", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (uiState.isRecordingVoice) {
                Spacer(Modifier.height(8.dp))
                Text("Recording live audio...", style = MaterialTheme.typography.labelSmall, color = StudioRose)
                LinearProgressIndicator(
                    progress = { uiState.voiceAmplitude.coerceIn(0.05f, 1f) },
                    color = StudioRose,
                    trackColor = StudioSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                )
            }
        }

        // Built-in Offline SFX & Music Synth
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(16.dp))
                Text("Offline SFX & Music Synth", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            }
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BuiltInAudioPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { onAddBuiltInPreset(preset) },
                        label = { Text(preset.title, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Audio Track Mixer Cards
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Timeline Audio Tracks (${project.audioTracks.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
        }

        if (project.audioTracks.isEmpty()) {
            item {
                Text(
                    "Record your voice, import audio, or tap any offline SFX above to add it at frame F${uiState.currentFrame + 1}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextMuted
                )
            }
        } else {
            items(project.audioTracks, key = { it.id }) { track ->
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(track.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("Start F${track.startFrame + 1} • ${track.durationMs}ms", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                            }
                            IconButton(onClick = { onPreviewTrack(track) }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Preview track", tint = StudioEmerald)
                            }
                            IconButton(onClick = { onUpdateTrack(track.copy(muted = !track.muted)) }, modifier = Modifier.size(34.dp)) {
                                Icon(
                                    if (track.muted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                                    contentDescription = "Mute toggle",
                                    tint = if (track.muted) StudioTextMuted else StudioCyan
                                )
                            }
                            IconButton(
                                onClick = { pendingDeleteTrack = track },
                                modifier = Modifier.size(34.dp).testTag("delete_audio_${track.id}")
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete track", tint = StudioRose)
                            }
                        }

                        // Mini Waveform Bar Strip
                        if (track.waveformPeaks.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(26.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0D1117))
                                    .padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                track.waveformPeaks.take(36).forEach { peak ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height((peak * 22f).coerceIn(3f, 22f).dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(if (track.muted) StudioTextMuted else StudioEmerald)
                                    )
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vol ${(track.volume * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(64.dp))
                            Slider(
                                value = track.volume,
                                onValueChange = { onUpdateTrack(track.copy(volume = it)) },
                                valueRange = 0f..1f,
                                colors = SliderDefaults.colors(thumbColor = StudioEmerald, activeTrackColor = StudioEmerald),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Start F${track.startFrame + 1}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(64.dp))
                            Slider(
                                value = track.startFrame.toFloat(),
                                onValueChange = { onUpdateTrack(track.copy(startFrame = it.toInt())) },
                                valueRange = 0f..((uiState.activeScene?.durationFrames ?: 48) - 1).coerceAtLeast(1).toFloat(),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Trim ${(track.trimEndMs / 1000f).let { String.format("%.1fs", it) }}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(64.dp))
                            Slider(
                                value = track.trimEndMs.toFloat().coerceIn(200f, track.durationMs.toFloat().coerceAtLeast(250f)),
                                onValueChange = { onUpdateTrack(track.copy(trimEndMs = it.toLong())) },
                                valueRange = 200f..track.durationMs.toFloat().coerceAtLeast(250f),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // Module 8: Auto-Duck Music toggle (automatically lowers BGM to 28% during voice dialogue!)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Auto-Duck Music under Voice", style = MaterialTheme.typography.labelSmall, color = StudioAmber)
                            Switch(
                                checked = track.autoDuckMusic,
                                onCheckedChange = { onToggleAutoDuck(track.id) }
                            )
                        }
                        // Offline Voice Changer FX (Cartoon Kid, Deep Monster, Ghost Echo, Robot)
                        Text("Voice Changer FX", style = MaterialTheme.typography.labelSmall, color = StudioViolet)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            VoiceEffectType.entries.forEach { fx ->
                                FilterChip(
                                    selected = track.voiceEffect == fx.name,
                                    onClick = { onApplyVoiceEffect(track, fx) },
                                    label = { Text(fx.label, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("voice_fx_${fx.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDeleteTrack?.let { track ->
        AlertDialog(
            onDismissRequest = { pendingDeleteTrack = null },
            containerColor = StudioSurfaceElevated,
            title = { Text("Delete Audio Track?", color = StudioTextPrimary) },
            text = { Text("Remove \"${track.name}\" from this project?", color = StudioTextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteTrack(track.id)
                        pendingDeleteTrack = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRose)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteTrack = null }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}
