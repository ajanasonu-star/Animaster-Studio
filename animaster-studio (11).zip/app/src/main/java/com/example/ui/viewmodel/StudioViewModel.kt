package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AnimasterDatabase
import com.example.data.local.LocalAssetEntity
import com.example.data.local.ProjectRepository
import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationProject
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CameraKeyframe
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.CustomActionClip
import com.example.data.model.DisplaySettings
import com.example.data.model.DrawStroke
import com.example.data.model.EasingType
import com.example.data.model.EditorTool
import com.example.data.model.ExportSettings
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FrameContent
import com.example.data.model.FrameVisibilityRange
import com.example.data.model.HandGesturePose
import com.example.data.model.HandPropKind
import com.example.data.model.ImportedImageItem
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PartBehaviorPreset
import com.example.data.model.ProjectSummary
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.RigBone
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneTransition
import com.example.data.model.SceneVfxType
import com.example.data.model.ScreenMode
import com.example.data.model.ShapeKind
import com.example.data.model.SkeletalRig
import com.example.data.model.SubtitleCue
import com.example.data.model.SubtitleStyle
import com.example.data.model.TargetedLoopClip
import com.example.data.model.TargetedLoopType
import com.example.data.model.TextBoxStyle
import com.example.data.model.TextFontStyle
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.TextOutAnimation
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.data.model.VoiceEffectType
import com.example.engine.AudioStudioEngine
import com.example.engine.AutoActionKind
import com.example.engine.BoneZOrderAction
import com.example.engine.BuiltInAudioPreset
import com.example.engine.ExportEngine
import com.example.engine.ExportResult
import com.example.engine.InterpolationEngine
import com.example.engine.MotionPreset
import com.example.engine.ProceduralPropKind
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigAttachmentArea
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.engine.StoryboardTemplate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

enum class StudioDestination {
    HUB,
    EDITOR,
    CHARACTER_RIG_STUDIO,
    CEL_STUDIO
}

enum class InspectorTab(val label: String) {
    LAYERS("Layers"),
    TEXT("Text"),
    PROPS("Props"),
    CHARACTER("Character"),
    RIG("Rigging"),
    SCENE("Scene"),
    AUDIO("Audio"),
    ASSETS("Assets")
}

enum class TrackSelectionKind(val label: String) {
    LAYER("Layer"),
    TEXT("Text"),
    AUDIO("Audio")
}

data class StudioUiState(
    val destination: StudioDestination = StudioDestination.HUB,
    val returnDestinationFromCharStudio: StudioDestination = StudioDestination.HUB,
    val displaySettings: DisplaySettings = DisplaySettings(),
    val showScreenSettingsDialog: Boolean = false,
    val showImportCharacterSheet: Boolean = false,
    val paintDrawerOpen: Boolean = false,
    val trackToolsExpanded: Boolean = false,
    val characterActionsExpanded: Boolean = false,
    val activeProject: AnimationProject? = null,
    val currentFrame: Int = 0,
    val selectedLayerId: String? = null,
    val selectedBoneId: String? = null,
    val selectedTextId: String? = null,
    val selectedAudioTrackId: String? = null,
    val selectedTrackKind: TrackSelectionKind = TrackSelectionKind.LAYER,
    val activeTool: EditorTool = EditorTool.RIG_EDIT,
    val primaryColorArgb: Long = 0xFFFF6B35L,
    val useGradient: Boolean = false,
    val gradientColorArgb: Long = 0xFF2DD4BFL,
    val brushSize: Float = 10f,
    val brushOpacity: Float = 1f,
    val fillShapes: Boolean = true,
    val polygonSides: Int = 5,
    val activeEasing: EasingType = EasingType.EASE_IN_OUT,
    val isPlaying: Boolean = false,
    val isLooping: Boolean = true,
    val onionSkinEnabled: Boolean = true,
    val ghostFramesEnabled: Boolean = false,
    val showRigOverlay: Boolean = true,
    val showMotionPaths: Boolean = true,
    val showCameraFrame: Boolean = false,
    val showCameraHud: Boolean = false,
    val activeInspectorTab: InspectorTab = InspectorTab.LAYERS,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isRecordingVoice: Boolean = false,
    val voiceAmplitude: Float = 0f,
    val isExporting: Boolean = false,
    val exportProgress: Float = 0f,
    val exportStatus: String = "",
    val lastExportResult: ExportResult? = null,
    val statusBanner: String? = null,
    val canvasZoom: Float = 1f,
    val canvasPanX: Float = 0f,
    val canvasPanY: Float = 0f,
    // Dedicated Character & Rig Studio draft state
    val studioDraftRig: SkeletalRig = RigSolver.createRiggedCharacterFromSpec(
        ProceduralSmartTools.characterPresets.first(),
        rootX = 640f,
        rootY = 420f
    ),
    val studioDraftSelectedBoneId: String? = "neck",
    val studioDraftOnionSkin: Boolean = true,
    val studioDraftTestFrame: Int = 0,
    val studioDraftPlaying: Boolean = false,
    // Modules 2, 7, 8 studio states
    val stretchRigMode: Boolean = false,
    val liveRecordMode: Boolean = false,
    val rangeStartFrame: Int = 0,
    val rangeEndFrame: Int = 24,
    val celOnionNextEnabled: Boolean = true,
    val celOnionOpacity: Float = 0.34f,
    val celLayerId: String? = null
) {
    val activeScene: AnimationScene?
        get() = activeProject?.let { p ->
            p.scenes.firstOrNull { it.id == p.activeSceneId } ?: p.scenes.firstOrNull()
        }

    val selectedLayer: AnimationLayer?
        get() = activeScene?.layers?.firstOrNull { it.id == selectedLayerId }
            ?: activeScene?.layers?.firstOrNull()

    val selectedText: CanvasTextItem?
        get() = activeScene?.animatedTexts?.firstOrNull { it.id == selectedTextId }
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("animaster_display_prefs", Context.MODE_PRIVATE)
    private val db = AnimasterDatabase.getInstance(application)
    val repository = ProjectRepository(db.projectDao(), db.localAssetDao())
    val audioEngine = AudioStudioEngine(application)
    val exportEngine = ExportEngine(application)
    private val projectAssetsDir: File by lazy {
        File(application.filesDir, "project_assets").apply { mkdirs() }
    }

    val projects: StateFlow<List<ProjectSummary>> = repository.projectsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recoverySnapshot: StateFlow<ProjectSummary?> = repository.recoverySnapshotFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val localAssets: StateFlow<List<LocalAssetEntity>> = repository.assetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myCharacters: StateFlow<List<SkeletalRig>> = repository.riggedCharactersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customAssets: StateFlow<List<SkeletalRig>> = repository.customAssetsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customActions: StateFlow<List<CustomActionClip>> = repository.customActionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(
        StudioUiState(
            displaySettings = loadDisplaySettings()
        )
    )
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private val undoStack = ArrayDeque<AnimationProject>()
    private val redoStack = ArrayDeque<AnimationProject>()
    private var playbackJob: Job? = null
    private var draftPlaybackJob: Job? = null
    private var autosaveJob: Job? = null
    private var voiceJob: Job? = null

    private fun loadDisplaySettings(): DisplaySettings {
        val modeName = prefs.getString("screen_mode", ScreenMode.AUTO_RESPONSIVE.name)
            ?: ScreenMode.AUTO_RESPONSIVE.name
        val mode = runCatching { ScreenMode.valueOf(modeName) }.getOrDefault(ScreenMode.AUTO_RESPONSIVE)
        val scale = prefs.getFloat("ui_scale", 1.0f).coerceIn(0.75f, 1.15f)
        return DisplaySettings(screenMode = mode, uiScale = scale)
    }

    init {
        // Seed one rich demo project on first launch only when the local DB is genuinely empty
        viewModelScope.launch {
            if (repository.getProjectCount() == 0) {
                val starter = ProceduralSmartTools.createProjectFromTemplate(
                    name = "Pastel Cartoon Demo",
                    width = 1280,
                    height = 720,
                    fps = 24,
                    template = StoryboardTemplate.HERO_DEMO
                )
                repository.saveProject(starter, isRecovery = false)
            }
        }
    }

    // ─── Screen & Display Settings & Workspace Navigation ───────────

    fun openScreenSettingsDialog(open: Boolean) {
        _uiState.update { it.copy(showScreenSettingsDialog = open) }
    }

    fun setScreenMode(mode: ScreenMode) {
        prefs.edit().putString("screen_mode", mode.name).apply()
        _uiState.update { it.copy(displaySettings = it.displaySettings.copy(screenMode = mode)) }
        showToast("Screen Mode: ${mode.label}")
    }

    fun setUiScale(scale: Float) {
        val clamped = scale.coerceIn(0.75f, 1.15f)
        prefs.edit().putFloat("ui_scale", clamped).apply()
        _uiState.update { it.copy(displaySettings = it.displaySettings.copy(uiScale = clamped)) }
    }

    fun togglePaintDrawer() = _uiState.update { it.copy(paintDrawerOpen = !it.paintDrawerOpen) }
    fun setPaintDrawerOpen(open: Boolean) = _uiState.update { it.copy(paintDrawerOpen = open) }
    fun toggleCharacterActionsExpanded() = _uiState.update { it.copy(characterActionsExpanded = !it.characterActionsExpanded) }
    fun openImportCharacterSheet(open: Boolean) = _uiState.update { it.copy(showImportCharacterSheet = open) }

    fun openCustomAssetMaker() {
        openCharacterRigStudio(
            RigSolver.createCustomAssetStarterRig(
                name = "Custom Asset ${(customAssets.value.size) + 1}",
                rootX = 640f,
                rootY = 400f
            )
        )
    }

    fun openCharacterRigStudio(initialRig: SkeletalRig? = null) {
        stopPlayback()
        val currentDest = _uiState.value.destination
        val baseRig = initialRig?.copy(
            rootX = 640f,
            rootY = 420f
        ) ?: RigSolver.createRiggedCharacterFromSpec(
            ProceduralSmartTools.characterPresets.first(),
            rootX = 640f,
            rootY = 420f
        ).copy(
            name = "My Hero",
            poseKeyframes = mapOf(
                "0" to RigSolver.presetPoseAngles("IDLE"),
                "12" to RigSolver.presetPoseAngles("WAVE"),
                "24" to RigSolver.presetPoseAngles("WALK")
            )
        )
        _uiState.update {
            it.copy(
                destination = StudioDestination.CHARACTER_RIG_STUDIO,
                returnDestinationFromCharStudio = if (currentDest == StudioDestination.CHARACTER_RIG_STUDIO) it.returnDestinationFromCharStudio else currentDest,
                studioDraftRig = baseRig,
                studioDraftSelectedBoneId = baseRig.bones.firstOrNull { b -> b.id == "neck" }?.id ?: baseRig.bones.firstOrNull()?.id,
                studioDraftTestFrame = 0,
                studioDraftPlaying = false
            )
        }
    }

    fun closeCharacterRigStudio() {
        stopDraftPlayback()
        _uiState.update { state ->
            val target = if (state.activeProject != null && state.returnDestinationFromCharStudio == StudioDestination.EDITOR) {
                StudioDestination.EDITOR
            } else {
                StudioDestination.HUB
            }
            state.copy(destination = target, studioDraftPlaying = false)
        }
    }

    fun updateStudioDraftRig(transform: (SkeletalRig) -> SkeletalRig) {
        _uiState.update { it.copy(studioDraftRig = transform(it.studioDraftRig)) }
    }

    fun selectStudioDraftBone(boneId: String?) {
        _uiState.update { it.copy(studioDraftSelectedBoneId = boneId) }
    }

    fun toggleStudioDraftOnionSkin() {
        _uiState.update { it.copy(studioDraftOnionSkin = !it.studioDraftOnionSkin) }
    }

    fun setStudioDraftTestFrame(frame: Int) {
        _uiState.update { it.copy(studioDraftTestFrame = frame.coerceIn(0, 35)) }
    }

    fun toggleStudioDraftTestPlay() {
        if (_uiState.value.studioDraftPlaying) {
            stopDraftPlayback()
        } else {
            draftPlaybackJob?.cancel()
            _uiState.update { it.copy(studioDraftPlaying = true) }
            draftPlaybackJob = viewModelScope.launch {
                while (isActive && _uiState.value.studioDraftPlaying) {
                    delay(80L)
                    _uiState.update { it.copy(studioDraftTestFrame = (it.studioDraftTestFrame + 1) % 36) }
                }
            }
        }
    }

    private fun stopDraftPlayback() {
        draftPlaybackJob?.cancel()
        draftPlaybackJob = null
        _uiState.update { it.copy(studioDraftPlaying = false) }
    }

    fun dragStudioDraftBone(boneId: String, target: Vec2) {
        val state = _uiState.value
        val rig = state.studioDraftRig
        val frame = state.studioDraftTestFrame
        val currentAngles = InterpolationEngine.evaluateRigAngles(rig, frame)
        val currentLengths = InterpolationEngine.evaluateBoneLengths(rig, frame)
        val effectiveFlipped = SceneRenderer.isLeftFacingView(rig.viewAngle, rig.flippedHorizontal)
        val draggedBone = rig.bones.firstOrNull { it.id == boneId }
        val allowStretch = state.stretchRigMode ||
            draggedBone?.allowElasticStretch == true ||
            draggedBone?.partBehaviorPreset == PartBehaviorPreset.ELASTIC_RUBBER.name
        if (allowStretch) {
            val (newAngles, newLengths) = RigSolver.solveStretchDragTarget(
                rig = rig,
                boneId = boneId,
                target = target,
                currentAngles = currentAngles,
                currentLengths = currentLengths,
                rootX = rig.rootX,
                rootY = rig.rootY,
                scale = rig.scale,
                scaleX = rig.scaleX,
                scaleY = rig.scaleY,
                flippedHorizontal = effectiveFlipped
            )
            _uiState.update {
                it.copy(
                    studioDraftSelectedBoneId = boneId,
                    studioDraftRig = rig.copy(
                        poseKeyframes = rig.poseKeyframes + (frame.toString() to newAngles),
                        boneLengthKeyframes = rig.boneLengthKeyframes + (frame.toString() to newLengths)
                    )
                )
            }
        } else {
            val newAngles = RigSolver.solveDragTarget(
                rig = rig,
                boneId = boneId,
                target = target,
                currentAngles = currentAngles,
                useIk = rig.ikEnabled,
                rootX = rig.rootX,
                rootY = rig.rootY,
                scale = rig.scale,
                flippedHorizontal = effectiveFlipped,
                lengthOverrides = currentLengths
            )
            _uiState.update {
                it.copy(
                    studioDraftSelectedBoneId = boneId,
                    studioDraftRig = rig.copy(poseKeyframes = rig.poseKeyframes + (frame.toString() to newAngles))
                )
            }
        }
    }

    fun autoRigStudioDraft() {
        updateStudioDraftRig { rig -> RigSolver.autoRigHumanoid(rig) }
        _uiState.update { it.copy(studioDraftSelectedBoneId = "hand_r") }
        showToast("Auto-Rigged Human Skeleton (14 joints: Head, Arms, Hands, Legs, Feet)")
    }

    fun applyStudioNonHumanTemplate(category: String) {
        updateStudioDraftRig { cur ->
            val template = when (category) {
                "BIRD" -> RigSolver.createBirdWingedRig(
                    name = if (cur.name.isBlank() || cur.name == "My Hero") "Bird / Winged Rig" else cur.name,
                    rootX = cur.rootX,
                    rootY = cur.rootY
                )
                "QUADRUPED" -> RigSolver.createQuadrupedAnimalRig(
                    name = if (cur.name.isBlank() || cur.name == "My Hero") "Animal Quadruped Rig" else cur.name,
                    rootX = cur.rootX,
                    rootY = cur.rootY
                )
                "CUSTOM_OBJECT" -> RigSolver.createCustomObjectRig(
                    name = if (cur.name.isBlank() || cur.name == "My Hero") "Custom Object Rig" else cur.name,
                    rootX = cur.rootX,
                    rootY = cur.rootY
                )
                "ASSET" -> RigSolver.createCustomAssetStarterRig(
                    name = if (cur.name.isBlank() || cur.name == "My Hero") "My Custom Asset" else cur.name,
                    rootX = cur.rootX,
                    rootY = cur.rootY
                )
                else -> RigSolver.autoRigHumanoid(cur).copy(rigCategory = "HUMAN")
            }
            template.copy(
                id = cur.id,
                scale = cur.scale,
                flippedHorizontal = cur.flippedHorizontal,
                viewAngle = cur.viewAngle,
                eyePack = cur.eyePack,
                mouthPhoneme = cur.mouthPhoneme,
                singleMeshImagePath = cur.singleMeshImagePath,
                singleMeshWidth = cur.singleMeshWidth,
                singleMeshHeight = cur.singleMeshHeight,
                singleMeshScale = cur.singleMeshScale,
                singleMeshOffsetX = cur.singleMeshOffsetX,
                singleMeshOffsetY = cur.singleMeshOffsetY,
                showFaceOverlayOnCustomImage = cur.showFaceOverlayOnCustomImage,
                faceOverlayOffsetX = cur.faceOverlayOffsetX,
                faceOverlayOffsetY = cur.faceOverlayOffsetY,
                faceOverlayScale = cur.faceOverlayScale,
                characterAppearance = if (category == "HUMAN") cur.characterAppearance else null
            )
        }
        val firstBoneId = _uiState.value.studioDraftRig.bones.firstOrNull()?.id
        _uiState.update { it.copy(studioDraftSelectedBoneId = firstBoneId) }
        val label = when (category) {
            "BIRD" -> "Bird / Winged Rig"
            "QUADRUPED" -> "Quadruped Animal Rig"
            "CUSTOM_OBJECT" -> "Custom Object Rig (Tap stage to add bones)"
            "ASSET" -> "Reusable Custom Asset Rig"
            else -> "Human Auto-Rig (14 joints)"
        }
        showToast("Switched to $label")
    }

    fun addStudioBoneAtTap(worldPoint: Vec2) {
        val state = _uiState.value
        val rig = state.studioDraftRig
        val angles = InterpolationEngine.evaluateRigAngles(rig, state.studioDraftTestFrame)
        val effFlip = if (rig.viewAngle == CharacterViewAngle.SIDE_LEFT.name) !rig.flippedHorizontal else rig.flippedHorizontal
        val (updatedRig, newBone) = RigSolver.addCustomBoneAtPoint(
            rig = rig,
            parentBoneId = state.studioDraftSelectedBoneId,
            tapWorldPoint = worldPoint,
            angleOverrides = angles,
            flippedHorizontal = effFlip
        )
        _uiState.update {
            it.copy(
                studioDraftRig = updatedRig,
                studioDraftSelectedBoneId = newBone.id
            )
        }
        showToast("Added ${newBone.name} (${updatedRig.bones.size} bones)")
    }

    fun deleteStudioSelectedBone() {
        val state = _uiState.value
        val rig = state.studioDraftRig
        val targetId = state.studioDraftSelectedBoneId ?: return
        if (rig.bones.size <= 1) {
            showToast("Keep at least 1 bone in the rig")
            return
        }
        val target = rig.bones.firstOrNull { it.id == targetId } ?: return
        val remaining = rig.bones
            .filterNot { it.id == targetId }
            .map { b -> if (b.parentId == targetId) b.copy(parentId = target.parentId) else b }
        _uiState.update {
            it.copy(
                studioDraftRig = rig.copy(bones = remaining),
                studioDraftSelectedBoneId = target.parentId ?: remaining.firstOrNull()?.id
            )
        }
        showToast("Deleted bone \"${target.name}\"")
    }

    fun moveStudioSingleMesh(dx: Float, dy: Float) {
        updateStudioDraftRig { rig ->
            val inv = 1f / rig.scale.coerceAtLeast(0.1f)
            rig.copy(
                singleMeshOffsetX = (rig.singleMeshOffsetX + dx * inv).coerceIn(-600f, 600f),
                singleMeshOffsetY = (rig.singleMeshOffsetY + dy * inv).coerceIn(-600f, 600f)
            )
        }
    }

    fun scaleStudioSingleMesh(factor: Float) {
        updateStudioDraftRig { rig ->
            rig.copy(singleMeshScale = (rig.singleMeshScale * factor).coerceIn(0.05f, 8.0f))
        }
    }

    fun squishStudioSingleMesh(factorX: Float, factorY: Float) {
        updateStudioDraftRig { rig ->
            val nextX = (rig.baseScaleX * factorX).coerceIn(0.1f, 5.0f)
            val nextY = (rig.baseScaleY * factorY).coerceIn(0.1f, 5.0f)
            rig.copy(
                baseScaleX = nextX,
                baseScaleY = nextY,
                characterAppearance = rig.characterAppearance?.copy(baseScaleX = nextX, baseScaleY = nextY)
            )
        }
    }

    fun setStudioBaseScaleXY(scaleX: Float? = null, scaleY: Float? = null, lockAspect: Boolean = false) {
        updateStudioDraftRig { rig ->
            var nextX = rig.baseScaleX
            var nextY = rig.baseScaleY
            if (scaleX != null && scaleY != null) {
                nextX = scaleX.coerceIn(0.1f, 5.0f)
                nextY = scaleY.coerceIn(0.1f, 5.0f)
            } else if (scaleX != null) {
                val ratio = if (rig.baseScaleX > 0.01f) scaleX / rig.baseScaleX else 1f
                nextX = scaleX.coerceIn(0.1f, 5.0f)
                if (lockAspect) nextY = (rig.baseScaleY * ratio).coerceIn(0.1f, 5.0f)
            } else if (scaleY != null) {
                val ratio = if (rig.baseScaleY > 0.01f) scaleY / rig.baseScaleY else 1f
                nextY = scaleY.coerceIn(0.1f, 5.0f)
                if (lockAspect) nextX = (rig.baseScaleX * ratio).coerceIn(0.1f, 5.0f)
            }
            rig.copy(
                baseScaleX = nextX,
                baseScaleY = nextY,
                characterAppearance = rig.characterAppearance?.copy(baseScaleX = nextX, baseScaleY = nextY)
            )
        }
    }

    fun setStudioBoneBaseScaleXY(boneId: String, scaleX: Float? = null, scaleY: Float? = null, lockAspect: Boolean = false) {
        updateStudioDraftRig { rig ->
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id != boneId) b else {
                        var nx = b.baseScaleX
                        var ny = b.baseScaleY
                        if (scaleX != null && scaleY != null) {
                            nx = scaleX.coerceIn(0.1f, 5.0f)
                            ny = scaleY.coerceIn(0.1f, 5.0f)
                        } else if (scaleX != null) {
                            val ratio = if (b.baseScaleX > 0.01f) scaleX / b.baseScaleX else 1f
                            nx = scaleX.coerceIn(0.1f, 5.0f)
                            if (lockAspect) ny = (b.baseScaleY * ratio).coerceIn(0.1f, 5.0f)
                        } else if (scaleY != null) {
                            val ratio = if (b.baseScaleY > 0.01f) scaleY / b.baseScaleY else 1f
                            ny = scaleY.coerceIn(0.1f, 5.0f)
                            if (lockAspect) nx = (b.baseScaleX * ratio).coerceIn(0.1f, 5.0f)
                        }
                        b.copy(baseScaleX = nx, baseScaleY = ny)
                    }
                }
            )
        }
    }

    fun squishStudioBonePart(boneId: String, factorX: Float, factorY: Float) {
        updateStudioDraftRig { rig ->
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id == boneId) {
                        b.copy(
                            baseScaleX = (b.baseScaleX * factorX).coerceIn(0.1f, 5.0f),
                            baseScaleY = (b.baseScaleY * factorY).coerceIn(0.1f, 5.0f)
                        )
                    } else b
                }
            )
        }
    }

    fun scaleStudioBonePartUniform(boneId: String, factor: Float) {
        updateStudioDraftRig { rig ->
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id == boneId) {
                        b.copy(imageScale = (b.imageScale * factor).coerceIn(0.05f, 8.0f))
                    } else b
                }
            )
        }
    }

    fun moveStudioBonePartPivot(boneId: String, dxLocal: Float, dyLocal: Float) {
        updateStudioDraftRig { rig ->
            val inv = 1f / rig.scale.coerceAtLeast(0.1f)
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id == boneId) {
                        b.copy(
                            pivotOffsetX = (b.pivotOffsetX + dxLocal * inv).coerceIn(-300f, 300f),
                            pivotOffsetY = (b.pivotOffsetY + dyLocal * inv).coerceIn(-300f, 300f)
                        )
                    } else b
                }
            )
        }
    }

    fun applyStudioBonePartBehaviorPreset(boneId: String, preset: PartBehaviorPreset) {
        updateStudioDraftRig { rig ->
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id == boneId) RigSolver.applyPartBehaviorPreset(b, preset) else b
                }
            )
        }
        showToast("Part Behavior: ${preset.label} (${preset.subtitle})")
    }

    fun setStudioDraftBehaviorPreset(preset: CharacterBehaviorPreset) {
        updateStudioDraftRig { rig ->
            applyBehaviorPresetToRig(rig, preset)
        }
        showToast("Character Behavior: ${preset.label}")
    }

    fun adjustStudioDraftBoneZOrder(boneId: String, action: BoneZOrderAction) {
        var boneName = "Part"
        var nextZ = 0
        updateStudioDraftRig { rig ->
            val updatedBones = RigSolver.adjustBoneZOrder(rig.bones, boneId, action)
            val target = updatedBones.firstOrNull { it.id == boneId }
            boneName = target?.name ?: "Part"
            nextZ = target?.zOrder ?: 0
            rig.copy(bones = updatedBones)
        }
        selectStudioDraftBone(boneId)
        val label = when (action) {
            BoneZOrderAction.BRING_FORWARD -> "Forward (+1)"
            BoneZOrderAction.SEND_BACKWARD -> "Backward (-1)"
            BoneZOrderAction.BRING_TO_FRONT -> "Front (Top)"
            BoneZOrderAction.SEND_TO_BACK -> "Back (Bottom)"
        }
        showToast("$boneName → $label (Z:$nextZ)")
    }

    fun applyStudioAutoHumanLayerOrder() {
        updateStudioDraftRig { rig ->
            RigSolver.applyAutoHumanLayerOrder(rig)
        }
        showToast("Applied Auto Human Layer Order (Back → Front)!")
    }

    private fun applyBehaviorPresetToRig(rig: SkeletalRig, preset: CharacterBehaviorPreset): SkeletalRig {
        return when (preset) {
            CharacterBehaviorPreset.NORMAL_CALM -> rig.copy(
                behaviorPreset = preset.name,
                eyePack = EyePackStyle.AUTO_BLINK.name,
                eyebrowStyle = EyebrowStyle.NORMAL.name,
                mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                leftHandGesture = HandGesturePose.RELAXED.name,
                rightHandGesture = HandGesturePose.RELAXED.name,
                characterAppearance = rig.characterAppearance?.copy(
                    behaviorPreset = preset.name,
                    eyebrowStyle = EyebrowStyle.NORMAL.name,
                    postureSlouch = 0f
                )
            )
            CharacterBehaviorPreset.ANGRY_STRICT -> rig.copy(
                behaviorPreset = preset.name,
                eyePack = EyePackStyle.ANGRY.name,
                eyebrowStyle = EyebrowStyle.ANGRY.name,
                mouthPhoneme = MouthPhoneme.TALKING_LOOP.name,
                leftHandGesture = HandGesturePose.FIST.name,
                rightHandGesture = HandGesturePose.POINTING.name,
                characterAppearance = rig.characterAppearance?.copy(
                    behaviorPreset = preset.name,
                    eyebrowStyle = EyebrowStyle.ANGRY.name,
                    postureSlouch = 0.08f
                )
            )
            CharacterBehaviorPreset.HORROR_GHOSTLY -> rig.copy(
                behaviorPreset = preset.name,
                eyePack = EyePackStyle.SCARED_HORROR.name,
                eyebrowStyle = EyebrowStyle.RAISED.name,
                mouthPhoneme = MouthPhoneme.SCARED.name,
                leftHandGesture = HandGesturePose.OPEN_PALM.name,
                rightHandGesture = HandGesturePose.OPEN_PALM.name,
                characterAppearance = rig.characterAppearance?.copy(
                    behaviorPreset = preset.name,
                    eyebrowStyle = EyebrowStyle.RAISED.name,
                    postureSlouch = 0.14f
                )
            )
            CharacterBehaviorPreset.HAPPY_PLAYFUL -> rig.copy(
                behaviorPreset = preset.name,
                eyePack = EyePackStyle.HAPPY.name,
                eyebrowStyle = EyebrowStyle.RAISED.name,
                mouthPhoneme = MouthPhoneme.SMILE.name,
                leftHandGesture = HandGesturePose.OPEN_PALM.name,
                rightHandGesture = HandGesturePose.THUMBS_UP.name,
                characterAppearance = rig.characterAppearance?.copy(
                    behaviorPreset = preset.name,
                    eyebrowStyle = EyebrowStyle.RAISED.name,
                    postureSlouch = 0f
                )
            )
            CharacterBehaviorPreset.ELDERLY_WEAK -> rig.copy(
                behaviorPreset = preset.name,
                eyePack = EyePackStyle.AUTO_BLINK.name,
                eyebrowStyle = EyebrowStyle.WORRIED.name,
                mouthPhoneme = MouthPhoneme.REST.name,
                leftHandGesture = HandGesturePose.RELAXED.name,
                rightHandGesture = HandGesturePose.OPEN_PALM.name,
                characterAppearance = rig.characterAppearance?.copy(
                    behaviorPreset = preset.name,
                    eyebrowStyle = EyebrowStyle.WORRIED.name,
                    postureSlouch = 0.68f
                )
            )
        }
    }

    fun moveStudioFaceOverlay(dx: Float, dy: Float) {
        updateStudioDraftRig { rig ->
            val effFlip = if (rig.viewAngle == CharacterViewAngle.SIDE_LEFT.name) !rig.flippedHorizontal else rig.flippedHorizontal
            val flipSign = if (effFlip) -1f else 1f
            val inv = 1f / rig.scale.coerceAtLeast(0.1f)
            rig.copy(
                faceOverlayOffsetX = (rig.faceOverlayOffsetX + dx * inv * flipSign).coerceIn(-400f, 400f),
                faceOverlayOffsetY = (rig.faceOverlayOffsetY + dy * inv).coerceIn(-400f, 400f)
            )
        }
    }

    fun scaleStudioFaceOverlay(factor: Float) {
        updateStudioDraftRig { rig ->
            rig.copy(faceOverlayScale = (rig.faceOverlayScale * factor).coerceIn(0.2f, 4.0f))
        }
    }

    fun setStudioDraftViewAngle(angle: CharacterViewAngle) {
        updateStudioDraftRig { rig ->
            rig.copy(
                viewAngle = angle.name,
                characterAppearance = rig.characterAppearance?.copy(viewAngle = angle.name)
            )
        }
        showToast("Turnaround View: ${angle.label}")
    }

    fun setStudioDraftHandProp(isRightHand: Boolean, prop: HandPropKind) {
        updateStudioDraftRig { rig ->
            if (isRightHand) {
                rig.copy(rightHandProp = prop.name, rightHandCustomImagePath = null)
            } else {
                rig.copy(leftHandProp = prop.name, leftHandCustomImagePath = null)
            }
        }
        showToast("${if (isRightHand) "Right" else "Left"} Hand: ${prop.label}")
    }

    fun setStudioDraftHandCustomPng(isRightHand: Boolean, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val savedPath = copyPickedImageToLocalFile(uri, if (isRightHand) "hand_r" else "hand_l")
            withContext(Dispatchers.Main) {
                if (savedPath != null) {
                    updateStudioDraftRig { rig ->
                        if (isRightHand) {
                            rig.copy(rightHandCustomImagePath = savedPath, rightHandProp = HandPropKind.NONE.name)
                        } else {
                            rig.copy(leftHandCustomImagePath = savedPath, leftHandProp = HandPropKind.NONE.name)
                        }
                    }
                    showToast("Attached custom PNG to ${if (isRightHand) "Right" else "Left"} Hand!")
                } else {
                    showToast("Could not load hand PNG image")
                }
            }
        }
    }

    fun clearStudioDraftHandProp(isRightHand: Boolean) {
        updateStudioDraftRig { rig ->
            if (isRightHand) rig.copy(rightHandProp = HandPropKind.NONE.name, rightHandCustomImagePath = null)
            else rig.copy(leftHandProp = HandPropKind.NONE.name, leftHandCustomImagePath = null)
        }
    }

    fun moveStudioDraftRoot(x: Float, y: Float) {
        val state = _uiState.value
        val rig = state.studioDraftRig
        val frame = state.studioDraftTestFrame
        val nextPoses = if (rig.autoWalkWhenDragged) {
            rig.poseKeyframes + (frame.toString() to RigSolver.computeAutoWalkPose(x))
        } else {
            rig.poseKeyframes
        }
        _uiState.update {
            it.copy(
                studioDraftRig = rig.copy(
                    rootX = x.coerceIn(180f, 1100f),
                    rootY = y.coerceIn(140f, 640f),
                    poseKeyframes = nextPoses
                )
            )
        }
    }

    fun applyStudioDraftPose(poseName: String) {
        val frameKey = _uiState.value.studioDraftTestFrame.toString()
        val pose = RigSolver.presetPoseAngles(poseName)
        updateStudioDraftRig { rig ->
            rig.copy(poseKeyframes = rig.poseKeyframes + (frameKey to pose))
        }
        showToast("Tested $poseName pose")
    }

    fun bindPickedImageToDraftBone(boneId: String, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val savedPath = copyPickedImageToLocalFile(uri, "part_${boneId}")
            if (savedPath != null) {
                withContext(Dispatchers.Main) {
                    updateStudioDraftRig { rig ->
                        rig.copy(
                            bones = rig.bones.map { b ->
                                if (b.id == boneId) b.copy(boundImagePath = savedPath) else b
                            }
                        )
                    }
                    showToast("Attached PNG to bone!")
                }
            } else {
                withContext(Dispatchers.Main) { showToast("Could not load PNG image") }
            }
        }
    }

    fun clearDraftBoneImage(boneId: String) {
        updateStudioDraftRig { rig ->
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id == boneId) b.copy(boundImagePath = null) else b
                }
            )
        }
    }

    fun bindPickedImageToDraftSingleMesh(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val savedPath = copyPickedImageToLocalFile(uri, "mesh_char")
            if (savedPath != null) {
                withContext(Dispatchers.Main) {
                    updateStudioDraftRig { rig ->
                        rig.copy(singleMeshImagePath = savedPath)
                    }
                    showToast("Bound single-image 2D Mesh!")
                }
            } else {
                withContext(Dispatchers.Main) { showToast("Could not import character PNG") }
            }
        }
    }

    fun clearDraftSingleMesh() {
        updateStudioDraftRig { it.copy(singleMeshImagePath = null) }
    }

    private fun copyPickedImageToLocalFile(uri: Uri, prefix: String): String? {
        val dir = File(getApplication<Application>().filesDir, "project_assets").apply { mkdirs() }
        val outFile = File(dir, "${prefix}_${System.currentTimeMillis()}.png")
        return try {
            val resolver = getApplication<Application>().contentResolver
            val inputStream = runCatching { resolver.openInputStream(uri) }.getOrNull()
                ?: runCatching { resolver.openAssetFileDescriptor(uri, "r")?.createInputStream() }.getOrNull()
                ?: return null
            inputStream.use { input ->
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
            }
            if (!outFile.exists() || outFile.length() <= 0L) {
                runCatching { outFile.delete() }
                return null
            }
            // Verify the copied file is a valid decodable image before accepting it
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(outFile.absolutePath, boundsOpts)
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) {
                runCatching { outFile.delete() }
                return null
            }
            outFile.absolutePath
        } catch (_: Throwable) {
            runCatching { if (outFile.exists()) outFile.delete() }
            null
        }
    }

    fun saveStudioDraftToMyCharacters(alsoImportToScene: Boolean = false) {
        val draft = _uiState.value.studioDraftRig
        val packageToSave = draft.copy(
            id = if (draft.id.isBlank()) UUID.randomUUID().toString() else draft.id,
            name = draft.name.ifBlank { "My Character" }
        )
        viewModelScope.launch {
            repository.saveRiggedCharacterToLibrary(packageToSave)
            if (_uiState.value.activeProject != null) {
                mutateProject(recordUndo = false) { p ->
                    val cleaned = p.savedRigs.filterNot { it.id == packageToSave.id }
                    p.copy(savedRigs = cleaned + packageToSave)
                }
            }
            if (alsoImportToScene && _uiState.value.activeProject != null) {
                importRiggedCharacterIntoScene(packageToSave)
                closeCharacterRigStudio()
                showToast("Saved & imported \"${packageToSave.name}\" to Scene!")
            } else {
                showToast("Saved \"${packageToSave.name}\" to My Characters!")
            }
        }
    }

    fun deleteMyCharacter(rigId: String) {
        viewModelScope.launch {
            repository.deleteRiggedCharacterFromLibrary(rigId)
            if (_uiState.value.activeProject != null) {
                mutateProject(recordUndo = false) { p ->
                    p.copy(savedRigs = p.savedRigs.filterNot { it.id == rigId })
                }
            }
            showToast("Deleted character from saved library")
        }
    }

    fun saveStudioDraftAsCustomAsset(alsoInsertToScene: Boolean = false) {
        val draft = _uiState.value.studioDraftRig
        val assetToSave = draft.copy(
            id = if (draft.id.isBlank()) UUID.randomUUID().toString() else draft.id,
            name = draft.name.ifBlank { "Custom Asset" },
            rigCategory = "ASSET"
        )
        viewModelScope.launch {
            repository.saveCustomAssetToLibrary(assetToSave)
            if (alsoInsertToScene && _uiState.value.activeProject != null) {
                insertCustomAssetIntoScene(assetToSave)
                closeCharacterRigStudio()
                showToast("Saved & inserted Custom Asset \"${assetToSave.name}\"!")
            } else {
                showToast("Saved \"${assetToSave.name}\" to My Custom Assets!")
            }
        }
    }

    fun deleteCustomAsset(assetId: String) {
        viewModelScope.launch {
            repository.deleteCustomAssetFromLibrary(assetId)
            showToast("Deleted custom asset from library")
        }
    }

    fun insertCustomAssetIntoScene(asset: SkeletalRig) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val count = scene.layers.count { it.type == LayerType.RIG.name }
        val offsetX = ((count % 4) - 1.5f) * 90f
        val placed = asset.copy(
            id = UUID.randomUUID().toString(),
            rootX = (proj.width * 0.5f + offsetX).coerceIn(140f, proj.width - 140f),
            rootY = proj.height * 0.58f
        )
        val newLayer = AnimationLayer(
            name = asset.name.ifBlank { "Custom Asset" },
            type = LayerType.RIG.name,
            rig = placed
        )
        mutateActiveScene(recordUndo = true) { s -> s.copy(layers = s.layers + newLayer) }
        _uiState.update {
            it.copy(
                selectedLayerId = newLayer.id,
                selectedBoneId = placed.bones.firstOrNull()?.id,
                selectedTrackKind = TrackSelectionKind.LAYER,
                activeTool = EditorTool.RIG_EDIT
            )
        }
        showToast("Added Custom Asset \"${placed.name}\" to Scene")
    }

    fun deleteLocalAssetWithFile(asset: LocalAssetEntity) {
        viewModelScope.launch {
            repository.deleteLocalAsset(asset.id)
            withContext(Dispatchers.IO) {
                val path = asset.filePath
                if (path.isNotBlank()) {
                    runCatching {
                        val file = File(path)
                        val appDir = getApplication<Application>().filesDir.canonicalPath
                        if (file.exists() && file.canonicalPath.startsWith(appDir)) {
                            file.delete()
                        }
                    }
                }
            }
            showToast("Deleted asset \"${asset.name}\"")
        }
    }

    fun deleteProjectSavedCharacter(charId: String) {
        mutateProject { p ->
            p.copy(savedCharacters = p.savedCharacters.filterNot { it.id == charId })
        }
        showToast("Deleted saved character")
    }

    fun deleteProjectSavedRig(rigId: String) {
        mutateProject { p ->
            p.copy(savedRigs = p.savedRigs.filterNot { it.id == rigId })
        }
        viewModelScope.launch {
            repository.deleteRiggedCharacterFromLibrary(rigId)
        }
        showToast("Deleted saved rig")
    }

    // ─── Project Management ─────────────────────────────────────────

    fun createNewProject(
        name: String,
        width: Int,
        height: Int,
        fps: Int,
        template: StoryboardTemplate
    ) {
        val proj = ProceduralSmartTools.createProjectFromTemplate(name, width, height, fps, template)
        openProjectDirect(proj)
        viewModelScope.launch {
            repository.saveProject(proj, isRecovery = false)
            showToast("Created \"${proj.name}\"")
        }
    }

    fun openProject(projectId: String) {
        viewModelScope.launch {
            val loaded = repository.loadProject(projectId)
            if (loaded != null) {
                openProjectDirect(loaded)
            } else {
                showToast("Could not load project")
            }
        }
    }

    fun recoverAutosave(recoveryId: String) {
        viewModelScope.launch {
            val loaded = repository.loadProject(recoveryId)
            if (loaded != null) {
                openProjectDirect(loaded)
                repository.saveProject(loaded, isRecovery = false)
                repository.clearRecovery()
                showToast("Recovered \"${loaded.name}\"")
            }
        }
    }

    fun dismissRecovery() {
        viewModelScope.launch { repository.clearRecovery() }
    }

    private fun openProjectDirect(project: AnimationProject) {
        stopPlayback()
        undoStack.clear()
        redoStack.clear()
        val scene = project.scenes.firstOrNull { it.id == project.activeSceneId } ?: project.scenes.firstOrNull()
        val preferredLayer = scene?.layers?.firstOrNull { it.rig != null }
            ?: scene?.layers?.lastOrNull { it.type == LayerType.DRAWING.name }
            ?: scene?.layers?.lastOrNull()
        val initialTool = if (preferredLayer?.rig != null) EditorTool.RIG_EDIT else EditorTool.BRUSH
        _uiState.update {
            it.copy(
                destination = StudioDestination.EDITOR,
                activeProject = project,
                currentFrame = 0,
                selectedLayerId = preferredLayer?.id,
                selectedBoneId = null,
                activeTool = initialTool,
                paintDrawerOpen = false,
                canUndo = false,
                canRedo = false,
                canvasZoom = 1f,
                canvasPanX = 0f,
                canvasPanY = 0f
            )
        }
    }

    fun closeProjectToHub() {
        stopPlayback()
        val current = _uiState.value.activeProject
        if (current != null) {
            viewModelScope.launch {
                repository.saveProject(current, isRecovery = false)
                repository.clearRecovery()
            }
        }
        _uiState.update {
            it.copy(
                destination = StudioDestination.HUB,
                activeProject = null,
                isPlaying = false,
                paintDrawerOpen = false
            )
        }
    }

    fun saveProjectNow() {
        val current = _uiState.value.activeProject ?: return
        viewModelScope.launch {
            repository.saveProject(current, isRecovery = false)
            repository.clearRecovery()
            showToast("Saved \"${current.name}\" locally")
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            showToast("Project deleted")
        }
    }

    fun renameActiveProject(newName: String) {
        if (newName.isBlank()) return
        mutateProject { it.copy(name = newName.trim()) }
    }

    fun importProjectFromUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val (json, msg) = exportEngine.importProjectArchiveFromUri(uri, projectAssetsDir)
            if (json != null) {
                val parsed = repository.importProjectFromJson(json)
                if (parsed != null) {
                    val imported = parsed.copy(id = UUID.randomUUID().toString(), updatedAt = System.currentTimeMillis())
                    repository.saveProject(imported, isRecovery = false)
                    withContext(Dispatchers.Main) {
                        openProjectDirect(imported)
                        showToast("$msg: \"${imported.name}\"")
                    }
                    return@launch
                }
            }
            withContext(Dispatchers.Main) { showToast(msg) }
        }
    }

    fun exportProjectJsonToUri(uri: Uri) {
        exportProjectArchiveToUri(projectId = null, targetUri = uri)
    }

    fun exportProjectArchiveToUri(projectId: String? = null, targetUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val proj = if (projectId != null) {
                repository.loadProject(projectId)
            } else {
                _uiState.value.activeProject
            } ?: return@launch
            val json = repository.exportProjectToJson(proj)
            val (_, msg) = exportEngine.exportProjectArchiveToUri(proj, json, targetUri)
            withContext(Dispatchers.Main) {
                showToast(msg)
            }
        }
    }

    fun exportDraftRigToUri(targetUri: Uri) {
        val draft = _uiState.value.studioDraftRig
        viewModelScope.launch(Dispatchers.IO) {
            val json = repository.exportRigToJson(draft)
            val (_, msg) = exportEngine.exportRigArchiveToUri(draft, json, targetUri)
            withContext(Dispatchers.Main) {
                showToast(msg)
            }
        }
    }

    fun importDraftRigFromUri(sourceUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val (json, msg) = exportEngine.importRigArchiveFromUri(sourceUri, projectAssetsDir)
            val rig = json?.let { repository.importRigFromJson(it) }
            withContext(Dispatchers.Main) {
                if (rig != null) {
                    _uiState.update { it.copy(studioDraftRig = rig, studioDraftSelectedBoneId = rig.bones.firstOrNull()?.id) }
                    showToast("Loaded rig \"${rig.name}\"")
                } else {
                    showToast(if (json == null) msg else "Invalid rig backup file")
                }
            }
        }
    }

    // ─── Core Project Mutation + Undo/Redo + Autosave ───────────────

    private fun mutateProject(recordUndo: Boolean = true, transform: (AnimationProject) -> AnimationProject) {
        val current = _uiState.value.activeProject ?: return
        if (recordUndo) {
            if (undoStack.size >= 35) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
        }
        val next = transform(current).copy(updatedAt = System.currentTimeMillis())
        val scene = next.scenes.firstOrNull { it.id == next.activeSceneId } ?: next.scenes.firstOrNull()
        val validLayerId = scene?.layers?.firstOrNull { it.id == _uiState.value.selectedLayerId }?.id
            ?: scene?.layers?.firstOrNull()?.id
        val clampedFrame = _uiState.value.currentFrame.coerceIn(0, ((scene?.durationFrames ?: 1) - 1).coerceAtLeast(0))

        _uiState.update {
            it.copy(
                activeProject = next,
                selectedLayerId = validLayerId,
                currentFrame = clampedFrame,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty()
            )
        }
        scheduleAutosave(next)
    }

    private fun mutateActiveScene(recordUndo: Boolean = true, transform: (AnimationScene) -> AnimationScene) {
        mutateProject(recordUndo) { proj ->
            proj.copy(scenes = proj.scenes.map { s -> if (s.id == proj.activeSceneId) transform(s) else s })
        }
    }

    private fun mutateSelectedLayer(recordUndo: Boolean = true, transform: (AnimationLayer) -> AnimationLayer) {
        val layerId = _uiState.value.selectedLayer?.id ?: return
        mutateActiveScene(recordUndo) { scene ->
            scene.copy(layers = scene.layers.map { l -> if (l.id == layerId) transform(l) else l })
        }
    }

    private fun scheduleAutosave(project: AnimationProject) {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(1500)
            repository.saveProject(project, isRecovery = true)
            repository.saveProject(project, isRecovery = false)
        }
    }

    fun undo() {
        val current = _uiState.value.activeProject ?: return
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(current)
        _uiState.update {
            it.copy(activeProject = prev, canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty())
        }
        scheduleAutosave(prev)
    }

    fun redo() {
        val current = _uiState.value.activeProject ?: return
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(current)
        _uiState.update {
            it.copy(activeProject = next, canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty())
        }
        scheduleAutosave(next)
    }

    // ─── Tool & Viewport Controls ───────────────────────────────────

    fun selectTool(tool: EditorTool) {
        if (tool == EditorTool.RIG_EDIT) {
            val scene = _uiState.value.activeScene
            val currentHasRig = _uiState.value.selectedLayer?.rig != null
            if (!currentHasRig && scene != null) {
                val rigLayer = scene.layers.lastOrNull { it.rig != null && it.visible }
                if (rigLayer != null) {
                    _uiState.update { it.copy(activeTool = tool, selectedLayerId = rigLayer.id) }
                    showToast("Selected Rig: ${rigLayer.name} — drag any joint")
                    return
                } else {
                    showToast("No rig layer yet — add one in Rigging")
                }
            }
        }
        _uiState.update { it.copy(activeTool = tool) }
    }
    fun setPrimaryColor(argb: Long) = _uiState.update { it.copy(primaryColorArgb = argb) }
    fun setGradientColor(argb: Long) = _uiState.update { it.copy(gradientColorArgb = argb) }
    fun toggleGradient(enabled: Boolean) = _uiState.update { it.copy(useGradient = enabled) }
    fun setBrushSize(size: Float) = _uiState.update { it.copy(brushSize = size.coerceIn(1f, 80f)) }
    fun setBrushOpacity(opacity: Float) = _uiState.update { it.copy(brushOpacity = opacity.coerceIn(0.05f, 1f)) }
    fun toggleFillShapes(fill: Boolean) = _uiState.update { it.copy(fillShapes = fill) }
    fun setPolygonSides(sides: Int) = _uiState.update { it.copy(polygonSides = sides.coerceIn(3, 12)) }
    fun setActiveEasing(easing: EasingType) = _uiState.update { it.copy(activeEasing = easing) }
    fun setInspectorTab(tab: InspectorTab) = _uiState.update { it.copy(activeInspectorTab = tab) }
    fun toggleOnionSkin() = _uiState.update { it.copy(onionSkinEnabled = !it.onionSkinEnabled) }
    fun toggleGhostFrames() = _uiState.update { it.copy(ghostFramesEnabled = !it.ghostFramesEnabled) }
    fun toggleRigOverlay() = _uiState.update { it.copy(showRigOverlay = !it.showRigOverlay) }
    fun toggleMotionPaths() = _uiState.update { it.copy(showMotionPaths = !it.showMotionPaths) }
    fun toggleLooping() = _uiState.update { it.copy(isLooping = !it.isLooping) }
    fun updateCanvasViewport(zoom: Float, panX: Float, panY: Float) = _uiState.update {
        it.copy(canvasZoom = zoom.coerceIn(0.4f, 4.5f), canvasPanX = panX, canvasPanY = panY)
    }
    fun resetCanvasViewport() = _uiState.update { it.copy(canvasZoom = 1f, canvasPanX = 0f, canvasPanY = 0f) }

    // ─── Drawing & Vector Operations ────────────────────────────────

    private fun ensureDrawableLayerSelected(): AnimationLayer? {
        val state = _uiState.value
        val selected = state.selectedLayer
        if (selected != null && !selected.locked) return selected
        return null
    }

    fun commitStroke(stroke: DrawStroke) {
        val layer = ensureDrawableLayerSelected() ?: run {
            showToast("Layer is locked")
            return
        }
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val currentContent = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            val updated = if (stroke.tool == EditorTool.ERASER.name) {
                val eraserR = (stroke.strokeWidth * 1.8f).coerceAtLeast(18f)
                val remainingStrokes = currentContent.strokes.filterNot { existing ->
                    existing.points.any { p ->
                        stroke.points.any { e -> kotlin.math.hypot(p.x - e.x, p.y - e.y) < eraserR }
                    }
                }
                val remainingShapes = currentContent.shapes.filterNot { s ->
                    val minX = kotlin.math.min(s.startX, s.endX) - eraserR
                    val maxX = kotlin.math.max(s.startX, s.endX) + eraserR
                    val minY = kotlin.math.min(s.startY, s.endY) - eraserR
                    val maxY = kotlin.math.max(s.startY, s.endY) + eraserR
                    stroke.points.any { e -> e.x in minX..maxX && e.y in minY..maxY }
                }
                val remainingTexts = currentContent.texts.filterNot { t ->
                    stroke.points.any { e -> kotlin.math.hypot(t.x - e.x, t.y - e.y) < eraserR * 2.5f }
                }
                currentContent.copy(
                    strokes = remainingStrokes,
                    shapes = remainingShapes,
                    texts = remainingTexts
                )
            } else {
                currentContent.copy(strokes = currentContent.strokes + stroke)
            }
            l.copy(frames = l.frames + (frameKey to updated))
        }
    }

    fun commitShape(shape: VectorShape) {
        ensureDrawableLayerSelected() ?: return
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val currentContent = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frameKey to currentContent.copy(shapes = currentContent.shapes + shape)))
        }
    }

    fun applyPaintBucket(canvasX: Float, canvasY: Float) {
        ensureDrawableLayerSelected() ?: return
        val state = _uiState.value
        val frameKey = state.currentFrame.toString()
        val fillHex = state.primaryColorArgb
        val gradHex = if (state.useGradient) state.gradientColorArgb else null

        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, state.currentFrame, holdPrevious = true)
                ?: FrameContent()
            // Check if tap hit an existing shape; if so recolor its fill, else add a fill backdrop rectangle
            val hitIdx = content.shapes.indexOfLast { s ->
                val minX = kotlin.math.min(s.startX, s.endX)
                val maxX = kotlin.math.max(s.startX, s.endX)
                val minY = kotlin.math.min(s.startY, s.endY)
                val maxY = kotlin.math.max(s.startY, s.endY)
                canvasX in minX..maxX && canvasY in minY..maxY
            }
            val newShapes = if (hitIdx >= 0) {
                content.shapes.mapIndexed { idx, s ->
                    if (idx == hitIdx) s.copy(fillColorArgb = fillHex, gradientEndArgb = gradHex) else s
                }
            } else {
                val p = state.activeProject
                val backdrop = VectorShape(
                    kind = ShapeKind.FILL_BACKDROP.name,
                    startX = 0f,
                    startY = 0f,
                    endX = (p?.width ?: 1280).toFloat(),
                    endY = (p?.height ?: 720).toFloat(),
                    strokeColorArgb = fillHex,
                    fillColorArgb = fillHex,
                    gradientEndArgb = gradHex,
                    strokeWidth = 0f
                )
                listOf(backdrop) + content.shapes
            }
            l.copy(frames = l.frames + (frameKey to content.copy(shapes = newShapes)))
        }
    }

    fun pickColorAt(canvasX: Float, canvasY: Float) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val bmp = SceneRenderer.renderSceneToBitmap(
            scene, _uiState.value.currentFrame, 320, 180, proj.width, proj.height
        )
        val px = ((canvasX / proj.width) * 320f).toInt().coerceIn(0, 319)
        val py = ((canvasY / proj.height) * 180f).toInt().coerceIn(0, 179)
        val pixel = bmp.getPixel(px, py)
        bmp.recycle()
        val argb = (pixel.toLong() and 0xFFFFFFFFL) or 0xFF000000L
        _uiState.update { it.copy(primaryColorArgb = argb, activeTool = EditorTool.BRUSH) }
        showToast("Picked color")
    }

    fun addTextItem(
        text: String,
        x: Float,
        y: Float,
        fontSize: Float = 68f,
        inAnimation: TextInAnimation = TextInAnimation.POP_BOUNCE,
        loopAnimation: TextLoopAnimation = TextLoopAnimation.NONE
    ) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val scene = _uiState.value.activeScene ?: return
        val start = _uiState.value.currentFrame
        val end = (scene.durationFrames - 1).coerceAtLeast(start)
        val item = CanvasTextItem(
            text = clean,
            x = x,
            y = y,
            fontSize = fontSize,
            colorArgb = _uiState.value.primaryColorArgb,
            gradientEndArgb = if (_uiState.value.useGradient) _uiState.value.gradientColorArgb else null,
            startFrame = start,
            endFrame = end,
            inAnimation = inAnimation.name,
            loopAnimation = loopAnimation.name,
            outAnimation = TextOutAnimation.FADE_OUT.name
        )
        mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts + item) }
        _uiState.update { it.copy(selectedTextId = item.id, activeInspectorTab = InspectorTab.TEXT) }
        showToast("Added animated text — drag on stage or edit in Text tab!")
    }

    fun addAnimatedTextPreset(presetKey: String) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val cx = proj.width * 0.5f
        val cy = proj.height * 0.28f
        val start = _uiState.value.currentFrame
        val end = (scene.durationFrames - 1).coerceAtLeast(start)

        val item = when (presetKey) {
            "YOUTUBE_TITLE" -> CanvasTextItem(
                text = "SUBSCRIBE!",
                x = cx, y = cy,
                fontSize = 76f,
                colorArgb = 0xFFFFFFFFL,
                strokeColorArgb = 0xFF7F1D1DL,
                strokeWidth = 8f,
                fontStyle = TextFontStyle.BOLD_CARTOON.name,
                boxStyle = TextBoxStyle.YOUTUBE_PILL.name,
                boxColorArgb = 0xEEEF4444L,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.POP_BOUNCE.name,
                inDurationFrames = 12,
                loopAnimation = TextLoopAnimation.PULSE.name,
                outAnimation = TextOutAnimation.POP_OUT.name
            )
            "HORROR_GLITCH" -> CanvasTextItem(
                text = "DON'T LOOK BACK...",
                x = cx, y = cy,
                fontSize = 66f,
                colorArgb = 0xFFFF3B5CL,
                gradientEndArgb = 0xFF991B1BL,
                strokeColorArgb = 0xFF000000L,
                strokeWidth = 9f,
                glowEnabled = true,
                fontStyle = TextFontStyle.SERIF_HORROR.name,
                boxStyle = TextBoxStyle.HORROR_BLOOD.name,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.ZOOM_SLAM.name,
                inDurationFrames = 10,
                loopAnimation = TextLoopAnimation.SHAKE_HORROR.name,
                outAnimation = TextOutAnimation.FADE_OUT.name
            )
            "COMIC_POW" -> CanvasTextItem(
                text = "BOOM!!",
                x = cx, y = proj.height * 0.36f,
                fontSize = 94f,
                colorArgb = 0xFFFFE066L,
                gradientEndArgb = 0xFFFF6B35L,
                strokeColorArgb = 0xFF0F172AL,
                strokeWidth = 14f,
                rotationDeg = -7f,
                fontStyle = TextFontStyle.COMIC_ITALIC.name,
                boxStyle = TextBoxStyle.NONE.name,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.SPIN_POP.name,
                inDurationFrames = 10,
                loopAnimation = TextLoopAnimation.BOUNCE.name,
                outAnimation = TextOutAnimation.ZOOM_OUT.name
            )
            "GHOST_FLOAT" -> CanvasTextItem(
                text = "WHO IS THERE?!",
                x = cx, y = cy,
                fontSize = 64f,
                colorArgb = 0xFFBAE6FDL,
                gradientEndArgb = 0xFF38BDF8L,
                strokeColorArgb = 0xFF082F49L,
                strokeWidth = 8f,
                glowEnabled = true,
                opacity = 0.85f,
                fontStyle = TextFontStyle.SERIF_HORROR.name,
                boxStyle = TextBoxStyle.NONE.name,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.FADE_IN.name,
                inDurationFrames = 16,
                loopAnimation = TextLoopAnimation.FLOAT.name,
                outAnimation = TextOutAnimation.FADE_OUT.name
            )
            "SPEECH_BUBBLE" -> CanvasTextItem(
                text = "Wait for me!",
                x = cx, y = proj.height * 0.25f,
                fontSize = 52f,
                colorArgb = 0xFF0F172AL,
                strokeColorArgb = 0xFFFFFFFFL,
                strokeWidth = 0f,
                shadowEnabled = false,
                fontStyle = TextFontStyle.BOLD_CARTOON.name,
                boxStyle = TextBoxStyle.SPEECH_BUBBLE.name,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.POP_BOUNCE.name,
                inDurationFrames = 9,
                loopAnimation = TextLoopAnimation.NONE.name,
                outAnimation = TextOutAnimation.POP_OUT.name
            )
            "CYBER_GLITCH" -> CanvasTextItem(
                text = "EPISODE 01",
                x = cx, y = cy,
                fontSize = 72f,
                colorArgb = 0xFF2DD4BFL,
                gradientEndArgb = 0xFFA78BFAL,
                strokeColorArgb = 0xFF020617L,
                strokeWidth = 9f,
                glowEnabled = true,
                fontStyle = TextFontStyle.MONO_TECH.name,
                boxStyle = TextBoxStyle.OUTLINE_GLOW.name,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.SLIDE_LEFT.name,
                inDurationFrames = 12,
                loopAnimation = TextLoopAnimation.GLITCH.name,
                outAnimation = TextOutAnimation.FADE_OUT.name
            )
            else -> CanvasTextItem(
                text = "Once upon a midnight...",
                x = cx, y = proj.height * 0.82f,
                fontSize = 54f,
                colorArgb = 0xFFFFFFFFL,
                strokeColorArgb = 0xFF0F172AL,
                strokeWidth = 7f,
                fontStyle = TextFontStyle.CLASSIC_CLEAN.name,
                boxStyle = TextBoxStyle.COMIC_BANNER.name,
                startFrame = start, endFrame = end,
                inAnimation = TextInAnimation.TYPEWRITER.name,
                inDurationFrames = 26,
                loopAnimation = TextLoopAnimation.NONE.name,
                outAnimation = TextOutAnimation.FADE_OUT.name
            )
        }
        mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts + item) }
        _uiState.update { it.copy(selectedTextId = item.id, activeInspectorTab = InspectorTab.TEXT) }
        showToast("Added \"${item.text}\" — drag on stage or customize!")
    }

    fun selectText(textId: String?) {
        _uiState.update { state ->
            state.copy(
                selectedTextId = textId,
                selectedTrackKind = if (textId != null) TrackSelectionKind.TEXT else state.selectedTrackKind
            )
        }
    }

    fun updateAnimatedText(
        textId: String,
        recordUndo: Boolean = true,
        transform: (CanvasTextItem) -> CanvasTextItem
    ) {
        mutateActiveScene(recordUndo = recordUndo) { s ->
            s.copy(animatedTexts = s.animatedTexts.map { if (it.id == textId) transform(it) else it })
        }
    }

    fun moveAnimatedText(textId: String, x: Float, y: Float, recordUndo: Boolean) {
        updateAnimatedText(textId, recordUndo = recordUndo) { it.copy(x = x, y = y) }
    }

    fun duplicateAnimatedText(textId: String) {
        val original = _uiState.value.activeScene?.animatedTexts?.firstOrNull { it.id == textId } ?: return
        val copy = original.copy(
            id = UUID.randomUUID().toString(),
            x = original.x + 36f,
            y = original.y + 44f
        )
        mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts + copy) }
        _uiState.update { it.copy(selectedTextId = copy.id) }
        showToast("Duplicated text")
    }

    fun deleteAnimatedText(textId: String) {
        mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts.filterNot { it.id == textId }) }
        _uiState.update { st ->
            st.copy(selectedTextId = if (st.selectedTextId == textId) null else st.selectedTextId)
        }
        showToast("Deleted text")
    }

    fun setSelectedTextStartToCurrentFrame() {
        val text = _uiState.value.selectedText ?: return
        val f = _uiState.value.currentFrame
        updateAnimatedText(text.id) {
            it.copy(startFrame = f, endFrame = it.endFrame.coerceAtLeast(f))
        }
        showToast("Text starts at F${f + 1}")
    }

    fun setSelectedTextEndToCurrentFrame() {
        val text = _uiState.value.selectedText ?: return
        val f = _uiState.value.currentFrame
        updateAnimatedText(text.id) {
            it.copy(startFrame = it.startFrame.coerceAtMost(f), endFrame = f)
        }
        showToast("Text ends at F${f + 1}")
    }

    fun insertProceduralProp(kind: ProceduralPropKind) {
        val proj = _uiState.value.activeProject ?: return
        val (shapes, strokes) = ProceduralSmartTools.generatePropShapes(kind, proj.width * 0.5f, proj.height * 0.5f)
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(
                frames = l.frames + (frameKey to content.copy(
                    shapes = content.shapes + shapes,
                    strokes = content.strokes + strokes
                ))
            )
        }
        showToast("Inserted ${kind.label}")
    }

    fun importImageFromUri(uri: Uri) {
        if (_uiState.value.activeProject == null) return
        viewModelScope.launch(Dispatchers.IO) {
            val savedPath = copyPickedImageToLocalFile(uri, "img")
            if (savedPath != null) {
                val savedFile = File(savedPath)
                repository.saveLocalAsset(
                    LocalAssetEntity(
                        id = UUID.randomUUID().toString(),
                        name = savedFile.nameWithoutExtension,
                        category = "IMAGE",
                        filePath = savedPath,
                        jsonPayload = null,
                        createdAt = System.currentTimeMillis()
                    )
                )
                withContext(Dispatchers.Main) {
                    insertLocalImageFile(savedPath, "Imported Image")
                }
            } else {
                withContext(Dispatchers.Main) {
                    showToast("Could not read selected image file")
                }
            }
        }
    }

    fun insertLocalImageFile(filePath: String, name: String) {
        val proj = _uiState.value.activeProject ?: return
        val frameKey = _uiState.value.currentFrame.toString()
        val item = ImportedImageItem(
            name = name,
            filePath = filePath,
            x = proj.width * 0.5f,
            y = proj.height * 0.5f,
            width = proj.width * 0.35f,
            height = proj.height * 0.35f
        )
        mutateSelectedLayer { l ->
            val content = l.frames[frameKey]
                ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frameKey to content.copy(images = content.images + item)))
        }
        showToast("Added image to frame")
    }

    fun importSvgFromUri(uri: Uri) {
        val proj = _uiState.value.activeProject ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val resolver = getApplication<Application>().contentResolver
            val readResult: Pair<String?, String?> = runCatching {
                val input = runCatching { resolver.openInputStream(uri) }.getOrNull()
                    ?: runCatching { resolver.openAssetFileDescriptor(uri, "r")?.createInputStream() }.getOrNull()
                    ?: return@runCatching null to "Could not read selected SVG file"
                val maxSvgBytes = 4 * 1024 * 1024
                val buffer = ByteArray(8192)
                val out = java.io.ByteArrayOutputStream()
                var total = 0
                input.use { stream ->
                    while (true) {
                        val n = stream.read(buffer)
                        if (n <= 0) break
                        total += n
                        if (total > maxSvgBytes) {
                            return@runCatching null to "SVG file is too large (max 4 MB)"
                        }
                        out.write(buffer, 0, n)
                    }
                }
                out.toString(Charsets.UTF_8.name()) to null
            }.getOrElse { null to "Could not read selected SVG file" }

            val svgText = readResult.first
            if (svgText == null) {
                withContext(Dispatchers.Main) {
                    showToast(readResult.second ?: "Could not read selected SVG file")
                }
                return@launch
            }
            val parsedShapes = SceneRenderer.parseSimpleSvgShapes(svgText, proj.width.toFloat(), proj.height.toFloat())
            withContext(Dispatchers.Main) {
                if (parsedShapes.isNotEmpty()) {
                    val frameKey = _uiState.value.currentFrame.toString()
                    mutateSelectedLayer { l ->
                        val content = l.frames[frameKey]
                            ?: InterpolationEngine.resolveFrameContent(l, _uiState.value.currentFrame, holdPrevious = true)
                            ?: FrameContent()
                        l.copy(frames = l.frames + (frameKey to content.copy(shapes = content.shapes + parsedShapes)))
                    }
                    showToast("Imported ${parsedShapes.size} SVG vector shapes")
                } else {
                    showToast("No basic SVG shapes found")
                }
            }
        }
    }

    fun nudgeSelectedLayerTransform(dx: Float, dy: Float, dRot: Float = 0f, dScale: Float = 0f, recordUndo: Boolean = false) {
        val frame = _uiState.value.currentFrame
        val scene = _uiState.value.activeScene ?: return
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val cur = InterpolationEngine.evaluateLayerTransform(l, frame, scene.durationFrames)
            val kf = TransformKeyframe(
                frame = frame,
                x = cur.x + dx,
                y = cur.y + dy,
                rotationDeg = cur.rotationDeg + dRot,
                scaleX = (cur.scaleX + dScale).coerceIn(0.1f, 10.0f),
                scaleY = (cur.scaleY + dScale).coerceIn(0.1f, 10.0f),
                opacity = cur.opacity,
                easing = _uiState.value.activeEasing.name
            )
            val updatedKfs = l.keyframes.filterNot { it.frame == frame } + kf
            l.copy(keyframes = updatedKfs.sortedBy { it.frame })
        }
    }

    /**
     * Direct on-canvas bounding box touch handles: drag body to move, drag 4 corners to scale (0.1x..10.0x),
     * drag 4 edge mid-points for independent X/Y squash & stretch, drag top lollipop handle to rotate 360° around center.
     */
    fun updateSelectedLayerDirectTransform(
        dx: Float = 0f,
        dy: Float = 0f,
        scaleFactor: Float = 1f,
        scaleXFactor: Float = 1f,
        scaleYFactor: Float = 1f,
        rotationDeltaDeg: Float = 0f,
        recordUndo: Boolean = false
    ) {
        val frame = _uiState.value.currentFrame
        val scene = _uiState.value.activeScene ?: return
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val cur = InterpolationEngine.evaluateLayerTransform(l, frame, scene.durationFrames)
            val kf = TransformKeyframe(
                frame = frame,
                x = cur.x + dx,
                y = cur.y + dy,
                rotationDeg = cur.rotationDeg + rotationDeltaDeg,
                scaleX = (cur.scaleX * scaleFactor * scaleXFactor).coerceIn(0.1f, 10.0f),
                scaleY = (cur.scaleY * scaleFactor * scaleYFactor).coerceIn(0.1f, 10.0f),
                opacity = cur.opacity,
                easing = _uiState.value.activeEasing.name
            )
            val updatedKfs = l.keyframes.filterNot { it.frame == frame } + kf
            l.copy(keyframes = updatedKfs.sortedBy { it.frame })
        }
    }

    fun setSelectedLayerTransformAbsolute(
        rotationDeg: Float? = null,
        scale: Float? = null,
        scaleX: Float? = null,
        scaleY: Float? = null,
        reset: Boolean = false,
        recordUndo: Boolean = false
    ) {
        val frame = _uiState.value.currentFrame
        val scene = _uiState.value.activeScene ?: return
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val cur = InterpolationEngine.evaluateLayerTransform(l, frame, scene.durationFrames)
            val nextScaleX = when {
                reset -> 1f
                scaleX != null -> scaleX.coerceIn(0.1f, 10.0f)
                scale != null -> scale.coerceIn(0.1f, 10.0f)
                else -> cur.scaleX
            }
            val nextScaleY = when {
                reset -> 1f
                scaleY != null -> scaleY.coerceIn(0.1f, 10.0f)
                scale != null -> scale.coerceIn(0.1f, 10.0f)
                else -> cur.scaleY
            }
            val nextRot = if (reset) 0f else (rotationDeg ?: cur.rotationDeg)
            val kf = TransformKeyframe(
                frame = frame,
                x = if (reset) 0f else cur.x,
                y = if (reset) 0f else cur.y,
                rotationDeg = nextRot,
                scaleX = nextScaleX,
                scaleY = nextScaleY,
                opacity = cur.opacity,
                easing = _uiState.value.activeEasing.name
            )
            val updatedKfs = l.keyframes.filterNot { it.frame == frame } + kf
            l.copy(keyframes = updatedKfs.sortedBy { it.frame })
        }
    }

    fun setSelectedLayerPivotMode(mode: String) {
        mutateSelectedLayer { it.copy(pivotMode = if (mode == "BOTTOM_FEET") "BOTTOM_FEET" else "CENTER") }
        showToast(if (mode == "BOTTOM_FEET") "Pivot: Bottom-Feet" else "Pivot: True Center")
    }

    fun addMotionPathPoint(pt: Vec2) {
        mutateSelectedLayer { l -> l.copy(motionPath = l.motionPath + pt) }
        _uiState.update { it.copy(showMotionPaths = true) }
    }

    fun setMotionPathPoints(points: List<Vec2>) {
        if (points.size < 2) return
        val startF = _uiState.value.currentFrame
        val total = _uiState.value.activeScene?.durationFrames ?: 96
        val useStartFrame = if (startF < total - 6) startF else 0
        mutateSelectedLayer(recordUndo = true) { l ->
            l.copy(
                motionPath = points,
                motionPathStartFrame = useStartFrame,
                motionPathEndFrame = -1
            )
        }
        _uiState.update { it.copy(showMotionPaths = true) }
        showToast("Smooth Path set (${points.size} pts) — press Play to follow!")
    }

    fun undoLastMotionPathPoint() {
        mutateSelectedLayer(recordUndo = true) { l ->
            if (l.motionPath.isEmpty()) l else l.copy(motionPath = l.motionPath.dropLast(1))
        }
    }

    fun reverseMotionPath() {
        mutateSelectedLayer(recordUndo = true) { l ->
            if (l.motionPath.size < 2) l else l.copy(motionPath = l.motionPath.reversed())
        }
        showToast("Reversed motion path direction")
    }

    fun toggleMotionPathOrient() {
        var enabled = false
        mutateSelectedLayer(recordUndo = true) { l ->
            enabled = !l.motionPathOrientToPath
            l.copy(motionPathOrientToPath = enabled)
        }
        showToast(if (enabled) "Auto-Orient along path ON" else "Auto-Orient along path OFF")
    }

    fun cycleMotionPathEasing() {
        val options = listOf(EasingType.EASE_IN_OUT, EasingType.LINEAR, EasingType.EASE_OUT, EasingType.EASE_IN, EasingType.BOUNCE)
        var nextEasing = EasingType.EASE_IN_OUT
        mutateSelectedLayer(recordUndo = true) { l ->
            val cur = runCatching { EasingType.valueOf(l.motionPathEasing) }.getOrDefault(EasingType.EASE_IN_OUT)
            nextEasing = options[(options.indexOf(cur) + 1) % options.size]
            l.copy(motionPathEasing = nextEasing.name)
        }
        showToast("Path Easing: ${nextEasing.displayName}")
    }

    fun clearMotionPath() {
        mutateSelectedLayer(recordUndo = true) { l ->
            l.copy(motionPath = emptyList(), motionPathStartFrame = 0, motionPathEndFrame = -1)
        }
        showToast("Motion path cleared")
    }

    // ─── Extra Variable Rig Bones & Custom Asset Grafting (Any Body Area) ───

    fun addExtraRigBoneToSelectedLayer(
        area: RigAttachmentArea,
        propKind: HandPropKind? = null,
        customName: String? = null,
        length: Float = 68f
    ) {
        val sel = _uiState.value.selectedLayer ?: return
        val rig = sel.rig ?: run {
            showToast("Select a rigged character layer first")
            return
        }
        val (updatedRig, newBone) = RigSolver.createExtraVariableBone(
            rig = rig,
            area = area,
            selectedBoneId = _uiState.value.selectedBoneId,
            name = customName,
            length = length,
            propKind = propKind
        )
        mutateSelectedLayer(recordUndo = true) { l -> l.copy(rig = updatedRig) }
        _uiState.update { it.copy(selectedBoneId = newBone.id, activeTool = EditorTool.RIG_EDIT) }
        showToast("Attached \"${newBone.name}\" — drag its glowing joint on stage to pose!")
    }

    fun attachCustomPngToNewExtraBone(area: RigAttachmentArea, uri: Uri) {
        val sel = _uiState.value.selectedLayer ?: return
        if (sel.rig == null) {
            showToast("Select a rigged character layer first")
            return
        }
        viewModelScope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                copyPickedImageToLocalFile(uri, "extra_rig_${area.name.lowercase()}")
            } ?: run {
                showToast("Could not load PNG for extra rig")
                return@launch
            }
            val currentRig = _uiState.value.selectedLayer?.rig ?: return@launch
            val (updatedRig, newBone) = RigSolver.createExtraVariableBone(
                rig = currentRig,
                area = area,
                selectedBoneId = _uiState.value.selectedBoneId,
                length = 74f,
                imagePath = savedPath,
                imageScale = 1.25f
            )
            mutateSelectedLayer(recordUndo = true) { l -> l.copy(rig = updatedRig) }
            _uiState.update { it.copy(selectedBoneId = newBone.id, activeTool = EditorTool.RIG_EDIT) }
            showToast("Attached Custom PNG onto ${area.label} as movable rig!")
        }
    }

    fun attachCustomAssetToSelectedLayer(asset: SkeletalRig, area: RigAttachmentArea) {
        val sel = _uiState.value.selectedLayer ?: return
        val rig = sel.rig ?: run {
            showToast("Select a rigged character first, or insert asset into Scene")
            return
        }
        val (updatedRig, firstBone) = RigSolver.graftCustomAssetOntoRig(
            targetRig = rig,
            assetRig = asset,
            area = area,
            selectedBoneId = _uiState.value.selectedBoneId
        )
        mutateSelectedLayer(recordUndo = true) { l -> l.copy(rig = updatedRig) }
        _uiState.update { it.copy(selectedBoneId = firstBone?.id, activeTool = EditorTool.RIG_EDIT) }
        showToast("Attached \"${asset.name}\" onto ${area.label}!")
    }

    fun updateSelectedLayerBone(boneId: String, recordUndo: Boolean = false, fn: (RigBone) -> RigBone) {
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(bones = rig.bones.map { if (it.id == boneId) fn(it) else it }))
        }
    }

    fun deleteBoneFromSelectedLayer(boneId: String) {
        val sel = _uiState.value.selectedLayer ?: return
        val rig = sel.rig ?: return
        if (rig.bones.size <= 1) {
            showToast("Cannot delete the last remaining bone")
            return
        }
        // Remove the bone and any descendants attached directly to it
        val toRemove = mutableSetOf(boneId)
        var changed = true
        while (changed) {
            changed = false
            rig.bones.forEach { b ->
                if (b.parentId in toRemove && b.id !in toRemove) {
                    toRemove.add(b.id)
                    changed = true
                }
            }
        }
        val remaining = rig.bones.filterNot { it.id in toRemove }
        if (remaining.isEmpty()) return
        mutateSelectedLayer(recordUndo = true) { l ->
            l.copy(rig = rig.copy(bones = remaining))
        }
        _uiState.update { state ->
            state.copy(selectedBoneId = if (state.selectedBoneId in toRemove) remaining.firstOrNull()?.id else state.selectedBoneId)
        }
        showToast("Removed extra rig attachment")
    }

    // ─── Layer Operations & Video Background Import ─────────────────

    fun selectLayer(layerId: String) {
        _uiState.update { state ->
            state.copy(
                selectedLayerId = layerId,
                selectedTrackKind = TrackSelectionKind.LAYER
            )
        }
    }

    fun addLayer(type: LayerType) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val idx = scene.layers.size + 1
        val newLayer = when (type) {
            LayerType.CHARACTER -> AnimationLayer(
                name = "Character $idx",
                type = type.name,
                character = ProceduralSmartTools.characterPresets.first().copy(x = proj.width * 0.5f, y = proj.height * 0.58f)
            )
            LayerType.RIG -> AnimationLayer(
                name = "Puppet $idx",
                type = type.name,
                rig = RigSolver.createRiggedCharacterFromSpec(
                    ProceduralSmartTools.characterPresets[(idx - 1) % ProceduralSmartTools.characterPresets.size],
                    proj.width * 0.5f,
                    proj.height * 0.6f
                )
            )
            LayerType.FOREGROUND -> AnimationLayer(name = "Foreground $idx", type = type.name, parallaxDepth = 1.35f)
            LayerType.BACKGROUND -> AnimationLayer(name = "Background $idx", type = type.name, parallaxDepth = 0.65f)
            LayerType.VIDEO -> AnimationLayer(name = "Video $idx", type = type.name, parallaxDepth = 1f)
            LayerType.DRAWING -> AnimationLayer(name = "Drawing $idx", type = type.name)
        }
        mutateActiveScene { s -> s.copy(layers = s.layers + newLayer) }
        _uiState.update { it.copy(selectedLayerId = newLayer.id) }
    }

    fun importVideoLayerFromUri(uri: Uri) {
        val proj = _uiState.value.activeProject ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val resolver = getApplication<Application>().contentResolver
            val mimeExt = runCatching { resolver.getType(uri) }.getOrNull()
                ?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
                ?.takeIf { it in setOf("mp4", "webm", "mkv", "mov", "3gp") }
                ?: "mp4"
            val dir = File(getApplication<Application>().filesDir, "videos").apply { mkdirs() }
            val outFile = File(dir, "vid_${System.currentTimeMillis()}.$mimeExt")
            val copied = runCatching {
                val inputStream = runCatching { resolver.openInputStream(uri) }.getOrNull()
                    ?: runCatching { resolver.openAssetFileDescriptor(uri, "r")?.createInputStream() }.getOrNull()
                    ?: return@runCatching false
                inputStream.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                outFile.exists() && outFile.length() > 0L
            }.getOrDefault(false)
            if (copied) {
                val durationMs = runCatching {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(outFile.absolutePath)
                        mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L
                    } finally {
                        runCatching { mmr.release() }
                    }
                }.getOrDefault(5000L)
                val videoLayer = AnimationLayer(
                    name = "Video BG",
                    type = LayerType.VIDEO.name,
                    parallaxDepth = 1f,
                    videoFilePath = outFile.absolutePath,
                    videoDurationMs = durationMs
                )
                withContext(Dispatchers.Main) {
                    mutateActiveScene { s ->
                        val minNeededFrames = ((durationMs / 1000f) * proj.fps).toInt().coerceIn(s.durationFrames, 2000)
                        s.copy(
                            durationFrames = maxOf(s.durationFrames, minNeededFrames),
                            layers = listOf(videoLayer) + s.layers
                        )
                    }
                    _uiState.update { it.copy(selectedLayerId = videoLayer.id) }
                    showToast("Imported video layer (${durationMs / 1000}s)")
                }
            } else {
                runCatching { if (outFile.exists()) outFile.delete() }
                withContext(Dispatchers.Main) { showToast("Could not read video file") }
            }
        }
    }

    fun deleteLayer(layerId: String) {
        mutateActiveScene { s ->
            if (s.layers.size <= 1) s else s.copy(layers = s.layers.filterNot { it.id == layerId })
        }
    }

    fun toggleLayerVisibility(layerId: String) {
        val currentLayer = _uiState.value.activeScene?.layers?.firstOrNull { it.id == layerId }
        mutateActiveScene { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(visible = !it.visible) else it })
        }
        if (currentLayer != null) {
            showToast(if (currentLayer.visible) "Hidden \"${currentLayer.name}\"" else "Shown \"${currentLayer.name}\"")
        }
    }

    fun toggleLayerLock(layerId: String) {
        mutateActiveScene { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(locked = !it.locked) else it })
        }
    }

    fun updateLayerOpacity(layerId: String, opacity: Float) {
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(opacity = opacity.coerceIn(0f, 1f)) else it })
        }
    }

    fun updateLayerParallax(layerId: String, depth: Float) {
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(layers = s.layers.map { if (it.id == layerId) it.copy(parallaxDepth = depth.coerceIn(0.2f, 2f)) else it })
        }
    }

    fun moveLayerOrder(layerId: String, up: Boolean) {
        val scene = _uiState.value.activeScene ?: return
        val idx = scene.layers.indexOfFirst { it.id == layerId }
        if (idx < 0) return
        val target = if (up) idx + 1 else idx - 1
        if (target !in scene.layers.indices) {
            showToast(if (up) "Already at Front (Top layer)" else "Already at Back (Bottom layer)")
            return
        }
        val layerName = scene.layers[idx].name
        mutateActiveScene { s ->
            val list = s.layers.toMutableList()
            val curIdx = list.indexOfFirst { it.id == layerId }
            val dstIdx = if (up) curIdx + 1 else curIdx - 1
            if (curIdx >= 0 && dstIdx in list.indices) {
                val item = list.removeAt(curIdx)
                list.add(dstIdx, item)
            }
            s.copy(layers = list)
        }
        val posFromTop = scene.layers.size - target
        showToast(if (up) "Moved \"$layerName\" Forward (Layer #$posFromTop)" else "Moved \"$layerName\" Backward (Layer #$posFromTop)")
    }

    fun moveLayerToExtreme(layerId: String, toFront: Boolean) {
        val scene = _uiState.value.activeScene ?: return
        val idx = scene.layers.indexOfFirst { it.id == layerId }
        if (idx < 0) return
        val layerName = scene.layers[idx].name
        mutateActiveScene { s ->
            val list = s.layers.toMutableList()
            val curIdx = list.indexOfFirst { it.id == layerId }
            if (curIdx >= 0) {
                val item = list.removeAt(curIdx)
                if (toFront) list.add(item) else list.add(0, item)
            }
            s.copy(layers = list)
        }
        showToast(if (toFront) "Brought \"$layerName\" to Front" else "Sent \"$layerName\" to Back")
    }

    fun toggleTextVisibility(textId: String) {
        val cur = _uiState.value.activeScene?.animatedTexts?.firstOrNull { it.id == textId } ?: return
        mutateActiveScene { s ->
            s.copy(animatedTexts = s.animatedTexts.map { if (it.id == textId) it.copy(visible = !it.visible) else it })
        }
        showToast(if (cur.visible) "Hidden Text track" else "Shown Text track")
    }

    fun moveTextOrder(textId: String, up: Boolean) {
        val scene = _uiState.value.activeScene ?: return
        val idx = scene.animatedTexts.indexOfFirst { it.id == textId }
        if (idx < 0) return
        val target = if (up) idx + 1 else idx - 1
        if (target !in scene.animatedTexts.indices) {
            showToast(if (up) "Text already on top" else "Text already at bottom")
            return
        }
        mutateActiveScene { s ->
            val list = s.animatedTexts.toMutableList()
            val curIdx = list.indexOfFirst { it.id == textId }
            val dstIdx = if (up) curIdx + 1 else curIdx - 1
            if (curIdx >= 0 && dstIdx in list.indices) {
                val item = list.removeAt(curIdx)
                list.add(dstIdx, item)
            }
            s.copy(animatedTexts = list)
        }
        showToast(if (up) "Moved Text Forward" else "Moved Text Backward")
    }

    fun moveSelectedTrackOrder(up: Boolean) {
        val state = _uiState.value
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val id = state.selectedLayer?.id ?: return
                moveLayerOrder(id, up)
            }
            TrackSelectionKind.TEXT -> {
                val id = state.selectedText?.id ?: return
                moveTextOrder(id, up)
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val id = state.selectedAudioTrackId ?: proj.audioTracks.firstOrNull()?.id ?: return
                val idx = proj.audioTracks.indexOfFirst { it.id == id }
                val target = if (up) idx - 1 else idx + 1
                if (idx < 0 || target !in proj.audioTracks.indices) {
                    showToast(if (up) "Audio already first" else "Audio already last")
                    return
                }
                mutateProject { p ->
                    val list = p.audioTracks.toMutableList()
                    val curIdx = list.indexOfFirst { it.id == id }
                    val dstIdx = if (up) curIdx - 1 else curIdx + 1
                    if (curIdx >= 0 && dstIdx in list.indices) {
                        val item = list.removeAt(curIdx)
                        list.add(dstIdx, item)
                    }
                    p.copy(audioTracks = list)
                }
                showToast(if (up) "Moved Audio Track Up" else "Moved Audio Track Down")
            }
        }
    }

    fun toggleAudioMute(trackId: String) {
        val cur = _uiState.value.activeProject?.audioTracks?.firstOrNull { it.id == trackId } ?: return
        mutateProject { p ->
            p.copy(audioTracks = p.audioTracks.map { if (it.id == trackId) it.copy(muted = !it.muted) else it })
        }
        showToast(if (cur.muted) "Unmuted \"${cur.name}\"" else "Muted \"${cur.name}\"")
    }

    fun toggleSelectedTrackVisibility() {
        val state = _uiState.value
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val id = state.selectedLayer?.id ?: return
                toggleLayerVisibility(id)
            }
            TrackSelectionKind.TEXT -> {
                val id = state.selectedText?.id ?: return
                toggleTextVisibility(id)
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val src = proj.audioTracks.firstOrNull { it.id == state.selectedAudioTrackId }
                    ?: proj.audioTracks.firstOrNull() ?: return
                toggleAudioMute(src.id)
            }
        }
    }

    // ─── Timeline, Playback & Keyframes ─────────────────────────────

    fun setCurrentFrame(frame: Int) {
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 1) - 1).coerceAtLeast(0)
        _uiState.update { it.copy(currentFrame = frame.coerceIn(0, maxF)) }
    }

    fun stepFrame(delta: Int) {
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 1) - 1).coerceAtLeast(0)
        val next = (_uiState.value.currentFrame + delta).coerceIn(0, maxF)
        _uiState.update { it.copy(currentFrame = next) }
    }

    fun setFps(fps: Int) {
        mutateProject { it.copy(fps = fps.coerceIn(6, 60)) }
    }

    fun setSceneDuration(frames: Int) {
        mutateActiveScene { it.copy(durationFrames = frames.coerceIn(1, 2000)) }
    }

    fun addFrames(delta: Int) {
        val currentTotal = _uiState.value.activeScene?.durationFrames ?: 96
        val nextTotal = (currentTotal + delta).coerceIn(1, 2000)
        mutateActiveScene { it.copy(durationFrames = nextTotal) }
        showToast("Timeline extended to $nextTotal frames")
    }

    fun jumpToFrame(frame: Int) {
        setCurrentFrame(frame)
    }

    fun togglePlayback() {
        if (_uiState.value.isPlaying) {
            stopPlayback()
        } else {
            startPlayback()
        }
    }

    private fun startPlayback() {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        playbackJob?.cancel()
        _uiState.update { it.copy(isPlaying = true) }

        playbackJob = viewModelScope.launch {
            while (isActive && _uiState.value.isPlaying) {
                val curState = _uiState.value
                val fps = (curState.activeProject?.fps ?: proj.fps).coerceIn(6, 60)
                val total = (curState.activeScene?.durationFrames ?: scene.durationFrames).coerceAtLeast(1)
                val frameNow = curState.currentFrame
                curState.activeProject?.audioTracks?.let { audioEngine.triggerTracksForFrame(it, frameNow) }
                delay((1000L / fps).coerceAtLeast(16L))
                val nextFrame = frameNow + 1
                if (nextFrame >= total) {
                    if (curState.isLooping) {
                        _uiState.update { it.copy(currentFrame = 0) }
                    } else {
                        stopPlayback()
                    }
                } else {
                    _uiState.update { it.copy(currentFrame = nextFrame) }
                }
            }
        }
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        audioEngine.stopAllPlayback()
        _uiState.update { it.copy(isPlaying = false) }
    }

    fun addBlankCelAtCurrentFrame() {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l -> l.copy(frames = l.frames + (frameKey to FrameContent())) }
        showToast("Added blank cel on F${_uiState.value.currentFrame + 1}")
    }

    fun duplicatePreviousCelToCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer { l ->
            val src = InterpolationEngine.resolveFrameContent(l, (frame - 1).coerceAtLeast(0), holdPrevious = true)
                ?: FrameContent()
            l.copy(frames = l.frames + (frame.toString() to src))
        }
        showToast("Duplicated cel to F${frame + 1}")
    }

    fun clearCurrentCel() {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l -> l.copy(frames = l.frames + (frameKey to FrameContent())) }
    }

    fun insertOrUpdateKeyframeAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        val scene = _uiState.value.activeScene ?: return
        mutateSelectedLayer { l ->
            val tf = InterpolationEngine.evaluateLayerTransform(l, frame, scene.durationFrames)
            val kf = TransformKeyframe(
                frame = frame,
                x = tf.x, y = tf.y, rotationDeg = tf.rotationDeg,
                scaleX = tf.scaleX, scaleY = tf.scaleY, opacity = tf.opacity,
                easing = _uiState.value.activeEasing.name
            )
            l.copy(keyframes = (l.keyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame })
        }
        showToast("Keyframe set at F${frame + 1}")
    }

    fun deleteKeyframeAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer { l -> l.copy(keyframes = l.keyframes.filterNot { it.frame == frame }) }
    }

    fun applyMotionPresetToSelectedLayer(preset: MotionPreset) {
        val scene = _uiState.value.activeScene ?: return
        if (preset == MotionPreset.DRAMATIC_ZOOM) {
            val end = (scene.durationFrames - 1).coerceAtLeast(1)
            mutateActiveScene { s ->
                s.copy(
                    cameraKeyframes = listOf(
                        CameraKeyframe(0, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(end / 2, 0f, -15f, 1.32f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(end, 0f, 0f, 1f, 0f, EasingType.EASE_OUT.name)
                    )
                )
            }
            showToast("Applied Camera Zoom-In preset")
            return
        }
        mutateSelectedLayer { l ->
            ProceduralSmartTools.applyMotionPreset(l, preset, scene.durationFrames)
        }
        showToast("Applied ${preset.label}")
    }

    // ─── Character Creator ──────────────────────────────────────────

    fun upsertCharacterLayer(spec: CharacterSpec, createNewLayer: Boolean) {
        val selected = _uiState.value.selectedLayer
        if (!createNewLayer && selected != null && selected.type == LayerType.CHARACTER.name) {
            mutateSelectedLayer { it.copy(name = spec.name, character = spec) }
        } else {
            val newLayer = AnimationLayer(name = spec.name, type = LayerType.CHARACTER.name, character = spec)
            mutateActiveScene { s -> s.copy(layers = s.layers + newLayer) }
            _uiState.update { it.copy(selectedLayerId = newLayer.id) }
        }
        showToast("Updated character \"${spec.name}\"")
    }

    fun saveCharacterTemplate(spec: CharacterSpec) {
        mutateProject { p ->
            val updated = p.savedCharacters.filterNot { it.id == spec.id } + spec.copy(id = UUID.randomUUID().toString())
            p.copy(savedCharacters = updated)
        }
        showToast("Saved character template \"${spec.name}\"")
    }

    fun setCharacterFrameExpressionOrPose(expression: String? = null, pose: String? = null) {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val base = l.frames[frameKey]?.characterOverride ?: l.character ?: return@mutateSelectedLayer l
            val nextChar = base.copy(
                expression = expression ?: base.expression,
                pose = pose ?: base.pose
            )
            val content = l.frames[frameKey] ?: FrameContent()
            l.copy(
                character = if (_uiState.value.currentFrame == 0) nextChar else l.character,
                frames = l.frames + (frameKey to content.copy(characterOverride = nextChar))
            )
        }
    }

    // ─── Skeletal Rigging & Multi-Character Puppet Stage ────────────

    fun selectBone(boneId: String?) = _uiState.update { it.copy(selectedBoneId = boneId) }

    fun importRiggedCharacterIntoScene(rig: SkeletalRig) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        val existingPuppets = scene.layers.count { it.rig != null }
        val offsetX = ((existingPuppets % 4) - 1.5f) * 140f
        val startX = (proj.width * 0.5f + offsetX).coerceIn(160f, proj.width - 160f)
        val startY = proj.height * 0.62f
        val frame = _uiState.value.currentFrame

        val freshRig = rig.copy(
            id = UUID.randomUUID().toString(),
            rootX = startX,
            rootY = startY,
            rootKeyframes = listOf(
                PuppetRootKeyframe(
                    frame = frame,
                    rootX = startX,
                    rootY = startY,
                    scale = rig.scale,
                    scaleX = rig.scaleX,
                    scaleY = rig.scaleY,
                    flippedHorizontal = rig.flippedHorizontal,
                    viewAngle = rig.viewAngle,
                    eyePack = rig.eyePack,
                    eyebrowStyle = rig.eyebrowStyle,
                    mouthPhoneme = rig.mouthPhoneme,
                    leftHandGesture = rig.leftHandGesture,
                    rightHandGesture = rig.rightHandGesture,
                    behaviorPreset = rig.behaviorPreset,
                    easing = _uiState.value.activeEasing.name
                )
            )
        )
        val isGhostPreset = freshRig.name.contains("Ghost", ignoreCase = true) ||
            freshRig.name.contains("Phantom", ignoreCase = true)
        val newLayer = AnimationLayer(
            name = "${freshRig.name} (Puppet)",
            type = LayerType.RIG.name,
            opacity = if (isGhostPreset) 0.55f else 1f,
            rig = freshRig
        )
        mutateActiveScene { s -> s.copy(layers = s.layers + newLayer) }
        _uiState.update {
            it.copy(
                selectedLayerId = newLayer.id,
                activeTool = EditorTool.RIG_EDIT,
                showImportCharacterSheet = false,
                showRigOverlay = true
            )
        }
        showToast(
            if (isGhostPreset) "Imported \"${freshRig.name}\" in Ghost Mode (55% Transparent)!"
            else "Imported \"${freshRig.name}\" — drag hip ring or limbs!"
        )
    }

    fun toggleSelectedLayerGhostMode() {
        val cur = _uiState.value.selectedLayer ?: return
        val nextOpacity = if (cur.opacity < 0.85f) 1.0f else 0.55f
        mutateSelectedLayer { l -> l.copy(opacity = nextOpacity) }
        showToast(if (nextOpacity < 0.85f) "Ghost Mode ON (55% Transparent + Aura)" else "Ghost Mode OFF (100% Solid)")
    }

    fun autoRigCharacterSpecIntoScene(spec: CharacterSpec) {
        val proj = _uiState.value.activeProject ?: return
        val rigged = RigSolver.createRiggedCharacterFromSpec(
            spec = spec,
            rootX = proj.width * 0.5f,
            rootY = proj.height * 0.62f
        )
        importRiggedCharacterIntoScene(rigged)
        showToast("Auto-Rigged \"${spec.name}\" (14 human bones + IK)!")
    }

    fun autoRigSelectedLayer() {
        val proj = _uiState.value.activeProject ?: return
        val selected = _uiState.value.selectedLayer ?: return
        if (selected.rig != null) {
            mutateSelectedLayer { l ->
                val curRig = l.rig ?: return@mutateSelectedLayer l
                val upgraded = RigSolver.autoRigHumanoid(curRig)
                l.copy(rig = upgraded)
            }
            _uiState.update { it.copy(activeTool = EditorTool.RIG_EDIT, showRigOverlay = true, selectedBoneId = "hand_r") }
            showToast("Auto-Rigged \"${selected.name}\" to 14-bone Human IK!")
        } else if (selected.character != null) {
            val spec = selected.character
            val rigged = RigSolver.createRiggedCharacterFromSpec(
                spec = spec,
                rootX = spec.x.coerceIn(140f, proj.width - 140f),
                rootY = spec.y.coerceIn(160f, proj.height - 120f)
            )
            mutateSelectedLayer { l ->
                l.copy(
                    type = LayerType.RIG.name,
                    name = "${spec.name} (Puppet)",
                    character = null,
                    rig = rigged
                )
            }
            _uiState.update { it.copy(activeTool = EditorTool.RIG_EDIT, showRigOverlay = true, selectedBoneId = "hand_r") }
            showToast("Converted \"${spec.name}\" to 14-bone Human Rig!")
        } else {
            // If user selected a Drawing/Image layer, check if it has an imported image to bind as a 2D mesh puppet!
            val content = InterpolationEngine.resolveFrameContent(selected, _uiState.value.currentFrame, holdPrevious = true)
            val firstImg = content?.images?.firstOrNull()
            val newRig = RigSolver.createHumanoidRig(
                name = "${selected.name} Rig",
                rootX = firstImg?.x ?: (proj.width * 0.5f),
                rootY = firstImg?.y ?: (proj.height * 0.6f)
            ).copy(
                singleMeshImagePath = firstImg?.filePath,
                singleMeshWidth = firstImg?.width ?: 260f,
                singleMeshHeight = firstImg?.height ?: 360f
            )
            mutateSelectedLayer { l ->
                val cleanedFrames = if (firstImg != null) {
                    l.frames.mapValues { (_, fc) ->
                        fc.copy(images = fc.images.filterNot { it.filePath == firstImg.filePath })
                    }
                } else l.frames
                l.copy(type = LayerType.RIG.name, rig = newRig, frames = cleanedFrames)
            }
            _uiState.update { it.copy(activeTool = EditorTool.RIG_EDIT, showRigOverlay = true, selectedBoneId = "hand_r") }
            showToast("Auto-Rigged layer with 14-bone Human Skeleton!")
        }
    }

    fun setPuppetViewAngle(angle: CharacterViewAngle) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = angle.name,
                eyePack = eval.eyePack,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(
                rig = rig.copy(
                    viewAngle = angle.name,
                    characterAppearance = rig.characterAppearance?.copy(viewAngle = angle.name),
                    rootKeyframes = nextKeys
                )
            )
        }
        showToast("View: ${angle.label} (Keyframed F${frame + 1})")
    }

    fun cyclePuppetViewAngle() {
        val rig = _uiState.value.selectedLayer?.rig ?: return
        val eval = InterpolationEngine.evaluatePuppetRoot(rig, _uiState.value.currentFrame)
        val cur = runCatching { CharacterViewAngle.valueOf(eval.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
        val list = CharacterViewAngle.entries
        val next = list[(list.indexOf(cur) + 1) % list.size]
        setPuppetViewAngle(next)
    }

    fun setPuppetHandProp(isRightHand: Boolean, prop: HandPropKind) {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(
                rig = if (isRightHand) {
                    rig.copy(rightHandProp = prop.name, rightHandCustomImagePath = null)
                } else {
                    rig.copy(leftHandProp = prop.name, leftHandCustomImagePath = null)
                }
            )
        }
        showToast("${if (isRightHand) "Right" else "Left"} Hand: ${prop.label}")
    }

    fun cyclePuppetHandProp(isRightHand: Boolean) {
        val rig = _uiState.value.selectedLayer?.rig ?: return
        val curName = if (isRightHand) rig.rightHandProp else rig.leftHandProp
        val cur = runCatching { HandPropKind.valueOf(curName) }.getOrDefault(HandPropKind.NONE)
        val list = HandPropKind.entries
        val next = list[(list.indexOf(cur) + 1) % list.size]
        setPuppetHandProp(isRightHand, next)
    }

    fun setPuppetHandCustomPng(isRightHand: Boolean, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val savedPath = copyPickedImageToLocalFile(uri, if (isRightHand) "puppet_hand_r" else "puppet_hand_l")
            withContext(Dispatchers.Main) {
                if (savedPath != null) {
                    mutateSelectedLayer { l ->
                        val rig = l.rig ?: return@mutateSelectedLayer l
                        l.copy(
                            rig = if (isRightHand) {
                                rig.copy(rightHandCustomImagePath = savedPath, rightHandProp = HandPropKind.NONE.name)
                            } else {
                                rig.copy(leftHandCustomImagePath = savedPath, leftHandProp = HandPropKind.NONE.name)
                            }
                        )
                    }
                    showToast("Attached custom PNG to ${if (isRightHand) "Right" else "Left"} Hand!")
                } else {
                    showToast("Could not load PNG image")
                }
            }
        }
    }

    fun clearPuppetHandProp(isRightHand: Boolean) {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(
                rig = if (isRightHand) rig.copy(rightHandProp = HandPropKind.NONE.name, rightHandCustomImagePath = null)
                else rig.copy(leftHandProp = HandPropKind.NONE.name, leftHandCustomImagePath = null)
            )
        }
    }

    fun dragRigBoneTo(boneId: String, target: Vec2, recordUndo: Boolean = false) {
        val frame = _uiState.value.currentFrame
        val stretchMode = _uiState.value.stretchRigMode
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val rootEval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val currentAngles = InterpolationEngine.evaluateRigAngles(rig, frame)
            val currentLengths = InterpolationEngine.evaluateBoneLengths(rig, frame)
            val effectiveFlipped = SceneRenderer.isLeftFacingView(rootEval.viewAngle, rootEval.flippedHorizontal)
            val draggedBone = rig.bones.firstOrNull { it.id == boneId }
            val allowStretch = stretchMode ||
                draggedBone?.allowElasticStretch == true ||
                draggedBone?.partBehaviorPreset == PartBehaviorPreset.ELASTIC_RUBBER.name
            if (allowStretch) {
                val (newAngles, newLengths) = RigSolver.solveStretchDragTarget(
                    rig = rig,
                    boneId = boneId,
                    target = target,
                    currentAngles = currentAngles,
                    currentLengths = currentLengths,
                    rootX = rootEval.rootX,
                    rootY = rootEval.rootY,
                    scale = rootEval.scale,
                    scaleX = rootEval.scaleX,
                    scaleY = rootEval.scaleY,
                    flippedHorizontal = effectiveFlipped
                )
                l.copy(
                    rig = rig.copy(
                        poseKeyframes = rig.poseKeyframes + (frame.toString() to newAngles),
                        boneLengthKeyframes = rig.boneLengthKeyframes + (frame.toString() to newLengths)
                    )
                )
            } else {
                val newAngles = RigSolver.solveDragTarget(
                    rig = rig,
                    boneId = boneId,
                    target = target,
                    currentAngles = currentAngles,
                    useIk = rig.ikEnabled,
                    rootX = rootEval.rootX,
                    rootY = rootEval.rootY,
                    scale = rootEval.scale,
                    flippedHorizontal = effectiveFlipped,
                    lengthOverrides = currentLengths
                )
                val updatedKeyframes = rig.poseKeyframes + (frame.toString() to newAngles)
                l.copy(rig = rig.copy(poseKeyframes = updatedKeyframes))
            }
        }
    }

    fun movePuppetRoot(x: Float, y: Float, recordUndo: Boolean = false) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer(recordUndo = recordUndo) { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val newKf = PuppetRootKeyframe(
                frame = frame,
                rootX = x,
                rootY = y,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = eval.eyePack,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextRootKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + newKf).sortedBy { it.frame }
            val nextPoses = if (rig.autoWalkWhenDragged) {
                rig.poseKeyframes + (frame.toString() to RigSolver.computeAutoWalkPose(x, eval.behaviorPreset))
            } else {
                rig.poseKeyframes
            }
            l.copy(
                rig = rig.copy(
                    rootX = if (frame == 0) x else rig.rootX,
                    rootY = if (frame == 0) y else rig.rootY,
                    rootKeyframes = nextRootKeys,
                    poseKeyframes = nextPoses
                )
            )
        }
    }

    fun togglePuppetFlipHorizontal() {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val flipped = !eval.flippedHorizontal
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = flipped,
                viewAngle = eval.viewAngle,
                eyePack = eval.eyePack,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(rig = rig.copy(flippedHorizontal = flipped, rootKeyframes = nextKeys))
        }
    }

    fun togglePuppetAutoWalk() {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(autoWalkWhenDragged = !rig.autoWalkWhenDragged))
        }
    }

    fun setPuppetEyePack(style: EyePackStyle) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = style.name,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(rig = rig.copy(eyePack = style.name, rootKeyframes = nextKeys))
        }
        showToast("Eyes: ${style.label}")
    }

    fun setPuppetMouthPhoneme(phoneme: MouthPhoneme) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = eval.eyePack,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = phoneme.name,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(rig = rig.copy(mouthPhoneme = phoneme.name, rootKeyframes = nextKeys))
        }
        showToast("Mouth: ${phoneme.label}")
    }

    fun scalePuppet(scale: Float) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        val clamped = scale.coerceIn(0.1f, 10.0f)
        mutateSelectedLayer(recordUndo = false) { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = clamped,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = eval.eyePack,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(rig = rig.copy(scale = clamped, rootKeyframes = nextKeys))
        }
    }

    // ─── Multi-Track Timeline Editing Tools (Cut, Mid-Cut, Duplicate, Delete, Remix) ───

    fun toggleTrackToolsExpanded() {
        _uiState.update { it.copy(trackToolsExpanded = !it.trackToolsExpanded) }
    }

    fun selectTrackTarget(kind: TrackSelectionKind, id: String) {
        _uiState.update { state ->
            when (kind) {
                TrackSelectionKind.LAYER -> state.copy(selectedTrackKind = kind, selectedLayerId = id)
                TrackSelectionKind.TEXT -> state.copy(selectedTrackKind = kind, selectedTextId = id)
                TrackSelectionKind.AUDIO -> state.copy(selectedTrackKind = kind, selectedAudioTrackId = id)
            }
        }
    }

    fun cutSelectedTrackAtPlayhead() {
        val state = _uiState.value
        val frame = state.currentFrame
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val target = state.selectedLayer ?: return
                mutateSelectedLayer { l ->
                    val trimmedFrames = l.frames.filterKeys { (it.toIntOrNull() ?: 0) < frame }
                    val trimmedKfs = l.keyframes.filter { it.frame < frame }
                    val trimmedRig = l.rig?.copy(
                        poseKeyframes = l.rig.poseKeyframes.filterKeys { (it.toIntOrNull() ?: 0) < frame },
                        boneLengthKeyframes = l.rig.boneLengthKeyframes.filterKeys { (it.toIntOrNull() ?: 0) < frame },
                        boneZOrderKeyframes = l.rig.boneZOrderKeyframes.filterKeys { (it.toIntOrNull() ?: 0) < frame },
                        rootKeyframes = l.rig.rootKeyframes.filter { it.frame < frame }
                    )
                    val endHidden = TransformKeyframe(frame = frame, opacity = 0f, easing = EasingType.LINEAR.name)
                    l.copy(
                        frames = trimmedFrames + (frame.toString() to FrameContent()),
                        keyframes = (trimmedKfs + endHidden).sortedBy { it.frame },
                        rig = trimmedRig
                    )
                }
                showToast("Cut \"${target.name}\" at F${frame + 1}")
            }
            TrackSelectionKind.TEXT -> {
                val text = state.selectedText ?: return
                val cutEnd = (frame - 1).coerceAtLeast(text.startFrame)
                mutateActiveScene { s ->
                    s.copy(animatedTexts = s.animatedTexts.map { if (it.id == text.id) it.copy(endFrame = cutEnd) else it })
                }
                showToast("Cut text track at F${cutEnd + 1}")
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val track = proj.audioTracks.firstOrNull { it.id == state.selectedAudioTrackId }
                    ?: proj.audioTracks.firstOrNull() ?: return
                val newDurMs = (((frame - track.startFrame).coerceAtLeast(2) * 1000L) / proj.fps.coerceAtLeast(1))
                    .coerceIn(200L, track.durationMs)
                updateAudioTrack(track.copy(durationMs = newDurMs))
                showToast("Trimmed audio \"${track.name}\" to F${frame + 1}")
            }
        }
    }

    fun midCutSelectedTrackAtPlayhead() {
        val state = _uiState.value
        val frame = state.currentFrame
        val scene = state.activeScene ?: return
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val src = state.selectedLayer ?: return
                if (frame <= 0 || frame >= scene.durationFrames - 1) {
                    showToast("Move playhead inside timeline to Mid-Cut")
                    return
                }
                val partAFrames = src.frames.filterKeys { (it.toIntOrNull() ?: 0) < frame } + (frame.toString() to FrameContent())
                val partBFrames = src.frames.filterKeys { (it.toIntOrNull() ?: 0) >= frame }.ifEmpty {
                    val resolved = InterpolationEngine.resolveFrameContent(src, frame, holdPrevious = true)
                    if (resolved != null) mapOf(frame.toString() to resolved) else emptyMap()
                }
                val evalTf = InterpolationEngine.evaluateLayerTransform(src, frame, scene.durationFrames)
                val partAKfs = (src.keyframes.filter { it.frame < frame } + TransformKeyframe(frame = frame, x = evalTf.x, y = evalTf.y, rotationDeg = evalTf.rotationDeg, scaleX = evalTf.scaleX, scaleY = evalTf.scaleY, opacity = 0f)).sortedBy { it.frame }
                val partBKfs = (listOf(
                    TransformKeyframe(frame = (frame - 1).coerceAtLeast(0), x = evalTf.x, y = evalTf.y, opacity = 0f),
                    TransformKeyframe(frame = frame, x = evalTf.x, y = evalTf.y, rotationDeg = evalTf.rotationDeg, scaleX = evalTf.scaleX, scaleY = evalTf.scaleY, opacity = evalTf.opacity)
                ) + src.keyframes.filter { it.frame > frame }).sortedBy { it.frame }

                val partARig = src.rig?.copy(
                    poseKeyframes = src.rig.poseKeyframes.filterKeys { (it.toIntOrNull() ?: 0) < frame },
                    boneLengthKeyframes = src.rig.boneLengthKeyframes.filterKeys { (it.toIntOrNull() ?: 0) < frame },
                    boneZOrderKeyframes = src.rig.boneZOrderKeyframes.filterKeys { (it.toIntOrNull() ?: 0) < frame },
                    rootKeyframes = src.rig.rootKeyframes.filter { it.frame < frame }
                )
                val partBRig = src.rig?.let { r ->
                    val rootAtCut = InterpolationEngine.evaluatePuppetRoot(r, frame)
                    val anglesAtCut = InterpolationEngine.evaluateRigAngles(r, frame)
                    val zOrdersAtCut = InterpolationEngine.evaluateBoneZOrders(r, frame)
                    r.copy(
                        id = UUID.randomUUID().toString(),
                        name = "${r.name} (Cut 2)",
                        poseKeyframes = r.poseKeyframes.filterKeys { (it.toIntOrNull() ?: 0) >= frame } + (frame.toString() to anglesAtCut),
                        boneLengthKeyframes = r.boneLengthKeyframes.filterKeys { (it.toIntOrNull() ?: 0) >= frame },
                        boneZOrderKeyframes = if (r.boneZOrderKeyframes.isEmpty()) emptyMap() else (r.boneZOrderKeyframes.filterKeys { (it.toIntOrNull() ?: 0) >= frame } + (frame.toString() to zOrdersAtCut)),
                        rootKeyframes = (r.rootKeyframes.filter { it.frame > frame } + PuppetRootKeyframe(
                            frame = frame,
                            rootX = rootAtCut.rootX,
                            rootY = rootAtCut.rootY,
                            scale = rootAtCut.scale,
                            scaleX = rootAtCut.scaleX,
                            scaleY = rootAtCut.scaleY,
                            flippedHorizontal = rootAtCut.flippedHorizontal,
                            viewAngle = rootAtCut.viewAngle,
                            eyePack = rootAtCut.eyePack,
                            eyebrowStyle = rootAtCut.eyebrowStyle,
                            mouthPhoneme = rootAtCut.mouthPhoneme,
                            leftHandGesture = rootAtCut.leftHandGesture,
                            rightHandGesture = rootAtCut.rightHandGesture,
                            behaviorPreset = rootAtCut.behaviorPreset
                        )).sortedBy { it.frame }
                    )
                }

                val partA = src.copy(name = "${src.name} A", frames = partAFrames, keyframes = partAKfs, rig = partARig)
                val partB = src.copy(
                    id = UUID.randomUUID().toString(),
                    name = "${src.name} B",
                    frames = partBFrames,
                    keyframes = partBKfs,
                    rig = partBRig
                )
                mutateActiveScene { s ->
                    val idx = s.layers.indexOfFirst { it.id == src.id }
                    if (idx < 0) s else {
                        val list = s.layers.toMutableList()
                        list[idx] = partA
                        list.add(idx + 1, partB)
                        s.copy(layers = list)
                    }
                }
                _uiState.update { it.copy(selectedLayerId = partB.id, selectedTrackKind = TrackSelectionKind.LAYER) }
                showToast("Mid-Cut \"${src.name}\" into 2 tracks at F${frame + 1}!")
            }
            TrackSelectionKind.TEXT -> {
                val src = state.selectedText ?: return
                if (frame <= src.startFrame || frame >= src.endFrame) {
                    showToast("Move playhead inside the Text clip to Mid-Cut")
                    return
                }
                val partA = src.copy(endFrame = frame - 1)
                val partB = src.copy(id = UUID.randomUUID().toString(), startFrame = frame, endFrame = src.endFrame)
                mutateActiveScene { s ->
                    val list = s.animatedTexts.flatMap { if (it.id == src.id) listOf(partA, partB) else listOf(it) }
                    s.copy(animatedTexts = list)
                }
                _uiState.update { it.copy(selectedTextId = partB.id, selectedTrackKind = TrackSelectionKind.TEXT) }
                showToast("Mid-Cut Text into 2 clips at F${frame + 1}!")
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val src = proj.audioTracks.firstOrNull { it.id == state.selectedAudioTrackId }
                    ?: proj.audioTracks.firstOrNull() ?: return
                val fps = proj.fps.coerceAtLeast(1)
                val clipFrames = ((src.durationMs / 1000f) * fps).toInt().coerceAtLeast(4)
                val splitOffset = frame - src.startFrame
                if (splitOffset <= 1 || splitOffset >= clipFrames - 1) {
                    showToast("Move playhead inside Audio clip to Mid-Cut")
                    return
                }
                val durA = (splitOffset * 1000L) / fps
                val durB = (src.durationMs - durA).coerceAtLeast(250L)
                val partA = src.copy(name = "${src.name} (1)", durationMs = durA)
                val partB = src.copy(
                    id = UUID.randomUUID().toString(),
                    name = "${src.name} (2)",
                    startFrame = frame,
                    durationMs = durB
                )
                mutateProject { p ->
                    val list = p.audioTracks.flatMap { if (it.id == src.id) listOf(partA, partB) else listOf(it) }
                    p.copy(audioTracks = list)
                }
                _uiState.update { it.copy(selectedAudioTrackId = partB.id, selectedTrackKind = TrackSelectionKind.AUDIO) }
                showToast("Mid-Cut Audio into 2 tracks at F${frame + 1}!")
            }
        }
    }

    fun duplicateSelectedTrack() {
        val state = _uiState.value
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val src = state.selectedLayer ?: return
                val dupRig = src.rig?.let { r ->
                    r.copy(
                        id = UUID.randomUUID().toString(),
                        name = "${r.name} Copy",
                        rootX = r.rootX + 60f,
                        rootKeyframes = r.rootKeyframes.map { it.copy(rootX = it.rootX + 60f) }
                    )
                }
                val dup = src.copy(
                    id = UUID.randomUUID().toString(),
                    name = "${src.name} Copy",
                    rig = dupRig,
                    keyframes = src.keyframes.map { it.copy(x = it.x + 30f) }
                )
                mutateActiveScene { s -> s.copy(layers = s.layers + dup) }
                _uiState.update { it.copy(selectedLayerId = dup.id, selectedTrackKind = TrackSelectionKind.LAYER) }
                showToast("Duplicated track \"${src.name}\"")
            }
            TrackSelectionKind.TEXT -> {
                val src = state.selectedText ?: return
                val dup = src.copy(id = UUID.randomUUID().toString(), y = (src.y + 70f).coerceAtMost(660f))
                mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts + dup) }
                _uiState.update { it.copy(selectedTextId = dup.id, selectedTrackKind = TrackSelectionKind.TEXT) }
                showToast("Duplicated Text track")
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val src = proj.audioTracks.firstOrNull { it.id == state.selectedAudioTrackId }
                    ?: proj.audioTracks.firstOrNull() ?: return
                val dup = src.copy(
                    id = UUID.randomUUID().toString(),
                    name = "${src.name} Copy",
                    startFrame = (src.startFrame + 8).coerceAtMost((state.activeScene?.durationFrames ?: 96) - 2)
                )
                mutateProject { p -> p.copy(audioTracks = p.audioTracks + dup) }
                _uiState.update { it.copy(selectedAudioTrackId = dup.id, selectedTrackKind = TrackSelectionKind.AUDIO) }
                showToast("Duplicated Audio track")
            }
        }
    }

    fun deleteSelectedTrack() {
        val state = _uiState.value
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val scene = state.activeScene ?: return
                val src = state.selectedLayer ?: return
                if (scene.layers.size <= 1) {
                    showToast("Keep at least 1 layer in the scene")
                    return
                }
                deleteLayer(src.id)
                val nextId = scene.layers.firstOrNull { it.id != src.id }?.id
                _uiState.update { it.copy(selectedLayerId = nextId) }
                showToast("Deleted track \"${src.name}\"")
            }
            TrackSelectionKind.TEXT -> {
                val id = state.selectedText?.id ?: return
                mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts.filterNot { it.id == id }) }
                _uiState.update { it.copy(selectedTextId = null, selectedTrackKind = TrackSelectionKind.LAYER) }
                showToast("Deleted Text track")
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val src = proj.audioTracks.firstOrNull { it.id == state.selectedAudioTrackId }
                    ?: proj.audioTracks.firstOrNull() ?: return
                deleteAudioTrack(src.id)
                _uiState.update { it.copy(selectedAudioTrackId = null, selectedTrackKind = TrackSelectionKind.LAYER) }
                showToast("Deleted Audio \"${src.name}\"")
            }
        }
    }

    fun remixSelectedTrack() {
        val state = _uiState.value
        val scene = state.activeScene ?: return
        when (state.selectedTrackKind) {
            TrackSelectionKind.LAYER -> {
                val src = state.selectedLayer ?: return
                val maxF = (scene.durationFrames - 1).coerceAtLeast(1)
                if (src.rig != null) {
                    // Remix puppet poses + turnaround rhythm + energetic bounce!
                    val poses = listOf("HERO", "WAVE", "WALK_A", "JUMP", "WALK_B", "IDLE")
                    val step = (maxF / 4).coerceAtLeast(6)
                    val remixedPoseMap = buildMap<String, Map<String, Float>> {
                        var f = 0
                        var idx = (state.currentFrame + 1) % poses.size
                        while (f <= maxF) {
                            put(f.toString(), RigSolver.presetPoseAngles(poses[idx % poses.size]))
                            f += step
                            idx++
                        }
                    }
                    val reversedRoots = if (src.rig.rootKeyframes.size >= 2) {
                        val frames = src.rig.rootKeyframes.map { it.frame }
                        src.rig.rootKeyframes.reversed().mapIndexed { i, kf ->
                            kf.copy(frame = frames[i], flippedHorizontal = !kf.flippedHorizontal)
                        }
                    } else {
                        src.rig.rootKeyframes
                    }
                    mutateSelectedLayer { l ->
                        l.copy(rig = l.rig?.copy(poseKeyframes = remixedPoseMap, rootKeyframes = reversedRoots))
                    }
                    showToast("Remixed \"${src.name}\" motion & poses!")
                } else {
                    // Remix non-rig layer: reverse keyframes or apply energetic bounce motion!
                    mutateSelectedLayer { l ->
                        if (l.keyframes.size >= 2) {
                            val frames = l.keyframes.map { it.frame }
                            val remixed = l.keyframes.reversed().mapIndexed { i, kf -> kf.copy(frame = frames[i]) }
                            l.copy(keyframes = remixed)
                        } else {
                            ProceduralSmartTools.applyMotionPreset(l, MotionPreset.BOUNCE_LOOP, scene.durationFrames)
                        }
                    }
                    showToast("Remixed track \"${src.name}\"!")
                }
            }
            TrackSelectionKind.TEXT -> {
                val src = state.selectedText ?: return
                val ins = TextInAnimation.entries
                val loops = TextLoopAnimation.entries
                val nextIn = ins[(ins.indexOfFirst { it.name == src.inAnimation }.coerceAtLeast(0) + 1) % ins.size]
                val nextLoop = loops[(loops.indexOfFirst { it.name == src.loopAnimation }.coerceAtLeast(0) + 1) % loops.size]
                val updated = src.copy(inAnimation = nextIn.name, loopAnimation = nextLoop.name)
                mutateActiveScene { s -> s.copy(animatedTexts = s.animatedTexts.map { if (it.id == src.id) updated else it }) }
                showToast("Remixed Text: ${nextIn.label} + ${nextLoop.label}")
            }
            TrackSelectionKind.AUDIO -> {
                val proj = state.activeProject ?: return
                val src = proj.audioTracks.firstOrNull { it.id == state.selectedAudioTrackId }
                    ?: proj.audioTracks.firstOrNull() ?: return
                val fxList = VoiceEffectType.entries
                val curIdx = fxList.indexOfFirst { it.name == src.voiceEffect }.coerceAtLeast(0)
                val nextFx = fxList[(curIdx + 1) % fxList.size]
                applyVoiceEffectToTrack(src, nextFx)
            }
        }
    }

    fun applyRigPosePreset(poseName: String) {
        val frameKey = _uiState.value.currentFrame.toString()
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val poseMap = RigSolver.presetPoseAngles(poseName)
            l.copy(rig = rig.copy(poseKeyframes = rig.poseKeyframes + (frameKey to poseMap)))
        }
        showToast("Keyframed $poseName pose at F${_uiState.value.currentFrame + 1}")
    }

    fun addChildBoneToRig(name: String, length: Float = 62f) {
        val parentId = _uiState.value.selectedBoneId
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val newBone = RigBone(
                name = name.ifBlank { "Bone ${rig.bones.size + 1}" },
                parentId = parentId ?: rig.bones.firstOrNull()?.id,
                length = length,
                localAngleDeg = 25f,
                thickness = 15f,
                colorArgb = 0xFF2DD4BFL
            )
            l.copy(rig = rig.copy(bones = rig.bones + newBone))
        }
    }

    fun toggleRigIkMode() {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(ikEnabled = !rig.ikEnabled))
        }
    }

    fun toggleRigSkinMesh() {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(showSkinMesh = !rig.showSkinMesh))
        }
    }

    fun saveRigTemplate() {
        val rig = _uiState.value.selectedLayer?.rig ?: return
        val savedCopy = rig.copy(id = UUID.randomUUID().toString())
        mutateProject { p ->
            p.copy(savedRigs = p.savedRigs + savedCopy)
        }
        viewModelScope.launch {
            repository.saveRiggedCharacterToLibrary(savedCopy)
        }
        showToast("Saved \"${rig.name}\" to My Characters")
    }

    fun insertSavedRig(rig: SkeletalRig) {
        importRiggedCharacterIntoScene(rig)
    }

    // ─── Scene & Camera ─────────────────────────────────────────────

    fun selectScene(sceneId: String) {
        val proj = _uiState.value.activeProject ?: return
        val target = proj.scenes.firstOrNull { it.id == sceneId } ?: return
        mutateProject(recordUndo = false) { it.copy(activeSceneId = sceneId) }
        _uiState.update { it.copy(currentFrame = 0, selectedLayerId = target.layers.firstOrNull()?.id) }
    }

    fun addScene(name: String) {
        val newScene = AnimationScene(
            name = name.ifBlank { "Scene ${(_uiState.value.activeProject?.scenes?.size ?: 0) + 1}" },
            durationFrames = 48,
            backgroundTemplate = BackgroundTemplate.SUNNY_MEADOW.name,
            layers = listOf(AnimationLayer(name = "Drawing 1", type = LayerType.DRAWING.name))
        )
        mutateProject { p -> p.copy(scenes = p.scenes + newScene, activeSceneId = newScene.id) }
        _uiState.update { it.copy(currentFrame = 0, selectedLayerId = newScene.layers.first().id) }
    }

    fun deleteScene(sceneId: String) {
        mutateProject { p ->
            if (p.scenes.size <= 1) p
            else {
                val rem = p.scenes.filterNot { it.id == sceneId }
                val nextActive = if (p.activeSceneId == sceneId) rem.first().id else p.activeSceneId
                p.copy(scenes = rem, activeSceneId = nextActive)
            }
        }
    }

    fun setSceneBackgroundTemplate(template: BackgroundTemplate) {
        mutateActiveScene { it.copy(backgroundTemplate = template.name) }
    }

    fun setSceneBackgroundColor(argb: Long) {
        mutateActiveScene { it.copy(backgroundColorArgb = argb, backgroundTemplate = BackgroundTemplate.SOLID.name) }
    }

    fun setSceneTransition(transition: SceneTransition) {
        mutateActiveScene { it.copy(transition = transition.name) }
    }

    fun toggleSceneVfx(vfx: SceneVfxType) {
        mutateActiveScene { s ->
            val next = if (vfx.name in s.activeVfx) {
                s.activeVfx - vfx.name
            } else {
                s.activeVfx + vfx.name
            }
            s.copy(activeVfx = next)
        }
    }

    fun setSceneBackgroundScrollSpeed(speed: Float) {
        val clamped = speed.coerceIn(-8f, 8f)
        mutateActiveScene(recordUndo = false) { it.copy(backgroundScrollSpeed = clamped) }
    }

    fun setSceneColorGrade(grade: SceneColorGrade) {
        mutateActiveScene { it.copy(colorGrade = grade.name) }
        showToast("Look: ${grade.label}")
    }

    fun addSubtitleAtCurrentFrame(
        text: String,
        speakerName: String,
        durationFrames: Int,
        style: SubtitleStyle,
        colorArgb: Long
    ) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val scene = _uiState.value.activeScene ?: return
        val start = _uiState.value.currentFrame
        val end = (start + durationFrames.coerceAtLeast(6) - 1).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(start))
        val cue = SubtitleCue(
            text = clean,
            speakerName = speakerName.trim(),
            startFrame = start,
            endFrame = end,
            colorArgb = colorArgb,
            style = style.name
        )
        mutateActiveScene { s -> s.copy(subtitles = (s.subtitles + cue).sortedBy { it.startFrame }) }
        showToast("Caption added (F${start + 1}–F${end + 1})")
    }

    fun deleteSubtitle(subtitleId: String) {
        mutateActiveScene { s -> s.copy(subtitles = s.subtitles.filterNot { it.id == subtitleId }) }
    }

    fun toggleCameraFrame() = _uiState.update { it.copy(showCameraFrame = !it.showCameraFrame) }
    fun toggleCameraHud() = _uiState.update {
        val next = !it.showCameraHud
        it.copy(showCameraHud = next, showCameraFrame = if (next) true else it.showCameraFrame)
    }

    fun applyCameraFollowSelectedLayer() {
        val proj = _uiState.value.activeProject ?: return
        val layerId = _uiState.value.selectedLayer?.id ?: return
        mutateActiveScene { s ->
            ProceduralSmartTools.applyCameraFollowCharacter(s, layerId, proj.width, proj.height)
        }
        _uiState.update { it.copy(showCameraFrame = true) }
        showToast("Camera now tracks selected character!")
    }

    fun applyCameraDollyZoomAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateActiveScene { s ->
            val curZoom = InterpolationEngine.evaluateCamera(s, frame).zoom
            val targetZoom = if (curZoom > 1.5f) 1.0f else 1.85f
            ProceduralSmartTools.applyCameraDollyZoom(s, frame, targetZoom = targetZoom)
        }
        _uiState.update { it.copy(showCameraFrame = true) }
        showToast("Added Smooth Dolly Zoom at F${frame + 1}")
    }

    fun applyCameraPanAcrossAtCurrentFrame() {
        val proj = _uiState.value.activeProject ?: return
        val frame = _uiState.value.currentFrame
        mutateActiveScene { s ->
            ProceduralSmartTools.applyCameraPanAcross(s, frame, proj.width)
        }
        _uiState.update { it.copy(showCameraFrame = true) }
        showToast("Added Cinematic Pan Across at F${frame + 1}")
    }

    fun applyCameraShakeAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateActiveScene { s ->
            ProceduralSmartTools.applyCameraShake(s, frame)
        }
        _uiState.update { it.copy(showCameraFrame = true) }
        showToast("Added Handheld Camera Shake at F${frame + 1}")
    }

    fun updateCameraKeyframeAtCurrentFrame(panX: Float, panY: Float, zoom: Float, rotationDeg: Float) {
        val frame = _uiState.value.currentFrame
        val kf = CameraKeyframe(
            frame = frame,
            panX = panX.coerceIn(-800f, 800f),
            panY = panY.coerceIn(-600f, 600f),
            zoom = zoom.coerceIn(0.3f, 4.0f),
            rotationDeg = rotationDeg.coerceIn(-180f, 180f),
            easing = _uiState.value.activeEasing.name
        )
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(cameraKeyframes = (s.cameraKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame })
        }
    }

    fun deleteCameraKeyframeAtFrame(frame: Int) {
        mutateActiveScene { s ->
            val rem = s.cameraKeyframes.filterNot { it.frame == frame }
            s.copy(cameraKeyframes = rem.ifEmpty { listOf(CameraKeyframe(frame = 0)) })
        }
        showToast("Removed camera keyframe at F${frame + 1}")
    }

    fun resetCameraKeyframes() {
        mutateActiveScene { it.copy(cameraKeyframes = listOf(CameraKeyframe(frame = 0))) }
        showToast("Reset camera motion")
    }

    // ─── Audio Studio ───────────────────────────────────────────────

    fun startVoiceRecording() {
        if (_uiState.value.isRecordingVoice) return
        _uiState.update { it.copy(isRecordingVoice = true, voiceAmplitude = 0f) }
        voiceJob = viewModelScope.launch {
            audioEngine.recordVoiceToWav(
                onAmplitude = { amp -> _uiState.update { it.copy(voiceAmplitude = amp) } },
                onFinished = { track ->
                    _uiState.update { it.copy(isRecordingVoice = false, voiceAmplitude = 0f) }
                    if (track != null) {
                        val positioned = track.copy(startFrame = _uiState.value.currentFrame)
                        mutateProject { p -> p.copy(audioTracks = p.audioTracks + positioned) }
                        showToast("Recorded voice track")
                    } else {
                        showToast("Recording too short or mic unavailable")
                    }
                }
            )
        }
    }

    fun stopVoiceRecording() {
        audioEngine.stopVoiceRecording()
    }

    fun addBuiltInAudioPreset(preset: BuiltInAudioPreset) {
        viewModelScope.launch {
            val track = audioEngine.synthesizeBuiltInPreset(preset, _uiState.value.currentFrame)
            mutateProject { p -> p.copy(audioTracks = p.audioTracks + track) }
            audioEngine.previewTrack(track)
            showToast("Added ${preset.title}")
        }
    }

    fun importAudioFromUri(uri: Uri, displayName: String) {
        viewModelScope.launch {
            val track = audioEngine.importAudioUri(uri, displayName, _uiState.value.currentFrame)
            if (track != null) {
                mutateProject { p -> p.copy(audioTracks = p.audioTracks + track) }
                showToast("Imported audio \"${track.name}\"")
            } else {
                showToast("Could not import audio file")
            }
        }
    }

    fun updateAudioTrack(updated: AudioTrackItem) {
        mutateProject(recordUndo = false) { p ->
            p.copy(audioTracks = p.audioTracks.map { if (it.id == updated.id) updated else it })
        }
    }

    fun deleteAudioTrack(trackId: String) {
        mutateProject { p -> p.copy(audioTracks = p.audioTracks.filterNot { it.id == trackId }) }
    }

    fun previewAudioTrack(track: AudioTrackItem) = audioEngine.previewTrack(track)

    fun applyVoiceEffectToTrack(track: AudioTrackItem, effect: VoiceEffectType) {
        viewModelScope.launch {
            val updated = audioEngine.applyVoiceEffect(track, effect)
            mutateProject(recordUndo = false) { p ->
                p.copy(audioTracks = p.audioTracks.map { if (it.id == updated.id) updated else it })
            }
            audioEngine.previewTrack(updated)
            showToast("Voice FX: ${effect.label}")
        }
    }

    // ─── Local Offline Export ───────────────────────────────────────

    fun runLocalExport(settings: ExportSettings) {
        val proj = _uiState.value.activeProject ?: return
        val scene = _uiState.value.activeScene ?: return
        stopPlayback()
        _uiState.update { it.copy(isExporting = true, exportProgress = 0.05f, exportStatus = "Preparing renderer...", lastExportResult = null) }

        viewModelScope.launch {
            val res = exportEngine.exportScene(
                project = proj,
                scene = scene,
                settings = settings,
                currentFrame = _uiState.value.currentFrame,
                onProgress = { prog, status ->
                    _uiState.update { it.copy(exportProgress = prog, exportStatus = status) }
                }
            )
            _uiState.update {
                it.copy(
                    isExporting = false,
                    exportProgress = if (res.success) 1f else 0f,
                    exportStatus = res.message,
                    lastExportResult = res
                )
            }
        }
    }

    fun saveExportFileToUri(sourceFile: File, targetUri: Uri) {
        viewModelScope.launch {
            val ok = exportEngine.copyExportFileToUri(sourceFile, targetUri)
            showToast(if (ok) "Saved to phone storage" else "Could not save file")
        }
    }

    fun clearExportResult() = _uiState.update { it.copy(lastExportResult = null, exportStatus = "", exportProgress = 0f) }

    // ─── Modules 2, 4, 6: Stretch Rig, Bone Scaling/Spring, Hand Gestures, Eyebrows & Auto-Dialogue ───

    fun toggleStretchRigMode() {
        val next = !_uiState.value.stretchRigMode
        _uiState.update { it.copy(stretchRigMode = next) }
        showToast(if (next) "Stretch Rig ON: drag joints to stretch limbs!" else "Stretch Rig OFF")
    }

    fun updateSelectedBoneScaleAndSpring(
        boneId: String,
        length: Float? = null,
        widthScale: Float? = null,
        lengthScale: Float? = null,
        springStiffness: Float? = null,
        springDamping: Float? = null
    ) {
        mutateSelectedLayer(recordUndo = false) { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val updatedBones = rig.bones.map { b ->
                if (b.id == boneId) {
                    b.copy(
                        length = (length ?: b.length).coerceIn(8f, 450f),
                        limbWidthScale = (widthScale ?: b.limbWidthScale).coerceIn(0.2f, 4.0f),
                        limbLengthScale = (lengthScale ?: b.limbLengthScale).coerceIn(0.2f, 4.0f),
                        springStiffness = (springStiffness ?: b.springStiffness).coerceIn(0f, 1f),
                        springDamping = (springDamping ?: b.springDamping).coerceIn(0.05f, 1f)
                    )
                } else b
            }
            l.copy(rig = rig.copy(bones = updatedBones))
        }
    }

    fun updateStudioDraftBoneScaleAndSpring(
        boneId: String,
        length: Float? = null,
        widthScale: Float? = null,
        lengthScale: Float? = null,
        springStiffness: Float? = null,
        springDamping: Float? = null
    ) {
        updateStudioDraftRig { rig ->
            rig.copy(
                bones = rig.bones.map { b ->
                    if (b.id == boneId) {
                        b.copy(
                            length = (length ?: b.length).coerceIn(8f, 450f),
                            limbWidthScale = (widthScale ?: b.limbWidthScale).coerceIn(0.2f, 4.0f),
                            limbLengthScale = (lengthScale ?: b.limbLengthScale).coerceIn(0.2f, 4.0f),
                            springStiffness = (springStiffness ?: b.springStiffness).coerceIn(0f, 1f),
                            springDamping = (springDamping ?: b.springDamping).coerceIn(0.05f, 1f)
                        )
                    } else b
                }
            )
        }
    }

    fun setPuppetHandGesture(isRightHand: Boolean, pose: HandGesturePose) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val nextLeft = if (!isRightHand) pose.name else eval.leftHandGesture
            val nextRight = if (isRightHand) pose.name else eval.rightHandGesture
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = eval.eyePack,
                eyebrowStyle = eval.eyebrowStyle,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = nextLeft,
                rightHandGesture = nextRight,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(
                rig = rig.copy(
                    leftHandGesture = nextLeft,
                    rightHandGesture = nextRight,
                    rootKeyframes = nextKeys
                )
            )
        }
        showToast("${if (isRightHand) "Right" else "Left"} Hand: ${pose.label} (F${frame + 1})")
    }

    fun setPuppetEyebrow(style: EyebrowStyle) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = eval.eyePack,
                eyebrowStyle = style.name,
                mouthPhoneme = eval.mouthPhoneme,
                leftHandGesture = eval.leftHandGesture,
                rightHandGesture = eval.rightHandGesture,
                behaviorPreset = eval.behaviorPreset,
                easing = easing
            )
            val nextKeys = (rig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            l.copy(rig = rig.copy(eyebrowStyle = style.name, rootKeyframes = nextKeys))
        }
        showToast("Eyebrows: ${style.label} (F${frame + 1})")
    }

    fun applySelectedBonePartBehaviorPreset(boneId: String, preset: PartBehaviorPreset) {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(
                rig = rig.copy(
                    bones = rig.bones.map { b ->
                        if (b.id == boneId) RigSolver.applyPartBehaviorPreset(b, preset) else b
                    }
                )
            )
        }
        showToast("Part Behavior: ${preset.label} (${preset.subtitle})")
    }

    /**
     * Keyframeable Front/Back Z-Order switching during animation:
     * Records the updated draw order at [currentFrame] so a limb/part can move behind the torso
     * on one frame and come in front of the chest on a later frame!
     */
    fun adjustSelectedLayerBoneZOrder(boneId: String, action: BoneZOrderAction) {
        val frame = _uiState.value.currentFrame
        var boneName = "Part"
        var nextZ = 0
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val currentMap = InterpolationEngine.evaluateBoneZOrders(rig, frame)
            val updatedMap = RigSolver.adjustBoneZOrderMap(rig.bones, currentMap, boneId, action)
            boneName = rig.bones.firstOrNull { it.id == boneId }?.name ?: "Part"
            nextZ = updatedMap[boneId] ?: 0
            val nextKeyframes = rig.boneZOrderKeyframes.toMutableMap()
            // Preserve frame 0 initial order automatically when creating the first mid-scene switch
            if (frame > 0 && nextKeyframes.isEmpty()) {
                nextKeyframes["0"] = rig.bones.associate { it.id to it.zOrder }
            }
            nextKeyframes[frame.toString()] = updatedMap
            val updatedBaseBones = if (frame == 0) {
                rig.bones.map { b -> b.copy(zOrder = updatedMap[b.id] ?: b.zOrder) }
            } else rig.bones
            l.copy(
                rig = rig.copy(
                    bones = updatedBaseBones,
                    boneZOrderKeyframes = nextKeyframes
                )
            )
        }
        selectBone(boneId)
        val label = when (action) {
            BoneZOrderAction.BRING_FORWARD -> "Forward (+1)"
            BoneZOrderAction.SEND_BACKWARD -> "Backward (-1)"
            BoneZOrderAction.BRING_TO_FRONT -> "Front (Top)"
            BoneZOrderAction.SEND_TO_BACK -> "Back (Bottom)"
        }
        showToast("$boneName → $label (Z:$nextZ • Keyframed F${frame + 1})")
    }

    fun applySelectedLayerAutoHumanLayerOrder() {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val autoRig = RigSolver.applyAutoHumanLayerOrder(rig)
            val autoMap = autoRig.bones.associate { it.id to it.zOrder }
            val nextKeyframes = rig.boneZOrderKeyframes.toMutableMap()
            if (frame > 0) {
                if (nextKeyframes.isEmpty()) {
                    nextKeyframes["0"] = rig.bones.associate { it.id to it.zOrder }
                }
                nextKeyframes[frame.toString()] = autoMap
                l.copy(rig = rig.copy(boneZOrderKeyframes = nextKeyframes))
            } else {
                if (nextKeyframes.isNotEmpty()) nextKeyframes["0"] = autoMap
                l.copy(rig = autoRig.copy(boneZOrderKeyframes = nextKeyframes))
            }
        }
        showToast(if (frame > 0) "Auto Human Layer Order Keyframed at F${frame + 1}" else "Applied Auto Human Layer Order!")
    }

    fun clearSelectedLayerZOrderKeyframeAtCurrentFrame() {
        val frame = _uiState.value.currentFrame
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(boneZOrderKeyframes = rig.boneZOrderKeyframes - frame.toString()))
        }
        showToast("Cleared Z-Order keyframe at F${frame + 1}")
    }

    fun setPuppetBehaviorPreset(preset: CharacterBehaviorPreset) {
        val frame = _uiState.value.currentFrame
        val easing = _uiState.value.activeEasing.name
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val eval = InterpolationEngine.evaluatePuppetRoot(rig, frame)
            val updatedRig = applyBehaviorPresetToRig(rig, preset)
            val kf = PuppetRootKeyframe(
                frame = frame,
                rootX = eval.rootX,
                rootY = eval.rootY,
                scale = eval.scale,
                scaleX = eval.scaleX,
                scaleY = eval.scaleY,
                flippedHorizontal = eval.flippedHorizontal,
                viewAngle = eval.viewAngle,
                eyePack = updatedRig.eyePack,
                eyebrowStyle = updatedRig.eyebrowStyle,
                mouthPhoneme = updatedRig.mouthPhoneme,
                leftHandGesture = updatedRig.leftHandGesture,
                rightHandGesture = updatedRig.rightHandGesture,
                behaviorPreset = preset.name,
                easing = easing
            )
            val nextKeys = (updatedRig.rootKeyframes.filterNot { it.frame == frame } + kf).sortedBy { it.frame }
            val nextRimLight = when (preset) {
                CharacterBehaviorPreset.HORROR_GHOSTLY -> l.rimLightColorArgb ?: 0xFFA5F3FCL
                CharacterBehaviorPreset.NORMAL_CALM -> if (l.rimLightColorArgb == 0xFFA5F3FCL) null else l.rimLightColorArgb
                else -> l.rimLightColorArgb
            }
            l.copy(
                rig = updatedRig.copy(rootKeyframes = nextKeys),
                rimLightColorArgb = nextRimLight
            )
        }
        showToast("Behavior: ${preset.label} (Keyframed F${frame + 1})")
    }

    fun togglePuppetAutoDialogueActing() {
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            l.copy(rig = rig.copy(autoDialogueActing = !rig.autoDialogueActing))
        }
        val enabled = _uiState.value.selectedLayer?.rig?.autoDialogueActing == true
        showToast(if (enabled) "Auto-Dialogue Acting ON (Head bob + gestures)" else "Auto-Dialogue Acting OFF")
    }

    fun setStudioDraftHandGesture(isRightHand: Boolean, pose: HandGesturePose) {
        updateStudioDraftRig { rig ->
            if (isRightHand) rig.copy(rightHandGesture = pose.name)
            else rig.copy(leftHandGesture = pose.name)
        }
    }

    fun setStudioDraftEyebrow(style: EyebrowStyle) {
        updateStudioDraftRig { it.copy(eyebrowStyle = style.name) }
    }

    fun updateSelectedRigCharacterAppearance(transform: (CharacterSpec) -> CharacterSpec) {
        mutateSelectedLayer(recordUndo = false) { l ->
            val rig = l.rig
            if (rig != null) {
                val base = rig.characterAppearance ?: ProceduralSmartTools.characterPresets.first()
                l.copy(rig = rig.copy(characterAppearance = transform(base)))
            } else if (l.character != null) {
                l.copy(character = transform(l.character))
            } else l
        }
    }

    // ─── Module 7: Dedicated Frame-by-Frame Cel Studio ───────────────────

    fun openCelStudio() {
        val proj = _uiState.value.activeProject
        if (proj == null) {
            createNewProject(
                name = "Cel Animation",
                width = 1280,
                height = 720,
                fps = 12,
                template = StoryboardTemplate.BLANK_STUDIO
            )
        }
        val scene = _uiState.value.activeScene ?: return
        var celLayer = scene.layers.firstOrNull { it.isCelFrameByFrame && it.type == LayerType.DRAWING.name }
        if (celLayer == null) {
            val newCel = AnimationLayer(
                name = "Cel Animation Track",
                type = LayerType.DRAWING.name,
                isCelFrameByFrame = true
            )
            mutateActiveScene { s -> s.copy(layers = s.layers + newCel) }
            celLayer = newCel
        }
        _uiState.update {
            it.copy(
                destination = StudioDestination.CEL_STUDIO,
                celLayerId = celLayer.id,
                selectedLayerId = celLayer.id,
                selectedTrackKind = TrackSelectionKind.LAYER,
                activeTool = EditorTool.BRUSH,
                onionSkinEnabled = true,
                showRigOverlay = false
            )
        }
    }

    fun closeCelStudio() {
        stopPlayback()
        _uiState.update { it.copy(destination = StudioDestination.EDITOR) }
    }

    fun celStepFrame(delta: Int) {
        val scene = _uiState.value.activeScene ?: return
        val maxF = (scene.durationFrames - 1).coerceAtLeast(0)
        val next = (_uiState.value.currentFrame + delta).coerceIn(0, maxF)
        _uiState.update { it.copy(currentFrame = next) }
    }

    fun toggleCelOnionNext() {
        _uiState.update { it.copy(celOnionNextEnabled = !it.celOnionNextEnabled) }
    }

    fun setCelOnionOpacity(opacity: Float) {
        _uiState.update { it.copy(celOnionOpacity = opacity.coerceIn(0.08f, 0.75f)) }
    }

    // ─── Module 8: Frame-Range Visibility, Targeted Loops, Custom Actions, Live Record & Auto-Actions ───

    fun setTimelineRange(start: Int, end: Int) {
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 96) - 1).coerceAtLeast(1)
        val s = start.coerceIn(0, maxF)
        val e = end.coerceIn(s, maxF)
        _uiState.update { it.copy(rangeStartFrame = s, rangeEndFrame = e) }
    }

    fun hideSelectedLayerFromCurrentFrame() {
        val frame = _uiState.value.currentFrame
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 96) - 1).coerceAtLeast(0)
        mutateSelectedLayer { l ->
            val currentRanges = if (l.visibilityRanges.isEmpty()) {
                listOf(FrameVisibilityRange(0, maxF))
            } else l.visibilityRanges
            val trimmed = currentRanges.mapNotNull { r ->
                when {
                    r.endFrame < frame -> r
                    r.startFrame >= frame -> null
                    else -> r.copy(endFrame = (frame - 1).coerceAtLeast(r.startFrame))
                }
            }
            l.copy(visibilityRanges = if (trimmed.isEmpty() && frame > 0) listOf(FrameVisibilityRange(0, frame - 1)) else trimmed)
        }
        showToast("Hidden from F${frame + 1} onward")
    }

    fun showSelectedLayerFromCurrentFrame() {
        val frame = _uiState.value.currentFrame
        val maxF = ((_uiState.value.activeScene?.durationFrames ?: 96) - 1).coerceAtLeast(frame)
        mutateSelectedLayer { l ->
            val next = l.visibilityRanges + FrameVisibilityRange(frame, maxF)
            l.copy(visibilityRanges = next.sortedBy { it.startFrame })
        }
        showToast("Visible from F${frame + 1} to F${maxF + 1}")
    }

    fun setSelectedLayerVisibleRange(startFrame: Int, endFrame: Int) {
        val s = startFrame.coerceAtLeast(0)
        val e = endFrame.coerceAtLeast(s)
        mutateSelectedLayer { l ->
            l.copy(visibilityRanges = listOf(FrameVisibilityRange(s, e)))
        }
        showToast("Visible only on F${s + 1}–F${e + 1}")
    }

    fun clearSelectedLayerVisibilityRanges() {
        mutateSelectedLayer { l -> l.copy(visibilityRanges = emptyList()) }
        showToast("Visible across entire scene")
    }

    fun applyTargetedLoopToSelectedLayer(type: TargetedLoopType, startFrame: Int, endFrame: Int) {
        val s = startFrame.coerceAtLeast(0)
        val e = endFrame.coerceAtLeast(s + 1)
        val clip = TargetedLoopClip(
            loopType = type.name,
            startFrame = s,
            endFrame = e
        )
        mutateSelectedLayer { l ->
            l.copy(targetedLoops = l.targetedLoops + clip)
        }
        showToast("Applied ${type.label} on F${s + 1}–F${e + 1}")
    }

    fun removeTargetedLoopFromSelectedLayer(loopId: String) {
        mutateSelectedLayer { l ->
            l.copy(targetedLoops = l.targetedLoops.filterNot { it.id == loopId })
        }
    }

    fun saveSelectedRangeAsCustomAction(actionName: String) {
        val state = _uiState.value
        val rig = state.selectedLayer?.rig ?: run {
            showToast("Select a rigged character first")
            return
        }
        val start = state.rangeStartFrame.coerceAtLeast(0)
        val end = state.rangeEndFrame.coerceAtLeast(start + 1)
        val poses = rig.poseKeyframes.mapNotNull { (k, v) ->
            val f = k.toIntOrNull() ?: return@mapNotNull null
            if (f in start..end) (f - start).toString() to v else null
        }.toMap().ifEmpty {
            mapOf("0" to InterpolationEngine.evaluateRigAngles(rig, start))
        }
        val lengths = rig.boneLengthKeyframes.mapNotNull { (k, v) ->
            val f = k.toIntOrNull() ?: return@mapNotNull null
            if (f in start..end) (f - start).toString() to v else null
        }.toMap()
        val zOrders = rig.boneZOrderKeyframes.mapNotNull { (k, v) ->
            val f = k.toIntOrNull() ?: return@mapNotNull null
            if (f in start..end) (f - start).toString() to v else null
        }.toMap()
        val baseRoot = InterpolationEngine.evaluatePuppetRoot(rig, start)
        val rootKfs = rig.rootKeyframes.filter { it.frame in start..end }.map { kf ->
            kf.copy(
                frame = kf.frame - start,
                rootX = kf.rootX - baseRoot.rootX,
                rootY = kf.rootY - baseRoot.rootY
            )
        }
        val clip = CustomActionClip(
            name = actionName.trim().ifBlank { "Custom Action" },
            durationFrames = (end - start + 1).coerceAtLeast(2),
            poseKeyframes = poses,
            boneLengthKeyframes = lengths,
            boneZOrderKeyframes = zOrders,
            rootKeyframes = rootKfs
        )
        viewModelScope.launch {
            repository.saveCustomAction(clip)
            showToast("Saved Custom Action \"${clip.name}\" (${clip.durationFrames}f)")
        }
    }

    fun applyCustomActionToSelectedLayer(clip: CustomActionClip) {
        val start = _uiState.value.currentFrame
        mutateSelectedLayer { l ->
            val rig = l.rig ?: return@mutateSelectedLayer l
            val anchor = InterpolationEngine.evaluatePuppetRoot(rig, start)
            val mergedPoses = rig.poseKeyframes.toMutableMap()
            clip.poseKeyframes.forEach { (k, v) ->
                val rel = k.toIntOrNull() ?: return@forEach
                mergedPoses[(start + rel).toString()] = v
            }
            val mergedLengths = rig.boneLengthKeyframes.toMutableMap()
            clip.boneLengthKeyframes.forEach { (k, v) ->
                val rel = k.toIntOrNull() ?: return@forEach
                mergedLengths[(start + rel).toString()] = v
            }
            val mergedZOrders = rig.boneZOrderKeyframes.toMutableMap()
            clip.boneZOrderKeyframes.forEach { (k, v) ->
                val rel = k.toIntOrNull() ?: return@forEach
                mergedZOrders[(start + rel).toString()] = v
            }
            val shiftedRoots = clip.rootKeyframes.map { kf ->
                kf.copy(
                    frame = start + kf.frame,
                    rootX = anchor.rootX + kf.rootX,
                    rootY = anchor.rootY + kf.rootY
                )
            }
            val shiftedFrames = shiftedRoots.map { it.frame }.toSet()
            val mergedRoots = (rig.rootKeyframes.filterNot { it.frame in shiftedFrames } + shiftedRoots)
                .sortedBy { it.frame }
            l.copy(
                rig = rig.copy(
                    poseKeyframes = mergedPoses,
                    boneLengthKeyframes = mergedLengths,
                    boneZOrderKeyframes = mergedZOrders,
                    rootKeyframes = mergedRoots
                )
            )
        }
        showToast("Applied \"${clip.name}\" at F${start + 1}!")
    }

    fun deleteCustomAction(id: String) {
        viewModelScope.launch {
            repository.deleteCustomAction(id)
            showToast("Deleted Custom Action")
        }
    }

    fun toggleLiveRecordMode() {
        val next = !_uiState.value.liveRecordMode
        _uiState.update { it.copy(liveRecordMode = next) }
        showToast(if (next) "Live Record ON — tap acting pads while playing!" else "Live Record OFF")
    }

    fun recordLiveActingPad(actionKey: String) {
        val frame = _uiState.value.currentFrame
        when (actionKey) {
            "TALK" -> setPuppetMouthPhoneme(MouthPhoneme.TALKING_LOOP)
            "BLINK" -> setPuppetEyePack(EyePackStyle.WINK)
            "LAUGH" -> {
                setPuppetEyePack(EyePackStyle.LAUGHING)
                setPuppetMouthPhoneme(MouthPhoneme.LAUGHING)
            }
            "CRY" -> {
                setPuppetEyePack(EyePackStyle.SAD_TEARS)
                setPuppetEyebrow(EyebrowStyle.WORRIED)
                setPuppetMouthPhoneme(MouthPhoneme.CRYING)
            }
            "ANGRY" -> {
                setPuppetEyePack(EyePackStyle.ANGRY)
                setPuppetEyebrow(EyebrowStyle.ANGRY)
                setPuppetMouthPhoneme(MouthPhoneme.SCARED)
            }
            "SHOCK" -> {
                setPuppetEyePack(EyePackStyle.SURPRISED)
                setPuppetEyebrow(EyebrowStyle.RAISED)
                setPuppetMouthPhoneme(MouthPhoneme.SHOCK)
            }
            "WAVE" -> {
                setPuppetHandGesture(isRightHand = true, pose = HandGesturePose.OPEN_PALM)
                mutateSelectedLayer(recordUndo = false) { l ->
                    val rig = l.rig ?: return@mutateSelectedLayer l
                    val angles = InterpolationEngine.evaluateRigAngles(rig, frame).toMutableMap()
                    angles["arm_r_up"] = -75f
                    angles["arm_r_low"] = -55f
                    l.copy(rig = rig.copy(poseKeyframes = rig.poseKeyframes + (frame.toString() to angles)))
                }
            }
            "NAMASTE" -> {
                setPuppetHandGesture(isRightHand = false, pose = HandGesturePose.NAMASTE)
                setPuppetHandGesture(isRightHand = true, pose = HandGesturePose.NAMASTE)
                mutateSelectedLayer(recordUndo = false) { l ->
                    val rig = l.rig ?: return@mutateSelectedLayer l
                    val angles = InterpolationEngine.evaluateRigAngles(rig, frame).toMutableMap()
                    angles["arm_l_up"] = 58f
                    angles["arm_l_low"] = -112f
                    angles["arm_r_up"] = 122f
                    angles["arm_r_low"] = 112f
                    l.copy(rig = rig.copy(poseKeyframes = rig.poseKeyframes + (frame.toString() to angles)))
                }
            }
        }
    }

    fun applyAutoAction(kind: AutoActionKind) {
        val start = _uiState.value.currentFrame
        val selId = _uiState.value.selectedLayer?.id ?: return
        mutateActiveScene { s ->
            ProceduralSmartTools.applyAutoActionToLayer(s, selId, start, kind)
        }
        showToast("Generated ${kind.label} at F${start + 1}!")
    }

    fun toggleAudioAutoDuck(trackId: String) {
        mutateProject { p ->
            p.copy(
                audioTracks = p.audioTracks.map {
                    if (it.id == trackId) it.copy(autoDuckMusic = !it.autoDuckMusic) else it
                }
            )
        }
        val on = _uiState.value.activeProject?.audioTracks?.firstOrNull { it.id == trackId }?.autoDuckMusic == true
        showToast(if (on) "Auto-Duck Music ON (ducks under voice)" else "Auto-Duck Music OFF")
    }

    // ─── Module 9: Multi-Plane Depth Blur, Camera Follow, Layer Effects, Spotlight & Watermark ───

    fun setSceneDepthBlur(blur: Float) {
        mutateActiveScene(recordUndo = false) { it.copy(backgroundDepthBlur = blur.coerceIn(0f, 1f)) }
    }

    fun toggleSceneForegroundPlane() {
        mutateActiveScene { it.copy(foregroundPlaneEnabled = !it.foregroundPlaneEnabled) }
    }

    fun setSceneCameraFollow(layerId: String?) {
        mutateActiveScene { it.copy(cameraFollowLayerId = layerId) }
        showToast(if (layerId == null) "Camera Follow OFF" else "Camera Following Selected Character!")
    }

    fun updateSelectedLayerEffects(
        groundShadow: Boolean? = null,
        rimLightColorArgb: Long? = null,
        clearRimLight: Boolean = false,
        maskToLayerBelow: Boolean? = null,
        motionBlurStrength: Float? = null
    ) {
        mutateSelectedLayer { l ->
            l.copy(
                groundShadowEnabled = groundShadow ?: l.groundShadowEnabled,
                rimLightColorArgb = when {
                    clearRimLight -> 0L
                    rimLightColorArgb != null -> rimLightColorArgb
                    else -> l.rimLightColorArgb
                },
                maskToLayerBelow = maskToLayerBelow ?: l.maskToLayerBelow,
                motionBlurStrength = (motionBlurStrength ?: l.motionBlurStrength).coerceIn(0f, 1f)
            )
        }
    }

    fun updateSceneSpotlight(
        enabled: Boolean? = null,
        x: Float? = null,
        y: Float? = null,
        radius: Float? = null,
        intensity: Float? = null,
        colorArgb: Long? = null
    ) {
        mutateActiveScene(recordUndo = false) { s ->
            s.copy(
                spotlightEnabled = enabled ?: s.spotlightEnabled,
                spotlightX = (x ?: s.spotlightX).coerceIn(0f, 1f),
                spotlightY = (y ?: s.spotlightY).coerceIn(0f, 1f),
                spotlightRadius = (radius ?: s.spotlightRadius).coerceIn(0.15f, 1.0f),
                spotlightIntensity = (intensity ?: s.spotlightIntensity).coerceIn(0.05f, 1.0f),
                spotlightColorArgb = colorArgb ?: s.spotlightColorArgb
            )
        }
    }

    fun updateSceneWatermark(
        text: String? = null,
        opacity: Float? = null,
        corner: String? = null,
        clear: Boolean = false
    ) {
        mutateActiveScene { s ->
            if (clear) {
                s.copy(watermarkText = "", watermarkImagePath = null)
            } else {
                s.copy(
                    watermarkText = text ?: s.watermarkText,
                    watermarkOpacity = (opacity ?: s.watermarkOpacity).coerceIn(0.1f, 1f),
                    watermarkCorner = corner ?: s.watermarkCorner
                )
            }
        }
    }

    fun importWatermarkLogoFromUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val path = copyPickedImageToLocalFile(uri, "watermark_logo")
            withContext(Dispatchers.Main) {
                if (path != null) {
                    mutateActiveScene { it.copy(watermarkImagePath = path) }
                    showToast("Added Channel Logo Watermark!")
                } else {
                    showToast("Could not load logo image")
                }
            }
        }
    }

    fun showToast(message: String) {
        _uiState.update { it.copy(statusBanner = message) }
        viewModelScope.launch {
            delay(2600)
            _uiState.update { if (it.statusBanner == message) it.copy(statusBanner = null) else it }
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stopVoiceRecording()
        audioEngine.stopAllPlayback()
        playbackJob?.cancel()
    }
}
