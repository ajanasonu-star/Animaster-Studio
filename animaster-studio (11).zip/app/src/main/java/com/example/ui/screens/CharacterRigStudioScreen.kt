package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material.icons.filled.VerticalAlignTop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.HandGesturePose
import com.example.data.model.HandPropKind
import com.example.data.model.MouthPhoneme
import com.example.data.model.PartBehaviorPreset
import com.example.data.model.RigBone
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import com.example.engine.EvaluatedPuppetRoot
import com.example.engine.InterpolationEngine
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioMint
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.StudioViewModel
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

import com.example.engine.BoneZOrderAction

private enum class RigStudioTab(val label: String) {
    BUILD("Build"),
    PARTS_MESH("PNG Parts & Mesh"),
    PART_LAYERS("Part Layers"),
    FACE_RIG("Eyes & Mouth"),
    BONES("Skeleton & Custom")
}

private enum class RigStageMode(val label: String) {
    POSE_IK("Pose IK"),
    MOVE_SCALE_PNG("Squish & Fit PNG"),
    PLACE_FACE("Fit Face"),
    TAP_ADD_BONE("Tap +Bone")
}

private enum class PngHandleDragMode {
    MOVE,
    CORNER_SCALE,
    EDGE_SCALE_X,
    EDGE_SCALE_Y
}

@Composable
fun CharacterRigStudioScreen(
    uiState: StudioUiState,
    viewModel: StudioViewModel,
    onPickImageForBone: (boneId: String) -> Unit,
    onPickSingleMeshImage: () -> Unit,
    onPickHandPropPng: (isRightHand: Boolean) -> Unit,
    onExportRigBackup: () -> Unit = {},
    onImportRigBackup: () -> Unit = {}
) {
    BackHandler { viewModel.closeCharacterRigStudio() }

    var activeTab by remember { mutableStateOf(RigStudioTab.BUILD) }
    var stageMode by remember { mutableStateOf(RigStageMode.POSE_IK) }
    val rig = uiState.studioDraftRig
    val hasActiveProject = uiState.activeProject != null

    Scaffold(
        containerColor = ObsidianBg,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            RigStudioTopBar(
                rigName = rig.name,
                isAssetDraft = rig.rigCategory == "ASSET",
                hasActiveProject = hasActiveProject,
                onBack = { viewModel.closeCharacterRigStudio() },
                onSaveOnly = { viewModel.saveStudioDraftToMyCharacters(alsoImportToScene = false) },
                onSaveAsAsset = { viewModel.saveStudioDraftAsCustomAsset(alsoInsertToScene = false) },
                onSaveAndImport = {
                    if (rig.rigCategory == "ASSET") {
                        viewModel.saveStudioDraftAsCustomAsset(alsoInsertToScene = true)
                    } else {
                        viewModel.saveStudioDraftToMyCharacters(alsoImportToScene = true)
                    }
                },
                onExportRigBackup = onExportRigBackup,
                onImportRigBackup = onImportRigBackup
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWide = maxWidth >= 700.dp

            if (isWide) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RigStudioStagePanel(
                        rig = rig,
                        selectedBoneId = uiState.studioDraftSelectedBoneId,
                        onionSkin = uiState.studioDraftOnionSkin,
                        testFrame = uiState.studioDraftTestFrame,
                        isPlaying = uiState.studioDraftPlaying,
                        stretchRigMode = uiState.stretchRigMode,
                        stageMode = stageMode,
                        onSelectStageMode = { stageMode = it },
                        viewModel = viewModel,
                        modifier = Modifier
                            .weight(1.15f)
                            .fillMaxHeight()
                    )
                    RigStudioWorkbenchPanel(
                        rig = rig,
                        selectedBoneId = uiState.studioDraftSelectedBoneId,
                        activeTab = activeTab,
                        stageMode = stageMode,
                        onSelectTab = { activeTab = it },
                        onSelectStageMode = { stageMode = it },
                        viewModel = viewModel,
                        onPickImageForBone = onPickImageForBone,
                        onPickSingleMeshImage = onPickSingleMeshImage,
                        onPickHandPropPng = onPickHandPropPng,
                        modifier = Modifier
                            .weight(0.95f)
                            .fillMaxHeight()
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    RigStudioStagePanel(
                        rig = rig,
                        selectedBoneId = uiState.studioDraftSelectedBoneId,
                        onionSkin = uiState.studioDraftOnionSkin,
                        testFrame = uiState.studioDraftTestFrame,
                        isPlaying = uiState.studioDraftPlaying,
                        stretchRigMode = uiState.stretchRigMode,
                        stageMode = stageMode,
                        onSelectStageMode = { stageMode = it },
                        viewModel = viewModel,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.47f)
                    )
                    RigStudioWorkbenchPanel(
                        rig = rig,
                        selectedBoneId = uiState.studioDraftSelectedBoneId,
                        activeTab = activeTab,
                        stageMode = stageMode,
                        onSelectTab = { activeTab = it },
                        onSelectStageMode = { stageMode = it },
                        viewModel = viewModel,
                        onPickImageForBone = onPickImageForBone,
                        onPickSingleMeshImage = onPickSingleMeshImage,
                        onPickHandPropPng = onPickHandPropPng,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.53f)
                    )
                }
            }

            uiState.statusBanner?.let { banner ->
                Surface(
                    color = PanelElevated.copy(alpha = 0.96f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCoral),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp)
                ) {
                    Text(
                        text = banner,
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RigStudioTopBar(
    rigName: String,
    isAssetDraft: Boolean,
    hasActiveProject: Boolean,
    onBack: () -> Unit,
    onSaveOnly: () -> Unit,
    onSaveAsAsset: () -> Unit,
    onSaveAndImport: () -> Unit,
    onExportRigBackup: () -> Unit = {},
    onImportRigBackup: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelSurface)
            .border(1.dp, StudioBorder)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(44.dp)
                .testTag("char_studio_back_btn")
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = StudioTextPrimary)
        }
        Icon(Icons.Default.AccessibilityNew, contentDescription = null, tint = StudioViolet, modifier = Modifier.size(22.dp))
        Column {
            Text(
                if (isAssetDraft) "Custom Asset & Rig Studio" else "Character & Rig Studio",
                color = StudioTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1
            )
            Text(
                rigName.ifBlank { "Untitled Puppet" },
                color = StudioCyan,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.width(8.dp))

        Button(
            onClick = onSaveOnly,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = StudioCyan),
            modifier = Modifier
                .height(40.dp)
                .testTag("save_to_my_characters_btn")
        ) {
            Icon(Icons.Default.BookmarkAdded, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Text("Save Character", color = Color(0xFF080B12), fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }

        Button(
            onClick = onSaveAsAsset,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = StudioMint),
            modifier = Modifier
                .height(40.dp)
                .testTag("save_as_custom_asset_btn")
        ) {
            Icon(Icons.Default.Layers, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Text("Save as Asset", color = Color(0xFF080B12), fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }

        if (hasActiveProject) {
            Button(
                onClick = onSaveAndImport,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                modifier = Modifier
                    .height(40.dp)
                    .testTag("save_and_import_to_scene_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Use in Scene", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
        OutlinedButton(
            onClick = onExportRigBackup,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.height(40.dp).testTag("export_rig_backup_btn")
        ) {
            Text("Backup", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = onImportRigBackup,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.height(40.dp).testTag("import_rig_backup_btn")
        ) {
            Text("Restore", color = StudioAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RigStudioStagePanel(
    rig: SkeletalRig,
    selectedBoneId: String?,
    onionSkin: Boolean,
    testFrame: Int,
    isPlaying: Boolean,
    stretchRigMode: Boolean,
    stageMode: RigStageMode,
    onSelectStageMode: (RigStageMode) -> Unit,
    viewModel: StudioViewModel,
    modifier: Modifier = Modifier
) {
    val latestRig by rememberUpdatedState(rig)
    val latestSelectedBoneId by rememberUpdatedState(selectedBoneId)
    val latestFrame by rememberUpdatedState(testFrame)
    val latestStageMode by rememberUpdatedState(stageMode)
    val density = LocalDensity.current

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(PanelSurface)
            .border(1.dp, StudioBorder, RoundedCornerShape(16.dp))
    ) {
        // Stage Direct-Manipulation Mode Switcher Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            RigStageMode.entries.forEach { mode ->
                val active = mode == stageMode
                val accent = when (mode) {
                    RigStageMode.POSE_IK -> StudioCoral
                    RigStageMode.MOVE_SCALE_PNG -> StudioCyan
                    RigStageMode.PLACE_FACE -> StudioAmber
                    RigStageMode.TAP_ADD_BONE -> StudioMint
                }
                Surface(
                    color = if (active) accent.copy(alpha = 0.24f) else PanelSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .border(1.dp, if (active) accent else StudioBorder, RoundedCornerShape(8.dp))
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            onSelectStageMode(mode)
                            if (mode == RigStageMode.PLACE_FACE && !rig.showFaceOverlayOnCustomImage && !rig.singleMeshImagePath.isNullOrBlank()) {
                                viewModel.updateStudioDraftRig { it.copy(showFaceOverlayOnCustomImage = true) }
                            }
                        }
                        .testTag("studio_stage_mode_${mode.name.lowercase()}")
                ) {
                    Text(
                        text = mode.label,
                        color = if (active) accent else StudioTextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Live IK / PNG Fit / Face Placement / Custom Bone Tap Stage
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF101522))
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("char_studio_live_stage")
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val w = size.width.toFloat().coerceAtLeast(1f)
                            val h = size.height.toFloat().coerceAtLeast(1f)
                            val scale = min(w / 1280f, h / 720f).coerceAtLeast(0.05f)
                            val ox = (w - 1280f * scale) / 2f
                            val oy = (h - 720f * scale) / 2f
                            fun toLogical(px: Float, py: Float) = Vec2((px - ox) / scale, (py - oy) / scale)

                            // Enforce >= 48dp touch hit-test radius in screen space!
                            val minTouch48dpLogical = with(density) { 48.dp.toPx() } / scale
                            val rigTouchRadius = max(minTouch48dpLogical, 68f)

                            val downPos = toLogical(down.position.x, down.position.y)
                            val curRig = latestRig
                            val mode = latestStageMode
                            val angles = InterpolationEngine.evaluateRigAngles(curRig, latestFrame)
                            val lengths = InterpolationEngine.evaluateBoneLengths(curRig, latestFrame)
                            val effFlip = SceneRenderer.isLeftFacingView(curRig.viewAngle, curRig.flippedHorizontal)

                            // Mode 4: Tap anywhere to add custom parent-child bone onto bird/animal/object PNG
                            if (mode == RigStageMode.TAP_ADD_BONE) {
                                down.consume()
                                viewModel.addStudioBoneAtTap(downPos)
                                // Wait for release
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    if (ev.changes.none { it.pressed }) break
                                }
                                return@awaitEachGesture
                            }

                            var draggingRoot = false
                            var hitBone: String? = null
                            var pngHandleMode = PngHandleDragMode.MOVE
                            var targetPartBoneId: String? = null
                            var targetPartRotRad = 0f
                            var meshCenter = Vec2(curRig.rootX, curRig.rootY)

                            if (mode == RigStageMode.POSE_IK) {
                                val rootDist = hypot(downPos.x - curRig.rootX, downPos.y - curRig.rootY)
                                val solved = RigSolver.solveForwardKinematics(
                                    rig = curRig,
                                    angleOverrides = angles,
                                    rootX = curRig.rootX,
                                    rootY = curRig.rootY,
                                    scale = curRig.scale,
                                    flippedHorizontal = effFlip,
                                    lengthOverrides = lengths
                                )
                                val nearestBone = solved.minByOrNull { sb -> hypot(sb.end.x - downPos.x, sb.end.y - downPos.y) }
                                val boneDist = nearestBone?.let { sb -> hypot(sb.end.x - downPos.x, sb.end.y - downPos.y) } ?: Float.MAX_VALUE

                                if (nearestBone != null && boneDist < rigTouchRadius && boneDist <= rootDist) {
                                    hitBone = nearestBone.bone.id
                                    viewModel.selectStudioDraftBone(hitBone)
                                } else if (rootDist < rigTouchRadius) {
                                    draggingRoot = true
                                } else if (nearestBone != null && boneDist < rigTouchRadius) {
                                    hitBone = nearestBone.bone.id
                                    viewModel.selectStudioDraftBone(hitBone)
                                }
                            } else if (mode == RigStageMode.MOVE_SCALE_PNG) {
                                val selBoneId = latestSelectedBoneId
                                val selBoneObj = curRig.bones.firstOrNull { it.id == selBoneId && !it.boundImagePath.isNullOrBlank() }
                                if (selBoneObj != null) {
                                    val solved = RigSolver.solveForwardKinematics(
                                        rig = curRig,
                                        angleOverrides = angles,
                                        rootX = curRig.rootX,
                                        rootY = curRig.rootY,
                                        scale = curRig.scale,
                                        flippedHorizontal = effFlip,
                                        lengthOverrides = lengths
                                    )
                                    val sb = solved.firstOrNull { it.bone.id == selBoneObj.id }
                                    val partBox = sb?.let { SceneRenderer.computeBoundBonePartBox(it, curRig.scale, effFlip) }
                                    if (partBox != null) {
                                        targetPartBoneId = selBoneObj.id
                                        targetPartRotRad = partBox.rotRad
                                        meshCenter = partBox.center
                                        val hitEdgeX = listOf(partBox.edgeLeft, partBox.edgeRight).any { p ->
                                            hypot(downPos.x - p.x, downPos.y - p.y) < rigTouchRadius
                                        }
                                        val hitEdgeY = listOf(partBox.edgeTop, partBox.edgeBottom).any { p ->
                                            hypot(downPos.x - p.x, downPos.y - p.y) < rigTouchRadius
                                        }
                                        val hitCorner = listOf(partBox.topLeft, partBox.topRight, partBox.bottomLeft, partBox.bottomRight).any { p ->
                                            hypot(downPos.x - p.x, downPos.y - p.y) < rigTouchRadius
                                        }
                                        pngHandleMode = when {
                                            hitEdgeX -> PngHandleDragMode.EDGE_SCALE_X
                                            hitEdgeY -> PngHandleDragMode.EDGE_SCALE_Y
                                            hitCorner -> PngHandleDragMode.CORNER_SCALE
                                            else -> PngHandleDragMode.MOVE
                                        }
                                    }
                                } else if (!curRig.singleMeshImagePath.isNullOrBlank()) {
                                    val rootEval = EvaluatedPuppetRoot(
                                        rootX = curRig.rootX,
                                        rootY = curRig.rootY,
                                        scale = curRig.scale,
                                        flippedHorizontal = curRig.flippedHorizontal,
                                        viewAngle = curRig.viewAngle,
                                        eyePack = curRig.eyePack,
                                        mouthPhoneme = curRig.mouthPhoneme,
                                        behaviorPreset = curRig.behaviorPreset
                                    )
                                    val rect = SceneRenderer.computeSingleMeshRect(curRig, rootEval)
                                    meshCenter = Vec2(rect.centerX(), rect.centerY())
                                    val midX = rect.centerX()
                                    val midY = rect.centerY()
                                    val hitEdgeX = listOf(rect.left to midY, rect.right to midY).any { (ex, ey) ->
                                        hypot(downPos.x - ex, downPos.y - ey) < rigTouchRadius
                                    }
                                    val hitEdgeY = listOf(midX to rect.top, midX to rect.bottom).any { (ex, ey) ->
                                        hypot(downPos.x - ex, downPos.y - ey) < rigTouchRadius
                                    }
                                    val hitCorner = listOf(
                                        rect.left to rect.top,
                                        rect.right to rect.top,
                                        rect.left to rect.bottom,
                                        rect.right to rect.bottom
                                    ).any { (cx, cy) -> hypot(downPos.x - cx, downPos.y - cy) < rigTouchRadius }
                                    pngHandleMode = when {
                                        hitEdgeX -> PngHandleDragMode.EDGE_SCALE_X
                                        hitEdgeY -> PngHandleDragMode.EDGE_SCALE_Y
                                        hitCorner -> PngHandleDragMode.CORNER_SCALE
                                        else -> PngHandleDragMode.MOVE
                                    }
                                }
                            }

                            var lastLogical = downPos
                            var isPinching = false

                            while (true) {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.isEmpty()) break

                                // Two-finger pinch-to-scale for Fit PNG (0.05x..8.0x) and Fit Face (0.2x..4.0x)
                                if (pressed.size >= 2 && (mode == RigStageMode.MOVE_SCALE_PNG || mode == RigStageMode.PLACE_FACE)) {
                                    isPinching = true
                                    val zoomDelta = event.calculateZoom()
                                    val panDelta = event.calculatePan()
                                    if (mode == RigStageMode.MOVE_SCALE_PNG) {
                                        val boneId = targetPartBoneId
                                        if (boneId != null) {
                                            if (zoomDelta != 1f) viewModel.scaleStudioBonePartUniform(boneId, zoomDelta)
                                            if (panDelta.x != 0f || panDelta.y != 0f) {
                                                viewModel.moveStudioBonePartPivot(boneId, panDelta.x / scale, panDelta.y / scale)
                                            }
                                        } else {
                                            if (zoomDelta != 1f) viewModel.scaleStudioSingleMesh(zoomDelta)
                                            if (panDelta.x != 0f || panDelta.y != 0f) {
                                                viewModel.moveStudioSingleMesh(panDelta.x / scale, panDelta.y / scale)
                                            }
                                        }
                                    } else {
                                        if (zoomDelta != 1f) viewModel.scaleStudioFaceOverlay(zoomDelta)
                                        if (panDelta.x != 0f || panDelta.y != 0f) {
                                            viewModel.moveStudioFaceOverlay(panDelta.x / scale, panDelta.y / scale)
                                        }
                                    }
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    continue
                                }

                                if (isPinching) continue

                                val change = pressed.firstOrNull { it.id == down.id } ?: pressed.first()
                                change.consume()
                                val pos = toLogical(change.position.x, change.position.y)
                                val dx = pos.x - lastLogical.x
                                val dy = pos.y - lastLogical.y

                                when (mode) {
                                    RigStageMode.POSE_IK -> {
                                        if (draggingRoot) {
                                            viewModel.moveStudioDraftRoot(pos.x, pos.y)
                                        } else if (hitBone != null) {
                                            viewModel.dragStudioDraftBone(hitBone, pos)
                                        }
                                    }
                                    RigStageMode.MOVE_SCALE_PNG -> {
                                        val boneId = targetPartBoneId
                                        if (boneId != null) {
                                            // Rotate world delta into bone-part local space for accurate Squish/Stretch!
                                            val cosR = kotlin.math.cos(-targetPartRotRad.toDouble()).toFloat()
                                            val sinR = kotlin.math.sin(-targetPartRotRad.toDouble()).toFloat()
                                            val prevLx = (lastLogical.x - meshCenter.x) * cosR - (lastLogical.y - meshCenter.y) * sinR
                                            val prevLy = (lastLogical.x - meshCenter.x) * sinR + (lastLogical.y - meshCenter.y) * cosR
                                            val curLx = (pos.x - meshCenter.x) * cosR - (pos.y - meshCenter.y) * sinR
                                            val curLy = (pos.x - meshCenter.x) * sinR + (pos.y - meshCenter.y) * cosR
                                            when (pngHandleMode) {
                                                PngHandleDragMode.EDGE_SCALE_X -> {
                                                    val fx = (kotlin.math.abs(curLx).coerceAtLeast(10f) / kotlin.math.abs(prevLx).coerceAtLeast(10f)).coerceIn(0.75f, 1.35f)
                                                    viewModel.squishStudioBonePart(boneId, factorX = fx, factorY = 1f)
                                                }
                                                PngHandleDragMode.EDGE_SCALE_Y -> {
                                                    val fy = (kotlin.math.abs(curLy).coerceAtLeast(10f) / kotlin.math.abs(prevLy).coerceAtLeast(10f)).coerceIn(0.75f, 1.35f)
                                                    viewModel.squishStudioBonePart(boneId, factorX = 1f, factorY = fy)
                                                }
                                                PngHandleDragMode.CORNER_SCALE -> {
                                                    val prevDist = hypot(lastLogical.x - meshCenter.x, lastLogical.y - meshCenter.y).coerceAtLeast(10f)
                                                    val curDist = hypot(pos.x - meshCenter.x, pos.y - meshCenter.y).coerceAtLeast(10f)
                                                    val factor = (curDist / prevDist).coerceIn(0.70f, 1.45f)
                                                    viewModel.scaleStudioBonePartUniform(boneId, factor)
                                                }
                                                PngHandleDragMode.MOVE -> {
                                                    val dLx = dx * cosR - dy * sinR
                                                    val dLy = dx * sinR + dy * cosR
                                                    viewModel.moveStudioBonePartPivot(boneId, dLx, dLy)
                                                }
                                            }
                                        } else {
                                            when (pngHandleMode) {
                                                PngHandleDragMode.EDGE_SCALE_X -> {
                                                    val prevAx = kotlin.math.abs(lastLogical.x - meshCenter.x).coerceAtLeast(12f)
                                                    val curAx = kotlin.math.abs(pos.x - meshCenter.x).coerceAtLeast(12f)
                                                    val fx = (curAx / prevAx).coerceIn(0.75f, 1.35f)
                                                    viewModel.squishStudioSingleMesh(factorX = fx, factorY = 1f)
                                                }
                                                PngHandleDragMode.EDGE_SCALE_Y -> {
                                                    val prevAy = kotlin.math.abs(lastLogical.y - meshCenter.y).coerceAtLeast(12f)
                                                    val curAy = kotlin.math.abs(pos.y - meshCenter.y).coerceAtLeast(12f)
                                                    val fy = (curAy / prevAy).coerceIn(0.75f, 1.35f)
                                                    viewModel.squishStudioSingleMesh(factorX = 1f, factorY = fy)
                                                }
                                                PngHandleDragMode.CORNER_SCALE -> {
                                                    val prevDist = hypot(lastLogical.x - meshCenter.x, lastLogical.y - meshCenter.y).coerceAtLeast(10f)
                                                    val curDist = hypot(pos.x - meshCenter.x, pos.y - meshCenter.y).coerceAtLeast(10f)
                                                    val factor = (curDist / prevDist).coerceIn(0.65f, 1.55f)
                                                    viewModel.scaleStudioSingleMesh(factor)
                                                }
                                                PngHandleDragMode.MOVE -> {
                                                    viewModel.moveStudioSingleMesh(dx, dy)
                                                }
                                            }
                                        }
                                    }
                                    RigStageMode.PLACE_FACE -> {
                                        viewModel.moveStudioFaceOverlay(dx, dy)
                                    }
                                    RigStageMode.TAP_ADD_BONE -> Unit
                                }
                                lastLogical = pos
                            }
                        }
                    }
            ) {
                val scale = min(size.width / 1280f, size.height / 720f)
                val ox = (size.width - 1280f * scale) / 2f
                val oy = (size.height - 720f * scale) / 2f

                drawIntoCanvas { composeCanvas ->
                    val nc = composeCanvas.nativeCanvas
                    nc.save()
                    nc.translate(ox, oy)
                    nc.scale(scale, scale)

                    // Studio subtle grid floor
                    val bgPaint = android.graphics.Paint().apply { color = 0xFF131929.toInt() }
                    nc.drawRect(0f, 0f, 1280f, 720f, bgPaint)
                    val gridPaint = android.graphics.Paint().apply {
                        color = 0x1EFFFFFF
                        strokeWidth = 1.5f
                    }
                    var gx = 0f
                    while (gx <= 1280f) {
                        nc.drawLine(gx, 0f, gx, 720f, gridPaint)
                        gx += 64f
                    }
                    var gy = 0f
                    while (gy <= 720f) {
                        nc.drawLine(0f, gy, 1280f, gy, gridPaint)
                        gy += 64f
                    }
                    val floorPaint = android.graphics.Paint().apply {
                        color = 0xFF2DD4BF.toInt()
                        strokeWidth = 2.5f
                        alpha = 110
                    }
                    nc.drawLine(140f, 590f, 1140f, 590f, floorPaint)

                    val rootEval = EvaluatedPuppetRoot(
                        rootX = rig.rootX,
                        rootY = rig.rootY,
                        scale = rig.scale,
                        flippedHorizontal = rig.flippedHorizontal,
                        viewAngle = rig.viewAngle,
                        eyePack = rig.eyePack,
                        mouthPhoneme = rig.mouthPhoneme,
                        eyebrowStyle = rig.eyebrowStyle,
                        leftHandGesture = rig.leftHandGesture,
                        rightHandGesture = rig.rightHandGesture,
                        behaviorPreset = rig.behaviorPreset
                    )

                    // 25% Onion-Skin Watermark Trail (both Character Artwork AND Skeleton Bone Wireframe!)
                    if (onionSkin) {
                        val prevFrame = (testFrame - 4).coerceAtLeast(0)
                        if (prevFrame != testFrame) {
                            val prevAngles = InterpolationEngine.evaluateRigAngles(rig, prevFrame)
                            SceneRenderer.drawSkeletalRig(
                                canvas = nc,
                                rig = rig,
                                puppetRoot = rootEval,
                                angles = prevAngles,
                                frame = prevFrame,
                                fps = 24,
                                audioTracks = emptyList(),
                                alpha = 0.25f,
                                tintColorArgb = 0xFFA78BFAL,
                                showOverlay = true,
                                isSelectedPuppet = false,
                                selectedBoneId = null
                            )
                        }
                    }

                    // Live Character + Skeleton + Color-coded IK Handles + Root Move Ring + Mesh/Face Guides
                    val angles = InterpolationEngine.evaluateRigAngles(rig, testFrame)
                    SceneRenderer.drawSkeletalRig(
                        canvas = nc,
                        rig = rig,
                        puppetRoot = rootEval,
                        angles = angles,
                        frame = testFrame,
                        fps = 24,
                        audioTracks = emptyList(),
                        alpha = 1f,
                        tintColorArgb = null,
                        showOverlay = true,
                        isSelectedPuppet = true,
                        selectedBoneId = selectedBoneId,
                        highlightMeshBox = stageMode == RigStageMode.MOVE_SCALE_PNG,
                        highlightFaceTarget = stageMode == RigStageMode.PLACE_FACE
                    )
                    nc.restore()
                }
            }

            // Context-aware Stage hint pill
            Surface(
                color = PanelSurface.copy(alpha = 0.88f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
            ) {
                val hintText = when (stageMode) {
                    RigStageMode.POSE_IK -> "Drag orange hip ring to move • Drag glowing dots to pose IK"
                    RigStageMode.MOVE_SCALE_PNG -> "Drag cyan L/R pills to Squish Width • Coral T/B pills to Stretch Height • Corners to scale"
                    RigStageMode.PLACE_FACE -> "Drag animated Eyes & Mouth onto face • 2-finger pinch to resize"
                    RigStageMode.TAP_ADD_BONE -> "Tap anywhere on PNG to add a child bone from selected joint"
                }
                Text(
                    hintText,
                    color = StudioTextSecondary,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        // Live IK Test Controls Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                color = if (isPlaying) StudioRose else StudioCoral,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .clickable { viewModel.toggleStudioDraftTestPlay() }
                    .testTag("char_studio_test_play_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = "Test Pose Playback",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (isPlaying) "Stop" else "Test", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }

            // 4-View Turnaround Switcher right on the live stage strip!
            CharacterViewAngle.entries.forEach { angle ->
                FilterChip(
                    selected = rig.viewAngle == angle.name,
                    onClick = { viewModel.setStudioDraftViewAngle(angle) },
                    label = { Text(angle.label, fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StudioAmber.copy(alpha = 0.25f),
                        selectedLabelColor = StudioAmber
                    ),
                    modifier = Modifier.testTag("studio_view_${angle.name.lowercase()}")
                )
            }

            FilterChip(
                selected = onionSkin,
                onClick = { viewModel.toggleStudioDraftOnionSkin() },
                label = { Text("Onion", fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(14.dp)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioViolet.copy(alpha = 0.28f),
                    selectedLabelColor = StudioViolet
                )
            )
            FilterChip(
                selected = rig.flippedHorizontal,
                onClick = { viewModel.updateStudioDraftRig { it.copy(flippedHorizontal = !it.flippedHorizontal) } },
                label = { Text("Flip", fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(14.dp)) }
            )
            FilterChip(
                selected = stretchRigMode,
                onClick = { viewModel.toggleStretchRigMode() },
                label = { Text(if (stretchRigMode) "Stretch Rig ON" else "Stretch Rig", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioCoral.copy(alpha = 0.28f),
                    selectedLabelColor = StudioCoral
                ),
                modifier = Modifier.testTag("studio_stretch_rig_chip")
            )
            FilterChip(
                selected = rig.autoWalkWhenDragged,
                onClick = { viewModel.updateStudioDraftRig { it.copy(autoWalkWhenDragged = !it.autoWalkWhenDragged) } },
                label = { Text("Auto-Walk", fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.AutoMirrored.Filled.DirectionsWalk, contentDescription = null, modifier = Modifier.size(14.dp)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioMint.copy(alpha = 0.22f),
                    selectedLabelColor = StudioMint
                )
            )

            val poseChips = if (rig.rigCategory == "BIRD") {
                listOf("FLAP_UP", "FLAP_DOWN", "IDLE")
            } else {
                listOf("IDLE", "WAVE", "WALK", "JUMP", "SIT")
            }
            poseChips.forEach { pose ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = PanelSurface,
                    modifier = Modifier
                        .border(1.dp, StudioBorder, RoundedCornerShape(8.dp))
                        .clickable { viewModel.applyStudioDraftPose(pose) }
                ) {
                    Text(
                        pose,
                        color = StudioAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RigStudioWorkbenchPanel(
    rig: SkeletalRig,
    selectedBoneId: String?,
    activeTab: RigStudioTab,
    stageMode: RigStageMode,
    onSelectTab: (RigStudioTab) -> Unit,
    onSelectStageMode: (RigStageMode) -> Unit,
    viewModel: StudioViewModel,
    onPickImageForBone: (boneId: String) -> Unit,
    onPickSingleMeshImage: () -> Unit,
    onPickHandPropPng: (isRightHand: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(PanelSurface)
            .border(1.dp, StudioBorder, RoundedCornerShape(16.dp))
    ) {
        // Tab bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            RigStudioTab.entries.forEach { tab ->
                val selected = tab == activeTab
                Surface(
                    shape = RoundedCornerShape(9.dp),
                    color = if (selected) StudioViolet else Color.Transparent,
                    modifier = Modifier
                        .clickable { onSelectTab(tab) }
                        .testTag("rig_studio_tab_${tab.name.lowercase()}")
                ) {
                    Text(
                        tab.label,
                        color = if (selected) Color.White else StudioTextSecondary,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (activeTab) {
                RigStudioTab.BUILD -> RigStudioBuildTab(
                    rig = rig,
                    viewModel = viewModel,
                    onPickHandPropPng = onPickHandPropPng
                )
                RigStudioTab.PARTS_MESH -> RigStudioPartsAndMeshTab(
                    rig = rig,
                    selectedBoneId = selectedBoneId,
                    stageMode = stageMode,
                    onSelectStageMode = onSelectStageMode,
                    viewModel = viewModel,
                    onPickImageForBone = onPickImageForBone,
                    onPickSingleMeshImage = onPickSingleMeshImage
                )
                RigStudioTab.PART_LAYERS -> RigStudioPartLayersTab(
                    rig = rig,
                    selectedBoneId = selectedBoneId,
                    viewModel = viewModel
                )
                RigStudioTab.FACE_RIG -> RigStudioFaceRigTab(
                    rig = rig,
                    stageMode = stageMode,
                    onSelectStageMode = onSelectStageMode,
                    viewModel = viewModel
                )
                RigStudioTab.BONES -> RigStudioBonesTab(
                    rig = rig,
                    selectedBoneId = selectedBoneId,
                    stageMode = stageMode,
                    onSelectStageMode = onSelectStageMode,
                    viewModel = viewModel
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RigStudioBuildTab(
    rig: SkeletalRig,
    viewModel: StudioViewModel,
    onPickHandPropPng: (isRightHand: Boolean) -> Unit
) {
    val spec = rig.characterAppearance ?: ProceduralSmartTools.characterPresets.first()
    var editingRightHand by remember { mutableStateOf(true) }

    fun updateSpec(transform: (CharacterSpec) -> CharacterSpec) {
        val nextSpec = transform(spec)
        viewModel.updateStudioDraftRig { cur ->
            val updatedBones = cur.bones.map { b ->
                when (b.id) {
                    "spine", "arm_l_up", "arm_r_up" -> b.copy(colorArgb = nextSpec.shirtColorArgb)
                    "neck", "arm_l_low", "arm_r_low", "hand_l", "hand_r" -> b.copy(colorArgb = nextSpec.skinToneArgb)
                    "leg_l_up", "leg_l_low", "leg_r_up", "leg_r_low" -> b.copy(colorArgb = nextSpec.pantsColorArgb)
                    else -> b
                }
            }
            cur.copy(characterAppearance = nextSpec, bones = updatedBones)
        }
    }

    OutlinedTextField(
        value = rig.name,
        onValueChange = { name -> viewModel.updateStudioDraftRig { it.copy(name = name) } },
        label = { Text("Character Name", fontSize = 12.sp) },
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("char_studio_name_input")
    )

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = { viewModel.autoRigStudioDraft() },
            colors = ButtonDefaults.buttonColors(containerColor = StudioCyan),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f).testTag("studio_auto_rig_human_btn")
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Text("Auto-Rig Human", color = Color(0xFF080B12), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Button(
            onClick = {
                val rnd = ProceduralSmartTools.randomizeCharacter()
                viewModel.updateStudioDraftRig { cur ->
                    RigSolver.createRiggedCharacterFromSpec(rnd, cur.rootX, cur.rootY).copy(
                        id = cur.id,
                        viewAngle = cur.viewAngle,
                        eyePack = cur.eyePack,
                        mouthPhoneme = cur.mouthPhoneme,
                        leftHandProp = cur.leftHandProp,
                        rightHandProp = cur.rightHandProp
                    )
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Default.Casino, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Text("Randomize", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }

    // Whole-Character Acting Behavior / Mood Presets (5 Instant Presets!)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioViolet.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("CHARACTER BEHAVIOR / MOOD PRESET", color = StudioViolet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            val activeBehavior = runCatching { CharacterBehaviorPreset.valueOf(rig.behaviorPreset) }
                .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
            Text(activeBehavior.subtitle, color = StudioTextSecondary, fontSize = 10.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                CharacterBehaviorPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = rig.behaviorPreset == preset.name,
                        onClick = { viewModel.setStudioDraftBehaviorPreset(preset) },
                        label = { Text(preset.label, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioViolet.copy(alpha = 0.28f),
                            selectedLabelColor = StudioViolet
                        ),
                        modifier = Modifier.testTag("studio_behavior_${preset.name.lowercase()}")
                    )
                }
            }
        }
    }

    // Character Designer Proportions Squish & Stretch (1-Tap Shape Chips + Independent Width/Height!)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioCyan.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
    ) {
        var unlockAspectBuild by remember { mutableStateOf(true) }
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("CHARACTER SQUISH & STRETCH", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Unlock Aspect", color = StudioTextSecondary, fontSize = 10.sp)
                    Switch(checked = unlockAspectBuild, onCheckedChange = { unlockAspectBuild = it })
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(
                    Triple("Normal (1:1)", 1.0f, 1.0f),
                    Triple("Wide / Chubby", 1.45f, 0.85f),
                    Triple("Tall / Slim", 0.72f, 1.45f),
                    Triple("Squished Flat", 1.55f, 0.52f)
                ).forEach { (label, sx, sy) ->
                    FilterChip(
                        selected = kotlin.math.abs(rig.baseScaleX - sx) < 0.05f && kotlin.math.abs(rig.baseScaleY - sy) < 0.05f,
                        onClick = { viewModel.setStudioBaseScaleXY(scaleX = sx, scaleY = sy, lockAspect = false) },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
            Text("Width (Scale X): ${String.format("%.2f×", rig.baseScaleX)}  |  Height (Scale Y): ${String.format("%.2f×", rig.baseScaleY)}", color = StudioTextSecondary, fontSize = 10.sp)
            Slider(
                value = rig.baseScaleX.coerceIn(0.1f, 5.0f),
                onValueChange = { viewModel.setStudioBaseScaleXY(scaleX = it, lockAspect = !unlockAspectBuild) },
                valueRange = 0.1f..5.0f,
                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan)
            )
            Slider(
                value = rig.baseScaleY.coerceIn(0.1f, 5.0f),
                onValueChange = { viewModel.setStudioBaseScaleXY(scaleY = it, lockAspect = !unlockAspectBuild) },
                valueRange = 0.1f..5.0f,
                colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral)
            )
        }
    }

    // Attach Built-in Hand Props OR Custom PNG directly to Left / Right Hand!
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ATTACH ITEM TO HANDS", color = StudioMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = !editingRightHand,
                        onClick = { editingRightHand = false },
                        label = { Text("L-Hand", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = editingRightHand,
                        onClick = { editingRightHand = true },
                        label = { Text("R-Hand", fontSize = 10.sp) }
                    )
                }
            }
            val activeProp = if (editingRightHand) rig.rightHandProp else rig.leftHandProp
            val hasCustomPng = !(if (editingRightHand) rig.rightHandCustomImagePath else rig.leftHandCustomImagePath).isNullOrBlank()
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                HandPropKind.entries.forEach { prop ->
                    FilterChip(
                        selected = !hasCustomPng && activeProp == prop.name,
                        onClick = { viewModel.setStudioDraftHandProp(editingRightHand, prop) },
                        label = { Text(prop.label, fontSize = 10.sp) }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = { onPickHandPropPng(editingRightHand) },
                    shape = RoundedCornerShape(9.dp),
                    modifier = Modifier.weight(1f).testTag("studio_import_hand_png_btn")
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Import PNG to ${if (editingRightHand) "Right" else "Left"} Hand", fontSize = 11.sp)
                }
                if (hasCustomPng || activeProp != HandPropKind.NONE.name) {
                    OutlinedButton(onClick = { viewModel.clearStudioDraftHandProp(editingRightHand) }, shape = RoundedCornerShape(9.dp)) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear Hand Item", tint = StudioRose, modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
    }

    Text("CARTOON TEMPLATES", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ProceduralSmartTools.characterPresets.forEach { preset ->
            FilterChip(
                selected = spec.name == preset.name,
                onClick = {
                    viewModel.updateStudioDraftRig { cur ->
                        RigSolver.createRiggedCharacterFromSpec(preset, cur.rootX, cur.rootY).copy(
                            id = cur.id,
                            eyePack = cur.eyePack,
                            mouthPhoneme = cur.mouthPhoneme
                        )
                    }
                },
                label = { Text(preset.name, fontSize = 11.sp) }
            )
        }
    }

    Text("HAIR STYLE (MODERN & TRADITIONAL)", color = StudioTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("SPIKY", "BOB", "PONYTAIL", "CURLY", "MOHAWK", "BALD", "BRAID_BENI", "TRADITIONAL_BUN", "SAGE_JATA", "LONG_GHOST").forEach { hair ->
            FilterChip(
                selected = spec.hairStyle == hair,
                onClick = { updateSpec { it.copy(hairStyle = hair) } },
                label = { Text(hair.replace('_', ' '), fontSize = 10.sp) }
            )
        }
    }

    Text("OUTFIT (INDIAN / BENGALI & MODERN)", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("HOODIE", "TEE", "JACKET", "CAPE", "TUNIC", "PANJABI_DHOTI", "KURTA_PAJAMA", "SAREE", "SALWAR_KAMEEZ", "TANTRIK_ROBE", "VILLAGE_GHOST").forEach { outfit ->
            FilterChip(
                selected = spec.shirtStyle == outfit,
                onClick = { updateSpec { it.copy(shirtStyle = outfit) } },
                label = { Text(outfit.replace('_', ' '), fontSize = 10.sp) }
            )
        }
    }

    Text("ACCESSORY & FACIAL HAIR", color = StudioTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("NONE", "HEADPHONES", "GLASSES", "CROWN", "ROYAL_CROWN", "HAT", "SCARF", "DUPATTA_SHAWL", "RUDRAKSHA_MALA").forEach { acc ->
            FilterChip(
                selected = spec.accessory == acc,
                onClick = { updateSpec { it.copy(accessory = acc) } },
                label = { Text(acc.replace('_', ' '), fontSize = 10.sp) }
            )
        }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("NONE", "THICK_MUSTACHE", "SAGE_BEARD", "GOATEE").forEach { fh ->
            FilterChip(
                selected = spec.facialHair == fh,
                onClick = { updateSpec { it.copy(facialHair = fh) } },
                label = { Text(fh.replace('_', ' '), fontSize = 10.sp) }
            )
        }
        FilterChip(
            selected = spec.hasBindi,
            onClick = { updateSpec { it.copy(hasBindi = !it.hasBindi) } },
            label = { Text("Bindi", fontSize = 10.sp) }
        )
        FilterChip(
            selected = spec.hasBangles,
            onClick = { updateSpec { it.copy(hasBangles = !it.hasBangles) } },
            label = { Text("Bangles", fontSize = 10.sp) }
        )
    }

    Text("HAND GESTURES (${if (editingRightHand) "RIGHT" else "LEFT"} HAND)", color = StudioAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    val curGesture = if (editingRightHand) rig.rightHandGesture else rig.leftHandGesture
    FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        HandGesturePose.entries.forEach { pose ->
            FilterChip(
                selected = curGesture == pose.name,
                onClick = { viewModel.setStudioDraftHandGesture(editingRightHand, pose) },
                label = { Text(pose.label, fontSize = 10.sp) }
            )
        }
    }

    Text("BODY BUILD (BELLY / SHOULDERS / TORSO / SLOUCH)", color = StudioViolet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    Text("Belly Plumpness: ${(spec.bellyPlumpness * 100).toInt()}%  |  Shoulders: ${String.format("%.2fx", spec.shoulderWidth)}", color = StudioTextSecondary, fontSize = 10.sp)
    Slider(value = spec.bellyPlumpness.coerceIn(0f, 1f), onValueChange = { v -> updateSpec { it.copy(bellyPlumpness = v) } }, valueRange = 0f..1f)
    Slider(value = spec.shoulderWidth.coerceIn(0.6f, 1.8f), onValueChange = { v -> updateSpec { it.copy(shoulderWidth = v) } }, valueRange = 0.6f..1.8f)
    Text("Torso Scale: ${String.format("%.2fx", spec.torsoScale)}  |  Elder Slouch: ${(spec.postureSlouch * 100).toInt()}%", color = StudioTextSecondary, fontSize = 10.sp)
    Slider(value = spec.torsoScale.coerceIn(0.7f, 1.5f), onValueChange = { v -> updateSpec { it.copy(torsoScale = v) } }, valueRange = 0.7f..1.5f)
    Slider(value = spec.postureSlouch.coerceIn(0f, 1f), onValueChange = { v -> updateSpec { it.copy(postureSlouch = v) } }, valueRange = 0f..1f)

    Text("SKIN / HAIR / OUTFIT COLORS", color = StudioTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    ColorDotRow("Skin", listOf(0xFFFFDFC4L, 0xFFF5C6A5L, 0xFFE0AC69L, 0xFFC68642L, 0xFF8D5524L), spec.skinToneArgb) { c ->
        updateSpec { it.copy(skinToneArgb = c) }
    }
    ColorDotRow("Hair", listOf(0xFF111827L, 0xFF7C2D12L, 0xFF4C1D95L, 0xFFDB2777L, 0xFF0284C7L, 0xFFD97706L), spec.hairColorArgb) { c ->
        updateSpec { it.copy(hairColorArgb = c) }
    }
    ColorDotRow("Outfit", listOf(0xFFFF6B35L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFBBF24L, 0xFFFB7185L, 0xFF34D399L), spec.shirtColorArgb) { c ->
        updateSpec { it.copy(shirtColorArgb = c) }
    }
}

@Composable
private fun ColorDotRow(label: String, palette: List<Long>, selected: Long, onPick: (Long) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, color = StudioTextSecondary, fontSize = 11.sp, modifier = Modifier.width(44.dp))
        palette.forEach { argb ->
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(argb.toInt()))
                    .border(
                        width = if (argb == selected) 2.5.dp else 1.dp,
                        color = if (argb == selected) Color.White else StudioBorder,
                        shape = CircleShape
                    )
                    .clickable { onPick(argb) }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RigStudioPartsAndMeshTab(
    rig: SkeletalRig,
    selectedBoneId: String?,
    stageMode: RigStageMode,
    onSelectStageMode: (RigStageMode) -> Unit,
    viewModel: StudioViewModel,
    onPickImageForBone: (boneId: String) -> Unit,
    onPickSingleMeshImage: () -> Unit
) {
    val activeBone = rig.bones.firstOrNull { it.id == selectedBoneId } ?: rig.bones.firstOrNull()

    // Mode A: Single-Image 2D Mesh Skinning (Unrestricted 0.05x..8.0x Scaling + Free X/Y Drag!)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "SINGLE-IMAGE 2D MESH SKINNING (UNRESTRICTED SCALE)",
                color = StudioViolet,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Import any Human, Bird, Animal, or Object PNG. Resize freely from 0.05× to 8.0× via slider, 2-finger pinch, or corner handles!",
                color = StudioTextSecondary,
                fontSize = 11.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onPickSingleMeshImage,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioViolet),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("import_single_mesh_png_btn")
                ) {
                    Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (rig.singleMeshImagePath != null) "Replace PNG" else "Import PNG Artwork", fontSize = 11.sp)
                }
                if (rig.singleMeshImagePath != null) {
                    OutlinedButton(onClick = { viewModel.clearDraftSingleMesh() }, shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear Mesh", tint = StudioRose, modifier = Modifier.size(16.dp))
                    }
                }
            }
            if (rig.singleMeshImagePath != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            onSelectStageMode(
                                if (stageMode == RigStageMode.MOVE_SCALE_PNG) RigStageMode.POSE_IK else RigStageMode.MOVE_SCALE_PNG
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (stageMode == RigStageMode.MOVE_SCALE_PNG) StudioCyan else PanelSurface
                        ),
                        shape = RoundedCornerShape(9.dp),
                        modifier = Modifier.weight(1f).testTag("toggle_fit_png_stage_mode_btn")
                    ) {
                        Icon(
                            Icons.Default.OpenWith,
                            contentDescription = null,
                            tint = if (stageMode == RigStageMode.MOVE_SCALE_PNG) Color(0xFF080B12) else StudioCyan,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            if (stageMode == RigStageMode.MOVE_SCALE_PNG) "Done Fitting PNG" else "Drag / Pinch PNG on Stage",
                            color = if (stageMode == RigStageMode.MOVE_SCALE_PNG) Color(0xFF080B12) else StudioCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.updateStudioDraftRig {
                                it.copy(singleMeshScale = 1.0f, singleMeshOffsetX = 0f, singleMeshOffsetY = 0f, baseScaleX = 1.0f, baseScaleY = 1.0f)
                            }
                        },
                        shape = RoundedCornerShape(9.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Reset PNG Fit", tint = StudioAmber, modifier = Modifier.size(16.dp))
                    }
                }
                var unlockMeshAspect by remember { mutableStateOf(true) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("IMAGE SQUISH & STRETCH (0.1× – 5.0×)", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Unlock Aspect Ratio", color = StudioTextSecondary, fontSize = 10.sp)
                        Switch(
                            checked = unlockMeshAspect,
                            onCheckedChange = { unlockMeshAspect = it },
                            modifier = Modifier.testTag("single_mesh_unlock_aspect_switch")
                        )
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        Triple("Normal (1:1)", 1.0f, 1.0f),
                        Triple("Wide / Chubby", 1.45f, 0.85f),
                        Triple("Tall / Slim", 0.72f, 1.45f),
                        Triple("Squished Flat", 1.55f, 0.52f)
                    ).forEach { (chipLabel, sx, sy) ->
                        FilterChip(
                            selected = kotlin.math.abs(rig.baseScaleX - sx) < 0.05f && kotlin.math.abs(rig.baseScaleY - sy) < 0.05f,
                            onClick = { viewModel.setStudioBaseScaleXY(scaleX = sx, scaleY = sy, lockAspect = false) },
                            label = { Text(chipLabel, fontSize = 10.sp) },
                            modifier = Modifier.testTag("mesh_shape_${chipLabel.lowercase().replace(Regex("[^a-z0-9]"), "_")}")
                        )
                    }
                }
                Text("Image Width (Scale X): ${String.format("%.2f×", rig.baseScaleX)}", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = rig.baseScaleX.coerceIn(0.1f, 5.0f),
                    onValueChange = { sx -> viewModel.setStudioBaseScaleXY(scaleX = sx, lockAspect = !unlockMeshAspect) },
                    valueRange = 0.1f..5.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                    modifier = Modifier.testTag("single_mesh_scale_x_slider")
                )
                Text("Image Height (Scale Y): ${String.format("%.2f×", rig.baseScaleY)}", color = StudioCoral, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = rig.baseScaleY.coerceIn(0.1f, 5.0f),
                    onValueChange = { sy -> viewModel.setStudioBaseScaleXY(scaleY = sy, lockAspect = !unlockMeshAspect) },
                    valueRange = 0.1f..5.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                    modifier = Modifier.testTag("single_mesh_scale_y_slider")
                )
                Text("Overall PNG Scale: ${String.format("%.2f", rig.singleMeshScale)}× (0.05× – 8.0×)", color = StudioTextSecondary, fontSize = 11.sp)
                Slider(
                    value = rig.singleMeshScale.coerceIn(0.05f, 8.0f),
                    onValueChange = { sc -> viewModel.updateStudioDraftRig { it.copy(singleMeshScale = sc) } },
                    valueRange = 0.05f..8.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet),
                    modifier = Modifier.testTag("single_mesh_scale_slider")
                )
                Text("PNG Offset X: ${rig.singleMeshOffsetX.toInt()} px  |  Y: ${rig.singleMeshOffsetY.toInt()} px", color = StudioTextSecondary, fontSize = 11.sp)
                Slider(
                    value = rig.singleMeshOffsetX.coerceIn(-600f, 600f),
                    onValueChange = { ox -> viewModel.updateStudioDraftRig { it.copy(singleMeshOffsetX = ox) } },
                    valueRange = -600f..600f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet)
                )
                Slider(
                    value = rig.singleMeshOffsetY.coerceIn(-600f, 600f),
                    onValueChange = { oy -> viewModel.updateStudioDraftRig { it.copy(singleMeshOffsetY = oy) } },
                    valueRange = -600f..600f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet)
                )
            }
        }
    }

    // Mode B: Segmented PNG Body Parts per Bone (Unrestricted 0.05x..8.0x Scale)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "SEGMENTED PNG BODY PARTS (PER BONE)",
                color = StudioCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Tap any bone below, then attach a transparent PNG (Head, Wing, Arm, Leg, Tail, Prop) and tune its pivot & scale freely.",
                color = StudioTextSecondary,
                fontSize = 11.sp
            )

            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                rig.bones.forEach { bone ->
                    val isSel = bone.id == activeBone?.id
                    val hasImg = !bone.boundImagePath.isNullOrBlank()
                    FilterChip(
                        selected = isSel,
                        onClick = { viewModel.selectStudioDraftBone(bone.id) },
                        label = {
                            Text(
                                if (hasImg) "${bone.name} ✓" else bone.name,
                                fontSize = 10.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioCyan.copy(alpha = 0.25f),
                            selectedLabelColor = StudioCyan
                        )
                    )
                }
            }

            if (activeBone != null) {
                HorizontalDivider(color = StudioBorder)
                Text("Selected Bone: ${activeBone.name}", color = StudioTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onPickImageForBone(activeBone.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("attach_png_to_bone_btn")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Attach PNG to ${activeBone.name}", color = Color(0xFF080B12), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    if (!activeBone.boundImagePath.isNullOrBlank()) {
                        OutlinedButton(onClick = { viewModel.clearDraftBoneImage(activeBone.id) }, shape = RoundedCornerShape(10.dp)) {
                            Icon(Icons.Default.Clear, contentDescription = "Remove Part PNG", tint = StudioRose, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                // Per-Bone / Part Behavior Preset Selector (4 Instant Presets for EVERY bone/part!)
                Text("PART BEHAVIOR PRESET (${activeBone.name.uppercase()})", color = StudioAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                val curPartBehavior = runCatching { PartBehaviorPreset.valueOf(activeBone.partBehaviorPreset) }
                    .getOrDefault(PartBehaviorPreset.RIGID)
                Text(curPartBehavior.subtitle, color = StudioTextSecondary, fontSize = 10.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PartBehaviorPreset.entries.forEach { preset ->
                        FilterChip(
                            selected = activeBone.partBehaviorPreset == preset.name,
                            onClick = { viewModel.applyStudioBonePartBehaviorPreset(activeBone.id, preset) },
                            label = { Text("${preset.label} (${preset.subtitle.substringBefore(" /")})", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioAmber.copy(alpha = 0.26f),
                                selectedLabelColor = StudioAmber
                            ),
                            modifier = Modifier.testTag("studio_part_behavior_${preset.name.lowercase()}")
                        )
                    }
                }

                // Quick Per-Part Z-Order (Front / Back Draw Order) Bar for Selected Bone
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "DRAW ORDER (Z:${activeBone.zOrder})",
                        color = StudioViolet,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.adjustStudioDraftBoneZOrder(activeBone.id, BoneZOrderAction.BRING_TO_FRONT) },
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) { Text("Front", fontSize = 10.sp, color = StudioCyan) }
                        OutlinedButton(
                            onClick = { viewModel.adjustStudioDraftBoneZOrder(activeBone.id, BoneZOrderAction.BRING_FORWARD) },
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) { Text("+1", fontSize = 10.sp, color = StudioMint) }
                        OutlinedButton(
                            onClick = { viewModel.adjustStudioDraftBoneZOrder(activeBone.id, BoneZOrderAction.SEND_BACKWARD) },
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) { Text("-1", fontSize = 10.sp, color = StudioAmber) }
                        OutlinedButton(
                            onClick = { viewModel.adjustStudioDraftBoneZOrder(activeBone.id, BoneZOrderAction.SEND_TO_BACK) },
                            shape = RoundedCornerShape(7.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) { Text("Back", fontSize = 10.sp, color = StudioCoral) }
                    }
                }

                if (!activeBone.boundImagePath.isNullOrBlank()) {
                    var unlockPartAspect by remember(activeBone.id) { mutableStateOf(true) }
                    fun updateBone(fn: (RigBone) -> RigBone) {
                        viewModel.updateStudioDraftRig { r ->
                            r.copy(bones = r.bones.map { if (it.id == activeBone.id) fn(it) else it })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                onSelectStageMode(
                                    if (stageMode == RigStageMode.MOVE_SCALE_PNG) RigStageMode.POSE_IK else RigStageMode.MOVE_SCALE_PNG
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (stageMode == RigStageMode.MOVE_SCALE_PNG) StudioCyan else PanelSurface
                            ),
                            shape = RoundedCornerShape(9.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.OpenWith,
                                contentDescription = null,
                                tint = if (stageMode == RigStageMode.MOVE_SCALE_PNG) Color(0xFF080B12) else StudioCyan,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                if (stageMode == RigStageMode.MOVE_SCALE_PNG) "Done Squishing Part" else "Squish Part on Stage",
                                color = if (stageMode == RigStageMode.MOVE_SCALE_PNG) Color(0xFF080B12) else StudioCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = {
                                updateBone { it.copy(baseScaleX = 1.0f, baseScaleY = 1.0f, imageScale = 1.0f, pivotOffsetX = 0f, pivotOffsetY = 0f) }
                            },
                            shape = RoundedCornerShape(9.dp)
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "Reset Part Squish", tint = StudioAmber, modifier = Modifier.size(16.dp))
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("PART SQUISH & STRETCH (0.1× – 5.0×)", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Unlock Aspect", color = StudioTextSecondary, fontSize = 10.sp)
                            Switch(checked = unlockPartAspect, onCheckedChange = { unlockPartAspect = it })
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            Triple("Normal (1:1)", 1.0f, 1.0f),
                            Triple("Wide / Chubby", 1.45f, 0.85f),
                            Triple("Tall / Slim", 0.72f, 1.45f),
                            Triple("Squished Flat", 1.55f, 0.52f)
                        ).forEach { (chipLabel, sx, sy) ->
                            FilterChip(
                                selected = kotlin.math.abs(activeBone.baseScaleX - sx) < 0.05f && kotlin.math.abs(activeBone.baseScaleY - sy) < 0.05f,
                                onClick = { viewModel.setStudioBoneBaseScaleXY(activeBone.id, scaleX = sx, scaleY = sy, lockAspect = false) },
                                label = { Text(chipLabel, fontSize = 10.sp) }
                            )
                        }
                    }
                    Text("Image Width (Scale X): ${String.format("%.2f×", activeBone.baseScaleX)}", color = StudioCyan, fontSize = 11.sp)
                    Slider(
                        value = activeBone.baseScaleX.coerceIn(0.1f, 5.0f),
                        onValueChange = { v -> viewModel.setStudioBoneBaseScaleXY(activeBone.id, scaleX = v, lockAspect = !unlockPartAspect) },
                        valueRange = 0.1f..5.0f,
                        colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                        modifier = Modifier.testTag("part_scale_x_slider")
                    )
                    Text("Image Height (Scale Y): ${String.format("%.2f×", activeBone.baseScaleY)}", color = StudioCoral, fontSize = 11.sp)
                    Slider(
                        value = activeBone.baseScaleY.coerceIn(0.1f, 5.0f),
                        onValueChange = { v -> viewModel.setStudioBoneBaseScaleXY(activeBone.id, scaleY = v, lockAspect = !unlockPartAspect) },
                        valueRange = 0.1f..5.0f,
                        colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                        modifier = Modifier.testTag("part_scale_y_slider")
                    )
                    Text("Overall Part Scale: ${String.format("%.2f", activeBone.imageScale)}× (0.05× – 8.0×)", color = StudioTextSecondary, fontSize = 11.sp)
                    Slider(
                        value = activeBone.imageScale.coerceIn(0.05f, 8.0f),
                        onValueChange = { v -> updateBone { it.copy(imageScale = v) } },
                        valueRange = 0.05f..8.0f
                    )
                    Text("Pivot Offset X: ${activeBone.pivotOffsetX.toInt()}  |  Y: ${activeBone.pivotOffsetY.toInt()}", color = StudioTextSecondary, fontSize = 11.sp)
                    Slider(
                        value = activeBone.pivotOffsetX.coerceIn(-300f, 300f),
                        onValueChange = { v -> updateBone { it.copy(pivotOffsetX = v) } },
                        valueRange = -300f..300f
                    )
                    Slider(
                        value = activeBone.pivotOffsetY.coerceIn(-300f, 300f),
                        onValueChange = { v -> updateBone { it.copy(pivotOffsetY = v) } },
                        valueRange = -300f..300f
                    )
                    Text("Angle Offset: ${activeBone.imageRotationOffsetDeg.toInt()}°", color = StudioTextSecondary, fontSize = 11.sp)
                    Slider(
                        value = activeBone.imageRotationOffsetDeg.coerceIn(-180f, 180f),
                        onValueChange = { v -> updateBone { it.copy(imageRotationOffsetDeg = v) } },
                        valueRange = -180f..180f
                    )
                }
            }
        }
    }
}

@Composable
private fun RigStudioPartLayersTab(
    rig: SkeletalRig,
    selectedBoneId: String?,
    viewModel: StudioViewModel
) {
    // Sort Top (Front / Highest zOrder) -> Bottom (Back / Lowest zOrder)
    val sortedFrontToBack = remember(rig.bones) {
        rig.bones.withIndex()
            .sortedWith(compareByDescending<IndexedValue<RigBone>> { it.value.zOrder }.thenByDescending { it.index })
            .map { it.value }
    }

    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioViolet.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Layers, contentDescription = null, tint = StudioViolet, modifier = Modifier.size(17.dp))
                    Text(
                        "PART LAYERS (FRONT / BACK ORDER)",
                        color = StudioViolet,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    color = PanelSurface,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "${sortedFrontToBack.size} Parts",
                        color = StudioTextSecondary,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }
            Text(
                "Top items draw in FRONT (overlapping lower parts). Bottom items draw in BACK. Reorder any bone or attached PNG cleanly.",
                color = StudioTextSecondary,
                fontSize = 11.sp
            )
            Button(
                onClick = { viewModel.applyStudioAutoHumanLayerOrder() },
                colors = ButtonDefaults.buttonColors(containerColor = StudioCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("studio_auto_human_layer_order_btn")
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "Auto Human Layer Order (Natural Back → Front)",
                    color = Color(0xFF080B12),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Text(
                "Preset: Back Arm/Hand → Back Leg → Torso/Outfit → Head/Face → Front Hair/Hat → Front Leg → Front Arm/Hand → Held Prop",
                color = StudioTextSecondary.copy(alpha = 0.8f),
                fontSize = 10.sp
            )
        }
    }

    sortedFrontToBack.forEachIndexed { idx, bone ->
        val isSelected = bone.id == selectedBoneId
        val hasPng = !bone.boundImagePath.isNullOrBlank()
        val hasProp = !bone.attachedPropKind.isNullOrBlank()
        val positionTag = when (idx) {
            0 -> "TOP / FRONT"
            sortedFrontToBack.lastIndex -> "BOTTOM / BACK"
            else -> "#${idx + 1}"
        }
        Surface(
            color = if (isSelected) StudioViolet.copy(alpha = 0.16f) else PanelElevated,
            shape = RoundedCornerShape(11.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = if (isSelected) 1.5.dp else 1.dp,
                    color = if (isSelected) StudioCyan else StudioBorder,
                    shape = RoundedCornerShape(11.dp)
                )
                .clickable { viewModel.selectStudioDraftBone(bone.id) }
                .testTag("studio_part_layer_row_${bone.id}")
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(bone.colorArgb))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            bone.name,
                            color = StudioTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                        val meta = buildString {
                            append(positionTag)
                            if (hasPng) append(" • PNG Part")
                            if (hasProp) append(" • Prop")
                        }
                        Text(meta, color = StudioTextSecondary, fontSize = 10.sp, maxLines = 1)
                    }
                    Surface(
                        color = PanelSurface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.border(1.dp, StudioBorder, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            "Z:${bone.zOrder}",
                            color = StudioAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.adjustStudioDraftBoneZOrder(bone.id, BoneZOrderAction.BRING_TO_FRONT) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("z_front_${bone.id}")
                    ) {
                        Icon(Icons.Default.VerticalAlignTop, contentDescription = "Bring to Front", tint = StudioCyan, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("Front", fontSize = 10.sp, color = StudioCyan, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { viewModel.adjustStudioDraftBoneZOrder(bone.id, BoneZOrderAction.BRING_FORWARD) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("z_fwd_${bone.id}")
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Bring Forward +1", tint = StudioMint, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("+1", fontSize = 10.sp, color = StudioMint, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { viewModel.adjustStudioDraftBoneZOrder(bone.id, BoneZOrderAction.SEND_BACKWARD) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("z_back1_${bone.id}")
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = "Send Backward -1", tint = StudioAmber, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("-1", fontSize = 10.sp, color = StudioAmber, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { viewModel.adjustStudioDraftBoneZOrder(bone.id, BoneZOrderAction.SEND_TO_BACK) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("z_bottom_${bone.id}")
                    ) {
                        Icon(Icons.Default.VerticalAlignBottom, contentDescription = "Send to Back", tint = StudioCoral, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("Back", fontSize = 10.sp, color = StudioCoral, maxLines = 1)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RigStudioFaceRigTab(
    rig: SkeletalRig,
    stageMode: RigStageMode,
    onSelectStageMode: (RigStageMode) -> Unit,
    viewModel: StudioViewModel
) {
    val hasCustomPng = !rig.singleMeshImagePath.isNullOrBlank() || rig.bones.any { !it.boundImagePath.isNullOrBlank() }

    // Fit & Adjust Animated Eyes & Mouth onto Imported PNG Characters
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (rig.showFaceOverlayOnCustomImage) StudioAmber else StudioBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        if (hasCustomPng) "FIT ANIMATED FACE ONTO PNG" else "FACE RIG ALIGNMENT (LOCKED TO HEAD)",
                        color = StudioAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (hasCustomPng) "Enable & drag animated Eyes + Talking/Crying/Laughing Mouth onto your PNG face"
                        else "Fine-tune animated Eyes & Mouth position and scale on Head bone",
                        color = StudioTextSecondary,
                        fontSize = 10.sp
                    )
                }
                if (hasCustomPng) {
                    Switch(
                        checked = rig.showFaceOverlayOnCustomImage,
                        onCheckedChange = { show -> viewModel.updateStudioDraftRig { it.copy(showFaceOverlayOnCustomImage = show) } },
                        modifier = Modifier.testTag("face_overlay_on_png_switch")
                    )
                }
            }

            if (!hasCustomPng || rig.showFaceOverlayOnCustomImage) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            onSelectStageMode(
                                if (stageMode == RigStageMode.PLACE_FACE) RigStageMode.POSE_IK else RigStageMode.PLACE_FACE
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (stageMode == RigStageMode.PLACE_FACE) StudioAmber else PanelSurface
                        ),
                        shape = RoundedCornerShape(9.dp),
                        modifier = Modifier.weight(1f).testTag("drag_face_on_stage_btn")
                    ) {
                        Icon(
                            Icons.Default.OpenWith,
                            contentDescription = null,
                            tint = if (stageMode == RigStageMode.PLACE_FACE) Color(0xFF080B12) else StudioAmber,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            if (stageMode == RigStageMode.PLACE_FACE) "Done Placing Face" else "Drag / Pinch Face on Stage",
                            color = if (stageMode == RigStageMode.PLACE_FACE) Color(0xFF080B12) else StudioAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.updateStudioDraftRig {
                                it.copy(faceOverlayOffsetX = 0f, faceOverlayOffsetY = 0f, faceOverlayScale = 1.0f)
                            }
                        },
                        shape = RoundedCornerShape(9.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Reset Face Fit", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
                Text("Face Scale: ${String.format("%.2f", rig.faceOverlayScale)}×", color = StudioAmber, fontSize = 11.sp)
                Slider(
                    value = rig.faceOverlayScale.coerceIn(0.2f, 4.0f),
                    onValueChange = { s -> viewModel.updateStudioDraftRig { it.copy(faceOverlayScale = s) } },
                    valueRange = 0.2f..4.0f,
                    colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
                    modifier = Modifier.testTag("face_overlay_scale_slider")
                )
                Text("Face Offset X: ${rig.faceOverlayOffsetX.toInt()}  |  Y: ${rig.faceOverlayOffsetY.toInt()}", color = StudioTextSecondary, fontSize = 11.sp)
                Slider(
                    value = rig.faceOverlayOffsetX.coerceIn(-300f, 300f),
                    onValueChange = { x -> viewModel.updateStudioDraftRig { it.copy(faceOverlayOffsetX = x) } },
                    valueRange = -300f..300f
                )
                Slider(
                    value = rig.faceOverlayOffsetY.coerceIn(-300f, 300f),
                    onValueChange = { y -> viewModel.updateStudioDraftRig { it.copy(faceOverlayOffsetY = y) } },
                    valueRange = -300f..300f
                )
            }
        }
    }

    Text(
        "LIVE ANIMATED EYE PACKS (BLINK, CRYING TEARS, LAUGHING, HORROR)",
        color = StudioCyan,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold
    )
    Text(
        "Frame-animated during preview and export: falling tears, squinting laugh, periodic blinking, and scared horror tremors.",
        color = StudioTextSecondary,
        fontSize = 11.sp
    )
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        EyePackStyle.entries.forEach { style ->
            val selected = rig.eyePack == style.name
            FilterChip(
                selected = selected,
                onClick = { viewModel.updateStudioDraftRig { it.copy(eyePack = style.name) } },
                label = { Text(style.label, fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioCyan.copy(alpha = 0.24f),
                    selectedLabelColor = StudioCyan
                ),
                modifier = Modifier.testTag("eye_pack_${style.name.lowercase()}")
            )
        }
    }

    Text("EYEBROW ACTING STYLE", color = StudioAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        EyebrowStyle.entries.forEach { brow ->
            FilterChip(
                selected = rig.eyebrowStyle == brow.name,
                onClick = { viewModel.setStudioDraftEyebrow(brow) },
                label = { Text(brow.label, fontSize = 11.sp) }
            )
        }
    }

    HorizontalDivider(color = StudioBorder)

    Text(
        "ANIMATED TALKING, LAUGHING, CRYING & AUTO LIP-SYNC MOUTHS",
        color = StudioCoral,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold
    )
    Text(
        "Pick Talking Loop for continuous animated speech, Auto Lip-Sync for voice tracks, or Laughing / Crying / Scared live loops.",
        color = StudioTextSecondary,
        fontSize = 11.sp
    )
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        MouthPhoneme.entries.forEach { phoneme ->
            val selected = rig.mouthPhoneme == phoneme.name
            FilterChip(
                selected = selected,
                onClick = { viewModel.updateStudioDraftRig { it.copy(mouthPhoneme = phoneme.name) } },
                label = { Text(phoneme.label, fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Face, contentDescription = null, modifier = Modifier.size(14.dp)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StudioCoral.copy(alpha = 0.24f),
                    selectedLabelColor = StudioCoral
                ),
                modifier = Modifier.testTag("mouth_phoneme_${phoneme.name.lowercase()}")
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RigStudioBonesTab(
    rig: SkeletalRig,
    selectedBoneId: String?,
    stageMode: RigStageMode,
    onSelectStageMode: (RigStageMode) -> Unit,
    viewModel: StudioViewModel
) {
    val activeBone = rig.bones.firstOrNull { it.id == selectedBoneId } ?: rig.bones.firstOrNull()

    // Non-Human & Custom Starter Rig Templates (Bird, Quadruped Animal, Custom Object, Human)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioMint.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.Pets, contentDescription = null, tint = StudioMint, modifier = Modifier.size(16.dp))
                Text("NON-HUMAN & CUSTOM RIG TEMPLATES", color = StudioMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "Rig any Bird, Quadruped Animal, Creature, or Custom Object PNG — then tap on stage to add custom parent-child bones!",
                color = StudioTextSecondary,
                fontSize = 10.sp
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    "HUMAN" to "Human (14b)",
                    "BIRD" to "Bird / Winged",
                    "QUADRUPED" to "Quadruped Animal",
                    "CUSTOM_OBJECT" to "Custom Object",
                    "ASSET" to "Reusable Asset"
                ).forEach { (cat, label) ->
                    FilterChip(
                        selected = rig.rigCategory == cat,
                        onClick = { viewModel.applyStudioNonHumanTemplate(cat) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StudioMint.copy(alpha = 0.25f),
                            selectedLabelColor = StudioMint
                        ),
                        modifier = Modifier.testTag("rig_template_${cat.lowercase()}")
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        onSelectStageMode(
                            if (stageMode == RigStageMode.TAP_ADD_BONE) RigStageMode.POSE_IK else RigStageMode.TAP_ADD_BONE
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (stageMode == RigStageMode.TAP_ADD_BONE) StudioMint else PanelSurface
                    ),
                    shape = RoundedCornerShape(9.dp),
                    modifier = Modifier.weight(1f).testTag("tap_stage_add_bone_btn")
                ) {
                    Icon(
                        Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = if (stageMode == RigStageMode.TAP_ADD_BONE) Color(0xFF080B12) else StudioMint,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        if (stageMode == RigStageMode.TAP_ADD_BONE) "Tap Stage Active" else "Tap Stage to Add Bone",
                        color = if (stageMode == RigStageMode.TAP_ADD_BONE) Color(0xFF080B12) else StudioMint,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (rig.bones.size > 1 && activeBone != null) {
                    OutlinedButton(
                        onClick = { viewModel.deleteStudioSelectedBone() },
                        shape = RoundedCornerShape(9.dp),
                        modifier = Modifier.testTag("delete_selected_bone_btn")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete selected bone", tint = StudioRose, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("2-Bone Inverse Kinematics (IK)", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("Dragging hand/foot/wing bends joints naturally", color = StudioTextSecondary, fontSize = 11.sp)
        }
        Switch(
            checked = rig.ikEnabled,
            onCheckedChange = { enabled -> viewModel.updateStudioDraftRig { it.copy(ikEnabled = enabled) } }
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("Show Character Skin / Parts", color = StudioTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("Toggle off to inspect pure bone skeleton", color = StudioTextSecondary, fontSize = 11.sp)
        }
        Switch(
            checked = rig.showSkinMesh,
            onCheckedChange = { show -> viewModel.updateStudioDraftRig { it.copy(showSkinMesh = show) } }
        )
    }

    Text("Puppet Scale: ${String.format("%.2f", rig.scale)}× (0.1× – 8.0×)", color = StudioTextSecondary, fontSize = 11.sp)
    Slider(
        value = rig.scale.coerceIn(0.1f, 8.0f),
        onValueChange = { s -> viewModel.updateStudioDraftRig { it.copy(scale = s) } },
        valueRange = 0.1f..8.0f,
        colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber)
    )

    if (activeBone != null) {
        Text("Selected Bone: ${activeBone.name}", color = StudioCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("Part Behavior Preset", color = StudioAmber, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            PartBehaviorPreset.entries.forEach { preset ->
                FilterChip(
                    selected = activeBone.partBehaviorPreset == preset.name,
                    onClick = { viewModel.applyStudioBonePartBehaviorPreset(activeBone.id, preset) },
                    label = { Text(preset.label, fontSize = 10.sp) }
                )
            }
        }
        Text("Bone Length: ${activeBone.length.toInt()} px", color = StudioTextSecondary, fontSize = 11.sp)
        Slider(
            value = activeBone.length.coerceIn(16f, 360f),
            onValueChange = { len -> viewModel.updateStudioDraftBoneScaleAndSpring(activeBone.id, length = len) },
            valueRange = 16f..360f
        )
        Text("Limb Width (Scale X): ${String.format("%.2fx", activeBone.limbWidthScale)}", color = StudioTextSecondary, fontSize = 11.sp)
        Slider(
            value = activeBone.limbWidthScale.coerceIn(0.25f, 3.5f),
            onValueChange = { w -> viewModel.updateStudioDraftBoneScaleAndSpring(activeBone.id, widthScale = w) },
            valueRange = 0.25f..3.5f,
            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan)
        )
        Text("Limb Length (Scale Y): ${String.format("%.2fx", activeBone.limbLengthScale)}", color = StudioTextSecondary, fontSize = 11.sp)
        Slider(
            value = activeBone.limbLengthScale.coerceIn(0.25f, 3.5f),
            onValueChange = { l -> viewModel.updateStudioDraftBoneScaleAndSpring(activeBone.id, lengthScale = l) },
            valueRange = 0.25f..3.5f,
            colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral)
        )
        Text("Physics Spring Sway: ${(activeBone.springStiffness * 100).toInt()}%  |  Damping: ${(activeBone.springDamping * 100).toInt()}%", color = StudioTextSecondary, fontSize = 11.sp)
        Slider(
            value = activeBone.springStiffness.coerceIn(0f, 1f),
            onValueChange = { s -> viewModel.updateStudioDraftBoneScaleAndSpring(activeBone.id, springStiffness = s) },
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(thumbColor = StudioMint, activeTrackColor = StudioMint)
        )
        Slider(
            value = activeBone.springDamping.coerceIn(0.1f, 0.98f),
            onValueChange = { d -> viewModel.updateStudioDraftBoneScaleAndSpring(activeBone.id, springDamping = d) },
            valueRange = 0.1f..0.98f
        )
    }

    Button(
        onClick = {
            val parent = activeBone?.id ?: rig.bones.firstOrNull()?.id
            val extra = RigBone(
                name = "Bone ${rig.bones.size + 1}",
                parentId = parent,
                length = 64f,
                localAngleDeg = 30f,
                thickness = 14f,
                colorArgb = 0xFF2DD4BFL
            )
            viewModel.updateStudioDraftRig { it.copy(bones = it.bones + extra) }
            viewModel.selectStudioDraftBone(extra.id)
        },
        colors = ButtonDefaults.buttonColors(containerColor = StudioMint),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text("Add Child Bone (Wing / Tail / Hair / Prop)", color = Color(0xFF080B12), fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
