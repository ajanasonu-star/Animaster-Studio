package com.example.data.model

import com.squareup.moshi.JsonClass
import java.util.UUID

enum class ScreenMode(val label: String) {
    AUTO_RESPONSIVE("Auto-Fit Responsive"),
    LOCK_LANDSCAPE("Lock Landscape"),
    LOCK_PORTRAIT("Lock Portrait")
}

data class DisplaySettings(
    val screenMode: ScreenMode = ScreenMode.AUTO_RESPONSIVE,
    val uiScale: Float = 1.0f
)

enum class EditorTool(val label: String, val shortcut: String) {
    PENCIL("Pencil", "P"),
    BRUSH("Brush", "B"),
    AIRBRUSH("Airbrush", "A"),
    ERASER("Eraser", "E"),
    BUCKET("Fill", "G"),
    PEN_BEZIER("Bezier", "N"),
    LINE("Line", "L"),
    RECTANGLE("Rect", "R"),
    CIRCLE("Circle", "C"),
    POLYGON("Poly", "Y"),
    TEXT("Text", "T"),
    EYEDROPPER("Picker", "I"),
    SELECT("Select", "V"),
    RIG_EDIT("Puppet", "K"),
    MOTION_PATH("Path", "M"),
    HAND_PAN("Pan", "H")
}

enum class LayerType(val displayName: String) {
    DRAWING("Vector & Raster"),
    CHARACTER("Character"),
    RIG("Rigged Puppet"),
    VIDEO("Video Layer"),
    BACKGROUND("Background"),
    FOREGROUND("Foreground")
}

enum class EasingType(val displayName: String) {
    EASE_IN_OUT("Smooth"),
    LINEAR("Linear"),
    BOUNCE("Bounce"),
    SNAP("Snap"),
    EASE_IN("Ease In"),
    EASE_OUT("Ease Out")
}

enum class SceneTransition(val displayName: String) {
    CUT("Cut"),
    FADE("Crossfade"),
    SLIDE_LEFT("Slide Left"),
    ZOOM_IN("Zoom In")
}

enum class ClipAnimationPreset(val displayName: String) {
    NONE("None"),
    FADE("Fade"),
    POP("Pop"),
    SLIDE("Slide"),
    FLASH("Flash");
    val label: String get() = displayName
}

enum class BackgroundTemplate(val displayName: String) {
    SOLID("Solid Canvas"),
    PASTEL_SKY("Pastel Sky"),
    ZAMINDAR_VERANDA("Zamindar Veranda"),
    VILLAGE_HUT_POND("Village Hut & Pond"),
    ROYAL_DARBAR("Royal Darbar Hall"),
    VILLAGE_ROAD("Village Road"),
    HAUNTED_FOREST_MULTIPLANE("Haunted Forest 3D"),
    TRADITIONAL_ROOM("Traditional Room"),
    CHERRY_BLOSSOM("Sakura Park"),
    TWILIGHT_DREAM("Twilight Glow"),
    HAUNTED_FOREST("Haunted Forest"),
    SPOOKY_MANSION("Spooky Mansion"),
    COMIC_BURST("Comic Burst"),
    CLASSROOM_STAGE("School Stage"),
    SUNNY_MEADOW("Sunny Meadow"),
    CYBERPUNK_CITY("Neon City"),
    COZY_STUDIO("Cozy Studio"),
    OUTER_SPACE("Deep Space"),
    SUNSET_DESERT("Sunset Dunes"),
    GRID_PAPER("Animator Grid")
}

enum class SceneVfxType(val displayName: String) {
    FIREFLIES("Fireflies"),
    FLOWER_PETALS("Sakura Petals"),
    SUNBEAMS("Soft Sunbeams"),
    HIGH_SUNLIGHT("High Sunlight"),
    GOLDEN_HOUR("Golden Sun Glow"),
    STORM("Thunderstorm"),
    RAIN("Rain"),
    HEAVY_RAIN("Heavy Rain + Splashes"),
    LIGHTNING_FLASH("Lightning"),
    SNOW("Snow"),
    RAINBOW("Rainbow Arc"),
    AURORA("Northern Aurora"),
    AUTUMN_LEAVES("Wind & Leaves"),
    STARLIGHT("Twinkling Stars"),
    FIRE_EMBERS("Fire Embers"),
    SPOOKY_FOG("Spooky Fog"),
    VIGNETTE_HORROR("Horror Vignette"),
    SPEED_LINES("Anime Speed Lines"),
    CONFETTI_POP("YouTube Confetti"),
    CINEMA_BARS("Cinema Bars");
    val label: String get() = displayName
}

enum class SceneColorGrade(val displayName: String) {
    NONE("Normal"),
    HORROR_COLD("Horror Cold"),
    NIGHT_BLUE("Midnight"),
    WARM_SUNSET("Warm Glow"),
    VINTAGE_VHS("Retro VHS"),
    NOIR_BW("Noir B&W");
    val label: String get() = displayName
}

enum class VoiceEffectType(val displayName: String) {
    NORMAL("Normal"),
    CHIPMUNK("Cartoon Kid"),
    DEEP_MONSTER("Deep Monster"),
    GHOST_ECHO("Ghost Echo"),
    ROBOT("Robot");
    val label: String get() = displayName
}

enum class SubtitleStyle(val displayName: String) {
    YOUTUBE_BOLD("YouTube Bold"),
    HORROR_DRIP("Horror Red"),
    COMIC_BOX("Comic Box"),
    CINEMATIC("Cinema Clean");
    val label: String get() = displayName
}

enum class TextFontStyle(val displayName: String) {
    BOLD_CARTOON("Cartoon Bold"),
    SERIF_HORROR("Horror Serif"),
    MONO_TECH("Tech Mono"),
    CLASSIC_CLEAN("Clean Sans"),
    COMIC_ITALIC("Comic Italic");
    val label: String get() = displayName
}

enum class TextBoxStyle(val displayName: String) {
    NONE("None"),
    OUTLINE_GLOW("Neon Glow"),
    COMIC_BANNER("Comic Box"),
    SPEECH_BUBBLE("Speech Bubble"),
    YOUTUBE_PILL("YouTube Pill"),
    HORROR_BLOOD("Horror Slash");
    val label: String get() = displayName
}

enum class TextInAnimation(val displayName: String) {
    NONE("None"),
    POP_BOUNCE("Pop Bounce"),
    TYPEWRITER("Typewriter"),
    SLIDE_UP("Slide Up"),
    SLIDE_LEFT("Slide Left"),
    ZOOM_SLAM("Zoom Slam"),
    DROP_LETTERS("Letter Drop"),
    SPIN_POP("Spin Pop"),
    FADE_IN("Fade In");
    val label: String get() = displayName
}

enum class TextLoopAnimation(val displayName: String) {
    NONE("Static"),
    WAVE("Wave Letters"),
    BOUNCE("Bounce"),
    FLOAT("Ghost Float"),
    SHAKE_HORROR("Horror Shake"),
    GLITCH("Cyber Glitch"),
    PULSE("Pulse"),
    RAINBOW("Rainbow Glow");
    val label: String get() = displayName
}

enum class TextOutAnimation(val displayName: String) {
    NONE("None"),
    FADE_OUT("Fade Out"),
    POP_OUT("Pop Out"),
    SLIDE_DOWN("Slide Down"),
    ZOOM_OUT("Zoom Out");
    val label: String get() = displayName
}

enum class CharacterViewAngle(val displayName: String) {
    FRONT("Front"),
    FRONT_LEFT_34("Front-L 3/4"),
    SIDE_LEFT("Left Side"),
    BACK_LEFT_34("Back-L 3/4"),
    BACK("Back"),
    BACK_RIGHT_34("Back-R 3/4"),
    SIDE_RIGHT("Right Side"),
    FRONT_RIGHT_34("Front-R 3/4");
    val label: String get() = displayName
}

enum class HandGesturePose(val displayName: String) {
    RELAXED("Relaxed"),
    OPEN_PALM("Open Palm"),
    PALM_FRONT("Palm Front"),
    PALM_BACK("Palm Back"),
    PALM_UP_OPEN("Palm Up / Open"),
    CUPPED_DRINKING_WATER("Cupped Water"),
    POINTING("Pointing"),
    NAMASTE("Namaste"),
    FIST("Fist"),
    THUMBS_UP("Thumbs Up"),
    HOLDING_PROP("Hold Prop");
    val label: String get() = displayName
}

enum class EyebrowStyle(val displayName: String) {
    NORMAL("Normal"),
    ANGRY("Angry Furrowed"),
    RAISED("Raised / Shock"),
    WORRIED("Sad Droop");
    val label: String get() = displayName
}

enum class FaceMoodCategory(val displayName: String, val shortLabel: String) {
    NORMAL("Normal", "Normal"),
    LAUGHING("Laughing", "Laugh"),
    CRYING("Crying", "Cry"),
    ANGRY("Angry", "Angry"),
    SCARED("Scared", "Scared"),
    WITCH_HORROR("Witch / Horror", "Horror");
    val label: String get() = displayName
}

enum class FaceArchetypePreset(val displayName: String) {
    MALE("Male"),
    FEMALE("Female"),
    CHILD("Child"),
    ELDERLY("Elderly"),
    WITCH_GHOST("Witch / Ghost");
    val label: String get() = displayName
}

enum class NoseStylePreset(val displayName: String) {
    CLASSIC("Classic"),
    BUTTON("Button"),
    SHARP("Sharp"),
    HOOKED_WITCH("Witch Hook"),
    MINIMAL("Minimal"),
    HIDDEN("Hidden");
    val label: String get() = displayName
}

enum class TargetedLoopType(val displayName: String) {
    TALKING_LOOP("Talking Loop"),
    AUTO_WALK("Auto-Walk Cycle"),
    CRYING_LOOP("Crying Loop"),
    LAUGHING_LOOP("Laughing Loop"),
    IDLE_BREATHING("Idle Breathing"),
    HORROR_TWITCH("Horror Twitch");
    val label: String get() = displayName
}

enum class PartBehaviorPreset(val displayName: String, val subtitle: String) {
    RIGID("Rigid", "Face / Hand / Prop"),
    SOFT_CLOTH("Soft Cloth", "Shirt / Saree / Skirt"),
    BOUNCY_SPRING("Bouncy Spring", "Hair / Tail / Wings"),
    ELASTIC_RUBBER("Elastic Rubber", "Horror / Stretch");
    val label: String get() = displayName
}

enum class CharacterBehaviorPreset(val displayName: String, val subtitle: String) {
    NORMAL_CALM("Normal / Calm", "Balanced posture, natural blink, relaxed walk"),
    ANGRY_STRICT("Angry / Strict", "Furrowed brows, sharp gestures, fast heavy steps"),
    HORROR_GHOSTLY("Horror / Ghostly", "Eerie twitch, floating sway, rim glow, tense limbs"),
    HAPPY_PLAYFUL("Happy / Playful", "Bouncy energetic walk, smile, lively hand waves"),
    ELDERLY_WEAK("Elderly / Weak", "Hunched slouch, slow careful steps, subtle tremor");
    val label: String get() = displayName
}

enum class HandPropKind(val displayName: String) {
    NONE("Empty"),
    SWORD("Sword"),
    MIC("YouTube Mic"),
    FLASHLIGHT("Flashlight"),
    MAGIC_WAND("Magic Wand"),
    PHONE("Phone"),
    HORROR_AXE("Horror Axe"),
    LANTERN("Ghost Lantern"),
    COFFEE("Coffee Cup"),
    SIGN("Sub Sign");
    val label: String get() = displayName
}

enum class EyePackStyle(val displayName: String) {
    AUTO_BLINK("Auto-Blink"),
    OPEN_NORMAL("Open"),
    HALF_BLINK("Half-Blink"),
    CLOSED_BLINK("Closed Blink"),
    HAPPY("Happy"),
    LAUGHING("Laughing"),
    ANGRY("Angry"),
    SAD_TEARS("Crying Tears"),
    SCARED_HORROR("Scared / Horror"),
    SURPRISED("Shocked / Wide"),
    WINK("Wink"),
    SIDE_LOOK("Side-Look");
    val label: String get() = displayName
}

enum class MouthPhoneme(val displayName: String) {
    AUTO_LIPSYNC("Auto Lip-Sync"),
    TALKING_LOOP("Talking Loop"),
    LAUGHING("Laughing"),
    CRYING("Crying"),
    ANGRY_SHOUT("Angry / Shout"),
    SCARED("Scared"),
    REST("Closed (Idle)"),
    HALF_OPEN("Half-Open"),
    A("A (Wide-Open)"),
    E("E (Smile)"),
    I("I (Teeth)"),
    O("O (Loud/O)"),
    U("U (Pucker)"),
    SMILE("Big Smile"),
    SHOCK("Shock");
    val label: String get() = displayName
}

enum class CustomMouthSlot(val displayName: String, val shortLabel: String) {
    CLOSED_IDLE("Closed (Idle)", "Closed"),
    HALF_OPEN_TALK("Half-Open (Soft Talk)", "Half-Open"),
    WIDE_OPEN_LOUD("Wide-Open (Loud/O)", "Wide-Open"),
    SMILE_LAUGH("Smile / Laugh", "Laugh"),
    SAD_CRYING("Sad / Crying", "Crying"),
    ANGRY_SHOUT("Angry / Shout", "Angry");
    val label: String get() = displayName
}

enum class CustomEyeSlot(val displayName: String, val shortLabel: String) {
    OPEN_NORMAL("Open (Normal)", "Open"),
    HALF_BLINK("Half-Blink", "Half-Blink"),
    CLOSED_BLINK("Closed (Blink)", "Closed"),
    HAPPY_LAUGHING("Happy / Laughing Squint", "Laughing"),
    CRYING_TEARS("Crying (With Tears)", "Crying"),
    ANGRY_FURROWED("Angry / Furrowed", "Angry"),
    SHOCKED_WIDE("Shocked / Wide", "Shocked");
    val label: String get() = displayName
}

enum class StageMoodPreset(val displayName: String) {
    NORMAL("Normal"),
    TALKING("Talking"),
    SUDDEN_CRY("Sudden Cry"),
    LAUGHING("Laughing"),
    ANGRY("Angry"),
    SHOCKED("Shocked"),
    BLINK("Blink");
    val label: String get() = displayName
}

enum class ShapeKind {
    LINE, RECTANGLE, CIRCLE, POLYGON, FILL_BACKDROP
}

enum class AudioTrackKind(val displayName: String) {
    VOICE("Voice"),
    SFX("SFX"),
    MUSIC("Music")
}

enum class ExportFormat(val label: String, val ext: String, val mime: String) {
    PNG("PNG Frame", "png", "image/png"),
    PNG_SEQUENCE("PNG Sequence (ZIP)", "zip", "application/zip"),
    GIF("Animated GIF", "gif", "image/gif"),
    MP4("MP4 Video (H.264)", "mp4", "video/mp4"),
    WEBM("WebM Video (VP8)", "webm", "video/webm"),
    PC_PRO_BUNDLE("PC Desktop Bundle (.animaster-pc)", "zip", "application/zip")
}

@JsonClass(generateAdapter = true)
data class Vec2(
    val x: Float,
    val y: Float
)

@JsonClass(generateAdapter = true)
data class DrawStroke(
    val id: String = UUID.randomUUID().toString(),
    val tool: String = EditorTool.BRUSH.name,
    val points: List<Vec2> = emptyList(),
    val colorArgb: Long = 0xFFFFFFFFL,
    val gradientEndArgb: Long? = null,
    val strokeWidth: Float = 8f,
    val opacity: Float = 1f,
    val isClosedBezier: Boolean = false
)

@JsonClass(generateAdapter = true)
data class VectorShape(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = ShapeKind.RECTANGLE.name,
    val startX: Float = 0f,
    val startY: Float = 0f,
    val endX: Float = 100f,
    val endY: Float = 100f,
    val polygonSides: Int = 5,
    val strokeColorArgb: Long = 0xFFFFFFFFL,
    val fillColorArgb: Long? = null,
    val gradientEndArgb: Long? = null,
    val strokeWidth: Float = 5f,
    val opacity: Float = 1f,
    val rotationDeg: Float = 0f
)

@JsonClass(generateAdapter = true)
data class CanvasTextItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "EPISODE 1!",
    val x: Float = 640f,
    val y: Float = 220f,
    val fontSize: Float = 68f,
    val colorArgb: Long = 0xFFFFE066L,
    val gradientEndArgb: Long? = null,
    val strokeColorArgb: Long = 0xFF0F172AL,
    val strokeWidth: Float = 8f,
    val isBold: Boolean = true,
    val shadowEnabled: Boolean = true,
    val glowEnabled: Boolean = false,
    val fontStyle: String = TextFontStyle.BOLD_CARTOON.name,
    val boxStyle: String = TextBoxStyle.NONE.name,
    val boxColorArgb: Long = 0xDD0F172AL,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f,
    val startFrame: Int = 0,
    val endFrame: Int = 9999,
    val inAnimation: String = TextInAnimation.POP_BOUNCE.name,
    val inDurationFrames: Int = 12,
    val loopAnimation: String = TextLoopAnimation.NONE.name,
    val loopSpeed: Float = 1f,
    val outAnimation: String = TextOutAnimation.FADE_OUT.name,
    val outDurationFrames: Int = 10,
    val visible: Boolean = true
)

@JsonClass(generateAdapter = true)
data class ImportedImageItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Image",
    val filePath: String = "",
    val x: Float = 320f,
    val y: Float = 180f,
    val width: Float = 320f,
    val height: Float = 240f,
    val rotationDeg: Float = 0f,
    val opacity: Float = 1f
)

@JsonClass(generateAdapter = true)
data class CharacterSpec(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nova",
    val x: Float = 640f,
    val y: Float = 380f,
    val scale: Float = 1f,
    val skinToneArgb: Long = 0xFFF5C6A5L,
    val faceShape: String = "OVAL",
    val eyeStyle: String = "ANIME",
    val eyeColorArgb: Long = 0xFF2DD4BFL,
    val mouthStyle: String = "SMILE",
    val expression: String = "HAPPY",
    val hairStyle: String = "SPIKY",
    val hairColorArgb: Long = 0xFF252B3AL,
    val shirtStyle: String = "HOODIE",
    val shirtColorArgb: Long = 0xFFFF6B35L,
    val pantsColorArgb: Long = 0xFF1E293BL,
    val accessory: String = "NONE",
    val pose: String = "IDLE",
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    // Module 4: Body Build & Traditional Indian/Bengali Story Character Styling
    val bellyPlumpness: Float = 0f,       // 0f..1f
    val shoulderWidth: Float = 1.0f,      // 0.65f..1.55f
    val torsoScale: Float = 1.0f,         // 0.7f..1.45f
    val postureSlouch: Float = 0f,        // 0f..1f (hunched elderly/sage posture)
    val facialHair: String = "NONE",      // NONE, MUSTACHE, THICK_MUSTACHE, SAGE_BEARD, ROYAL_BEARD
    val hasBindi: Boolean = false,
    val bindiColorArgb: Long = 0xFFDC2626L,
    val hasBangles: Boolean = false,
    val banglesColorArgb: Long = 0xFFFACC15L,
    val dupattaColorArgb: Long = 0xFFF59E0BL,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    // Character Designer Squish & Stretch base proportions + Acting Mood Behavior
    val baseScaleX: Float = 1.0f,
    val baseScaleY: Float = 1.0f,
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name
)

@JsonClass(generateAdapter = true)
data class RigBone(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Bone",
    val parentId: String? = null,
    val length: Float = 75f,
    val localAngleDeg: Float = -90f,
    val thickness: Float = 18f,
    val colorArgb: Long = 0xFF2DD4BFL,
    // Unrestricted 360-degree continuous joint rotation (-720..+720, zero angle locks)
    val minAngleDeg: Float = -720f,
    val maxAngleDeg: Float = 720f,
    // Rig Position Mode: exact anatomical base joint pivot offset (locked when baseRigPositionLocked = true)
    val basePivotOffsetX: Float = 0f,
    val basePivotOffsetY: Float = 0f,
    // Segmented PNG Part Binding
    val boundImagePath: String? = null,
    val imageScale: Float = 1.0f,
    val pivotOffsetX: Float = 0f,
    val pivotOffsetY: Float = 0f,
    val imageRotationOffsetDeg: Float = 0f,
    // Extra variable rig attachment support (built-in prop or custom rigged asset bone on any area)
    val attachedPropKind: String? = null,
    val isExtraRigBone: Boolean = false,
    // Module 2 & 9: Individual Limb Scaling (Width X & Length Y) + Per-Bone Spring Physics
    val limbWidthScale: Float = 1.0f,
    val limbLengthScale: Float = 1.0f,
    val springStiffness: Float = 0f,      // 0f = off, >0f = secondary physics sway
    val springDamping: Float = 0.65f,     // 0.1f..1.0f
    // Image Squish & Stretch (X/Y Axis Reshaping) + Part Behavior Preset
    val baseScaleX: Float = 1.0f,
    val baseScaleY: Float = 1.0f,
    val partBehaviorPreset: String = PartBehaviorPreset.RIGID.name,
    val meshBendSmoothness: Float = 0f,
    val allowElasticStretch: Boolean = false,
    // Per-Part Draw Order / Z-Order (Higher = Front / Top, Lower = Back / Bottom)
    val zOrder: Int = 0,
    // Module 7 & 11: Bone Stretch Lock (Head bone locked by default) + Per-Bone Touch Lock
    val allowLengthStretch: Boolean = true,
    val locked: Boolean = false
)

@JsonClass(generateAdapter = true)
data class FaceFeatureTransform(
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scale: Float = 1.0f,
    val rotationDeg: Float = 0f,
    val zOrder: Int = 0,
    val visible: Boolean = true
)

@JsonClass(generateAdapter = true)
data class FaceLayersConfig(
    val leftEar: FaceFeatureTransform = FaceFeatureTransform(offsetX = -32f, offsetY = 2f, scale = 1.0f, zOrder = -10),
    val rightEar: FaceFeatureTransform = FaceFeatureTransform(offsetX = 32f, offsetY = 2f, scale = 1.0f, zOrder = -10),
    val leftEarImagePath: String? = null,
    val rightEarImagePath: String? = null,
    val nose: FaceFeatureTransform = FaceFeatureTransform(offsetX = 0f, offsetY = 6f, scale = 1.0f, zOrder = 20),
    val leftEye: FaceFeatureTransform = FaceFeatureTransform(offsetX = -14f, offsetY = -6f, scale = 1.0f, zOrder = 10),
    val rightEye: FaceFeatureTransform = FaceFeatureTransform(offsetX = 14f, offsetY = -6f, scale = 1.0f, zOrder = 10),
    val leftBrow: FaceFeatureTransform = FaceFeatureTransform(offsetX = -14f, offsetY = -18f, scale = 1.0f, zOrder = 25),
    val rightBrow: FaceFeatureTransform = FaceFeatureTransform(offsetX = 14f, offsetY = -18f, scale = 1.0f, zOrder = 25),
    val leftBrowImagePath: String? = null,
    val rightBrowImagePath: String? = null,
    val mouth: FaceFeatureTransform = FaceFeatureTransform(offsetX = 0f, offsetY = 17f, scale = 1.0f, zOrder = 15),
    // Frame-by-frame 30% onion-skin watermark builder custom frame lists (Eye / Mouth / Brow)
    val eyeBuilderFrames: List<String> = emptyList(),
    val mouthBuilderFrames: List<String> = emptyList(),
    val browBuilderFrames: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class MeshPinLink(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Fabric Stitch",
    val boneAId: String = "spine",
    val localAnchorA: Vec2 = Vec2(0f, 0.5f),
    val boneBId: String = "arm_r_up",
    val localAnchorB: Vec2 = Vec2(0f, 0.5f),
    val radiusPx: Float = 54f,
    val clothStiffness: Float = 0.65f
)

@JsonClass(generateAdapter = true)
data class RigViewAngleConfig(
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val singleMeshImagePath: String? = null,
    val boneImagePaths: Map<String, String> = emptyMap(),
    val boneLengths: Map<String, Float> = emptyMap(),
    val boneLocalAngles: Map<String, Float> = emptyMap(),
    val boneZOrders: Map<String, Int> = emptyMap(),
    val bonePivotOffsets: Map<String, Vec2> = emptyMap()
)

@JsonClass(generateAdapter = true)
data class CustomEyeContainer(
    val scleraImagePath: String? = null,
    val pupilImagePath: String? = null,
    val eyelidImagePath: String? = null,
    val eyelidColorArgb: Long = 0xFFF5C6A5L,
    val pupilScale: Float = 1.0f,
    val maxPupilOffsetPx: Float = 13f
)

@JsonClass(generateAdapter = true)
data class CustomEyePreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Custom Eyes",
    val leftEye: CustomEyeContainer = CustomEyeContainer(),
    val rightEye: CustomEyeContainer = CustomEyeContainer(),
    val syncPupils: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class EyeMoodSet(
    val mood: String = FaceMoodCategory.NORMAL.name,
    val openImagePath: String? = null,
    val halfBlinkImagePath: String? = null,
    val closedImagePath: String? = null,
    val pupilImagePath: String? = null,
    val eyelidImagePath: String? = null
)

@JsonClass(generateAdapter = true)
data class MouthMoodSet(
    val mood: String = FaceMoodCategory.NORMAL.name,
    val frame1SilentClosed: String? = null,
    val frame2SilentIdle: String? = null,
    val frame3SoftSpeech: String? = null,
    val frame4MediumSpeech: String? = null,
    val frame5WideSpeech: String? = null,
    val frame6PeakEmotion: String? = null
)

@JsonClass(generateAdapter = true)
data class FaceComboPreset(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Story Combo",
    val eyeMood: String = FaceMoodCategory.NORMAL.name,
    val mouthMood: String = FaceMoodCategory.NORMAL.name,
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val leftEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val rightEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val noseStyle: String = NoseStylePreset.CLASSIC.name
)

@JsonClass(generateAdapter = true)
data class FaceFxTriggerKeyframe(
    val id: String = UUID.randomUUID().toString(),
    val frame: Int = 0,
    val fxName: String = "Horror Scream",
    val eyeAnimPaths: List<String> = emptyList(),
    val mouthAnimPaths: List<String> = emptyList(),
    val durationFrames: Int = 24,
    val flashColorArgb: Long? = 0x55FF1744L
)

@JsonClass(generateAdapter = true)
data class DetachedBoneKeyframe(
    val frame: Int = 0,
    val boneId: String = "neck",
    val detached: Boolean = true,
    val worldX: Float = 640f,
    val worldY: Float = 260f,
    val rotationDeg: Float = 0f,
    val gravityFall: Boolean = true
)

@JsonClass(generateAdapter = true)
data class HandPropSocketKeyframe(
    val frame: Int = 0,
    val isRightHand: Boolean = true,
    val propKind: String = HandPropKind.NONE.name,
    val customImagePath: String? = null
)

@JsonClass(generateAdapter = true)
data class PropGrabKeyframe(
    val frame: Int = 0,
    val targetLayerId: String? = null,
    val targetBoneId: String? = null,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val rotationOffsetDeg: Float = 0f
)

@JsonClass(generateAdapter = true)
data class CharacterFormKeyframe(
    val id: String = UUID.randomUUID().toString(),
    val frame: Int = 0,
    val formName: String = "Normal Form",
    val formRigId: String? = null,
    val characterSpec: CharacterSpec? = null,
    val singleMeshImagePath: String? = null,
    val transitionFx: String = "NONE", // NONE, FLASH, SMOKE
    val transitionDurationFrames: Int = 8
)

@JsonClass(generateAdapter = true)
data class InstantVisibilityKeyframe(
    val frame: Int = 0,
    val visible: Boolean = true
)

@JsonClass(generateAdapter = true)
data class AnimatedFxClip(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Lamp Fire Loop",
    val frames: Map<String, FrameContent> = emptyMap(),
    val durationFrames: Int = 12,
    val createdAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class FaceAngleAdjustment(
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scaleX: Float = 1.0f,
    val scaleY: Float = 1.0f,
    val rotationDeg: Float = 0f,
    val eyeOffsetX: Float = 0f,
    val eyeOffsetY: Float = 0f,
    val eyeScale: Float = 1.0f,
    val eyeRotationDeg: Float = 0f,
    val mouthOffsetX: Float = 0f,
    val mouthOffsetY: Float = 0f,
    val mouthScale: Float = 1.0f,
    val mouthRotationDeg: Float = 0f,
    val isManualOverride: Boolean = false
)

@JsonClass(generateAdapter = true)
data class FacialTimingConfig(
    val useSecondsUnit: Boolean = false,
    // Lip-Sync Change Interval (1..120 frames or 0.05s..10.0s)
    val lipSyncIntervalFrames: Int = 4,
    val lipSyncIntervalSec: Float = 0.16f,
    // Auto-Blink Interval & Hold Duration
    val blinkIntervalFrames: Int = 60,
    val blinkIntervalSec: Float = 2.5f,
    val blinkDurationFrames: Int = 3,
    val blinkDurationSec: Float = 0.12f,
    // Emotion Loop Speed (Crying tears / Laughing bounce cycle)
    val emotionLoopSpeedFrames: Int = 12,
    val emotionLoopSpeedSec: Float = 0.50f
)

@JsonClass(generateAdapter = true)
data class PuppetRootKeyframe(
    val frame: Int = 0,
    val rootX: Float = 640f,
    val rootY: Float = 390f,
    val scale: Float = 1f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val flippedHorizontal: Boolean = false,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name,
    val easing: String = EasingType.EASE_IN_OUT.name,
    // Modules 4, 5, 6: 2.5D Face Turn, Independent Eyebrows, Pupil Joystick & Separate Mood Sets
    val headTurn25D: Float = 0f,
    val leftEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val rightEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftPupilX: Float = 0f,
    val leftPupilY: Float = 0f,
    val rightPupilX: Float = 0f,
    val rightPupilY: Float = 0f,
    val activeEyeMood: String = FaceMoodCategory.NORMAL.name,
    val activeMouthMood: String = FaceMoodCategory.NORMAL.name
)

@JsonClass(generateAdapter = true)
data class SkeletalRig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Hero Rig",
    val rootX: Float = 640f,
    val rootY: Float = 390f,
    val scale: Float = 1f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val pivotMode: String = "CENTER",     // "CENTER" or "BOTTOM_FEET"
    val flippedHorizontal: Boolean = false,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val autoWalkWhenDragged: Boolean = true,
    val autoDialogueActing: Boolean = false,
    val bones: List<RigBone> = emptyList(),
    // Map of frameIndex (as String for Moshi JSON) -> Map<boneId, angleDeg>
    val poseKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    // Module 2: Live Stretch Rig bone-length keyframes (frameIndex -> Map<boneId, boneLength>)
    val boneLengthKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    // Keyframeable Front/Back Z-Order switching during animation (frameIndex -> Map<boneId, zOrder>)
    val boneZOrderKeyframes: Map<String, Map<String, Int>> = emptyMap(),
    val rootKeyframes: List<PuppetRootKeyframe> = emptyList(),
    val showSkinMesh: Boolean = true,
    val ikEnabled: Boolean = true,
    // Optional Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh)
    val singleMeshImagePath: String? = null,
    val singleMeshWidth: Float = 260f,
    val singleMeshHeight: Float = 360f,
    // Optional Procedural Character Appearance bound directly to this skeleton
    val characterAppearance: CharacterSpec? = null,
    // Modular Facial Rig attached to Head bone
    val eyePack: String = EyePackStyle.AUTO_BLINK.name,
    val mouthPhoneme: String = MouthPhoneme.AUTO_LIPSYNC.name,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    // Module 4: Independent Left & Right Hand Gestures
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    // Hand-Held Props & Custom PNG Attachments (follow left/right hand bones automatically)
    val leftHandProp: String = HandPropKind.NONE.name,
    val rightHandProp: String = HandPropKind.NONE.name,
    val leftHandCustomImagePath: String? = null,
    val rightHandCustomImagePath: String? = null,
    val handPropScale: Float = 1.0f,
    // Keep custom PNG faces clean unless user explicitly overlays modular cartoon face
    val showFaceOverlayOnCustomImage: Boolean = false,
    // Unrestricted single-mesh PNG transform (0.05x to 8.0x scale + free X/Y offset + Squish/Stretch baseScaleX/Y)
    val singleMeshScale: Float = 1.0f,
    val singleMeshOffsetX: Float = 0f,
    val singleMeshOffsetY: Float = 0f,
    val baseScaleX: Float = 1.0f,
    val baseScaleY: Float = 1.0f,
    // Whole-Character Acting Behavior / Mood Preset
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name,
    // Modular Facial Rig positioning & scaling on imported PNG characters (locked to Head bone)
    val faceOverlayOffsetX: Float = 0f,
    val faceOverlayOffsetY: Float = 0f,
    val faceOverlayScale: Float = 1.0f,
    val faceOverlayRotationDeg: Float = 0f,
    // Custom Drawn / Imported PNG Multi-Pose Facial Slots (locked to Head bone)
    val customEyeSlots: Map<String, String> = emptyMap(),
    val customMouthSlots: Map<String, String> = emptyMap(),
    // Per-Angle Manual Fine-Tune Overrides (CharacterViewAngle.name -> FaceAngleAdjustment)
    val perAngleFaceFit: Map<String, FaceAngleAdjustment> = emptyMap(),
    // Manual Frame & Second Timing Interval Config for Lip-Sync, Auto-Blink & Emotion Loops
    val facialTiming: FacialTimingConfig = FacialTimingConfig(),
    // Rig archetype: HUMAN, BIRD, QUADRUPED, CUSTOM_OBJECT, ASSET
    val rigCategory: String = "HUMAN",
    // Module 1: Point-to-Point Mesh Pinning (localized cloth/fabric rubber stretching between pinned bone anchors)
    val meshPins: List<MeshPinLink> = emptyList(),
    // Module 2: Per-View 8-Angle Custom Artwork, Bone Layout & Z-Order Designer
    val perAngleRigConfigs: Map<String, RigViewAngleConfig> = emptyMap(),
    // Module 4: Unified Single-Container Left/Right Eyes + Custom Pupil + Sclera Alpha Masking
    val leftEyeContainer: CustomEyeContainer = CustomEyeContainer(),
    val rightEyeContainer: CustomEyeContainer = CustomEyeContainer(),
    val syncPupils: Boolean = true,
    val leftPupilX: Float = 0f,
    val leftPupilY: Float = 0f,
    val rightPupilX: Float = 0f,
    val rightPupilY: Float = 0f,
    // Module 5: Strictly Separate Eye File Sets vs. 6-Frame Mouth File Sets + Archetypes & Triggers
    val eyeMoodSets: Map<String, EyeMoodSet> = emptyMap(),
    val mouthMoodSets: Map<String, MouthMoodSet> = emptyMap(),
    val activeEyeMood: String = FaceMoodCategory.NORMAL.name,
    val activeMouthMood: String = FaceMoodCategory.NORMAL.name,
    val noseStyle: String = NoseStylePreset.CLASSIC.name,
    val customNoseImagePath: String? = null,
    val faceArchetype: String = FaceArchetypePreset.MALE.name,
    val showFaceAlignmentGuides: Boolean = false,
    val faceFxTriggers: List<FaceFxTriggerKeyframe> = emptyList(),
    val savedFaceCombos: List<FaceComboPreset> = emptyList(),
    // Module 6: 2.5D Face Turn Parallax, Auto-Dialogue Head Nod & Independent Eyebrows
    val headTurn25D: Float = 0f,
    val autoDialogueHeadBounce: Boolean = true,
    val leftEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val rightEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    // Module 7: Detachable Limbs / Severed Head + Variable Hand Prop Socket Keyframes
    val detachedBoneKeyframes: List<DetachedBoneKeyframe> = emptyList(),
    val handPropSocketKeyframes: List<HandPropSocketKeyframe> = emptyList(),
    // Module 8: Custom PNG Slots for Hand Pose / Palm Angle Switcher
    val customHandPoseSlots: Map<String, String> = emptyMap(),
    // Master Upgrade Module 1 & 3: Base Rig Pivot Position Lock + Dedicated Face Making Layers
    val baseRigPositionLocked: Boolean = false,
    val faceLayers: FaceLayersConfig = FaceLayersConfig()
)

@JsonClass(generateAdapter = true)
data class FrameVisibilityRange(
    val startFrame: Int = 0,
    val endFrame: Int = 9999
)

@JsonClass(generateAdapter = true)
data class TargetedLoopClip(
    val id: String = UUID.randomUUID().toString(),
    val loopType: String = TargetedLoopType.TALKING_LOOP.name,
    val startFrame: Int = 0,
    val endFrame: Int = 24
)

@JsonClass(generateAdapter = true)
data class CustomActionClip(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Custom Action",
    val durationFrames: Int = 24,
    // Relative frame offset ("0", "4", ...) -> boneId -> angleDeg
    val poseKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    val boneLengthKeyframes: Map<String, Map<String, Float>> = emptyMap(),
    val boneZOrderKeyframes: Map<String, Map<String, Int>> = emptyMap(),
    // Relative root offsets & expression changes
    val rootKeyframes: List<PuppetRootKeyframe> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class FrameContent(
    val strokes: List<DrawStroke> = emptyList(),
    val shapes: List<VectorShape> = emptyList(),
    val texts: List<CanvasTextItem> = emptyList(),
    val images: List<ImportedImageItem> = emptyList(),
    val characterOverride: CharacterSpec? = null
)

@JsonClass(generateAdapter = true)
data class TransformKeyframe(
    val frame: Int = 0,
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val opacity: Float = 1f,
    val easing: String = EasingType.EASE_IN_OUT.name
)

@JsonClass(generateAdapter = true)
data class CameraKeyframe(
    val frame: Int = 0,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val rotationDeg: Float = 0f,
    val easing: String = EasingType.EASE_IN_OUT.name,
    // Module 11: Keyframeable Camera Shake, Action Impact Flash & Motion Blur
    val shakeIntensity: Float = 0f,
    val impactFlashAlpha: Float = 0f,
    val impactFlashColorArgb: Long = 0xFFFFFFFFL,
    val motionBlurAmount: Float = 0f
)

@JsonClass(generateAdapter = true)
data class AnimationLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Layer 1",
    val type: String = LayerType.DRAWING.name,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val opacity: Float = 1f,
    val parallaxDepth: Float = 1f,
    val frames: Map<String, FrameContent> = emptyMap(),
    val keyframes: List<TransformKeyframe> = emptyList(),
    val motionPath: List<Vec2> = emptyList(),
    val motionPathStartFrame: Int = 0,
    val motionPathEndFrame: Int = -1,
    val motionPathOrientToPath: Boolean = false,
    val motionPathEasing: String = EasingType.EASE_IN_OUT.name,
    val character: CharacterSpec? = null,
    val rig: SkeletalRig? = null,
    // Video background/reference layer
    val videoFilePath: String? = null,
    val videoDurationMs: Long = 0L,
    // Module 1, 7, 8, 9 enhancements
    val pivotMode: String = "CENTER",
    val isCelFrameByFrame: Boolean = false,
    val visibilityRanges: List<FrameVisibilityRange> = emptyList(),
    val targetedLoops: List<TargetedLoopClip> = emptyList(),
    val groundShadowEnabled: Boolean = false,
    val rimLightColorArgb: Long? = null,
    val maskToLayerBelow: Boolean = false,
    val motionBlurStrength: Float = 0f,
    // Module 7 & 9: Variable Prop Grab Target + Same-Track Character Form Morph + Instant Visibility
    val propGrabKeyframes: List<PropGrabKeyframe> = emptyList(),
    val formMorphKeyframes: List<CharacterFormKeyframe> = emptyList(),
    val visibilityKeyframes: List<InstantVisibilityKeyframe> = emptyList(),
    // Master Upgrade Module 4: VN-Style Clip Range, Multi-Lane Sub-Track & In/Out/Loop Animations
    val clipStartFrame: Int = 0,
    val clipEndFrame: Int = -1, // -1 = extends to end of scene (Backgrounds stay 0..totalFrames!)
    val clipInAnimation: String = ClipAnimationPreset.NONE.name,
    val clipOutAnimation: String = ClipAnimationPreset.NONE.name,
    val clipLoopAnimation: String = ClipAnimationPreset.NONE.name,
    val clipAnimationFrames: Int = 8,
    val laneIndex: Int = 0,
    val clipCharacterId: String? = null
)

@JsonClass(generateAdapter = true)
data class SubtitleCue(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Wait... did you hear that?!",
    val speakerName: String = "",
    val startFrame: Int = 0,
    val endFrame: Int = 48,
    val colorArgb: Long = 0xFFFFE066L,
    val style: String = SubtitleStyle.YOUTUBE_BOLD.name
)

@JsonClass(generateAdapter = true)
data class AnimationScene(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Scene 1",
    val durationFrames: Int = 96,
    val backgroundColorArgb: Long = 0xFF141824L,
    val backgroundTemplate: String = BackgroundTemplate.PASTEL_SKY.name,
    val backgroundScrollSpeed: Float = 0f,
    val backgroundDepthBlur: Float = 0f,
    val foregroundPlaneEnabled: Boolean = true,
    val colorGrade: String = SceneColorGrade.NONE.name,
    val transition: String = SceneTransition.FADE.name,
    val activeVfx: List<String> = emptyList(),
    val subtitles: List<SubtitleCue> = emptyList(),
    val animatedTexts: List<CanvasTextItem> = emptyList(),
    val layers: List<AnimationLayer> = emptyList(),
    val cameraKeyframes: List<CameraKeyframe> = listOf(CameraKeyframe(frame = 0)),
    // Module 9: Camera Follow, Directional Spotlight & Channel Brand Watermark
    val cameraFollowLayerId: String? = null,
    val spotlightEnabled: Boolean = false,
    val spotlightX: Float = 0.5f,
    val spotlightY: Float = 0.22f,
    val spotlightRadius: Float = 0.48f,
    val spotlightIntensity: Float = 0.65f,
    val spotlightColorArgb: Long = 0xFFFFF3C4L,
    val watermarkText: String = "",
    val watermarkImagePath: String? = null,
    val watermarkOpacity: Float = 0.65f,
    val watermarkCorner: String = "BOTTOM_RIGHT"
)

@JsonClass(generateAdapter = true)
data class AudioTrackItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Track 1",
    val filePath: String = "",
    val originalFilePath: String = "",
    val kind: String = AudioTrackKind.SFX.name,
    val voiceEffect: String = VoiceEffectType.NORMAL.name,
    val startFrame: Int = 0,
    val endFrame: Int = -1, // -1 = auto from trimEndMs - trimStartMs; strict one-shot clamp!
    val loopClip: Boolean = false, // Strict One-Shot default (never loops unless explicitly enabled!)
    val durationMs: Long = 2000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 2000L,
    val volume: Float = 0.85f,
    val fadeInMs: Long = 100L,
    val fadeOutMs: Long = 150L,
    val muted: Boolean = false,
    val autoDuckMusic: Boolean = false,
    val waveformPeaks: List<Float> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AnimationProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Animation",
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 24,
    val scenes: List<AnimationScene> = emptyList(),
    val activeSceneId: String = "",
    val audioTracks: List<AudioTrackItem> = emptyList(),
    val savedCharacters: List<CharacterSpec> = emptyList(),
    val savedRigs: List<SkeletalRig> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class ProjectSummary(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val sceneCount: Int,
    val updatedAt: Long,
    val isRecoverySnapshot: Boolean = false
)

data class ExportSettings(
    val format: ExportFormat = ExportFormat.MP4,
    val width: Int = 1280,
    val height: Int = 720,
    val fps: Int = 24,
    val quality: Int = 85,
    val startFrame: Int = 0,
    val endFrame: Int = 47,
    val transparentBackground: Boolean = false,
    val exportAllScenes: Boolean = false,
    val includeAudio: Boolean = true,
    // Module 12: Hardware-Gated 1-Click PC Pro Cinema Export Preset (strictly OFF during live mobile editing!)
    val isPcProMode: Boolean = false,
    val pcProResolution4K: Boolean = false,
    val pcProClothWindPhysics: Boolean = true,
    val pcProRayCastShadows: Boolean = true,
    val pcProMotionBlur60Fps: Boolean = true,
    val pcProGodRaysAndParticles: Boolean = true,
    val pcProBokehDofAndInertia: Boolean = true
)
