package com.example.data.local

import com.example.data.model.AnimatedFxClip
import com.example.data.model.AnimationProject
import com.example.data.model.CustomActionClip
import com.example.data.model.CustomEyePreset
import com.example.data.model.ProjectSummary
import com.example.data.model.SkeletalRig
import com.example.engine.RigSolver
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ProjectRepository(
    private val projectDao: ProjectDao,
    private val assetDao: LocalAssetDao
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val projectAdapter = moshi.adapter(AnimationProject::class.java)
    private val rigAdapter = moshi.adapter(SkeletalRig::class.java)
    private val customActionAdapter = moshi.adapter(CustomActionClip::class.java)
    private val eyePresetAdapter = moshi.adapter(CustomEyePreset::class.java)
    private val animatedFxClipAdapter = moshi.adapter(AnimatedFxClip::class.java)

    val projectsFlow: Flow<List<ProjectSummary>> = projectDao.observeAllProjects().map { list ->
        list.map { entity ->
            ProjectSummary(
                id = entity.id,
                name = entity.name,
                width = entity.width,
                height = entity.height,
                fps = entity.fps,
                sceneCount = entity.sceneCount,
                updatedAt = entity.updatedAt,
                isRecoverySnapshot = entity.isRecoverySnapshot
            )
        }
    }

    val recoverySnapshotFlow: Flow<ProjectSummary?> = projectDao.observeRecoverySnapshot().map { entity ->
        entity?.let {
            ProjectSummary(
                id = it.id,
                name = it.name,
                width = it.width,
                height = it.height,
                fps = it.fps,
                sceneCount = it.sceneCount,
                updatedAt = it.updatedAt,
                isRecoverySnapshot = true
            )
        }
    }

    val assetsFlow: Flow<List<LocalAssetEntity>> = assetDao.observeAllAssets()

    val riggedCharactersFlow: Flow<List<SkeletalRig>> = assetsFlow.map { assets ->
        assets.filter { it.category == CATEGORY_RIGGED_CHARACTER }
            .mapNotNull { entity ->
                val payload = entity.jsonPayload ?: return@mapNotNull null
                runCatching { rigAdapter.fromJson(payload)?.let(::normalizeRigZOrder) }.getOrNull()
            }
    }

    val customAssetsFlow: Flow<List<SkeletalRig>> = assetsFlow.map { assets ->
        assets.filter { it.category == CATEGORY_CUSTOM_ASSET }
            .mapNotNull { entity ->
                val payload = entity.jsonPayload ?: return@mapNotNull null
                runCatching { rigAdapter.fromJson(payload)?.let(::normalizeRigZOrder) }.getOrNull()
            }
    }

    val customActionsFlow: Flow<List<CustomActionClip>> = assetsFlow.map { assets ->
        assets.filter { it.category == CATEGORY_CUSTOM_ACTION }
            .mapNotNull { entity ->
                val payload = entity.jsonPayload ?: return@mapNotNull null
                runCatching { customActionAdapter.fromJson(payload) }.getOrNull()
            }
    }

    val customEyePresetsFlow: Flow<List<CustomEyePreset>> = assetsFlow.map { assets ->
        assets.filter { it.category == CATEGORY_EYE_PRESET }
            .mapNotNull { entity ->
                val payload = entity.jsonPayload ?: return@mapNotNull null
                runCatching { eyePresetAdapter.fromJson(payload) }.getOrNull()
            }
    }

    val animatedFxClipsFlow: Flow<List<AnimatedFxClip>> = assetsFlow.map { assets ->
        assets.filter { it.category == CATEGORY_ANIMATED_FX_CLIP }
            .mapNotNull { entity ->
                val payload = entity.jsonPayload ?: return@mapNotNull null
                runCatching { animatedFxClipAdapter.fromJson(payload) }.getOrNull()
            }
    }

    val projectImageLibraryFlow: Flow<List<LocalAssetEntity>> = assetsFlow.map { assets ->
        assets.filter {
            it.filePath.isNotBlank() &&
                (it.category == CATEGORY_PROJECT_IMAGE || it.category == "IMAGE" || it.category == "PART")
        }.distinctBy { it.filePath }
    }

    suspend fun getProjectCount(): Int = withContext(Dispatchers.IO) {
        projectDao.getProjectCount()
    }

    suspend fun saveProject(project: AnimationProject, isRecovery: Boolean = false) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val updated = project.copy(updatedAt = now)
        val json = projectAdapter.toJson(updated)
        val entity = ProjectEntity(
            id = if (isRecovery) "recovery_${updated.id}" else updated.id,
            name = updated.name,
            width = updated.width,
            height = updated.height,
            fps = updated.fps,
            sceneCount = updated.scenes.size,
            jsonPayload = json,
            isRecoverySnapshot = isRecovery,
            createdAt = updated.createdAt,
            updatedAt = now
        )
        if (isRecovery) {
            projectDao.clearRecoverySnapshots()
        }
        projectDao.upsertProject(entity)
    }

    suspend fun loadProject(projectId: String): AnimationProject? = withContext(Dispatchers.IO) {
        val entity = projectDao.getProjectById(projectId) ?: return@withContext null
        runCatching { projectAdapter.fromJson(entity.jsonPayload)?.let(::normalizeProjectRigZOrders) }.getOrNull()
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        projectDao.deleteProjectById(projectId)
    }

    suspend fun clearRecovery() = withContext(Dispatchers.IO) {
        projectDao.clearRecoverySnapshots()
    }

    suspend fun exportProjectToJson(project: AnimationProject): String = withContext(Dispatchers.IO) {
        projectAdapter.indent("  ").toJson(project)
    }

    suspend fun importProjectFromJson(json: String): AnimationProject? = withContext(Dispatchers.IO) {
        runCatching { projectAdapter.fromJson(json)?.let(::normalizeProjectRigZOrders) }.getOrNull()
    }

    suspend fun saveLocalAsset(asset: LocalAssetEntity) = withContext(Dispatchers.IO) {
        assetDao.upsertAsset(asset)
    }

    suspend fun deleteLocalAsset(id: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById(id)
    }

    suspend fun saveRiggedCharacterToLibrary(rig: SkeletalRig) = withContext(Dispatchers.IO) {
        val json = rigAdapter.toJson(rig)
        assetDao.upsertAsset(
            LocalAssetEntity(
                id = "rig_${rig.id}",
                name = rig.name,
                category = CATEGORY_RIGGED_CHARACTER,
                filePath = rig.singleMeshImagePath.orEmpty(),
                jsonPayload = json,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteRiggedCharacterFromLibrary(rigId: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById("rig_$rigId")
    }

    suspend fun saveCustomAssetToLibrary(asset: SkeletalRig) = withContext(Dispatchers.IO) {
        val normalized = asset.copy(rigCategory = "ASSET")
        val json = rigAdapter.toJson(normalized)
        assetDao.upsertAsset(
            LocalAssetEntity(
                id = "asset_${normalized.id}",
                name = normalized.name,
                category = CATEGORY_CUSTOM_ASSET,
                filePath = normalized.singleMeshImagePath
                    ?: normalized.bones.firstNotNullOfOrNull { it.boundImagePath }.orEmpty(),
                jsonPayload = json,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteCustomAssetFromLibrary(assetId: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById("asset_$assetId")
    }

    suspend fun saveCustomAction(action: CustomActionClip) = withContext(Dispatchers.IO) {
        val json = customActionAdapter.toJson(action)
        assetDao.upsertAsset(
            LocalAssetEntity(
                id = "action_${action.id}",
                name = action.name,
                category = CATEGORY_CUSTOM_ACTION,
                filePath = "",
                jsonPayload = json,
                createdAt = action.createdAt
            )
        )
    }

    suspend fun deleteCustomAction(actionId: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById("action_$actionId")
    }

    suspend fun saveCustomEyePreset(preset: CustomEyePreset) = withContext(Dispatchers.IO) {
        val json = eyePresetAdapter.toJson(preset)
        assetDao.upsertAsset(
            LocalAssetEntity(
                id = "eyepreset_${preset.id}",
                name = preset.name,
                category = CATEGORY_EYE_PRESET,
                filePath = preset.leftEye.scleraImagePath.orEmpty(),
                jsonPayload = json,
                createdAt = preset.createdAt
            )
        )
    }

    suspend fun deleteCustomEyePreset(presetId: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById("eyepreset_$presetId")
    }

    suspend fun saveAnimatedFxClip(clip: AnimatedFxClip) = withContext(Dispatchers.IO) {
        val json = animatedFxClipAdapter.toJson(clip)
        assetDao.upsertAsset(
            LocalAssetEntity(
                id = "fxclip_${clip.id}",
                name = clip.name,
                category = CATEGORY_ANIMATED_FX_CLIP,
                filePath = "",
                jsonPayload = json,
                createdAt = clip.createdAt
            )
        )
    }

    suspend fun deleteAnimatedFxClip(clipId: String) = withContext(Dispatchers.IO) {
        assetDao.deleteAssetById("fxclip_$clipId")
    }

    suspend fun registerProjectImageInLibrary(name: String, filePath: String) = withContext(Dispatchers.IO) {
        if (filePath.isBlank()) return@withContext
        assetDao.upsertAsset(
            LocalAssetEntity(
                id = "img_${filePath.hashCode()}",
                name = name.ifBlank { "Image Part" },
                category = CATEGORY_PROJECT_IMAGE,
                filePath = filePath,
                jsonPayload = null,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun exportRigToJson(rig: SkeletalRig): String = withContext(Dispatchers.IO) {
        rigAdapter.indent("  ").toJson(rig)
    }

    suspend fun importRigFromJson(json: String): SkeletalRig? = withContext(Dispatchers.IO) {
        runCatching { rigAdapter.fromJson(json)?.let(::normalizeRigZOrder) }.getOrNull()
    }

    private fun normalizeRigZOrder(rig: SkeletalRig): SkeletalRig {
        if (rig.bones.size <= 1) return rig
        val allZeroLegacy = rig.bones.all { it.zOrder == 0 } && rig.boneZOrderKeyframes.isEmpty()
        val withHeadLock = rig.copy(
            bones = rig.bones.map { b ->
                if (b.id == "neck" || b.name.equals("Head", ignoreCase = true)) {
                    b.copy(allowLengthStretch = false)
                } else b
            }
        )
        return if (allZeroLegacy) RigSolver.applyAutoHumanLayerOrder(withHeadLock) else withHeadLock
    }

    private fun normalizeProjectRigZOrders(project: AnimationProject): AnimationProject {
        return project.copy(
            scenes = project.scenes.map { scene ->
                scene.copy(
                    layers = scene.layers.map { layer ->
                        layer.rig?.let { r -> layer.copy(rig = normalizeRigZOrder(r)) } ?: layer
                    }
                )
            },
            savedRigs = project.savedRigs.map(::normalizeRigZOrder)
        )
    }

    companion object {
        const val CATEGORY_RIGGED_CHARACTER = "RIGGED_CHARACTER"
        const val CATEGORY_CUSTOM_ASSET = "CUSTOM_ASSET"
        const val CATEGORY_CUSTOM_ACTION = "CUSTOM_ACTION"
        const val CATEGORY_EYE_PRESET = "EYE_PRESET"
        const val CATEGORY_ANIMATED_FX_CLIP = "ANIMATED_FX_CLIP"
        const val CATEGORY_PROJECT_IMAGE = "IMAGE"
    }
}
