package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val sceneCount: Int,
    val jsonPayload: String,
    val isRecoverySnapshot: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "local_assets")
data class LocalAssetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // IMAGE, SVG_VECTOR, CHARACTER, RIG, AUDIO, PROP
    val filePath: String,
    val jsonPayload: String?,
    val createdAt: Long
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE isRecoverySnapshot = 0 ORDER BY updatedAt DESC")
    fun observeAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE isRecoverySnapshot = 1 ORDER BY updatedAt DESC LIMIT 1")
    fun observeRecoverySnapshot(): Flow<ProjectEntity?>

    @Query("SELECT COUNT(*) FROM projects WHERE isRecoverySnapshot = 0")
    suspend fun getProjectCount(): Int

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)

    @Query("DELETE FROM projects WHERE isRecoverySnapshot = 1")
    suspend fun clearRecoverySnapshots()
}

@Dao
interface LocalAssetDao {
    @Query("SELECT * FROM local_assets ORDER BY createdAt DESC")
    fun observeAllAssets(): Flow<List<LocalAssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAsset(asset: LocalAssetEntity)

    @Query("DELETE FROM local_assets WHERE id = :id")
    suspend fun deleteAssetById(id: String)
}

@Database(
    entities = [ProjectEntity::class, LocalAssetEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AnimasterDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun localAssetDao(): LocalAssetDao

    companion object {
        @Volatile
        private var INSTANCE: AnimasterDatabase? = null

        fun getInstance(context: Context): AnimasterDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AnimasterDatabase::class.java,
                    "animaster_studio_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
