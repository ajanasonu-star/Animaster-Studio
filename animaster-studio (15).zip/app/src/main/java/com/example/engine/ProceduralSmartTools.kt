package com.example.engine

import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationProject
import com.example.data.model.AnimationScene
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CameraKeyframe
import com.example.data.model.CharacterSpec
import com.example.data.model.DrawStroke
import com.example.data.model.EasingType
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FrameContent
import com.example.data.model.HandGesturePose
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneTransition
import com.example.data.model.SceneVfxType
import com.example.data.model.ShapeKind
import com.example.data.model.SubtitleCue
import com.example.data.model.SubtitleStyle
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class StoryboardTemplate(val title: String, val subtitle: String) {
    BLANK_STUDIO("Blank Canvas", "Clean 1280×720 stage with drawing & background layers"),
    HERO_DEMO("Character Showcase", "Animated character + skeletal rig + keyframed camera"),
    HORROR_STORY("Horror Cartoon", "Semi-transparent Ghost rig, haunted forest, fog, lightning & captions"),
    THREE_ACT_STORY("3-Act Storyboard", "Intro, Conflict, and Finale scenes with transitions"),
    BOUNCE_STUDY("12-Principles Bounce", "Classic squash-and-stretch animation loop")
}

enum class MotionPreset(val label: String, val description: String) {
    BOUNCE_LOOP("Bounce Loop", "Energetic squash & bounce keyframes"),
    WALK_ACROSS("Walk Across", "Smooth horizontal travel with bobbing"),
    WAVE_HELLO("Wave & Pop", "Scale pop entrance with gentle tilt"),
    ORBIT_FLOAT("Zero-G Float", "Curved floating motion path + rotation"),
    DRAMATIC_ZOOM("Camera Zoom-In", "Adds eased camera push-in keyframes")
}

enum class ProceduralPropKind(val label: String) {
    STARBURST("Starburst"),
    SPEECH_BUBBLE("Speech Bubble"),
    AESTHETIC_SPEECH_BUBBLE("Pastel Bubble"),
    CARTOON_CLOUD("Fluffy Cloud"),
    PINE_TREE("Stylized Tree"),
    ROCKET_SHIP("Mini Rocket"),
    LIGHTNING("Energy Bolt")
}

enum class AutoActionKind(val label: String, val description: String) {
    CARTOON_JUMP_LAND("Jump & Land", "Anticipation crouch, high arc jump, and squash landing"),
    ANIME_PUNCH("Anime Punch", "Wind-up, 2-frame impact hit-stop, and camera shake"),
    FAST_RUN_CYCLE("Fast Run", "Energetic forward sprint with pumping arms & legs"),
    COMEDIC_SLIP_FALL("Slip & Fall", "Cartoon banana-slip kick up, tumble spin, and flat splat")
}

object ProceduralSmartTools {

    val characterPresets: List<CharacterSpec> = listOf(
        CharacterSpec(
            id = "preset_nova",
            name = "Nova",
            skinToneArgb = 0xFFF5C6A5L,
            faceShape = "OVAL",
            eyeStyle = "ANIME",
            eyeColorArgb = 0xFF2DD4BFL,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFF1F2937L,
            shirtStyle = "HOODIE",
            shirtColorArgb = 0xFFFF6B35L,
            pantsColorArgb = 0xFF1E293BL,
            accessory = "HEADPHONES",
            pose = "WAVE"
        ),
        CharacterSpec(
            id = "preset_luna",
            name = "Luna",
            skinToneArgb = 0xFFE8B496L,
            faceShape = "CHIBI",
            eyeStyle = "STAR",
            eyeColorArgb = 0xFFA78BFAL,
            mouthStyle = "CAT",
            expression = "WINK",
            hairStyle = "PONYTAIL",
            hairColorArgb = 0xFF4C1D95L,
            shirtStyle = "CAPE",
            shirtColorArgb = 0xFF06B6D4L,
            pantsColorArgb = 0xFF312E81L,
            accessory = "CROWN",
            pose = "HERO"
        ),
        CharacterSpec(
            id = "preset_kai",
            name = "Kai",
            skinToneArgb = 0xFFC68642L,
            faceShape = "SQUARE",
            eyeStyle = "COOL",
            eyeColorArgb = 0xFFFBBF24L,
            mouthStyle = "SMIRK",
            expression = "NEUTRAL",
            hairStyle = "CURLY",
            hairColorArgb = 0xFF111827L,
            shirtStyle = "JACKET",
            shirtColorArgb = 0xFF10B981L,
            pantsColorArgb = 0xFF0F172AL,
            accessory = "GLASSES",
            pose = "WALK_A"
        ),
        CharacterSpec(
            id = "preset_pip",
            name = "Pip",
            skinToneArgb = 0xFFFFDFC4L,
            faceShape = "ROUND",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFF38BDF8L,
            mouthStyle = "OPEN",
            expression = "SURPRISED",
            hairStyle = "BOB",
            hairColorArgb = 0xFFEC4899L,
            shirtStyle = "TEE",
            shirtColorArgb = 0xFFF59E0BL,
            pantsColorArgb = 0xFF334155L,
            accessory = "SCARF",
            pose = "JUMP"
        ),
        CharacterSpec(
            id = "preset_phantom_ghost",
            name = "Phantom Ghost",
            skinToneArgb = 0xFFD8F3FCL,
            faceShape = "OVAL",
            eyeStyle = "STAR",
            eyeColorArgb = 0xFF38BDF8L,
            mouthStyle = "O_SHAPE",
            expression = "SURPRISED",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFFE0F2FEL,
            shirtStyle = "CAPE",
            shirtColorArgb = 0xFFBAE6FDL,
            pantsColorArgb = 0xFF7DD3FCL,
            accessory = "NONE",
            pose = "HERO",
            eyePack = EyePackStyle.SURPRISED.name,
            mouthPhoneme = MouthPhoneme.SHOCK.name
        ),
        CharacterSpec(
            id = "preset_shadow_reaper",
            name = "Shadow Reaper",
            skinToneArgb = 0xFF334155L,
            faceShape = "SQUARE",
            eyeStyle = "COOL",
            eyeColorArgb = 0xFFEF4444L,
            mouthStyle = "SMIRK",
            expression = "NEUTRAL",
            hairStyle = "MOHAWK",
            hairColorArgb = 0xFF090D16L,
            shirtStyle = "CAPE",
            shirtColorArgb = 0xFF111827L,
            pantsColorArgb = 0xFF030712L,
            accessory = "SCARF",
            pose = "HERO",
            eyePack = EyePackStyle.ANGRY.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name
        ),
        CharacterSpec(
            id = "preset_zombie_kid",
            name = "Zombie Kid",
            skinToneArgb = 0xFF84CC16L,
            faceShape = "ROUND",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFFFEF08AL,
            mouthStyle = "OPEN",
            expression = "SURPRISED",
            hairStyle = "CURLY",
            hairColorArgb = 0xFF1E293BL,
            shirtStyle = "HOODIE",
            shirtColorArgb = 0xFF4C1D95L,
            pantsColorArgb = 0xFF1E1B4BL,
            accessory = "NONE",
            pose = "WALK_A",
            eyePack = EyePackStyle.SIDE_LOOK.name,
            mouthPhoneme = MouthPhoneme.A.name
        ),
        CharacterSpec(
            id = "preset_yt_host",
            name = "YouTube Host",
            skinToneArgb = 0xFFF5C6A5L,
            faceShape = "CHIBI",
            eyeStyle = "ANIME",
            eyeColorArgb = 0xFFFF3B5CL,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFF0F172AL,
            shirtStyle = "HOODIE",
            shirtColorArgb = 0xFFEF4444L,
            pantsColorArgb = 0xFF1E293BL,
            accessory = "HEADPHONES",
            pose = "WAVE",
            eyePack = EyePackStyle.HAPPY.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name
        ),
        // Traditional Indian / Bengali Story Presets (Module 4)
        CharacterSpec(
            id = "preset_zamindar_uncle",
            name = "Zamindar Uncle",
            skinToneArgb = 0xFFD99E6AL,
            faceShape = "ROUND",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFF1E293BL,
            mouthStyle = "SMIRK",
            expression = "HAPPY",
            hairStyle = "BOB",
            hairColorArgb = 0xFF334155L,
            shirtStyle = "PANJABI_DHOTI",
            shirtColorArgb = 0xFFF59E0BL,
            pantsColorArgb = 0xFFFFFBF0L,
            accessory = "SCARF",
            pose = "IDLE",
            eyePack = EyePackStyle.AUTO_BLINK.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
            bellyPlumpness = 0.72f,
            shoulderWidth = 1.12f,
            torsoScale = 1.08f,
            facialHair = "THICK_MUSTACHE",
            dupattaColorArgb = 0xFFDC2626L
        ),
        CharacterSpec(
            id = "preset_village_didi",
            name = "Village Didi",
            skinToneArgb = 0xFFE3A978L,
            faceShape = "OVAL",
            eyeStyle = "ANIME",
            eyeColorArgb = 0xFF1F2937L,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "BRAID_BENI",
            hairColorArgb = 0xFF0F172AL,
            shirtStyle = "SAREE",
            shirtColorArgb = 0xFFDC2626L,
            pantsColorArgb = 0xFFFDE047L,
            accessory = "NONE",
            pose = "WAVE",
            eyePack = EyePackStyle.AUTO_BLINK.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
            hasBindi = true,
            bindiColorArgb = 0xFFDC2626L,
            hasBangles = true,
            banglesColorArgb = 0xFFFACC15L,
            dupattaColorArgb = 0xFFFBBF24L
        ),
        CharacterSpec(
            id = "preset_village_hero",
            name = "Raju (Kurta)",
            skinToneArgb = 0xFFDC9F6BL,
            faceShape = "OVAL",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFF111827L,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFF111827L,
            shirtStyle = "KURTA_PAJAMA",
            shirtColorArgb = 0xFF0EA5E9L,
            pantsColorArgb = 0xFFF8FAFCL,
            accessory = "NONE",
            pose = "HERO",
            eyePack = EyePackStyle.AUTO_BLINK.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
            shoulderWidth = 1.08f
        ),
        CharacterSpec(
            id = "preset_grandma_dida",
            name = "Grandma Dida",
            skinToneArgb = 0xFFDAA475L,
            faceShape = "ROUND",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFF1E293BL,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "TRADITIONAL_BUN",
            hairColorArgb = 0xFFE2E8F0L,
            shirtStyle = "SAREE",
            shirtColorArgb = 0xFFF8FAFCL,
            pantsColorArgb = 0xFFEF4444L,
            accessory = "GLASSES",
            pose = "IDLE",
            eyePack = EyePackStyle.HAPPY.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
            postureSlouch = 0.35f,
            bellyPlumpness = 0.25f,
            hasBindi = true,
            bindiColorArgb = 0xFFB91C1CL,
            hasBangles = true,
            banglesColorArgb = 0xFFF8FAFCL,
            dupattaColorArgb = 0xFFDC2626L
        ),
        CharacterSpec(
            id = "preset_tantrik_sage",
            name = "Tantrik Sage",
            skinToneArgb = 0xFFB87B4BL,
            faceShape = "SQUARE",
            eyeStyle = "COOL",
            eyeColorArgb = 0xFFF97316L,
            mouthStyle = "SMIRK",
            expression = "NEUTRAL",
            hairStyle = "SAGE_JATA",
            hairColorArgb = 0xFF1E293BL,
            shirtStyle = "TANTRIK_ROBE",
            shirtColorArgb = 0xFF991B1BL,
            pantsColorArgb = 0xFF450A0AL,
            accessory = "SCARF",
            pose = "HERO",
            eyePack = EyePackStyle.ANGRY.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
            facialHair = "SAGE_BEARD",
            hasBindi = true,
            bindiColorArgb = 0xFFF97316L,
            dupattaColorArgb = 0xFFEA580CL
        ),
        CharacterSpec(
            id = "preset_village_chudail",
            name = "Petni Ghost",
            skinToneArgb = 0xFFCBD5E1L,
            faceShape = "OVAL",
            eyeStyle = "STAR",
            eyeColorArgb = 0xFFEF4444L,
            mouthStyle = "OPEN",
            expression = "SURPRISED",
            hairStyle = "LONG_GHOST",
            hairColorArgb = 0xFF020617L,
            shirtStyle = "VILLAGE_GHOST",
            shirtColorArgb = 0xFFE2E8F0L,
            pantsColorArgb = 0xFF94A3B8L,
            accessory = "NONE",
            pose = "WAVE",
            eyePack = EyePackStyle.SCARED_HORROR.name,
            mouthPhoneme = MouthPhoneme.SHOCK.name,
            hasBindi = true,
            bindiColorArgb = 0xFF991B1BL,
            hasBangles = true,
            banglesColorArgb = 0xFFEF4444L
        )
    )

    fun randomizeCharacter(seed: Int = Random.nextInt()): CharacterSpec {
        val rng = Random(seed)
        val skins = listOf(0xFFFFDFC4L, 0xFFF5C6A5L, 0xFFE0AC69L, 0xFFC68642L, 0xFF8D5524L)
        val hairs = listOf(0xFF111827L, 0xFF7C2D12L, 0xFF4C1D95L, 0xFFDB2777L, 0xFF0284C7L, 0xFFD97706L)
        val shirts = listOf(0xFFFF6B35L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFBBF24L, 0xFFFB7185L, 0xFF34D399L)
        val eyes = listOf(0xFF2DD4BFL, 0xFF38BDF8L, 0xFFA78BFAL, 0xFFF59E0BL, 0xFF10B981L)
        val names = listOf("Zephyr", "Milo", "Kira", "Bramble", "Vex", "Sora", "Toby", "Zara")
        return CharacterSpec(
            name = names[rng.nextInt(names.size)],
            skinToneArgb = skins[rng.nextInt(skins.size)],
            faceShape = listOf("OVAL", "ROUND", "SQUARE", "CHIBI")[rng.nextInt(4)],
            eyeStyle = listOf("ANIME", "DOT", "CARTOON", "COOL", "STAR")[rng.nextInt(5)],
            eyeColorArgb = eyes[rng.nextInt(eyes.size)],
            mouthStyle = listOf("SMILE", "OPEN", "SMIRK", "CAT", "O_SHAPE")[rng.nextInt(5)],
            expression = listOf("HAPPY", "NEUTRAL", "SURPRISED", "WINK", "TALKING")[rng.nextInt(5)],
            hairStyle = listOf("SPIKY", "BOB", "PONYTAIL", "CURLY", "MOHAWK")[rng.nextInt(5)],
            hairColorArgb = hairs[rng.nextInt(hairs.size)],
            shirtStyle = listOf("HOODIE", "TEE", "JACKET", "CAPE", "TUNIC")[rng.nextInt(5)],
            shirtColorArgb = shirts[rng.nextInt(shirts.size)],
            pantsColorArgb = listOf(0xFF1E293BL, 0xFF312E81L, 0xFF1F2937L, 0xFF3F3F46L)[rng.nextInt(4)],
            accessory = listOf("NONE", "GLASSES", "HEADPHONES", "CROWN", "SCARF", "HAT")[rng.nextInt(6)],
            pose = listOf("IDLE", "WAVE", "WALK_A", "JUMP", "HERO")[rng.nextInt(5)]
        )
    }

    fun generatePropShapes(kind: ProceduralPropKind, cx: Float, cy: Float): Pair<List<VectorShape>, List<DrawStroke>> {
        return when (kind) {
            ProceduralPropKind.STARBURST -> {
                val pts = mutableListOf<Vec2>()
                val spikes = 10
                for (i in 0..spikes * 2) {
                    val angle = i * PI / spikes - PI / 2
                    val r = if (i % 2 == 0) 85f else 38f
                    pts.add(Vec2(cx + (cos(angle) * r).toFloat(), cy + (sin(angle) * r).toFloat()))
                }
                emptyList<VectorShape>() to listOf(
                    DrawStroke(
                        tool = EditorTool.PEN_BEZIER.name,
                        points = pts,
                        colorArgb = 0xFFFBBF24L,
                        strokeWidth = 6f,
                        isClosedBezier = true
                    )
                )
            }
            ProceduralPropKind.SPEECH_BUBBLE -> {
                val bubble = VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = cx - 95f,
                    startY = cy - 60f,
                    endX = cx + 95f,
                    endY = cy + 45f,
                    strokeColorArgb = 0xFF0F172AL,
                    fillColorArgb = 0xFFF8FAFCL,
                    strokeWidth = 5f
                )
                val tail = DrawStroke(
                    tool = EditorTool.PEN_BEZIER.name,
                    points = listOf(Vec2(cx - 25f, cy + 40f), Vec2(cx - 55f, cy + 88f), Vec2(cx + 8f, cy + 44f)),
                    colorArgb = 0xFF0F172AL,
                    strokeWidth = 5f
                )
                listOf(bubble) to listOf(tail)
            }
            ProceduralPropKind.AESTHETIC_SPEECH_BUBBLE -> {
                val shadow = VectorShape(
                    kind = ShapeKind.RECTANGLE.name,
                    startX = cx - 102f,
                    startY = cy - 52f,
                    endX = cx + 108f,
                    endY = cy + 52f,
                    strokeColorArgb = 0x00000000L,
                    fillColorArgb = 0x55A78BFAL,
                    strokeWidth = 0f
                )
                val card = VectorShape(
                    kind = ShapeKind.RECTANGLE.name,
                    startX = cx - 108f,
                    startY = cy - 58f,
                    endX = cx + 102f,
                    endY = cy + 46f,
                    strokeColorArgb = 0xFF6366F1L,
                    fillColorArgb = 0xFFFFFBF5L,
                    gradientEndArgb = 0xFFFDE8F3L,
                    strokeWidth = 4f
                )
                val sparkle = VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = cx + 74f,
                    startY = cy - 68f,
                    endX = cx + 98f,
                    endY = cy - 44f,
                    strokeColorArgb = 0xFFF472B6L,
                    fillColorArgb = 0xFFFDE047L,
                    strokeWidth = 3f
                )
                val tail = DrawStroke(
                    tool = EditorTool.PEN_BEZIER.name,
                    points = listOf(Vec2(cx - 32f, cy + 46f), Vec2(cx - 58f, cy + 82f), Vec2(cx - 2f, cy + 46f)),
                    colorArgb = 0xFF6366F1L,
                    strokeWidth = 4f
                )
                listOf(shadow, card, sparkle) to listOf(tail)
            }
            ProceduralPropKind.CARTOON_CLOUD -> {
                val shapes = listOf(
                    VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 95f, startY = cy - 28f, endX = cx - 10f, endY = cy + 38f, strokeColorArgb = 0xFFE2E8F0L, fillColorArgb = 0xFFFFFFFFL, strokeWidth = 3f),
                    VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 50f, startY = cy - 62f, endX = cx + 52f, endY = cy + 32f, strokeColorArgb = 0xFFE2E8F0L, fillColorArgb = 0xFFFFFFFFL, strokeWidth = 3f),
                    VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx + 10f, startY = cy - 28f, endX = cx + 95f, endY = cy + 38f, strokeColorArgb = 0xFFE2E8F0L, fillColorArgb = 0xFFFFFFFFL, strokeWidth = 3f)
                )
                shapes to emptyList()
            }
            ProceduralPropKind.PINE_TREE -> {
                val trunk = VectorShape(kind = ShapeKind.RECTANGLE.name, startX = cx - 16f, startY = cy + 30f, endX = cx + 16f, endY = cy + 105f, strokeColorArgb = 0xFF451A03L, fillColorArgb = 0xFF78350FL, strokeWidth = 4f)
                val crown1 = VectorShape(kind = ShapeKind.POLYGON.name, startX = cx - 78f, startY = cy - 35f, endX = cx + 78f, endY = cy + 48f, polygonSides = 3, strokeColorArgb = 0xFF064E3BL, fillColorArgb = 0xFF10B981L, strokeWidth = 4f)
                val crown2 = VectorShape(kind = ShapeKind.POLYGON.name, startX = cx - 58f, startY = cy - 92f, endX = cx + 58f, endY = cy - 10f, polygonSides = 3, strokeColorArgb = 0xFF064E3BL, fillColorArgb = 0xFF34D399L, strokeWidth = 4f)
                listOf(trunk, crown1, crown2) to emptyList()
            }
            ProceduralPropKind.ROCKET_SHIP -> {
                val body = VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 34f, startY = cy - 95f, endX = cx + 34f, endY = cy + 68f, strokeColorArgb = 0xFF0F172AL, fillColorArgb = 0xFFF1F5F9L, strokeWidth = 5f)
                val window = VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 18f, startY = cy - 42f, endX = cx + 18f, endY = cy - 6f, strokeColorArgb = 0xFF0F172AL, fillColorArgb = 0xFF38BDF8L, strokeWidth = 4f)
                val flame = VectorShape(kind = ShapeKind.POLYGON.name, startX = cx - 22f, startY = cy + 60f, endX = cx + 22f, endY = cy + 115f, polygonSides = 3, strokeColorArgb = 0xFFFF6B35L, fillColorArgb = 0xFFFBBF24L, strokeWidth = 3f, rotationDeg = 180f)
                listOf(flame, body, window) to emptyList()
            }
            ProceduralPropKind.LIGHTNING -> {
                val bolt = DrawStroke(
                    tool = EditorTool.PEN_BEZIER.name,
                    points = listOf(
                        Vec2(cx + 15f, cy - 95f),
                        Vec2(cx - 42f, cy + 5f),
                        Vec2(cx + 8f, cy + 5f),
                        Vec2(cx - 22f, cy + 95f),
                        Vec2(cx + 46f, cy - 15f),
                        Vec2(cx - 4f, cy - 15f)
                    ),
                    colorArgb = 0xFF2DD4BFL,
                    strokeWidth = 7f,
                    isClosedBezier = true
                )
                emptyList<VectorShape>() to listOf(bolt)
            }
        }
    }

    fun applyMotionPreset(layer: AnimationLayer, preset: MotionPreset, totalFrames: Int): AnimationLayer {
        val mid = (totalFrames / 2).coerceAtLeast(1)
        val end = (totalFrames - 1).coerceAtLeast(2)
        return when (preset) {
            MotionPreset.BOUNCE_LOOP -> layer.copy(
                keyframes = listOf(
                    TransformKeyframe(0, 0f, -120f, 0f, 0.92f, 1.08f, 1f, EasingType.EASE_IN.name),
                    TransformKeyframe(mid, 0f, 45f, 0f, 1.18f, 0.84f, 1f, EasingType.BOUNCE.name),
                    TransformKeyframe(end, 0f, -120f, 0f, 0.92f, 1.08f, 1f, EasingType.EASE_OUT.name)
                )
            )
            MotionPreset.WALK_ACROSS -> layer.copy(
                keyframes = listOf(
                    TransformKeyframe(0, -280f, 0f, -3f, 1f, 1f, 1f, EasingType.LINEAR.name),
                    TransformKeyframe(totalFrames / 4, -140f, -18f, 3f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(mid, 0f, 0f, -3f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe((totalFrames * 3) / 4, 140f, -18f, 3f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(end, 280f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_OUT.name)
                )
            )
            MotionPreset.WAVE_HELLO -> layer.copy(
                keyframes = listOf(
                    TransformKeyframe(0, 0f, 60f, -8f, 0.4f, 0.4f, 0.2f, EasingType.BOUNCE.name),
                    TransformKeyframe(totalFrames / 3, 0f, 0f, 6f, 1.08f, 1.08f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe((totalFrames * 2) / 3, 0f, -10f, -6f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(end, 0f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_OUT.name)
                )
            )
            MotionPreset.ORBIT_FLOAT -> layer.copy(
                motionPath = listOf(
                    Vec2(640f, 360f),
                    Vec2(780f, 260f),
                    Vec2(640f, 200f),
                    Vec2(500f, 290f),
                    Vec2(640f, 360f)
                ),
                keyframes = listOf(
                    TransformKeyframe(0, 0f, 0f, -10f, 0.95f, 0.95f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(mid, 0f, 0f, 10f, 1.08f, 1.08f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(end, 0f, 0f, -10f, 0.95f, 0.95f, 1f, EasingType.EASE_IN_OUT.name)
                )
            )
            MotionPreset.DRAMATIC_ZOOM -> layer
        }
    }

    /**
     * Generates smooth camera tracking keyframes that follow a selected character or puppet layer.
     */
    fun applyCameraFollowCharacter(
        scene: AnimationScene,
        targetLayerId: String,
        logicalWidth: Int,
        logicalHeight: Int
    ): AnimationScene {
        val target = scene.layers.firstOrNull { it.id == targetLayerId } ?: return scene
        val step = (scene.durationFrames / 8).coerceAtLeast(4)
        val keys = mutableListOf<CameraKeyframe>()
        val centerX = logicalWidth * 0.5f
        val centerY = logicalHeight * 0.5f

        var f = 0
        while (f < scene.durationFrames) {
            val (px, py) = when {
                target.rig != null -> {
                    val eval = InterpolationEngine.evaluatePuppetRoot(target.rig, f)
                    eval.rootX to (eval.rootY - 60f * eval.scale)
                }
                target.character != null -> {
                    val t = InterpolationEngine.evaluateLayerTransform(target, f, scene.durationFrames)
                    (target.character.x + t.x) to (target.character.y + t.y - 40f)
                }
                else -> {
                    val t = InterpolationEngine.evaluateLayerTransform(target, f, scene.durationFrames)
                    (centerX + t.x) to (centerY + t.y)
                }
            }
            keys.add(
                CameraKeyframe(
                    frame = f,
                    panX = (px - centerX).coerceIn(-logicalWidth * 0.35f, logicalWidth * 0.35f),
                    panY = (py - centerY).coerceIn(-logicalHeight * 0.3f, logicalHeight * 0.3f),
                    zoom = 1.18f,
                    rotationDeg = 0f,
                    easing = EasingType.EASE_IN_OUT.name
                )
            )
            f += step
        }
        return scene.copy(cameraKeyframes = keys)
    }

    /**
     * Injects a snappy cartoon Camera Shake burst starting at startFrame.
     */
    fun applyCameraShake(
        scene: AnimationScene,
        startFrame: Int,
        intensity: Float = 22f
    ): AnimationScene {
        val baseCam = InterpolationEngine.evaluateCamera(scene, startFrame)
        val shakeOffsets = listOf(
            0 to (0f to 0f),
            2 to (-intensity to intensity * 0.6f),
            4 to (intensity * 0.9f to -intensity * 0.7f),
            6 to (-intensity * 0.6f to -intensity * 0.4f),
            8 to (intensity * 0.35f to intensity * 0.3f),
            10 to (0f to 0f)
        )
        val existing = scene.cameraKeyframes.filterNot { kf ->
            kf.frame in startFrame..(startFrame + 10)
        }.toMutableList()
        shakeOffsets.forEach { (dt, pair) ->
            val frame = (startFrame + dt).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(0))
            existing.add(
                CameraKeyframe(
                    frame = frame,
                    panX = baseCam.panX + pair.first,
                    panY = baseCam.panY + pair.second,
                    zoom = baseCam.zoom,
                    rotationDeg = baseCam.rotationDeg + pair.first * 0.08f,
                    easing = EasingType.LINEAR.name
                )
            )
        }
        return scene.copy(cameraKeyframes = existing.distinctBy { it.frame }.sortedBy { it.frame })
    }

    /**
     * Cinematic Dolly Zoom: smoothly zooms in/out from startFrame across ~36 frames with Ease In-Out.
     */
    fun applyCameraDollyZoom(
        scene: AnimationScene,
        startFrame: Int,
        targetZoom: Float = 1.75f
    ): AnimationScene {
        val baseCam = InterpolationEngine.evaluateCamera(scene, startFrame)
        val endFrame = (startFrame + 36).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(1))
        val k1 = CameraKeyframe(
            frame = startFrame,
            panX = baseCam.panX,
            panY = baseCam.panY,
            zoom = baseCam.zoom,
            rotationDeg = baseCam.rotationDeg,
            easing = EasingType.EASE_IN_OUT.name
        )
        val k2 = CameraKeyframe(
            frame = endFrame,
            panX = baseCam.panX,
            panY = baseCam.panY - 18f,
            zoom = targetZoom.coerceIn(0.3f, 4.0f),
            rotationDeg = baseCam.rotationDeg,
            easing = EasingType.EASE_IN_OUT.name
        )
        val cleaned = scene.cameraKeyframes.filterNot { it.frame == startFrame || it.frame == endFrame }
        return scene.copy(cameraKeyframes = (cleaned + listOf(k1, k2)).sortedBy { it.frame })
    }

    /**
     * Cinematic Pan Across: establishes the whole scene by smoothly panning left-to-right across the timeline.
     */
    fun applyCameraPanAcross(
        scene: AnimationScene,
        startFrame: Int,
        logicalWidth: Int
    ): AnimationScene {
        val endFrame = (startFrame + 48).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(1))
        val span = (logicalWidth * 0.28f).coerceIn(140f, 420f)
        val k1 = CameraKeyframe(
            frame = startFrame,
            panX = -span,
            panY = 0f,
            zoom = 1.28f,
            rotationDeg = 0f,
            easing = EasingType.EASE_IN_OUT.name
        )
        val k2 = CameraKeyframe(
            frame = endFrame,
            panX = span,
            panY = 0f,
            zoom = 1.28f,
            rotationDeg = 0f,
            easing = EasingType.EASE_IN_OUT.name
        )
        val cleaned = scene.cameraKeyframes.filterNot { it.frame == startFrame || it.frame == endFrame }
        return scene.copy(cameraKeyframes = (cleaned + listOf(k1, k2)).sortedBy { it.frame })
    }

    /**
     * Module 8: One-tap Auto-Actions generator (Cartoon Jump & Land, Anime Punch with 2-frame hit-stop + camera shake,
     * Fast Run Cycle, and Comedic Slip/Fall) supporting both Rigged Puppets and Standard Layers.
     */
    fun applyAutoActionToLayer(
        scene: AnimationScene,
        layerId: String,
        startFrame: Int,
        action: AutoActionKind
    ): AnimationScene {
        val target = scene.layers.firstOrNull { it.id == layerId } ?: return scene
        val maxFrame = (scene.durationFrames - 1).coerceAtLeast(1)
        fun cf(offset: Int) = (startFrame + offset).coerceIn(0, maxFrame)

        var updatedScene = scene
        val updatedLayer = if (target.rig != null) {
            val rig = target.rig
            val baseRoot = InterpolationEngine.evaluatePuppetRoot(rig, startFrame)
            val dir = if (baseRoot.flippedHorizontal) -1f else 1f
            val newRootKeys = rig.rootKeyframes.toMutableList()
            val newPoseKeys = rig.poseKeyframes.toMutableMap()

            fun upsertRoot(
                offset: Int,
                dx: Float = 0f,
                dy: Float = 0f,
                sx: Float = baseRoot.scaleX,
                sy: Float = baseRoot.scaleY,
                eye: String = baseRoot.eyePack,
                mouth: String = baseRoot.mouthPhoneme,
                brow: String = baseRoot.eyebrowStyle,
                lHand: String = baseRoot.leftHandGesture,
                rHand: String = baseRoot.rightHandGesture,
                easing: String = EasingType.EASE_IN_OUT.name
            ) {
                val f = cf(offset)
                newRootKeys.removeAll { it.frame == f }
                newRootKeys.add(
                    PuppetRootKeyframe(
                        frame = f,
                        rootX = baseRoot.rootX + dx,
                        rootY = baseRoot.rootY + dy,
                        scale = baseRoot.scale,
                        scaleX = sx,
                        scaleY = sy,
                        flippedHorizontal = baseRoot.flippedHorizontal,
                        viewAngle = baseRoot.viewAngle,
                        eyePack = eye,
                        mouthPhoneme = mouth,
                        eyebrowStyle = brow,
                        leftHandGesture = lHand,
                        rightHandGesture = rHand,
                        easing = easing
                    )
                )
            }

            fun upsertPose(offset: Int, poseName: String, overrides: Map<String, Float> = emptyMap()) {
                val f = cf(offset)
                val basePose = RigSolver.presetPoseAngles(poseName).toMutableMap()
                overrides.forEach { (k, v) -> basePose[k] = v }
                newPoseKeys[f.toString()] = basePose
            }

            when (action) {
                AutoActionKind.CARTOON_JUMP_LAND -> {
                    upsertRoot(0, 0f, 0f, 1f, 1f)
                    upsertPose(0, "IDLE")
                    // Anticipation crouch squash
                    upsertRoot(4, 0f, 22f, 1.22f, 0.78f, easing = EasingType.EASE_IN.name)
                    upsertPose(4, "IDLE", mapOf("thigh_l" to 58f, "shin_l" to 118f, "thigh_r" to 122f, "shin_r" to 62f, "upper_arm_l" to 145f, "upper_arm_r" to 35f))
                    // Stretch takeoff
                    upsertRoot(8, 28f * dir, -55f, 0.84f, 1.24f, eye = EyePackStyle.HAPPY.name, easing = EasingType.EASE_OUT.name)
                    upsertPose(8, "JUMP")
                    // Apex float
                    upsertRoot(14, 72f * dir, -145f, 0.96f, 1.06f, eye = EyePackStyle.SURPRISED.name, mouth = MouthPhoneme.O.name)
                    upsertPose(14, "JUMP", mapOf("upper_arm_l" to -135f, "upper_arm_r" to -45f))
                    // Fast drop stretch
                    upsertRoot(20, 118f * dir, -30f, 0.86f, 1.20f, easing = EasingType.EASE_IN.name)
                    upsertPose(20, "JUMP")
                    // Squash impact landing
                    upsertRoot(23, 130f * dir, 24f, 1.28f, 0.72f, easing = EasingType.BOUNCE.name)
                    upsertPose(23, "IDLE", mapOf("thigh_l" to 62f, "shin_l" to 118f, "thigh_r" to 118f, "shin_r" to 62f))
                    // Recover settle
                    upsertRoot(28, 135f * dir, 0f, 1f, 1f, easing = EasingType.EASE_OUT.name)
                    upsertPose(28, "IDLE")
                }
                AutoActionKind.ANIME_PUNCH -> {
                    // Ready stance
                    upsertRoot(0, 0f, 0f, 1f, 1f, brow = EyebrowStyle.ANGRY.name, lHand = HandGesturePose.FIST.name, rHand = HandGesturePose.FIST.name)
                    upsertPose(0, "IDLE")
                    // Deep wind-up pull back
                    upsertRoot(5, -26f * dir, 6f, 0.92f, 1.06f, eye = EyePackStyle.ANGRY.name, brow = EyebrowStyle.ANGRY.name, lHand = HandGesturePose.FIST.name, rHand = HandGesturePose.FIST.name, easing = EasingType.EASE_IN.name)
                    upsertPose(5, "IDLE", mapOf("torso" to -98f, "upper_arm_r" to 155f, "forearm_r" to 125f, "upper_arm_l" to 45f))
                    // Explosive punch frame (hit-stop frame 1)
                    upsertRoot(8, 68f * dir, -6f, 1.18f, 0.92f, eye = EyePackStyle.ANGRY.name, mouth = MouthPhoneme.A.name, brow = EyebrowStyle.ANGRY.name, lHand = HandGesturePose.FIST.name, rHand = HandGesturePose.FIST.name, easing = EasingType.LINEAR.name)
                    upsertPose(8, "HERO", mapOf("torso" to -76f, "upper_arm_r" to -4f, "forearm_r" to -2f, "hand_r" to 0f, "upper_arm_l" to 145f))
                    // 2-frame hit-stop hold
                    upsertRoot(10, 70f * dir, -6f, 1.18f, 0.92f, eye = EyePackStyle.ANGRY.name, mouth = MouthPhoneme.A.name, brow = EyebrowStyle.ANGRY.name, lHand = HandGesturePose.FIST.name, rHand = HandGesturePose.FIST.name, easing = EasingType.LINEAR.name)
                    upsertPose(10, "HERO", mapOf("torso" to -76f, "upper_arm_r" to -4f, "forearm_r" to -2f, "hand_r" to 0f, "upper_arm_l" to 145f))
                    // Follow-through & recover
                    upsertRoot(17, 56f * dir, 0f, 1f, 1f, brow = EyebrowStyle.NORMAL.name, lHand = HandGesturePose.RELAXED.name, rHand = HandGesturePose.RELAXED.name, easing = EasingType.EASE_OUT.name)
                    upsertPose(17, "IDLE")
                    updatedScene = applyCameraShake(updatedScene, cf(8), intensity = 26f)
                }
                AutoActionKind.FAST_RUN_CYCLE -> {
                    for (step in 0..6) {
                        val dt = step * 4
                        val stride = step * 52f * dir
                        val bob = if (step % 2 == 0) -14f else 6f
                        upsertRoot(
                            dt,
                            dx = stride,
                            dy = bob,
                            sx = if (step % 2 == 0) 1.06f else 0.95f,
                            sy = if (step % 2 == 0) 0.96f else 1.05f,
                            lHand = HandGesturePose.FIST.name,
                            rHand = HandGesturePose.FIST.name,
                            easing = EasingType.LINEAR.name
                        )
                        val isA = step % 2 == 0
                        upsertPose(
                            dt,
                            if (isA) "WALK_A" else "WALK_B",
                            mapOf(
                                "torso" to -76f,
                                "thigh_l" to if (isA) 48f else 132f,
                                "shin_l" to if (isA) 110f else 155f,
                                "thigh_r" to if (isA) 132f else 48f,
                                "shin_r" to if (isA) 155f else 110f,
                                "upper_arm_l" to if (isA) 138f else 36f,
                                "upper_arm_r" to if (isA) 36f else 138f
                            )
                        )
                    }
                }
                AutoActionKind.COMEDIC_SLIP_FALL -> {
                    upsertRoot(0, 0f, 0f, 1f, 1f)
                    upsertPose(0, "WALK_A")
                    // Foot slips forward, arms flail up
                    upsertRoot(4, 24f * dir, -28f, 0.90f, 1.15f, eye = EyePackStyle.SURPRISED.name, mouth = MouthPhoneme.SHOCK.name, brow = EyebrowStyle.RAISED.name, lHand = HandGesturePose.OPEN_PALM.name, rHand = HandGesturePose.OPEN_PALM.name)
                    upsertPose(4, "JUMP", mapOf("torso" to -125f, "thigh_l" to 15f, "thigh_r" to 35f, "upper_arm_l" to -150f, "upper_arm_r" to -30f))
                    // Mid-air upside-down tumble
                    upsertRoot(9, 55f * dir, -52f, 1.05f, 0.95f, eye = EyePackStyle.SCARED_HORROR.name, mouth = MouthPhoneme.A.name)
                    upsertPose(9, "JUMP", mapOf("torso" to -175f, "thigh_l" to -40f, "thigh_r" to -20f, "upper_arm_l" to 160f, "upper_arm_r" to 120f))
                    // Flat cartoon splat!
                    upsertRoot(14, 78f * dir, 48f, 1.38f, 0.62f, eye = EyePackStyle.WINK.name, mouth = MouthPhoneme.O.name, easing = EasingType.BOUNCE.name)
                    upsertPose(14, "IDLE", mapOf("torso" to 176f, "neck" to 170f, "head" to 168f, "thigh_l" to 4f, "shin_l" to 8f, "thigh_r" to -6f, "shin_r" to -2f))
                    // Dizzy bounce settle
                    upsertRoot(20, 82f * dir, 40f, 1.08f, 0.92f, eye = EyePackStyle.SAD_TEARS.name, easing = EasingType.EASE_OUT.name)
                    updatedScene = applyCameraShake(updatedScene, cf(14), intensity = 16f)
                }
            }
            target.copy(
                rig = rig.copy(
                    rootKeyframes = newRootKeys.sortedBy { it.frame },
                    poseKeyframes = newPoseKeys
                )
            )
        } else {
            val baseT = InterpolationEngine.evaluateLayerTransform(target, startFrame, scene.durationFrames)
            val kfs = target.keyframes.toMutableList()
            fun upsertTf(offset: Int, dx: Float, dy: Float, rot: Float, sx: Float, sy: Float, easing: String = EasingType.EASE_IN_OUT.name) {
                val f = cf(offset)
                kfs.removeAll { it.frame == f }
                kfs.add(TransformKeyframe(f, baseT.x + dx, baseT.y + dy, baseT.rotationDeg + rot, baseT.scaleX * sx, baseT.scaleY * sy, baseT.opacity, easing))
            }
            when (action) {
                AutoActionKind.CARTOON_JUMP_LAND -> {
                    upsertTf(0, 0f, 0f, 0f, 1f, 1f)
                    upsertTf(4, 0f, 20f, 0f, 1.24f, 0.76f, EasingType.EASE_IN.name)
                    upsertTf(12, 60f, -135f, -6f, 0.88f, 1.18f, EasingType.EASE_OUT.name)
                    upsertTf(20, 120f, 22f, 4f, 1.28f, 0.72f, EasingType.BOUNCE.name)
                    upsertTf(26, 124f, 0f, 0f, 1f, 1f, EasingType.EASE_OUT.name)
                }
                AutoActionKind.ANIME_PUNCH -> {
                    upsertTf(0, 0f, 0f, 0f, 1f, 1f)
                    upsertTf(5, -28f, 0f, -10f, 0.90f, 1.08f, EasingType.EASE_IN.name)
                    upsertTf(8, 72f, -4f, 12f, 1.26f, 0.88f, EasingType.LINEAR.name)
                    upsertTf(10, 72f, -4f, 12f, 1.26f, 0.88f, EasingType.LINEAR.name)
                    upsertTf(16, 48f, 0f, 0f, 1f, 1f, EasingType.EASE_OUT.name)
                    updatedScene = applyCameraShake(updatedScene, cf(8), intensity = 24f)
                }
                AutoActionKind.FAST_RUN_CYCLE -> {
                    for (step in 0..6) {
                        upsertTf(step * 4, step * 52f, if (step % 2 == 0) -14f else 6f, 8f, if (step % 2 == 0) 1.08f else 0.94f, if (step % 2 == 0) 0.94f else 1.08f, EasingType.LINEAR.name)
                    }
                }
                AutoActionKind.COMEDIC_SLIP_FALL -> {
                    upsertTf(0, 0f, 0f, 0f, 1f, 1f)
                    upsertTf(5, 25f, -48f, -42f, 0.92f, 1.12f)
                    upsertTf(12, 72f, 38f, -92f, 1.32f, 0.68f, EasingType.BOUNCE.name)
                    upsertTf(18, 76f, 34f, -88f, 1.04f, 0.96f, EasingType.EASE_OUT.name)
                    updatedScene = applyCameraShake(updatedScene, cf(12), intensity = 16f)
                }
            }
            target.copy(keyframes = kfs.sortedBy { it.frame })
        }

        return updatedScene.copy(
            layers = updatedScene.layers.map { if (it.id == layerId) updatedLayer else it }
        )
    }

    fun createProjectFromTemplate(
        name: String,
        width: Int = 1280,
        height: Int = 720,
        fps: Int = 24,
        template: StoryboardTemplate = StoryboardTemplate.HERO_DEMO
    ): AnimationProject {
        val projectId = UUID.randomUUID().toString()
        val scenes = when (template) {
            StoryboardTemplate.BLANK_STUDIO -> {
                val scene = AnimationScene(
                    name = "Scene 1",
                    durationFrames = 96,
                    backgroundTemplate = BackgroundTemplate.GRID_PAPER.name,
                    layers = listOf(
                        AnimationLayer(name = "Ink Layer", type = LayerType.DRAWING.name),
                        AnimationLayer(name = "Sketch Layer", type = LayerType.DRAWING.name, opacity = 0.7f)
                    )
                )
                listOf(scene)
            }
            StoryboardTemplate.HERO_DEMO -> {
                val novaRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = characterPresets[0],
                    rootX = width * 0.32f,
                    rootY = height * 0.62f
                ).copy(
                    autoWalkWhenDragged = true,
                    eyePack = EyePackStyle.AUTO_BLINK.name,
                    mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(
                            frame = 0,
                            rootX = width * 0.28f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = false,
                            eyePack = EyePackStyle.AUTO_BLINK.name,
                            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 36,
                            rootX = width * 0.40f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = false,
                            eyePack = EyePackStyle.HAPPY.name,
                            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 95,
                            rootX = width * 0.36f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = false,
                            eyePack = EyePackStyle.AUTO_BLINK.name,
                            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                            easing = EasingType.EASE_OUT.name
                        )
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("IDLE"),
                        "18" to RigSolver.presetPoseAngles("WALK"),
                        "42" to RigSolver.presetPoseAngles("WAVE"),
                        "72" to RigSolver.presetPoseAngles("JUMP"),
                        "95" to RigSolver.presetPoseAngles("IDLE")
                    )
                )
                val lunaRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = characterPresets[1],
                    rootX = width * 0.68f,
                    rootY = height * 0.62f
                ).copy(
                    flippedHorizontal = true,
                    eyePack = EyePackStyle.HAPPY.name,
                    mouthPhoneme = MouthPhoneme.SMILE.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(
                            frame = 0,
                            rootX = width * 0.72f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = true,
                            eyePack = EyePackStyle.HAPPY.name,
                            mouthPhoneme = MouthPhoneme.SMILE.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 48,
                            rootX = width * 0.64f,
                            rootY = height * 0.60f,
                            scale = 1.03f,
                            flippedHorizontal = true,
                            eyePack = EyePackStyle.WINK.name,
                            mouthPhoneme = MouthPhoneme.A.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 95,
                            rootX = width * 0.70f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = true,
                            eyePack = EyePackStyle.HAPPY.name,
                            mouthPhoneme = MouthPhoneme.SMILE.name,
                            easing = EasingType.EASE_OUT.name
                        )
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("IDLE"),
                        "30" to RigSolver.presetPoseAngles("WAVE"),
                        "60" to RigSolver.presetPoseAngles("IDLE"),
                        "95" to RigSolver.presetPoseAngles("WAVE")
                    )
                )
                val novaLayer = AnimationLayer(
                    name = "Nova (Puppet)",
                    type = LayerType.RIG.name,
                    rig = novaRig
                )
                val lunaLayer = AnimationLayer(
                    name = "Luna (Puppet)",
                    type = LayerType.RIG.name,
                    rig = lunaRig
                )
                val (bubbleShapes, bubbleStrokes) = generatePropShapes(
                    ProceduralPropKind.AESTHETIC_SPEECH_BUBBLE,
                    width * 0.50f,
                    height * 0.22f
                )
                val fxLayer = AnimationLayer(
                    name = "FX & Props",
                    type = LayerType.DRAWING.name,
                    parallaxDepth = 1.0f,
                    frames = mapOf("0" to FrameContent(shapes = bubbleShapes, strokes = bubbleStrokes))
                )
                listOf(
                    AnimationScene(
                        name = "Act 1 • Main Stage",
                        durationFrames = 96,
                        backgroundTemplate = BackgroundTemplate.PASTEL_SKY.name,
                        activeVfx = listOf(SceneVfxType.FIREFLIES.name),
                        layers = listOf(novaLayer, lunaLayer, fxLayer),
                        cameraKeyframes = listOf(
                            CameraKeyframe(0, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name),
                            CameraKeyframe(48, 0f, -12f, 1.06f, 0f, EasingType.EASE_IN_OUT.name),
                            CameraKeyframe(95, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name)
                        )
                    )
                )
            }
            StoryboardTemplate.HORROR_STORY -> {
                val ghostSpec = characterPresets.first { it.id == "preset_phantom_ghost" }
                val heroSpec = characterPresets.first { it.id == "preset_nova" }
                val ghostRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = ghostSpec,
                    rootX = width * 0.72f,
                    rootY = height * 0.44f
                ).copy(
                    flippedHorizontal = true,
                    autoWalkWhenDragged = false,
                    eyePack = EyePackStyle.SURPRISED.name,
                    mouthPhoneme = MouthPhoneme.SHOCK.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(frame = 0, rootX = width * 0.84f, rootY = height * 0.42f, scale = 0.92f, flippedHorizontal = true, eyePack = EyePackStyle.SURPRISED.name, mouthPhoneme = MouthPhoneme.REST.name),
                        PuppetRootKeyframe(frame = 36, rootX = width * 0.68f, rootY = height * 0.36f, scale = 1.04f, flippedHorizontal = true, eyePack = EyePackStyle.ANGRY.name, mouthPhoneme = MouthPhoneme.O.name),
                        PuppetRootKeyframe(frame = 64, rootX = width * 0.56f, rootY = height * 0.40f, scale = 1.15f, flippedHorizontal = true, eyePack = EyePackStyle.ANGRY.name, mouthPhoneme = MouthPhoneme.SHOCK.name),
                        PuppetRootKeyframe(frame = 95, rootX = width * 0.70f, rootY = height * 0.35f, scale = 1.0f, flippedHorizontal = true, eyePack = EyePackStyle.SURPRISED.name, mouthPhoneme = MouthPhoneme.REST.name)
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("IDLE"),
                        "36" to RigSolver.presetPoseAngles("WAVE"),
                        "64" to RigSolver.presetPoseAngles("JUMP"),
                        "95" to RigSolver.presetPoseAngles("IDLE")
                    )
                )
                val heroRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = heroSpec,
                    rootX = width * 0.28f,
                    rootY = height * 0.58f
                ).copy(
                    autoWalkWhenDragged = true,
                    eyePack = EyePackStyle.SURPRISED.name,
                    mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(frame = 0, rootX = width * 0.24f, rootY = height * 0.58f, scale = 1f, flippedHorizontal = false, eyePack = EyePackStyle.SIDE_LOOK.name, mouthPhoneme = MouthPhoneme.REST.name),
                        PuppetRootKeyframe(frame = 48, rootX = width * 0.34f, rootY = height * 0.58f, scale = 1f, flippedHorizontal = false, eyePack = EyePackStyle.SURPRISED.name, mouthPhoneme = MouthPhoneme.SHOCK.name),
                        PuppetRootKeyframe(frame = 95, rootX = width * 0.20f, rootY = height * 0.58f, scale = 1f, flippedHorizontal = true, eyePack = EyePackStyle.SURPRISED.name, mouthPhoneme = MouthPhoneme.A.name)
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("WALK_A"),
                        "24" to RigSolver.presetPoseAngles("WALK_B"),
                        "48" to RigSolver.presetPoseAngles("JUMP"),
                        "95" to RigSolver.presetPoseAngles("WALK_A")
                    )
                )
                val baseScene = AnimationScene(
                    name = "Act 1 • Haunted Woods",
                    durationFrames = 96,
                    backgroundTemplate = BackgroundTemplate.HAUNTED_FOREST.name,
                    backgroundScrollSpeed = 1.6f,
                    colorGrade = SceneColorGrade.HORROR_COLD.name,
                    activeVfx = listOf(
                        SceneVfxType.SPOOKY_FOG.name,
                        SceneVfxType.LIGHTNING_FLASH.name,
                        SceneVfxType.VIGNETTE_HORROR.name
                    ),
                    subtitles = listOf(
                        SubtitleCue(
                            text = "WAIT... WHO IS BEHIND ME?!",
                            speakerName = "NOVA",
                            startFrame = 8,
                            endFrame = 52,
                            colorArgb = 0xFFFFE066L,
                            style = SubtitleStyle.YOUTUBE_BOLD.name
                        ),
                        SubtitleCue(
                            text = "BOO! DO NOT TURN AROUND...",
                            speakerName = "PHANTOM",
                            startFrame = 54,
                            endFrame = 92,
                            colorArgb = 0xFFFF4D6DL,
                            style = SubtitleStyle.HORROR_DRIP.name
                        )
                    ),
                    layers = listOf(
                        AnimationLayer(
                            name = "Nova (Hero)",
                            type = LayerType.RIG.name,
                            rig = heroRig
                        ),
                        AnimationLayer(
                            name = "Phantom Ghost (55%)",
                            type = LayerType.RIG.name,
                            opacity = 0.55f,
                            rig = ghostRig
                        ),
                        AnimationLayer(
                            name = "Spooky FX Sketch",
                            type = LayerType.DRAWING.name
                        )
                    ),
                    cameraKeyframes = listOf(
                        CameraKeyframe(0, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(52, 20f, -10f, 1.12f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(95, 0f, 0f, 1.04f, 0f, EasingType.EASE_IN_OUT.name)
                    )
                )
                listOf(applyCameraShake(baseScene, startFrame = 56, intensity = 22f))
            }
            StoryboardTemplate.THREE_ACT_STORY -> {
                val scene1 = AnimationScene(
                    name = "Act 1 • Arrival",
                    durationFrames = 36,
                    backgroundTemplate = BackgroundTemplate.SUNNY_MEADOW.name,
                    transition = SceneTransition.FADE.name,
                    layers = listOf(
                        AnimationLayer(
                            name = "Protagonist",
                            type = LayerType.CHARACTER.name,
                            character = characterPresets[0].copy(x = width * 0.35f, y = height * 0.62f, pose = "WALK_A"),
                            keyframes = listOf(
                                TransformKeyframe(0, -180f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_OUT.name),
                                TransformKeyframe(35, 160f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name)
                            )
                        ),
                        AnimationLayer(name = "Foreground FX", type = LayerType.DRAWING.name, parallaxDepth = 1.3f)
                    )
                )
                val scene2 = AnimationScene(
                    name = "Act 2 • Discovery",
                    durationFrames = 36,
                    backgroundTemplate = BackgroundTemplate.OUTER_SPACE.name,
                    transition = SceneTransition.SLIDE_LEFT.name,
                    layers = listOf(
                        AnimationLayer(
                            name = "Explorer",
                            type = LayerType.CHARACTER.name,
                            character = characterPresets[1].copy(x = width * 0.5f, y = height * 0.55f, pose = "JUMP", expression = "SURPRISED")
                        ),
                        AnimationLayer(name = "Sketch Layer", type = LayerType.DRAWING.name)
                    ),
                    cameraKeyframes = listOf(
                        CameraKeyframe(0, 0f, 0f, 0.95f, 0f),
                        CameraKeyframe(35, 0f, -20f, 1.25f, 0f)
                    )
                )
                val scene3 = AnimationScene(
                    name = "Act 3 • Finale",
                    durationFrames = 36,
                    backgroundTemplate = BackgroundTemplate.SUNSET_DESERT.name,
                    transition = SceneTransition.ZOOM_IN.name,
                    layers = listOf(
                        AnimationLayer(
                            name = "Hero Pose",
                            type = LayerType.CHARACTER.name,
                            character = characterPresets[2].copy(x = width * 0.5f, y = height * 0.6f, pose = "HERO", expression = "HAPPY")
                        ),
                        AnimationLayer(name = "Title & Ink", type = LayerType.DRAWING.name)
                    )
                )
                listOf(scene1, scene2, scene3)
            }
            StoryboardTemplate.BOUNCE_STUDY -> {
                val ball = VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = width * 0.5f - 58f,
                    startY = height * 0.5f - 58f,
                    endX = width * 0.5f + 58f,
                    endY = height * 0.5f + 58f,
                    strokeColorArgb = 0xFFFFFFFFL,
                    fillColorArgb = 0xFFFF6B35L,
                    gradientEndArgb = 0xFFFBBF24L,
                    strokeWidth = 6f
                )
                val ballLayer = applyMotionPreset(
                    AnimationLayer(
                        name = "Bouncing Ball",
                        type = LayerType.DRAWING.name,
                        frames = mapOf("0" to FrameContent(shapes = listOf(ball)))
                    ),
                    MotionPreset.BOUNCE_LOOP,
                    36
                )
                listOf(
                    AnimationScene(
                        name = "Bounce Cycle",
                        durationFrames = 36,
                        backgroundTemplate = BackgroundTemplate.COZY_STUDIO.name,
                        layers = listOf(
                            ballLayer,
                            AnimationLayer(name = "Motion Arcs", type = LayerType.DRAWING.name)
                        )
                    )
                )
            }
        }

        return AnimationProject(
            id = projectId,
            name = name.ifBlank { "Untitled Studio" },
            width = width,
            height = height,
            fps = fps,
            scenes = scenes,
            activeSceneId = scenes.first().id,
            savedCharacters = characterPresets,
            savedRigs = characterPresets.map { RigSolver.createRiggedCharacterFromSpec(it) } + listOf(
                RigSolver.createHumanoidRig(),
                RigSolver.createCartoonMascotRig()
            )
        )
    }
}
