package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import com.example.data.model.AnimationScene
import com.example.data.model.ExportSettings
import com.example.data.model.SceneVfxType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Module 12: Hardware-Gated 1-Click PC Pro Cinema Export Renderer.
 *
 * Strictly invoked ONLY during export when `ExportSettings.isPcProMode == true`.
 * Live mobile canvas editing NEVER executes these heavy passes so mobile RAM and
 * 60FPS touch latency remain silky-smooth.
 */
object PcProCinemaRenderer {

    /**
     * Applies the enabled PC Pro Cinema post-processing passes onto a newly allocated ARGB_8888 Bitmap.
     * Caller owns recycling both the input [currentBmp] (if replaced) and the returned Bitmap.
     */
    fun applyCinemaPostPass(
        currentBmp: Bitmap,
        prevBmp: Bitmap?,
        scene: AnimationScene,
        frameIndex: Int,
        totalFrames: Int,
        fps: Int,
        settings: ExportSettings
    ): Bitmap {
        if (!settings.isPcProMode) return currentBmp

        val w = currentBmp.width.coerceAtLeast(1)
        val h = currentBmp.height.coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val basePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val timeSec = frameIndex.toFloat() / fps.coerceAtLeast(1).toFloat()

        // 1. Cloth / Hair Wind Physics + Secondary Body Inertia Micro-Bounce
        if (settings.pcProClothWindPhysics || settings.pcProBokehDofAndInertia) {
            drawWindAndInertiaMesh(
                canvas = canvas,
                src = currentBmp,
                timeSec = timeSec,
                enableWind = settings.pcProClothWindPhysics,
                enableInertia = settings.pcProBokehDofAndInertia,
                paint = basePaint
            )
        } else {
            canvas.drawBitmap(currentBmp, 0f, 0f, basePaint)
        }

        // 2. Per-Limb Velocity Motion Blur temporal ghost blend (uses previous frame)
        if (settings.pcProMotionBlur60Fps && prevBmp != null && !prevBmp.isRecycled &&
            prevBmp.width == w && prevBmp.height == h
        ) {
            val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = 58
            }
            val shiftX = sin(timeSec * 8f) * (w * 0.0022f)
            canvas.drawBitmap(prevBmp, shiftX, 0f, blurPaint)
        }

        // 3. Ray-Cast Directional Soft Shadows & Ambient Occlusion Ground Depth
        if (settings.pcProRayCastShadows) {
            drawRayCastShadowsAndAo(canvas, w.toFloat(), h.toFloat(), timeSec)
        }

        // 4. Volumetric Sunbeams (God-Rays) & Atmospheric Dust/Ember/Rain Particles
        if (settings.pcProGodRaysAndParticles) {
            drawVolumetricGodRaysAndParticles(canvas, w.toFloat(), h.toFloat(), scene, frameIndex, timeSec)
        }

        // 5. Cinematic Bokeh Depth-of-Field peripheral softness & cinema edge grade
        if (settings.pcProBokehDofAndInertia) {
            drawCinematicBokehDof(canvas, currentBmp, w.toFloat(), h.toFloat())
        }

        return out
    }

    private fun drawWindAndInertiaMesh(
        canvas: Canvas,
        src: Bitmap,
        timeSec: Float,
        enableWind: Boolean,
        enableInertia: Boolean,
        paint: Paint
    ) {
        val w = src.width.toFloat()
        val h = src.height.toFloat()
        val cols = 12
        val rows = 8
        val verts = FloatArray((cols + 1) * (rows + 1) * 2)

        // Subtle vertical secondary inertia breathing (keeps composition locked, adds life)
        val inertiaScaleY = if (enableInertia) 1f + sin(timeSec * 2.6f * PI.toFloat()) * 0.0035f else 1f
        val inertiaShiftY = if (enableInertia) (1f - inertiaScaleY) * h * 0.5f else 0f

        var idx = 0
        for (r in 0..rows) {
            val v = r.toFloat() / rows.toFloat()
            val baseY = v * h
            // Cloth/hair shimmer increases gently toward lower & upper silhouette edges, zero at strict borders
            val edgeFadeY = sin(v * PI.toFloat())
            val clothZone = if (v > 0.42f) (v - 0.42f) / 0.58f else (0.42f - v) * 0.35f
            for (c in 0..cols) {
                val u = c.toFloat() / cols.toFloat()
                val baseX = u * w
                val edgeFadeX = sin(u * PI.toFloat())
                val windAmp = if (enableWind) (w * 0.0032f) * edgeFadeX * edgeFadeY * clothZone else 0f
                val wave = sin((timeSec * 3.8f) + u * 6.5f + v * 4.2f)
                val dx = wave * windAmp
                val dy = cos((timeSec * 2.9f) + u * 5.0f) * (windAmp * 0.35f)
                verts[idx++] = baseX + dx
                verts[idx++] = baseY * inertiaScaleY + inertiaShiftY + dy
            }
        }
        canvas.drawBitmapMesh(src, cols, rows, verts, 0, null, 0, paint)
    }

    private fun drawRayCastShadowsAndAo(
        canvas: Canvas,
        w: Float,
        h: Float,
        timeSec: Float
    ) {
        // Directional warm key light from top-left + cool ambient occlusion shadow on bottom-right ground
        val sunDrift = sin(timeSec * 0.45f) * (w * 0.03f)
        val keyLight = LinearGradient(
            w * 0.12f + sunDrift,
            0f,
            w * 0.88f,
            h,
            intArrayOf(
                Color.argb(36, 255, 240, 200),
                Color.argb(0, 255, 255, 255),
                Color.argb(58, 12, 18, 36)
            ),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        val lightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = keyLight }
        canvas.drawRect(0f, 0f, w, h, lightPaint)

        // Subtle grounded ambient occlusion band along lower floor contact region
        val groundAo = LinearGradient(
            0f,
            h * 0.78f,
            0f,
            h,
            intArrayOf(
                Color.argb(0, 0, 0, 0),
                Color.argb(54, 8, 10, 20)
            ),
            null,
            Shader.TileMode.CLAMP
        )
        val aoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = groundAo }
        canvas.drawRect(0f, h * 0.78f, w, h, aoPaint)
    }

    private fun drawVolumetricGodRaysAndParticles(
        canvas: Canvas,
        w: Float,
        h: Float,
        scene: AnimationScene,
        frameIndex: Int,
        timeSec: Float
    ) {
        val isDarkMood = scene.activeVfx.any {
            it == SceneVfxType.STORM.name || it == SceneVfxType.HEAVY_RAIN.name || it == SceneVfxType.SPOOKY_FOG.name
        }

        // Volumetric angled sunbeam shafts from upper-left canopy
        val rayColor = if (isDarkMood) Color.argb(24, 150, 205, 255) else Color.argb(34, 255, 232, 168)
        val rayFade = if (isDarkMood) Color.argb(0, 120, 170, 255) else Color.argb(0, 255, 220, 130)
        val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 5) {
            val sway = sin(timeSec * 0.6f + i * 1.3f) * (w * 0.025f)
            val topX = w * (0.04f + i * 0.16f) + sway
            val rayW = w * (0.055f + (i % 2) * 0.028f)
            val slant = w * 0.28f
            val path = Path().apply {
                moveTo(topX, 0f)
                lineTo(topX + rayW, 0f)
                lineTo(topX + rayW + slant, h * 0.92f)
                lineTo(topX + slant * 0.78f, h * 0.92f)
                close()
            }
            rayPaint.shader = LinearGradient(
                topX,
                0f,
                topX + slant,
                h * 0.92f,
                rayColor,
                rayFade,
                Shader.TileMode.CLAMP
            )
            canvas.drawPath(path, rayPaint)
        }

        // Floating volumetric dust motes / cinematic atmosphere particles
        val motePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val particleCount = 34
        for (i in 0 until particleCount) {
            val seed = (i * 7919 + 104729) % 10000
            val baseX = (seed % 1000) / 1000f
            val baseY = ((seed / 7) % 1000) / 1000f
            val speed = 0.015f + (i % 5) * 0.008f
            val px = ((baseX + timeSec * speed + sin(timeSec * 1.1f + i) * 0.018f) % 1f + 1f) % 1f * w
            val py = ((baseY - timeSec * speed * 0.65f + cos(timeSec * 0.9f + i * 2) * 0.015f) % 1f + 1f) % 1f * h
            val radius = (w * 0.0018f) * (1f + (i % 4) * 0.65f)
            val twinkle = (0.45f + 0.55f * sin(timeSec * 3.1f + i * 1.7f + frameIndex * 0.04f)).coerceIn(0.15f, 1f)
            motePaint.color = if (isDarkMood) {
                Color.argb((twinkle * 120).toInt(), 180, 225, 255)
            } else {
                Color.argb((twinkle * 145).toInt(), 255, 242, 195)
            }
            canvas.drawCircle(px, py, radius, motePaint)
        }
    }

    private fun drawCinematicBokehDof(
        canvas: Canvas,
        src: Bitmap,
        w: Float,
        h: Float
    ) {
        // Fast downscaled optical blur pass blended only along outer frame periphery (keeps center subject razor-sharp)
        val blurW = (w / 10f).toInt().coerceAtLeast(32)
        val blurH = (h / 10f).toInt().coerceAtLeast(32)
        val tiny = runCatching { Bitmap.createScaledBitmap(src, blurW, blurH, true) }.getOrNull()
        if (tiny != null) {
            val bokehLayer = Bitmap.createBitmap(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val bc = Canvas(bokehLayer)
            val matrix = Matrix().apply {
                setScale(w / blurW.toFloat(), h / blurH.toFloat())
            }
            bc.drawBitmap(tiny, matrix, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))

            // Punch clear center aperture using DST_OUT radial mask so subject stays sharp
            val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
                shader = RadialGradient(
                    w * 0.5f,
                    h * 0.48f,
                    maxOf(w, h) * 0.58f,
                    intArrayOf(Color.BLACK, Color.BLACK, Color.TRANSPARENT),
                    floatArrayOf(0f, 0.56f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            bc.drawRect(0f, 0f, w, h, maskPaint)
            canvas.drawBitmap(bokehLayer, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = 155 })
            bokehLayer.recycle()
            tiny.recycle()
        }

        // Subtle cinematic anamorphic lens vignette
        val vignette = RadialGradient(
            w * 0.5f,
            h * 0.5f,
            maxOf(w, h) * 0.72f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(82, 6, 8, 16)),
            floatArrayOf(0f, 0.68f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = vignette })
    }

    /**
     * Generates a 100% standalone offline HTML5 WebGL2 / Canvas2D Desktop Cinema Player (`player.html`)
     * bundled inside the `.animaster-pc` ZIP package so the user can open and render/play their
     * project on any Windows, macOS, or Linux desktop browser with zero internet required.
     */
    fun generateOfflineHtml5WebGl2Player(
        projectName: String,
        width: Int,
        height: Int,
        fps: Int,
        frameCount: Int,
        sceneNames: List<String>,
        settings: ExportSettings
    ): String {
        val safeTitle = projectName
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
        val sceneListJson = sceneNames.joinToString(",") {
            "\"${it.replace("\\", "\\\\").replace("\"", "\\\"")}\""
        }
        val targetFps = if (settings.pcProMotionBlur60Fps) 60 else fps.coerceIn(12, 60)
        return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<title>$safeTitle — Animaster PC Pro Cinema Player</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; }
  body { margin: 0; background: #0B0E17; color: #F1F5F9; display: flex; flex-direction: column; min-height: 100vh; }
  header { padding: 14px 20px; background: #131826; border-bottom: 1px solid #263047; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
  .badge { background: linear-gradient(135deg,#6366F1,#EC4899); padding: 4px 10px; border-radius: 999px; font-size: 12px; font-weight: 700; letter-spacing: .04em; }
  main { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 18px; gap: 14px; }
  #stageWrap { position: relative; width: min(94vw, 1120px); aspect-ratio: $width / $height; background: #000; border-radius: 14px; overflow: hidden; box-shadow: 0 22px 60px rgba(0,0,0,.65); border: 1px solid #2A3550; }
  canvas { width: 100%; height: 100%; display: block; }
  .controls { width: min(94vw, 1120px); background: #131826; border: 1px solid #263047; border-radius: 14px; padding: 14px 16px; display: flex; flex-direction: column; gap: 12px; }
  .row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
  button { background: #2563EB; color: #fff; border: 0; border-radius: 8px; padding: 8px 14px; font-weight: 600; cursor: pointer; }
  button.secondary { background: #1E293B; color: #E2E8F0; border: 1px solid #334155; }
  input[type=range] { flex: 1; min-width: 180px; accent-color: #6366F1; }
  label.chip { display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 999px; background: #1E293B; border: 1px solid #334155; font-size: 12px; cursor: pointer; }
  .meta { font-size: 12px; color: #94A3B8; }
</style>
</head>
<body>
<header>
  <div>
    <strong>$safeTitle</strong>
    <span class="meta"> &middot; ${width}x${height} &middot; ${targetFps} FPS Master &middot; $frameCount frames</span>
  </div>
  <span class="badge">PC PRO OFFLINE WEBGL2 CINEMA PLAYER</span>
</header>
<main>
  <div id="stageWrap">
    <canvas id="cinemaCanvas" width="$width" height="$height"></canvas>
  </div>
  <div class="controls">
    <div class="row">
      <button id="playBtn">Play</button>
      <button id="prevBtn" class="secondary">&laquo; Prev</button>
      <button id="nextBtn" class="secondary">Next &raquo;</button>
      <input id="scrub" type="range" min="0" max="${(frameCount - 1).coerceAtLeast(0)}" value="0" />
      <span id="frameInfo" class="meta">Frame 1 / $frameCount</span>
    </div>
    <div class="row">
      <label class="chip"><input id="fxWind" type="checkbox" ${if (settings.pcProClothWindPhysics) "checked" else ""} /> Cloth/Hair Wind Shader</label>
      <label class="chip"><input id="fxRays" type="checkbox" ${if (settings.pcProGodRaysAndParticles) "checked" else ""} /> Volumetric God-Rays</label>
      <label class="chip"><input id="fxBokeh" type="checkbox" ${if (settings.pcProBokehDofAndInertia) "checked" else ""} /> Bokeh DoF + Vignette</label>
      <label class="chip"><input id="fxBlur" type="checkbox" ${if (settings.pcProMotionBlur60Fps) "checked" else ""} /> 60FPS Motion Blur</label>
      <span id="glBadge" class="meta">Renderer: Detecting WebGL2...</span>
    </div>
    <div class="meta">Scenes bundled: <span id="sceneList"></span> &middot; Extract this .animaster-pc ZIP and open player.html offline in Chrome, Edge, Firefox, or Safari.</div>
  </div>
</main>
<script>
const FRAME_COUNT = ${frameCount.coerceAtLeast(1)};
const TARGET_FPS = $targetFps;
const SCENES = [$sceneListJson];
document.getElementById('sceneList').textContent = SCENES.join(' -> ');

const canvas = document.getElementById('cinemaCanvas');
const ctx = canvas.getContext('2d');
const glProbe = document.createElement('canvas').getContext('webgl2');
document.getElementById('glBadge').textContent = glProbe ? 'WebGL2 Hardware Ready (60FPS)' : 'Canvas2D Cinema Ready';

const frames = new Array(FRAME_COUNT);
let current = 0;
let playing = false;
let lastTick = 0;

function pad4(n) { return String(n).padStart(4, '0'); }
for (let i = 0; i < FRAME_COUNT; i++) {
  const img = new Image();
  img.src = 'frames/frame_' + pad4(i + 1) + '.png';
  img.onload = () => { if (i === current) drawFrame(current); };
  frames[i] = img;
}

function drawFrame(idx) {
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  const img = frames[idx];
  const prev = frames[Math.max(0, idx - 1)];
  const t = idx / TARGET_FPS;
  if (img && img.complete && img.naturalWidth > 0) {
    const windOn = document.getElementById('fxWind').checked;
    const dx = windOn ? Math.sin(t * 4.2) * 1.8 : 0;
    ctx.drawImage(img, dx, 0, w, h);
    if (document.getElementById('fxBlur').checked && prev && prev.complete && prev.naturalWidth > 0 && idx > 0) {
      ctx.save(); ctx.globalAlpha = 0.18; ctx.drawImage(prev, 0, 0, w, h); ctx.restore();
    }
  } else {
    ctx.fillStyle = '#0F172A'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#E2E8F0'; ctx.font = 'bold 28px system-ui';
    ctx.fillText('Loading frame ' + (idx + 1) + ' / ' + FRAME_COUNT + '...', 48, h / 2);
  }
  if (document.getElementById('fxRays').checked) {
    const grad = ctx.createLinearGradient(0, 0, w * 0.65, h * 0.85);
    grad.addColorStop(0, 'rgba(255,235,175,0.14)');
    grad.addColorStop(1, 'rgba(255,235,175,0)');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, w, h);
  }
  if (document.getElementById('fxBokeh').checked) {
    const rad = ctx.createRadialGradient(w * 0.5, h * 0.5, Math.min(w, h) * 0.34, w * 0.5, h * 0.5, Math.max(w, h) * 0.68);
    rad.addColorStop(0, 'rgba(0,0,0,0)');
    rad.addColorStop(1, 'rgba(5,8,18,0.42)');
    ctx.fillStyle = rad; ctx.fillRect(0, 0, w, h);
  }
  document.getElementById('scrub').value = idx;
  document.getElementById('frameInfo').textContent = 'Frame ' + (idx + 1) + ' / ' + FRAME_COUNT;
}

function loop(ts) {
  if (playing) {
    if (ts - lastTick >= 1000 / TARGET_FPS) {
      current = (current + 1) % FRAME_COUNT;
      drawFrame(current);
      lastTick = ts;
    }
    requestAnimationFrame(loop);
  }
}

document.getElementById('playBtn').onclick = () => {
  playing = !playing;
  document.getElementById('playBtn').textContent = playing ? 'Pause' : 'Play';
  if (playing) { lastTick = performance.now(); requestAnimationFrame(loop); }
};
document.getElementById('prevBtn').onclick = () => { current = (current - 1 + FRAME_COUNT) % FRAME_COUNT; drawFrame(current); };
document.getElementById('nextBtn').onclick = () => { current = (current + 1) % FRAME_COUNT; drawFrame(current); };
document.getElementById('scrub').oninput = (e) => { current = parseInt(e.target.value, 10) || 0; drawFrame(current); };
['fxWind','fxRays','fxBokeh','fxBlur'].forEach(id => document.getElementById(id).onchange = () => drawFrame(current));
drawFrame(0);
</script>
</body>
</html>
""".trimIndent()
    }
}
