package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Rectangle
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EditorTool
import com.example.ui.components.CanvasStage
import com.example.ui.components.InfiniteColorPicker
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioViewModel

/**
 * Module 7: Dedicated "Frame-by-Frame Cel Studio"
 * - Advancing to the next frame automatically hides the solid previous cel drawing
 *   and displays a semi-transparent Rose-Red (prev) & optional Cyan (next) Onion-Skin Watermark
 *   for effortless tracing.
 * - Playback & Export show ONLY clean frame-by-frame cel artwork (zero onion-skin watermark).
 */
@Composable
fun FrameByFrameCelStudioScreen(
    viewModel: StudioViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scene = uiState.activeScene
    val celLayer = uiState.selectedLayer
    var showColorDialog by remember { mutableStateOf(false) }
    var showRangeTools by remember { mutableStateOf(false) }
    var rangeStart by remember { mutableStateOf(0) }
    var rangeEnd by remember { mutableStateOf(7) }
    var showSaveFxDialog by remember { mutableStateOf(false) }
    var fxClipName by remember { mutableStateOf("Animated FX Loop") }
    val filmstripState = rememberLazyListState()

    BackHandler { viewModel.closeCelStudio() }

    LaunchedEffect(uiState.currentFrame) {
        if (uiState.currentFrame >= 0) {
            runCatching { filmstripState.animateScrollToItem((uiState.currentFrame - 2).coerceAtLeast(0)) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBg)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .testTag("cel_studio_screen")
    ) {
        // 1. Top Cel Studio Header Bar
        Surface(
            color = StudioSurface,
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(
                    onClick = { viewModel.closeCelStudio() },
                    modifier = Modifier.size(40.dp).testTag("cel_back_btn")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Studio", tint = StudioTextPrimary)
                }

                Column {
                    Text(
                        "Cel Studio",
                        color = StudioCoral,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        "Frame ${uiState.currentFrame + 1} / ${scene?.durationFrames ?: 96}",
                        color = StudioTextSecondary,
                        fontSize = 10.sp
                    )
                }

                Spacer(Modifier.width(4.dp))

                IconButton(
                    onClick = { viewModel.undo() },
                    enabled = uiState.canUndo,
                    modifier = Modifier.size(38.dp).testTag("cel_undo_btn")
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Undo,
                        contentDescription = "Undo",
                        tint = if (uiState.canUndo) StudioTextPrimary else StudioTextSecondary.copy(alpha = 0.35f)
                    )
                }
                IconButton(
                    onClick = { viewModel.redo() },
                    enabled = uiState.canRedo,
                    modifier = Modifier.size(38.dp).testTag("cel_redo_btn")
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Redo,
                        contentDescription = "Redo",
                        tint = if (uiState.canRedo) StudioTextPrimary else StudioTextSecondary.copy(alpha = 0.35f)
                    )
                }

                // Clean Playback Button (Zero Onion Watermark during playback!)
                Button(
                    onClick = { viewModel.togglePlayback() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isPlaying) StudioCoral else StudioEmerald
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(36.dp).testTag("cel_play_btn")
                ) {
                    Icon(
                        if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (uiState.isPlaying) "Pause" else "Play Clean Preview",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (uiState.isPlaying) "Stop" else "Play", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Onion-Skin Watermark Toggle (Prev Rose-Red)
                Surface(
                    color = if (uiState.onionSkinEnabled) Color(0xFFFB7185).copy(alpha = 0.22f) else Color(0xFF1A202E),
                    shape = RoundedCornerShape(9.dp),
                    border = BorderStroke(1.dp, if (uiState.onionSkinEnabled) Color(0xFFFB7185) else StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(9.dp))
                        .clickable { viewModel.toggleOnionSkin() }
                        .testTag("cel_onion_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = "Onion Watermark", tint = Color(0xFFFB7185), modifier = Modifier.size(14.dp))
                        Text(
                            if (uiState.onionSkinEnabled) "Onion ON" else "Onion OFF",
                            color = if (uiState.onionSkinEnabled) Color(0xFFFB7185) else StudioTextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Optional Next Frame Cyan Onion Watermark
                Surface(
                    color = if (uiState.celOnionNextEnabled) StudioCyan.copy(alpha = 0.22f) else Color(0xFF1A202E),
                    shape = RoundedCornerShape(9.dp),
                    border = BorderStroke(1.dp, if (uiState.celOnionNextEnabled) StudioCyan else StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(9.dp))
                        .clickable { viewModel.toggleCelOnionNext() }
                        .testTag("cel_onion_next_toggle")
                ) {
                    Text(
                        if (uiState.celOnionNextEnabled) "+Next Cyan" else "Next OFF",
                        color = if (uiState.celOnionNextEnabled) StudioCyan else StudioTextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                // Onion Opacity Slider
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.width(120.dp)
                ) {
                    Text("${(uiState.celOnionOpacity * 100).toInt()}%", color = StudioTextSecondary, fontSize = 10.sp)
                    Slider(
                        value = uiState.celOnionOpacity,
                        onValueChange = { viewModel.setCelOnionOpacity(it) },
                        valueRange = 0.08f..0.75f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFFFB7185), activeTrackColor = Color(0xFFFB7185)),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Duplicate Prev Cel / Clear Current Cel
                IconButton(
                    onClick = { viewModel.duplicatePreviousCelToCurrentFrame() },
                    modifier = Modifier.size(38.dp).testTag("cel_dup_prev_btn")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Previous Cel", tint = StudioAmber, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = { viewModel.clearCurrentCel() },
                    modifier = Modifier.size(38.dp).testTag("cel_clear_btn")
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Current Cel", tint = StudioCoral, modifier = Modifier.size(18.dp))
                }

                // Module 10: Universal Multi-Frame Range / Batch Color / Auto-Loop / Animated FX Bar toggle
                Surface(
                    color = if (showRangeTools) StudioViolet else Color(0xFF1A202E),
                    shape = RoundedCornerShape(9.dp),
                    border = BorderStroke(1.dp, if (showRangeTools) StudioViolet else StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(9.dp))
                        .clickable { showRangeTools = !showRangeTools }
                        .testTag("cel_range_tools_toggle")
                ) {
                    Text(
                        "Range / Loop / Color",
                        color = if (showRangeTools) Color.White else StudioAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // 2. Clean Drawing Tools + Infinite Color Swatch + Brush Size Strip
        Surface(
            color = Color(0xFF151924),
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val celTools = listOf(
                    Triple(EditorTool.BRUSH, "Brush", Icons.Default.Brush),
                    Triple(EditorTool.PENCIL, "Pencil", Icons.Default.Edit),
                    Triple(EditorTool.AIRBRUSH, "Soft", Icons.Default.AutoFixHigh),
                    Triple(EditorTool.ERASER, "Eraser", Icons.Default.DeleteOutline),
                    Triple(EditorTool.BUCKET, "Fill", Icons.Default.FormatColorFill),
                    Triple(EditorTool.LINE, "Line", Icons.Default.ShowChart),
                    Triple(EditorTool.RECTANGLE, "Rect", Icons.Default.Rectangle),
                    Triple(EditorTool.CIRCLE, "Circle", Icons.Default.RadioButtonUnchecked)
                )
                celTools.forEach { (tool, label, icon) ->
                    val active = uiState.activeTool == tool
                    Surface(
                        color = if (active) StudioCoral.copy(alpha = 0.22f) else StudioSurface,
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, if (active) StudioCoral else StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .clickable { viewModel.selectTool(tool) }
                            .testTag("cel_tool_${tool.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(icon, contentDescription = label, tint = if (active) StudioCoral else StudioTextSecondary, modifier = Modifier.size(14.dp))
                            Text(label, color = if (active) StudioCoral else StudioTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                // Infinite Color Swatch Picker Button
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(uiState.primaryColorArgb.toInt()))
                        .border(2.dp, Color.White, CircleShape)
                        .clickable { showColorDialog = true }
                        .testTag("cel_color_picker_btn")
                )

                Text("Size ${uiState.brushSize.toInt()}", color = StudioTextSecondary, fontSize = 10.sp)
                Slider(
                    value = uiState.brushSize.coerceIn(1f, 64f),
                    onValueChange = { viewModel.setBrushSize(it) },
                    valueRange = 1f..64f,
                    colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                    modifier = Modifier.width(104.dp)
                )
            }
        }

        // 3. Full-Focus Pure Cel Drawing Stage (0px Touch Accuracy + Auto-Hide Onion Watermark)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            CanvasStage(
                uiState = uiState,
                onCommitStroke = { viewModel.commitStroke(it) },
                onCommitShape = { viewModel.commitShape(it) },
                onPaintBucket = { x, y -> viewModel.applyPaintBucket(x, y) },
                onPickColor = { x, y -> viewModel.pickColorAt(x, y) },
                onAddText = { _, _, _, _, _ -> },
                onSelectText = {},
                onMoveText = { _, _, _, _ -> },
                onUpdateText = { _, _, _ -> },
                onDuplicateText = {},
                onDeleteText = {},
                onOpenTextStudio = {},
                onDirectTransform = { dx, dy, sc, rot, undo ->
                    viewModel.updateSelectedLayerDirectTransform(dx = dx, dy = dy, scaleFactor = sc, rotationDeltaDeg = rot, recordUndo = undo)
                },
                onDirectTransformXY = { dx, dy, sc, sx, sy, rot, undo ->
                    viewModel.updateSelectedLayerDirectTransform(dx, dy, sc, sx, sy, rot, undo)
                },
                onSelectLayer = { viewModel.selectLayer(it) },
                onSelectBone = { viewModel.selectBone(it) },
                onDragRigBone = { b, p, u -> viewModel.dragRigBoneTo(b, p, u) },
                onMovePuppetRoot = { x, y, u -> viewModel.movePuppetRoot(x, y, u) },
                onTogglePuppetFlip = {},
                onTogglePuppetAutoWalk = {},
                onTogglePuppetGhostMode = {},
                onCyclePuppetViewAngle = {},
                onCyclePuppetHandProp = {},
                onCyclePuppetEyePack = {},
                onCyclePuppetMouthPhoneme = {},
                onApplyPuppetPose = {},
                onOpenImportCharacter = {},
                isCelStudioMode = true,
                onAddMotionPathPoint = {},
                onUpdateViewport = { z, px, py -> viewModel.updateCanvasViewport(z, px, py) },
                onResetViewport = { viewModel.resetCanvasViewport() },
                modifier = Modifier.fillMaxSize()
            )

            uiState.statusBanner?.let { banner ->
                Surface(
                    color = StudioSurface.copy(alpha = 0.96f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCoral),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                ) {
                    Text(
                        text = banner,
                        color = StudioTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // Module 10: Universal Multi-Frame Selection, Batch Color/Hue, Auto-Loop Paste & Save FX Clip Bar
        if (showRangeTools) {
            Surface(
                color = Color(0xFF171C2A),
                border = BorderStroke(1.dp, StudioViolet.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth().testTag("cel_multi_frame_range_bar")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = StudioCyan.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable {
                            rangeStart = uiState.currentFrame
                            if (rangeEnd < rangeStart) rangeEnd = rangeStart
                        }.testTag("cel_set_range_start_btn")
                    ) {
                        Text("Set Start (F${rangeStart + 1})", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Surface(
                        color = StudioAmber.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable {
                            rangeEnd = uiState.currentFrame.coerceAtLeast(rangeStart)
                        }.testTag("cel_set_range_end_btn")
                    ) {
                        Text("Set End (F${rangeEnd + 1})", color = StudioAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Surface(
                        color = StudioViolet.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable {
                            viewModel.batchShiftColorInRange(rangeStart, rangeEnd, hueDeltaDeg = 35f)
                        }.testTag("cel_batch_hue_plus_btn")
                    ) {
                        Text("Batch Hue +35°", color = StudioTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Surface(
                        color = StudioCoral.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable {
                            viewModel.batchShiftColorInRange(rangeStart, rangeEnd, hueDeltaDeg = 0f, tintColorArgb = uiState.primaryColorArgb, tintAmount = 0.65f)
                        }.testTag("cel_batch_tint_btn")
                    ) {
                        Text("Batch Tint Color", color = StudioCoral, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Surface(
                        color = StudioEmerald.copy(alpha = 0.20f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable {
                            viewModel.copyFramesInRange(rangeStart, rangeEnd)
                        }.testTag("cel_copy_range_btn")
                    ) {
                        Text("Copy Range", color = StudioEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Surface(
                        color = StudioEmerald,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable {
                            viewModel.pasteAutoLoopFillRange(rangeStart, rangeEnd)
                        }.testTag("cel_paste_autoloop_btn")
                    ) {
                        Text(
                            if (uiState.copiedRangeFrames.isNotEmpty()) "Auto-Loop Fill (${uiState.copiedRangeFrames.size}f)" else "Auto-Loop Fill",
                            color = Color(0xFF080B12),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                    Surface(
                        color = StudioAmber,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { showSaveFxDialog = true }.testTag("cel_save_fx_clip_btn")
                    ) {
                        Text("Save FX Clip", color = Color(0xFF080B12), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                }
            }
        }

        // 4. Bottom Cel Filmstrip with Auto-Hide Next Cel Stepper
        Surface(
            color = StudioSurface,
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(
                    onClick = { viewModel.celStepFrame(-1) },
                    modifier = Modifier.size(40.dp).testTag("cel_prev_frame_btn")
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Cel", tint = StudioTextPrimary)
                }

                val totalFrames = (scene?.durationFrames ?: 96).coerceAtLeast(1)
                LazyRow(
                    state = filmstripState,
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(totalFrames) { frameIdx ->
                        val isCurrent = frameIdx == uiState.currentFrame
                        val content = celLayer?.frames?.get(frameIdx.toString())
                        val hasInk = content != null && (content.strokes.isNotEmpty() || content.shapes.isNotEmpty() || content.images.isNotEmpty())
                        Surface(
                            color = when {
                                isCurrent -> StudioCoral.copy(alpha = 0.25f)
                                hasInk -> StudioViolet.copy(alpha = 0.22f)
                                else -> Color(0xFF141822)
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(
                                width = if (isCurrent) 2.dp else 1.dp,
                                color = when {
                                    isCurrent -> StudioCoral
                                    hasInk -> StudioViolet
                                    else -> StudioBorder
                                }
                            ),
                            modifier = Modifier
                                .size(width = 44.dp, height = 44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.setCurrentFrame(frameIdx) }
                                .testTag("cel_frame_$frameIdx")
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    "F${frameIdx + 1}",
                                    color = if (isCurrent) StudioCoral else StudioTextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (hasInk) {
                                    Spacer(Modifier.height(2.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(if (isCurrent) StudioAmber else StudioCyan)
                                    )
                                }
                            }
                        }
                    }
                }

                // Prominent "+ Next Cel" button: advances to next frame (auto-hides solid prev cel & shows rose-red onion watermark!)
                Button(
                    onClick = { viewModel.celStepFrame(1) },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(42.dp).testTag("cel_next_frame_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Next Cel", modifier = Modifier.size(16.dp))
                    Text("Next Cel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }
    }

    if (showColorDialog) {
        AlertDialog(
            onDismissRequest = { showColorDialog = false },
            containerColor = StudioSurface,
            title = { Text("Cel Ink Color", color = StudioTextPrimary, style = MaterialTheme.typography.titleMedium) },
            text = {
                InfiniteColorPicker(
                    selectedColorArgb = uiState.primaryColorArgb,
                    onColorChanged = { viewModel.setPrimaryColor(it) },
                    label = "Infinite Cel Ink Color",
                    testTagPrefix = "cel_infinite_color"
                )
            },
            confirmButton = {
                Button(onClick = { showColorDialog = false }) { Text("Done") }
            }
        )
    }

    if (showSaveFxDialog) {
        AlertDialog(
            onDismissRequest = { showSaveFxDialog = false },
            containerColor = StudioSurface,
            title = { Text("Save Animated FX Clip (F${rangeStart + 1}–F${rangeEnd + 1})", color = StudioTextPrimary, style = MaterialTheme.typography.titleMedium) },
            text = {
                androidx.compose.material3.OutlinedTextField(
                    value = fxClipName,
                    onValueChange = { fxClipName = it },
                    label = { Text("FX Clip Name (e.g. Lamp Fire Loop)") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveCelRangeAsAnimatedFxClip(fxClipName, rangeStart, rangeEnd)
                    showSaveFxDialog = false
                }) { Text("Save FX Clip") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showSaveFxDialog = false }) { Text("Cancel") }
            }
        )
    }
}
