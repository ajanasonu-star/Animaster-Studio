package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClipAnimationPreset
import com.example.data.model.LayerType
import com.example.data.model.SkeletalRig
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.TrackSelectionKind
import java.util.Locale
import kotlin.math.roundToInt

private fun formatVnTimecode(frame: Int, fps: Int): String {
    val safeFps = fps.coerceAtLeast(1)
    val totalSec = frame / safeFps
    val mins = totalSec / 60
    val secs = totalSec % 60
    val remFrames = frame % safeFps
    return String.format(Locale.US, "%02d:%02d.%02d", mins, secs, remFrames)
}

private val TrackYellowHighlight = Color(0xFFFFD600)

/**
 * Master Upgrade Module 4:
 * Track Mode (Default Primary Multi-Track Timeline) + Prisma 3D High-Contrast Frame Highlight.
 * Official UI names: "Track Mode" and "Frame Mode".
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VnMultiTrackTimelineContent(
    uiState: StudioUiState,
    myCharacters: List<SkeletalRig>,
    onTogglePlay: () -> Unit,
    onStepFrame: (Int) -> Unit,
    onSelectFrame: (Int) -> Unit,
    onAddFrames: (Int) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onToggleOnionSkin: () -> Unit = {},
    onSwitchToFrameGrid: () -> Unit,
    onSelectTrackTarget: (TrackSelectionKind, String) -> Unit,
    onSplitAtPlayhead: () -> Unit,
    onDeleteTrack: () -> Unit,
    onCopyClip: () -> Unit,
    onPasteClip: () -> Unit,
    onTrimLayerBounds: (layerId: String, startFrame: Int, endFrame: Int) -> Unit,
    onMoveLayerClip: (layerId: String, newStartFrame: Int) -> Unit,
    onMoveLayerClip2D: (layerId: String, newStartFrame: Int, deltaVisualLanes: Int, liftToTop: Boolean) -> Unit = { id, ns, _, _ ->
        onMoveLayerClip(id, ns)
    },
    onMoveTrackOrder: (up: Boolean) -> Unit = {},
    onReplaceLayerCharacter: (layerId: String, replacementRig: SkeletalRig) -> Unit,
    onUpdateLayerAnimations: (layerId: String, ClipAnimationPreset, ClipAnimationPreset, ClipAnimationPreset, Int) -> Unit,
    onAddExtraTrack: (name: String, LayerType, durationFrames: Int, ClipAnimationPreset, ClipAnimationPreset, ClipAnimationPreset) -> Unit,
    onTrimAudioBounds: (trackId: String, startFrame: Int, endFrame: Int) -> Unit,
    onMoveAudioTrack: (trackId: String, newStartFrame: Int) -> Unit,
    onToggleAudioLoop: (trackId: String) -> Unit,
    onSetTimelineRange: (Int, Int) -> Unit,
    compactMode: Boolean = false
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val fps = project.fps.coerceAtLeast(1)
    val totalFrames = scene.durationFrames.coerceAtLeast(1)
    val frameWidthDp = 18.dp
    val density = LocalDensity.current
    val frameWidthPx = with(density) { frameWidthDp.toPx() }.coerceAtLeast(8f)
    val lanePitchPx = with(density) { 31.dp.toPx() }.coerceAtLeast(24f)

    val horizScroll = rememberScrollState()
    val vertScroll = rememberScrollState()

    var showReplaceDialog by remember { mutableStateOf(false) }
    var showAnimationDialog by remember { mutableStateOf(false) }
    var showExtraTrackDialog by remember { mutableStateOf(false) }
    var showTrimDialog by remember { mutableStateOf(false) }
    var programmaticScroll by remember { mutableStateOf(false) }

    // 2D Drag-and-Drop state for lifting clips across frames (X) AND tracks (Y)!
    var activeDragClipLabel by remember { mutableStateOf<String?>(null) }
    var activeDragTargetFrame by remember { mutableIntStateOf(0) }
    var activeDragTargetLaneIdx by remember { mutableIntStateOf(0) }
    var activeDragLiftToNewTop by remember { mutableStateOf(false) }

    // Keep active frame locked right under the fixed white center playhead line!
    LaunchedEffect(uiState.currentFrame, totalFrames) {
        val targetScroll = (uiState.currentFrame * frameWidthPx).roundToInt()
        if (kotlin.math.abs(horizScroll.value - targetScroll) > frameWidthPx * 0.6f) {
            programmaticScroll = true
            horizScroll.scrollTo(targetScroll)
            programmaticScroll = false
        }
    }

    // Immediate real-time canvas scrubbing on every horizontal scroll pixel delta!
    LaunchedEffect(horizScroll.value, totalFrames) {
        if (!programmaticScroll && !uiState.isPlaying) {
            val exactPlayheadFrame = (horizScroll.value / frameWidthPx).roundToInt().coerceIn(0, totalFrames - 1)
            if (exactPlayheadFrame != uiState.currentFrame) {
                onSelectFrame(exactPlayheadFrame)
            }
        }
    }

    val backgroundLayer = remember(scene.layers) {
        scene.layers.firstOrNull { it.type == LayerType.BACKGROUND.name }
    }
    val overlayLayers = remember(scene.layers) {
        scene.layers.filter { it.type != LayerType.BACKGROUND.name }.reversed()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurface)
            .testTag("vn_multitrack_timeline")
    ) {
        // 1. Track Mode Transport Bar: [Track Mode | Frame Mode] | MM:SS.ff | |< Play >| | Undo/Redo, Onion Skin, + Add Frames
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurfaceVariant)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // Official [Track Mode | Frame Mode] Pill Toggle
            Surface(
                color = Color(0xFF0B111E),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StudioBorder)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(2.dp)) {
                    Surface(
                        color = StudioCyan.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("timeline_mode_track_pill")
                    ) {
                        Text(
                            "Track Mode",
                            color = StudioCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Surface(
                        color = Color.Transparent,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onSwitchToFrameGrid() }
                            .testTag("vn_switch_frame_grid_btn")
                    ) {
                        Text(
                            "Frame Mode",
                            color = StudioTextSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // Timecode + Frame Indicator
            Surface(
                color = Color(0xFF0E1626),
                shape = RoundedCornerShape(7.dp),
                border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.6f))
            ) {
                Text(
                    text = "${formatVnTimecode(uiState.currentFrame, fps)} / ${formatVnTimecode(totalFrames, fps)}",
                    color = StudioCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
            Text(
                text = "F${uiState.currentFrame + 1}/$totalFrames",
                color = TrackYellowHighlight,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold
            )

            // Center Transport: |<  Play/Pause  >|
            IconButton(
                onClick = { onStepFrame(-1) },
                modifier = Modifier.size(30.dp).testTag("vn_prev_frame_btn")
            ) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous frame", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
            }
            Surface(
                color = if (uiState.isPlaying) StudioCoral else StudioCyan,
                shape = CircleShape,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .clickable { onTogglePlay() }
                    .testTag("vn_play_pause_btn")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (uiState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Play or Pause",
                        tint = Color(0xFF080B12),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            IconButton(
                onClick = { onStepFrame(1) },
                modifier = Modifier.size(30.dp).testTag("vn_next_frame_btn")
            ) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Next frame", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
            }

            // Undo / Redo + Stage Onion Skin + Separate "+ Add Frames"
            IconButton(
                onClick = onUndo,
                enabled = uiState.canUndo,
                modifier = Modifier.size(28.dp).testTag("vn_undo_btn")
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Undo,
                    contentDescription = "Undo",
                    tint = if (uiState.canUndo) StudioTextPrimary else StudioTextSecondary.copy(alpha = 0.35f),
                    modifier = Modifier.size(16.dp)
                )
            }
            IconButton(
                onClick = onRedo,
                enabled = uiState.canRedo,
                modifier = Modifier.size(28.dp).testTag("vn_redo_btn")
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Redo,
                    contentDescription = "Redo",
                    tint = if (uiState.canRedo) StudioTextPrimary else StudioTextSecondary.copy(alpha = 0.35f),
                    modifier = Modifier.size(16.dp)
                )
            }
            Surface(
                color = if (uiState.onionSkinEnabled) StudioViolet.copy(alpha = 0.28f) else StudioSurfaceElevated,
                shape = RoundedCornerShape(7.dp),
                border = BorderStroke(1.dp, if (uiState.onionSkinEnabled) StudioViolet else StudioBorder),
                modifier = Modifier
                    .clip(RoundedCornerShape(7.dp))
                    .clickable { onToggleOnionSkin() }
                    .testTag("track_onion_skin_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Icon(
                        Icons.Rounded.Layers,
                        contentDescription = "Stage Onion Skin",
                        tint = if (uiState.onionSkinEnabled) StudioViolet else StudioTextSecondary,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        "Onion",
                        color = if (uiState.onionSkinEnabled) StudioViolet else StudioTextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            // "+ Add Frames" strictly extends totalFrames & persistent background (NEVER adds a new track!)
            Surface(
                color = StudioSurfaceElevated,
                shape = RoundedCornerShape(7.dp),
                border = BorderStroke(1.dp, StudioEmerald.copy(alpha = 0.7f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(7.dp))
                    .clickable { onAddFrames(24) }
                    .testTag("vn_add_24f_btn")
            ) {
                Text(
                    "+ Add Frames (+24f)",
                    color = StudioEmerald,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }

        // Top Drop Zone when long-press dragging a clip vertically!
        if (activeDragClipLabel != null) {
            Surface(
                color = if (activeDragLiftToNewTop) StudioEmerald.copy(alpha = 0.32f) else StudioSurfaceElevated,
                border = BorderStroke(1.5.dp, if (activeDragLiftToNewTop) StudioEmerald else TrackYellowHighlight),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .testTag("track_2d_drop_top_zone")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (activeDragLiftToNewTop) {
                            "⬆ Release to Lift \"$activeDragClipLabel\" to Top Foreground Track!"
                        } else {
                            "+ Drag Up Here to Create Top Foreground Track"
                        },
                        color = if (activeDragLiftToNewTop) StudioEmerald else TrackYellowHighlight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "F${activeDragTargetFrame + 1} • Layer ${activeDragTargetLaneIdx + 1}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 2. Multi-Track Scrollable Timeline Canvas with Fixed Vertical White Center Playhead Line!
        val trackHeight = if (compactMode) 118.dp else 164.dp
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(trackHeight)
                .background(Color(0xFF0A0F1A))
        ) {
            val halfWidthDp = maxWidth / 2
            val timelineContentWidthDp = frameWidthDp * totalFrames

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .horizontalScroll(horizScroll)
            ) {
                Row(modifier = Modifier.fillMaxHeight()) {
                    // Left center-offset spacer so Frame 0 aligns cleanly at the center playhead line!
                    Spacer(modifier = Modifier.width(halfWidthDp))

                    Column(
                        modifier = Modifier
                            .width(timelineContentWidthDp)
                            .fillMaxHeight()
                    ) {
                        // A. Time Ruler + Prisma 3D Cyan/Amber Highlighted Range Strip
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(22.dp)
                                .background(Color(0xFF101726))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val rangeS = uiState.rangeStartFrame.coerceIn(0, totalFrames - 1)
                                val rangeE = uiState.rangeEndFrame.coerceIn(rangeS, totalFrames - 1)
                                // Prisma 3D High-Contrast Cyan Range Highlight Band
                                if (rangeE > rangeS) {
                                    val rx = rangeS * frameWidthPx
                                    val rw = (rangeE - rangeS + 1) * frameWidthPx
                                    drawRect(
                                        color = Color(0x4406B6D4),
                                        topLeft = Offset(rx, 0f),
                                        size = Size(rw, size.height)
                                    )
                                    drawLine(
                                        color = Color(0xFF06B6D4),
                                        start = Offset(rx, 0f),
                                        end = Offset(rx + rw, 0f),
                                        strokeWidth = 3f
                                    )
                                }
                                // Active Frame Prisma 3D Amber Highlight Cell
                                val curX = uiState.currentFrame * frameWidthPx
                                drawRect(
                                    color = Color(0x66FBBF24),
                                    topLeft = Offset(curX, 0f),
                                    size = Size(frameWidthPx, size.height)
                                )
                                // Frame ticks
                                for (f in 0 until totalFrames) {
                                    val x = f * frameWidthPx
                                    val isSecond = f % fps == 0
                                    val isHalf = f % (fps / 2).coerceAtLeast(1) == 0
                                    val tickH = when {
                                        isSecond -> size.height * 0.72f
                                        isHalf -> size.height * 0.45f
                                        else -> size.height * 0.25f
                                    }
                                    drawLine(
                                        color = if (isSecond) Color(0xCCFFFFFF) else Color(0x44FFFFFF),
                                        start = Offset(x, size.height - tickH),
                                        end = Offset(x, size.height),
                                        strokeWidth = if (isSecond) 2f else 1f
                                    )
                                }
                            }
                            // Second & Frame labels
                            Row(modifier = Modifier.fillMaxSize()) {
                                val step = (fps / 2).coerceAtLeast(6)
                                var f = 0
                                while (f < totalFrames) {
                                    val label = if (f % fps == 0) "${f / fps}s" else "F${f + 1}"
                                    val span = minOf(step, totalFrames - f)
                                    Box(
                                        modifier = Modifier
                                            .width(frameWidthDp * span)
                                            .fillMaxHeight()
                                            .padding(start = 3.dp, top = 2.dp)
                                    ) {
                                        Text(
                                            text = label,
                                            color = if (f % fps == 0) Color.White else StudioTextSecondary,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                    f += step
                                }
                            }
                        }

                        // B. Scrollable Multi-Lane Track Area (Characters/Overlays, Text, Audio Waveform, Bottom Continuous Background Filmstrip)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(vertScroll)
                                .padding(vertical = 3.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            // Overlay / Character / Drawing Lanes (Top = Frontmost Z-Order in SceneRenderer!)
                            overlayLayers.forEachIndexed { laneIdx, layer ->
                                val isSel = uiState.selectedTrackKind == TrackSelectionKind.LAYER && uiState.selectedLayerId == layer.id
                                val startF = layer.clipStartFrame.coerceIn(0, totalFrames - 1)
                                val endF = (if (layer.clipEndFrame >= startF) layer.clipEndFrame else (totalFrames - 1)).coerceIn(startF, totalFrames - 1)
                                val clipLenFrames = (endF - startF + 1).coerceAtLeast(1)
                                val clipSecs = clipLenFrames.toFloat() / fps.toFloat()
                                val barColor = when (layer.type) {
                                    LayerType.RIG.name, LayerType.CHARACTER.name -> StudioViolet
                                    LayerType.VIDEO.name -> StudioAmber
                                    else -> StudioCyan
                                }
                                val animTag = listOfNotNull(
                                    layer.clipInAnimation.takeIf { it != ClipAnimationPreset.NONE.name }?.let { "In:$it" },
                                    layer.clipOutAnimation.takeIf { it != ClipAnimationPreset.NONE.name }?.let { "Out:$it" },
                                    layer.clipLoopAnimation.takeIf { it != ClipAnimationPreset.NONE.name }?.let { "Loop:$it" }
                                ).joinToString("•")

                                VnDraggableClipLane(
                                    label = layer.name,
                                    durationBadge = String.format(Locale.US, "%.2fs / %df", clipSecs, clipLenFrames) +
                                        if (animTag.isNotEmpty()) " [$animTag]" else "",
                                    startFrame = startF,
                                    endFrame = endF,
                                    totalFrames = totalFrames,
                                    laneIndex = laneIdx,
                                    lanePitchPx = lanePitchPx,
                                    frameWidthDp = frameWidthDp,
                                    frameWidthPx = frameWidthPx,
                                    clipColor = barColor,
                                    isSelected = isSel,
                                    keyframeIndices = remember(layer) {
                                        val s = mutableSetOf<Int>()
                                        layer.keyframes.forEach { s += it.frame }
                                        layer.rig?.rootKeyframes?.forEach { s += it.frame }
                                        layer.rig?.poseKeyframes?.keys?.mapNotNullTo(s) { it.toIntOrNull() }
                                        layer.rig?.boneZOrderKeyframes?.keys?.mapNotNullTo(s) { it.toIntOrNull() }
                                        s
                                    },
                                    onSelect = { onSelectTrackTarget(TrackSelectionKind.LAYER, layer.id) },
                                    onTrimBounds = { ns, ne -> onTrimLayerBounds(layer.id, ns, ne) },
                                    onDrag2DProgress = { dragging, targetFrame, deltaLanes, liftTop ->
                                        if (dragging) {
                                            activeDragClipLabel = layer.name
                                            activeDragTargetFrame = targetFrame
                                            activeDragTargetLaneIdx = (laneIdx + deltaLanes).coerceAtLeast(0)
                                            activeDragLiftToNewTop = liftTop
                                        } else {
                                            activeDragClipLabel = null
                                            activeDragLiftToNewTop = false
                                        }
                                    },
                                    onLongPressMove2D = { ns, deltaLanes, liftTop ->
                                        activeDragClipLabel = null
                                        activeDragLiftToNewTop = false
                                        onMoveLayerClip2D(layer.id, ns, deltaLanes, liftTop)
                                    }
                                )
                            }

                            // Animated Text Lanes
                            scene.animatedTexts.forEach { textItem ->
                                val isSel = uiState.selectedTrackKind == TrackSelectionKind.TEXT && uiState.selectedTextId == textItem.id
                                val startF = textItem.startFrame.coerceIn(0, totalFrames - 1)
                                val endF = textItem.endFrame.coerceIn(startF, totalFrames - 1)
                                val clipLen = (endF - startF + 1).coerceAtLeast(1)
                                VnDraggableClipLane(
                                    label = "T: ${textItem.text.take(18)}",
                                    durationBadge = String.format(Locale.US, "%.2fs / %df", clipLen.toFloat() / fps, clipLen),
                                    startFrame = startF,
                                    endFrame = endF,
                                    totalFrames = totalFrames,
                                    laneIndex = overlayLayers.size,
                                    lanePitchPx = lanePitchPx,
                                    frameWidthDp = frameWidthDp,
                                    frameWidthPx = frameWidthPx,
                                    clipColor = StudioCoral,
                                    isSelected = isSel,
                                    keyframeIndices = emptySet(),
                                    onSelect = { onSelectTrackTarget(TrackSelectionKind.TEXT, textItem.id) },
                                    onTrimBounds = { _, _ -> },
                                    onDrag2DProgress = { _, _, _, _ -> },
                                    onLongPressMove2D = { _, _, _ -> }
                                )
                            }

                            // Live Yellow Audio Waveform Lanes
                            project.audioTracks.forEach { track ->
                                val isSel = uiState.selectedTrackKind == TrackSelectionKind.AUDIO && uiState.selectedAudioTrackId == track.id
                                val startF = track.startFrame.coerceIn(0, totalFrames - 1)
                                val naturalFrames = ((track.durationMs / 1000f) * fps).toInt().coerceAtLeast(3)
                                val endF = (if (track.endFrame > startF) track.endFrame - 1 else (startF + naturalFrames - 1))
                                    .coerceIn(startF, totalFrames - 1)
                                val clipLen = (endF - startF + 1).coerceAtLeast(1)
                                val loopLabel = if (track.loopClip) "LOOP" else "1-SHOT"
                                VnAudioWaveformLane(
                                    name = track.name,
                                    badge = String.format(Locale.US, "%.2fs / %df • %s", clipLen.toFloat() / fps, clipLen, loopLabel),
                                    startFrame = startF,
                                    endFrame = endF,
                                    waveformPeaks = track.waveformPeaks,
                                    frameWidthDp = frameWidthDp,
                                    frameWidthPx = frameWidthPx,
                                    isSelected = isSel,
                                    muted = track.muted,
                                    onSelect = { onSelectTrackTarget(TrackSelectionKind.AUDIO, track.id) },
                                    onTrimBounds = { ns, ne -> onTrimAudioBounds(track.id, ns, ne + 1) },
                                    onLongPressMoveStart = { ns -> onMoveAudioTrack(track.id, ns) }
                                )
                            }

                            // Bottom Continuous Main Scene / Background Filmstrip (0..totalFrames — NEVER disappears on Frame 2!)
                            val bgSelected = backgroundLayer != null &&
                                uiState.selectedTrackKind == TrackSelectionKind.LAYER &&
                                uiState.selectedLayerId == backgroundLayer.id
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF16273B))
                                    .border(
                                        width = if (bgSelected) 2.dp else 1.dp,
                                        color = if (bgSelected) StudioEmerald else StudioEmerald.copy(alpha = 0.45f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        backgroundLayer?.let { onSelectTrackTarget(TrackSelectionKind.LAYER, it.id) }
                                    }
                                    .testTag("vn_background_filmstrip_lane")
                            ) {
                                // Filmstrip sprocket perforations & frame thumbnail dividers across 0..totalFrames
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val cellStep = (fps / 2).coerceAtLeast(6)
                                    var f = 0
                                    while (f < totalFrames) {
                                        val x = f * frameWidthPx
                                        drawLine(
                                            color = Color(0x3310B981),
                                            start = Offset(x, 0f),
                                            end = Offset(x, size.height),
                                            strokeWidth = 1.5f
                                        )
                                        // Top & bottom film sprockets
                                        drawRect(
                                            color = Color(0x55A7F3D0),
                                            topLeft = Offset(x + 4f, 2f),
                                            size = Size(6f, 3f)
                                        )
                                        drawRect(
                                            color = Color(0x55A7F3D0),
                                            topLeft = Offset(x + 4f, size.height - 5f),
                                            size = Size(6f, 3f)
                                        )
                                        f += cellStep
                                    }
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "BG FILMSTRIP: ${backgroundLayer?.name ?: scene.name} (Continuous F1–F$totalFrames)",
                                        color = Color(0xFFA7F3D0),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = String.format(Locale.US, "%.2fs / %df", totalFrames.toFloat() / fps, totalFrames),
                                        color = StudioEmerald,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Right center-offset spacer so the last frame can scroll smoothly to the center playhead!
                    Spacer(modifier = Modifier.width(halfWidthDp))
                }
            }

            // Fixed Vertical White Center Playhead Line (|) with top glowing handle!
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxHeight()
                    .width(2.5.dp)
                    .background(Color.White)
                    .testTag("vn_center_playhead_line")
            )
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .size(width = 12.dp, height = 8.dp)
                    .clip(RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                    .background(Color.White)
            )
        }

        // 3. VN Contextual Clip Action Bar (Split, Trim, Copy/Paste, Replace, Animation, + Extra Track, Prisma Range, Delete)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurfaceElevated)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            VnActionChip(
                label = "Split",
                icon = Icons.Rounded.ContentCut,
                accent = StudioAmber,
                tag = "vn_action_split",
                onClick = onSplitAtPlayhead
            )
            VnActionChip(
                label = "Trim",
                icon = Icons.Rounded.Tune,
                accent = StudioCyan,
                tag = "vn_action_trim",
                onClick = { showTrimDialog = true }
            )
            VnActionChip(
                label = "Copy",
                icon = Icons.Rounded.ContentCopy,
                accent = StudioTextPrimary,
                tag = "vn_action_copy",
                onClick = onCopyClip
            )
            VnActionChip(
                label = "Paste",
                icon = Icons.Rounded.ContentPaste,
                accent = if (uiState.copiedLayerClip != null) StudioEmerald else StudioTextSecondary,
                tag = "vn_action_paste",
                onClick = onPasteClip
            )
            VnActionChip(
                label = "Replace",
                icon = Icons.Rounded.SwapHoriz,
                accent = StudioViolet,
                tag = "vn_action_replace",
                onClick = { showReplaceDialog = true }
            )
            VnActionChip(
                label = "Animation",
                icon = Icons.Rounded.AutoAwesome,
                accent = StudioCoral,
                tag = "vn_action_animation",
                onClick = { showAnimationDialog = true }
            )
            VnActionChip(
                label = "Track ▲",
                icon = Icons.Rounded.ArrowUpward,
                accent = StudioCyan,
                tag = "track_action_move_up",
                onClick = { onMoveTrackOrder(true) }
            )
            VnActionChip(
                label = "Track ▼",
                icon = Icons.Rounded.ArrowDownward,
                accent = StudioAmber,
                tag = "track_action_move_down",
                onClick = { onMoveTrackOrder(false) }
            )
            VnActionChip(
                label = "+ Add Track",
                icon = Icons.Rounded.Add,
                accent = StudioEmerald,
                tag = "vn_action_extra_track",
                onClick = { showExtraTrackDialog = true }
            )
            // Audio Loop quick toggle when an Audio track is selected
            if (uiState.selectedTrackKind == TrackSelectionKind.AUDIO) {
                val activeAudio = project.audioTracks.firstOrNull { it.id == uiState.selectedAudioTrackId }
                if (activeAudio != null) {
                    VnActionChip(
                        label = if (activeAudio.loopClip) "Loop: ON" else "One-Shot",
                        icon = Icons.Rounded.GraphicEq,
                        accent = if (activeAudio.loopClip) StudioAmber else StudioCyan,
                        tag = "vn_action_audio_loop",
                        onClick = { onToggleAudioLoop(activeAudio.id) }
                    )
                }
            }
            // Prisma 3D Range In/Out Markers
            Surface(
                color = StudioSurfaceVariant,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.5f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        onSetTimelineRange(uiState.currentFrame, (uiState.currentFrame + 12).coerceAtMost(totalFrames - 1))
                    }
                    .testTag("vn_action_prisma_range")
            ) {
                Text(
                    "Range [F${uiState.rangeStartFrame + 1}..F${uiState.rangeEndFrame + 1}]",
                    color = StudioCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
            VnActionChip(
                label = "Delete",
                icon = Icons.Rounded.Delete,
                accent = StudioRose,
                tag = "vn_action_delete",
                onClick = onDeleteTrack
            )
        }
    }

    // Dialog 1: Replace Character / Saved Rig on Split Clip
    if (showReplaceDialog) {
        val targetLayer = uiState.selectedLayer
        AlertDialog(
            onDismissRequest = { showReplaceDialog = false },
            containerColor = StudioSurfaceElevated,
            title = { Text("Replace Character on Clip", color = StudioTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "Swap \"${targetLayer?.name ?: "Selected Clip"}\" with any saved character or built-in preset from this split point onward:",
                        color = StudioTextSecondary,
                        fontSize = 12.sp
                    )
                    if (myCharacters.isNotEmpty()) {
                        Text("MY SAVED CHARACTERS", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        myCharacters.forEach { savedRig ->
                            OutlinedButton(
                                onClick = {
                                    if (targetLayer != null) {
                                        onReplaceLayerCharacter(targetLayer.id, savedRig)
                                    }
                                    showReplaceDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(savedRig.name, color = StudioTextPrimary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    Text("BUILT-IN CARTOON CHARACTERS", color = StudioAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    ProceduralSmartTools.characterPresets.take(8).forEach { preset ->
                        OutlinedButton(
                            onClick = {
                                if (targetLayer != null) {
                                    val rig = RigSolver.createRiggedCharacterFromSpec(preset, rootX = 640f, rootY = 420f)
                                    onReplaceLayerCharacter(targetLayer.id, rig)
                                }
                                showReplaceDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(preset.name, color = StudioAmber)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReplaceDialog = false }) { Text("Close") }
            }
        )
    }

    // Dialog 2: Clip Animation Presets (In / Out / Loop)
    if (showAnimationDialog) {
        val layer = uiState.selectedLayer
        if (layer != null) {
            var inAnim by remember(layer.id) {
                mutableStateOf(runCatching { ClipAnimationPreset.valueOf(layer.clipInAnimation) }.getOrDefault(ClipAnimationPreset.NONE))
            }
            var outAnim by remember(layer.id) {
                mutableStateOf(runCatching { ClipAnimationPreset.valueOf(layer.clipOutAnimation) }.getOrDefault(ClipAnimationPreset.NONE))
            }
            var loopAnim by remember(layer.id) {
                mutableStateOf(runCatching { ClipAnimationPreset.valueOf(layer.clipLoopAnimation) }.getOrDefault(ClipAnimationPreset.NONE))
            }
            var animFrames by remember(layer.id) { mutableIntStateOf(layer.clipAnimationFrames.coerceIn(2, 48)) }

            AlertDialog(
                onDismissRequest = { showAnimationDialog = false },
                containerColor = StudioSurfaceElevated,
                title = { Text("Clip Animation (${layer.name})", color = StudioTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("IN ANIMATION", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ClipAnimationPreset.entries.forEach { p ->
                                FilterChip(selected = inAnim == p, onClick = { inAnim = p }, label = { Text(p.label, fontSize = 10.sp) })
                            }
                        }
                        Text("OUT ANIMATION", color = StudioCoral, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ClipAnimationPreset.entries.forEach { p ->
                                FilterChip(selected = outAnim == p, onClick = { outAnim = p }, label = { Text(p.label, fontSize = 10.sp) })
                            }
                        }
                        Text("LOOP ANIMATION", color = StudioAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ClipAnimationPreset.entries.forEach { p ->
                                FilterChip(selected = loopAnim == p, onClick = { loopAnim = p }, label = { Text(p.label, fontSize = 10.sp) })
                            }
                        }
                        Text("In/Out Duration: ${animFrames} frames", color = StudioTextSecondary, fontSize = 11.sp)
                        Slider(
                            value = animFrames.toFloat(),
                            onValueChange = { animFrames = it.roundToInt() },
                            valueRange = 2f..36f,
                            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onUpdateLayerAnimations(layer.id, inAnim, outAnim, loopAnim, animFrames)
                            showAnimationDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioCyan)
                    ) { Text("Apply", color = Color(0xFF080B12), fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showAnimationDialog = false }) { Text("Cancel") }
                }
            )
        }
    }

    // Dialog 3: + Extra Track with Exact Frame Count Picker & In/Out/Loop Presets
    if (showExtraTrackDialog) {
        var trackName by remember { mutableStateOf("Extra Clip ${scene.layers.size + 1}") }
        var layerType by remember { mutableStateOf(LayerType.DRAWING) }
        var durFramesText by remember { mutableStateOf("24") }
        var inAnim by remember { mutableStateOf(ClipAnimationPreset.FADE) }
        var outAnim by remember { mutableStateOf(ClipAnimationPreset.NONE) }
        var loopAnim by remember { mutableStateOf(ClipAnimationPreset.NONE) }

        val parsedFrames = (durFramesText.toIntOrNull() ?: 24).coerceIn(1, 2000)

        AlertDialog(
            onDismissRequest = { showExtraTrackDialog = false },
            containerColor = StudioSurfaceElevated,
            title = { Text("+ Add Extra Track", color = StudioEmerald, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = trackName,
                        onValueChange = { trackName = it },
                        label = { Text("Track Name", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("TRACK TYPE", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(
                            LayerType.DRAWING to "Drawing / FX",
                            LayerType.CHARACTER to "Character",
                            LayerType.BACKGROUND to "Background"
                        ).forEach { (lt, lbl) ->
                            FilterChip(
                                selected = layerType == lt,
                                onClick = { layerType = lt },
                                label = { Text(lbl, fontSize = 10.sp) }
                            )
                        }
                    }

                    // Exact Frame Count Picker (+/- & numeric input!)
                    Text(
                        "EXACT FRAME COUNT (starts at F${uiState.currentFrame + 1} • ${String.format(Locale.US, "%.2fs", parsedFrames.toFloat() / fps)})",
                        color = StudioAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { durFramesText = (parsedFrames - 6).coerceAtLeast(1).toString() },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(38.dp)
                        ) { Text("-6", fontSize = 11.sp) }
                        OutlinedButton(
                            onClick = { durFramesText = (parsedFrames - 1).coerceAtLeast(1).toString() },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(38.dp)
                        ) { Text("-", fontWeight = FontWeight.Bold) }
                        OutlinedTextField(
                            value = durFramesText,
                            onValueChange = { durFramesText = it.filter { ch -> ch.isDigit() } },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("extra_track_frame_count_input")
                        )
                        OutlinedButton(
                            onClick = { durFramesText = (parsedFrames + 1).coerceAtMost(2000).toString() },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(38.dp)
                        ) { Text("+", fontWeight = FontWeight.Bold) }
                        OutlinedButton(
                            onClick = { durFramesText = (parsedFrames + 12).coerceAtMost(2000).toString() },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(38.dp)
                        ) { Text("+12", fontSize = 11.sp) }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(12, 24, 48, 72, 120).forEach { quickF ->
                            FilterChip(
                                selected = parsedFrames == quickF,
                                onClick = { durFramesText = quickF.toString() },
                                label = { Text("${quickF}f", fontSize = 10.sp) }
                            )
                        }
                    }

                    HorizontalDivider(color = StudioBorder)
                    Text("IN / OUT / LOOP PRESETS", color = StudioViolet, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = {
                                val list = ClipAnimationPreset.entries
                                inAnim = list[(list.indexOf(inAnim) + 1) % list.size]
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("In: ${inAnim.label}", fontSize = 10.sp) }
                        OutlinedButton(
                            onClick = {
                                val list = ClipAnimationPreset.entries
                                outAnim = list[(list.indexOf(outAnim) + 1) % list.size]
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Out: ${outAnim.label}", fontSize = 10.sp) }
                        OutlinedButton(
                            onClick = {
                                val list = ClipAnimationPreset.entries
                                loopAnim = list[(list.indexOf(loopAnim) + 1) % list.size]
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Loop: ${loopAnim.label}", fontSize = 10.sp) }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddExtraTrack(trackName, layerType, parsedFrames, inAnim, outAnim, loopAnim)
                        showExtraTrackDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioEmerald)
                ) {
                    Text("Add Track (${parsedFrames}f)", color = Color(0xFF080B12), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExtraTrackDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Dialog 4: Numeric Trim Bounds (in addition to direct edge-handle dragging on timeline!)
    if (showTrimDialog) {
        val layer = uiState.selectedLayer
        if (layer != null) {
            val curStart = layer.clipStartFrame.coerceIn(0, totalFrames - 1)
            val curEnd = (if (layer.clipEndFrame >= curStart) layer.clipEndFrame else (totalFrames - 1)).coerceIn(curStart, totalFrames - 1)
            var sTxt by remember(layer.id) { mutableStateOf((curStart + 1).toString()) }
            var eTxt by remember(layer.id) { mutableStateOf((curEnd + 1).toString()) }
            AlertDialog(
                onDismissRequest = { showTrimDialog = false },
                containerColor = StudioSurfaceElevated,
                title = { Text("Trim Clip (${layer.name})", color = StudioCyan, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Tip: You can also drag the Left/Right white handles directly on the clip bar!", color = StudioTextSecondary, fontSize = 11.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = sTxt,
                                onValueChange = { sTxt = it.filter { c -> c.isDigit() } },
                                label = { Text("Start Frame") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = eTxt,
                                onValueChange = { eTxt = it.filter { c -> c.isDigit() } },
                                label = { Text("End Frame") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val ns = ((sTxt.toIntOrNull() ?: 1) - 1).coerceIn(0, totalFrames - 1)
                            val ne = ((eTxt.toIntOrNull() ?: totalFrames) - 1).coerceIn(ns, totalFrames - 1)
                            onTrimLayerBounds(layer.id, ns, ne)
                            showTrimDialog = false
                        }
                    ) { Text("Apply Trim") }
                },
                dismissButton = {
                    TextButton(onClick = { showTrimDialog = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun VnDraggableClipLane(
    label: String,
    durationBadge: String,
    startFrame: Int,
    endFrame: Int,
    totalFrames: Int,
    laneIndex: Int,
    lanePitchPx: Float,
    frameWidthDp: androidx.compose.ui.unit.Dp,
    frameWidthPx: Float,
    clipColor: Color,
    isSelected: Boolean,
    keyframeIndices: Set<Int>,
    onSelect: () -> Unit,
    onTrimBounds: (Int, Int) -> Unit,
    onDrag2DProgress: (dragging: Boolean, targetFrame: Int, deltaVisualLanes: Int, liftToTop: Boolean) -> Unit,
    onLongPressMove2D: (newStartFrame: Int, deltaVisualLanes: Int, liftToTop: Boolean) -> Unit
) {
    var dragAccumX by remember(startFrame, endFrame) { mutableFloatStateOf(0f) }
    var dragAccumY by remember(startFrame, endFrame, laneIndex) { mutableFloatStateOf(0f) }
    var isLongDragging by remember { mutableStateOf(false) }
    val clipLen = (endFrame - startFrame + 1).coerceAtLeast(1)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(Color(0xFF0E1422))
    ) {
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        (startFrame * frameWidthPx + if (isLongDragging) dragAccumX else 0f).roundToInt(),
                        if (isLongDragging) dragAccumY.roundToInt().coerceIn(-64, 64) else 0
                    )
                }
                .width(frameWidthDp * clipLen)
                .fillMaxHeight()
                .clip(RoundedCornerShape(7.dp))
                .background(clipColor.copy(alpha = if (isSelected) 0.48f else 0.25f))
                .border(
                    width = if (isSelected || isLongDragging) 2.5.dp else 1.dp,
                    color = if (isSelected || isLongDragging) TrackYellowHighlight else clipColor.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(7.dp)
                )
                .clickable { onSelect() }
                .pointerInput(startFrame, endFrame, totalFrames, laneIndex) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = {
                            onSelect()
                            isLongDragging = true
                            dragAccumX = 0f
                            dragAccumY = 0f
                            onDrag2DProgress(true, startFrame, 0, false)
                        },
                        onDragEnd = {
                            val deltaFrames = (dragAccumX / frameWidthPx).roundToInt()
                            val deltaLanes = (dragAccumY / lanePitchPx).roundToInt()
                            val liftTop = (laneIndex + deltaLanes) < 0 || dragAccumY < -(lanePitchPx * (laneIndex + 0.85f))
                            val targetFrame = (startFrame + deltaFrames).coerceIn(0, totalFrames - 1)
                            isLongDragging = false
                            dragAccumX = 0f
                            dragAccumY = 0f
                            onDrag2DProgress(false, targetFrame, 0, false)
                            if (deltaFrames != 0 || deltaLanes != 0 || liftTop) {
                                onLongPressMove2D(targetFrame, deltaLanes, liftTop)
                            }
                        },
                        onDragCancel = {
                            isLongDragging = false
                            dragAccumX = 0f
                            dragAccumY = 0f
                            onDrag2DProgress(false, startFrame, 0, false)
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            dragAccumX += dragAmount.x
                            dragAccumY += dragAmount.y
                            val targetFrame = (startFrame + (dragAccumX / frameWidthPx).roundToInt()).coerceIn(0, totalFrames - 1)
                            val deltaLanes = (dragAccumY / lanePitchPx).roundToInt()
                            val liftTop = (laneIndex + deltaLanes) < 0 || dragAccumY < -(lanePitchPx * (laneIndex + 0.85f))
                            onDrag2DProgress(true, targetFrame, deltaLanes, liftTop)
                        }
                    )
                }
        ) {
            // Crisp Diamond Keyframe Markers (◆) inside the clip bar!
            Canvas(modifier = Modifier.fillMaxSize()) {
                val r = 4.2f
                keyframeIndices.forEach { kf ->
                    if (kf in startFrame..endFrame) {
                        val kx = (kf - startFrame) * frameWidthPx + frameWidthPx * 0.5f
                        val ky = size.height - 6f
                        val diamond = Path().apply {
                            moveTo(kx, ky - r)
                            lineTo(kx + r, ky)
                            lineTo(kx, ky + r)
                            lineTo(kx - r, ky)
                            close()
                        }
                        drawPath(diamond, color = TrackYellowHighlight)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = if (isSelected) 12.dp else 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isLongDragging) "✥ $label" else label,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    text = durationBadge,
                    color = Color(0xFFE2E8F0),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }

            // Draggable Left & Right Trim Handles when selected!
            if (isSelected) {
                var leftDragAcc by remember(startFrame) { mutableFloatStateOf(0f) }
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .width(10.dp)
                        .fillMaxHeight()
                        .background(TrackYellowHighlight)
                        .pointerInput(startFrame, endFrame) {
                            detectHorizontalDragGestures(
                                onDragEnd = { leftDragAcc = 0f },
                                onHorizontalDrag = { change, dragAmount ->
                                    change.consume()
                                    leftDragAcc += dragAmount
                                    val df = (leftDragAcc / frameWidthPx).roundToInt()
                                    if (df != 0) {
                                        leftDragAcc -= df * frameWidthPx
                                        onTrimBounds((startFrame + df).coerceIn(0, endFrame), endFrame)
                                    }
                                }
                            )
                        }
                )
                var rightDragAcc by remember(endFrame) { mutableFloatStateOf(0f) }
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .width(10.dp)
                        .fillMaxHeight()
                        .background(TrackYellowHighlight)
                        .pointerInput(startFrame, endFrame) {
                            detectHorizontalDragGestures(
                                onDragEnd = { rightDragAcc = 0f },
                                onHorizontalDrag = { change, dragAmount ->
                                    change.consume()
                                    rightDragAcc += dragAmount
                                    val df = (rightDragAcc / frameWidthPx).roundToInt()
                                    if (df != 0) {
                                        rightDragAcc -= df * frameWidthPx
                                        onTrimBounds(startFrame, (endFrame + df).coerceIn(startFrame, totalFrames - 1))
                                    }
                                }
                            )
                        }
                )
            }
        }
    }
}

@Composable
private fun VnAudioWaveformLane(
    name: String,
    badge: String,
    startFrame: Int,
    endFrame: Int,
    waveformPeaks: List<Float>,
    frameWidthDp: androidx.compose.ui.unit.Dp,
    frameWidthPx: Float,
    isSelected: Boolean,
    muted: Boolean,
    onSelect: () -> Unit,
    onTrimBounds: (Int, Int) -> Unit,
    onLongPressMoveStart: (Int) -> Unit
) {
    val clipLen = (endFrame - startFrame + 1).coerceAtLeast(1)
    var dragAccumPx by remember(startFrame, endFrame) { mutableFloatStateOf(0f) }
    var isLongDragging by remember { mutableStateOf(false) }
    val yellowAccent = if (muted) Color(0xFF64748B) else Color(0xFFFACC15)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(Color(0xFF14120A))
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset((startFrame * frameWidthPx + if (isLongDragging) dragAccumPx else 0f).roundToInt(), 0) }
                .width(frameWidthDp * clipLen)
                .fillMaxHeight()
                .clip(RoundedCornerShape(7.dp))
                .background(yellowAccent.copy(alpha = if (isSelected) 0.34f else 0.22f))
                .border(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) Color.White else yellowAccent,
                    shape = RoundedCornerShape(7.dp)
                )
                .clickable { onSelect() }
                .pointerInput(startFrame, endFrame) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { onSelect(); isLongDragging = true; dragAccumPx = 0f },
                        onDragEnd = {
                            val df = (dragAccumPx / frameWidthPx).roundToInt()
                            isLongDragging = false; dragAccumPx = 0f
                            if (df != 0) onLongPressMoveStart((startFrame + df).coerceAtLeast(0))
                        },
                        onDragCancel = { isLongDragging = false; dragAccumPx = 0f },
                        onDrag = { change, amt -> change.consume(); dragAccumPx += amt.x }
                    )
                }
        ) {
            // Live Yellow Waveform Bars
            Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 4.dp)) {
                val peaks = waveformPeaks.ifEmpty { listOf(0.25f, 0.55f, 0.85f, 0.45f, 0.7f, 0.35f, 0.6f, 0.4f) }
                val barCount = (size.width / 5f).toInt().coerceIn(8, 120)
                val stepW = size.width / barCount
                for (i in 0 until barCount) {
                    val peak = peaks[(i * peaks.size) / barCount].coerceIn(0.12f, 1f)
                    val h = size.height * peak
                    val topY = (size.height - h) / 2f
                    drawLine(
                        color = yellowAccent.copy(alpha = 0.85f),
                        start = Offset(i * stepW + stepW * 0.5f, topY),
                        end = Offset(i * stepW + stepW * 0.5f, topY + h),
                        strokeWidth = 2.2f
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = if (isSelected) 12.dp else 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "♪ $name",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Text(
                    text = badge,
                    color = Color(0xFFFEF08A),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
            if (isSelected) {
                var rightDragAcc by remember(endFrame) { mutableFloatStateOf(0f) }
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .width(10.dp)
                        .fillMaxHeight()
                        .background(yellowAccent)
                        .pointerInput(startFrame, endFrame) {
                            detectHorizontalDragGestures(
                                onDragEnd = { rightDragAcc = 0f },
                                onHorizontalDrag = { change, amt ->
                                    change.consume()
                                    rightDragAcc += amt
                                    val df = (rightDragAcc / frameWidthPx).roundToInt()
                                    if (df != 0) {
                                        rightDragAcc -= df * frameWidthPx
                                        onTrimBounds(startFrame, (endFrame + df).coerceAtLeast(startFrame + 1))
                                    }
                                }
                            )
                        }
                )
            }
        }
    }
}

@Composable
private fun VnActionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        color = StudioSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f)),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(13.dp))
            Text(label, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}
