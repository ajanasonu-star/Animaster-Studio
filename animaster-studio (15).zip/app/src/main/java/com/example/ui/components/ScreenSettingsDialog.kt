package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.ScreenLockLandscape
import androidx.compose.material.icons.filled.ScreenLockPortrait
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DisplaySettings
import com.example.data.model.ScreenMode
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioMint
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScreenSettingsDialog(
    settings: DisplaySettings,
    showFitStageAction: Boolean,
    fastProxyPreviewMode: Boolean = false,
    onToggleFastProxyPreviewMode: () -> Unit = {},
    onSelectScreenMode: (ScreenMode) -> Unit,
    onSelectUiScale: (Float) -> Unit,
    onFitStageToScreen: () -> Unit,
    onDismiss: () -> Unit
) {
    val scalePresets = listOf(0.75f to "75%", 0.85f to "85%", 1.0f to "100%", 1.15f to "115%")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(1.dp, StudioBorder, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            color = PanelSurface
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(StudioCyan.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Screen and Display Settings",
                                tint = StudioCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "Screen & Display Settings",
                                style = MaterialTheme.typography.titleMedium,
                                color = StudioTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Auto-fit Mobile, Tablet & Desktop workspaces",
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_screen_settings_btn")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close Settings", tint = StudioTextSecondary)
                    }
                }

                HorizontalDivider(color = StudioBorder)

                // Section A: Screen Mode
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "SCREEN ORIENTATION MODE",
                        color = StudioCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    ScreenModeOptionRow(
                        icon = Icons.Default.ScreenRotation,
                        title = ScreenMode.AUTO_RESPONSIVE.label,
                        subtitle = "Automatically adapts Portrait phone, Landscape tablet & Desktop",
                        selected = settings.screenMode == ScreenMode.AUTO_RESPONSIVE,
                        tag = "screen_mode_auto",
                        onClick = { onSelectScreenMode(ScreenMode.AUTO_RESPONSIVE) }
                    )
                    ScreenModeOptionRow(
                        icon = Icons.Default.ScreenLockLandscape,
                        title = ScreenMode.LOCK_LANDSCAPE.label,
                        subtitle = "Widescreen studio view with side-by-side Canvas & Inspector",
                        selected = settings.screenMode == ScreenMode.LOCK_LANDSCAPE,
                        tag = "screen_mode_landscape",
                        onClick = { onSelectScreenMode(ScreenMode.LOCK_LANDSCAPE) }
                    )
                    ScreenModeOptionRow(
                        icon = Icons.Default.ScreenLockPortrait,
                        title = ScreenMode.LOCK_PORTRAIT.label,
                        subtitle = "One-handed vertical mobile layout with compact bottom controls",
                        selected = settings.screenMode == ScreenMode.LOCK_PORTRAIT,
                        tag = "screen_mode_portrait",
                        onClick = { onSelectScreenMode(ScreenMode.LOCK_PORTRAIT) }
                    )
                }

                HorizontalDivider(color = StudioBorder)

                // Section B: UI Scale
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "INTERFACE UI SCALE",
                            color = StudioViolet,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            "${(settings.uiScale * 100f).roundToInt()}%",
                            color = StudioTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        scalePresets.forEach { (value, label) ->
                            val isSelected = kotlin.math.abs(settings.uiScale - value) < 0.03f
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) StudioViolet else PanelElevated,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(
                                        1.dp,
                                        if (isSelected) StudioViolet else StudioBorder,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSelectUiScale(value) }
                                    .testTag("ui_scale_${label.replace("%", "")}")
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else StudioTextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }

                    Slider(
                        value = settings.uiScale,
                        onValueChange = { raw ->
                            val snapped = (raw * 20f).roundToInt() / 20f
                            onSelectUiScale(snapped.coerceIn(0.75f, 1.15f))
                        },
                        valueRange = 0.75f..1.15f,
                        steps = 7,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioViolet,
                            activeTrackColor = StudioViolet
                        ),
                        modifier = Modifier.testTag("ui_scale_slider")
                    )
                    Text(
                        "Use 75%–85% on compact phones to fit more timeline tracks, or 115% on large tablets.",
                        color = StudioTextSecondary,
                        fontSize = 11.sp
                    )
                }

                // Section C: Canvas Fit
                if (showFitStageAction) {
                    HorizontalDivider(color = StudioBorder)
                    OutlinedButton(
                        onClick = {
                            onFitStageToScreen()
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("auto_fit_stage_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.FitScreen, contentDescription = null, tint = StudioMint)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Auto-Fit Stage to Screen",
                            color = StudioMint,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Section C2: Module 11 Mobile RAM Protection — Fast Proxy Preview Mode
                HorizontalDivider(color = StudioBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(PanelElevated)
                        .border(1.dp, if (fastProxyPreviewMode) StudioCyan else StudioBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("fast_proxy_preview_row"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "Fast Proxy Preview Mode",
                        tint = if (fastProxyPreviewMode) StudioCyan else StudioTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Fast Proxy Preview (Low RAM Mode)",
                            color = StudioTextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Downscales live viewport bitmaps 50% for ultra-smooth phone editing. Final MP4/PNG/PC Pro exports always render at 100% HD!",
                            color = StudioTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = fastProxyPreviewMode,
                        onCheckedChange = { onToggleFastProxyPreviewMode() },
                        modifier = Modifier.testTag("fast_proxy_preview_switch")
                    )
                }

                // Section D: Commercial Use License
                HorizontalDivider(color = StudioBorder)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(StudioMint.copy(alpha = 0.08f))
                        .border(1.dp, StudioMint.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                        .testTag("commercial_license_card"),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Commercial Use License Verified",
                            tint = StudioMint,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "COMMERCIAL USE LICENSE • 100% ROYALTY-FREE",
                            color = StudioMint,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.7.sp
                        )
                    }
                    Text(
                        text = "Licensed for Commercial & Personal Use: You retain 100% full ownership and commercial rights to all animations, videos, characters, artwork, and audio exported from Animaster Studio — including monetized YouTube videos, Shorts, client work, broadcast, and social media — with zero royalties, zero forced watermarks, and no attribution required.",
                        color = StudioTextPrimary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "License: Animaster Studio Standard Commercial Creator License (Offline Perpetual Grant)",
                        color = StudioTextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("apply_screen_settings_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral)
                ) {
                    Icon(Icons.Default.AspectRatio, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ScreenModeOptionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    selected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) StudioCyan.copy(alpha = 0.14f) else PanelElevated)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) StudioCyan else StudioBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (selected) StudioCyan else StudioTextSecondary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = if (selected) Color.White else StudioTextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            Text(
                text = subtitle,
                color = StudioTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}
