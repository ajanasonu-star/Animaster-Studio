package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val StudioDarkColorScheme = darkColorScheme(
    primary = StudioCoral,
    onPrimary = Color(0xFF140702),
    primaryContainer = Color(0xFF471C0B),
    onPrimaryContainer = StudioCoralLight,
    secondary = StudioCyan,
    onSecondary = Color(0xFF041C1A),
    secondaryContainer = StudioCyanDim,
    onSecondaryContainer = Color(0xFFA7F3EB),
    tertiary = StudioViolet,
    onTertiary = Color(0xFF1B1038),
    tertiaryContainer = StudioVioletDim,
    onTertiaryContainer = Color(0xFFDDD6FE),
    background = StudioBg,
    onBackground = StudioTextPrimary,
    surface = StudioSurface,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioSurfaceVariant,
    onSurfaceVariant = StudioTextSecondary,
    surfaceContainerHighest = StudioSurfaceElevated,
    outline = StudioBorder,
    outlineVariant = StudioBorderSubtle,
    error = StudioRose,
    onError = Color(0xFF2C060D)
)

val AnimasterShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun AnimasterStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudioDarkColorScheme,
        typography = AnimasterTypography,
        shapes = AnimasterShapes,
        content = content
    )
}
