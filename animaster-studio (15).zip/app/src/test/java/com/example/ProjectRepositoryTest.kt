package com.example

import android.content.Context
import android.graphics.RectF
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AnimasterDatabase
import com.example.data.local.ProjectRepository
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.StoryboardTemplate
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProjectRepositoryTest {

    @Test
    fun saveAndLoadAllTemplates_roundTripSucceeds() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AnimasterDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ProjectRepository(db.projectDao(), db.localAssetDao())

        for (tpl in StoryboardTemplate.entries) {
            val proj = ProceduralSmartTools.createProjectFromTemplate("Proj_${tpl.name}", 1280, 720, 24, tpl)
            repo.saveProject(proj, isRecovery = false)
            val loaded = repo.loadProject(proj.id)
            assertNotNull("Failed to reload template $tpl", loaded)
            assertEquals(proj.name, loaded!!.name)
            assertEquals(proj.scenes.size, loaded.scenes.size)
            assertEquals(proj.scenes.first().layers.size, loaded.scenes.first().layers.size)
        }
        db.close()
    }

    @Test
    fun saveAndLoadRiggedCharactersLibrary_roundTripSucceeds() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AnimasterDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ProjectRepository(db.projectDao(), db.localAssetDao())

        val rig = RigSolver.createRiggedCharacterFromSpec(ProceduralSmartTools.characterPresets.first())
            .copy(name = "Custom Hero Rig", autoWalkWhenDragged = true)
        repo.saveRiggedCharacterToLibrary(rig)

        val savedList = repo.riggedCharactersFlow.first()
        assertEquals(1, savedList.size)
        assertEquals("Custom Hero Rig", savedList.first().name)
        assertEquals(rig.bones.size, savedList.first().bones.size)

        repo.deleteRiggedCharacterFromLibrary(rig.id)
        assertTrue(repo.riggedCharactersFlow.first().isEmpty())
        db.close()
    }

    @Test
    fun rigSolver_lbsMeshDeformationProducesFiniteVertices() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 400f)
        val rest = RigSolver.solveForwardKinematics(rig)
        val posed = RigSolver.solveForwardKinematics(rig, RigSolver.presetPoseAngles("WAVE"))
        val meshRect = RectF(370f, 220f, 630f, 580f)
        val verts = RigSolver.computeDeformedMeshVertices(rest, posed, meshRect, cols = 8, rows = 8)
        assertEquals((8 + 1) * (8 + 1) * 2, verts.size)
        assertTrue(verts.all { it.isFinite() })
    }
}
