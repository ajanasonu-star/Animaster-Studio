package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CanvasTextItem
import com.example.data.model.TextBoxStyle
import com.example.data.model.TextFontStyle
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.TextOutAnimation
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

private val TextPaletteColors = listOf(
    0xFFFFFFFFL,
    0xFFFFE066L,
    0xFFFF6B35L,
    0xFFFF3B5CL,
    0xFF2DD4BFL,
    0xFF38BDF8L,
    0xFFA78BFAL,
    0xFF34D399L,
    0xFF0F172AL,
    0xFF000000L
)

private val TextPresetCatalog = listOf(
    Triple("YOUTUBE_TITLE", "YouTube Pill", StudioCoral),
    Triple("HORROR_GLITCH", "Horror Shake", StudioRose),
    Triple("COMIC_POW", "Comic BOOM!", StudioAmber),
    Triple("GHOST_FLOAT", "Ghost Float", StudioCyan),
    Triple("SPEECH_BUBBLE", "Speech Bubble", StudioEmerald),
    Triple("CYBER_GLITCH", "Cyber Glitch", StudioViolet),
    Triple("TYPEWRITER_STORY", "Typewriter", StudioTextSecondary)
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TextStudioInspectorPanel(
    uiState: StudioUiState,
    onAddBlankText: () -> Unit,
    onAddPreset: (String) -> Unit,
    onSelectText: (String) -> Unit,
    onUpdateText: (String, Boolean, (CanvasTextItem) -> CanvasTextItem) -> Unit,
    onDuplicateText: (String) -> Unit,
    onDeleteText: (String) -> Unit,
    onSetStartNow: () -> Unit,
    onSetEndNow: () -> Unit
) {
    val scene = uiState.activeScene ?: return
    val texts = scene.animatedTexts
    val selected = uiState.selectedText ?: texts.lastOrNull()
    val maxFrame = (scene.durationFrames - 1).coerceAtLeast(1)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Header & Quick Presets
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Title, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(18.dp))
                    Text("Kinetic Text Studio", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                }
                Button(
                    onClick = onAddBlankText,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("text_studio_add_btn")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("New Text", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("1-Tap Viral Text Presets", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TextPresetCatalog.forEach { (key, label, accent) ->
                    Surface(
                        color = accent.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onAddPreset(key) }
                            .testTag("text_preset_${key.lowercase()}")
                    ) {
                        Text(
                            text = "+ $label",
                            style = MaterialTheme.typography.labelSmall,
                            color = accent,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // 2. Active Scene Text Items List
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Text Layers on Stage (${texts.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
            Spacer(Modifier.height(6.dp))
            if (texts.isEmpty()) {
                Text(
                    "Tap any preset above, tap '+ New Text', or use the Text tool on the canvas. Drag text with 1 finger on stage!",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextMuted
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    texts.forEach { item ->
                        val isSel = item.id == selected?.id
                        val endLabel = if (item.endFrame >= 9000) "End" else "F${item.endFrame + 1}"
                        Surface(
                            color = if (isSel) StudioCyan.copy(alpha = 0.15f) else StudioSurfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isSel) StudioCyan else StudioBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectText(item.id) }
                                .testTag("text_layer_row_${item.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.text.replace("\n", " "),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = StudioTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "F${item.startFrame + 1}–$endLabel • In: ${item.inAnimation} • Loop: ${item.loopAnimation}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSel) StudioCyan else StudioTextMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = { onDuplicateText(item.id) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = "Duplicate text", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { onDeleteText(item.id) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete text", tint = StudioRose, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Full Live Editor for Selected Text
        if (selected != null) {
            item(key = "edit_content_${selected.id}") {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Edit Selected Text", style = MaterialTheme.typography.titleSmall, color = StudioCyan)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = selected.text,
                    onValueChange = { newText ->
                        onUpdateText(selected.id, false) { it.copy(text = newText) }
                    },
                    label = { Text("Text Content (Enter for multi-line)") },
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("text_studio_content_input")
                )
            }

            // 4. Entrance, Loop & Exit Animations
            item(key = "edit_anims_${selected.id}") {
                Text("Entrance Animation (In)", style = MaterialTheme.typography.titleSmall, color = StudioCoral)
                Spacer(Modifier.height(5.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TextInAnimation.entries.forEach { anim ->
                        FilterChip(
                            selected = selected.inAnimation == anim.name,
                            onClick = { onUpdateText(selected.id, true) { it.copy(inAnimation = anim.name) } },
                            label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("text_in_${anim.name.lowercase()}")
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("In: ${selected.inDurationFrames}F", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(66.dp))
                    Slider(
                        value = selected.inDurationFrames.toFloat().coerceIn(2f, 48f),
                        onValueChange = { v -> onUpdateText(selected.id, false) { it.copy(inDurationFrames = v.toInt()) } },
                        valueRange = 2f..48f,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(6.dp))
                Text("Continuous Animation (Loop)", style = MaterialTheme.typography.titleSmall, color = StudioViolet)
                Spacer(Modifier.height(5.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TextLoopAnimation.entries.forEach { anim ->
                        FilterChip(
                            selected = selected.loopAnimation == anim.name,
                            onClick = { onUpdateText(selected.id, true) { it.copy(loopAnimation = anim.name) } },
                            label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("text_loop_${anim.name.lowercase()}")
                        )
                    }
                }
                if (selected.loopAnimation != TextLoopAnimation.NONE.name) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speed ${String.format("%.1fx", selected.loopSpeed)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(74.dp))
                        Slider(
                            value = selected.loopSpeed.coerceIn(0.3f, 2.8f),
                            onValueChange = { v -> onUpdateText(selected.id, false) { it.copy(loopSpeed = v) } },
                            valueRange = 0.3f..2.8f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Exit Animation (Out)", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                Spacer(Modifier.height(5.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TextOutAnimation.entries.forEach { anim ->
                        FilterChip(
                            selected = selected.outAnimation == anim.name,
                            onClick = { onUpdateText(selected.id, true) { it.copy(outAnimation = anim.name) } },
                            label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // 5. Timeline Timing Controls
            item(key = "edit_timing_${selected.id}") {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                val effectiveEnd = selected.endFrame.coerceIn(selected.startFrame, maxFrame)
                Text("Timeline Visibility (F${selected.startFrame + 1} – F${effectiveEnd + 1})", style = MaterialTheme.typography.titleSmall, color = StudioEmerald)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onSetStartNow,
                        modifier = Modifier.weight(1f).testTag("text_set_start_now_btn")
                    ) {
                        Text("Start = F${uiState.currentFrame + 1}", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = onSetEndNow,
                        modifier = Modifier.weight(1f).testTag("text_set_end_now_btn")
                    ) {
                        Text("End = F${uiState.currentFrame + 1}", style = MaterialTheme.typography.labelSmall)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("In F${selected.startFrame + 1}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(62.dp))
                    Slider(
                        value = selected.startFrame.toFloat().coerceIn(0f, maxFrame.toFloat()),
                        onValueChange = { v ->
                            val st = v.toInt()
                            onUpdateText(selected.id, false) { it.copy(startFrame = st, endFrame = it.endFrame.coerceAtLeast(st)) }
                        },
                        valueRange = 0f..maxFrame.toFloat(),
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Out F${effectiveEnd + 1}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(62.dp))
                    Slider(
                        value = effectiveEnd.toFloat(),
                        onValueChange = { v ->
                            val en = v.toInt()
                            onUpdateText(selected.id, false) { it.copy(startFrame = it.startFrame.coerceAtMost(en), endFrame = en) }
                        },
                        valueRange = 0f..maxFrame.toFloat(),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 6. Typography, Box Style, Transform & Colors
            item(key = "edit_style_${selected.id}") {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Font Style", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TextFontStyle.entries.forEach { fs ->
                        FilterChip(
                            selected = selected.fontStyle == fs.name,
                            onClick = { onUpdateText(selected.id, true) { it.copy(fontStyle = fs.name) } },
                            label = { Text(fs.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Box & Banner Style", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TextBoxStyle.entries.forEach { bs ->
                        FilterChip(
                            selected = selected.boxStyle == bs.name,
                            onClick = { onUpdateText(selected.id, true) { it.copy(boxStyle = bs.name) } },
                            label = { Text(bs.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                TextSliderRow("Size ${selected.fontSize.toInt()}", selected.fontSize, 20f..160f) { v ->
                    onUpdateText(selected.id, false) { it.copy(fontSize = v) }
                }
                TextSliderRow("Rotate ${selected.rotationDeg.toInt()}°", selected.rotationDeg, -45f..45f) { v ->
                    onUpdateText(selected.id, false) { it.copy(rotationDeg = v) }
                }
                TextSliderRow("Outline ${selected.strokeWidth.toInt()}", selected.strokeWidth, 0f..24f) { v ->
                    onUpdateText(selected.id, false) { it.copy(strokeWidth = v) }
                }
                TextSliderRow("Opacity ${(selected.opacity * 100).toInt()}%", selected.opacity, 0.1f..1f) { v ->
                    onUpdateText(selected.id, false) { it.copy(opacity = v) }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Shadow", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                        Spacer(Modifier.width(6.dp))
                        Switch(
                            checked = selected.shadowEnabled,
                            onCheckedChange = { c -> onUpdateText(selected.id, true) { it.copy(shadowEnabled = c) } }
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Neon Glow", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                        Spacer(Modifier.width(6.dp))
                        Switch(
                            checked = selected.glowEnabled,
                            onCheckedChange = { c -> onUpdateText(selected.id, true) { it.copy(glowEnabled = c) } }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Text Fill Color", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(Modifier.height(4.dp))
                TextColorSwatchRow(
                    selectedArgb = selected.colorArgb,
                    allowNone = false,
                    onPick = { c -> if (c != null) onUpdateText(selected.id, true) { it.copy(colorArgb = c) } }
                )

                Spacer(Modifier.height(6.dp))
                Text("2-Color Gradient End (Optional)", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(Modifier.height(4.dp))
                TextColorSwatchRow(
                    selectedArgb = selected.gradientEndArgb,
                    allowNone = true,
                    onPick = { c -> onUpdateText(selected.id, true) { it.copy(gradientEndArgb = c) } }
                )

                Spacer(Modifier.height(6.dp))
                Text("Outline Color", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(Modifier.height(4.dp))
                TextColorSwatchRow(
                    selectedArgb = selected.strokeColorArgb,
                    allowNone = false,
                    onPick = { c -> if (c != null) onUpdateText(selected.id, true) { it.copy(strokeColorArgb = c) } }
                )
            }
        }
    }
}

@Composable
private fun TextSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = StudioTextSecondary,
            modifier = Modifier.width(82.dp)
        )
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
            modifier = Modifier.weight(1f)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TextColorSwatchRow(
    selectedArgb: Long?,
    allowNone: Boolean,
    onPick: (Long?) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        if (allowNone) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(StudioSurfaceVariant)
                    .border(
                        width = if (selectedArgb == null) 2.5.dp else 1.dp,
                        color = if (selectedArgb == null) StudioCyan else StudioBorder,
                        shape = CircleShape
                    )
                    .clickable { onPick(null) }
            ) {
                Text("×", color = StudioTextSecondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }
        TextPaletteColors.forEach { argb ->
            val isSel = selectedArgb == argb
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(argb.toInt()))
                    .border(
                        width = if (isSel) 2.5.dp else 1.dp,
                        color = if (isSel) StudioCyan else StudioBorder,
                        shape = CircleShape
                    )
                    .clickable { onPick(argb) }
            )
        }
    }
}
