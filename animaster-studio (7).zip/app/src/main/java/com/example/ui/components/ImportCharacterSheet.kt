package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SkeletalRig
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioMint
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImportCharacterDialog(
    myCharacters: List<SkeletalRig>,
    onImportCharacter: (SkeletalRig) -> Unit,
    onEditInCharStudio: (SkeletalRig?) -> Unit,
    onDeleteMyCharacter: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val builtInRiggedPresets = remember {
        ProceduralSmartTools.characterPresets.map { spec ->
            RigSolver.createRiggedCharacterFromSpec(spec)
        } + listOf(
            RigSolver.createCartoonMascotRig().copy(name = "Chibi Mascot")
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .border(1.dp, StudioBorder, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            color = PanelSurface
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(StudioCoral.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AccessibilityNew,
                                contentDescription = "Import Character",
                                tint = StudioCoral,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                "Import Character to Scene",
                                style = MaterialTheme.typography.titleMedium,
                                color = StudioTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Each puppet gets its own Timeline track & live IK controls",
                                style = MaterialTheme.typography.bodySmall,
                                color = StudioTextSecondary
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_import_char_btn")) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                    }
                }

                // Launch Dedicated Character & Rig Studio
                Button(
                    onClick = {
                        onDismiss()
                        onEditInCharStudio(null)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_char_studio_from_import_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioViolet)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Create / Rig New Character in Studio", fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(color = StudioBorder)

                // My Saved Characters
                Text(
                    "MY CHARACTERS (${myCharacters.size})",
                    color = StudioCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                if (myCharacters.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(PanelElevated)
                            .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            "No saved custom characters yet. Tap \"Create / Rig New Character in Studio\" above to build or import PNG characters and save them here!",
                            color = StudioTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        myCharacters.forEach { rig ->
                            CharacterImportCard(
                                rig = rig,
                                accent = StudioCyan,
                                isCustom = true,
                                onImport = { onImportCharacter(rig) },
                                onEdit = {
                                    onDismiss()
                                    onEditInCharStudio(rig)
                                },
                                onDelete = { onDeleteMyCharacter(rig.id) }
                            )
                        }
                    }
                }

                HorizontalDivider(color = StudioBorder)

                // Built-in Rigged Cartoon Presets
                Text(
                    "BUILT-IN RIGGED CARTOON CAST",
                    color = StudioAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    builtInRiggedPresets.forEach { preset ->
                        CharacterPresetTile(
                            rig = preset,
                            onImport = { onImportCharacter(preset) },
                            onCustomize = {
                                onDismiss()
                                onEditInCharStudio(preset)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CharacterImportCard(
    rig: SkeletalRig,
    accent: Color,
    isCustom: Boolean,
    onImport: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val avatarColor = Color((rig.characterAppearance?.shirtColorArgb ?: 0xFF2DD4BFL).toInt())
    val rigBadge = when {
        !rig.singleMeshImagePath.isNullOrBlank() -> "2D PNG Mesh"
        rig.bones.any { !it.boundImagePath.isNullOrBlank() } -> "PNG Parts Rig"
        else -> "Cartoon Rig"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(PanelElevated)
            .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onImport)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("import_my_char_${rig.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(avatarColor.copy(alpha = 0.25f))
                .border(1.5.dp, avatarColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Face, contentDescription = null, tint = avatarColor, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                rig.name,
                color = StudioTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "$rigBadge • ${rig.bones.size} bones • ${rig.eyePack}",
                color = StudioTextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onEdit, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "Edit in Rig Studio", tint = StudioViolet, modifier = Modifier.size(18.dp))
        }
        if (isCustom) {
            IconButton(onClick = onDelete, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StudioRose, modifier = Modifier.size(18.dp))
            }
        }
        Surface(
            color = accent,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.clickable(onClick = onImport)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(2.dp))
                Text("Add", color = Color(0xFF080B12), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CharacterPresetTile(
    rig: SkeletalRig,
    onImport: () -> Unit,
    onCustomize: () -> Unit
) {
    val accent = Color((rig.characterAppearance?.shirtColorArgb ?: 0xFFFF6B35L).toInt())
    Column(
        modifier = Modifier
            .width(142.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(PanelElevated)
            .border(1.dp, StudioBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onImport)
            .padding(12.dp)
            .testTag("import_preset_${rig.name.lowercase()}"),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.25f))
                    .border(1.5.dp, accent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AccessibilityNew, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            }
            IconButton(onClick = onCustomize, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Customize ${rig.name}", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
            }
        }
        Text(
            rig.name,
            color = StudioTextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            "${rig.bones.size} IK bones",
            color = StudioTextSecondary,
            fontSize = 10.sp
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(StudioMint.copy(alpha = 0.16f))
                .padding(vertical = 5.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("+ Add to Scene", color = StudioMint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}
