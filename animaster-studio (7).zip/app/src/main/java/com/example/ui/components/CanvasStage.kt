package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterViewAngle
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.HandPropKind
import com.example.data.model.MouthPhoneme
import com.example.data.model.ShapeKind
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.engine.InterpolationEngine
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.CanvasBackdrop
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

private enum class SelectionHandleMode {
    NONE,
    TRANSLATE,
    RESIZE_CORNER,
    ROTATE
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CanvasStage(
    uiState: StudioUiState,
    onCommitStroke: (DrawStroke) -> Unit,
    onCommitShape: (VectorShape) -> Unit,
    onPaintBucket: (Float, Float) -> Unit,
    onPickColor: (Float, Float) -> Unit,
    onAddText: (String, Float, Float, TextInAnimation, TextLoopAnimation) -> Unit,
    onSelectText: (String?) -> Unit,
    onMoveText: (String, Float, Float, Boolean) -> Unit,
    onUpdateText: (String, Boolean, (CanvasTextItem) -> CanvasTextItem) -> Unit,
    onDuplicateText: (String) -> Unit,
    onDeleteText: (String) -> Unit,
    onOpenTextStudio: () -> Unit,
    onDirectTransform: (dx: Float, dy: Float, scaleFactor: Float, rotationDeltaDeg: Float, recordUndo: Boolean) -> Unit,
    onSelectLayer: (String) -> Unit,
    onSelectBone: (String?) -> Unit,
    onDragRigBone: (String, Vec2, Boolean) -> Unit,
    onMovePuppetRoot: (Float, Float, Boolean) -> Unit,
    onTogglePuppetFlip: () -> Unit,
    onTogglePuppetAutoWalk: () -> Unit,
    onTogglePuppetGhostMode: () -> Unit,
    onCyclePuppetViewAngle: () -> Unit,
    onCyclePuppetHandProp: (isRightHand: Boolean) -> Unit,
    onCyclePuppetEyePack: (EyePackStyle) -> Unit,
    onCyclePuppetMouthPhoneme: (MouthPhoneme) -> Unit,
    onApplyPuppetPose: (String) -> Unit,
    onOpenImportCharacter: () -> Unit,
    onAddMotionPathPoint: (Vec2) -> Unit,
    onUpdateViewport: (Float, Float, Float) -> Unit,
    onResetViewport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return

    var activeStroke by remember { mutableStateOf<DrawStroke?>(null) }
    var activeShape by remember { mutableStateOf<VectorShape?>(null) }
    var pendingTextPos by remember { mutableStateOf<Vec2?>(null) }
    var editingTextId by remember { mutableStateOf<String?>(null) }
    var textDraft by remember { mutableStateOf("") }
    var draftInAnim by remember { mutableStateOf(TextInAnimation.POP_BOUNCE) }
    var draftLoopAnim by remember { mutableStateOf(TextLoopAnimation.NONE) }

    val latestState by rememberUpdatedState(uiState)
    val latestCommitStroke by rememberUpdatedState(onCommitStroke)
    val latestCommitShape by rememberUpdatedState(onCommitShape)
    val latestPaintBucket by rememberUpdatedState(onPaintBucket)
    val latestPickColor by rememberUpdatedState(onPickColor)
    val latestSelectText by rememberUpdatedState(onSelectText)
    val latestMoveText by rememberUpdatedState(onMoveText)
    val latestDirectTransform by rememberUpdatedState(onDirectTransform)
    val latestSelectLayer by rememberUpdatedState(onSelectLayer)
    val latestSelectBone by rememberUpdatedState(onSelectBone)
    val latestDragBone by rememberUpdatedState(onDragRigBone)
    val latestMovePuppetRoot by rememberUpdatedState(onMovePuppetRoot)
    val latestAddMotionPath by rememberUpdatedState(onAddMotionPathPoint)
    val latestUpdateViewport by rememberUpdatedState(onUpdateViewport)

    val selectedRig = uiState.selectedLayer?.rig
    val selectedPuppetRoot = remember(selectedRig, uiState.currentFrame) {
        selectedRig?.let { InterpolationEngine.evaluatePuppetRoot(it, uiState.currentFrame) }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasBackdrop)
            .clipToBounds()
            .testTag("animation_canvas_stage")
    ) {
        val density = LocalDensity.current
        val viewW = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
        val viewH = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)
        val projW = project.width.toFloat()
        val projH = project.height.toFloat()

        val baseScale = min((viewW * 0.92f) / projW, (viewH * 0.92f) / projH)
        val totalScale = baseScale * uiState.canvasZoom
        val stageW = projW * totalScale
        val stageH = projH * totalScale
        val originX = (viewW - stageW) / 2f + uiState.canvasPanX
        val originY = (viewH - stageH) / 2f + uiState.canvasPanY

        val latestOriginX by rememberUpdatedState(originX)
        val latestOriginY by rememberUpdatedState(originY)
        val latestTotalScale by rememberUpdatedState(totalScale)

        fun toStageWorld(offset: Offset): Vec2 {
            val st = latestState
            val sc = st.activeScene
            val rawX = (offset.x - latestOriginX) / latestTotalScale
            val rawY = (offset.y - latestOriginY) / latestTotalScale
            if (sc == null) return Vec2(rawX, rawY)

            val cam = InterpolationEngine.evaluateCamera(sc, st.currentFrame)
            val cx = projW / 2f
            val cy = projH / 2f
            val dx = rawX - cx
            val dy = rawY - cy
            val rad = Math.toRadians((-cam.rotationDeg).toDouble())
            val rx = (dx * cos(rad) - dy * sin(rad)).toFloat() / cam.zoom.coerceAtLeast(0.1f)
            val ry = (dx * sin(rad) + dy * cos(rad)).toFloat() / cam.zoom.coerceAtLeast(0.1f)
            return Vec2(rx + cx + cam.panX, ry + cy + cam.panY)
        }

        fun toStageScreen(offset: Offset): Vec2 {
            val rawX = (offset.x - latestOriginX) / latestTotalScale
            val rawY = (offset.y - latestOriginY) / latestTotalScale
            return Vec2(rawX, rawY)
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val firstDown = awaitFirstDown(requireUnconsumed = false)
                        val startPos = firstDown.position
                        val startStage = toStageWorld(startPos)
                        val startScreen = toStageScreen(startPos)
                        val st0 = latestState
                        val tool = st0.activeTool

                        var isMultiTouch = false
                        var hasDragged = false
                        var lastPos = startPos
                        var lastStage = startStage

                        var draggingTextId: String? = null
                        var draggingTextOffsetX = 0f
                        var draggingTextOffsetY = 0f
                        var textUndoRecorded = false

                        var draggingBoneId: String? = null
                        var draggingPuppetRoot = false
                        var puppetUndoRecorded = false
                        var selectUndoRecorded = false
                        var handleMode = SelectionHandleMode.NONE
                        var boundsCenterX = projW / 2f
                        var boundsCenterY = projH / 2f

                        val activeSc = st0.activeScene

                        // 0. Hit-test Animated Text on stage in SELECT, TEXT, or RIG_EDIT modes
                        val canInteractWithText = tool == EditorTool.TEXT || tool == EditorTool.SELECT || tool == EditorTool.RIG_EDIT
                        if (canInteractWithText && activeSc != null && activeSc.animatedTexts.isNotEmpty()) {
                            val hitText = activeSc.animatedTexts.reversed().firstOrNull { item ->
                                st0.currentFrame in item.startFrame..item.endFrame &&
                                    SceneRenderer.computeTextBounds(item).contains(startScreen.x, startScreen.y)
                            }
                            if (hitText != null) {
                                draggingTextId = hitText.id
                                draggingTextOffsetX = hitText.x - startScreen.x
                                draggingTextOffsetY = hitText.y - startScreen.y
                                latestSelectText(hitText.id)
                            } else if (tool == EditorTool.SELECT && st0.selectedTextId != null) {
                                latestSelectText(null)
                            }
                        }

                        // Hit-test Rigged Puppet controls in RIG_EDIT or when selecting a puppet in SELECT
                        val canInteractWithPuppet = draggingTextId == null && (
                            (tool == EditorTool.RIG_EDIT) ||
                                (tool == EditorTool.SELECT && st0.selectedLayer?.rig != null)
                            )

                        if (canInteractWithPuppet && activeSc != null) {
                            // 1) Try selected rig layer first, otherwise search any visible puppet hit
                            val visibleRigs = activeSc.layers.reversed().filter { it.visible && it.rig != null }
                            val orderedRigs = buildList {
                                st0.selectedLayer?.takeIf { it.visible && it.rig != null }?.let { add(it) }
                                visibleRigs.forEach { if (it.id != st0.selectedLayer?.id) add(it) }
                            }

                            for (rigLayer in orderedRigs) {
                                val rig = rigLayer.rig ?: continue
                                val pRoot = InterpolationEngine.evaluatePuppetRoot(rig, st0.currentFrame)
                                val distRoot = hypot(startStage.x - pRoot.rootX, startStage.y - pRoot.rootY)
                                if (distRoot < 52f) {
                                    if (st0.selectedLayerId != rigLayer.id) latestSelectLayer(rigLayer.id)
                                    draggingPuppetRoot = true
                                    break
                                }
                                val angles = InterpolationEngine.evaluateRigAngles(rig, st0.currentFrame)
                                val effectiveFlipped = if (pRoot.viewAngle == CharacterViewAngle.SIDE_LEFT.name) {
                                    !pRoot.flippedHorizontal
                                } else {
                                    pRoot.flippedHorizontal
                                }
                                val solved = RigSolver.solveForwardKinematics(
                                    rig = rig,
                                    angleOverrides = angles,
                                    rootX = pRoot.rootX,
                                    rootY = pRoot.rootY,
                                    scale = pRoot.scale,
                                    flippedHorizontal = effectiveFlipped
                                )
                                val nearest = solved.minByOrNull { hypot(it.end.x - startStage.x, it.end.y - startStage.y) }
                                if (nearest != null && hypot(nearest.end.x - startStage.x, nearest.end.y - startStage.y) < 88f) {
                                    if (st0.selectedLayerId != rigLayer.id) latestSelectLayer(rigLayer.id)
                                    draggingBoneId = nearest.bone.id
                                    latestSelectBone(nearest.bone.id)
                                    latestDragBone(nearest.bone.id, startStage, true)
                                    break
                                }
                            }
                        }

                        // Prepare drawing / shape / selection-box handle mode if not dragging a text or puppet
                        if (draggingTextId == null && !draggingPuppetRoot && draggingBoneId == null) {
                            when (tool) {
                                EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                    activeStroke = DrawStroke(
                                        tool = tool.name,
                                        points = listOf(startStage),
                                        colorArgb = if (tool == EditorTool.ERASER) 0xFFFB7185L else st0.primaryColorArgb,
                                        gradientEndArgb = if (st0.useGradient && tool != EditorTool.ERASER) st0.gradientColorArgb else null,
                                        strokeWidth = st0.brushSize,
                                        opacity = st0.brushOpacity
                                    )
                                }
                                EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                    val kind = when (tool) {
                                        EditorTool.LINE -> ShapeKind.LINE
                                        EditorTool.RECTANGLE -> ShapeKind.RECTANGLE
                                        EditorTool.CIRCLE -> ShapeKind.CIRCLE
                                        else -> ShapeKind.POLYGON
                                    }
                                    activeShape = VectorShape(
                                        kind = kind.name,
                                        startX = startStage.x,
                                        startY = startStage.y,
                                        endX = startStage.x,
                                        endY = startStage.y,
                                        polygonSides = st0.polygonSides,
                                        strokeColorArgb = st0.primaryColorArgb,
                                        fillColorArgb = if (st0.fillShapes && kind != ShapeKind.LINE) st0.primaryColorArgb else null,
                                        gradientEndArgb = if (st0.useGradient) st0.gradientColorArgb else null,
                                        strokeWidth = st0.brushSize.coerceAtLeast(2f),
                                        opacity = st0.brushOpacity
                                    )
                                }
                                EditorTool.SELECT -> {
                                    val selLayer = st0.selectedLayer
                                    if (selLayer != null && selLayer.rig == null && activeSc != null) {
                                        val bounds = SceneRenderer.computeLayerBounds(selLayer, st0.currentFrame, activeSc.durationFrames, projW, projH)
                                        if (bounds != null) {
                                            boundsCenterX = bounds.centerX()
                                            boundsCenterY = bounds.centerY()
                                            val rotHandleX = bounds.centerX()
                                            val rotHandleY = bounds.top - 44f
                                            val corners = listOf(
                                                bounds.left to bounds.top,
                                                bounds.right to bounds.top,
                                                bounds.left to bounds.bottom,
                                                bounds.right to bounds.bottom
                                            )
                                            handleMode = when {
                                                hypot(startStage.x - rotHandleX, startStage.y - rotHandleY) < 42f -> SelectionHandleMode.ROTATE
                                                corners.any { (cx, cy) -> hypot(startStage.x - cx, startStage.y - cy) < 40f } -> SelectionHandleMode.RESIZE_CORNER
                                                else -> SelectionHandleMode.TRANSLATE
                                            }
                                        } else {
                                            handleMode = SelectionHandleMode.TRANSLATE
                                        }
                                    } else {
                                        handleMode = SelectionHandleMode.TRANSLATE
                                    }
                                }
                                else -> Unit
                            }
                        }

                        while (true) {
                            val event = awaitPointerEvent()
                            val activePointers = event.changes.filter { it.pressed }
                            if (activePointers.isEmpty()) break

                            // Seamless 2-finger pinch-to-zoom & pan
                            if (activePointers.size >= 2) {
                                if (!isMultiTouch) {
                                    isMultiTouch = true
                                    activeStroke = null
                                    activeShape = null
                                    draggingTextId = null
                                    draggingBoneId = null
                                    draggingPuppetRoot = false
                                    handleMode = SelectionHandleMode.NONE
                                }
                                val zoomChange = event.calculateZoom()
                                val panChange = event.calculatePan()
                                if (zoomChange != 1f || panChange != Offset.Zero) {
                                    val cur = latestState
                                    latestUpdateViewport(
                                        (cur.canvasZoom * zoomChange).coerceIn(0.4f, 4.5f),
                                        cur.canvasPanX + panChange.x,
                                        cur.canvasPanY + panChange.y
                                    )
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                                continue
                            }

                            if (isMultiTouch) continue

                            val change = activePointers.first()
                            val pos = change.position
                            val delta = pos - lastPos
                            if (hypot(pos.x - startPos.x, pos.y - startPos.y) > 4f) {
                                hasDragged = true
                            }
                            lastPos = pos
                            val pt = toStageWorld(pos)
                            val scrPt = toStageScreen(pos)

                            when {
                                draggingTextId != null -> {
                                    val firstMove = !textUndoRecorded
                                    textUndoRecorded = true
                                    latestMoveText(
                                        draggingTextId,
                                        (scrPt.x + draggingTextOffsetX).coerceIn(20f, projW - 20f),
                                        (scrPt.y + draggingTextOffsetY).coerceIn(20f, projH - 20f),
                                        firstMove
                                    )
                                    change.consume()
                                }
                                draggingPuppetRoot -> {
                                    val firstMove = !puppetUndoRecorded
                                    puppetUndoRecorded = true
                                    latestMovePuppetRoot(pt.x, pt.y, firstMove)
                                    change.consume()
                                }
                                draggingBoneId != null -> {
                                    latestDragBone(draggingBoneId, pt, false)
                                    change.consume()
                                }
                                tool in listOf(
                                    EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH,
                                    EditorTool.ERASER, EditorTool.PEN_BEZIER
                                ) -> {
                                    activeStroke = activeStroke?.let { s ->
                                        val prev = s.points.lastOrNull()
                                        if (prev == null || hypot(pt.x - prev.x, pt.y - prev.y) >= 2.5f) {
                                            s.copy(points = s.points + pt)
                                        } else s
                                    }
                                    change.consume()
                                }
                                tool in listOf(
                                    EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON
                                ) -> {
                                    activeShape = activeShape?.copy(endX = pt.x, endY = pt.y)
                                    change.consume()
                                }
                                tool == EditorTool.HAND_PAN -> {
                                    if (delta != Offset.Zero) {
                                        val cur = latestState
                                        latestUpdateViewport(
                                            cur.canvasZoom,
                                            cur.canvasPanX + delta.x,
                                            cur.canvasPanY + delta.y
                                        )
                                        change.consume()
                                    }
                                }
                                tool == EditorTool.SELECT -> {
                                    if (delta != Offset.Zero) {
                                        val firstMove = !selectUndoRecorded
                                        selectUndoRecorded = true
                                        when (handleMode) {
                                            SelectionHandleMode.ROTATE -> {
                                                val prevAng = Math.toDegrees(
                                                    atan2((lastStage.y - boundsCenterY).toDouble(), (lastStage.x - boundsCenterX).toDouble())
                                                ).toFloat()
                                                val curAng = Math.toDegrees(
                                                    atan2((pt.y - boundsCenterY).toDouble(), (pt.x - boundsCenterX).toDouble())
                                                ).toFloat()
                                                var dRot = curAng - prevAng
                                                if (dRot > 180f) dRot -= 360f
                                                if (dRot < -180f) dRot += 360f
                                                latestDirectTransform(0f, 0f, 1f, dRot, firstMove)
                                            }
                                            SelectionHandleMode.RESIZE_CORNER -> {
                                                val prevDist = hypot(lastStage.x - boundsCenterX, lastStage.y - boundsCenterY).coerceAtLeast(16f)
                                                val curDist = hypot(pt.x - boundsCenterX, pt.y - boundsCenterY).coerceAtLeast(16f)
                                                val factor = (curDist / prevDist).coerceIn(0.85f, 1.18f)
                                                latestDirectTransform(0f, 0f, factor, 0f, firstMove)
                                            }
                                            else -> {
                                                latestDirectTransform(
                                                    delta.x / latestTotalScale,
                                                    delta.y / latestTotalScale,
                                                    1f,
                                                    0f,
                                                    firstMove
                                                )
                                            }
                                        }
                                        change.consume()
                                    }
                                }
                            }
                            lastStage = pt
                        }

                        // Gesture ended: commit stroke/shape or trigger tap-based tools
                        if (!isMultiTouch && draggingTextId == null && !draggingPuppetRoot && draggingBoneId == null) {
                            when (tool) {
                                EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                    activeStroke?.let { if (it.points.isNotEmpty()) latestCommitStroke(it) }
                                }
                                EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                    activeShape?.let { shape ->
                                        val dist = hypot(shape.endX - shape.startX, shape.endY - shape.startY)
                                        val finalShape = if (dist < 6f) {
                                            shape.copy(endX = shape.startX + 120f, endY = shape.startY + 90f)
                                        } else shape
                                        latestCommitShape(finalShape)
                                    }
                                }
                                EditorTool.BUCKET -> if (!hasDragged) latestPaintBucket(startStage.x, startStage.y)
                                EditorTool.EYEDROPPER -> if (!hasDragged) latestPickColor(startStage.x, startStage.y)
                                EditorTool.TEXT -> if (!hasDragged) {
                                    textDraft = ""
                                    draftInAnim = TextInAnimation.POP_BOUNCE
                                    draftLoopAnim = TextLoopAnimation.NONE
                                    pendingTextPos = startScreen
                                }
                                EditorTool.MOTION_PATH -> latestAddMotionPath(startStage)
                                else -> Unit
                            }
                        }
                        activeStroke = null
                        activeShape = null
                    }
                }
        ) {
            drawIntoCanvas { composeCanvas ->
                val nc = composeCanvas.nativeCanvas
                nc.save()
                nc.translate(originX, originY)
                nc.scale(totalScale, totalScale)
                nc.clipRect(0f, 0f, projW, projH)

                SceneRenderer.renderScene(
                    canvas = nc,
                    scene = scene,
                    frame = uiState.currentFrame,
                    projectWidth = projW,
                    projectHeight = projH,
                    fps = project.fps,
                    audioTracks = project.audioTracks,
                    onionSkin = uiState.onionSkinEnabled && !uiState.isPlaying,
                    ghostFrames = uiState.ghostFramesEnabled && !uiState.isPlaying,
                    showRigBones = uiState.showRigOverlay && !uiState.isPlaying,
                    showMotionPaths = uiState.showMotionPaths && !uiState.isPlaying,
                    showSelectionBox = uiState.activeTool == EditorTool.SELECT && !uiState.isPlaying,
                    selectedLayerId = uiState.selectedLayer?.id,
                    selectedBoneId = uiState.selectedBoneId,
                    selectedTextId = if (!uiState.isPlaying) uiState.selectedTextId else null,
                    activePreviewStroke = activeStroke,
                    activePreviewShape = activeShape
                )
                nc.restore()
            }

            // Stage Frame Border
            drawRect(
                color = if (uiState.isPlaying) StudioCoral else if (uiState.activeTool == EditorTool.SELECT) StudioCyan else StudioBorder,
                topLeft = Offset(originX, originY),
                size = Size(stageW, stageH),
                style = Stroke(width = 2.5f)
            )
        }

        // Top-Left Stage HUD Badge + Top-Right Quick "Import Character" Button
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = StudioSurface.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudioBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = uiState.activeTool.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCoral,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• ${uiState.selectedLayer?.name ?: "No Layer"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextSecondary
                        )
                    }
                }

                // Prominent on-stage "+ Character" button for Multi-Character Importing
                if (!uiState.isPlaying) {
                    Surface(
                        color = StudioViolet.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenImportCharacter)
                            .testTag("stage_import_character_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.AccessibilityNew,
                                contentDescription = "Import Character",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                "+ Character",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Prominent on-stage "+ Text" button for Kinetic Animated Text
                    Surface(
                        color = StudioAmber.copy(alpha = 0.94f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenTextStudio)
                            .testTag("stage_add_text_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Title,
                                contentDescription = "Add Animated Text",
                                tint = Color(0xFF0F172A),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                "+ Text",
                                color = Color(0xFF0F172A),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Floating Animated Text Quick Action Bar whenever a Text Item is selected!
            val selText = uiState.selectedText
            if (selText != null && !uiState.isPlaying) {
                val inEntries = TextInAnimation.entries
                val curIn = runCatching { TextInAnimation.valueOf(selText.inAnimation) }.getOrDefault(TextInAnimation.POP_BOUNCE)
                val nextIn = inEntries[(inEntries.indexOf(curIn) + 1) % inEntries.size]

                val loopEntries = TextLoopAnimation.entries
                val curLoop = runCatching { TextLoopAnimation.valueOf(selText.loopAnimation) }.getOrDefault(TextLoopAnimation.NONE)
                val nextLoop = loopEntries[(loopEntries.indexOf(curLoop) + 1) % loopEntries.size]

                Surface(
                    color = StudioSurface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.65f))
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        PuppetQuickPill(
                            label = "Edit Text",
                            icon = Icons.Default.Edit,
                            active = true,
                            accent = StudioAmber,
                            tag = "text_bar_edit_btn",
                            onClick = {
                                textDraft = selText.text
                                editingTextId = selText.id
                            }
                        )
                        PuppetQuickPill(
                            label = "In: ${curIn.label}",
                            icon = Icons.Default.AutoAwesome,
                            active = curIn != TextInAnimation.NONE,
                            accent = StudioCoral,
                            tag = "text_bar_in_anim_btn",
                            onClick = { onUpdateText(selText.id, true) { it.copy(inAnimation = nextIn.name) } }
                        )
                        PuppetQuickPill(
                            label = "Loop: ${curLoop.label}",
                            icon = Icons.Default.AutoAwesome,
                            active = curLoop != TextLoopAnimation.NONE,
                            accent = StudioViolet,
                            tag = "text_bar_loop_anim_btn",
                            onClick = { onUpdateText(selText.id, true) { it.copy(loopAnimation = nextLoop.name) } }
                        )
                        PuppetQuickPill(
                            label = "Style",
                            icon = Icons.Default.Tune,
                            active = true,
                            accent = StudioCyan,
                            tag = "text_bar_style_btn",
                            onClick = onOpenTextStudio
                        )
                        PuppetQuickPill(
                            label = "Copy",
                            icon = Icons.Default.ContentCopy,
                            active = false,
                            accent = StudioEmerald,
                            tag = "text_bar_duplicate_btn",
                            onClick = { onDuplicateText(selText.id) }
                        )
                        PuppetQuickPill(
                            label = "Delete",
                            icon = Icons.Default.Delete,
                            active = false,
                            accent = StudioCoral,
                            tag = "text_bar_delete_btn",
                            onClick = { onDeleteText(selText.id) }
                        )
                    }
                }
            }

            // Toontastic / TweenCraft Floating Quick Action Bar whenever a Rigged Puppet is selected!
            if (selText == null && selectedRig != null && selectedPuppetRoot != null && !uiState.isPlaying) {
                val eyeEntries = EyePackStyle.entries
                val curEye = runCatching { EyePackStyle.valueOf(selectedPuppetRoot.eyePack) }.getOrDefault(EyePackStyle.AUTO_BLINK)
                val nextEye = eyeEntries[(eyeEntries.indexOf(curEye) + 1) % eyeEntries.size]

                val mouthEntries = MouthPhoneme.entries
                val curMouth = runCatching { MouthPhoneme.valueOf(selectedPuppetRoot.mouthPhoneme) }.getOrDefault(MouthPhoneme.AUTO_LIPSYNC)
                val nextMouth = mouthEntries[(mouthEntries.indexOf(curMouth) + 1) % mouthEntries.size]

                Surface(
                    color = StudioSurface.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioViolet.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        val curView = runCatching { CharacterViewAngle.valueOf(selectedPuppetRoot.viewAngle) }
                            .getOrDefault(CharacterViewAngle.FRONT)
                        val curRightProp = runCatching { HandPropKind.valueOf(selectedRig.rightHandProp) }
                            .getOrDefault(HandPropKind.NONE)
                        val rightPropLabel = if (!selectedRig.rightHandCustomImagePath.isNullOrBlank()) "PNG" else curRightProp.label

                        PuppetQuickPill(
                            label = "View: ${curView.label}",
                            icon = Icons.Default.AccessibilityNew,
                            active = curView != CharacterViewAngle.FRONT,
                            accent = StudioAmber,
                            tag = "puppet_cycle_view_btn",
                            onClick = onCyclePuppetViewAngle
                        )
                        PuppetQuickPill(
                            label = "Hand: $rightPropLabel",
                            icon = Icons.Default.AutoAwesome,
                            active = curRightProp != HandPropKind.NONE || !selectedRig.rightHandCustomImagePath.isNullOrBlank(),
                            accent = StudioCoral,
                            tag = "puppet_cycle_hand_prop_btn",
                            onClick = { onCyclePuppetHandProp(true) }
                        )
                        PuppetQuickPill(
                            label = if (selectedPuppetRoot.flippedHorizontal) "Flip L" else "Flip R",
                            icon = Icons.Default.Flip,
                            active = selectedPuppetRoot.flippedHorizontal,
                            accent = StudioCyan,
                            tag = "puppet_flip_h_btn",
                            onClick = onTogglePuppetFlip
                        )
                        val isGhostMode = (uiState.selectedLayer?.opacity ?: 1f) < 0.85f
                        PuppetQuickPill(
                            label = "Auto-Walk",
                            icon = Icons.AutoMirrored.Filled.DirectionsWalk,
                            active = selectedRig.autoWalkWhenDragged,
                            accent = StudioEmerald,
                            tag = "puppet_autowalk_btn",
                            onClick = onTogglePuppetAutoWalk
                        )
                        PuppetQuickPill(
                            label = if (isGhostMode) "Ghost 55%" else "Ghost",
                            icon = Icons.Default.Visibility,
                            active = isGhostMode,
                            accent = Color(0xFF7DD3FC),
                            tag = "puppet_ghost_mode_btn",
                            onClick = onTogglePuppetGhostMode
                        )
                        PuppetQuickPill(
                            label = "Eyes: ${curEye.label}",
                            icon = Icons.Default.Visibility,
                            active = true,
                            accent = StudioViolet,
                            tag = "puppet_cycle_eyes_btn",
                            onClick = { onCyclePuppetEyePack(nextEye) }
                        )
                        PuppetQuickPill(
                            label = "Mouth: ${curMouth.label}",
                            icon = Icons.Default.Face,
                            active = true,
                            accent = StudioCoral,
                            tag = "puppet_cycle_mouth_btn",
                            onClick = { onCyclePuppetMouthPhoneme(nextMouth) }
                        )
                        listOf("IDLE", "WAVE", "WALK", "JUMP", "SIT").forEach { pose ->
                            Surface(
                                color = Color(0xFF212838),
                                shape = RoundedCornerShape(7.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(7.dp))
                                    .clickable { onApplyPuppetPose(pose) }
                                    .testTag("puppet_pose_${pose.lowercase()}")
                            ) {
                                Text(
                                    text = pose,
                                    color = StudioAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom-Right Floating Zoom Controls
        Surface(
            color = StudioSurface.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom - 0.25f).coerceAtLeast(0.4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Rounded.Remove, contentDescription = "Zoom out", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "${(uiState.canvasZoom * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioCyan
                )
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom + 0.25f).coerceAtMost(4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Zoom in", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = onResetViewport,
                    modifier = Modifier.size(36.dp).testTag("canvas_fit_reset_btn")
                ) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Fit stage to screen", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }
    }

    // Upgraded Add Animated Text Dialog when tapping stage with TEXT tool
    pendingTextPos?.let { pos ->
        AlertDialog(
            onDismissRequest = { pendingTextPos = null },
            containerColor = StudioSurface,
            title = { Text("Add Animated Text", color = StudioTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = textDraft,
                        onValueChange = { textDraft = it },
                        label = { Text("Title, dialogue or sound FX") },
                        maxLines = 3
                    )
                    Text("Entrance Animation", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            TextInAnimation.POP_BOUNCE,
                            TextInAnimation.TYPEWRITER,
                            TextInAnimation.ZOOM_SLAM,
                            TextInAnimation.DROP_LETTERS,
                            TextInAnimation.SLIDE_UP,
                            TextInAnimation.SPIN_POP
                        ).forEach { anim ->
                            FilterChip(
                                selected = draftInAnim == anim,
                                onClick = { draftInAnim = anim },
                                label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Text("Loop Motion", style = MaterialTheme.typography.labelSmall, color = StudioViolet)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            TextLoopAnimation.NONE,
                            TextLoopAnimation.WAVE,
                            TextLoopAnimation.BOUNCE,
                            TextLoopAnimation.FLOAT,
                            TextLoopAnimation.SHAKE_HORROR,
                            TextLoopAnimation.GLITCH,
                            TextLoopAnimation.RAINBOW
                        ).forEach { anim ->
                            FilterChip(
                                selected = draftLoopAnim == anim,
                                onClick = { draftLoopAnim = anim },
                                label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = textDraft.isNotBlank(),
                    onClick = {
                        onAddText(textDraft, pos.x, pos.y, draftInAnim, draftLoopAnim)
                        pendingTextPos = null
                    }
                ) { Text("Place Animated Text") }
            },
            dismissButton = {
                TextButton(onClick = { pendingTextPos = null }) { Text("Cancel") }
            }
        )
    }

    // Quick Edit Existing Text Dialog
    editingTextId?.let { editId ->
        AlertDialog(
            onDismissRequest = { editingTextId = null },
            containerColor = StudioSurface,
            title = { Text("Edit Text Content", color = StudioTextPrimary) },
            text = {
                OutlinedTextField(
                    value = textDraft,
                    onValueChange = { textDraft = it },
                    label = { Text("Text (Enter for new line)") },
                    maxLines = 3
                )
            },
            confirmButton = {
                Button(
                    enabled = textDraft.isNotBlank(),
                    onClick = {
                        onUpdateText(editId, true) { it.copy(text = textDraft.trim()) }
                        editingTextId = null
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { editingTextId = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PuppetQuickPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) accent.copy(alpha = 0.2f) else Color(0xFF1A202E),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (active) accent else StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = label, tint = if (active) accent else StudioTextSecondary, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                text = label,
                color = if (active) accent else StudioTextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
