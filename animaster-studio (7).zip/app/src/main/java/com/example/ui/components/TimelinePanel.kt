package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CallSplit
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.FirstPage
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LastPage
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LayerType
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioBorderSubtle
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.TrackSelectionKind

/**
 * Unlimited Dynamic Virtualized Timeline supporting 1 to 2,000+ frames smoothly
 * using a column-sliced LazyRow locked in perfect horizontal alignment across all tracks.
 */
@Composable
fun TimelinePanel(
    uiState: StudioUiState,
    onTogglePlay: () -> Unit,
    onStepFrame: (Int) -> Unit,
    onSelectFrame: (Int) -> Unit,
    onAddFrames: (Int) -> Unit,
    onSelectLayer: (String) -> Unit,
    onSelectTrackTarget: (TrackSelectionKind, String) -> Unit,
    onToggleTrackTools: () -> Unit,
    onCutTrack: () -> Unit,
    onMidCutTrack: () -> Unit,
    onDuplicateTrack: () -> Unit,
    onDeleteTrack: () -> Unit,
    onRemixTrack: () -> Unit,
    onMoveTrackOrder: (Boolean) -> Unit,
    onToggleTrackVisibility: () -> Unit,
    onMoveLayerOrder: (String, Boolean) -> Unit,
    onToggleLayerVisibility: (String) -> Unit,
    onToggleTextVisibility: (String) -> Unit,
    onToggleAudioMute: (String) -> Unit,
    onSetFps: (Int) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleOnionSkin: () -> Unit,
    onToggleGhostFrames: () -> Unit,
    onAddBlankCel: () -> Unit,
    onDuplicateCel: () -> Unit,
    onInsertKeyframe: () -> Unit,
    compactMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val totalFrames = scene.durationFrames.coerceAtLeast(1)
    val lazyFrameState = rememberLazyListState()
    val verticalTrackScroll = rememberScrollState()

    var fpsMenuExpanded by remember { mutableStateOf(false) }
    var addFramesMenuExpanded by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var jumpInput by remember { mutableStateOf((uiState.currentFrame + 1).toString()) }
    var tracksExpanded by remember { mutableStateOf(true) }

    val activeTargetHidden = remember(
        uiState.selectedTrackKind,
        uiState.selectedLayer,
        uiState.selectedText,
        uiState.selectedAudioTrackId,
        project.audioTracks
    ) {
        when (uiState.selectedTrackKind) {
            TrackSelectionKind.LAYER -> uiState.selectedLayer?.visible == false
            TrackSelectionKind.TEXT -> uiState.selectedText?.visible == false
            TrackSelectionKind.AUDIO -> {
                val tr = project.audioTracks.firstOrNull { it.id == uiState.selectedAudioTrackId }
                    ?: project.audioTracks.firstOrNull()
                tr?.muted == true
            }
        }
    }

    val activeTargetLabel = remember(
        uiState.selectedTrackKind,
        uiState.selectedLayer,
        uiState.selectedText,
        uiState.selectedAudioTrackId,
        project.audioTracks
    ) {
        when (uiState.selectedTrackKind) {
            TrackSelectionKind.LAYER -> "Layer: ${uiState.selectedLayer?.name ?: "None"}"
            TrackSelectionKind.TEXT -> "Text: ${uiState.selectedText?.text?.take(12) ?: "None"}"
            TrackSelectionKind.AUDIO -> {
                val tr = project.audioTracks.firstOrNull { it.id == uiState.selectedAudioTrackId }
                    ?: project.audioTracks.firstOrNull()
                "Audio: ${tr?.name?.take(12) ?: "None"}"
            }
        }
    }

    // Keep playhead visible automatically when scrubbing, jumping, or playing across 1,000+ frames
    LaunchedEffect(uiState.currentFrame) {
        val visibleItems = lazyFrameState.layoutInfo.visibleItemsInfo
        if (visibleItems.isNotEmpty()) {
            val firstIdx = visibleItems.first().index
            val lastIdx = visibleItems.last().index
            if (uiState.currentFrame < firstIdx || uiState.currentFrame > lastIdx - 1) {
                lazyFrameState.scrollToItem((uiState.currentFrame - 3).coerceAtLeast(0))
            }
        }
    }

    val reversedLayers = remember(scene.layers) { scene.layers.reversed() }
    val layerKeyframesMap = remember(scene.layers) {
        scene.layers.associate { layer ->
            val tfSet = layer.keyframes.map { it.frame }.toSet()
            val rigPoseSet = layer.rig?.poseKeyframes?.keys?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            val rigRootSet = layer.rig?.rootKeyframes?.map { it.frame }?.toSet() ?: emptySet()
            layer.id to (tfSet + rigPoseSet + rigRootSet)
        }
    }
    val cameraKeySet = remember(scene.cameraKeyframes) { scene.cameraKeyframes.map { it.frame }.toSet() }

    val seconds = uiState.currentFrame.toFloat() / project.fps.coerceAtLeast(1).toFloat()
    val timecode = String.format("F%d/%d • %04.1fs", uiState.currentFrame + 1, totalFrames, seconds)

    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 1. Transport, Unlimited "+ Add Frames", Jump & Keyframe Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StudioSurfaceVariant)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // First Frame & -10 Jump
                IconButton(
                    onClick = { onSelectFrame(0) },
                    modifier = Modifier.size(34.dp).testTag("timeline_first_frame")
                ) {
                    Icon(Icons.Rounded.FirstPage, contentDescription = "First frame", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = { onStepFrame(-10) },
                    modifier = Modifier.size(34.dp).testTag("timeline_back_10")
                ) {
                    Icon(Icons.Rounded.FastRewind, contentDescription = "Back 10 frames", tint = StudioTextSecondary, modifier = Modifier.size(17.dp))
                }
                IconButton(
                    onClick = { onStepFrame(-1) },
                    modifier = Modifier.size(36.dp).testTag("timeline_prev_frame")
                ) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous frame", tint = StudioTextPrimary)
                }

                // Play / Pause
                Surface(
                    color = StudioCoral,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onTogglePlay)
                        .testTag("timeline_play_pause")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (uiState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (uiState.isPlaying) "Pause" else "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { onStepFrame(1) },
                    modifier = Modifier.size(36.dp).testTag("timeline_next_frame")
                ) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next frame", tint = StudioTextPrimary)
                }
                IconButton(
                    onClick = { onStepFrame(10) },
                    modifier = Modifier.size(34.dp).testTag("timeline_fwd_10")
                ) {
                    Icon(Icons.Rounded.FastForward, contentDescription = "Forward 10 frames", tint = StudioTextSecondary, modifier = Modifier.size(17.dp))
                }
                IconButton(
                    onClick = { onSelectFrame(totalFrames - 1) },
                    modifier = Modifier.size(34.dp).testTag("timeline_last_frame")
                ) {
                    Icon(Icons.Rounded.LastPage, contentDescription = "Last frame", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }

                // Interactive Timecode Pill -> Tap to Jump to Any Frame (1..2000)
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            jumpInput = (uiState.currentFrame + 1).toString()
                            showJumpDialog = true
                        }
                        .testTag("timeline_jump_frame_btn")
                ) {
                    Text(
                        text = timecode,
                        style = MaterialTheme.typography.labelMedium,
                        color = StudioTextPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                // "+ Add Frames" (+10, +50, +100) Dropdown for Unlimited Cartoon Length
                Box {
                    Surface(
                        color = StudioEmerald.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioEmerald),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { addFramesMenuExpanded = true }
                            .testTag("timeline_add_frames_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Add Frames", tint = StudioEmerald, modifier = Modifier.size(14.dp))
                            Text("Frames", style = MaterialTheme.typography.labelSmall, color = StudioEmerald, fontWeight = FontWeight.Bold)
                        }
                    }
                    DropdownMenu(
                        expanded = addFramesMenuExpanded,
                        onDismissRequest = { addFramesMenuExpanded = false }
                    ) {
                        listOf(10, 50, 100, 250).forEach { delta ->
                            DropdownMenuItem(
                                text = { Text("+$delta Frames (Total: ${(totalFrames + delta).coerceAtMost(2000)})") },
                                onClick = {
                                    addFramesMenuExpanded = false
                                    onAddFrames(delta)
                                }
                            )
                        }
                    }
                }

                TimelineToggleChip(
                    label = "Loop",
                    active = uiState.isLooping,
                    accent = StudioCyan,
                    onClick = onToggleLoop
                )

                // FPS Selector
                Box {
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clickable { fpsMenuExpanded = true }
                            .testTag("fps_selector")
                    ) {
                        Text(
                            text = "${project.fps} FPS",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioAmber,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = fpsMenuExpanded,
                        onDismissRequest = { fpsMenuExpanded = false }
                    ) {
                        listOf(12, 24, 30, 60).forEach { fps ->
                            DropdownMenuItem(
                                text = { Text("$fps FPS") },
                                onClick = {
                                    fpsMenuExpanded = false
                                    onSetFps(fps)
                                }
                            )
                        }
                    }
                }

                TimelineToggleChip(
                    label = "Onion",
                    active = uiState.onionSkinEnabled,
                    accent = StudioViolet,
                    onClick = onToggleOnionSkin
                )
                TimelineToggleChip(
                    label = "Ghost",
                    active = uiState.ghostFramesEnabled,
                    accent = StudioCyan,
                    onClick = onToggleGhostFrames
                )

                // Single-Button Collapsible Multi-Track Editing Tools Toggle
                Surface(
                    color = if (uiState.trackToolsExpanded) StudioCoral.copy(alpha = 0.24f) else StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (uiState.trackToolsExpanded) StudioCoral else StudioAmber),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onToggleTrackTools)
                        .testTag("timeline_track_tools_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Tune,
                            contentDescription = "Track Tools",
                            tint = if (uiState.trackToolsExpanded) StudioCoral else StudioAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (uiState.trackToolsExpanded) "Hide Tools" else "Track Tools",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (uiState.trackToolsExpanded) StudioCoral else StudioAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                TimelineActionPill(icon = Icons.Rounded.Add, label = "Cel", tint = StudioTextPrimary, onClick = onAddBlankCel)
                TimelineActionPill(icon = Icons.Rounded.ContentCopy, label = "Dup", tint = StudioTextPrimary, onClick = onDuplicateCel)
                TimelineActionPill(icon = Icons.Rounded.Diamond, label = "Key", tint = StudioViolet, onClick = onInsertKeyframe)

                if (!compactMode) {
                    IconButton(
                        onClick = { tracksExpanded = !tracksExpanded },
                        modifier = Modifier.size(34.dp).testTag("timeline_collapse_toggle")
                    ) {
                        Icon(
                            imageVector = if (tracksExpanded) Icons.Rounded.ExpandMore else Icons.Rounded.ExpandLess,
                            contentDescription = if (tracksExpanded) "Collapse tracks" else "Expand tracks",
                            tint = StudioTextSecondary
                        )
                    }
                }
            }

            // Collapsible 1-Row Multi-Track Tool Bar (Cut, Mid-Cut, Duplicate, Delete, Remix)
            // Hidden behind the single "Track Tools" button so the preview area stays maximally visible!
            AnimatedVisibility(visible = uiState.trackToolsExpanded) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StudioSurfaceElevated)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, StudioBorder)
                    ) {
                        Text(
                            text = activeTargetLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCyan,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        )
                    }
                    TimelineActionPill(
                        icon = Icons.Rounded.ArrowUpward,
                        label = "Up",
                        tint = StudioCyan,
                        onClick = { onMoveTrackOrder(true) },
                        tag = "track_tool_move_up"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ArrowDownward,
                        label = "Down",
                        tint = StudioAmber,
                        onClick = { onMoveTrackOrder(false) },
                        tag = "track_tool_move_down"
                    )
                    TimelineActionPill(
                        icon = if (activeTargetHidden) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                        label = if (activeTargetHidden) "Show" else "Hide",
                        tint = if (activeTargetHidden) StudioEmerald else StudioTextSecondary,
                        onClick = onToggleTrackVisibility,
                        tag = "track_tool_toggle_hide"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ContentCut,
                        label = "Cut",
                        tint = StudioAmber,
                        onClick = onCutTrack,
                        tag = "track_tool_cut"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.CallSplit,
                        label = "Mid-Cut",
                        tint = StudioCyan,
                        onClick = onMidCutTrack,
                        tag = "track_tool_midcut"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ContentCopy,
                        label = "Duplicate",
                        tint = StudioEmerald,
                        onClick = onDuplicateTrack,
                        tag = "track_tool_duplicate"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.AutoAwesome,
                        label = "Remix",
                        tint = StudioViolet,
                        onClick = onRemixTrack,
                        tag = "track_tool_remix"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.Delete,
                        label = "Delete",
                        tint = Color(0xFFF87171),
                        onClick = onDeleteTrack,
                        tag = "track_tool_delete"
                    )
                }
            }

            HorizontalDivider(color = StudioBorder)

            // Smooth Playhead Scrubber Bar across 1..2000 frames
            if (totalFrames > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                        .background(StudioSurface)
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("SCRUB", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                    Slider(
                        value = uiState.currentFrame.toFloat().coerceIn(0f, (totalFrames - 1).toFloat()),
                        onValueChange = { onSelectFrame(it.toInt()) },
                        valueRange = 0f..(totalFrames - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = StudioCoral,
                            activeTrackColor = StudioCoral,
                            inactiveTrackColor = StudioBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("timeline_scrubber")
                    )
                }
            }

            if (tracksExpanded && !compactMode) {
                // 2. Virtualized Multi-Track Dopesheet (1..2,000+ frames)
                val trackAreaHeight = if (uiState.trackToolsExpanded) 104.dp else 124.dp
                val totalTracksHeight = (24 + reversedLayers.size * 26 + scene.animatedTexts.size * 24 + 24 + project.audioTracks.size * 24).dp
                    .coerceAtLeast(trackAreaHeight)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(trackAreaHeight)
                        .background(StudioSurface)
                        .verticalScroll(verticalTrackScroll)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(totalTracksHeight)
                    ) {
                        // Left Track Labels Column (with quick Z-Order Up/Down & Hide/Show toggles)
                        Column(
                            modifier = Modifier
                                .width(152.dp)
                                .fillMaxHeight()
                                .background(StudioSurfaceVariant)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp)
                                    .background(StudioSurfaceVariant)
                                    .border(0.5.dp, StudioBorderSubtle)
                                    .padding(horizontal = 6.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text("TRACKS (${scene.layers.size}) • Z/EYE", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted, fontSize = 9.sp)
                            }
                            reversedLayers.forEach { layer ->
                                val isSelected = uiState.selectedTrackKind == TrackSelectionKind.LAYER && layer.id == uiState.selectedLayer?.id
                                val dotColor = when {
                                    !layer.visible -> StudioTextMuted.copy(alpha = 0.45f)
                                    isSelected -> StudioCoral
                                    layer.rig != null -> StudioViolet
                                    layer.type == LayerType.VIDEO.name -> StudioAmber
                                    else -> StudioCyan
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(26.dp)
                                        .background(
                                            when {
                                                !layer.visible -> StudioSurface.copy(alpha = 0.55f)
                                                isSelected -> StudioSurfaceElevated
                                                else -> StudioSurface
                                            }
                                        )
                                        .border(0.5.dp, if (isSelected) StudioCoral.copy(alpha = 0.7f) else StudioBorderSubtle)
                                        .clickable {
                                            onSelectLayer(layer.id)
                                            onSelectTrackTarget(TrackSelectionKind.LAYER, layer.id)
                                        }
                                        .padding(start = 6.dp, end = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(dotColor)
                                    )
                                    Text(
                                        text = layer.name,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 10.sp,
                                        color = when {
                                            !layer.visible -> StudioTextMuted
                                            isSelected -> StudioTextPrimary
                                            else -> StudioTextSecondary
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .clickable { onMoveLayerOrder(layer.id, true) }
                                            .testTag("timeline_layer_up_${layer.id}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move layer forward", tint = StudioCyan, modifier = Modifier.size(12.dp))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .clickable { onMoveLayerOrder(layer.id, false) }
                                            .testTag("timeline_layer_down_${layer.id}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move layer backward", tint = StudioAmber, modifier = Modifier.size(12.dp))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(19.dp)
                                            .clip(CircleShape)
                                            .clickable { onToggleLayerVisibility(layer.id) }
                                            .testTag("timeline_layer_eye_${layer.id}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (layer.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                            contentDescription = if (layer.visible) "Hide layer" else "Show layer",
                                            tint = if (layer.visible) StudioTextPrimary else StudioCoral,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                            // Separate Animated Text Track headers (tap to target + quick Hide/Show)
                            scene.animatedTexts.forEach { txt ->
                                val isSelectedText = uiState.selectedTrackKind == TrackSelectionKind.TEXT && uiState.selectedTextId == txt.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(24.dp)
                                        .background(if (isSelectedText) StudioSurfaceElevated else StudioSurface)
                                        .border(0.5.dp, if (isSelectedText) StudioCoral else StudioBorderSubtle)
                                        .clickable { onSelectTrackTarget(TrackSelectionKind.TEXT, txt.id) }
                                        .padding(start = 6.dp, end = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Rounded.Title, contentDescription = null, tint = if (txt.visible) StudioCyan else StudioTextMuted, modifier = Modifier.size(12.dp))
                                    Text(
                                        txt.text.ifBlank { "Text" },
                                        fontSize = 10.sp,
                                        color = when {
                                            !txt.visible -> StudioTextMuted
                                            isSelectedText -> StudioTextPrimary
                                            else -> StudioCyan
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(19.dp)
                                            .clip(CircleShape)
                                            .clickable { onToggleTextVisibility(txt.id) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (txt.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                            contentDescription = if (txt.visible) "Hide text" else "Show text",
                                            tint = if (txt.visible) StudioCyan else StudioCoral,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                            // Camera header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp)
                                    .background(StudioSurface)
                                    .border(0.5.dp, StudioBorderSubtle)
                                    .padding(horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(Icons.Rounded.Videocam, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(12.dp))
                                Text("Camera", fontSize = 10.sp, color = StudioAmber)
                            }
                            // Separate Audio Track headers (tap to target + quick Mute/Unmute)
                            project.audioTracks.forEach { audio ->
                                val isSelectedAudio = uiState.selectedTrackKind == TrackSelectionKind.AUDIO && uiState.selectedAudioTrackId == audio.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(24.dp)
                                        .background(if (isSelectedAudio) StudioSurfaceElevated else StudioSurface)
                                        .border(0.5.dp, if (isSelectedAudio) StudioCoral else StudioBorderSubtle)
                                        .clickable { onSelectTrackTarget(TrackSelectionKind.AUDIO, audio.id) }
                                        .padding(start = 6.dp, end = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = if (audio.muted) StudioTextMuted else StudioEmerald, modifier = Modifier.size(12.dp))
                                    Text(
                                        audio.name,
                                        fontSize = 10.sp,
                                        color = if (audio.muted) StudioTextMuted else if (isSelectedAudio) StudioTextPrimary else StudioEmerald,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(19.dp)
                                            .clip(CircleShape)
                                            .clickable { onToggleAudioMute(audio.id) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (audio.muted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                                            contentDescription = if (audio.muted) "Unmute audio" else "Mute audio",
                                            tint = if (audio.muted) StudioCoral else StudioEmerald,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Right Virtualized LazyRow of Frame Columns (supports 2,000+ frames effortlessly)
                        LazyRow(
                            state = lazyFrameState,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .testTag("timeline_virtualized_frames")
                        ) {
                            items(count = totalFrames, key = { it }) { f ->
                                val isCurrent = f == uiState.currentFrame
                                Column(
                                    modifier = Modifier
                                        .width(26.dp)
                                        .fillMaxHeight()
                                ) {
                                    // Ruler cell
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(24.dp)
                                            .background(if (isCurrent) StudioCoral else StudioSurface)
                                            .border(0.5.dp, StudioBorderSubtle)
                                            .clickable { onSelectFrame(f) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isCurrent || f % 5 == 0) "${f + 1}" else "·",
                                            fontSize = 9.sp,
                                            color = if (isCurrent) Color.Black else StudioTextMuted,
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1
                                        )
                                    }

                                    // Layer cells
                                    reversedLayers.forEach { layer ->
                                        val isSelectedLayer = layer.id == uiState.selectedLayer?.id
                                        val hasCel = layer.frames.containsKey(f.toString())
                                        val hasKf = layerKeyframesMap[layer.id]?.contains(f) == true
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(26.dp)
                                                .background(
                                                    when {
                                                        isCurrent -> StudioCoral.copy(alpha = 0.24f)
                                                        hasCel -> StudioCyan.copy(alpha = 0.14f)
                                                        isSelectedLayer -> StudioSurfaceElevated.copy(alpha = 0.55f)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(0.5.dp, StudioBorderSubtle)
                                                .clickable {
                                                    onSelectLayer(layer.id)
                                                    onSelectFrame(f)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (hasKf) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(7.dp)
                                                        .rotate(45f)
                                                        .background(if (layer.rig != null) StudioCyan else StudioViolet)
                                                )
                                            } else if (hasCel) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(StudioCyan)
                                                )
                                            }
                                        }
                                    }

                                    // Separate Animated Text track cells
                                    scene.animatedTexts.forEach { txt ->
                                        val insideText = f in txt.startFrame..txt.endFrame
                                        val isSelText = uiState.selectedTrackKind == TrackSelectionKind.TEXT && uiState.selectedTextId == txt.id
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(24.dp)
                                                .background(
                                                    when {
                                                        isCurrent -> StudioCoral.copy(alpha = 0.24f)
                                                        insideText && isSelText -> StudioCyan.copy(alpha = 0.36f)
                                                        insideText -> StudioCyan.copy(alpha = 0.18f)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(0.5.dp, StudioBorderSubtle)
                                                .clickable {
                                                    onSelectTrackTarget(TrackSelectionKind.TEXT, txt.id)
                                                    onSelectFrame(f)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (f == txt.startFrame || f == txt.endFrame) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(StudioCyan)
                                                )
                                            }
                                        }
                                    }

                                    // Camera cell
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(24.dp)
                                            .background(if (isCurrent) StudioCoral.copy(alpha = 0.18f) else Color.Transparent)
                                            .border(0.5.dp, StudioBorderSubtle)
                                            .clickable { onSelectFrame(f) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (cameraKeySet.contains(f)) {
                                            Box(
                                                modifier = Modifier
                                                    .size(7.dp)
                                                    .rotate(45f)
                                                    .background(StudioAmber)
                                            )
                                        }
                                    }

                                    // Audio cells
                                    project.audioTracks.forEach { track ->
                                        val clipFrames = (((track.trimEndMs - track.trimStartMs).coerceAtLeast(200L) / 1000f) * project.fps).toInt().coerceAtLeast(2)
                                        val inside = f >= track.startFrame && f < track.startFrame + clipFrames
                                        val peakIdx = if (inside && track.waveformPeaks.isNotEmpty()) {
                                            (((f - track.startFrame).toFloat() / clipFrames) * track.waveformPeaks.size).toInt()
                                                .coerceIn(0, track.waveformPeaks.lastIndex)
                                        } else -1
                                        val barH = if (peakIdx >= 0) (track.waveformPeaks[peakIdx] * 16f).coerceIn(3f, 16f) else 0f

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(24.dp)
                                                .background(
                                                    when {
                                                        isCurrent -> StudioCoral.copy(alpha = 0.2f)
                                                        inside -> StudioEmerald.copy(alpha = if (track.muted) 0.08f else 0.18f)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(0.5.dp, StudioBorderSubtle)
                                                .clickable {
                                                    onSelectTrackTarget(TrackSelectionKind.AUDIO, track.id)
                                                    onSelectFrame(f)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (inside) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(10.dp)
                                                        .height(barH.dp)
                                                        .clip(RoundedCornerShape(2.dp))
                                                        .background(if (track.muted) StudioTextMuted else StudioEmerald)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showJumpDialog) {
        AlertDialog(
            onDismissRequest = { showJumpDialog = false },
            containerColor = StudioSurface,
            title = { Text("Jump to Frame (1 – $totalFrames)", color = StudioTextPrimary) },
            text = {
                OutlinedTextField(
                    value = jumpInput,
                    onValueChange = { txt -> jumpInput = txt.filter { it.isDigit() } },
                    label = { Text("Frame number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                Button(onClick = {
                    val target = (jumpInput.toIntOrNull() ?: 1).coerceIn(1, totalFrames) - 1
                    onSelectFrame(target)
                    showJumpDialog = false
                }) { Text("Jump") }
            },
            dismissButton = {
                TextButton(onClick = { showJumpDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun TimelineToggleChip(
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) accent.copy(alpha = 0.2f) else StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (active) accent else StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) accent else StudioTextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun TimelineActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    tag: String? = null
) {
    Surface(
        color = StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.45f)),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .then(if (tag != null) Modifier.testTag(tag) else Modifier)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = tint, fontWeight = FontWeight.SemiBold)
        }
    }
}
