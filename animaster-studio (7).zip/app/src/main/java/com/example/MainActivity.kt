package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ScreenMode
import com.example.ui.components.ScreenSettingsDialog
import com.example.ui.screens.CharacterRigStudioScreen
import com.example.ui.screens.EditorWorkspaceScreen
import com.example.ui.screens.ProjectHubScreen
import com.example.ui.theme.AnimasterStudioTheme
import com.example.ui.viewmodel.StudioDestination
import com.example.ui.viewmodel.StudioViewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnimasterStudioTheme {
                AnimasterAppRoot()
            }
        }
    }
}

@Composable
private fun AnimasterAppRoot(
    viewModel: StudioViewModel = viewModel()
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val baseDensity = LocalDensity.current

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val recoverySnapshot by viewModel.recoverySnapshot.collectAsStateWithLifecycle()
    val localAssets by viewModel.localAssets.collectAsStateWithLifecycle()
    val myCharacters by viewModel.myCharacters.collectAsStateWithLifecycle()

    // Apply User's Screen & Display Orientation Preference live
    LaunchedEffect(uiState.displaySettings.screenMode) {
        activity?.requestedOrientation = when (uiState.displaySettings.screenMode) {
            ScreenMode.AUTO_RESPONSIVE -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            ScreenMode.LOCK_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ScreenMode.LOCK_PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    // Zero-permission Android Photo Picker for PNG/JPG canvas import
    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importImageFromUri(uri)
    }

    // Zero-permission Android Photo Picker for MP4/WebM Video Background / Reference import
    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importVideoLayerFromUri(uri)
    }

    // Zero-permission Android Photo Picker for PNG Body Part bound to a specific bone in Character & Rig Studio
    var pendingBoneIdForImage by remember { mutableStateOf<String?>(null) }
    val pickBonePartImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val boneId = pendingBoneIdForImage
        pendingBoneIdForImage = null
        if (uri != null && boneId != null) {
            viewModel.bindPickedImageToDraftBone(boneId, uri)
        }
    }

    // Zero-permission Android Photo Picker for Single-Image 2D Mesh Skinning in Character & Rig Studio
    val pickSingleMeshImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.bindPickedImageToDraftSingleMesh(uri)
    }

    // Zero-permission Android Photo Picker for attaching any custom PNG into Left or Right Hand
    var pendingHandTargetIsRight by remember { mutableStateOf(true) }
    var pendingHandTargetIsStudioDraft by remember { mutableStateOf(false) }
    val pickHandPropPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            if (pendingHandTargetIsStudioDraft) {
                viewModel.setStudioDraftHandCustomPng(pendingHandTargetIsRight, uri)
            } else {
                viewModel.setPuppetHandCustomPng(pendingHandTargetIsRight, uri)
            }
        }
    }

    // SAF OpenDocument for SVG import
    val importSvgLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importSvgFromUri(uri)
    }

    // SAF OpenDocument for Audio file import
    val importAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Audio Track"
            viewModel.importAudioFromUri(uri, name)
        }
    }

    // SAF OpenDocument for Project JSON import
    val importProjectLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importProjectFromUri(uri)
    }

    // SAF CreateDocument for Project JSON backup export
    val exportProjectJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) viewModel.exportProjectJsonToUri(uri)
    }

    // SAF CreateDocument for saving rendered PNG / ZIP / GIF / MP4 / WebM to any folder on the phone
    var pendingExportSaveFile by remember { mutableStateOf<File?>(null) }
    val saveExportToDeviceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val src = pendingExportSaveFile
        pendingExportSaveFile = null
        if (uri != null && src != null) {
            viewModel.saveExportFileToUri(src, uri)
        }
    }

    // Runtime RECORD_AUDIO permission launcher for Voice Recording
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startVoiceRecording()
        } else {
            viewModel.showToast("Microphone permission is needed to record voice")
        }
    }

    // Apply User UI Scale Setting (75%, 85%, 100%, 115%) cleanly via CompositionLocal Density
    val uiScale = uiState.displaySettings.uiScale.coerceIn(0.75f, 1.15f)
    val scaledDensity = remember(baseDensity, uiScale) {
        Density(
            density = baseDensity.density * uiScale,
            fontScale = baseDensity.fontScale * uiScale
        )
    }

    CompositionLocalProvider(LocalDensity provides scaledDensity) {
        when (uiState.destination) {
            StudioDestination.CHARACTER_RIG_STUDIO -> {
                CharacterRigStudioScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onPickImageForBone = { boneId ->
                        pendingBoneIdForImage = boneId
                        pickBonePartImageLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickSingleMeshImage = {
                        pickSingleMeshImageLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickHandPropPng = { isRightHand ->
                        pendingHandTargetIsRight = isRightHand
                        pendingHandTargetIsStudioDraft = true
                        pickHandPropPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                )
            }

            StudioDestination.EDITOR -> {
                if (uiState.activeProject != null) {
                    EditorWorkspaceScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        localAssets = localAssets,
                        myCharacters = myCharacters,
                        onBackToHub = { viewModel.closeProjectToHub() },
                        onImportImage = {
                            pickImageLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onImportHandPropPng = { isRightHand ->
                            pendingHandTargetIsRight = isRightHand
                            pendingHandTargetIsStudioDraft = false
                            pickHandPropPngLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onImportSvg = { importSvgLauncher.launch(arrayOf("image/svg+xml", "text/xml", "*/*")) },
                        onImportVideo = {
                            pickVideoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        onImportAudio = { importAudioLauncher.launch(arrayOf("audio/*")) },
                        onRequestRecordVoice = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                viewModel.startVoiceRecording()
                            } else {
                                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        onExportProjectJson = {
                            val safe = (uiState.activeProject?.name ?: "project").replace(Regex("[^A-Za-z0-9_\\-]"), "_")
                            exportProjectJsonLauncher.launch("${safe}.animaster.json")
                        },
                        onSaveExportedToDevice = { file, _ ->
                            pendingExportSaveFile = file
                            saveExportToDeviceLauncher.launch(file.name)
                        },
                        onShareExportedFile = { file, mime ->
                            runCatching {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    file
                                )
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = mime
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share Exported Animation"))
                            }.onFailure {
                                viewModel.showToast("Could not open share sheet")
                            }
                        }
                    )
                } else {
                    ProjectHubScreen(
                        projects = projects,
                        myCharacters = myCharacters,
                        recoverySnapshot = recoverySnapshot,
                        statusBanner = uiState.statusBanner,
                        onOpenProject = { viewModel.openProject(it) },
                        onCreateProject = { name, w, h, fps, tpl ->
                            viewModel.createNewProject(name, w, h, fps, tpl)
                        },
                        onDeleteProject = { viewModel.deleteProject(it) },
                        onImportProject = { importProjectLauncher.launch(arrayOf("application/json", "*/*")) },
                        onOpenCharacterRigStudio = { viewModel.openCharacterRigStudio(it) },
                        onOpenScreenSettings = { viewModel.openScreenSettingsDialog(true) },
                        onRecoverAutosave = { viewModel.recoverAutosave(it) },
                        onDismissRecovery = { viewModel.dismissRecovery() }
                    )
                }
            }

            StudioDestination.HUB -> {
                ProjectHubScreen(
                    projects = projects,
                    myCharacters = myCharacters,
                    recoverySnapshot = recoverySnapshot,
                    statusBanner = uiState.statusBanner,
                    onOpenProject = { viewModel.openProject(it) },
                    onCreateProject = { name, w, h, fps, tpl ->
                        viewModel.createNewProject(name, w, h, fps, tpl)
                    },
                    onDeleteProject = { viewModel.deleteProject(it) },
                    onImportProject = { importProjectLauncher.launch(arrayOf("application/json", "*/*")) },
                    onOpenCharacterRigStudio = { viewModel.openCharacterRigStudio(it) },
                    onOpenScreenSettings = { viewModel.openScreenSettingsDialog(true) },
                    onRecoverAutosave = { viewModel.recoverAutosave(it) },
                    onDismissRecovery = { viewModel.dismissRecovery() }
                )
            }
        }

        // Global Screen & Display Settings Dialog (accessible from both Project Hub & Editor Top Bar)
        if (uiState.showScreenSettingsDialog) {
            ScreenSettingsDialog(
                settings = uiState.displaySettings,
                showFitStageAction = uiState.destination == StudioDestination.EDITOR && uiState.activeProject != null,
                onSelectScreenMode = { viewModel.setScreenMode(it) },
                onSelectUiScale = { viewModel.setUiScale(it) },
                onFitStageToScreen = {
                    viewModel.resetCanvasViewport()
                    viewModel.showToast("Stage fitted to screen")
                },
                onDismiss = { viewModel.openScreenSettingsDialog(false) }
            )
        }
    }
}
