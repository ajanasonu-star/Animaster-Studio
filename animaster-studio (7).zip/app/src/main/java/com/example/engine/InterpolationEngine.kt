package com.example.engine

import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.CameraKeyframe
import com.example.data.model.CharacterViewAngle
import com.example.data.model.EasingType
import com.example.data.model.FrameContent
import com.example.data.model.MouthPhoneme
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.SkeletalRig
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import kotlin.math.hypot
import kotlin.math.pow

data class EvaluatedTransform(
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val opacity: Float = 1f
)

data class EvaluatedCamera(
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val rotationDeg: Float = 0f
)

data class EvaluatedPuppetRoot(
    val rootX: Float,
    val rootY: Float,
    val scale: Float,
    val flippedHorizontal: Boolean,
    val eyePack: String,
    val mouthPhoneme: String,
    val viewAngle: String = CharacterViewAngle.FRONT.name
)

object InterpolationEngine {

    fun applyEasing(t: Float, easingName: String): Float {
        val clamped = t.coerceIn(0f, 1f)
        val easing = runCatching { EasingType.valueOf(easingName) }.getOrDefault(EasingType.EASE_IN_OUT)
        return when (easing) {
            EasingType.LINEAR -> clamped
            EasingType.SNAP -> if (clamped < 0.99f) 0f else 1f
            EasingType.EASE_IN -> clamped * clamped * clamped
            EasingType.EASE_OUT -> 1f - (1f - clamped).pow(3)
            EasingType.EASE_IN_OUT -> if (clamped < 0.5f) {
                4f * clamped * clamped * clamped
            } else {
                1f - (-2f * clamped + 2f).pow(3) / 2f
            }
            EasingType.BOUNCE -> bounceOut(clamped)
        }
    }

    private fun bounceOut(x: Float): Float {
        val n1 = 7.5625f
        val d1 = 2.75f
        return when {
            x < 1f / d1 -> n1 * x * x
            x < 2f / d1 -> {
                val t = x - 1.5f / d1
                n1 * t * t + 0.75f
            }
            x < 2.5f / d1 -> {
                val t = x - 2.25f / d1
                n1 * t * t + 0.9375f
            }
            else -> {
                val t = x - 2.625f / d1
                n1 * t * t + 0.984375f
            }
        }
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    fun evaluateLayerTransform(layer: AnimationLayer, frame: Int, totalFrames: Int): EvaluatedTransform {
        var base = if (layer.keyframes.isEmpty()) {
            EvaluatedTransform()
        } else {
            val sorted = layer.keyframes.sortedBy { it.frame }
            when {
                frame <= sorted.first().frame -> sorted.first().toEvaluated()
                frame >= sorted.last().frame -> sorted.last().toEvaluated()
                else -> {
                    val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                    val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                    val next = sorted[nextIdx]
                    if (prev.frame == next.frame) {
                        next.toEvaluated()
                    } else {
                        val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                        val eased = applyEasing(rawT, prev.easing)
                        EvaluatedTransform(
                            x = lerp(prev.x, next.x, eased),
                            y = lerp(prev.y, next.y, eased),
                            rotationDeg = lerp(prev.rotationDeg, next.rotationDeg, eased),
                            scaleX = lerp(prev.scaleX, next.scaleX, eased),
                            scaleY = lerp(prev.scaleY, next.scaleY, eased),
                            opacity = lerp(prev.opacity, next.opacity, eased)
                        )
                    }
                }
            }
        }

        if (layer.motionPath.size >= 2 && totalFrames > 1) {
            val progress = (frame.toFloat() / (totalFrames - 1).toFloat()).coerceIn(0f, 1f)
            val pathPos = samplePolyline(layer.motionPath, progress)
            val origin = layer.motionPath.first()
            base = base.copy(
                x = base.x + (pathPos.x - origin.x),
                y = base.y + (pathPos.y - origin.y)
            )
        }
        return base
    }

    fun evaluatePuppetRoot(rig: SkeletalRig, frame: Int): EvaluatedPuppetRoot {
        if (rig.rootKeyframes.isEmpty()) {
            return EvaluatedPuppetRoot(
                rootX = rig.rootX,
                rootY = rig.rootY,
                scale = rig.scale,
                flippedHorizontal = rig.flippedHorizontal,
                eyePack = rig.eyePack,
                mouthPhoneme = rig.mouthPhoneme,
                viewAngle = rig.viewAngle
            )
        }
        val sorted = rig.rootKeyframes.sortedBy { it.frame }
        return when {
            frame <= sorted.first().frame -> sorted.first().toEvaluated()
            frame >= sorted.last().frame -> sorted.last().toEvaluated()
            else -> {
                val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                val next = sorted[nextIdx]
                if (prev.frame == next.frame) {
                    next.toEvaluated()
                } else {
                    val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                    val eased = applyEasing(rawT, prev.easing)
                    EvaluatedPuppetRoot(
                        rootX = lerp(prev.rootX, next.rootX, eased),
                        rootY = lerp(prev.rootY, next.rootY, eased),
                        scale = lerp(prev.scale, next.scale, eased).coerceIn(0.25f, 4f),
                        flippedHorizontal = prev.flippedHorizontal,
                        eyePack = prev.eyePack,
                        mouthPhoneme = prev.mouthPhoneme,
                        viewAngle = prev.viewAngle
                    )
                }
            }
        }
    }

    fun evaluateCamera(scene: AnimationScene, frame: Int): EvaluatedCamera {
        val sorted = scene.cameraKeyframes.sortedBy { it.frame }
        if (sorted.isEmpty()) return EvaluatedCamera()
        return when {
            frame <= sorted.first().frame -> sorted.first().toEvaluated()
            frame >= sorted.last().frame -> sorted.last().toEvaluated()
            else -> {
                val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                val next = sorted[nextIdx]
                if (prev.frame == next.frame) {
                    next.toEvaluated()
                } else {
                    val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                    val eased = applyEasing(rawT, prev.easing)
                    EvaluatedCamera(
                        panX = lerp(prev.panX, next.panX, eased),
                        panY = lerp(prev.panY, next.panY, eased),
                        zoom = lerp(prev.zoom, next.zoom, eased).coerceIn(0.25f, 4f),
                        rotationDeg = lerp(prev.rotationDeg, next.rotationDeg, eased)
                    )
                }
            }
        }
    }

    fun evaluateRigAngles(rig: SkeletalRig, frame: Int): Map<String, Float> {
        val defaultAngles = rig.bones.associate { it.id to it.localAngleDeg }
        if (rig.poseKeyframes.isEmpty()) return defaultAngles

        val sortedFrames = rig.poseKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        if (sortedFrames.isEmpty()) return defaultAngles

        val exact = rig.poseKeyframes[frame.toString()]
        if (exact != null) return defaultAngles + exact

        return when {
            frame < sortedFrames.first() -> defaultAngles + (rig.poseKeyframes[sortedFrames.first().toString()] ?: emptyMap())
            frame > sortedFrames.last() -> defaultAngles + (rig.poseKeyframes[sortedFrames.last().toString()] ?: emptyMap())
            else -> {
                val nextIdx = sortedFrames.indexOfFirst { it >= frame }
                val prevF = sortedFrames[(nextIdx - 1).coerceAtLeast(0)]
                val nextF = sortedFrames[nextIdx]
                val prevMap = rig.poseKeyframes[prevF.toString()] ?: emptyMap()
                val nextMap = rig.poseKeyframes[nextF.toString()] ?: emptyMap()
                val t = applyEasing((frame - prevF).toFloat() / (nextF - prevF).coerceAtLeast(1).toFloat(), EasingType.EASE_IN_OUT.name)
                rig.bones.associate { bone ->
                    val a = prevMap[bone.id] ?: bone.localAngleDeg
                    val b = nextMap[bone.id] ?: bone.localAngleDeg
                    bone.id to lerpAngle(a, b, t)
                }
            }
        }
    }

    /**
     * Evaluates voiceover audio waveform energy at [frame] to drive Auto Lip-Sync talking mouths.
     */
    fun evaluateLipSyncPhoneme(
        audioTracks: List<AudioTrackItem>,
        frame: Int,
        fps: Int
    ): MouthPhoneme {
        val voiceTracks = audioTracks.filter { !it.muted && it.waveformPeaks.isNotEmpty() }
            .sortedByDescending { it.kind == AudioTrackKind.VOICE.name }
        if (voiceTracks.isEmpty()) return MouthPhoneme.REST

        var maxEnergy = 0f
        for (track in voiceTracks) {
            val clipFrames = (((track.trimEndMs - track.trimStartMs).coerceAtLeast(200L) / 1000f) * fps.coerceAtLeast(1)).toInt().coerceAtLeast(1)
            if (frame >= track.startFrame && frame < track.startFrame + clipFrames) {
                val rel = (frame - track.startFrame).toFloat() / clipFrames.toFloat()
                val idx = (rel * track.waveformPeaks.size).toInt().coerceIn(0, track.waveformPeaks.lastIndex)
                val energy = track.waveformPeaks[idx] * track.volume
                if (energy > maxEnergy) maxEnergy = energy
            }
        }
        return when {
            maxEnergy < 0.14f -> MouthPhoneme.REST
            maxEnergy < 0.30f -> if (frame % 2 == 0) MouthPhoneme.I else MouthPhoneme.U
            maxEnergy < 0.52f -> if (frame % 3 == 0) MouthPhoneme.E else MouthPhoneme.O
            else -> MouthPhoneme.A
        }
    }

    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        var diff = (b - a) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return a + diff * t
    }

    fun resolveFrameContent(layer: AnimationLayer, frame: Int, holdPrevious: Boolean = true): FrameContent? {
        layer.frames[frame.toString()]?.let { return it }
        if (!holdPrevious) return null
        val prevKey = layer.frames.keys
            .mapNotNull { it.toIntOrNull() }
            .filter { it < frame }
            .maxOrNull() ?: return null
        return layer.frames[prevKey.toString()]
    }

    fun samplePolyline(points: List<Vec2>, t: Float): Vec2 {
        if (points.isEmpty()) return Vec2(0f, 0f)
        if (points.size == 1) return points.first()
        val lengths = FloatArray(points.size - 1)
        var total = 0f
        for (i in 0 until points.size - 1) {
            val d = hypot(points[i + 1].x - points[i].x, points[i + 1].y - points[i].y)
            lengths[i] = d
            total += d
        }
        if (total <= 0.001f) return points.first()
        val target = total * t.coerceIn(0f, 1f)
        var acc = 0f
        for (i in lengths.indices) {
            if (acc + lengths[i] >= target) {
                val segT = if (lengths[i] > 0f) (target - acc) / lengths[i] else 0f
                return Vec2(
                    lerp(points[i].x, points[i + 1].x, segT),
                    lerp(points[i].y, points[i + 1].y, segT)
                )
            }
            acc += lengths[i]
        }
        return points.last()
    }

    private fun TransformKeyframe.toEvaluated() = EvaluatedTransform(
        x = x, y = y, rotationDeg = rotationDeg, scaleX = scaleX, scaleY = scaleY, opacity = opacity
    )

    private fun CameraKeyframe.toEvaluated() = EvaluatedCamera(
        panX = panX, panY = panY, zoom = zoom, rotationDeg = rotationDeg
    )

    private fun PuppetRootKeyframe.toEvaluated() = EvaluatedPuppetRoot(
        rootX = rootX,
        rootY = rootY,
        scale = scale,
        flippedHorizontal = flippedHorizontal,
        eyePack = eyePack,
        mouthPhoneme = mouthPhoneme,
        viewAngle = viewAngle
    )
}
