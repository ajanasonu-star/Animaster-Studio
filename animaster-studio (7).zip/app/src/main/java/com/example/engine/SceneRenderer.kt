package com.example.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.util.LruCache
import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.FrameContent
import com.example.data.model.HandPropKind
import com.example.data.model.ImportedImageItem
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneVfxType
import com.example.data.model.ShapeKind
import com.example.data.model.SkeletalRig
import com.example.data.model.SubtitleCue
import com.example.data.model.SubtitleStyle
import com.example.data.model.TextBoxStyle
import com.example.data.model.TextFontStyle
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.TextOutAnimation
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Deterministic high-performance 2D Canvas renderer shared between the live editor,
 * Character & Rig Studio, and the offline PNG / GIF / MP4 / WebM export pipeline.
 */
object SceneRenderer {

    private val bitmapCache = object : LruCache<String, Bitmap>(32) {}
    private val videoFrameCache = object : LruCache<String, Bitmap>(16) {}

    fun getCachedBitmap(path: String): Bitmap? {
        if (path.isBlank()) return null
        bitmapCache.get(path)?.let { if (!it.isRecycled) return it }
        return runCatching {
            val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            BitmapFactory.decodeFile(path, opts)?.also { bitmapCache.put(path, it) }
        }.getOrNull()
    }

    private fun getCachedVideoFrame(path: String, timeUs: Long): Bitmap? {
        if (path.isBlank()) return null
        // Bucket video frame lookups to 100ms intervals for smooth scrubbing performance
        val bucketUs = (timeUs / 100_000L) * 100_000L
        val key = "$path@$bucketUs"
        videoFrameCache.get(key)?.let { if (!it.isRecycled) return it }
        return runCatching {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(path)
            val bmp = mmr.getFrameAtTime(bucketUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            mmr.release()
            bmp?.also { videoFrameCache.put(key, it) }
        }.getOrNull()
    }

    fun renderSceneToBitmap(
        scene: AnimationScene,
        frame: Int,
        outWidth: Int,
        outHeight: Int,
        projectWidth: Int,
        projectHeight: Int,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = false,
        showMotionPaths: Boolean = false,
        selectedLayerId: String? = null,
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false
    ): Bitmap {
        val bmp = Bitmap.createBitmap(outWidth.coerceAtLeast(16), outHeight.coerceAtLeast(16), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (transparentBackground && !chromaKeyGreen) {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        }
        val sx = outWidth.toFloat() / projectWidth.toFloat()
        val sy = outHeight.toFloat() / projectHeight.toFloat()
        canvas.scale(sx, sy)
        renderScene(
            canvas = canvas,
            scene = scene,
            frame = frame,
            projectWidth = projectWidth.toFloat(),
            projectHeight = projectHeight.toFloat(),
            fps = fps,
            audioTracks = audioTracks,
            onionSkin = onionSkin,
            ghostFrames = ghostFrames,
            showRigBones = showRigBones,
            showMotionPaths = showMotionPaths,
            showSelectionBox = false,
            selectedLayerId = if (showRigBones) selectedLayerId else null,
            selectedBoneId = null,
            selectedTextId = null,
            transparentBackground = transparentBackground,
            chromaKeyGreen = chromaKeyGreen
        )
        return bmp
    }

    fun renderScene(
        canvas: Canvas,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Float,
        projectHeight: Float,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = true,
        showMotionPaths: Boolean = true,
        showSelectionBox: Boolean = false,
        selectedLayerId: String? = null,
        selectedBoneId: String? = null,
        selectedTextId: String? = null,
        activePreviewStroke: DrawStroke? = null,
        activePreviewShape: VectorShape? = null,
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false
    ) {
        val camera = InterpolationEngine.evaluateCamera(scene, frame)

        // 1. Background (with automatic continuous scroll if backgroundScrollSpeed != 0)
        val scrollOffsetX = frame * scene.backgroundScrollSpeed * 2.5f
        if (chromaKeyGreen) {
            canvas.drawColor(Color.rgb(0, 255, 0))
        } else if (!transparentBackground) {
            drawBackgroundTemplate(
                canvas = canvas,
                templateName = scene.backgroundTemplate,
                bgColorArgb = scene.backgroundColorArgb,
                w = projectWidth,
                h = projectHeight,
                panX = camera.panX * 0.35f + scrollOffsetX,
                panY = camera.panY * 0.35f,
                frame = frame
            )
        }

        // 2. Onion-Skin Watermark Trail (25% opacity) in BOTH Frame Animation & Bone Rigging
        if (onionSkin || ghostFrames) {
            val offsets = if (ghostFrames) listOf(-3, -2, -1, 1, 2) else listOf(-1, 1)
            for (delta in offsets) {
                val targetF = frame + delta
                if (targetF in 0 until scene.durationFrames) {
                    val alpha = if (kotlin.math.abs(delta) == 1) 0.25f else 0.14f
                    val tint = if (delta < 0) 0xFFA78BFAL else 0xFF2DD4BFL
                    scene.layers.filter { it.visible && it.type != LayerType.VIDEO.name }.forEach { layer ->
                        drawLayerAtFrame(
                            canvas = canvas,
                            scene = scene,
                            layer = layer,
                            frame = targetF,
                            fps = fps,
                            audioTracks = audioTracks,
                            camera = camera,
                            projectWidth = projectWidth,
                            projectHeight = projectHeight,
                            overrideAlpha = alpha,
                            tintColorArgb = tint,
                            showRigOverlay = showRigBones, // Also show ghost skeleton bone trails!
                            isSelectedLayer = false,
                            selectedBoneId = null
                        )
                    }
                }
            }
        }

        // 3. Current Frame Layers (bottom to top)
        scene.layers.filter { it.visible }.forEach { layer ->
            val isSel = layer.id == selectedLayerId
            drawLayerAtFrame(
                canvas = canvas,
                scene = scene,
                layer = layer,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                camera = camera,
                projectWidth = projectWidth,
                projectHeight = projectHeight,
                overrideAlpha = null,
                tintColorArgb = null,
                showRigOverlay = showRigBones,
                isSelectedLayer = isSel,
                selectedBoneId = if (isSel) selectedBoneId else null
            )

            // Direct On-Canvas Touch Handles for selected Drawing/Prop/Image layer in SELECT mode
            if (showSelectionBox && isSel && layer.type != LayerType.RIG.name) {
                val bounds = computeLayerBounds(layer, frame, scene.durationFrames, projectWidth, projectHeight)
                if (bounds != null) {
                    canvas.save()
                    applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)
                    drawSelectionTouchHandles(canvas, bounds)
                    canvas.restore()
                }
            }

            if (showMotionPaths && layer.motionPath.size >= 2) {
                drawMotionPathOverlay(canvas, layer.motionPath, isSel)
            }
        }

        // 4. Aesthetic & Horror Scene VFX Overlays
        if (scene.activeVfx.isNotEmpty() && !chromaKeyGreen) {
            drawSceneVfx(canvas, scene.activeVfx, projectWidth, projectHeight, frame)
        }

        // 4b. Cinematic Color Grading Filter (Horror Cold, Midnight, Retro VHS, Noir B&W, Warm Glow)
        if (!chromaKeyGreen && !transparentBackground && scene.colorGrade != SceneColorGrade.NONE.name) {
            drawColorGradeOverlay(canvas, scene.colorGrade, projectWidth, projectHeight, frame)
        }

        // 4c. Dynamic YouTube Subtitles & Captions Track
        if (scene.subtitles.isNotEmpty()) {
            drawSubtitles(canvas, scene.subtitles, frame, projectWidth, projectHeight)
        }

        // 4d. Kinetic Animated Text & Title Layers (visible across scene timeline)
        if (scene.animatedTexts.isNotEmpty()) {
            scene.animatedTexts.filter { it.visible }.forEach { textItem ->
                drawTextItem(
                    canvas = canvas,
                    item = textItem,
                    frame = frame,
                    layerAlpha = 1f,
                    tintColorArgb = null,
                    isSelected = (textItem.id == selectedTextId)
                )
            }
        }

        // 5. Live in-progress stroke / shape preview
        if (activePreviewStroke != null || activePreviewShape != null) {
            canvas.save()
            applyCameraTransform(canvas, camera, projectWidth, projectHeight, 1f)
            activePreviewStroke?.let { drawStroke(canvas, it, 1f, null) }
            activePreviewShape?.let { drawVectorShape(canvas, it, 1f, null) }
            canvas.restore()
        }
    }

    fun computeLayerBounds(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int,
        projectWidth: Float,
        projectHeight: Float
    ): RectF? {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, totalFrames)
        val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        fun include(x: Float, y: Float) {
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }

        content?.strokes?.forEach { s -> s.points.forEach { include(it.x, it.y) } }
        content?.shapes?.filter { it.kind != ShapeKind.FILL_BACKDROP.name }?.forEach { s ->
            include(s.startX, s.startY); include(s.endX, s.endY)
        }
        content?.images?.forEach { img ->
            include(img.x - img.width / 2f, img.y - img.height / 2f)
            include(img.x + img.width / 2f, img.y + img.height / 2f)
        }
        content?.texts?.forEach { t ->
            include(t.x, t.y - t.fontSize)
            include(t.x + t.text.length * t.fontSize * 0.55f, t.y + 12f)
        }
        layer.character?.let { c ->
            include(c.x - 90f * c.scale, c.y - 170f * c.scale)
            include(c.x + 90f * c.scale, c.y + 170f * c.scale)
        }

        if (!minX.isFinite()) return null
        val cx = projectWidth / 2f
        val cy = projectHeight / 2f
        val sx = tf.scaleX
        val sy = tf.scaleY
        val tx1 = (minX - cx) * sx + cx + tf.x
        val ty1 = (minY - cy) * sy + cy + tf.y
        val tx2 = (maxX - cx) * sx + cx + tf.x
        val ty2 = (maxY - cy) * sy + cy + tf.y
        return RectF(min(tx1, tx2) - 14f, min(ty1, ty2) - 14f, max(tx1, tx2) + 14f, max(ty1, ty2) + 14f)
    }

    private fun drawSelectionTouchHandles(canvas: Canvas, rect: RectF) {
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF2DD4BF.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
            pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
        }
        canvas.drawRect(rect, boxPaint)

        // Top Rotation Lollipop Handle
        val rotX = rect.centerX()
        val rotY = rect.top - 42f
        val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFF6B35.toInt()
            strokeWidth = 3f
        }
        canvas.drawLine(rect.centerX(), rect.top, rotX, rotY, stemPaint)
        val rotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
        val whiteStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f }
        canvas.drawCircle(rotX, rotY, 13f, rotFill)
        canvas.drawCircle(rotX, rotY, 13f, whiteStroke)

        // 4 Corner Resize Handles
        val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt(); style = Paint.Style.FILL }
        listOf(
            Vec2(rect.left, rect.top),
            Vec2(rect.right, rect.top),
            Vec2(rect.left, rect.bottom),
            Vec2(rect.right, rect.bottom)
        ).forEach { corner ->
            canvas.drawCircle(corner.x, corner.y, 11f, handleFill)
            canvas.drawCircle(corner.x, corner.y, 11f, whiteStroke)
        }
    }

    private fun applyCameraTransform(
        canvas: Canvas,
        camera: EvaluatedCamera,
        w: Float,
        h: Float,
        parallax: Float
    ) {
        canvas.translate(w / 2f, h / 2f)
        canvas.rotate(camera.rotationDeg)
        val effectiveZoom = 1f + (camera.zoom - 1f) * parallax
        canvas.scale(effectiveZoom, effectiveZoom)
        canvas.translate(-w / 2f - camera.panX * parallax, -h / 2f - camera.panY * parallax)
    }

    private fun drawLayerAtFrame(
        canvas: Canvas,
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        camera: EvaluatedCamera,
        projectWidth: Float,
        projectHeight: Float,
        overrideAlpha: Float?,
        tintColorArgb: Long?,
        showRigOverlay: Boolean,
        isSelectedLayer: Boolean,
        selectedBoneId: String?
    ) {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val combinedAlpha = ((overrideAlpha ?: (layer.opacity * tf.opacity))).coerceIn(0f, 1f)
        if (combinedAlpha <= 0.01f) return

        canvas.save()
        applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)

        // Seamless horizontal background scrolling for custom Background layers
        val bgAutoShiftX = if (layer.type == LayerType.BACKGROUND.name && scene.backgroundScrollSpeed != 0f) {
            val raw = -(frame * scene.backgroundScrollSpeed * 2.5f * layer.parallaxDepth)
            ((raw % projectWidth) + projectWidth) % projectWidth - projectWidth * 0.5f
        } else 0f

        canvas.translate(projectWidth / 2f + tf.x + bgAutoShiftX, projectHeight / 2f + tf.y)
        canvas.rotate(tf.rotationDeg)
        canvas.scale(tf.scaleX, tf.scaleY)
        canvas.translate(-projectWidth / 2f, -projectHeight / 2f)

        // Video Background / Reference Layer
        if (layer.type == LayerType.VIDEO.name && !layer.videoFilePath.isNullOrBlank()) {
            val timeUs = ((frame.toDouble() / fps.coerceAtLeast(1)) * 1_000_000.0).toLong()
            val vBmp = getCachedVideoFrame(layer.videoFilePath, timeUs)
            if (vBmp != null) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = (combinedAlpha * 255).toInt().coerceIn(0, 255)
                }
                canvas.drawBitmap(vBmp, null, RectF(0f, 0f, projectWidth, projectHeight), p)
            }
        }

        val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
        if (content != null) {
            // Avoid rendering a duplicate static copy of any PNG that is already bound to this layer's rig
            val filteredContent = if (layer.type == LayerType.RIG.name && layer.rig != null && content.images.isNotEmpty()) {
                val rigPaths = buildSet {
                    layer.rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let(::add)
                    layer.rig.bones.mapNotNull { it.boundImagePath?.takeIf { p -> p.isNotBlank() } }.forEach(::add)
                }
                if (rigPaths.isNotEmpty()) {
                    content.copy(images = content.images.filterNot { it.filePath in rigPaths })
                } else content
            } else content
            drawFrameContent(canvas, filteredContent, combinedAlpha, tintColorArgb, frame)
        }

        if (layer.type == LayerType.CHARACTER.name) {
            val charSpec = content?.characterOverride ?: layer.character
            if (charSpec != null) {
                drawCharacter(canvas, charSpec, combinedAlpha, tintColorArgb, frame, fps, audioTracks)
            }
        }

        if (layer.type == LayerType.RIG.name && layer.rig != null) {
            val puppetRoot = InterpolationEngine.evaluatePuppetRoot(layer.rig, frame)
            val angles = InterpolationEngine.evaluateRigAngles(layer.rig, frame)
            drawSkeletalRig(
                canvas = canvas,
                rig = layer.rig,
                puppetRoot = puppetRoot,
                angles = angles,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                alpha = combinedAlpha,
                tintColorArgb = tintColorArgb,
                showOverlay = showRigOverlay,
                isSelectedPuppet = isSelectedLayer,
                selectedBoneId = selectedBoneId
            )
        }

        canvas.restore()
    }

    private fun drawFrameContent(
        canvas: Canvas,
        content: FrameContent,
        alpha: Float,
        tintColorArgb: Long?,
        frame: Int = 0
    ) {
        content.images.forEach { img -> drawImportedImage(canvas, img, alpha, tintColorArgb) }
        content.shapes.forEach { shape -> drawVectorShape(canvas, shape, alpha, tintColorArgb) }
        content.strokes.forEach { stroke -> drawStroke(canvas, stroke, alpha, tintColorArgb) }
        content.texts.forEach { textItem -> drawTextItem(canvas, textItem, frame, alpha, tintColorArgb, false) }
    }

    private fun drawImportedImage(canvas: Canvas, item: ImportedImageItem, layerAlpha: Float, tintColorArgb: Long?) {
        val bmp = getCachedBitmap(item.filePath) ?: return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (layerAlpha * item.opacity * 255).toInt().coerceIn(0, 255)
            if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
        }
        canvas.save()
        canvas.translate(item.x, item.y)
        canvas.rotate(item.rotationDeg)
        val dst = RectF(-item.width / 2f, -item.height / 2f, item.width / 2f, item.height / 2f)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
    }

    private fun buildTintColorFilter(tintArgb: Long): ColorMatrixColorFilter {
        val r = Color.red(tintArgb.toInt()) / 255f
        val g = Color.green(tintArgb.toInt()) / 255f
        val b = Color.blue(tintArgb.toInt()) / 255f
        return ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    r, 0f, 0f, 0f, 30f,
                    0f, g, 0f, 0f, 30f,
                    0f, 0f, b, 0f, 30f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    private fun drawStroke(canvas: Canvas, stroke: DrawStroke, layerAlpha: Float, tintColorArgb: Long?) {
        if (stroke.points.isEmpty()) return
        val effectiveAlpha = (layerAlpha * stroke.opacity * 255).toInt().coerceIn(0, 255)
        val baseColor = (tintColorArgb ?: stroke.colorArgb).toInt()

        if (stroke.tool == EditorTool.AIRBRUSH.name) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = baseColor
                style = Paint.Style.FILL
                alpha = (effectiveAlpha * 0.25f).toInt().coerceIn(8, 255)
            }
            val spread = stroke.strokeWidth * 1.4f
            val rng = Random(stroke.id.hashCode())
            stroke.points.forEach { pt ->
                repeat(10) {
                    val a = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * spread
                    canvas.drawCircle(
                        pt.x + cos(a) * r,
                        pt.y + sin(a) * r,
                        (stroke.strokeWidth * 0.14f).coerceAtLeast(1.5f),
                        dotPaint
                    )
                }
            }
            return
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = baseColor
            style = if (stroke.isClosedBezier) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
            strokeWidth = if (stroke.tool == EditorTool.PENCIL.name) {
                (stroke.strokeWidth * 0.55f).coerceAtLeast(1.5f)
            } else {
                stroke.strokeWidth
            }
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = effectiveAlpha
        }

        if (stroke.gradientEndArgb != null && tintColorArgb == null && stroke.points.size >= 2) {
            val first = stroke.points.first()
            val last = stroke.points.last()
            paint.shader = LinearGradient(
                first.x, first.y, last.x, last.y,
                stroke.colorArgb.toInt(),
                stroke.gradientEndArgb.toInt(),
                Shader.TileMode.CLAMP
            )
        }

        if (stroke.points.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(stroke.points[0].x, stroke.points[0].y, paint.strokeWidth / 2f, paint)
            return
        }

        val path = Path().apply {
            moveTo(stroke.points[0].x, stroke.points[0].y)
            for (i in 1 until stroke.points.size) {
                val prev = stroke.points[i - 1]
                val curr = stroke.points[i]
                val midX = (prev.x + curr.x) / 2f
                val midY = (prev.y + curr.y) / 2f
                quadTo(prev.x, prev.y, midX, midY)
            }
            val last = stroke.points.last()
            lineTo(last.x, last.y)
            if (stroke.isClosedBezier) close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawVectorShape(canvas: Canvas, shape: VectorShape, layerAlpha: Float, tintColorArgb: Long?) {
        val alphaInt = (layerAlpha * shape.opacity * 255).toInt().coerceIn(0, 255)
        val kind = runCatching { ShapeKind.valueOf(shape.kind) }.getOrDefault(ShapeKind.RECTANGLE)
        val rect = RectF(
            min(shape.startX, shape.endX),
            min(shape.startY, shape.endY),
            max(shape.startX, shape.endX),
            max(shape.startY, shape.endY)
        )

        canvas.save()
        if (shape.rotationDeg != 0f) canvas.rotate(shape.rotationDeg, rect.centerX(), rect.centerY())

        val fillPaint = shape.fillColorArgb?.let { fillHex ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = (tintColorArgb ?: fillHex).toInt()
                alpha = alphaInt
                if (shape.gradientEndArgb != null && tintColorArgb == null) {
                    shader = LinearGradient(
                        rect.left, rect.top, rect.right, rect.bottom,
                        fillHex.toInt(), shape.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                    )
                }
            }
        }

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: shape.strokeColorArgb).toInt()
            strokeWidth = shape.strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (kind) {
            ShapeKind.LINE -> canvas.drawLine(shape.startX, shape.startY, shape.endX, shape.endY, strokePaint)
            ShapeKind.RECTANGLE -> {
                fillPaint?.let { canvas.drawRoundRect(rect, 10f, 10f, it) }
                if (shape.strokeWidth > 0f) canvas.drawRoundRect(rect, 10f, 10f, strokePaint)
            }
            ShapeKind.FILL_BACKDROP -> fillPaint?.let { canvas.drawRect(rect, it) }
            ShapeKind.CIRCLE -> {
                fillPaint?.let { canvas.drawOval(rect, it) }
                if (shape.strokeWidth > 0f) canvas.drawOval(rect, strokePaint)
            }
            ShapeKind.POLYGON -> {
                val sides = shape.polygonSides.coerceIn(3, 12)
                val cx = rect.centerX(); val cy = rect.centerY()
                val rx = rect.width() / 2f; val ry = rect.height() / 2f
                val path = Path()
                for (i in 0 until sides) {
                    val angle = (i * 2.0 * PI / sides) - PI / 2.0
                    val px = cx + (cos(angle) * rx).toFloat()
                    val py = cy + (sin(angle) * ry).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                fillPaint?.let { canvas.drawPath(path, it) }
                if (shape.strokeWidth > 0f) canvas.drawPath(path, strokePaint)
            }
        }
        canvas.restore()
    }

    private fun resolveTextTypeface(fontStyleName: String, fallbackBold: Boolean): Typeface {
        return when (runCatching { TextFontStyle.valueOf(fontStyleName) }.getOrNull()) {
            TextFontStyle.BOLD_CARTOON -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            TextFontStyle.SERIF_HORROR -> Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            TextFontStyle.MONO_TECH -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            TextFontStyle.CLASSIC_CLEAN -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            TextFontStyle.COMIC_ITALIC -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            null -> if (fallbackBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    fun computeTextBounds(item: CanvasTextItem): RectF {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = item.fontSize.coerceIn(16f, 220f)
            typeface = resolveTextTypeface(item.fontStyle, item.isBold)
        }
        val lines = item.text.ifBlank { "Text" }.split("\n")
        val maxW = lines.maxOfOrNull { paint.measureText(it) }?.coerceAtLeast(80f) ?: 120f
        val lineH = item.fontSize * 1.18f
        val totalH = (lines.size * lineH).coerceAtLeast(item.fontSize)
        val padX = 34f
        val padY = 24f
        return RectF(
            item.x - maxW / 2f - padX,
            item.y - totalH / 2f - padY,
            item.x + maxW / 2f + padX,
            item.y + totalH / 2f + padY
        )
    }

    private fun drawTextItem(
        canvas: Canvas,
        item: CanvasTextItem,
        frame: Int,
        layerAlpha: Float,
        tintColorArgb: Long?,
        isSelected: Boolean
    ) {
        if (item.text.isBlank()) return
        if (frame < item.startFrame || frame > item.endFrame) return

        val inAnim = runCatching { TextInAnimation.valueOf(item.inAnimation) }.getOrDefault(TextInAnimation.NONE)
        val loopAnim = runCatching { TextLoopAnimation.valueOf(item.loopAnimation) }.getOrDefault(TextLoopAnimation.NONE)
        val outAnim = runCatching { TextOutAnimation.valueOf(item.outAnimation) }.getOrDefault(TextOutAnimation.NONE)
        val boxStyle = runCatching { TextBoxStyle.valueOf(item.boxStyle) }.getOrDefault(TextBoxStyle.NONE)

        val localFrame = (frame - item.startFrame).coerceAtLeast(0)
        val inDur = item.inDurationFrames.coerceAtLeast(1)
        val inT = (localFrame.toFloat() / inDur.toFloat()).coerceIn(0f, 1f)

        val remainingFrames = if (item.endFrame < 9000) (item.endFrame - frame).coerceAtLeast(0) else 9999
        val outDur = item.outDurationFrames.coerceAtLeast(1)
        val outT = if (outAnim != TextOutAnimation.NONE && remainingFrames < outDur) {
            1f - (remainingFrames.toFloat() / outDur.toFloat()).coerceIn(0f, 1f)
        } else 0f

        var animDx = 0f
        var animDy = 0f
        var animScaleX = 1f
        var animScaleY = 1f
        var animRot = 0f
        var animAlpha = (layerAlpha * item.opacity).coerceIn(0f, 1f)
        var visibleText = item.text

        // 1. Entrance Animation
        when (inAnim) {
            TextInAnimation.POP_BOUNCE -> {
                if (inT < 1f) {
                    val sc = when {
                        inT < 0.55f -> (inT / 0.55f) * 1.26f
                        inT < 0.80f -> 1.26f - ((inT - 0.55f) / 0.25f) * 0.34f
                        else -> 0.92f + ((inT - 0.80f) / 0.20f) * 0.08f
                    }
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (inT * 2.5f).coerceIn(0f, 1f)
                }
            }
            TextInAnimation.TYPEWRITER -> {
                if (inT < 1f) {
                    val count = (item.text.length * inT).toInt().coerceIn(1, item.text.length)
                    val caret = if ((localFrame / 3) % 2 == 0) "|" else ""
                    visibleText = item.text.take(count) + caret
                }
            }
            TextInAnimation.SLIDE_UP -> {
                val ease = 1f - (1f - inT) * (1f - inT) * (1f - inT)
                animDy += (1f - ease) * 110f
                animAlpha *= ease
            }
            TextInAnimation.SLIDE_LEFT -> {
                val ease = 1f - (1f - inT) * (1f - inT) * (1f - inT)
                animDx += (1f - ease) * 190f
                animAlpha *= ease
            }
            TextInAnimation.ZOOM_SLAM -> {
                if (inT < 1f) {
                    val sc = 2.6f - 1.6f * (inT * inT)
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (inT * 2f).coerceIn(0f, 1f)
                } else if (localFrame - inDur in 0..4) {
                    val amp = (5 - (localFrame - inDur)) * 4f
                    animDx += if (localFrame % 2 == 0) amp else -amp
                    animDy += if (localFrame % 3 == 0) -amp * 0.6f else amp * 0.6f
                }
            }
            TextInAnimation.SPIN_POP -> {
                val ease = 1f - (1f - inT) * (1f - inT)
                animScaleX *= ease.coerceAtLeast(0.05f)
                animScaleY *= ease.coerceAtLeast(0.05f)
                animRot += (1f - ease) * -360f
                animAlpha *= ease
            }
            TextInAnimation.FADE_IN -> {
                animAlpha *= inT
            }
            TextInAnimation.DROP_LETTERS, TextInAnimation.NONE -> Unit
        }

        // 2. Continuous Loop Animation
        val spd = item.loopSpeed.coerceIn(0.25f, 3f)
        val phase = localFrame * 0.28f * spd
        when (loopAnim) {
            TextLoopAnimation.BOUNCE -> {
                val b = kotlin.math.abs(sin(phase.toDouble())).toFloat()
                animDy -= b * 24f
                animScaleX *= (1.06f - b * 0.10f)
                animScaleY *= (0.94f + b * 0.12f)
            }
            TextLoopAnimation.FLOAT -> {
                animDy += sin(phase.toDouble() * 0.6).toFloat() * 14f
                animRot += cos(phase.toDouble() * 0.45).toFloat() * 3.5f
            }
            TextLoopAnimation.SHAKE_HORROR -> {
                val rng = Random(frame * 97 + item.id.hashCode())
                animDx += (rng.nextFloat() - 0.5f) * 14f * spd
                animDy += (rng.nextFloat() - 0.5f) * 12f * spd
                animRot += (rng.nextFloat() - 0.5f) * 4.5f
            }
            TextLoopAnimation.PULSE -> {
                val p = 1f + 0.11f * sin(phase.toDouble() * 1.1).toFloat()
                animScaleX *= p
                animScaleY *= p
            }
            TextLoopAnimation.GLITCH -> {
                if ((frame % 9) in 0..2) {
                    val rng = Random(frame * 131)
                    animDx += (rng.nextFloat() - 0.5f) * 12f
                }
            }
            TextLoopAnimation.WAVE, TextLoopAnimation.RAINBOW, TextLoopAnimation.NONE -> Unit
        }

        // 3. Exit Animation
        if (outT > 0f) {
            when (outAnim) {
                TextOutAnimation.FADE_OUT -> animAlpha *= (1f - outT)
                TextOutAnimation.POP_OUT -> {
                    val sc = (1f - outT).coerceAtLeast(0.01f)
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.SLIDE_DOWN -> {
                    animDy += outT * outT * 110f
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.ZOOM_OUT -> {
                    val sc = 1f + outT * 1.3f
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.NONE -> Unit
            }
        }

        val alphaInt = (animAlpha * 255f).toInt().coerceIn(0, 255)
        if (alphaInt <= 2) return

        val tf = resolveTextTypeface(item.fontStyle, item.isBold)
        val textSizePx = item.fontSize.coerceIn(16f, 220f)
        val lines = visibleText.split("\n")

        val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textSizePx
            typeface = tf
        }
        val maxLineW = lines.maxOfOrNull { measurePaint.measureText(it) }?.coerceAtLeast(40f) ?: 80f
        val lineHeight = textSizePx * 1.18f
        val totalTextH = lines.size * lineHeight

        canvas.save()
        canvas.translate(item.x + animDx, item.y + animDy)
        canvas.rotate(item.rotationDeg + animRot)
        canvas.scale(animScaleX, animScaleY)

        // 4. Optional Box / Banner / Speech Bubble Backdrop
        val boxPadX = 28f
        val boxPadY = 18f
        val boxRect = RectF(
            -maxLineW / 2f - boxPadX,
            -totalTextH / 2f - boxPadY,
            maxLineW / 2f + boxPadX,
            totalTextH / 2f + boxPadY
        )
        when (boxStyle) {
            TextBoxStyle.COMIC_BANNER -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = item.boxColorArgb.toInt()
                    alpha = (alphaInt * 0.92f).toInt()
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                    color = item.colorArgb.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 14f, 14f, bg)
                canvas.drawRoundRect(boxRect, 14f, 14f, brd)
            }
            TextBoxStyle.YOUTUBE_PILL -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (item.boxColorArgb == 0xDD0F172AL) 0xEEEF4444.toInt() else item.boxColorArgb.toInt()
                    alpha = alphaInt
                }
                val radius = boxRect.height() * 0.5f
                canvas.drawRoundRect(boxRect, radius, radius, bg)
            }
            TextBoxStyle.SPEECH_BUBBLE -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFAFFFFFF.toInt()
                    alpha = alphaInt
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                    color = 0xFF0F172AL.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 26f, 26f, bg)
                canvas.drawRoundRect(boxRect, 26f, 26f, brd)
                val tail = Path().apply {
                    moveTo(-18f, boxRect.bottom - 2f)
                    lineTo(-34f, boxRect.bottom + 28f)
                    lineTo(10f, boxRect.bottom - 2f)
                    close()
                }
                canvas.drawPath(tail, bg)
                canvas.drawPath(tail, brd)
            }
            TextBoxStyle.HORROR_BLOOD -> {
                val slash = Path().apply {
                    moveTo(boxRect.left - 18f, boxRect.top + 8f)
                    lineTo(boxRect.right + 22f, boxRect.top - 6f)
                    lineTo(boxRect.right + 8f, boxRect.bottom + 6f)
                    lineTo(boxRect.left - 26f, boxRect.bottom - 4f)
                    close()
                }
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xE622050A.toInt()
                    alpha = alphaInt
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                    color = 0xFFEF4444.toInt()
                    alpha = alphaInt
                }
                canvas.drawPath(slash, bg)
                canvas.drawPath(slash, brd)
            }
            TextBoxStyle.OUTLINE_GLOW -> {
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 14f
                    color = item.colorArgb.toInt()
                    alpha = (alphaInt * 0.35f).toInt()
                }
                val crisp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 3.5f
                    color = item.colorArgb.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 18f, 18f, glow)
                canvas.drawRoundRect(boxRect, 18f, 18f, crisp)
            }
            TextBoxStyle.NONE -> Unit
        }

        // 5. Prepare Fill, Stroke, Shadow & Glow Paints
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textSizePx
            typeface = tf
            textAlign = Paint.Align.CENTER
            style = Paint.Style.FILL
            color = (tintColorArgb ?: item.colorArgb).toInt()
            alpha = alphaInt
        }

        if (tintColorArgb == null) {
            if (loopAnim == TextLoopAnimation.RAINBOW) {
                val shift = (frame * 6f * spd) % 360f
                val c1 = Color.HSVToColor(alphaInt, floatArrayOf(shift, 0.85f, 1f))
                val c2 = Color.HSVToColor(alphaInt, floatArrayOf((shift + 120f) % 360f, 0.85f, 1f))
                val c3 = Color.HSVToColor(alphaInt, floatArrayOf((shift + 240f) % 360f, 0.85f, 1f))
                fillPaint.shader = LinearGradient(
                    -maxLineW / 2f, 0f, maxLineW / 2f, 0f,
                    intArrayOf(c1, c2, c3), null, Shader.TileMode.CLAMP
                )
            } else if (item.gradientEndArgb != null) {
                fillPaint.shader = LinearGradient(
                    0f, -totalTextH / 2f, 0f, totalTextH / 2f,
                    item.colorArgb.toInt(), item.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                )
            }
        }

        val strokePaint = if (item.strokeWidth > 0.5f) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.STROKE
                strokeWidth = item.strokeWidth
                strokeJoin = Paint.Join.ROUND
                color = (tintColorArgb ?: item.strokeColorArgb).toInt()
                alpha = alphaInt
            }
        } else null

        val shadowPaint = if (item.shadowEnabled) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.FILL
                color = 0xAA000000.toInt()
                alpha = (alphaInt * 0.65f).toInt()
            }
        } else null

        val glowPaint = if (item.glowEnabled || boxStyle == TextBoxStyle.OUTLINE_GLOW) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.STROKE
                strokeWidth = item.strokeWidth + 14f
                strokeJoin = Paint.Join.ROUND
                color = (tintColorArgb ?: item.colorArgb).toInt()
                alpha = (alphaInt * 0.34f).toInt()
            }
        } else null

        val perCharMode = (loopAnim == TextLoopAnimation.WAVE) || (inAnim == TextInAnimation.DROP_LETTERS && inT < 1f)
        val startBaselineY = -totalTextH / 2f + textSizePx * 0.88f

        lines.forEachIndexed { lineIdx, line ->
            val baseY = startBaselineY + lineIdx * lineHeight

            // Cyber Glitch RGB chromatic ghosts
            if (loopAnim == TextLoopAnimation.GLITCH && (frame % 9) in 0..2 && tintColorArgb == null) {
                val cyanP = Paint(fillPaint).apply { shader = null; color = 0xAA22D3EE.toInt() }
                val pinkP = Paint(fillPaint).apply { shader = null; color = 0xAAFB7185.toInt() }
                canvas.drawText(line, -7f, baseY - 2f, cyanP)
                canvas.drawText(line, 7f, baseY + 2f, pinkP)
            }

            if (perCharMode) {
                val lineW = measurePaint.measureText(line)
                var curX = -lineW / 2f
                line.forEachIndexed { charIdx, ch ->
                    val chStr = ch.toString()
                    val chW = measurePaint.measureText(chStr)
                    val cx = curX + chW / 2f
                    var cy = baseY
                    var chAlpha = alphaInt

                    if (loopAnim == TextLoopAnimation.WAVE) {
                        cy += sin((phase + charIdx * 0.55f).toDouble()).toFloat() * (textSizePx * 0.22f)
                    }
                    if (inAnim == TextInAnimation.DROP_LETTERS && inT < 1f) {
                        val charDelay = charIdx.toFloat() / (line.length.coerceAtLeast(1) + 2).toFloat()
                        val ct = ((inT - charDelay * 0.55f) / 0.45f).coerceIn(0f, 1f)
                        val drop = (1f - ct) * (1f - ct) * 110f
                        cy -= drop
                        chAlpha = (alphaInt * ct).toInt().coerceIn(0, 255)
                    }

                    if (chAlpha > 2) {
                        shadowPaint?.let {
                            it.alpha = (chAlpha * 0.65f).toInt()
                            canvas.drawText(chStr, cx + 5f, cy + 6f, it)
                        }
                        glowPaint?.let {
                            it.alpha = (chAlpha * 0.34f).toInt()
                            canvas.drawText(chStr, cx, cy, it)
                        }
                        strokePaint?.let {
                            it.alpha = chAlpha
                            canvas.drawText(chStr, cx, cy, it)
                        }
                        fillPaint.alpha = chAlpha
                        canvas.drawText(chStr, cx, cy, fillPaint)
                    }
                    curX += chW
                }
            } else {
                shadowPaint?.let { canvas.drawText(line, 5f, baseY + 6f, it) }
                glowPaint?.let { canvas.drawText(line, 0f, baseY, it) }
                strokePaint?.let { canvas.drawText(line, 0f, baseY, it) }
                canvas.drawText(line, 0f, baseY, fillPaint)
            }
        }

        // 6. Editor Selection Frame (only when selected & not playing/exporting)
        if (isSelected) {
            val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 3f
                color = 0xFF2DD4BF.toInt()
                pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
            }
            val selRect = RectF(boxRect.left - 8f, boxRect.top - 8f, boxRect.right + 8f, boxRect.bottom + 8f)
            canvas.drawRoundRect(selRect, 12f, 12f, selPaint)
            val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt() }
            canvas.drawCircle(selRect.left, selRect.top, 7f, dotFill)
            canvas.drawCircle(selRect.right, selRect.top, 7f, dotFill)
            canvas.drawCircle(selRect.left, selRect.bottom, 7f, dotFill)
            canvas.drawCircle(selRect.right, selRect.bottom, 7f, dotFill)
        }

        canvas.restore()
    }

    /**
     * Modular Pre-Animated Eyes & Auto Lip-Sync Talking Mouths rendered at head coordinates.
     */
    fun drawModularFaceRig(
        canvas: Canvas,
        eyePackName: String,
        mouthPhonemeName: String,
        eyeColorArgb: Long,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        alphaInt: Int,
        tintColorArgb: Long?,
        isSideProfile: Boolean = false
    ) {
        val eyePack = runCatching { EyePackStyle.valueOf(eyePackName) }.getOrDefault(EyePackStyle.AUTO_BLINK)
        val requestedMouth = runCatching { MouthPhoneme.valueOf(mouthPhonemeName) }.getOrDefault(MouthPhoneme.AUTO_LIPSYNC)
        val activeMouth = if (requestedMouth == MouthPhoneme.AUTO_LIPSYNC) {
            InterpolationEngine.evaluateLipSyncPhoneme(audioTracks, frame, fps)
        } else requestedMouth

        fun fill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        // Periodic natural blink every ~2.4 seconds
        val blinkPeriod = (fps * 2.4f).toInt().coerceAtLeast(18)
        val blinkPhase = frame % blinkPeriod
        val isBlinkingNow = eyePack == EyePackStyle.AUTO_BLINK && (blinkPhase == 0 || blinkPhase == 1)

        val eyeY = -8f
        val eyeXs = if (isSideProfile) listOf(18f) else listOf(-18f, 18f)
        eyeXs.forEachIndexed { idx, ex ->
            when {
                isBlinkingNow || (eyePack == EyePackStyle.WINK && (isSideProfile || idx == 1)) -> {
                    canvas.drawArc(RectF(ex - 9f, eyeY - 4f, ex + 9f, eyeY + 8f), 195f, 150f, false, stroke)
                }
                eyePack == EyePackStyle.HAPPY -> {
                    canvas.drawArc(RectF(ex - 10f, eyeY - 7f, ex + 10f, eyeY + 9f), 200f, 140f, false, stroke)
                }
                else -> {
                    val pupilShiftX = if (isSideProfile) 3.5f else if (eyePack == EyePackStyle.SIDE_LOOK) 4.5f else 0f
                    val eyeR = if (eyePack == EyePackStyle.SURPRISED) 12.5f else 10.5f
                    val eyeRx = if (isSideProfile) eyeR * 0.78f else eyeR
                    canvas.drawOval(RectF(ex - eyeRx, eyeY - eyeR * 1.15f, ex + eyeRx, eyeY + eyeR * 1.15f), fill(0xFFFFFFFFL))
                    val irisR = if (eyePack == EyePackStyle.SURPRISED) 5.2f else 6.8f
                    canvas.drawCircle(ex + pupilShiftX, eyeY + 1f, irisR, fill(eyeColorArgb))
                    canvas.drawCircle(ex + pupilShiftX, eyeY + 1f, irisR * 0.55f, fill(0xFF0F172AL))
                    canvas.drawCircle(ex - 2.5f + pupilShiftX * 0.5f, eyeY - 3.5f, 2.6f, fill(0xFFFFFFFFL))
                    canvas.drawOval(RectF(ex - eyeRx, eyeY - eyeR * 1.15f, ex + eyeRx, eyeY + eyeR * 1.15f), stroke)

                    if (eyePack == EyePackStyle.SAD_TEARS) {
                        val dropOffset = ((frame * 6) % 24).toFloat()
                        canvas.drawOval(RectF(ex - 3.5f, eyeY + 11f + dropOffset, ex + 3.5f, eyeY + 21f + dropOffset), fill(0xFF38BDF8L))
                    }
                }
            }
            val browLift = if (eyePack == EyePackStyle.SURPRISED) -6f else 0f
            val tilt = when (eyePack) {
                EyePackStyle.ANGRY -> if (idx == 0 && !isSideProfile) 6f else -6f
                EyePackStyle.SAD_TEARS -> if (idx == 0 && !isSideProfile) -5f else 5f
                else -> 0f
            }
            canvas.drawLine(ex - 8f, eyeY - 17f + browLift - tilt, ex + 8f, eyeY - 17f + browLift + tilt, stroke)
        }

        // Talking Mouth Phoneme Shapes (shifted forward cleanly in side-profile!)
        val mouthX = if (isSideProfile) 24f else 0f
        val mouthScaleX = if (isSideProfile) 0.72f else 1f
        val mouthY = 18f
        val mouthFill = fill(0xFFBE123CL)
        val teethFill = fill(0xFFFFFFFFL)
        canvas.save()
        canvas.translate(mouthX, 0f)
        canvas.scale(mouthScaleX, 1f)
        when (activeMouth) {
            MouthPhoneme.REST -> {
                canvas.drawArc(RectF(-12f, mouthY - 5f, 12f, mouthY + 6f), 15f, 150f, false, stroke)
            }
            MouthPhoneme.SMILE -> {
                canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 12f), 0f, 180f, true, teethFill)
                canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 12f), 0f, 180f, true, stroke)
            }
            MouthPhoneme.A -> {
                canvas.drawOval(RectF(-14f, mouthY - 8f, 14f, mouthY + 14f), mouthFill)
                canvas.drawRect(RectF(-10f, mouthY - 7f, 10f, mouthY - 2f), teethFill)
                canvas.drawOval(RectF(-14f, mouthY - 8f, 14f, mouthY + 14f), stroke)
            }
            MouthPhoneme.E -> {
                canvas.drawRoundRect(RectF(-16f, mouthY - 5f, 16f, mouthY + 7f), 6f, 6f, mouthFill)
                canvas.drawLine(-13f, mouthY, 13f, mouthY, Paint(stroke).apply { color = Color.WHITE; strokeWidth = 3f })
                canvas.drawRoundRect(RectF(-16f, mouthY - 5f, 16f, mouthY + 7f), 6f, 6f, stroke)
            }
            MouthPhoneme.I -> {
                canvas.drawRoundRect(RectF(-14f, mouthY - 4f, 14f, mouthY + 4f), 4f, 4f, teethFill)
                canvas.drawRoundRect(RectF(-14f, mouthY - 4f, 14f, mouthY + 4f), 4f, 4f, stroke)
            }
            MouthPhoneme.O -> {
                canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), mouthFill)
                canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), stroke)
            }
            MouthPhoneme.U -> {
                canvas.drawCircle(0f, mouthY + 1f, 6.5f, mouthFill)
                canvas.drawCircle(0f, mouthY + 1f, 6.5f, stroke)
            }
            MouthPhoneme.SHOCK -> {
                canvas.drawOval(RectF(-12f, mouthY - 11f, 12f, mouthY + 15f), mouthFill)
                canvas.drawOval(RectF(-12f, mouthY - 11f, 12f, mouthY + 15f), stroke)
            }
            else -> {
                canvas.drawArc(RectF(-12f, mouthY - 5f, 12f, mouthY + 6f), 15f, 150f, false, stroke)
            }
        }
        canvas.restore()
    }

    fun drawCharacter(
        canvas: Canvas,
        c: CharacterSpec,
        layerAlpha: Float,
        tintColorArgb: Long?,
        frame: Int = 0,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList()
    ) {
        val alphaInt = (layerAlpha * 255).toInt().coerceIn(0, 255)
        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 4.5f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        canvas.save()
        canvas.translate(c.x, c.y)
        val viewAngle = runCatching { CharacterViewAngle.valueOf(c.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isBack = viewAngle == CharacterViewAngle.BACK
        val sideFlipX = if (viewAngle == CharacterViewAngle.SIDE_LEFT) -1f else 1f
        canvas.scale(c.scale * sideFlipX, c.scale)

        val legSpread = when (c.pose) {
            "WALK_A" -> 34f; "WALK_B" -> -34f; "JUMP" -> 42f; "HERO" -> 28f; else -> 18f
        }
        val bodyBob = when (c.pose) {
            "JUMP" -> -36f; "SIT" -> 28f; "WALK_A", "WALK_B" -> -6f; else -> 0f
        }
        canvas.translate(0f, bodyBob)

        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((alphaInt * 0.28f).toInt(), 0, 0, 0)
        }
        canvas.drawOval(RectF(-58f, 152f - bodyBob, 58f, 174f - bodyBob), shadowPaint)

        val pantsPaint = pFill(c.pantsColorArgb)
        val shirtPaint = pFill(c.shirtColorArgb)
        val skinPaint = pFill(c.skinToneArgb)
        val leftArmAngle = when (c.pose) { "JUMP" -> -140f; "HERO" -> -25f; "WALK_A" -> 28f; "WALK_B" -> -28f; else -> 18f }
        val rightArmAngle = when (c.pose) { "WAVE" -> -135f; "JUMP" -> 140f; "HERO" -> 25f; "WALK_A" -> -28f; "WALK_B" -> 28f; else -> -18f }

        if (c.shirtStyle == "CAPE" && !isBack) {
            val capePath = if (isSide) {
                Path().apply { moveTo(-24f, -4f); lineTo(4f, -4f); lineTo(-14f, 118f); lineTo(-58f, 118f); close() }
            } else {
                Path().apply { moveTo(-36f, -6f); lineTo(36f, -6f); lineTo(66f, 118f); lineTo(-66f, 118f); close() }
            }
            canvas.drawPath(capePath, shirtPaint); canvas.drawPath(capePath, outline)
        }

        if (isSide) {
            // Far arm behind torso
            canvas.save()
            canvas.translate(8f, 6f); canvas.rotate(-leftArmAngle)
            canvas.drawRoundRect(RectF(-10f, 0f, 10f, 66f), 10f, 10f, shirtPaint)
            canvas.drawRoundRect(RectF(-10f, 0f, 10f, 66f), 10f, 10f, outline)
            canvas.drawCircle(0f, 68f, 10f, skinPaint); canvas.drawCircle(0f, 68f, 10f, outline)
            canvas.restore()

            // Side-profile legs (front/back stride)
            val legFar = RectF(-14f - legSpread * 0.45f, 68f, 10f - legSpread * 0.25f, if (c.pose == "SIT") 124f else 156f)
            val legNear = RectF(-8f + legSpread * 0.25f, 68f, 16f + legSpread * 0.45f, if (c.pose == "SIT") 124f else 156f)
            canvas.drawRoundRect(legFar, 12f, 12f, pantsPaint); canvas.drawRoundRect(legFar, 12f, 12f, outline)
            canvas.drawRoundRect(legNear, 12f, 12f, pantsPaint); canvas.drawRoundRect(legNear, 12f, 12f, outline)

            // Side-profile slim torso
            val torso = RectF(-28f, -14f, 28f, 82f)
            canvas.drawRoundRect(torso, 22f, 22f, shirtPaint); canvas.drawRoundRect(torso, 22f, 22f, outline)

            // Near arm in front of torso
            canvas.save()
            canvas.translate(-4f, 6f); canvas.rotate(rightArmAngle)
            canvas.drawRoundRect(RectF(-11f, 0f, 11f, 68f), 10f, 10f, shirtPaint)
            canvas.drawRoundRect(RectF(-11f, 0f, 11f, 68f), 10f, 10f, outline)
            canvas.drawCircle(0f, 70f, 10.5f, skinPaint); canvas.drawCircle(0f, 70f, 10.5f, outline)
            canvas.restore()
        } else {
            val legL = RectF(-30f - legSpread * 0.4f, 68f, -6f - legSpread * 0.2f, if (c.pose == "SIT") 124f else 156f)
            val legR = RectF(6f + legSpread * 0.2f, 68f, 30f + legSpread * 0.4f, if (c.pose == "SIT") 124f else 156f)
            canvas.drawRoundRect(legL, 12f, 12f, pantsPaint); canvas.drawRoundRect(legL, 12f, 12f, outline)
            canvas.drawRoundRect(legR, 12f, 12f, pantsPaint); canvas.drawRoundRect(legR, 12f, 12f, outline)

            val torso = RectF(-42f, -14f, 42f, 82f)
            canvas.drawRoundRect(torso, 24f, 24f, shirtPaint); canvas.drawRoundRect(torso, 24f, 24f, outline)

            listOf(Triple(-40f, leftArmAngle, 1f), Triple(40f, rightArmAngle, 1f)).forEach { (ax, ang, _) ->
                canvas.save()
                canvas.translate(ax, 4f); canvas.rotate(ang)
                canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, shirtPaint)
                canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, outline)
                canvas.drawCircle(0f, 70f, 11f, skinPaint); canvas.drawCircle(0f, 70f, 11f, outline)
                canvas.restore()
            }

            if (isBack && c.shirtStyle == "CAPE") {
                val capePath = Path().apply {
                    moveTo(-38f, -8f); lineTo(38f, -8f); lineTo(62f, 124f); lineTo(-62f, 124f); close()
                }
                canvas.drawPath(capePath, shirtPaint); canvas.drawPath(capePath, outline)
            }
            if (isBack && c.shirtStyle == "HOODIE") {
                // Draw back hood collar detail!
                canvas.drawArc(RectF(-30f, -20f, 30f, 28f), 0f, 180f, true, shirtPaint)
                canvas.drawArc(RectF(-30f, -20f, 30f, 28f), 0f, 180f, true, outline)
            }
        }

        // Head + Hair + Modular Face (Front / Side Profile / Back View)
        canvas.save()
        canvas.translate(0f, -66f)
        drawHeadSculpt(canvas, c, skinPaint, pFill(c.hairColorArgb), outline, alphaInt, tintColorArgb, frame, fps, audioTracks, viewAngle)
        canvas.restore()

        canvas.restore()
    }

    private fun drawHeadSculpt(
        canvas: Canvas,
        c: CharacterSpec,
        skinPaint: Paint,
        hairPaint: Paint,
        outline: Paint,
        alphaInt: Int,
        tintColorArgb: Long?,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT
    ) {
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isBack = viewAngle == CharacterViewAngle.BACK

        val headRect = when {
            isSide -> RectF(-42f, -56f, 44f, 52f)
            c.faceShape == "ROUND" -> RectF(-54f, -56f, 54f, 52f)
            c.faceShape == "SQUARE" -> RectF(-50f, -56f, 50f, 52f)
            c.faceShape == "CHIBI" -> RectF(-60f, -62f, 60f, 54f)
            else -> RectF(-48f, -58f, 48f, 52f)
        }
        val r = if (c.faceShape == "SQUARE") 20f else 50f

        if (isSide) {
            // Side-profile nose silhouette + head contour
            val nosePath = Path().apply {
                moveTo(38f, -10f)
                lineTo(54f, 4f)
                lineTo(40f, 12f)
                close()
            }
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawPath(nosePath, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
            canvas.drawPath(nosePath, outline)
            // Side ear
            canvas.drawOval(RectF(-16f, -6f, 0f, 16f), skinPaint)
            canvas.drawOval(RectF(-16f, -6f, 0f, 16f), outline)
        } else {
            // Ears visible cleanly in Front and Back views
            canvas.drawCircle(-49f, 2f, 11f, skinPaint); canvas.drawCircle(-49f, 2f, 11f, outline)
            canvas.drawCircle(49f, 2f, 11f, skinPaint); canvas.drawCircle(49f, 2f, 11f, outline)
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
        }

        if (isBack) {
            // Back-of-head full hair silhouette (no eyes/mouth!)
            val backHairRect = RectF(headRect.left - 5f, headRect.top - 8f, headRect.right + 5f, headRect.bottom - 4f)
            canvas.drawRoundRect(backHairRect, 48f, 48f, hairPaint)
            canvas.drawRoundRect(backHairRect, 48f, 48f, outline)
            when (c.hairStyle) {
                "SPIKY" -> {
                    val spikes = Path().apply {
                        moveTo(-54f, -14f); lineTo(-66f, -58f); lineTo(-34f, -52f)
                        lineTo(-20f, -86f); lineTo(0f, -62f); lineTo(22f, -84f)
                        lineTo(36f, -52f); lineTo(66f, -58f); lineTo(54f, -14f); close()
                    }
                    canvas.drawPath(spikes, hairPaint); canvas.drawPath(spikes, outline)
                }
                "PONYTAIL" -> {
                    canvas.drawOval(RectF(-22f, -12f, 22f, 66f), hairPaint)
                    canvas.drawOval(RectF(-22f, -12f, 22f, 66f), outline)
                }
                "CURLY" -> {
                    for (i in -2..2) {
                        canvas.drawCircle(i * 22f, -54f + kotlin.math.abs(i) * 6f, 22f, hairPaint)
                        canvas.drawCircle(i * 22f, -54f + kotlin.math.abs(i) * 6f, 22f, outline)
                    }
                }
                "MOHAWK" -> {
                    val mohawk = Path().apply {
                        moveTo(-16f, -52f); lineTo(-22f, -94f); lineTo(0f, -82f); lineTo(22f, -94f); lineTo(16f, -52f); close()
                    }
                    canvas.drawPath(mohawk, hairPaint); canvas.drawPath(mohawk, outline)
                }
            }
        } else {
            when (c.hairStyle) {
                "SPIKY" -> {
                    val spikes = if (isSide) {
                        Path().apply {
                            moveTo(-44f, 14f); lineTo(-58f, -18f); lineTo(-46f, -44f)
                            lineTo(-34f, -74f); lineTo(-8f, -62f); lineTo(18f, -80f)
                            lineTo(38f, -48f); lineTo(48f, -24f)
                            quadTo(4f, -38f, -18f, 16f); close()
                        }
                    } else {
                        Path().apply {
                            moveTo(-52f, -18f); lineTo(-62f, -58f); lineTo(-32f, -50f)
                            lineTo(-20f, -84f); lineTo(0f, -60f); lineTo(22f, -82f)
                            lineTo(34f, -50f); lineTo(62f, -56f); lineTo(52f, -18f)
                            quadTo(0f, -42f, -52f, -18f); close()
                        }
                    }
                    canvas.drawPath(spikes, hairPaint); canvas.drawPath(spikes, outline)
                }
                "BOB" -> {
                    if (isSide) {
                        canvas.drawArc(RectF(-50f, -68f, 48f, 40f), 140f, 220f, true, hairPaint)
                        canvas.drawRoundRect(RectF(-50f, -26f, -12f, 46f), 14f, 14f, hairPaint)
                        canvas.drawArc(RectF(-50f, -68f, 48f, 40f), 140f, 220f, false, outline)
                    } else {
                        canvas.drawArc(RectF(-58f, -70f, 58f, 40f), 180f, 180f, true, hairPaint)
                        canvas.drawRoundRect(RectF(-58f, -24f, -40f, 42f), 12f, 12f, hairPaint)
                        canvas.drawRoundRect(RectF(40f, -24f, 58f, 42f), 12f, 12f, hairPaint)
                        canvas.drawArc(RectF(-58f, -70f, 58f, 40f), 180f, 180f, false, outline)
                    }
                }
                "PONYTAIL" -> {
                    val ponyRect = if (isSide) RectF(-78f, -44f, -32f, 18f) else RectF(36f, -54f, 82f, 6f)
                    canvas.drawOval(ponyRect, hairPaint); canvas.drawOval(ponyRect, outline)
                    canvas.drawArc(RectF(-52f, -68f, 50f, 20f), 180f, 180f, true, hairPaint)
                    canvas.drawArc(RectF(-52f, -68f, 50f, 20f), 180f, 180f, false, outline)
                }
                "CURLY" -> {
                    for (i in -2..2) {
                        canvas.drawCircle(i * (if (isSide) 17f else 22f), -56f + kotlin.math.abs(i) * 6f, 21f, hairPaint)
                        canvas.drawCircle(i * (if (isSide) 17f else 22f), -56f + kotlin.math.abs(i) * 6f, 21f, outline)
                    }
                }
                "MOHAWK" -> {
                    val mohawk = Path().apply {
                        moveTo(-16f, -52f); lineTo(-24f, -94f); lineTo(0f, -82f); lineTo(24f, -94f); lineTo(16f, -52f); close()
                    }
                    canvas.drawPath(mohawk, hairPaint); canvas.drawPath(mohawk, outline)
                }
            }

            drawModularFaceRig(
                canvas = canvas,
                eyePackName = c.eyePack,
                mouthPhonemeName = c.mouthPhoneme,
                eyeColorArgb = c.eyeColorArgb,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                alphaInt = alphaInt,
                tintColorArgb = tintColorArgb,
                isSideProfile = isSide
            )
        }

        // Accessories (adapt cleanly across Front, Side, and Back views)
        fun pAcc(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL; color = (tintColorArgb ?: argb).toInt(); alpha = alphaInt
        }
        when (c.accessory) {
            "GLASSES" -> if (!isBack) {
                val f = Paint(outline).apply { strokeWidth = 3.8f }
                if (isSide) {
                    canvas.drawRoundRect(RectF(8f, -22f, 34f, 6f), 6f, 6f, f)
                    canvas.drawLine(-8f, -8f, 8f, -8f, f)
                } else {
                    canvas.drawRoundRect(RectF(-34f, -22f, -4f, 6f), 6f, 6f, f)
                    canvas.drawRoundRect(RectF(4f, -22f, 34f, 6f), 6f, 6f, f)
                    canvas.drawLine(-4f, -8f, 4f, -8f, f)
                }
            }
            "HEADPHONES" -> {
                canvas.drawArc(RectF(-56f, -72f, 56f, 22f), 180f, 180f, false, Paint(outline).apply {
                    color = (tintColorArgb ?: 0xFF2DD4BFL).toInt(); strokeWidth = 8f
                })
                if (isSide) {
                    canvas.drawRoundRect(RectF(-20f, -18f, 6f, 20f), 10f, 10f, pAcc(0xFF2DD4BFL))
                } else {
                    canvas.drawRoundRect(RectF(-68f, -22f, -50f, 14f), 8f, 8f, pAcc(0xFF2DD4BFL))
                    canvas.drawRoundRect(RectF(50f, -22f, 68f, 14f), 8f, 8f, pAcc(0xFF2DD4BFL))
                }
            }
            "CROWN" -> {
                val crown = Path().apply {
                    moveTo(-26f, -58f); lineTo(-30f, -90f); lineTo(-10f, -74f)
                    lineTo(0f, -98f); lineTo(10f, -74f); lineTo(30f, -90f); lineTo(26f, -58f); close()
                }
                canvas.drawPath(crown, pAcc(0xFFFBBF24L)); canvas.drawPath(crown, outline)
            }
            "HAT" -> {
                canvas.drawRoundRect(RectF(-58f, -58f, 58f, -44f), 6f, 6f, pAcc(0xFF334155L))
                canvas.drawRoundRect(RectF(-36f, -94f, 36f, -54f), 14f, 14f, pAcc(0xFF334155L))
                canvas.drawRoundRect(RectF(-58f, -58f, 58f, -44f), 6f, 6f, outline)
            }
        }
    }

    /**
     * Renders a complete Skeletal Rig Puppet with:
     * 1) 4-View Turnaround support (Front, Left Side, Right Side, Back),
     * 2) Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh) if singleMeshImagePath is set,
     * 3) Segmented Bone-to-Image PNG Part Binding (boundImagePath per bone),
     * 4) Bound Procedural Cartoon Character 14-bone limbs, hands, feet & head with Modular Eyes & Auto Lip-Sync,
     * 5) Built-in Hand Props & Custom PNG attachments bound directly to Left & Right Hands,
     * 6) Color-coded Toontastic/TweenCraft IK Limb Handles + Central Root Move Handle.
     */
    fun drawSkeletalRig(
        canvas: Canvas,
        rig: SkeletalRig,
        puppetRoot: EvaluatedPuppetRoot,
        angles: Map<String, Float>,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        alpha: Float,
        tintColorArgb: Long?,
        showOverlay: Boolean,
        isSelectedPuppet: Boolean,
        selectedBoneId: String?
    ) {
        val viewAngle = runCatching { CharacterViewAngle.valueOf(puppetRoot.viewAngle) }
            .getOrDefault(CharacterViewAngle.FRONT)
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isBack = viewAngle == CharacterViewAngle.BACK
        // Combine explicit flip toggle with SIDE_LEFT facing direction cleanly
        val effectiveFlipped = if (viewAngle == CharacterViewAngle.SIDE_LEFT) {
            !puppetRoot.flippedHorizontal
        } else {
            puppetRoot.flippedHorizontal
        }

        val solved = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = angles,
            rootX = puppetRoot.rootX,
            rootY = puppetRoot.rootY,
            scale = puppetRoot.scale,
            flippedHorizontal = effectiveFlipped
        )
        val alphaInt = (alpha * 255).toInt().coerceIn(0, 255)
        val scale = puppetRoot.scale

        val meshBmp = rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        val hasSingleMesh = meshBmp != null
        val hasBoundParts = rig.bones.any { !it.boundImagePath.isNullOrBlank() && getCachedBitmap(it.boundImagePath) != null }
        val hasCharacterSpec = rig.characterAppearance != null
        val hasAssignedArtwork = hasSingleMesh || hasBoundParts || hasCharacterSpec

        // Spectral Ghost Aura when a puppet layer with assigned artwork is lightly transparent (Ghost Mode)
        if (hasAssignedArtwork && tintColorArgb == null && alpha in 0.12f..0.84f) {
            val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    puppetRoot.rootX,
                    puppetRoot.rootY - 40f * scale,
                    155f * scale,
                    0x557DD3FC,
                    0x007DD3FC,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY - 40f * scale, 155f * scale, auraPaint)
        }

        // A. Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh)
        if (meshBmp != null) {
            val restSolved = RigSolver.solveForwardKinematics(
                rig = rig,
                angleOverrides = emptyMap(),
                rootX = puppetRoot.rootX,
                rootY = puppetRoot.rootY,
                scale = scale,
                flippedHorizontal = effectiveFlipped
            )
            val halfW = (rig.singleMeshWidth * scale) / 2f
            val halfH = (rig.singleMeshHeight * scale) / 2f
            val meshRect = RectF(
                puppetRoot.rootX - halfW,
                puppetRoot.rootY - halfH * 1.15f,
                puppetRoot.rootX + halfW,
                puppetRoot.rootY + halfH * 0.85f
            )
            val verts = RigSolver.computeDeformedMeshVertices(restSolved, solved, meshRect, 8, 8)
            val meshPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                this.alpha = alphaInt
                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
            }
            canvas.drawBitmapMesh(meshBmp, 8, 8, verts, 0, null, 0, meshPaint)
        }

        // B. Depth-ordered limbs/torso for Front, Side Profile, and Back turnaround views
        val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.8f * scale
            strokeCap = Paint.Cap.ROUND
            this.alpha = alphaInt
        }

        fun boneDepthOrder(boneId: String): Int {
            return when {
                isSide -> when {
                    boneId.contains("_l") -> 0 // Far arm/leg behind torso
                    boneId == "spine" -> 1
                    boneId == "neck" -> 2
                    else -> 3 // Near arm/leg in front of torso
                }
                isBack -> when {
                    boneId.startsWith("leg") || boneId.startsWith("foot") -> 0
                    boneId.startsWith("arm") || boneId.startsWith("hand") -> 1
                    boneId == "spine" -> 2
                    else -> 3
                }
                else -> when {
                    boneId.startsWith("leg") || boneId.startsWith("foot") -> 0
                    boneId == "spine" -> 1
                    boneId == "neck" -> 2
                    else -> 3
                }
            }
        }

        val orderedSolved = solved.sortedBy { boneDepthOrder(it.bone.id) }
        val leftHandBone = solved.firstOrNull { it.bone.id == "hand_l" }
            ?: solved.firstOrNull { it.bone.id == "arm_l_low" }
        val rightHandBone = solved.firstOrNull { it.bone.id == "hand_r" }
            ?: solved.firstOrNull { it.bone.id == "arm_r_low" }

        // Draw far-side hand prop behind torso when in side profile
        if (isSide && leftHandBone != null) {
            drawHandProp(
                canvas = canvas,
                handBone = leftHandBone,
                propKindName = rig.leftHandProp,
                customImagePath = rig.leftHandCustomImagePath,
                propScale = rig.handPropScale * scale,
                flipped = effectiveFlipped,
                alphaInt = alphaInt,
                tintColorArgb = tintColorArgb,
                frame = frame
            )
        }

        if (rig.showSkinMesh) {
            orderedSolved.forEach { sb ->
                val partPath = sb.bone.boundImagePath
                if (!partPath.isNullOrBlank()) {
                    val partBmp = getCachedBitmap(partPath)
                    if (partBmp != null) {
                        val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                            this.alpha = alphaInt
                            if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                        }
                        val boneLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y)
                        val drawH = (boneLen * 1.25f * sb.bone.imageScale).coerceAtLeast(32f)
                        val aspect = partBmp.width.toFloat() / partBmp.height.coerceAtLeast(1).toFloat()
                        val drawW = (drawH * aspect).coerceAtLeast(28f)
                        val rotDeg = Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat()

                        canvas.save()
                        canvas.translate(sb.start.x, sb.start.y)
                        canvas.rotate(rotDeg - 90f + sb.bone.imageRotationOffsetDeg)
                        if (effectiveFlipped) canvas.scale(-1f, 1f)
                        val dst = RectF(
                            -drawW / 2f + sb.bone.pivotOffsetX * scale,
                            -drawH * 0.12f + sb.bone.pivotOffsetY * scale,
                            drawW / 2f + sb.bone.pivotOffsetX * scale,
                            drawH * 0.88f + sb.bone.pivotOffsetY * scale
                        )
                        canvas.drawBitmap(partBmp, null, dst, imgPaint)
                        canvas.restore()
                    }
                } else if (!hasSingleMesh && hasCharacterSpec) {
                    val isHead = sb.bone.id == "neck" || sb.bone.name.contains("Head", ignoreCase = true)
                    if (!isHead) {
                        val isFarSideLimb = isSide && sb.bone.id.contains("_l")
                        val thicknessFactor = if (isSide && sb.bone.id == "spine") 0.78f else 1f
                        val effectiveThickness = sb.bone.thickness * thicknessFactor
                        val baseFillColor = if (isFarSideLimb && tintColorArgb == null) {
                            darkenArgb(sb.bone.colorArgb, 0.82f)
                        } else {
                            (tintColorArgb ?: sb.bone.colorArgb).toInt()
                        }

                        val limbOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
                            strokeWidth = (effectiveThickness + 6f) * scale
                            strokeCap = Paint.Cap.ROUND
                            style = Paint.Style.STROKE
                            this.alpha = alphaInt
                        }
                        val limbFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = baseFillColor
                            strokeWidth = effectiveThickness * scale
                            strokeCap = Paint.Cap.ROUND
                            style = Paint.Style.STROKE
                            this.alpha = alphaInt
                        }
                        canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbOutline)
                        canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbFill)

                        // Back view hoodie hood detail on spine
                        if (isBack && sb.bone.id == "spine" && rig.characterAppearance?.shirtStyle == "HOODIE") {
                            val hoodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                style = Paint.Style.FILL
                                color = baseFillColor
                                this.alpha = alphaInt
                            }
                            canvas.drawCircle(sb.end.x, sb.end.y + 8f * scale, 22f * scale, hoodPaint)
                            canvas.drawCircle(sb.end.x, sb.end.y + 8f * scale, 22f * scale, outlinePaint)
                        }

                        // Rounded hand palm cap for hand_l / hand_r
                        if (sb.bone.id.startsWith("hand_")) {
                            val handFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                style = Paint.Style.FILL
                                color = baseFillColor
                                this.alpha = alphaInt
                            }
                            canvas.drawCircle(sb.end.x, sb.end.y, 11f * scale, handFill)
                            canvas.drawCircle(sb.end.x, sb.end.y, 11f * scale, outlinePaint)
                        }
                    }
                }
            }
        }

        // C. Head Sculpt + Modular Pre-Animated Eyes & Auto Lip-Sync Talking Mouth snapped to Head bone!
        val headBone = solved.firstOrNull { it.bone.id == "neck" || it.bone.name.contains("Head", ignoreCase = true) }
        if (headBone != null) {
            val headAngle = Math.toDegrees(
                atan2((headBone.end.y - headBone.start.y).toDouble(), (headBone.end.x - headBone.start.x).toDouble())
            ).toFloat() + 90f
            val headCenterX = (headBone.start.x + headBone.end.x * 2f) / 3f
            val headCenterY = (headBone.start.y + headBone.end.y * 2f) / 3f

            canvas.save()
            canvas.translate(headCenterX, headCenterY)
            canvas.rotate(headAngle)
            canvas.scale(if (effectiveFlipped) -scale else scale, scale)

            val spec = rig.characterAppearance?.copy(
                eyePack = puppetRoot.eyePack,
                mouthPhoneme = puppetRoot.mouthPhoneme,
                viewAngle = viewAngle.name
            )
            if (spec != null && headBone.bone.boundImagePath.isNullOrBlank() && !hasSingleMesh) {
                val skinP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: spec.skinToneArgb).toInt(); this.alpha = alphaInt }
                val hairP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: spec.hairColorArgb).toInt(); this.alpha = alphaInt }
                drawHeadSculpt(canvas, spec, skinP, hairP, outlinePaint, alphaInt, tintColorArgb, frame, fps, audioTracks, viewAngle)
            } else if (hasAssignedArtwork && rig.showFaceOverlayOnCustomImage && !isBack) {
                // Only draw modular face overlay on custom PNGs if explicitly enabled
                drawModularFaceRig(
                    canvas = canvas,
                    eyePackName = puppetRoot.eyePack,
                    mouthPhonemeName = puppetRoot.mouthPhoneme,
                    eyeColorArgb = rig.characterAppearance?.eyeColorArgb ?: 0xFF2DD4BFL,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    alphaInt = alphaInt,
                    tintColorArgb = tintColorArgb,
                    isSideProfile = isSide
                )
            }
            canvas.restore()
        }

        // C2. Hand-Held Props & Custom PNG Attachments (follow Left & Right Hands in real time!)
        if (!isSide && leftHandBone != null) {
            drawHandProp(
                canvas = canvas,
                handBone = leftHandBone,
                propKindName = rig.leftHandProp,
                customImagePath = rig.leftHandCustomImagePath,
                propScale = rig.handPropScale * scale,
                flipped = effectiveFlipped,
                alphaInt = alphaInt,
                tintColorArgb = tintColorArgb,
                frame = frame
            )
        }
        if (rightHandBone != null) {
            drawHandProp(
                canvas = canvas,
                handBone = rightHandBone,
                propKindName = rig.rightHandProp,
                customImagePath = rig.rightHandCustomImagePath,
                propScale = rig.handPropScale * scale,
                flipped = effectiveFlipped,
                alphaInt = alphaInt,
                tintColorArgb = tintColorArgb,
                frame = frame
            )
        }

        // D. Skeleton Wireframe & Color-Coded Toontastic/TweenCraft IK Handles (also drawn in Onion-Skin tint!)
        if (showOverlay) {
            solved.forEach { sb ->
                val isSelectedBone = sb.bone.id == selectedBoneId && tintColorArgb == null
                val isEndEffector = sb.bone.id.startsWith("hand_") || sb.bone.id.startsWith("foot_") || sb.bone.id == "neck"
                val limbAccent = when {
                    tintColorArgb != null -> tintColorArgb.toInt()
                    isSelectedBone -> 0xFFFF6B35.toInt()
                    sb.bone.id.startsWith("hand_") -> 0xFF06B6D4.toInt() // Bright Cyan for Hands IK
                    sb.bone.id.startsWith("arm") -> 0xFF2DD4BF.toInt()   // Teal for Arms
                    sb.bone.id.startsWith("foot_") -> 0xFFC084FC.toInt() // Bright Violet for Feet IK
                    sb.bone.id.startsWith("leg") -> 0xFFA78BFA.toInt()   // Violet for Legs
                    else -> 0xFFFBBF24.toInt()                            // Amber for Spine/Head
                }

                val bonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = limbAccent
                    style = Paint.Style.STROKE
                    strokeWidth = if (isSelectedBone) 4f else 2.4f
                    this.alpha = if (tintColorArgb != null) (alphaInt * 1.4f).toInt().coerceAtMost(180) else 235
                }
                val dx = sb.end.x - sb.start.x
                val dy = sb.end.y - sb.start.y
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val ux = dx / len; val uy = dy / len
                val px = -uy; val py = ux
                val midX = sb.start.x + dx * 0.22f
                val midY = sb.start.y + dy * 0.22f
                val w = (len * 0.11f).coerceIn(3.5f, 10.5f)

                val bonePath = Path().apply {
                    moveTo(sb.start.x, sb.start.y)
                    lineTo(midX + px * w, midY + py * w)
                    lineTo(sb.end.x, sb.end.y)
                    lineTo(midX - px * w, midY - py * w)
                    close()
                }
                canvas.drawPath(bonePath, bonePaint)

                if (tintColorArgb == null && isSelectedPuppet) {
                    val handleRadius = when {
                        isSelectedBone -> 13f
                        isEndEffector -> 11.5f
                        else -> 8.2f
                    }
                    val jointFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                    }
                    val ringStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.WHITE
                        style = Paint.Style.STROKE
                        strokeWidth = if (isEndEffector) 2.8f else 2f
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, handleRadius, jointFill)
                    canvas.drawCircle(sb.end.x, sb.end.y, handleRadius, ringStroke)
                } else {
                    val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                        this.alpha = if (tintColorArgb != null) (alphaInt * 1.5f).toInt().coerceAtMost(190) else 220
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, 5.5f, dot)
                }
            }

            // Central Root / Hip Move Handle (Toontastic / TweenCraft style 1-finger drag ring)
            if (tintColorArgb == null && isSelectedPuppet) {
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0x55FF6B35
                    style = Paint.Style.FILL
                }
                val rootFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFFFF6B35.toInt()
                    style = Paint.Style.FILL
                }
                val rootRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.STROKE
                    strokeWidth = 3f
                }
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 24f, glow)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 15f, rootFill)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, 15f, rootRing)
                canvas.drawLine(puppetRoot.rootX - 7f, puppetRoot.rootY, puppetRoot.rootX + 7f, puppetRoot.rootY, rootRing)
                canvas.drawLine(puppetRoot.rootX, puppetRoot.rootY - 7f, puppetRoot.rootX, puppetRoot.rootY + 7f, rootRing)
            }
        }
    }

    private fun darkenArgb(argb: Long, factor: Float): Int {
        val c = argb.toInt()
        val r = (Color.red(c) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(c) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(c) * factor).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(c), r, g, b)
    }

    /**
     * Renders any built-in Hand Prop or Custom Imported PNG attached directly to a character's Left or Right Hand bone!
     */
    private fun drawHandProp(
        canvas: Canvas,
        handBone: SolvedBone,
        propKindName: String,
        customImagePath: String?,
        propScale: Float,
        flipped: Boolean,
        alphaInt: Int,
        tintColorArgb: Long?,
        frame: Int
    ) {
        val propKind = runCatching { HandPropKind.valueOf(propKindName) }.getOrDefault(HandPropKind.NONE)
        if (propKind == HandPropKind.NONE && customImagePath.isNullOrBlank()) return

        val boneAngleDeg = Math.toDegrees(
            atan2((handBone.end.y - handBone.start.y).toDouble(), (handBone.end.x - handBone.start.x).toDouble())
        ).toFloat()

        canvas.save()
        canvas.translate(handBone.end.x, handBone.end.y)
        canvas.rotate(boneAngleDeg + 90f)
        canvas.scale(if (flipped) -propScale else propScale, propScale)

        // Custom imported PNG takes priority when attached
        if (!customImagePath.isNullOrBlank()) {
            val bmp = getCachedBitmap(customImagePath)
            if (bmp != null) {
                val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = alphaInt
                    if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                }
                val maxDim = 92f
                val aspect = bmp.width.toFloat() / bmp.height.coerceAtLeast(1).toFloat()
                val drawW = if (aspect >= 1f) maxDim else maxDim * aspect
                val drawH = if (aspect >= 1f) maxDim / aspect else maxDim
                canvas.drawBitmap(bmp, null, RectF(-drawW / 2f, -drawH * 0.85f, drawW / 2f, drawH * 0.15f), imgPaint)
            }
            canvas.restore()
            return
        }

        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (propKind) {
            HandPropKind.SWORD -> {
                val blade = Path().apply {
                    moveTo(-7f, -12f); lineTo(-6f, -94f); lineTo(0f, -112f); lineTo(6f, -94f); lineTo(7f, -12f); close()
                }
                canvas.drawPath(blade, pFill(0xFFE2E8F0L)); canvas.drawPath(blade, outline)
                canvas.drawLine(0f, -14f, 0f, -96f, Paint(outline).apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f })
                canvas.drawRoundRect(RectF(-18f, -16f, 18f, -7f), 4f, 4f, pFill(0xFFFBBF24L))
                canvas.drawRoundRect(RectF(-18f, -16f, 18f, -7f), 4f, 4f, outline)
                canvas.drawRoundRect(RectF(-5f, -7f, 5f, 16f), 4f, 4f, pFill(0xFF78350FL))
                canvas.drawRoundRect(RectF(-5f, -7f, 5f, 16f), 4f, 4f, outline)
            }
            HandPropKind.MIC -> {
                canvas.drawRoundRect(RectF(-5f, -34f, 5f, 14f), 4f, 4f, pFill(0xFF1E293BL))
                canvas.drawRoundRect(RectF(-5f, -34f, 5f, 14f), 4f, 4f, outline)
                canvas.drawCircle(0f, -44f, 14f, pFill(0xFF94A3B8L))
                canvas.drawCircle(0f, -44f, 14f, outline)
                canvas.drawLine(-13f, -44f, 13f, -44f, Paint(outline).apply { strokeWidth = 2.5f })
                canvas.drawCircle(0f, -16f, 3f, pFill(0xFFEF4444L))
            }
            HandPropKind.FLASHLIGHT -> {
                if (tintColorArgb == null) {
                    val beam = Path().apply {
                        moveTo(-10f, -42f); lineTo(10f, -42f); lineTo(58f, -210f); lineTo(-58f, -210f); close()
                    }
                    val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = LinearGradient(0f, -42f, 0f, -210f, 0x88FEF08A.toInt(), 0x00FEF08A, Shader.TileMode.CLAMP)
                    }
                    canvas.drawPath(beam, beamPaint)
                }
                canvas.drawRoundRect(RectF(-7f, -32f, 7f, 16f), 5f, 5f, pFill(0xFF334155L))
                canvas.drawRoundRect(RectF(-7f, -32f, 7f, 16f), 5f, 5f, outline)
                canvas.drawRoundRect(RectF(-12f, -44f, 12f, -30f), 4f, 4f, pFill(0xFFFBBF24L))
                canvas.drawRoundRect(RectF(-12f, -44f, 12f, -30f), 4f, 4f, outline)
            }
            HandPropKind.MAGIC_WAND -> {
                canvas.drawRoundRect(RectF(-4f, -72f, 4f, 14f), 3f, 3f, pFill(0xFF7C3AEDL))
                canvas.drawRoundRect(RectF(-4f, -72f, 4f, 14f), 3f, 3f, outline)
                val pulse = 1f + 0.14f * sin(frame * 0.35).toFloat()
                canvas.save()
                canvas.translate(0f, -78f); canvas.scale(pulse, pulse)
                if (tintColorArgb == null) {
                    canvas.drawCircle(0f, 0f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FDE047 })
                }
                val star = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 16f else 7f
                    val a = (i * PI / 5.0) - PI / 2.0
                    val sx = (cos(a) * r).toFloat(); val sy = (sin(a) * r).toFloat()
                    if (i == 0) star.moveTo(sx, sy) else star.lineTo(sx, sy)
                }
                star.close()
                canvas.drawPath(star, pFill(0xFFFDE047L)); canvas.drawPath(star, outline)
                canvas.restore()
            }
            HandPropKind.PHONE -> {
                canvas.drawRoundRect(RectF(-15f, -46f, 15f, 4f), 6f, 6f, pFill(0xFF0F172AL))
                canvas.drawRoundRect(RectF(-15f, -46f, 15f, 4f), 6f, 6f, outline)
                canvas.drawRoundRect(RectF(-12f, -41f, 12f, -4f), 3f, 3f, pFill(0xFF38BDF8L))
                canvas.drawCircle(0f, -1f, 2f, pFill(0xFF94A3B8L))
            }
            HandPropKind.HORROR_AXE -> {
                canvas.drawRoundRect(RectF(-5f, -88f, 5f, 18f), 4f, 4f, pFill(0xFF57534EL))
                canvas.drawRoundRect(RectF(-5f, -88f, 5f, 18f), 4f, 4f, outline)
                val axeHead = Path().apply {
                    moveTo(2f, -84f); quadTo(36f, -92f, 36f, -54f); quadTo(18f, -52f, 2f, -64f); close()
                }
                canvas.drawPath(axeHead, pFill(0xFFCBD5E1L)); canvas.drawPath(axeHead, outline)
                val edgeTint = Path().apply {
                    moveTo(24f, -86f); quadTo(36f, -72f, 32f, -56f); lineTo(24f, -60f); close()
                }
                canvas.drawPath(edgeTint, pFill(0xFFDC2626L))
            }
            HandPropKind.LANTERN -> {
                if (tintColorArgb == null) {
                    val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = RadialGradient(0f, -26f, 64f, 0x88FB923C.toInt(), 0x00FB923C, Shader.TileMode.CLAMP)
                    }
                    canvas.drawCircle(0f, -26f, 64f, glow)
                }
                canvas.drawArc(RectF(-10f, -56f, 10f, -38f), 180f, 180f, false, outline)
                canvas.drawRoundRect(RectF(-15f, -44f, 15f, -10f), 6f, 6f, pFill(0xFFFEF08AL))
                canvas.drawRoundRect(RectF(-15f, -44f, 15f, -10f), 6f, 6f, outline)
                canvas.drawRect(RectF(-18f, -48f, 18f, -42f), pFill(0xFF1E293BL))
                canvas.drawRect(RectF(-18f, -12f, 18f, -6f), pFill(0xFF1E293BL))
            }
            HandPropKind.COFFEE -> {
                canvas.drawRoundRect(RectF(-13f, -34f, 13f, 2f), 5f, 5f, pFill(0xFFFFFFFFL))
                canvas.drawRoundRect(RectF(-13f, -34f, 13f, 2f), 5f, 5f, outline)
                canvas.drawRect(RectF(-12f, -22f, 12f, -10f), pFill(0xFFB45309L))
                canvas.drawRoundRect(RectF(-15f, -40f, 15f, -32f), 4f, 4f, pFill(0xFF334155L))
                canvas.drawRoundRect(RectF(-15f, -40f, 15f, -32f), 4f, 4f, outline)
            }
            HandPropKind.SIGN -> {
                canvas.drawRoundRect(RectF(-4f, -44f, 4f, 14f), 3f, 3f, pFill(0xFF92400EL))
                canvas.drawRoundRect(RectF(-4f, -44f, 4f, 14f), 3f, 3f, outline)
                canvas.drawRoundRect(RectF(-38f, -86f, 38f, -40f), 10f, 10f, pFill(0xFFEF4444L))
                canvas.drawRoundRect(RectF(-38f, -86f, 38f, -40f), 10f, 10f, outline)
                val subText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = 18f
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    alpha = alphaInt
                }
                canvas.drawText("SUB!", 0f, -57f, subText)
            }
            HandPropKind.NONE -> Unit
        }
        canvas.restore()
    }

    private fun drawMotionPathOverlay(canvas: Canvas, points: List<Vec2>, isSelected: Boolean) {
        val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isSelected) 0xFFFF6B35.toInt() else 0xFFA78BFA.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
            pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
        }
        val path = Path().apply {
            moveTo(points[0].x, points[0].y)
            for (i in 1 until points.size) lineTo(points[i].x, points[i].y)
        }
        canvas.drawPath(path, pathPaint)
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFBBF24.toInt(); style = Paint.Style.FILL }
        points.forEach { canvas.drawCircle(it.x, it.y, 5.5f, dotPaint) }
    }

    private fun drawSceneVfx(
        canvas: Canvas,
        activeVfx: List<String>,
        w: Float,
        h: Float,
        frame: Int
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        activeVfx.forEach { name ->
            when (runCatching { SceneVfxType.valueOf(name) }.getOrNull()) {
                SceneVfxType.FIREFLIES -> {
                    val rng = Random(101)
                    repeat(28) { i ->
                        val bx = rng.nextFloat() * w
                        val by = rng.nextFloat() * h
                        val fx = (bx + sin((frame + i * 7) * 0.08) * 38f).toFloat()
                        val fy = (by + cos((frame + i * 5) * 0.06) * 28f).toFloat()
                        val pulse = (0.45f + 0.55f * sin((frame + i * 11) * 0.16).toFloat()).coerceIn(0.15f, 1f)
                        paint.style = Paint.Style.FILL
                        paint.color = Color.argb((pulse * 80).toInt(), 251, 191, 36)
                        canvas.drawCircle(fx, fy, 16f, paint)
                        paint.color = Color.argb((pulse * 240).toInt(), 254, 240, 138)
                        canvas.drawCircle(fx, fy, 4.5f, paint)
                    }
                }
                SceneVfxType.FLOWER_PETALS -> {
                    val rng = Random(202)
                    repeat(32) { i ->
                        val startX = rng.nextFloat() * w
                        val startY = rng.nextFloat() * h
                        val px = (startX + frame * (2.5f + i % 3) + sin((frame + i * 9) * 0.12) * 24f).toFloat() % (w + 40f) - 20f
                        val py = (startY + frame * (4.2f + (i % 4))) % (h + 40f) - 20f
                        paint.style = Paint.Style.FILL
                        paint.color = if (i % 2 == 0) 0xDDF9A8D4.toInt() else 0xDDFBCFE8.toInt()
                        canvas.save()
                        canvas.translate(px, py)
                        canvas.rotate((frame * 5 + i * 25).toFloat())
                        canvas.drawOval(RectF(-9f, -5f, 9f, 5f), paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.SUNBEAMS -> {
                    paint.style = Paint.Style.FILL
                    val beamAlpha = (36 + 12 * sin(frame * 0.06)).toInt()
                    paint.shader = LinearGradient(0f, 0f, w * 0.7f, h, Color.argb(beamAlpha, 254, 240, 138), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    listOf(0.12f, 0.36f, 0.62f).forEach { startFrac ->
                        val p = Path().apply {
                            moveTo(w * startFrac, 0f)
                            lineTo(w * (startFrac + 0.12f), 0f)
                            lineTo(w * (startFrac + 0.34f), h)
                            lineTo(w * (startFrac + 0.16f), h)
                            close()
                        }
                        canvas.drawPath(p, paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.RAIN -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.2f
                    paint.color = 0x88BAE6FD.toInt()
                    val rng = Random(303)
                    repeat(55) { i ->
                        val rx = (rng.nextFloat() * w + frame * 7f) % w
                        val ry = (rng.nextFloat() * h + frame * 26f) % h
                        canvas.drawLine(rx, ry, rx - 8f, ry + 30f, paint)
                    }
                }
                SceneVfxType.SNOW -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xDDFFFFFF.toInt()
                    val rng = Random(404)
                    repeat(48) { i ->
                        val sx = (rng.nextFloat() * w + sin((frame + i * 5) * 0.07) * 30f).toFloat()
                        val sy = (rng.nextFloat() * h + frame * (2.5f + i % 3)) % h
                        canvas.drawCircle(sx, sy, 2.5f + (i % 4), paint)
                    }
                }
                SceneVfxType.SPOOKY_FOG -> {
                    paint.style = Paint.Style.FILL
                    val drift1 = (frame * 2.4f) % (w + 380f)
                    val drift2 = (frame * 1.3f) % (w + 420f)
                    for (i in 0..5) {
                        val fx = ((i * (w / 4f) + drift1) % (w + 360f)) - 180f
                        val fy = h * (0.76f + (i % 2) * 0.08f)
                        paint.shader = RadialGradient(
                            fx, fy, 190f,
                            0x48CBD5E1, 0x00CBD5E1, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(fx - 220f, fy - 75f, fx + 220f, fy + 75f), paint)
                    }
                    for (i in 0..3) {
                        val fx = w - (((i * (w / 3f) + drift2) % (w + 360f)) - 180f)
                        val fy = h * 0.88f
                        paint.shader = RadialGradient(
                            fx, fy, 220f,
                            0x55E2E8F0, 0x00E2E8F0, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(fx - 260f, fy - 90f, fx + 260f, fy + 90f), paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.LIGHTNING_FLASH -> {
                    val cycle = frame % 48
                    if (cycle == 14 || cycle == 16 || cycle == 39) {
                        paint.style = Paint.Style.FILL
                        paint.color = if (cycle == 14) 0x88E0F2FE.toInt() else 0x55FFFFFF.toInt()
                        canvas.drawRect(0f, 0f, w, h, paint)

                        val boltX = if (cycle == 39) w * 0.25f else w * 0.72f
                        val boltPath = Path().apply {
                            moveTo(boltX, 0f)
                            lineTo(boltX - 28f, h * 0.22f)
                            lineTo(boltX + 18f, h * 0.26f)
                            lineTo(boltX - 36f, h * 0.56f)
                            lineTo(boltX + 12f, h * 0.58f)
                            lineTo(boltX - 18f, h * 0.82f)
                        }
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 10f
                        paint.color = 0x9938BDF8.toInt()
                        canvas.drawPath(boltPath, paint)
                        paint.strokeWidth = 4f
                        paint.color = Color.WHITE
                        canvas.drawPath(boltPath, paint)
                    }
                }
                SceneVfxType.VIGNETTE_HORROR -> {
                    paint.style = Paint.Style.FILL
                    val r = hypot(w, h) * 0.62f
                    paint.shader = RadialGradient(
                        w / 2f, h / 2f, r,
                        intArrayOf(0x00000000, 0x22000000, 0xCC020617.toInt()),
                        floatArrayOf(0.38f, 0.72f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null
                }
                SceneVfxType.CONFETTI_POP -> {
                    paint.style = Paint.Style.FILL
                    val colors = intArrayOf(
                        0xFFFF6B35.toInt(), 0xFF2DD4BF.toInt(), 0xFFFBBF24.toInt(),
                        0xFFA78BFA.toInt(), 0xFFFB7185.toInt(), 0xFF34D399.toInt()
                    )
                    val rng = Random(707)
                    repeat(46) { i ->
                        val cx = (rng.nextFloat() * w + sin((frame + i * 7) * 0.1) * 28f).toFloat()
                        val cy = (rng.nextFloat() * h + frame * (4.5f + i % 4)) % h
                        paint.color = colors[i % colors.size]
                        canvas.save()
                        canvas.translate(cx, cy)
                        canvas.rotate((frame * (7f + i % 5) + i * 25f) % 360f)
                        canvas.drawRect(-7f, -4f, 7f, 4f, paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.CINEMA_BARS -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xFF000000.toInt()
                    val barH = h * 0.105f
                    canvas.drawRect(0f, 0f, w, barH, paint)
                    canvas.drawRect(0f, h - barH, w, h, paint)
                }
                SceneVfxType.SPEED_LINES -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 3f
                    paint.color = 0xAAFFFFFF.toInt()
                    val cx = w / 2f; val cy = h / 2f
                    val outerR = hypot(cx, cy) * 1.15f
                    val rng = Random(505 + frame / 2)
                    repeat(36) {
                        val a = rng.nextFloat() * 2f * PI.toFloat()
                        val innerR = outerR * (0.48f + rng.nextFloat() * 0.22f)
                        canvas.drawLine(
                            cx + cos(a) * innerR, cy + sin(a) * innerR,
                            cx + cos(a) * outerR, cy + sin(a) * outerR,
                            paint
                        )
                    }
                }
                null -> Unit
            }
        }
    }

    private fun drawColorGradeOverlay(
        canvas: Canvas,
        gradeName: String,
        w: Float,
        h: Float,
        frame: Int
    ) {
        val grade = runCatching { SceneColorGrade.valueOf(gradeName) }.getOrDefault(SceneColorGrade.NONE)
        if (grade == SceneColorGrade.NONE) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (grade) {
            SceneColorGrade.HORROR_COLD -> {
                paint.color = 0x380B253A
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0x3304141D, 0x44020617, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.NIGHT_BLUE -> {
                paint.color = 0x480F172A
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.WARM_SUNSET -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0x30FB923C, 0x26F43F5E, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.VINTAGE_VHS -> {
                paint.color = 0x2278350F
                canvas.drawRect(0f, 0f, w, h, paint)
                val linePaint = Paint().apply { color = 0x22000000; strokeWidth = 2f }
                var y = 0f
                while (y < h) {
                    canvas.drawLine(0f, y, w, y, linePaint)
                    y += 6f
                }
                // Rolling VHS tracking bar + REC timestamp
                val trackY = (frame * 11f) % h
                paint.color = 0x1EFFFFFF
                canvas.drawRect(0f, trackY, w, trackY + 18f, paint)
                val recPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xDDFF3B30.toInt()
                    textSize = (h * 0.036f).coerceIn(18f, 34f)
                    typeface = Typeface.MONOSPACE
                }
                if ((frame / 12) % 2 == 0) {
                    canvas.drawCircle(38f, 40f, 9f, recPaint)
                }
                recPaint.color = 0xEEFFFFFF.toInt()
                canvas.drawText("PLAY  VHS", 56f, 48f, recPaint)
            }
            SceneColorGrade.NOIR_BW -> {
                paint.color = 0x660B0F17
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w, h) * 0.58f,
                    0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.NONE -> Unit
        }
    }

    private fun drawSubtitles(
        canvas: Canvas,
        subtitles: List<SubtitleCue>,
        frame: Int,
        w: Float,
        h: Float
    ) {
        val active = subtitles.lastOrNull { frame in it.startFrame..it.endFrame } ?: return
        val subStyle = runCatching { SubtitleStyle.valueOf(active.style) }.getOrDefault(SubtitleStyle.YOUTUBE_BOLD)
        val ageFrames = (frame - active.startFrame).coerceAtLeast(0)
        // Snappy YouTube pop-in bounce over the first 4 frames
        val popScale = when (ageFrames) {
            0 -> 0.82f
            1 -> 1.08f
            2 -> 0.98f
            else -> 1f
        }
        val baseTextSize = (min(w, h) * 0.064f).coerceIn(26f, 64f)
        val displayLine = if (active.speakerName.isNotBlank()) "${active.speakerName}: ${active.text}" else active.text
        val centerX = w / 2f
        val baseY = h * 0.88f

        canvas.save()
        canvas.translate(centerX, baseY)
        canvas.scale(popScale, popScale)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = baseTextSize
            typeface = when (subStyle) {
                SubtitleStyle.YOUTUBE_BOLD, SubtitleStyle.COMIC_BOX -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                SubtitleStyle.HORROR_DRIP -> Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
                SubtitleStyle.CINEMATIC -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
        }
        val textW = textPaint.measureText(displayLine)

        when (subStyle) {
            SubtitleStyle.COMIC_BOX -> {
                val padX = 24f; val padY = 14f
                val boxRect = RectF(-textW / 2f - padX, -baseTextSize - padY * 0.4f, textW / 2f + padX, padY)
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE0F172A.toInt() }
                val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = active.colorArgb.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                }
                canvas.drawRoundRect(boxRect, 14f, 14f, bg)
                canvas.drawRoundRect(boxRect, 14f, 14f, border)
            }
            SubtitleStyle.CINEMATIC -> {
                val padX = 22f; val padY = 10f
                val boxRect = RectF(-textW / 2f - padX, -baseTextSize - padY * 0.3f, textW / 2f + padX, padY)
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA000000.toInt() }
                canvas.drawRoundRect(boxRect, 8f, 8f, bg)
            }
            else -> Unit
        }

        // Crisp dark outline + shadow
        val strokePaint = Paint(textPaint).apply {
            color = 0xFF000000.toInt()
            style = Paint.Style.STROKE
            strokeWidth = if (subStyle == SubtitleStyle.YOUTUBE_BOLD || subStyle == SubtitleStyle.HORROR_DRIP) 10f else 5f
            strokeJoin = Paint.Join.ROUND
        }
        canvas.drawText(displayLine, 0f, 0f, strokePaint)

        textPaint.style = Paint.Style.FILL
        textPaint.color = if (subStyle == SubtitleStyle.HORROR_DRIP) 0xFFFF3B5C.toInt() else active.colorArgb.toInt()
        canvas.drawText(displayLine, 0f, 0f, textPaint)
        canvas.restore()
    }

    private fun drawBackgroundTemplate(
        canvas: Canvas,
        templateName: String,
        bgColorArgb: Long,
        w: Float,
        h: Float,
        panX: Float,
        panY: Float,
        frame: Int
    ) {
        val template = runCatching { BackgroundTemplate.valueOf(templateName) }.getOrDefault(BackgroundTemplate.SOLID)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (template) {
            BackgroundTemplate.SOLID -> {
                paint.color = bgColorArgb.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            BackgroundTemplate.PASTEL_SKY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF93C5FD.toInt(), 0xFFFBCFE8.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Soft pastel drifting clouds
                paint.color = 0xEEFFFFFF.toInt()
                val drift = (frame * 0.8f) % (w + 260f)
                listOf(0.18f to 0.22f, 0.56f to 0.16f, 0.84f to 0.28f).forEach { (xf, yf) ->
                    val cx = (w * xf + drift) % (w + 180f) - 90f - panX * 0.25f
                    val cy = h * yf - panY * 0.2f
                    canvas.drawCircle(cx - 38f, cy, 32f, paint)
                    canvas.drawCircle(cx, cy - 14f, 44f, paint)
                    canvas.drawCircle(cx + 40f, cy, 34f, paint)
                }
                paint.color = 0xFF86EFAC.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.68f, w * 0.8f - panX * 0.5f, h * 1.35f), paint)
                paint.color = 0xFF4ADE80.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.72f, w * 1.3f - panX * 0.7f, h * 1.4f), paint)
            }
            BackgroundTemplate.CHERRY_BLOSSOM -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(w * 0.08f - panX * 0.4f, h * 0.35f, w * 0.13f - panX * 0.4f, h * 0.85f, paint)
                paint.color = 0xFFF472B6.toInt()
                canvas.drawCircle(w * 0.12f - panX * 0.4f, h * 0.28f, 125f, paint)
                paint.color = 0xFFFBCFE8.toInt()
                canvas.drawCircle(w * 0.22f - panX * 0.4f, h * 0.32f, 95f, paint)
                paint.color = 0xFF6EE7B7.toInt()
                canvas.drawRect(0f, h * 0.76f, w, h, paint)
            }
            BackgroundTemplate.TWILIGHT_DREAM -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF312E81.toInt(), 0xFFEC4899.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFEF08A.toInt()
                canvas.drawCircle(w * 0.76f - panX * 0.2f, h * 0.24f, 54f, paint)
                paint.color = 0xFF1E1B4B.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.6f, h * 0.66f, w * 1.15f - panX * 0.6f, h * 1.38f), paint)
            }
            BackgroundTemplate.HAUNTED_FOREST -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF040914.toInt(), 0xFF132238.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Eerie glowing full moon
                val moonX = w * 0.74f - (panX * 0.12f) % (w * 0.5f)
                paint.shader = RadialGradient(moonX, h * 0.22f, 150f, 0x55BAE6FD, 0x00BAE6FD, Shader.TileMode.CLAMP)
                canvas.drawCircle(moonX, h * 0.22f, 150f, paint)
                paint.shader = null
                paint.color = 0xFFE2E8F0.toInt()
                canvas.drawCircle(moonX, h * 0.22f, 58f, paint)
                // Seamlessly wrapping silhouettes of twisted dead trees
                val span = w + 320f
                paint.color = 0xFF070D19.toInt()
                for (i in 0..8) {
                    val tx = (((i * (span / 8f) - panX * 0.65f) % span) + span) % span - 160f
                    val treeH = h * (0.48f + (i % 3) * 0.12f)
                    val trunkW = 24f + (i % 3) * 8f
                    canvas.drawRect(tx - trunkW / 2f, h - treeH, tx + trunkW / 2f, h * 0.84f, paint)
                    // Spooky crooked branches
                    val branchP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF070D19.toInt()
                        strokeWidth = 9f
                        strokeCap = Paint.Cap.ROUND
                    }
                    canvas.drawLine(tx, h - treeH * 0.72f, tx - 56f, h - treeH * 0.88f, branchP)
                    canvas.drawLine(tx, h - treeH * 0.60f, tx + 62f, h - treeH * 0.78f, branchP)
                }
                // Dark misty ground
                paint.color = 0xFF020617.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
            }
            BackgroundTemplate.SPOOKY_MANSION -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF1A1025.toInt(), 0xFF0B0712.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Repeating haunted hallway pillars & gothic arched windows
                val span = w + 320f
                for (i in 0..4) {
                    val wx = (((i * (span / 4f) - panX * 0.6f) % span) + span) % span - 140f
                    // Gothic moonlight window
                    paint.color = 0xFF1E293B.toInt()
                    canvas.drawRoundRect(RectF(wx - 44f, h * 0.16f, wx + 44f, h * 0.54f), 44f, 44f, paint)
                    paint.color = 0xFF334155.toInt()
                    canvas.drawRect(wx - 3f, h * 0.16f, wx + 3f, h * 0.54f, paint)
                    canvas.drawRect(wx - 44f, h * 0.36f, wx + 44f, h * 0.38f, paint)
                    // Flickering wall torch glow
                    val flicker = 0.85f + 0.15f * sin((frame + i * 7) * 0.6).toFloat()
                    paint.shader = RadialGradient(
                        wx + 110f, h * 0.42f, 90f * flicker,
                        0x66F59E0B, 0x00F59E0B, Shader.TileMode.CLAMP
                    )
                    canvas.drawCircle(wx + 110f, h * 0.42f, 90f * flicker, paint)
                    paint.shader = null
                }
                paint.color = 0xFF1C1329.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0xFF3B0764.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h * 0.77f, paint)
            }
            BackgroundTemplate.COMIC_BURST -> {
                paint.shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w, h) * 0.6f,
                    0xFFFEF08A.toInt(), 0xFFFF6B35.toInt(), Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val cx = w / 2f; val cy = h / 2f
                val r = hypot(w, h)
                val rotOffset = frame * 0.8f
                paint.color = 0x33FFFFFF
                for (i in 0 until 16) {
                    val a1 = Math.toRadians((i * 22.5 + rotOffset))
                    val a2 = Math.toRadians((i * 22.5 + 10.0 + rotOffset))
                    val tri = Path().apply {
                        moveTo(cx, cy)
                        lineTo(cx + (cos(a1) * r).toFloat(), cy + (sin(a1) * r).toFloat())
                        lineTo(cx + (cos(a2) * r).toFloat(), cy + (sin(a2) * r).toFloat())
                        close()
                    }
                    canvas.drawPath(tri, paint)
                }
            }
            BackgroundTemplate.CLASSROOM_STAGE -> {
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                // Classic green chalkboard
                val bx = w * 0.14f - panX * 0.35f
                paint.color = 0xFF78350F.toInt()
                canvas.drawRoundRect(RectF(bx - 12f, h * 0.14f - 12f, bx + w * 0.72f + 12f, h * 0.58f + 12f), 14f, 14f, paint)
                paint.color = 0xFF14532D.toInt()
                canvas.drawRect(bx, h * 0.14f, bx + w * 0.72f, h * 0.58f, paint)
                // Wooden floor
                paint.color = 0xFFB45309.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0xFF92400E.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h * 0.76f, paint)
            }
            BackgroundTemplate.GRID_PAPER -> {
                paint.color = 0xFFF8FAFC.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                val gridPaint = Paint().apply { color = 0xFFCBD5E1.toInt(); strokeWidth = 1.5f }
                var x = 0f; while (x <= w) { canvas.drawLine(x, 0f, x, h, gridPaint); x += 64f }
                var y = 0f; while (y <= h) { canvas.drawLine(0f, y, w, y, gridPaint); y += 64f }
                val centerPaint = Paint().apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f }
                canvas.drawLine(w / 2f, 0f, w / 2f, h, centerPaint)
                canvas.drawLine(0f, h / 2f, w, h / 2f, centerPaint)
            }
            BackgroundTemplate.SUNNY_MEADOW -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF38BDF8.toInt(), 0xFFBAE6FD.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.82f - panX * 0.2f, h * 0.2f - panY * 0.2f, 64f, paint)
                paint.color = 0xFF22C55E.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.62f, w * 0.7f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF16A34A.toInt()
                canvas.drawOval(RectF(w * 0.35f - panX * 0.7f, h * 0.66f, w * 1.25f - panX * 0.7f, h * 1.35f), paint)
            }
            BackgroundTemplate.CYBERPUNK_CITY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF090D1A.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.shader = LinearGradient(0f, h * 0.55f, 0f, h, 0x44FF6B35, 0x00000000, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, h * 0.55f, w, h, paint)
                paint.shader = null
                val bWidths = listOf(110f, 85f, 140f, 95f, 130f, 105f, 150f, 90f, 135f, 120f)
                val bHeights = listOf(260f, 380f, 220f, 420f, 300f, 360f, 250f, 410f, 290f, 330f)
                var bx = -40f - panX * 0.6f
                bWidths.forEachIndexed { idx, bw ->
                    val bh = bHeights[idx]
                    paint.color = 0xFF0F172A.toInt()
                    canvas.drawRect(bx, h - bh, bx + bw - 8f, h, paint)
                    paint.color = if (idx % 2 == 0) 0xAA2DD4BF.toInt() else 0xAAFF6B35.toInt()
                    var wy = h - bh + 20f
                    while (wy < h - 60f) { canvas.drawRect(bx + 14f, wy, bx + bw - 26f, wy + 7f, paint); wy += 26f }
                    bx += bw
                }
                paint.color = 0xFF151922.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
                paint.color = 0x552DD4BF; paint.strokeWidth = 2f
                canvas.drawLine(0f, h * 0.78f, w, h * 0.78f, paint)
            }
            BackgroundTemplate.COZY_STUDIO -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF292524.toInt(), 0xFF1C1917.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF44403C.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0x33FBBF24
                canvas.drawCircle(w * 0.5f, h * 0.35f, 280f, paint)
            }
            BackgroundTemplate.OUTER_SPACE -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0xFF030712.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val rng = Random(42)
                paint.color = 0xFFFFFFFF.toInt()
                repeat(70) { canvas.drawCircle(rng.nextFloat() * w, rng.nextFloat() * h, 1.5f + rng.nextFloat() * 2.5f, paint) }
                paint.color = 0xFF7C3AED.toInt()
                canvas.drawCircle(w * 0.78f - panX * 0.3f, h * 0.28f, 74f, paint)
                paint.color = 0x552DD4BF; paint.style = Paint.Style.STROKE; paint.strokeWidth = 10f
                canvas.drawOval(RectF(w * 0.78f - 125f - panX * 0.3f, h * 0.28f - 24f, w * 0.78f + 125f - panX * 0.3f, h * 0.28f + 24f), paint)
            }
            BackgroundTemplate.SUNSET_DESERT -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f, 0xFF7C2D12.toInt(), 0xFFFB923C.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.5f, h * 0.58f, 92f, paint)
                paint.color = 0xFF9A3412.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.5f, h * 0.65f, w * 0.75f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF7C2D12.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.7f, w * 1.2f - panX * 0.7f, h * 1.35f), paint)
            }
        }
    }

    fun parseSimpleSvgShapes(svgContent: String, canvasW: Float, canvasH: Float): List<VectorShape> {
        val shapes = mutableListOf<VectorShape>()
        val cx = canvasW / 2f; val cy = canvasH / 2f
        fun extractAttr(tag: String, attr: String): Float? =
            Regex("""$attr\s*=\s*["']([0-9.\-]+)["']""").find(tag)?.groupValues?.getOrNull(1)?.toFloatOrNull()

        Regex("<rect[^>]+>").findAll(svgContent).forEach { m ->
            val x = extractAttr(m.value, "x") ?: 0f; val y = extractAttr(m.value, "y") ?: 0f
            val w = extractAttr(m.value, "width") ?: 120f; val h = extractAttr(m.value, "height") ?: 80f
            shapes.add(VectorShape(kind = ShapeKind.RECTANGLE.name, startX = cx - 150f + x, startY = cy - 100f + y, endX = cx - 150f + x + w, endY = cy - 100f + y + h, strokeColorArgb = 0xFF2DD4BFL, fillColorArgb = 0x662DD4BF, strokeWidth = 4f))
        }
        Regex("<circle[^>]+>").findAll(svgContent).forEach { m ->
            val x = extractAttr(m.value, "cx") ?: 80f; val y = extractAttr(m.value, "cy") ?: 80f
            val r = extractAttr(m.value, "r") ?: 50f
            shapes.add(VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 150f + x - r, startY = cy - 100f + y - r, endX = cx - 150f + x + r, endY = cy - 100f + y + r, strokeColorArgb = 0xFFFF6B35L, fillColorArgb = 0x66FF6B35, strokeWidth = 4f))
        }
        Regex("<line[^>]+>").findAll(svgContent).forEach { m ->
            val x1 = extractAttr(m.value, "x1") ?: 0f; val y1 = extractAttr(m.value, "y1") ?: 0f
            val x2 = extractAttr(m.value, "x2") ?: 120f; val y2 = extractAttr(m.value, "y2") ?: 120f
            shapes.add(VectorShape(kind = ShapeKind.LINE.name, startX = cx - 150f + x1, startY = cy - 100f + y1, endX = cx - 150f + x2, endY = cy - 100f + y2, strokeColorArgb = 0xFFFBBF24L, strokeWidth = 5f))
        }
        return shapes
    }
}
