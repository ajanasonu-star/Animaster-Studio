package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.VoiceEffectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

enum class BuiltInAudioPreset(val title: String, val kind: AudioTrackKind, val durationSec: Float) {
    SFX_POP("Cartoon Pop", AudioTrackKind.SFX, 0.35f),
    SFX_BOING("Spring Boing", AudioTrackKind.SFX, 0.75f),
    SFX_WHOOSH("Fast Whoosh", AudioTrackKind.SFX, 0.55f),
    SFX_SPARKLE("Magic Chime", AudioTrackKind.SFX, 0.9f),
    SFX_FOOTSTEP("Soft Step", AudioTrackKind.SFX, 0.25f),
    SFX_JUMPSCARE("Horror Scare", AudioTrackKind.SFX, 0.95f),
    SFX_GHOST_MOAN("Ghost Wail", AudioTrackKind.SFX, 1.5f),
    SFX_THUNDER("Thunder Clap", AudioTrackKind.SFX, 1.6f),
    SFX_HEARTBEAT("Suspense Pulse", AudioTrackKind.SFX, 2.0f),
    MUSIC_SYNTH_LOOP("Studio Synth Loop", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_PLAYFUL_BEAT("Playful Marimba", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_HORROR_DRONE("Horror Ambience", AudioTrackKind.MUSIC, 4.0f)
}

class AudioStudioEngine(private val context: Context) {

    private val audioDir: File by lazy {
        File(context.filesDir, "audio").apply { mkdirs() }
    }

    private var activeRecorder: AudioRecord? = null
    @Volatile
    private var isRecordingFlag = false
    private val activePlayers = mutableListOf<MediaPlayer>()

    @SuppressLint("MissingPermission")
    suspend fun recordVoiceToWav(
        onAmplitude: (Float) -> Unit,
        onFinished: (AudioTrackItem?) -> Unit
    ) = withContext(Dispatchers.IO) {
        val sampleRate = 22050
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, encoding).coerceAtLeast(2048)

        val recorder = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, encoding, minBuf * 2)
        }.getOrNull()

        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        activeRecorder = recorder
        isRecordingFlag = true
        val pcmStream = ByteArrayOutputStream()
        val buffer = ShortArray(1024)

        try {
            recorder.startRecording()
            while (isRecordingFlag && isActive) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    var peak = 0
                    val byteBuf = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until read) {
                        val s = buffer[i]
                        byteBuf.putShort(s)
                        val a = abs(s.toInt())
                        if (a > peak) peak = a
                    }
                    pcmStream.write(byteBuf.array())
                    val norm = (peak / 32768f).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main) { onAmplitude(norm) }
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
            activeRecorder = null
            isRecordingFlag = false
        }

        val pcmBytes = pcmStream.toByteArray()
        if (pcmBytes.size < 400) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        val file = File(audioDir, "voice_${System.currentTimeMillis()}.wav")
        writeWavFile(file, pcmBytes, sampleRate)
        val durationMs = ((pcmBytes.size / 2.0) / sampleRate * 1000.0).toLong().coerceAtLeast(200L)
        val peaks = extractPeaksFromPcm16(pcmBytes, 48)
        val track = AudioTrackItem(
            id = UUID.randomUUID().toString(),
            name = "Voice Take ${(System.currentTimeMillis() % 1000)}",
            filePath = file.absolutePath,
            originalFilePath = file.absolutePath,
            kind = AudioTrackKind.VOICE.name,
            voiceEffect = VoiceEffectType.NORMAL.name,
            startFrame = 0,
            durationMs = durationMs,
            trimStartMs = 0L,
            trimEndMs = durationMs,
            volume = 0.95f,
            fadeInMs = 50L,
            fadeOutMs = 80L,
            waveformPeaks = peaks
        )
        withContext(Dispatchers.Main) { onFinished(track) }
    }

    fun stopVoiceRecording() {
        isRecordingFlag = false
    }

    suspend fun synthesizeBuiltInPreset(preset: BuiltInAudioPreset, startFrame: Int): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val sampleRate = 22050
            val totalSamples = (sampleRate * preset.durationSec).toInt()
            val pcm = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
            val rng = Random(preset.ordinal * 997 + 13)

            for (i in 0 until totalSamples) {
                val t = i.toFloat() / sampleRate.toFloat()
                val progress = i.toFloat() / totalSamples.toFloat()
                val sample = when (preset) {
                    BuiltInAudioPreset.SFX_POP -> {
                        val freq = 220f + 560f * progress
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 14f)
                    }
                    BuiltInAudioPreset.SFX_BOING -> {
                        val freq = 140f + 240f * sin(2.0 * PI * 9.0 * t).toFloat()
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 3.2f)
                    }
                    BuiltInAudioPreset.SFX_WHOOSH -> {
                        val env = sin(PI * progress).toFloat()
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.45f
                        val tone = sin(2.0 * PI * (180f + 420f * progress) * t).toFloat() * 0.35f
                        (noise + tone) * env
                    }
                    BuiltInAudioPreset.SFX_SPARKLE -> {
                        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f)
                        val noteIdx = (progress * notes.size).toInt().coerceIn(0, notes.lastIndex)
                        val localT = t - (noteIdx * (preset.durationSec / notes.size))
                        val env = exp(-localT.coerceAtLeast(0f) * 8f)
                        (sin(2.0 * PI * notes[noteIdx] * t) + 0.4 * sin(4.0 * PI * notes[noteIdx] * t)).toFloat() * 0.6f * env
                    }
                    BuiltInAudioPreset.SFX_FOOTSTEP -> {
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.5f
                        val thud = sin(2.0 * PI * (95f - 45f * progress) * t).toFloat() * 0.6f
                        (noise + thud) * exp(-t * 22f)
                    }
                    BuiltInAudioPreset.SFX_JUMPSCARE -> {
                        val shriek = sin(2.0 * PI * (680f + 420f * sin(t * 28.0)) * t).toFloat() * 0.45f
                        val dissonance = sin(2.0 * PI * 725.0 * t).toFloat() * 0.38f
                        val rumble = sin(2.0 * PI * 62.0 * t).toFloat() * 0.4f
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.35f
                        (shriek + dissonance + rumble + noise) * exp(-t * 3.1f)
                    }
                    BuiltInAudioPreset.SFX_GHOST_MOAN -> {
                        val env = sin(PI * progress).toFloat()
                        val vibrato = sin(2.0 * PI * 5.2 * t).toFloat() * 28f
                        val freq = 340f - 140f * progress + vibrato
                        val wail = sin(2.0 * PI * freq * t).toFloat() * 0.55f +
                            sin(2.0 * PI * (freq * 1.5f) * t).toFloat() * 0.22f
                        val breath = (rng.nextFloat() * 2f - 1f) * 0.14f
                        (wail + breath) * env
                    }
                    BuiltInAudioPreset.SFX_THUNDER -> {
                        val crack = (rng.nextFloat() * 2f - 1f) * exp(-t * 6.5f) * 0.7f
                        val roll = (rng.nextFloat() * 2f - 1f) * (0.4f + 0.3f * sin(t * 9.0).toFloat()) * exp(-t * 1.4f)
                        val sub = sin(2.0 * PI * (52f - 18f * progress) * t).toFloat() * exp(-t * 1.8f) * 0.5f
                        crack + roll * 0.55f + sub
                    }
                    BuiltInAudioPreset.SFX_HEARTBEAT -> {
                        val cycle = t % 0.85f
                        val beat1 = if (cycle < 0.16f) sin(2.0 * PI * 58.0 * cycle).toFloat() * exp(-cycle * 22f) else 0f
                        val beat2 = if (cycle in 0.22f..0.38f) {
                            val lt = cycle - 0.22f
                            sin(2.0 * PI * 50.0 * lt).toFloat() * exp(-lt * 24f) * 0.75f
                        } else 0f
                        (beat1 + beat2) * 0.95f
                    }
                    BuiltInAudioPreset.MUSIC_SYNTH_LOOP -> {
                        val stepDur = 0.2f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val chord = floatArrayOf(261.63f, 329.63f, 392.0f, 329.63f, 220.0f, 261.63f, 349.23f, 392.0f)
                        val f = chord[step % chord.size]
                        val bass = sin(2.0 * PI * (f / 2f) * t).toFloat() * 0.32f
                        val lead = sin(2.0 * PI * f * t).toFloat() * exp(-localT * 6.5f) * 0.45f
                        (bass + lead) * (1f - 0.1f * progress)
                    }
                    BuiltInAudioPreset.MUSIC_PLAYFUL_BEAT -> {
                        val stepDur = 0.16f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val scale = floatArrayOf(392f, 440f, 523.25f, 587.33f, 659.25f, 587.33f, 523.25f, 440f)
                        val f = scale[step % scale.size]
                        sin(2.0 * PI * f * t).toFloat() * exp(-localT * 11f) * 0.65f
                    }
                    BuiltInAudioPreset.MUSIC_HORROR_DRONE -> {
                        val drone1 = sin(2.0 * PI * 55.0 * t).toFloat() * 0.38f
                        val drone2 = sin(2.0 * PI * 58.27 * t).toFloat() * 0.32f
                        val eerieHigh = sin(2.0 * PI * (466.16 + 8.0 * sin(t * 1.7)) * t).toFloat() * 0.12f
                        val wind = (rng.nextFloat() * 2f - 1f) * 0.08f * (0.5f + 0.5f * sin(t * 2.1).toFloat())
                        (drone1 + drone2 + eerieHigh + wind) * sin(PI * progress).toFloat().coerceAtLeast(0.25f)
                    }
                }
                val s16 = (sample.coerceIn(-0.98f, 0.98f) * 32000f).toInt().toShort()
                pcm.putShort(s16)
            }

            val pcmBytes = pcm.array()
            val file = File(audioDir, "preset_${preset.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(file, pcmBytes, sampleRate)
            val durationMs = (preset.durationSec * 1000L).toLong()
            AudioTrackItem(
                id = UUID.randomUUID().toString(),
                name = preset.title,
                filePath = file.absolutePath,
                originalFilePath = file.absolutePath,
                kind = preset.kind.name,
                voiceEffect = VoiceEffectType.NORMAL.name,
                startFrame = startFrame,
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                volume = 0.85f,
                fadeInMs = 40L,
                fadeOutMs = 100L,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 44)
            )
        }

    /**
     * Real offline PCM16 Voice Changer DSP for Cartoon Kid, Deep Monster, Ghost Echo & Robot voices.
     */
    suspend fun applyVoiceEffect(track: AudioTrackItem, effect: VoiceEffectType): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val basePath = track.originalFilePath.ifBlank { track.filePath }
            val sourceFile = File(basePath)
            if (!sourceFile.exists()) return@withContext track.copy(voiceEffect = effect.name)

            if (effect == VoiceEffectType.NORMAL) {
                val bytes = runCatching { sourceFile.readBytes() }.getOrNull()
                val wav = bytes?.let { parseWavPcm16(it) }
                val durMs = wav?.let { ((it.samples.size.toDouble() / it.sampleRate) * 1000.0).toLong().coerceAtLeast(200L) }
                    ?: track.durationMs
                val restoredPeaks = if (wav != null) {
                    val bb = ByteBuffer.allocate(wav.samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                    wav.samples.forEach { bb.putShort(it) }
                    extractPeaksFromPcm16(bb.array(), 48)
                } else track.waveformPeaks
                return@withContext track.copy(
                    filePath = basePath,
                    originalFilePath = basePath,
                    voiceEffect = effect.name,
                    durationMs = durMs,
                    trimStartMs = 0L,
                    trimEndMs = durMs,
                    waveformPeaks = restoredPeaks
                )
            }

            val rawBytes = runCatching { sourceFile.readBytes() }.getOrNull()
                ?: return@withContext track.copy(voiceEffect = effect.name)
            val parsed = parseWavPcm16(rawBytes)
                ?: return@withContext track.copy(voiceEffect = effect.name)

            val processedSamples = processVoicePcm16(parsed.samples, parsed.sampleRate, effect)
            val outBytes = ByteBuffer.allocate(processedSamples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            processedSamples.forEach { outBytes.putShort(it) }
            val pcmBytes = outBytes.array()

            val outFile = File(audioDir, "fx_${effect.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(outFile, pcmBytes, parsed.sampleRate)
            val durationMs = ((processedSamples.size.toDouble() / parsed.sampleRate) * 1000.0).toLong().coerceAtLeast(200L)
            track.copy(
                filePath = outFile.absolutePath,
                originalFilePath = basePath,
                voiceEffect = effect.name,
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 48)
            )
        }

    suspend fun importAudioUri(uri: Uri, displayName: String, startFrame: Int): AudioTrackItem? =
        withContext(Dispatchers.IO) {
            val outFile = File(audioDir, "import_${System.currentTimeMillis()}.audio")
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(outFile.absolutePath)
                val durationMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.coerceAtLeast(300L) ?: 3000L
                mmr.release()

                val bytes = outFile.readBytes()
                val peaks = if (bytes.size > 44 && String(bytes.copyOfRange(0, 4)) == "RIFF") {
                    extractPeaksFromPcm16(bytes.copyOfRange(44, bytes.size), 48)
                } else {
                    extractApproximatePeaks(bytes, 48)
                }

                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    name = displayName.substringBeforeLast('.').ifBlank { "Imported Audio" },
                    filePath = outFile.absolutePath,
                    originalFilePath = outFile.absolutePath,
                    kind = AudioTrackKind.MUSIC.name,
                    voiceEffect = VoiceEffectType.NORMAL.name,
                    startFrame = startFrame,
                    durationMs = durationMs,
                    trimStartMs = 0L,
                    trimEndMs = durationMs,
                    volume = 0.85f,
                    fadeInMs = 80L,
                    fadeOutMs = 120L,
                    waveformPeaks = peaks
                )
            }.getOrNull()
        }

    fun previewTrack(track: AudioTrackItem) {
        stopAllPlayback()
        if (track.muted || track.filePath.isBlank()) return
        val file = File(track.filePath)
        if (!file.exists()) return
        runCatching {
            val mp = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setVolume(track.volume, track.volume)
                if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                setOnCompletionListener {
                    it.release()
                    activePlayers.remove(it)
                }
                start()
            }
            activePlayers.add(mp)
        }
    }

    fun triggerTracksForFrame(tracks: List<AudioTrackItem>, frame: Int) {
        tracks.filter { !it.muted && it.startFrame == frame && it.filePath.isNotBlank() }.forEach { track ->
            val file = File(track.filePath)
            if (file.exists()) {
                runCatching {
                    val mp = MediaPlayer().apply {
                        setDataSource(file.absolutePath)
                        prepare()
                        setVolume(track.volume, track.volume)
                        if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                        setOnCompletionListener {
                            it.release()
                            activePlayers.remove(it)
                        }
                        start()
                    }
                    activePlayers.add(mp)
                }
            }
        }
    }

    fun stopAllPlayback() {
        val copy = activePlayers.toList()
        activePlayers.clear()
        copy.forEach { mp ->
            runCatching {
                if (mp.isPlaying) mp.stop()
                mp.release()
            }
        }
    }

    private fun writeWavFile(file: File, pcmData: ByteArray, sampleRate: Int) {
        val channels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + dataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1) // PCM
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort((channels * bitsPerSample / 8).toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray())
            putInt(dataSize)
        }
        FileOutputStream(file).use { out ->
            out.write(header.array())
            out.write(pcmData)
        }
    }

    private fun extractPeaksFromPcm16(pcmBytes: ByteArray, bars: Int): List<Float> {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return List(bars) { 0.15f }
        val step = (sampleCount / bars).coerceAtLeast(1)
        val bb = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)
        val peaks = mutableListOf<Float>()
        for (b in 0 until bars) {
            var maxAmp = 0
            val start = b * step
            val end = ((b + 1) * step).coerceAtMost(sampleCount)
            for (s in start until end) {
                val v = abs(bb.getShort(s * 2).toInt())
                if (v > maxAmp) maxAmp = v
            }
            peaks.add((maxAmp / 32768f).coerceIn(0.08f, 1f))
        }
        return peaks
    }

    private fun extractApproximatePeaks(bytes: ByteArray, bars: Int): List<Float> {
        if (bytes.isEmpty()) return List(bars) { 0.25f }
        val step = (bytes.size / bars).coerceAtLeast(1)
        return List(bars) { b ->
            val idx = (b * step).coerceIn(0, bytes.lastIndex)
            val norm = abs(bytes[idx].toInt()) / 128f
            norm.coerceIn(0.15f, 0.95f)
        }
    }

    data class ParsedWav(val sampleRate: Int, val samples: ShortArray)

    companion object {
        fun parseWavPcm16(bytes: ByteArray): ParsedWav? {
            if (bytes.size <= 44) return null
            if (String(bytes.copyOfRange(0, 4)) != "RIFF") return null
            if (String(bytes.copyOfRange(8, 12)) != "WAVE") return null
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

            var channels = 1
            var sampleRate = 22050
            var bits = 16
            var foundFmt = false
            var dataOffset = -1
            var dataSize = 0

            var cursor = 12
            while (cursor + 8 <= bytes.size) {
                val chunkId = String(bytes.copyOfRange(cursor, cursor + 4))
                val chunkSize = bb.getInt(cursor + 4).coerceAtLeast(0)
                val bodyStart = cursor + 8
                if (chunkId == "fmt " && bodyStart + 16 <= bytes.size) {
                    channels = bb.getShort(bodyStart + 2).toInt().coerceIn(1, 8)
                    sampleRate = bb.getInt(bodyStart + 4).coerceIn(8000, 48000)
                    bits = bb.getShort(bodyStart + 14).toInt()
                    foundFmt = true
                } else if (chunkId == "data") {
                    dataOffset = bodyStart
                    dataSize = chunkSize.coerceAtMost((bytes.size - bodyStart).coerceAtLeast(0))
                    break
                }
                val padded = chunkSize + (chunkSize and 1)
                if (padded <= 0) break
                cursor = bodyStart + padded
            }

            if (!foundFmt || bits != 16 || dataOffset < 0 || dataSize <= 0) return null
            val frameCount = dataSize / (2 * channels)
            if (frameCount <= 0) return null
            val mono = ShortArray(frameCount)
            for (i in 0 until frameCount) {
                var sum = 0
                for (c in 0 until channels) {
                    val pos = dataOffset + (i * channels + c) * 2
                    if (pos + 1 < bytes.size) sum += bb.getShort(pos).toInt()
                }
                mono[i] = (sum / channels).toShort()
            }
            return ParsedWav(sampleRate, mono)
        }

        fun processVoicePcm16(
            input: ShortArray,
            sampleRate: Int,
            effect: VoiceEffectType
        ): ShortArray {
            if (input.isEmpty() || effect == VoiceEffectType.NORMAL) return input
            return when (effect) {
                VoiceEffectType.CHIPMUNK -> resamplePitch(input, 1.48f)
                VoiceEffectType.DEEP_MONSTER -> {
                    val pitched = resamplePitch(input, 0.68f)
                    ShortArray(pitched.size) { i ->
                        val t = i.toDouble() / sampleRate.toDouble()
                        val growl = 1.0 + 0.18 * sin(2.0 * PI * 32.0 * t)
                        (pitched[i] * growl).toInt().coerceIn(-32767, 32767).toShort()
                    }
                }
                VoiceEffectType.GHOST_ECHO -> {
                    val pitched = resamplePitch(input, 0.90f)
                    val tailSamples = (sampleRate * 0.55f).toInt()
                    val out = FloatArray(pitched.size + tailSamples)
                    val d1 = (sampleRate * 0.17f).toInt().coerceAtLeast(1)
                    val d2 = (sampleRate * 0.34f).toInt().coerceAtLeast(1)
                    for (i in out.indices) {
                        var v = if (i < pitched.size) pitched[i].toFloat() else 0f
                        if (i >= d1) v += out[i - d1] * 0.45f
                        if (i >= d2) v += out[i - d2] * 0.25f
                        out[i] = v.coerceIn(-32767f, 32767f)
                    }
                    ShortArray(out.size) { out[it].toInt().toShort() }
                }
                VoiceEffectType.ROBOT -> {
                    ShortArray(input.size) { i ->
                        val t = i.toDouble() / sampleRate.toDouble()
                        val carrier = sin(2.0 * PI * 58.0 * t)
                        val mod = input[i] * (0.45 + 0.55 * carrier)
                        // Subtle bit-crushed metallic edge
                        val stepped = ((mod / 2048.0).toInt() * 2048.0)
                        (mod * 0.72 + stepped * 0.28).toInt().coerceIn(-32767, 32767).toShort()
                    }
                }
                VoiceEffectType.NORMAL -> input
            }
        }

        private fun resamplePitch(input: ShortArray, speedFactor: Float): ShortArray {
            val outLen = (input.size / speedFactor).toInt().coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = i * speedFactor
                val i0 = srcPos.toInt().coerceIn(0, input.lastIndex)
                val i1 = (i0 + 1).coerceAtMost(input.lastIndex)
                val frac = srcPos - i0
                val sample = input[i0] * (1f - frac) + input[i1] * frac
                sample.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        /**
         * Mixes all active WAV tracks into a single mono 44.1kHz PCM16 timeline buffer
         * for real offline AAC audio muxing inside exported MP4 videos.
         */
        fun mixTracksToPcm16(
            tracks: List<AudioTrackItem>,
            totalFrames: Int,
            fps: Int,
            targetSampleRate: Int = 44100,
            startFrameOffset: Int = 0
        ): ShortArray? {
            val active = tracks.filter { !it.muted && it.filePath.isNotBlank() }
            if (active.isEmpty() || totalFrames <= 0) return null
            val durationSec = totalFrames.toDouble() / fps.coerceAtLeast(1).toDouble()
            val totalSamples = (durationSec * targetSampleRate).toInt().coerceAtLeast(1024)
            val mix = FloatArray(totalSamples)
            var wroteAny = false

            for (track in active) {
                val file = File(track.filePath)
                if (!file.exists()) continue
                val bytes = runCatching { file.readBytes() }.getOrNull() ?: continue
                val parsed = parseWavPcm16(bytes) ?: continue
                wroteAny = true

                val relativeStartFrames = track.startFrame - startFrameOffset
                val startSec = relativeStartFrames.toDouble() / fps.coerceAtLeast(1).toDouble()
                val dstStart = (startSec * targetSampleRate).toInt()
                val trimStartSample = ((track.trimStartMs / 1000.0) * parsed.sampleRate).toInt().coerceIn(0, parsed.samples.size)
                val trimEndSample = ((track.trimEndMs / 1000.0) * parsed.sampleRate).toInt().coerceIn(trimStartSample, parsed.samples.size)
                val srcSpan = (trimEndSample - trimStartSample).coerceAtLeast(1)
                val ratio = parsed.sampleRate.toDouble() / targetSampleRate.toDouble()
                val dstSpan = (srcSpan / ratio).toInt().coerceAtLeast(1)
                val fadeInSamples = ((track.fadeInMs / 1000.0) * targetSampleRate).toInt().coerceAtLeast(1)
                val fadeOutSamples = ((track.fadeOutMs / 1000.0) * targetSampleRate).toInt().coerceAtLeast(1)

                for (k in 0 until dstSpan) {
                    val dstIdx = dstStart + k
                    if (dstIdx < 0) continue
                    if (dstIdx >= totalSamples) break
                    val srcPos = trimStartSample + k * ratio
                    val s0 = srcPos.toInt().coerceIn(0, parsed.samples.lastIndex)
                    val s1 = (s0 + 1).coerceAtMost(parsed.samples.lastIndex)
                    val frac = (srcPos - s0).toFloat()
                    var sample = (parsed.samples[s0] * (1f - frac) + parsed.samples[s1] * frac) * track.volume
                    if (k < fadeInSamples) sample *= (k.toFloat() / fadeInSamples)
                    val rem = dstSpan - k
                    if (rem < fadeOutSamples) sample *= (rem.toFloat() / fadeOutSamples)
                    mix[dstIdx] += sample
                }
            }
            if (!wroteAny) return null
            return ShortArray(totalSamples) { mix[it].toInt().coerceIn(-32767, 32767).toShort() }
        }
    }
}
