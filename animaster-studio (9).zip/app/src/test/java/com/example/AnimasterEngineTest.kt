package com.example

import com.example.data.model.AnimationLayer
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.EasingType
import com.example.data.model.EyePackStyle
import com.example.data.model.FrameContent
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.engine.InterpolationEngine
import com.example.engine.MotionPreset
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.engine.StoryboardTemplate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot

class AnimasterEngineTest {

    @Test
    fun interpolation_easingAndKeyframes() {
        val layer = AnimationLayer(
            keyframes = listOf(
                TransformKeyframe(frame = 0, x = 0f, y = 0f, scaleX = 1f, easing = EasingType.LINEAR.name),
                TransformKeyframe(frame = 10, x = 100f, y = -50f, scaleX = 2f, easing = EasingType.LINEAR.name)
            )
        )
        val mid = InterpolationEngine.evaluateLayerTransform(layer, frame = 5, totalFrames = 20)
        assertEquals(50f, mid.x, 0.01f)
        assertEquals(-25f, mid.y, 0.01f)
        assertEquals(1.5f, mid.scaleX, 0.01f)

        // SNAP easing holds 0 until t >= 0.999f
        assertEquals(0f, InterpolationEngine.applyEasing(0.5f, EasingType.SNAP.name), 0.001f)
        assertEquals(1f, InterpolationEngine.applyEasing(1f, EasingType.SNAP.name), 0.001f)
    }

    @Test
    fun interpolation_puppetRootAndAutoLipSync() {
        val rig = RigSolver.createHumanoidRig(rootX = 300f, rootY = 400f).copy(
            rootKeyframes = listOf(
                PuppetRootKeyframe(
                    frame = 0, rootX = 200f, rootY = 400f, scale = 1f,
                    flippedHorizontal = false, eyePack = EyePackStyle.AUTO_BLINK.name,
                    mouthPhoneme = MouthPhoneme.REST.name, easing = EasingType.LINEAR.name
                ),
                PuppetRootKeyframe(
                    frame = 10, rootX = 600f, rootY = 300f, scale = 1.5f,
                    flippedHorizontal = true, eyePack = EyePackStyle.HAPPY.name,
                    mouthPhoneme = MouthPhoneme.A.name, easing = EasingType.LINEAR.name
                )
            )
        )
        val mid = InterpolationEngine.evaluatePuppetRoot(rig, frame = 5)
        assertEquals(400f, mid.rootX, 0.01f)
        assertEquals(350f, mid.rootY, 0.01f)
        assertEquals(1.25f, mid.scale, 0.01f)
        assertFalse(mid.flippedHorizontal)

        val end = InterpolationEngine.evaluatePuppetRoot(rig, frame = 10)
        assertTrue(end.flippedHorizontal)
        assertEquals(EyePackStyle.HAPPY.name, end.eyePack)
        assertEquals(MouthPhoneme.A.name, end.mouthPhoneme)

        val quietTrack = AudioTrackItem(
            kind = AudioTrackKind.VOICE.name,
            startFrame = 0,
            trimStartMs = 0L,
            trimEndMs = 1000L,
            waveformPeaks = listOf(0.05f, 0.40f, 0.85f)
        )
        assertEquals(MouthPhoneme.REST, InterpolationEngine.evaluateLipSyncPhoneme(listOf(quietTrack), frame = 0, fps = 24))
        assertEquals(MouthPhoneme.A, InterpolationEngine.evaluateLipSyncPhoneme(listOf(quietTrack), frame = 20, fps = 24))
    }

    @Test
    fun rigSolver_fkTwoBoneIkAndAutoWalk() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 400f)
        val fk = RigSolver.solveForwardKinematics(rig)
        assertEquals(rig.bones.size, fk.size)

        val currentAngles = rig.bones.associate { it.id to it.localAngleDeg }
        val target = Vec2(600f, 340f)
        val solvedAngles = RigSolver.solveDragTarget(rig, "arm_r_low", target, currentAngles, useIk = true)
        val fkAfter = RigSolver.solveForwardKinematics(rig, solvedAngles)
        val hand = fkAfter.first { it.bone.id == "arm_r_low" }
        assertTrue(hypot(hand.end.x - target.x, hand.end.y - target.y) < 35f)

        val walkA = RigSolver.computeAutoWalkPose(travelX = 24f)
        val walkB = RigSolver.computeAutoWalkPose(travelX = 120f)
        assertNotEquals(walkA["leg_l_up"], walkB["leg_l_up"])
        assertNotEquals(walkA["arm_r_up"], walkB["arm_r_up"])
    }

    @Test
    fun proceduralTemplatesCameraToolsAndSvgParser() {
        val proj = ProceduralSmartTools.createProjectFromTemplate("Test", 1280, 720, 24, StoryboardTemplate.THREE_ACT_STORY)
        assertEquals(3, proj.scenes.size)

        val heroProj = ProceduralSmartTools.createProjectFromTemplate("Hero", 1280, 720, 24, StoryboardTemplate.HERO_DEMO)
        assertEquals(96, heroProj.scenes.first().durationFrames)
        assertTrue(heroProj.scenes.first().layers.count { it.rig != null } >= 2)

        val rigLayer = heroProj.scenes.first().layers.first { it.rig != null }
        val followed = ProceduralSmartTools.applyCameraFollowCharacter(heroProj.scenes.first(), rigLayer.id, 1280, 720)
        assertTrue(followed.cameraKeyframes.size >= 4)

        val shaken = ProceduralSmartTools.applyCameraShake(heroProj.scenes.first(), startFrame = 12, intensity = 24f)
        assertTrue(shaken.cameraKeyframes.size >= 6)

        val movedLayer = ProceduralSmartTools.applyMotionPreset(AnimationLayer(), MotionPreset.BOUNCE_LOOP, 36)
        assertTrue(movedLayer.keyframes.size >= 3)

        val svg = """<svg><rect x="10" y="20" width="100" height="50"/><circle cx="60" cy="60" r="30"/></svg>"""
        val shapes = SceneRenderer.parseSimpleSvgShapes(svg, 1280f, 720f)
        assertEquals(2, shapes.size)
    }

    @Test
    fun voiceChangerDsp_andHorrorStoryTemplate() {
        val sampleRate = 22050
        val input = ShortArray(4096) { i ->
            (kotlin.math.sin(2.0 * kotlin.math.PI * 220.0 * i / sampleRate) * 16000.0).toInt().toShort()
        }
        val chipmunk = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.CHIPMUNK
        )
        val monster = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.DEEP_MONSTER
        )
        val ghost = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.GHOST_ECHO
        )
        val robot = com.example.engine.AudioStudioEngine.processVoicePcm16(
            input, sampleRate, com.example.data.model.VoiceEffectType.ROBOT
        )
        assertTrue(chipmunk.size < input.size)
        assertTrue(monster.size > input.size)
        assertTrue(ghost.size > input.size)
        assertEquals(input.size, robot.size)

        val horror = ProceduralSmartTools.createProjectFromTemplate(
            "Haunted Ep 1", 1280, 720, 24, StoryboardTemplate.HORROR_STORY
        )
        val sc = horror.scenes.first()
        assertTrue(sc.backgroundScrollSpeed > 0f)
        assertTrue(sc.subtitles.size >= 2)
        assertTrue(sc.layers.any { it.opacity < 0.7f && it.rig != null })
    }

    @Test
    fun animatedTextModel_supportsAllKineticOptions() {
        val item = com.example.data.model.CanvasTextItem(
            text = "SUBSCRIBE\nNOW!",
            x = 640f,
            y = 220f,
            fontSize = 72f,
            colorArgb = 0xFFFFE066L,
            gradientEndArgb = 0xFFFF6B35L,
            fontStyle = com.example.data.model.TextFontStyle.BOLD_CARTOON.name,
            boxStyle = com.example.data.model.TextBoxStyle.YOUTUBE_PILL.name,
            inAnimation = com.example.data.model.TextInAnimation.TYPEWRITER.name,
            loopAnimation = com.example.data.model.TextLoopAnimation.WAVE.name,
            outAnimation = com.example.data.model.TextOutAnimation.POP_OUT.name,
            startFrame = 10,
            endFrame = 80
        )
        assertEquals(10, item.startFrame)
        assertEquals(80, item.endFrame)
        assertEquals(9, com.example.data.model.TextInAnimation.entries.size)
        assertEquals(8, com.example.data.model.TextLoopAnimation.entries.size)
        assertEquals(5, com.example.data.model.TextOutAnimation.entries.size)
    }

    @Test
    fun humanAutoRig_extremityIk_turnaroundAndHandProps() {
        val rig = RigSolver.createHumanoidRig(rootX = 500f, rootY = 420f)
        val expectedIds = setOf(
            "spine", "neck",
            "arm_l_up", "arm_l_low", "hand_l",
            "arm_r_up", "arm_r_low", "hand_r",
            "leg_l_up", "leg_l_low", "foot_l",
            "leg_r_up", "leg_r_low", "foot_r"
        )
        assertEquals(14, rig.bones.size)
        assertEquals(expectedIds, rig.bones.map { it.id }.toSet())
        assertTrue(rig.bones.all { it.minAngleDeg < it.maxAngleDeg })

        // Pulling hand_r with IK enabled should drive arm_r_up & arm_r_low smoothly
        val initialAngles = rig.bones.associate { it.id to it.localAngleDeg }
        val handTarget = Vec2(620f, 340f)
        val ikAngles = RigSolver.solveDragTarget(rig, "hand_r", handTarget, initialAngles, useIk = true)
        val fkAfterHand = RigSolver.solveForwardKinematics(rig, ikAngles)
        val wristEnd = fkAfterHand.first { it.bone.id == "arm_r_low" }.end
        assertTrue(hypot(wristEnd.x - handTarget.x, wristEnd.y - handTarget.y) < 40f)

        // Auto-rigging an older/minimal rig upgrades it to 14 human joints while preserving turnaround & hand props
        val minimalRig = rig.copy(
            bones = rig.bones.take(3),
            viewAngle = com.example.data.model.CharacterViewAngle.SIDE_RIGHT.name,
            leftHandProp = com.example.data.model.HandPropKind.LANTERN.name,
            rightHandProp = com.example.data.model.HandPropKind.SWORD.name
        )
        val autoRigged = RigSolver.autoRigHumanoid(minimalRig)
        assertEquals(14, autoRigged.bones.size)
        assertEquals(com.example.data.model.CharacterViewAngle.SIDE_RIGHT.name, autoRigged.viewAngle)
        assertEquals(com.example.data.model.HandPropKind.LANTERN.name, autoRigged.leftHandProp)
        assertEquals(com.example.data.model.HandPropKind.SWORD.name, autoRigged.rightHandProp)

        // 4-view turnaround propagates accurately across puppet root keyframes
        val turnaroundRig = autoRigged.copy(
            rootKeyframes = listOf(
                PuppetRootKeyframe(
                    frame = 0, rootX = 400f, rootY = 420f,
                    viewAngle = com.example.data.model.CharacterViewAngle.FRONT.name
                ),
                PuppetRootKeyframe(
                    frame = 12, rootX = 520f, rootY = 420f,
                    viewAngle = com.example.data.model.CharacterViewAngle.SIDE_LEFT.name
                ),
                PuppetRootKeyframe(
                    frame = 24, rootX = 640f, rootY = 420f,
                    viewAngle = com.example.data.model.CharacterViewAngle.BACK.name
                )
            )
        )
        assertEquals(
            com.example.data.model.CharacterViewAngle.FRONT.name,
            InterpolationEngine.evaluatePuppetRoot(turnaroundRig, frame = 4).viewAngle
        )
        assertEquals(
            com.example.data.model.CharacterViewAngle.SIDE_LEFT.name,
            InterpolationEngine.evaluatePuppetRoot(turnaroundRig, frame = 15).viewAngle
        )
        assertEquals(
            com.example.data.model.CharacterViewAngle.BACK.name,
            InterpolationEngine.evaluatePuppetRoot(turnaroundRig, frame = 30).viewAngle
        )
        assertEquals(4, com.example.data.model.CharacterViewAngle.entries.size)
        assertEquals(10, com.example.data.model.HandPropKind.entries.size)
    }

    @Test
    fun nonHumanRigs_customBones_facialExpressions_andCameraDirector() {
        val bird = RigSolver.createBirdWingedRig()
        assertEquals("BIRD", bird.rigCategory)
        assertTrue(bird.bones.any { it.id == "wing_l_tip" })
        assertTrue(bird.bones.any { it.id == "wing_r_tip" })
        assertTrue(RigSolver.presetPoseAngles("FLAP_UP").containsKey("wing_l_in"))
        assertTrue(RigSolver.presetPoseAngles("FLAP_DOWN").containsKey("wing_r_in"))

        val quad = RigSolver.createQuadrupedAnimalRig()
        assertEquals("QUADRUPED", quad.rigCategory)
        assertEquals(12, quad.bones.size)

        val customObj = RigSolver.createCustomObjectRig()
        assertEquals("CUSTOM_OBJECT", customObj.rigCategory)
        val (expandedRig, addedBone) = RigSolver.addCustomBoneAtPoint(
            rig = customObj,
            parentBoneId = "tip_1",
            tapWorldPoint = Vec2(780f, 320f)
        )
        assertEquals(customObj.bones.size + 1, expandedRig.bones.size)
        assertEquals("tip_1", addedBone.parentId)
        assertTrue(addedBone.length in 22f..260f)

        // Unrestricted mesh & face overlay alignment defaults on SkeletalRig
        assertEquals(1.0f, bird.singleMeshScale, 0.001f)
        assertEquals(1.0f, bird.faceOverlayScale, 0.001f)

        // New live animated expression enums
        assertTrue(EyePackStyle.entries.contains(EyePackStyle.LAUGHING))
        assertTrue(EyePackStyle.entries.contains(EyePackStyle.SCARED_HORROR))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.TALKING_LOOP))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.LAUGHING))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.CRYING))
        assertTrue(MouthPhoneme.entries.contains(MouthPhoneme.SCARED))

        // Camera Director Dolly Zoom & Pan Across presets
        val proj = ProceduralSmartTools.createProjectFromTemplate("CamTest", 1280, 720, 24, StoryboardTemplate.HERO_DEMO)
        val scene = proj.scenes.first()
        val dolly = ProceduralSmartTools.applyCameraDollyZoom(scene, startFrame = 0, targetZoom = 2.0f)
        assertTrue(dolly.cameraKeyframes.size >= 2)
        assertTrue(InterpolationEngine.evaluateCamera(dolly, frame = 36).zoom > 1.8f)

        val panned = ProceduralSmartTools.applyCameraPanAcross(scene, startFrame = 0, logicalWidth = 1280)
        val startCam = InterpolationEngine.evaluateCamera(panned, frame = 0)
        val endCam = InterpolationEngine.evaluateCamera(panned, frame = 48)
        assertTrue(startCam.panX < 0f && endCam.panX > 0f)
    }

    @Test
    fun smoothMotionPathFollowing_forObjectsAndRiggedPuppets() {
        val curvedPath = listOf(
            Vec2(120f, 500f),
            Vec2(420f, 260f),
            Vec2(820f, 520f),
            Vec2(1140f, 300f)
        )
        val s0 = InterpolationEngine.sampleSmoothPath(curvedPath, 0f)
        val sMid = InterpolationEngine.sampleSmoothPath(curvedPath, 0.5f)
        val s1 = InterpolationEngine.sampleSmoothPath(curvedPath, 1f)
        assertEquals(120f, s0.position.x, 1.5f)
        assertEquals(500f, s0.position.y, 1.5f)
        assertEquals(1140f, s1.position.x, 1.5f)
        assertEquals(300f, s1.position.y, 1.5f)
        assertTrue(sMid.position.x in 420f..820f)
        assertTrue(sMid.totalLength > 1000f)

        // Rigged puppet smoothly follows the exact path coordinates & auto-walks along traveled distance
        val rig = RigSolver.createHumanoidRig(rootX = 640f, rootY = 400f).copy(autoWalkWhenDragged = true)
        val rigLayer = AnimationLayer(
            name = "Hero",
            type = LayerType.RIG.name,
            rig = rig,
            motionPath = curvedPath,
            motionPathOrientToPath = true,
            motionPathEasing = EasingType.LINEAR.name
        )
        val rootStart = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, frame = 0, totalFrames = 49)
        val rootMid = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, frame = 24, totalFrames = 49)
        val rootEnd = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, frame = 48, totalFrames = 49)
        assertEquals(120f, rootStart.rootX, 2f)
        assertEquals(500f, rootStart.rootY, 2f)
        assertEquals(1140f, rootEnd.rootX, 2f)
        assertEquals(300f, rootEnd.rootY, 2f)
        assertTrue(rootMid.rootX > rootStart.rootX && rootMid.rootX < rootEnd.rootX)
        // Moving left-to-right should face right (flippedHorizontal = false)
        assertEquals(false, rootMid.flippedHorizontal)

        // Non-rig drawing/object aligns directly ON the drawn path instead of drifting off-screen
        val shapeLayer = AnimationLayer(
            name = "Ball",
            type = LayerType.DRAWING.name,
            frames = mapOf(
                "0" to FrameContent(
                    shapes = listOf(VectorShape(startX = 600f, startY = 300f, endX = 680f, endY = 380f))
                )
            ),
            motionPath = curvedPath,
            motionPathOrientToPath = true,
            motionPathEasing = EasingType.LINEAR.name
        )
        val tfStart = InterpolationEngine.evaluateLayerTransform(shapeLayer, frame = 0, totalFrames = 49)
        val tfEnd = InterpolationEngine.evaluateLayerTransform(shapeLayer, frame = 48, totalFrames = 49)
        // Visual center was (640, 340); at frame 0 it moves directly to (120, 500) -> delta (-520, +160)
        assertEquals(120f - 640f, tfStart.x, 2f)
        assertEquals(500f - 340f, tfStart.y, 2f)
        assertEquals(1140f - 640f, tfEnd.x, 2f)
        assertEquals(300f - 340f, tfEnd.y, 2f)
    }

    @Test
    fun extraVariableRigAndCustomAssetGrafting_worksOnAllAreas() {
        val hero = RigSolver.createHumanoidRig()
        // Attach a Sword extra variable rig onto Right Hand
        val (withHandProp, handBone) = RigSolver.createExtraVariableBone(
            rig = hero,
            area = com.example.engine.RigAttachmentArea.RIGHT_HAND,
            propKind = com.example.data.model.HandPropKind.SWORD
        )
        assertEquals("hand_r", handBone.parentId)
        assertTrue(handBone.isExtraRigBone)
        assertEquals(com.example.data.model.HandPropKind.SWORD.name, handBone.attachedPropKind)

        // Attach an extra variable rig bone onto Left Leg / Foot
        val (withLegRig, legBone) = RigSolver.createExtraVariableBone(
            rig = withHandProp,
            area = com.example.engine.RigAttachmentArea.LEFT_LEG
        )
        assertEquals("foot_l", legBone.parentId)
        assertTrue(legBone.isExtraRigBone)

        // Create a multi-bone Reusable Custom Asset and graft it onto Chest/Back (e.g. wings/cape)
        val customAsset = RigSolver.createCustomAssetStarterRig(name = "Jetpack Wings")
        assertEquals("ASSET", customAsset.rigCategory)
        assertEquals(2, customAsset.bones.size)

        val (graftedHero, rootAttached) = RigSolver.graftCustomAssetOntoRig(
            targetRig = withLegRig,
            assetRig = customAsset,
            area = com.example.engine.RigAttachmentArea.CHEST_BACK
        )
        assertEquals(withLegRig.bones.size + customAsset.bones.size, graftedHero.bones.size)
        assertEquals("spine", rootAttached?.parentId)
        val solved = RigSolver.solveForwardKinematics(graftedHero)
        assertEquals(graftedHero.bones.size, solved.size)
    }

    @Test
    fun exactDrawingCoordinateMapping_hasZeroOffsetUnderTransformsAndParallax() {
        val projW = 1280f
        val projH = 720f
        val originX = 48.5f
        val originY = 92.25f
        val totalScale = 0.78f
        val cam = com.example.engine.EvaluatedCamera(
            panX = 115f,
            panY = -64f,
            zoom = 1.45f,
            rotationDeg = 18f
        )
        val layerTf = com.example.engine.EvaluatedTransform(
            x = -85f,
            y = 42f,
            rotationDeg = -27f,
            scaleX = 1.35f,
            scaleY = 0.85f,
            opacity = 1f
        )
        val bgShiftX = -140f

        listOf(0.65f, 1.0f, 1.35f).forEach { parallax ->
            // Simulate user touching at exact pixel (30f, 30f), (450f, 290f), (910f, 520f)
            listOf(Vec2(30f, 30f), Vec2(450f, 290f), Vec2(910f, 520f)).forEach { touchPx ->
                val localPt = InterpolationEngine.canvasPxToLayerLocal(
                    canvasPxX = touchPx.x,
                    canvasPxY = touchPx.y,
                    projectWidth = projW,
                    projectHeight = projH,
                    originX = originX,
                    originY = originY,
                    totalScale = totalScale,
                    camera = cam,
                    parallax = parallax,
                    layerTransform = layerTf,
                    bgAutoShiftX = bgShiftX
                )
                val renderedPx = InterpolationEngine.layerLocalToCanvasPx(
                    localPt = localPt,
                    projectWidth = projW,
                    projectHeight = projH,
                    originX = originX,
                    originY = originY,
                    totalScale = totalScale,
                    camera = cam,
                    parallax = parallax,
                    layerTransform = layerTf,
                    bgAutoShiftX = bgShiftX
                )
                assertEquals("X must match touch pixel exactly (parallax=$parallax)", touchPx.x, renderedPx.x, 0.05f)
                assertEquals("Y must match touch pixel exactly (parallax=$parallax)", touchPx.y, renderedPx.y, 0.05f)
            }
        }
    }

    @Test
    fun expandedWeatherAndSunlightVfxTypes_areAvailable() {
        val vfx = com.example.data.model.SceneVfxType.entries
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.STORM))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.HEAVY_RAIN))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.HIGH_SUNLIGHT))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.GOLDEN_HOUR))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.RAINBOW))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.AURORA))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.AUTUMN_LEAVES))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.STARLIGHT))
        assertTrue(vfx.contains(com.example.data.model.SceneVfxType.FIRE_EMBERS))
        assertTrue(vfx.size >= 20)
    }
}
