package com.example.engine

import android.graphics.RectF
import com.example.data.model.CharacterSpec
import com.example.data.model.EyePackStyle
import com.example.data.model.HandPropKind
import com.example.data.model.MouthPhoneme
import com.example.data.model.RigBone
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import java.util.UUID
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class RigAttachmentArea(
    val label: String,
    val shortLabel: String,
    val candidateBoneIds: List<String>,
    val defaultAngleDeg: Float
) {
    RIGHT_HAND("Right Hand", "R-Hand", listOf("hand_r", "arm_r_low", "arm_r_up"), -35f),
    LEFT_HAND("Left Hand", "L-Hand", listOf("hand_l", "arm_l_low", "arm_l_up"), 35f),
    RIGHT_LEG("Right Leg / Foot", "R-Leg", listOf("foot_r", "leg_r_low", "leg_r_up"), 15f),
    LEFT_LEG("Left Leg / Foot", "L-Leg", listOf("foot_l", "leg_l_low", "leg_l_up"), -15f),
    HEAD("Head / Hat / Hair", "Head", listOf("neck"), -15f),
    CHEST_BACK("Chest / Wings / Cape", "Chest", listOf("spine"), 145f),
    HIP_WAIST("Hip / Tail / Waist", "Hip", emptyList(), 155f),
    SELECTED_BONE("Selected Bone", "Selected", emptyList(), 25f)
}

data class SolvedBone(
    val bone: RigBone,
    val start: Vec2,
    val end: Vec2,
    val worldAngleDeg: Float
)

object RigSolver {

    /**
     * Computes Forward Kinematics (FK) world coordinates for every bone in the rig,
     * honoring animated root position, scale, and horizontal mirroring.
     */
    fun solveForwardKinematics(
        rig: SkeletalRig,
        angleOverrides: Map<String, Float> = emptyMap(),
        rootX: Float = rig.rootX,
        rootY: Float = rig.rootY,
        scale: Float = rig.scale,
        flippedHorizontal: Boolean = rig.flippedHorizontal
    ): List<SolvedBone> {
        val boneMap = rig.bones.associateBy { it.id }
        val solved = LinkedHashMap<String, SolvedBone>()

        fun resolve(bone: RigBone): SolvedBone {
            solved[bone.id]?.let { return it }
            val localAngle = angleOverrides[bone.id] ?: bone.localAngleDeg
            val parentSolved = bone.parentId?.let { pid -> boneMap[pid]?.let { resolve(it) } }
            val start = parentSolved?.end ?: Vec2(rootX, rootY)
            val worldAngleDeg = (parentSolved?.worldAngleDeg ?: 0f) + localAngle
            val rad = Math.toRadians(worldAngleDeg.toDouble())
            val dx = (cos(rad) * bone.length * scale).toFloat() * (if (flippedHorizontal) -1f else 1f)
            val dy = (sin(rad) * bone.length * scale).toFloat()
            val end = Vec2(start.x + dx, start.y + dy)
            val displayAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            val result = SolvedBone(bone, start, end, if (flippedHorizontal) displayAngle else worldAngleDeg)
            solved[bone.id] = result
            return result
        }

        rig.bones.forEach { resolve(it) }
        return rig.bones.mapNotNull { solved[it.id] }
    }

    /**
     * Solves 2-bone analytical Inverse Kinematics (IK) when dragging a child bone's tip
     * toward [target], supporting scaled and horizontally flipped puppets.
     */
    fun solveDragTarget(
        rig: SkeletalRig,
        boneId: String,
        target: Vec2,
        currentAngles: Map<String, Float>,
        useIk: Boolean,
        rootX: Float = rig.rootX,
        rootY: Float = rig.rootY,
        scale: Float = rig.scale,
        flippedHorizontal: Boolean = rig.flippedHorizontal
    ): Map<String, Float> {
        // Mirror target into unflipped local puppet coordinate space so math stays clean
        val localTarget = if (flippedHorizontal) {
            Vec2(rootX - (target.x - rootX), target.y)
        } else {
            target
        }

        // If user drags an extremity bone (hand_l/hand_r/foot_l/foot_r) with IK enabled,
        // redirect 2-bone IK cleanly to the forearm/shin chain so pulling the hand pulls the whole arm naturally!
        val effectiveBoneId = if (useIk) {
            when (boneId) {
                "hand_l" -> if (rig.bones.any { it.id == "arm_l_low" }) "arm_l_low" else boneId
                "hand_r" -> if (rig.bones.any { it.id == "arm_r_low" }) "arm_r_low" else boneId
                "foot_l" -> if (rig.bones.any { it.id == "leg_l_low" }) "leg_l_low" else boneId
                "foot_r" -> if (rig.bones.any { it.id == "leg_r_low" }) "leg_r_low" else boneId
                else -> boneId
            }
        } else boneId

        val solvedList = solveForwardKinematics(rig, currentAngles, rootX, rootY, scale, false)
        val solvedMap = solvedList.associateBy { it.bone.id }
        val targetSolved = solvedMap[effectiveBoneId] ?: return currentAngles
        val bone = targetSolved.bone
        val parentSolved = bone.parentId?.let { solvedMap[it] }

        // 1-bone FK aim when IK disabled or root/spine/neck bone
        if (!useIk || parentSolved == null || parentSolved.bone.parentId == null) {
            val dx = localTarget.x - targetSolved.start.x
            val dy = localTarget.y - targetSolved.start.y
            val desiredWorld = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            val parentWorld = parentSolved?.worldAngleDeg ?: 0f
            val clamped = normalizeAngle(desiredWorld - parentWorld)
                .coerceIn(bone.minAngleDeg, bone.maxAngleDeg)
            return currentAngles + (bone.id to clamped)
        }

        // 2-bone analytical IK on (parentBone -> bone) with anatomical joint constraints
        val grandParentWorld = parentSolved.bone.parentId?.let { solvedMap[it]?.worldAngleDeg } ?: 0f
        val rootPos = parentSolved.start
        val l1 = (parentSolved.bone.length * scale).coerceAtLeast(1f)
        val l2 = (bone.length * scale).coerceAtLeast(1f)
        val dx = localTarget.x - rootPos.x
        val dy = localTarget.y - rootPos.y
        val dist = hypot(dx, dy).coerceIn(kotlin.math.abs(l1 - l2) + 1f, l1 + l2 - 0.5f)

        val baseAngle = atan2(dy.toDouble(), dx.toDouble())
        val cosA = ((l1 * l1 + dist * dist - l2 * l2) / (2f * l1 * dist)).toDouble().coerceIn(-1.0, 1.0)
        val cosB = ((l1 * l1 + l2 * l2 - dist * dist) / (2f * l1 * l2)).toDouble().coerceIn(-1.0, 1.0)
        val angleA = acos(cosA)
        val angleB = acos(cosB)

        val bendSign = if ((currentAngles[bone.id] ?: bone.localAngleDeg) >= 0f) 1.0 else -1.0
        val worldParent = Math.toDegrees(baseAngle - bendSign * angleA).toFloat()
        val localParent = normalizeAngle(worldParent - grandParentWorld)
            .coerceIn(parentSolved.bone.minAngleDeg, parentSolved.bone.maxAngleDeg)
        val localChild = normalizeAngle(Math.toDegrees(bendSign * (PI - angleB)).toFloat())
            .coerceIn(bone.minAngleDeg, bone.maxAngleDeg)

        return currentAngles + mapOf(
            parentSolved.bone.id to localParent,
            bone.id to localChild
        )
    }

    /**
     * Generates smooth alternating walking limb angles driven by horizontal travel distance
     * ("Auto-Walk When Dragged" puppet animation mode).
     */
    fun computeAutoWalkPose(travelX: Float): Map<String, Float> {
        val phase = (travelX / 48f).toDouble()
        val swing = sin(phase).toFloat()
        val lift = cos(phase).toFloat()
        return mapOf(
            "spine" to (-90f + swing * 4f),
            "neck" to (-swing * 3f),
            "arm_l_up" to (-135f + swing * 28f),
            "arm_l_low" to (24f + kotlin.math.max(0f, swing) * 20f),
            "arm_r_up" to (135f + swing * 28f),
            "arm_r_low" to (-24f - kotlin.math.max(0f, -swing) * 20f),
            "leg_l_up" to (96f - swing * 32f),
            "leg_l_low" to (-10f - kotlin.math.max(0f, lift) * 26f),
            "leg_r_up" to (84f + swing * 32f),
            "leg_r_low" to (10f + kotlin.math.max(0f, -lift) * 26f)
        )
    }

    /**
     * True 2D Linear Blend Skinning (LBS) for Canvas.drawBitmapMesh.
     * Computes deformed mesh vertices from rest-pose bones to current posed bones so a single
     * character PNG bends and flexes naturally when IK handles are dragged.
     */
    fun computeDeformedMeshVertices(
        restBones: List<SolvedBone>,
        currentBones: List<SolvedBone>,
        meshRect: RectF,
        cols: Int = 8,
        rows: Int = 8
    ): FloatArray {
        val verts = FloatArray((cols + 1) * (rows + 1) * 2)
        val restMap = restBones.associateBy { it.bone.id }
        val pairs = currentBones.mapNotNull { cur -> restMap[cur.bone.id]?.let { rest -> rest to cur } }

        var idx = 0
        for (r in 0..rows) {
            val vFrac = r.toFloat() / rows.toFloat()
            val restY = meshRect.top + vFrac * meshRect.height()
            for (c in 0..cols) {
                val uFrac = c.toFloat() / cols.toFloat()
                val restX = meshRect.left + uFrac * meshRect.width()

                if (pairs.isEmpty()) {
                    verts[idx++] = restX
                    verts[idx++] = restY
                    continue
                }

                var sumX = 0f
                var sumY = 0f
                var sumW = 0f

                for ((restB, curB) in pairs) {
                    val dist = pointToSegmentDist(restX, restY, restB.start.x, restB.start.y, restB.end.x, restB.end.y)
                    val w = 1f / ((dist * dist) / 1400f + 0.08f)

                    val restAngle = atan2((restB.end.y - restB.start.y).toDouble(), (restB.end.x - restB.start.x).toDouble())
                    val curAngle = atan2((curB.end.y - curB.start.y).toDouble(), (curB.end.x - curB.start.x).toDouble())
                    val dTheta = curAngle - restAngle

                    val rx = restX - restB.start.x
                    val ry = restY - restB.start.y
                    val cosT = cos(dTheta).toFloat()
                    val sinT = sin(dTheta).toFloat()

                    val tx = curB.start.x + (rx * cosT - ry * sinT)
                    val ty = curB.start.y + (rx * sinT + ry * cosT)

                    sumX += tx * w
                    sumY += ty * w
                    sumW += w
                }

                verts[idx++] = if (sumW > 0f) sumX / sumW else restX
                verts[idx++] = if (sumW > 0f) sumY / sumW else restY
            }
        }
        return verts
    }

    private fun pointToSegmentDist(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq <= 0.001f) return hypot(px - x1, py - y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lenSq).coerceIn(0f, 1f)
        val projX = x1 + t * dx
        val projY = y1 + t * dy
        return hypot(px - projX, py - projY)
    }

    private fun normalizeAngle(deg: Float): Float {
        var a = deg % 360f
        if (a > 180f) a -= 360f
        if (a < -180f) a += 360f
        return a
    }

    /**
     * Full 14-Bone Anatomical Human Auto-Rig:
     * Separate Torso/Spine, Head, L/R Upper Arm, L/R Forearm, L/R Hand (prop socket),
     * L/R Thigh, L/R Shin, and L/R Foot with natural human joint constraints.
     */
    fun createHumanoidRig(
        name: String = "Hero Rig",
        rootX: Float = 640f,
        rootY: Float = 400f,
        characterAppearance: CharacterSpec? = null
    ): SkeletalRig {
        val shirtColor = characterAppearance?.shirtColorArgb ?: 0xFFFF6B35L
        val skinColor = characterAppearance?.skinToneArgb ?: 0xFFF5C6A5L
        val pantsColor = characterAppearance?.pantsColorArgb ?: 0xFF312E81L
        val shoeColor = 0xFF1E293BL

        val bones = listOf(
            RigBone(id = "spine", name = "Torso / Spine", parentId = null, length = 90f, localAngleDeg = -90f, thickness = 36f, colorArgb = shirtColor, minAngleDeg = -135f, maxAngleDeg = -45f),
            RigBone(id = "neck", name = "Head", parentId = "spine", length = 64f, localAngleDeg = 0f, thickness = 44f, colorArgb = skinColor, minAngleDeg = -55f, maxAngleDeg = 55f),
            RigBone(id = "arm_l_up", name = "L Upper Arm", parentId = "spine", length = 60f, localAngleDeg = -138f, thickness = 18f, colorArgb = shirtColor),
            RigBone(id = "arm_l_low", name = "L Forearm", parentId = "arm_l_up", length = 50f, localAngleDeg = 22f, thickness = 15f, colorArgb = skinColor, minAngleDeg = -150f, maxAngleDeg = 150f),
            RigBone(id = "hand_l", name = "L Hand", parentId = "arm_l_low", length = 22f, localAngleDeg = 8f, thickness = 16f, colorArgb = skinColor, minAngleDeg = -85f, maxAngleDeg = 85f),
            RigBone(id = "arm_r_up", name = "R Upper Arm", parentId = "spine", length = 60f, localAngleDeg = 138f, thickness = 18f, colorArgb = shirtColor),
            RigBone(id = "arm_r_low", name = "R Forearm", parentId = "arm_r_up", length = 50f, localAngleDeg = -22f, thickness = 15f, colorArgb = skinColor, minAngleDeg = -150f, maxAngleDeg = 150f),
            RigBone(id = "hand_r", name = "R Hand", parentId = "arm_r_low", length = 22f, localAngleDeg = -8f, thickness = 16f, colorArgb = skinColor, minAngleDeg = -85f, maxAngleDeg = 85f),
            RigBone(id = "leg_l_up", name = "L Thigh", parentId = null, length = 76f, localAngleDeg = 104f, thickness = 22f, colorArgb = pantsColor),
            RigBone(id = "leg_l_low", name = "L Shin", parentId = "leg_l_up", length = 68f, localAngleDeg = -10f, thickness = 18f, colorArgb = pantsColor, minAngleDeg = -145f, maxAngleDeg = 145f),
            RigBone(id = "foot_l", name = "L Foot", parentId = "leg_l_low", length = 24f, localAngleDeg = -75f, thickness = 16f, colorArgb = shoeColor, minAngleDeg = -115f, maxAngleDeg = 60f),
            RigBone(id = "leg_r_up", name = "R Thigh", parentId = null, length = 76f, localAngleDeg = 76f, thickness = 22f, colorArgb = pantsColor),
            RigBone(id = "leg_r_low", name = "R Shin", parentId = "leg_r_up", length = 68f, localAngleDeg = 10f, thickness = 18f, colorArgb = pantsColor, minAngleDeg = -145f, maxAngleDeg = 145f),
            RigBone(id = "foot_r", name = "R Foot", parentId = "leg_r_low", length = 24f, localAngleDeg = 75f, thickness = 16f, colorArgb = shoeColor, minAngleDeg = -60f, maxAngleDeg = 115f)
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            viewAngle = characterAppearance?.viewAngle ?: com.example.data.model.CharacterViewAngle.FRONT.name,
            bones = bones,
            characterAppearance = characterAppearance,
            eyePack = characterAppearance?.eyePack ?: EyePackStyle.AUTO_BLINK.name,
            mouthPhoneme = characterAppearance?.mouthPhoneme ?: MouthPhoneme.AUTO_LIPSYNC.name
        )
    }

    /**
     * Automatically upgrades/fits a full 14-bone human skeleton onto ANY existing rig or imported PNG character,
     * preserving existing PNG part bindings, single-mesh image, hand props, view angle, and facial packs.
     */
    fun autoRigHumanoid(existing: SkeletalRig): SkeletalRig {
        val base = createHumanoidRig(
            name = existing.name,
            rootX = existing.rootX,
            rootY = existing.rootY,
            characterAppearance = existing.characterAppearance
        )
        val oldMap = existing.bones.associateBy { it.id }
        val mergedBones = base.bones.map { b ->
            val old = oldMap[b.id]
            if (old != null) {
                b.copy(
                    boundImagePath = old.boundImagePath,
                    imageScale = old.imageScale,
                    pivotOffsetX = old.pivotOffsetX,
                    pivotOffsetY = old.pivotOffsetY,
                    imageRotationOffsetDeg = old.imageRotationOffsetDeg
                )
            } else b
        }
        return existing.copy(
            bones = mergedBones,
            ikEnabled = true,
            showSkinMesh = true
        )
    }

    fun createRiggedCharacterFromSpec(spec: CharacterSpec, rootX: Float = 640f, rootY: Float = 410f): SkeletalRig {
        return createHumanoidRig(
            name = spec.name,
            rootX = rootX,
            rootY = rootY,
            characterAppearance = spec
        )
    }

    fun createCartoonMascotRig(rootX: Float = 640f, rootY: Float = 420f): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Body", parentId = null, length = 70f, localAngleDeg = -90f, thickness = 44f, colorArgb = 0xFFFBBF24L),
            RigBone(id = "neck", name = "Head", parentId = "spine", length = 56f, localAngleDeg = 0f, thickness = 50f, colorArgb = 0xFFFDE68AL),
            RigBone(id = "ear_l", name = "L Ear", parentId = "neck", length = 42f, localAngleDeg = -35f, thickness = 14f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "ear_r", name = "R Ear", parentId = "neck", length = 42f, localAngleDeg = 35f, thickness = 14f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "arm_l_up", name = "L Arm", parentId = "spine", length = 54f, localAngleDeg = -125f, thickness = 15f, colorArgb = 0xFF34D399L),
            RigBone(id = "arm_r_up", name = "R Arm", parentId = "spine", length = 54f, localAngleDeg = 125f, thickness = 15f, colorArgb = 0xFF34D399L),
            RigBone(id = "leg_l_up", name = "L Leg", parentId = null, length = 56f, localAngleDeg = 110f, thickness = 17f, colorArgb = 0xFF38BDF8L),
            RigBone(id = "leg_r_up", name = "R Leg", parentId = null, length = 56f, localAngleDeg = 70f, thickness = 17f, colorArgb = 0xFF38BDF8L)
        )
        return SkeletalRig(name = "Cartoon Mascot", rootX = rootX, rootY = rootY, bones = bones, rigCategory = "CUSTOM_OBJECT")
    }

    /**
     * Non-Human Bird / Winged Creature Starter Rig:
     * Body, Head/Beak, Left & Right 2-bone flapping wings, Tail feathers, and Legs.
     */
    fun createBirdWingedRig(
        name: String = "Bird / Winged Rig",
        rootX: Float = 640f,
        rootY: Float = 380f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Body", parentId = null, length = 74f, localAngleDeg = -15f, thickness = 34f, colorArgb = 0xFF38BDF8L),
            RigBone(id = "neck", name = "Head / Beak", parentId = "spine", length = 52f, localAngleDeg = -25f, thickness = 30f, colorArgb = 0xFFFBBF24L),
            RigBone(id = "wing_l_in", name = "L Wing Inner", parentId = "spine", length = 78f, localAngleDeg = -105f, thickness = 18f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "wing_l_tip", name = "L Wing Tip", parentId = "wing_l_in", length = 70f, localAngleDeg = -25f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "wing_r_in", name = "R Wing Inner", parentId = "spine", length = 78f, localAngleDeg = -65f, thickness = 18f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "wing_r_tip", name = "R Wing Tip", parentId = "wing_r_in", length = 70f, localAngleDeg = 20f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "tail_base", name = "Tail Base", parentId = null, length = 64f, localAngleDeg = 165f, thickness = 16f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "tail_tip", name = "Tail Fan", parentId = "tail_base", length = 48f, localAngleDeg = 10f, thickness = 14f, colorArgb = 0xFFC084FCL),
            RigBone(id = "claw_l", name = "L Claw", parentId = null, length = 46f, localAngleDeg = 105f, thickness = 12f, colorArgb = 0xFFF59E0BL),
            RigBone(id = "claw_r", name = "R Claw", parentId = null, length = 46f, localAngleDeg = 75f, thickness = 12f, colorArgb = 0xFFF59E0BL)
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            bones = bones,
            ikEnabled = true,
            showSkinMesh = true,
            rigCategory = "BIRD"
        )
    }

    /**
     * Non-Human Quadruped Animal Starter Rig (Dog, Cat, Horse, Monster, Dragon):
     * Spine, Neck/Head, 2-bone Tail, and 4 articulated 2-bone legs.
     */
    fun createQuadrupedAnimalRig(
        name: String = "Animal Quadruped Rig",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "spine", name = "Torso Spine", parentId = null, length = 115f, localAngleDeg = 0f, thickness = 34f, colorArgb = 0xFFFF6B35L),
            RigBone(id = "neck", name = "Head / Snout", parentId = "spine", length = 68f, localAngleDeg = -42f, thickness = 32f, colorArgb = 0xFFFBBF24L),
            RigBone(id = "tail_base", name = "Tail Base", parentId = null, length = 58f, localAngleDeg = -145f, thickness = 14f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "tail_tip", name = "Tail Tip", parentId = "tail_base", length = 52f, localAngleDeg = -20f, thickness = 11f, colorArgb = 0xFFC084FCL),
            RigBone(id = "leg_fl_up", name = "Front-L Upper", parentId = "spine", length = 64f, localAngleDeg = 82f, thickness = 17f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "leg_fl_low", name = "Front-L Paw", parentId = "leg_fl_up", length = 56f, localAngleDeg = 12f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "leg_fr_up", name = "Front-R Upper", parentId = "spine", length = 64f, localAngleDeg = 98f, thickness = 17f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "leg_fr_low", name = "Front-R Paw", parentId = "leg_fr_up", length = 56f, localAngleDeg = -10f, thickness = 14f, colorArgb = 0xFF06B6D4L),
            RigBone(id = "leg_bl_up", name = "Back-L Upper", parentId = null, length = 66f, localAngleDeg = 104f, thickness = 18f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_bl_low", name = "Back-L Paw", parentId = "leg_bl_up", length = 58f, localAngleDeg = -18f, thickness = 14f, colorArgb = 0xFFC084FCL),
            RigBone(id = "leg_br_up", name = "Back-R Upper", parentId = null, length = 66f, localAngleDeg = 86f, thickness = 18f, colorArgb = 0xFFA78BFAL),
            RigBone(id = "leg_br_low", name = "Back-R Paw", parentId = "leg_br_up", length = 58f, localAngleDeg = 14f, thickness = 14f, colorArgb = 0xFFC084FCL)
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            bones = bones,
            ikEnabled = true,
            showSkinMesh = true,
            rigCategory = "QUADRUPED"
        )
    }

    /**
     * Minimal Custom Object / Creature Rig ready for tap-anywhere custom bone placement on any PNG.
     */
    fun createCustomObjectRig(
        name: String = "Custom Object Rig",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(id = "root_body", name = "Core Bone", parentId = null, length = 82f, localAngleDeg = -90f, thickness = 22f, colorArgb = 0xFF2DD4BFL),
            RigBone(id = "tip_1", name = "Tip Bone", parentId = "root_body", length = 68f, localAngleDeg = 15f, thickness = 16f, colorArgb = 0xFFFBBF24L)
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            bones = bones,
            ikEnabled = true,
            showSkinMesh = true,
            rigCategory = "CUSTOM_OBJECT"
        )
    }

    /**
     * Adds a custom parent-child bone directly to where the user tapped on the canvas!
     * Computes exact local angle and length relative to the selected parent bone tip (or root).
     */
    fun addCustomBoneAtPoint(
        rig: SkeletalRig,
        parentBoneId: String?,
        tapWorldPoint: Vec2,
        angleOverrides: Map<String, Float> = emptyMap(),
        flippedHorizontal: Boolean = false
    ): Pair<SkeletalRig, RigBone> {
        val localTap = if (flippedHorizontal) {
            Vec2(rig.rootX - (tapWorldPoint.x - rig.rootX), tapWorldPoint.y)
        } else {
            tapWorldPoint
        }
        val solved = solveForwardKinematics(rig, angleOverrides, rig.rootX, rig.rootY, rig.scale, false)
        val parentSolved = parentBoneId?.let { pid -> solved.firstOrNull { it.bone.id == pid } }
        val start = parentSolved?.end ?: Vec2(rig.rootX, rig.rootY)
        val parentWorldDeg = parentSolved?.worldAngleDeg ?: 0f

        val dx = localTap.x - start.x
        val dy = localTap.y - start.y
        val worldLen = hypot(dx, dy).coerceAtLeast(24f)
        val boneLen = (worldLen / rig.scale.coerceAtLeast(0.1f)).coerceIn(22f, 260f)
        val worldDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        val localDeg = normalizeAngle(worldDeg - parentWorldDeg)

        val nextIdx = rig.bones.size + 1
        val bonePalette = listOf(0xFF2DD4BFL, 0xFFFBBF24L, 0xFFA78BFAL, 0xFFFF6B35L, 0xFF34D399L, 0xFF38BDF8L)
        val newBone = RigBone(
            name = "Bone $nextIdx",
            parentId = parentSolved?.bone?.id,
            length = boneLen,
            localAngleDeg = localDeg,
            thickness = 15f,
            colorArgb = bonePalette[nextIdx % bonePalette.size]
        )
        return rig.copy(bones = rig.bones + newBone) to newBone
    }

    /**
     * Starter rig for building reusable Custom Rigged Assets & Props (animated sword, wings, cape, skateboard,
     * umbrella, creature attachment, custom PNG prop with articulated bones).
     */
    fun createCustomAssetStarterRig(
        name: String = "My Custom Asset",
        rootX: Float = 640f,
        rootY: Float = 400f
    ): SkeletalRig {
        val bones = listOf(
            RigBone(
                id = "asset_base",
                name = "Asset Base",
                parentId = null,
                length = 72f,
                localAngleDeg = -90f,
                thickness = 18f,
                colorArgb = 0xFF2DD4BFL,
                isExtraRigBone = true
            ),
            RigBone(
                id = "asset_tip",
                name = "Asset Tip",
                parentId = "asset_base",
                length = 58f,
                localAngleDeg = 12f,
                thickness = 14f,
                colorArgb = 0xFFFBBF24L,
                isExtraRigBone = true
            )
        )
        return SkeletalRig(
            name = name,
            rootX = rootX,
            rootY = rootY,
            bones = bones,
            ikEnabled = true,
            showSkinMesh = true,
            rigCategory = "ASSET"
        )
    }

    /**
     * Resolves which bone ID on [rig] corresponds to the requested [area] (Hands, Legs, Head, Chest, Hip, or Selected Bone).
     */
    fun resolveAttachmentParentBoneId(
        rig: SkeletalRig,
        area: RigAttachmentArea,
        selectedBoneId: String?
    ): String? {
        if (area == RigAttachmentArea.HIP_WAIST) return null
        if (area == RigAttachmentArea.SELECTED_BONE) {
            return selectedBoneId?.takeIf { id -> rig.bones.any { it.id == id } } ?: rig.bones.firstOrNull()?.id
        }
        val existingIds = rig.bones.map { it.id }.toSet()
        for (candidate in area.candidateBoneIds) {
            if (candidate in existingIds) return candidate
        }
        return selectedBoneId?.takeIf { it in existingIds } ?: rig.bones.firstOrNull()?.id
    }

    /**
     * Attaches a new extra variable articulated rig bone onto ANY body area (Hand, Leg, Foot, Head, Chest, Hip, or Selected Bone),
     * optionally carrying a built-in prop graphic or imported custom PNG that bends, scales, and rotates independently!
     */
    fun createExtraVariableBone(
        rig: SkeletalRig,
        area: RigAttachmentArea,
        selectedBoneId: String? = null,
        name: String? = null,
        length: Float = 68f,
        propKind: HandPropKind? = null,
        imagePath: String? = null,
        imageScale: Float = 1.0f
    ): Pair<SkeletalRig, RigBone> {
        val parentId = resolveAttachmentParentBoneId(rig, area, selectedBoneId)
        val extraCount = rig.bones.count { it.isExtraRigBone } + 1
        val propLabel = propKind?.takeIf { it != HandPropKind.NONE }?.label
        val resolvedName = name?.takeIf { it.isNotBlank() }
            ?: when {
                propLabel != null -> "${area.shortLabel}: $propLabel"
                !imagePath.isNullOrBlank() -> "${area.shortLabel} PNG #$extraCount"
                else -> "${area.shortLabel} Rig #$extraCount"
            }
        val palette = listOf(0xFFFBBF24L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFF6B35L, 0xFF34D399L, 0xFF38BDF8L)
        val newBone = RigBone(
            id = "extra_${UUID.randomUUID().toString().take(8)}",
            name = resolvedName,
            parentId = parentId,
            length = length.coerceIn(18f, 260f),
            localAngleDeg = area.defaultAngleDeg,
            thickness = 14f,
            colorArgb = palette[extraCount % palette.size],
            boundImagePath = imagePath,
            imageScale = imageScale.coerceIn(0.1f, 6.0f),
            attachedPropKind = propKind?.takeIf { it != HandPropKind.NONE }?.name,
            isExtraRigBone = true
        )
        return rig.copy(bones = rig.bones + newBone) to newBone
    }

    /**
     * Grafts a full multi-bone reusable Custom Asset onto ANY body area of [targetRig],
     * remapping bone IDs uniquely and parenting the asset's root bones onto the target socket bone!
     */
    fun graftCustomAssetOntoRig(
        targetRig: SkeletalRig,
        assetRig: SkeletalRig,
        area: RigAttachmentArea,
        selectedBoneId: String? = null
    ): Pair<SkeletalRig, RigBone?> {
        val socketParentId = resolveAttachmentParentBoneId(targetRig, area, selectedBoneId)
        val prefix = "att_${UUID.randomUUID().toString().take(6)}_"

        val sourceBones = if (assetRig.bones.isNotEmpty()) {
            assetRig.bones
        } else {
            listOf(
                RigBone(
                    id = "root",
                    name = assetRig.name,
                    parentId = null,
                    length = 72f,
                    localAngleDeg = area.defaultAngleDeg,
                    boundImagePath = assetRig.singleMeshImagePath,
                    imageScale = assetRig.singleMeshScale.coerceIn(0.1f, 6.0f),
                    isExtraRigBone = true
                )
            )
        }

        val idMap = sourceBones.associate { it.id to "$prefix${it.id}" }
        val graftedBones = sourceBones.mapIndexed { idx, bone ->
            val mappedParent = if (bone.parentId == null) {
                socketParentId
            } else {
                idMap[bone.parentId] ?: socketParentId
            }
            // If the asset used a single-mesh PNG and this is its first root bone without its own bound PNG, carry it along!
            val carriedImage = bone.boundImagePath
                ?: if (idx == 0 && !assetRig.singleMeshImagePath.isNullOrBlank()) assetRig.singleMeshImagePath else null
            val carriedScale = if (bone.boundImagePath == null && carriedImage != null) {
                (assetRig.singleMeshScale * 1.4f).coerceIn(0.2f, 6.0f)
            } else {
                bone.imageScale
            }
            bone.copy(
                id = idMap.getValue(bone.id),
                name = if (idx == 0) "${area.shortLabel}: ${assetRig.name}" else "${assetRig.name} • ${bone.name}",
                parentId = mappedParent,
                boundImagePath = carriedImage,
                imageScale = carriedScale,
                isExtraRigBone = true
            )
        }
        return targetRig.copy(bones = targetRig.bones + graftedBones) to graftedBones.firstOrNull()
    }

    fun presetPoseAngles(poseName: String): Map<String, Float> = when (poseName) {
        "WAVE" -> mapOf(
            "spine" to -86f,
            "neck" to 8f,
            "arm_r_up" to 32f,
            "arm_r_low" to -52f,
            "arm_l_up" to -145f,
            "arm_l_low" to 18f
        )
        "WALK_A" -> mapOf(
            "spine" to -84f,
            "arm_l_up" to -110f,
            "arm_l_low" to 35f,
            "arm_r_up" to 158f,
            "arm_r_low" to -22f,
            "leg_l_up" to 125f,
            "leg_l_low" to -18f,
            "leg_r_up" to 58f,
            "leg_r_low" to 28f
        )
        "WALK_B" -> mapOf(
            "spine" to -94f,
            "arm_l_up" to -160f,
            "arm_l_low" to 22f,
            "arm_r_up" to 105f,
            "arm_r_low" to -35f,
            "leg_l_up" to 62f,
            "leg_l_low" to 25f,
            "leg_r_up" to 122f,
            "leg_r_low" to -15f
        )
        "JUMP" -> mapOf(
            "spine" to -90f,
            "arm_l_up" to -42f,
            "arm_l_low" to -20f,
            "arm_r_up" to 42f,
            "arm_r_low" to 20f,
            "leg_l_up" to 132f,
            "leg_l_low" to -65f,
            "leg_r_up" to 48f,
            "leg_r_low" to 65f
        )
        "SIT" -> mapOf(
            "spine" to -88f,
            "arm_l_up" to -130f,
            "arm_l_low" to -20f,
            "arm_r_up" to 130f,
            "arm_r_low" to 20f,
            "leg_l_up" to 165f,
            "leg_l_low" to -80f,
            "leg_r_up" to 15f,
            "leg_r_low" to 80f
        )
        "FLAP_UP" -> mapOf(
            "wing_l_in" to -135f,
            "wing_l_tip" to -15f,
            "wing_r_in" to -45f,
            "wing_r_tip" to 15f,
            "tail_base" to 155f
        )
        "FLAP_DOWN" -> mapOf(
            "wing_l_in" to 145f,
            "wing_l_tip" to 35f,
            "wing_r_in" to 35f,
            "wing_r_tip" to -35f,
            "tail_base" to 178f
        )
        else -> mapOf(
            "spine" to -90f,
            "neck" to 0f,
            "arm_l_up" to -138f,
            "arm_l_low" to 24f,
            "arm_r_up" to 138f,
            "arm_r_low" to -24f,
            "leg_l_up" to 104f,
            "leg_l_low" to -10f,
            "leg_r_up" to 76f,
            "leg_r_low" to 10f
        )
    }
}
