package com.example.engine

import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationProject
import com.example.data.model.AnimationScene
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CameraKeyframe
import com.example.data.model.CharacterSpec
import com.example.data.model.DrawStroke
import com.example.data.model.EasingType
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.FrameContent
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneTransition
import com.example.data.model.SceneVfxType
import com.example.data.model.ShapeKind
import com.example.data.model.SubtitleCue
import com.example.data.model.SubtitleStyle
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class StoryboardTemplate(val title: String, val subtitle: String) {
    BLANK_STUDIO("Blank Canvas", "Clean 1280×720 stage with drawing & background layers"),
    HERO_DEMO("Character Showcase", "Animated character + skeletal rig + keyframed camera"),
    HORROR_STORY("Horror Cartoon", "Semi-transparent Ghost rig, haunted forest, fog, lightning & captions"),
    THREE_ACT_STORY("3-Act Storyboard", "Intro, Conflict, and Finale scenes with transitions"),
    BOUNCE_STUDY("12-Principles Bounce", "Classic squash-and-stretch animation loop")
}

enum class MotionPreset(val label: String, val description: String) {
    BOUNCE_LOOP("Bounce Loop", "Energetic squash & bounce keyframes"),
    WALK_ACROSS("Walk Across", "Smooth horizontal travel with bobbing"),
    WAVE_HELLO("Wave & Pop", "Scale pop entrance with gentle tilt"),
    ORBIT_FLOAT("Zero-G Float", "Curved floating motion path + rotation"),
    DRAMATIC_ZOOM("Camera Zoom-In", "Adds eased camera push-in keyframes")
}

enum class ProceduralPropKind(val label: String) {
    STARBURST("Starburst"),
    SPEECH_BUBBLE("Speech Bubble"),
    AESTHETIC_SPEECH_BUBBLE("Pastel Bubble"),
    CARTOON_CLOUD("Fluffy Cloud"),
    PINE_TREE("Stylized Tree"),
    ROCKET_SHIP("Mini Rocket"),
    LIGHTNING("Energy Bolt")
}

object ProceduralSmartTools {

    val characterPresets: List<CharacterSpec> = listOf(
        CharacterSpec(
            id = "preset_nova",
            name = "Nova",
            skinToneArgb = 0xFFF5C6A5L,
            faceShape = "OVAL",
            eyeStyle = "ANIME",
            eyeColorArgb = 0xFF2DD4BFL,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFF1F2937L,
            shirtStyle = "HOODIE",
            shirtColorArgb = 0xFFFF6B35L,
            pantsColorArgb = 0xFF1E293BL,
            accessory = "HEADPHONES",
            pose = "WAVE"
        ),
        CharacterSpec(
            id = "preset_luna",
            name = "Luna",
            skinToneArgb = 0xFFE8B496L,
            faceShape = "CHIBI",
            eyeStyle = "STAR",
            eyeColorArgb = 0xFFA78BFAL,
            mouthStyle = "CAT",
            expression = "WINK",
            hairStyle = "PONYTAIL",
            hairColorArgb = 0xFF4C1D95L,
            shirtStyle = "CAPE",
            shirtColorArgb = 0xFF06B6D4L,
            pantsColorArgb = 0xFF312E81L,
            accessory = "CROWN",
            pose = "HERO"
        ),
        CharacterSpec(
            id = "preset_kai",
            name = "Kai",
            skinToneArgb = 0xFFC68642L,
            faceShape = "SQUARE",
            eyeStyle = "COOL",
            eyeColorArgb = 0xFFFBBF24L,
            mouthStyle = "SMIRK",
            expression = "NEUTRAL",
            hairStyle = "CURLY",
            hairColorArgb = 0xFF111827L,
            shirtStyle = "JACKET",
            shirtColorArgb = 0xFF10B981L,
            pantsColorArgb = 0xFF0F172AL,
            accessory = "GLASSES",
            pose = "WALK_A"
        ),
        CharacterSpec(
            id = "preset_pip",
            name = "Pip",
            skinToneArgb = 0xFFFFDFC4L,
            faceShape = "ROUND",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFF38BDF8L,
            mouthStyle = "OPEN",
            expression = "SURPRISED",
            hairStyle = "BOB",
            hairColorArgb = 0xFFEC4899L,
            shirtStyle = "TEE",
            shirtColorArgb = 0xFFF59E0BL,
            pantsColorArgb = 0xFF334155L,
            accessory = "SCARF",
            pose = "JUMP"
        ),
        CharacterSpec(
            id = "preset_phantom_ghost",
            name = "Phantom Ghost",
            skinToneArgb = 0xFFD8F3FCL,
            faceShape = "OVAL",
            eyeStyle = "STAR",
            eyeColorArgb = 0xFF38BDF8L,
            mouthStyle = "O_SHAPE",
            expression = "SURPRISED",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFFE0F2FEL,
            shirtStyle = "CAPE",
            shirtColorArgb = 0xFFBAE6FDL,
            pantsColorArgb = 0xFF7DD3FCL,
            accessory = "NONE",
            pose = "HERO",
            eyePack = EyePackStyle.SURPRISED.name,
            mouthPhoneme = MouthPhoneme.SHOCK.name
        ),
        CharacterSpec(
            id = "preset_shadow_reaper",
            name = "Shadow Reaper",
            skinToneArgb = 0xFF334155L,
            faceShape = "SQUARE",
            eyeStyle = "COOL",
            eyeColorArgb = 0xFFEF4444L,
            mouthStyle = "SMIRK",
            expression = "NEUTRAL",
            hairStyle = "MOHAWK",
            hairColorArgb = 0xFF090D16L,
            shirtStyle = "CAPE",
            shirtColorArgb = 0xFF111827L,
            pantsColorArgb = 0xFF030712L,
            accessory = "SCARF",
            pose = "HERO",
            eyePack = EyePackStyle.ANGRY.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name
        ),
        CharacterSpec(
            id = "preset_zombie_kid",
            name = "Zombie Kid",
            skinToneArgb = 0xFF84CC16L,
            faceShape = "ROUND",
            eyeStyle = "CARTOON",
            eyeColorArgb = 0xFFFEF08AL,
            mouthStyle = "OPEN",
            expression = "SURPRISED",
            hairStyle = "CURLY",
            hairColorArgb = 0xFF1E293BL,
            shirtStyle = "HOODIE",
            shirtColorArgb = 0xFF4C1D95L,
            pantsColorArgb = 0xFF1E1B4BL,
            accessory = "NONE",
            pose = "WALK_A",
            eyePack = EyePackStyle.SIDE_LOOK.name,
            mouthPhoneme = MouthPhoneme.A.name
        ),
        CharacterSpec(
            id = "preset_yt_host",
            name = "YouTube Host",
            skinToneArgb = 0xFFF5C6A5L,
            faceShape = "CHIBI",
            eyeStyle = "ANIME",
            eyeColorArgb = 0xFFFF3B5CL,
            mouthStyle = "SMILE",
            expression = "HAPPY",
            hairStyle = "SPIKY",
            hairColorArgb = 0xFF0F172AL,
            shirtStyle = "HOODIE",
            shirtColorArgb = 0xFFEF4444L,
            pantsColorArgb = 0xFF1E293BL,
            accessory = "HEADPHONES",
            pose = "WAVE",
            eyePack = EyePackStyle.HAPPY.name,
            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name
        )
    )

    fun randomizeCharacter(seed: Int = Random.nextInt()): CharacterSpec {
        val rng = Random(seed)
        val skins = listOf(0xFFFFDFC4L, 0xFFF5C6A5L, 0xFFE0AC69L, 0xFFC68642L, 0xFF8D5524L)
        val hairs = listOf(0xFF111827L, 0xFF7C2D12L, 0xFF4C1D95L, 0xFFDB2777L, 0xFF0284C7L, 0xFFD97706L)
        val shirts = listOf(0xFFFF6B35L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFBBF24L, 0xFFFB7185L, 0xFF34D399L)
        val eyes = listOf(0xFF2DD4BFL, 0xFF38BDF8L, 0xFFA78BFAL, 0xFFF59E0BL, 0xFF10B981L)
        val names = listOf("Zephyr", "Milo", "Kira", "Bramble", "Vex", "Sora", "Toby", "Zara")
        return CharacterSpec(
            name = names[rng.nextInt(names.size)],
            skinToneArgb = skins[rng.nextInt(skins.size)],
            faceShape = listOf("OVAL", "ROUND", "SQUARE", "CHIBI")[rng.nextInt(4)],
            eyeStyle = listOf("ANIME", "DOT", "CARTOON", "COOL", "STAR")[rng.nextInt(5)],
            eyeColorArgb = eyes[rng.nextInt(eyes.size)],
            mouthStyle = listOf("SMILE", "OPEN", "SMIRK", "CAT", "O_SHAPE")[rng.nextInt(5)],
            expression = listOf("HAPPY", "NEUTRAL", "SURPRISED", "WINK", "TALKING")[rng.nextInt(5)],
            hairStyle = listOf("SPIKY", "BOB", "PONYTAIL", "CURLY", "MOHAWK")[rng.nextInt(5)],
            hairColorArgb = hairs[rng.nextInt(hairs.size)],
            shirtStyle = listOf("HOODIE", "TEE", "JACKET", "CAPE", "TUNIC")[rng.nextInt(5)],
            shirtColorArgb = shirts[rng.nextInt(shirts.size)],
            pantsColorArgb = listOf(0xFF1E293BL, 0xFF312E81L, 0xFF1F2937L, 0xFF3F3F46L)[rng.nextInt(4)],
            accessory = listOf("NONE", "GLASSES", "HEADPHONES", "CROWN", "SCARF", "HAT")[rng.nextInt(6)],
            pose = listOf("IDLE", "WAVE", "WALK_A", "JUMP", "HERO")[rng.nextInt(5)]
        )
    }

    fun generatePropShapes(kind: ProceduralPropKind, cx: Float, cy: Float): Pair<List<VectorShape>, List<DrawStroke>> {
        return when (kind) {
            ProceduralPropKind.STARBURST -> {
                val pts = mutableListOf<Vec2>()
                val spikes = 10
                for (i in 0..spikes * 2) {
                    val angle = i * PI / spikes - PI / 2
                    val r = if (i % 2 == 0) 85f else 38f
                    pts.add(Vec2(cx + (cos(angle) * r).toFloat(), cy + (sin(angle) * r).toFloat()))
                }
                emptyList<VectorShape>() to listOf(
                    DrawStroke(
                        tool = EditorTool.PEN_BEZIER.name,
                        points = pts,
                        colorArgb = 0xFFFBBF24L,
                        strokeWidth = 6f,
                        isClosedBezier = true
                    )
                )
            }
            ProceduralPropKind.SPEECH_BUBBLE -> {
                val bubble = VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = cx - 95f,
                    startY = cy - 60f,
                    endX = cx + 95f,
                    endY = cy + 45f,
                    strokeColorArgb = 0xFF0F172AL,
                    fillColorArgb = 0xFFF8FAFCL,
                    strokeWidth = 5f
                )
                val tail = DrawStroke(
                    tool = EditorTool.PEN_BEZIER.name,
                    points = listOf(Vec2(cx - 25f, cy + 40f), Vec2(cx - 55f, cy + 88f), Vec2(cx + 8f, cy + 44f)),
                    colorArgb = 0xFF0F172AL,
                    strokeWidth = 5f
                )
                listOf(bubble) to listOf(tail)
            }
            ProceduralPropKind.AESTHETIC_SPEECH_BUBBLE -> {
                val shadow = VectorShape(
                    kind = ShapeKind.RECTANGLE.name,
                    startX = cx - 102f,
                    startY = cy - 52f,
                    endX = cx + 108f,
                    endY = cy + 52f,
                    strokeColorArgb = 0x00000000L,
                    fillColorArgb = 0x55A78BFAL,
                    strokeWidth = 0f
                )
                val card = VectorShape(
                    kind = ShapeKind.RECTANGLE.name,
                    startX = cx - 108f,
                    startY = cy - 58f,
                    endX = cx + 102f,
                    endY = cy + 46f,
                    strokeColorArgb = 0xFF6366F1L,
                    fillColorArgb = 0xFFFFFBF5L,
                    gradientEndArgb = 0xFFFDE8F3L,
                    strokeWidth = 4f
                )
                val sparkle = VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = cx + 74f,
                    startY = cy - 68f,
                    endX = cx + 98f,
                    endY = cy - 44f,
                    strokeColorArgb = 0xFFF472B6L,
                    fillColorArgb = 0xFFFDE047L,
                    strokeWidth = 3f
                )
                val tail = DrawStroke(
                    tool = EditorTool.PEN_BEZIER.name,
                    points = listOf(Vec2(cx - 32f, cy + 46f), Vec2(cx - 58f, cy + 82f), Vec2(cx - 2f, cy + 46f)),
                    colorArgb = 0xFF6366F1L,
                    strokeWidth = 4f
                )
                listOf(shadow, card, sparkle) to listOf(tail)
            }
            ProceduralPropKind.CARTOON_CLOUD -> {
                val shapes = listOf(
                    VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 95f, startY = cy - 28f, endX = cx - 10f, endY = cy + 38f, strokeColorArgb = 0xFFE2E8F0L, fillColorArgb = 0xFFFFFFFFL, strokeWidth = 3f),
                    VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 50f, startY = cy - 62f, endX = cx + 52f, endY = cy + 32f, strokeColorArgb = 0xFFE2E8F0L, fillColorArgb = 0xFFFFFFFFL, strokeWidth = 3f),
                    VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx + 10f, startY = cy - 28f, endX = cx + 95f, endY = cy + 38f, strokeColorArgb = 0xFFE2E8F0L, fillColorArgb = 0xFFFFFFFFL, strokeWidth = 3f)
                )
                shapes to emptyList()
            }
            ProceduralPropKind.PINE_TREE -> {
                val trunk = VectorShape(kind = ShapeKind.RECTANGLE.name, startX = cx - 16f, startY = cy + 30f, endX = cx + 16f, endY = cy + 105f, strokeColorArgb = 0xFF451A03L, fillColorArgb = 0xFF78350FL, strokeWidth = 4f)
                val crown1 = VectorShape(kind = ShapeKind.POLYGON.name, startX = cx - 78f, startY = cy - 35f, endX = cx + 78f, endY = cy + 48f, polygonSides = 3, strokeColorArgb = 0xFF064E3BL, fillColorArgb = 0xFF10B981L, strokeWidth = 4f)
                val crown2 = VectorShape(kind = ShapeKind.POLYGON.name, startX = cx - 58f, startY = cy - 92f, endX = cx + 58f, endY = cy - 10f, polygonSides = 3, strokeColorArgb = 0xFF064E3BL, fillColorArgb = 0xFF34D399L, strokeWidth = 4f)
                listOf(trunk, crown1, crown2) to emptyList()
            }
            ProceduralPropKind.ROCKET_SHIP -> {
                val body = VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 34f, startY = cy - 95f, endX = cx + 34f, endY = cy + 68f, strokeColorArgb = 0xFF0F172AL, fillColorArgb = 0xFFF1F5F9L, strokeWidth = 5f)
                val window = VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 18f, startY = cy - 42f, endX = cx + 18f, endY = cy - 6f, strokeColorArgb = 0xFF0F172AL, fillColorArgb = 0xFF38BDF8L, strokeWidth = 4f)
                val flame = VectorShape(kind = ShapeKind.POLYGON.name, startX = cx - 22f, startY = cy + 60f, endX = cx + 22f, endY = cy + 115f, polygonSides = 3, strokeColorArgb = 0xFFFF6B35L, fillColorArgb = 0xFFFBBF24L, strokeWidth = 3f, rotationDeg = 180f)
                listOf(flame, body, window) to emptyList()
            }
            ProceduralPropKind.LIGHTNING -> {
                val bolt = DrawStroke(
                    tool = EditorTool.PEN_BEZIER.name,
                    points = listOf(
                        Vec2(cx + 15f, cy - 95f),
                        Vec2(cx - 42f, cy + 5f),
                        Vec2(cx + 8f, cy + 5f),
                        Vec2(cx - 22f, cy + 95f),
                        Vec2(cx + 46f, cy - 15f),
                        Vec2(cx - 4f, cy - 15f)
                    ),
                    colorArgb = 0xFF2DD4BFL,
                    strokeWidth = 7f,
                    isClosedBezier = true
                )
                emptyList<VectorShape>() to listOf(bolt)
            }
        }
    }

    fun applyMotionPreset(layer: AnimationLayer, preset: MotionPreset, totalFrames: Int): AnimationLayer {
        val mid = (totalFrames / 2).coerceAtLeast(1)
        val end = (totalFrames - 1).coerceAtLeast(2)
        return when (preset) {
            MotionPreset.BOUNCE_LOOP -> layer.copy(
                keyframes = listOf(
                    TransformKeyframe(0, 0f, -120f, 0f, 0.92f, 1.08f, 1f, EasingType.EASE_IN.name),
                    TransformKeyframe(mid, 0f, 45f, 0f, 1.18f, 0.84f, 1f, EasingType.BOUNCE.name),
                    TransformKeyframe(end, 0f, -120f, 0f, 0.92f, 1.08f, 1f, EasingType.EASE_OUT.name)
                )
            )
            MotionPreset.WALK_ACROSS -> layer.copy(
                keyframes = listOf(
                    TransformKeyframe(0, -280f, 0f, -3f, 1f, 1f, 1f, EasingType.LINEAR.name),
                    TransformKeyframe(totalFrames / 4, -140f, -18f, 3f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(mid, 0f, 0f, -3f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe((totalFrames * 3) / 4, 140f, -18f, 3f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(end, 280f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_OUT.name)
                )
            )
            MotionPreset.WAVE_HELLO -> layer.copy(
                keyframes = listOf(
                    TransformKeyframe(0, 0f, 60f, -8f, 0.4f, 0.4f, 0.2f, EasingType.BOUNCE.name),
                    TransformKeyframe(totalFrames / 3, 0f, 0f, 6f, 1.08f, 1.08f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe((totalFrames * 2) / 3, 0f, -10f, -6f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(end, 0f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_OUT.name)
                )
            )
            MotionPreset.ORBIT_FLOAT -> layer.copy(
                motionPath = listOf(
                    Vec2(640f, 360f),
                    Vec2(780f, 260f),
                    Vec2(640f, 200f),
                    Vec2(500f, 290f),
                    Vec2(640f, 360f)
                ),
                keyframes = listOf(
                    TransformKeyframe(0, 0f, 0f, -10f, 0.95f, 0.95f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(mid, 0f, 0f, 10f, 1.08f, 1.08f, 1f, EasingType.EASE_IN_OUT.name),
                    TransformKeyframe(end, 0f, 0f, -10f, 0.95f, 0.95f, 1f, EasingType.EASE_IN_OUT.name)
                )
            )
            MotionPreset.DRAMATIC_ZOOM -> layer
        }
    }

    /**
     * Generates smooth camera tracking keyframes that follow a selected character or puppet layer.
     */
    fun applyCameraFollowCharacter(
        scene: AnimationScene,
        targetLayerId: String,
        logicalWidth: Int,
        logicalHeight: Int
    ): AnimationScene {
        val target = scene.layers.firstOrNull { it.id == targetLayerId } ?: return scene
        val step = (scene.durationFrames / 8).coerceAtLeast(4)
        val keys = mutableListOf<CameraKeyframe>()
        val centerX = logicalWidth * 0.5f
        val centerY = logicalHeight * 0.5f

        var f = 0
        while (f < scene.durationFrames) {
            val (px, py) = when {
                target.rig != null -> {
                    val eval = InterpolationEngine.evaluatePuppetRoot(target.rig, f)
                    eval.rootX to (eval.rootY - 60f * eval.scale)
                }
                target.character != null -> {
                    val t = InterpolationEngine.evaluateLayerTransform(target, f, scene.durationFrames)
                    (target.character.x + t.x) to (target.character.y + t.y - 40f)
                }
                else -> {
                    val t = InterpolationEngine.evaluateLayerTransform(target, f, scene.durationFrames)
                    (centerX + t.x) to (centerY + t.y)
                }
            }
            keys.add(
                CameraKeyframe(
                    frame = f,
                    panX = (px - centerX).coerceIn(-logicalWidth * 0.35f, logicalWidth * 0.35f),
                    panY = (py - centerY).coerceIn(-logicalHeight * 0.3f, logicalHeight * 0.3f),
                    zoom = 1.18f,
                    rotationDeg = 0f,
                    easing = EasingType.EASE_IN_OUT.name
                )
            )
            f += step
        }
        return scene.copy(cameraKeyframes = keys)
    }

    /**
     * Injects a snappy cartoon Camera Shake burst starting at startFrame.
     */
    fun applyCameraShake(
        scene: AnimationScene,
        startFrame: Int,
        intensity: Float = 22f
    ): AnimationScene {
        val baseCam = InterpolationEngine.evaluateCamera(scene, startFrame)
        val shakeOffsets = listOf(
            0 to (0f to 0f),
            2 to (-intensity to intensity * 0.6f),
            4 to (intensity * 0.9f to -intensity * 0.7f),
            6 to (-intensity * 0.6f to -intensity * 0.4f),
            8 to (intensity * 0.35f to intensity * 0.3f),
            10 to (0f to 0f)
        )
        val existing = scene.cameraKeyframes.filterNot { kf ->
            kf.frame in startFrame..(startFrame + 10)
        }.toMutableList()
        shakeOffsets.forEach { (dt, pair) ->
            val frame = (startFrame + dt).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(0))
            existing.add(
                CameraKeyframe(
                    frame = frame,
                    panX = baseCam.panX + pair.first,
                    panY = baseCam.panY + pair.second,
                    zoom = baseCam.zoom,
                    rotationDeg = baseCam.rotationDeg + pair.first * 0.08f,
                    easing = EasingType.LINEAR.name
                )
            )
        }
        return scene.copy(cameraKeyframes = existing.distinctBy { it.frame }.sortedBy { it.frame })
    }

    /**
     * Cinematic Dolly Zoom: smoothly zooms in/out from startFrame across ~36 frames with Ease In-Out.
     */
    fun applyCameraDollyZoom(
        scene: AnimationScene,
        startFrame: Int,
        targetZoom: Float = 1.75f
    ): AnimationScene {
        val baseCam = InterpolationEngine.evaluateCamera(scene, startFrame)
        val endFrame = (startFrame + 36).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(1))
        val k1 = CameraKeyframe(
            frame = startFrame,
            panX = baseCam.panX,
            panY = baseCam.panY,
            zoom = baseCam.zoom,
            rotationDeg = baseCam.rotationDeg,
            easing = EasingType.EASE_IN_OUT.name
        )
        val k2 = CameraKeyframe(
            frame = endFrame,
            panX = baseCam.panX,
            panY = baseCam.panY - 18f,
            zoom = targetZoom.coerceIn(0.3f, 4.0f),
            rotationDeg = baseCam.rotationDeg,
            easing = EasingType.EASE_IN_OUT.name
        )
        val cleaned = scene.cameraKeyframes.filterNot { it.frame == startFrame || it.frame == endFrame }
        return scene.copy(cameraKeyframes = (cleaned + listOf(k1, k2)).sortedBy { it.frame })
    }

    /**
     * Cinematic Pan Across: establishes the whole scene by smoothly panning left-to-right across the timeline.
     */
    fun applyCameraPanAcross(
        scene: AnimationScene,
        startFrame: Int,
        logicalWidth: Int
    ): AnimationScene {
        val endFrame = (startFrame + 48).coerceAtMost((scene.durationFrames - 1).coerceAtLeast(1))
        val span = (logicalWidth * 0.28f).coerceIn(140f, 420f)
        val k1 = CameraKeyframe(
            frame = startFrame,
            panX = -span,
            panY = 0f,
            zoom = 1.28f,
            rotationDeg = 0f,
            easing = EasingType.EASE_IN_OUT.name
        )
        val k2 = CameraKeyframe(
            frame = endFrame,
            panX = span,
            panY = 0f,
            zoom = 1.28f,
            rotationDeg = 0f,
            easing = EasingType.EASE_IN_OUT.name
        )
        val cleaned = scene.cameraKeyframes.filterNot { it.frame == startFrame || it.frame == endFrame }
        return scene.copy(cameraKeyframes = (cleaned + listOf(k1, k2)).sortedBy { it.frame })
    }

    fun createProjectFromTemplate(
        name: String,
        width: Int = 1280,
        height: Int = 720,
        fps: Int = 24,
        template: StoryboardTemplate = StoryboardTemplate.HERO_DEMO
    ): AnimationProject {
        val projectId = UUID.randomUUID().toString()
        val scenes = when (template) {
            StoryboardTemplate.BLANK_STUDIO -> {
                val scene = AnimationScene(
                    name = "Scene 1",
                    durationFrames = 96,
                    backgroundTemplate = BackgroundTemplate.GRID_PAPER.name,
                    layers = listOf(
                        AnimationLayer(name = "Ink Layer", type = LayerType.DRAWING.name),
                        AnimationLayer(name = "Sketch Layer", type = LayerType.DRAWING.name, opacity = 0.7f)
                    )
                )
                listOf(scene)
            }
            StoryboardTemplate.HERO_DEMO -> {
                val novaRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = characterPresets[0],
                    rootX = width * 0.32f,
                    rootY = height * 0.62f
                ).copy(
                    autoWalkWhenDragged = true,
                    eyePack = EyePackStyle.AUTO_BLINK.name,
                    mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(
                            frame = 0,
                            rootX = width * 0.28f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = false,
                            eyePack = EyePackStyle.AUTO_BLINK.name,
                            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 36,
                            rootX = width * 0.40f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = false,
                            eyePack = EyePackStyle.HAPPY.name,
                            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 95,
                            rootX = width * 0.36f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = false,
                            eyePack = EyePackStyle.AUTO_BLINK.name,
                            mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                            easing = EasingType.EASE_OUT.name
                        )
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("IDLE"),
                        "18" to RigSolver.presetPoseAngles("WALK"),
                        "42" to RigSolver.presetPoseAngles("WAVE"),
                        "72" to RigSolver.presetPoseAngles("JUMP"),
                        "95" to RigSolver.presetPoseAngles("IDLE")
                    )
                )
                val lunaRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = characterPresets[1],
                    rootX = width * 0.68f,
                    rootY = height * 0.62f
                ).copy(
                    flippedHorizontal = true,
                    eyePack = EyePackStyle.HAPPY.name,
                    mouthPhoneme = MouthPhoneme.SMILE.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(
                            frame = 0,
                            rootX = width * 0.72f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = true,
                            eyePack = EyePackStyle.HAPPY.name,
                            mouthPhoneme = MouthPhoneme.SMILE.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 48,
                            rootX = width * 0.64f,
                            rootY = height * 0.60f,
                            scale = 1.03f,
                            flippedHorizontal = true,
                            eyePack = EyePackStyle.WINK.name,
                            mouthPhoneme = MouthPhoneme.A.name,
                            easing = EasingType.EASE_IN_OUT.name
                        ),
                        PuppetRootKeyframe(
                            frame = 95,
                            rootX = width * 0.70f,
                            rootY = height * 0.62f,
                            scale = 1f,
                            flippedHorizontal = true,
                            eyePack = EyePackStyle.HAPPY.name,
                            mouthPhoneme = MouthPhoneme.SMILE.name,
                            easing = EasingType.EASE_OUT.name
                        )
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("IDLE"),
                        "30" to RigSolver.presetPoseAngles("WAVE"),
                        "60" to RigSolver.presetPoseAngles("IDLE"),
                        "95" to RigSolver.presetPoseAngles("WAVE")
                    )
                )
                val novaLayer = AnimationLayer(
                    name = "Nova (Puppet)",
                    type = LayerType.RIG.name,
                    rig = novaRig
                )
                val lunaLayer = AnimationLayer(
                    name = "Luna (Puppet)",
                    type = LayerType.RIG.name,
                    rig = lunaRig
                )
                val (bubbleShapes, bubbleStrokes) = generatePropShapes(
                    ProceduralPropKind.AESTHETIC_SPEECH_BUBBLE,
                    width * 0.50f,
                    height * 0.22f
                )
                val fxLayer = AnimationLayer(
                    name = "FX & Props",
                    type = LayerType.DRAWING.name,
                    parallaxDepth = 1.0f,
                    frames = mapOf("0" to FrameContent(shapes = bubbleShapes, strokes = bubbleStrokes))
                )
                listOf(
                    AnimationScene(
                        name = "Act 1 • Main Stage",
                        durationFrames = 96,
                        backgroundTemplate = BackgroundTemplate.PASTEL_SKY.name,
                        activeVfx = listOf(SceneVfxType.FIREFLIES.name),
                        layers = listOf(novaLayer, lunaLayer, fxLayer),
                        cameraKeyframes = listOf(
                            CameraKeyframe(0, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name),
                            CameraKeyframe(48, 0f, -12f, 1.06f, 0f, EasingType.EASE_IN_OUT.name),
                            CameraKeyframe(95, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name)
                        )
                    )
                )
            }
            StoryboardTemplate.HORROR_STORY -> {
                val ghostSpec = characterPresets.first { it.id == "preset_phantom_ghost" }
                val heroSpec = characterPresets.first { it.id == "preset_nova" }
                val ghostRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = ghostSpec,
                    rootX = width * 0.72f,
                    rootY = height * 0.44f
                ).copy(
                    flippedHorizontal = true,
                    autoWalkWhenDragged = false,
                    eyePack = EyePackStyle.SURPRISED.name,
                    mouthPhoneme = MouthPhoneme.SHOCK.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(0, width * 0.84f, height * 0.42f, 0.92f, true, EyePackStyle.SURPRISED.name, MouthPhoneme.REST.name),
                        PuppetRootKeyframe(36, width * 0.68f, height * 0.36f, 1.04f, true, EyePackStyle.ANGRY.name, MouthPhoneme.O.name),
                        PuppetRootKeyframe(64, width * 0.56f, height * 0.40f, 1.15f, true, EyePackStyle.ANGRY.name, MouthPhoneme.SHOCK.name),
                        PuppetRootKeyframe(95, width * 0.70f, height * 0.35f, 1.0f, true, EyePackStyle.SURPRISED.name, MouthPhoneme.REST.name)
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("IDLE"),
                        "36" to RigSolver.presetPoseAngles("WAVE"),
                        "64" to RigSolver.presetPoseAngles("JUMP"),
                        "95" to RigSolver.presetPoseAngles("IDLE")
                    )
                )
                val heroRig = RigSolver.createRiggedCharacterFromSpec(
                    spec = heroSpec,
                    rootX = width * 0.28f,
                    rootY = height * 0.58f
                ).copy(
                    autoWalkWhenDragged = true,
                    eyePack = EyePackStyle.SURPRISED.name,
                    mouthPhoneme = MouthPhoneme.AUTO_LIPSYNC.name,
                    rootKeyframes = listOf(
                        PuppetRootKeyframe(0, width * 0.24f, height * 0.58f, 1f, false, EyePackStyle.SIDE_LOOK.name, MouthPhoneme.REST.name),
                        PuppetRootKeyframe(48, width * 0.34f, height * 0.58f, 1f, false, EyePackStyle.SURPRISED.name, MouthPhoneme.SHOCK.name),
                        PuppetRootKeyframe(95, width * 0.20f, height * 0.58f, 1f, true, EyePackStyle.SURPRISED.name, MouthPhoneme.A.name)
                    ),
                    poseKeyframes = mapOf(
                        "0" to RigSolver.presetPoseAngles("WALK_A"),
                        "24" to RigSolver.presetPoseAngles("WALK_B"),
                        "48" to RigSolver.presetPoseAngles("JUMP"),
                        "95" to RigSolver.presetPoseAngles("WALK_A")
                    )
                )
                val baseScene = AnimationScene(
                    name = "Act 1 • Haunted Woods",
                    durationFrames = 96,
                    backgroundTemplate = BackgroundTemplate.HAUNTED_FOREST.name,
                    backgroundScrollSpeed = 1.6f,
                    colorGrade = SceneColorGrade.HORROR_COLD.name,
                    activeVfx = listOf(
                        SceneVfxType.SPOOKY_FOG.name,
                        SceneVfxType.LIGHTNING_FLASH.name,
                        SceneVfxType.VIGNETTE_HORROR.name
                    ),
                    subtitles = listOf(
                        SubtitleCue(
                            text = "WAIT... WHO IS BEHIND ME?!",
                            speakerName = "NOVA",
                            startFrame = 8,
                            endFrame = 52,
                            colorArgb = 0xFFFFE066L,
                            style = SubtitleStyle.YOUTUBE_BOLD.name
                        ),
                        SubtitleCue(
                            text = "BOO! DO NOT TURN AROUND...",
                            speakerName = "PHANTOM",
                            startFrame = 54,
                            endFrame = 92,
                            colorArgb = 0xFFFF4D6DL,
                            style = SubtitleStyle.HORROR_DRIP.name
                        )
                    ),
                    layers = listOf(
                        AnimationLayer(
                            name = "Nova (Hero)",
                            type = LayerType.RIG.name,
                            rig = heroRig
                        ),
                        AnimationLayer(
                            name = "Phantom Ghost (55%)",
                            type = LayerType.RIG.name,
                            opacity = 0.55f,
                            rig = ghostRig
                        ),
                        AnimationLayer(
                            name = "Spooky FX Sketch",
                            type = LayerType.DRAWING.name
                        )
                    ),
                    cameraKeyframes = listOf(
                        CameraKeyframe(0, 0f, 0f, 1f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(52, 20f, -10f, 1.12f, 0f, EasingType.EASE_IN_OUT.name),
                        CameraKeyframe(95, 0f, 0f, 1.04f, 0f, EasingType.EASE_IN_OUT.name)
                    )
                )
                listOf(applyCameraShake(baseScene, startFrame = 56, intensity = 22f))
            }
            StoryboardTemplate.THREE_ACT_STORY -> {
                val scene1 = AnimationScene(
                    name = "Act 1 • Arrival",
                    durationFrames = 36,
                    backgroundTemplate = BackgroundTemplate.SUNNY_MEADOW.name,
                    transition = SceneTransition.FADE.name,
                    layers = listOf(
                        AnimationLayer(
                            name = "Protagonist",
                            type = LayerType.CHARACTER.name,
                            character = characterPresets[0].copy(x = width * 0.35f, y = height * 0.62f, pose = "WALK_A"),
                            keyframes = listOf(
                                TransformKeyframe(0, -180f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_OUT.name),
                                TransformKeyframe(35, 160f, 0f, 0f, 1f, 1f, 1f, EasingType.EASE_IN_OUT.name)
                            )
                        ),
                        AnimationLayer(name = "Foreground FX", type = LayerType.DRAWING.name, parallaxDepth = 1.3f)
                    )
                )
                val scene2 = AnimationScene(
                    name = "Act 2 • Discovery",
                    durationFrames = 36,
                    backgroundTemplate = BackgroundTemplate.OUTER_SPACE.name,
                    transition = SceneTransition.SLIDE_LEFT.name,
                    layers = listOf(
                        AnimationLayer(
                            name = "Explorer",
                            type = LayerType.CHARACTER.name,
                            character = characterPresets[1].copy(x = width * 0.5f, y = height * 0.55f, pose = "JUMP", expression = "SURPRISED")
                        ),
                        AnimationLayer(name = "Sketch Layer", type = LayerType.DRAWING.name)
                    ),
                    cameraKeyframes = listOf(
                        CameraKeyframe(0, 0f, 0f, 0.95f, 0f),
                        CameraKeyframe(35, 0f, -20f, 1.25f, 0f)
                    )
                )
                val scene3 = AnimationScene(
                    name = "Act 3 • Finale",
                    durationFrames = 36,
                    backgroundTemplate = BackgroundTemplate.SUNSET_DESERT.name,
                    transition = SceneTransition.ZOOM_IN.name,
                    layers = listOf(
                        AnimationLayer(
                            name = "Hero Pose",
                            type = LayerType.CHARACTER.name,
                            character = characterPresets[2].copy(x = width * 0.5f, y = height * 0.6f, pose = "HERO", expression = "HAPPY")
                        ),
                        AnimationLayer(name = "Title & Ink", type = LayerType.DRAWING.name)
                    )
                )
                listOf(scene1, scene2, scene3)
            }
            StoryboardTemplate.BOUNCE_STUDY -> {
                val ball = VectorShape(
                    kind = ShapeKind.CIRCLE.name,
                    startX = width * 0.5f - 58f,
                    startY = height * 0.5f - 58f,
                    endX = width * 0.5f + 58f,
                    endY = height * 0.5f + 58f,
                    strokeColorArgb = 0xFFFFFFFFL,
                    fillColorArgb = 0xFFFF6B35L,
                    gradientEndArgb = 0xFFFBBF24L,
                    strokeWidth = 6f
                )
                val ballLayer = applyMotionPreset(
                    AnimationLayer(
                        name = "Bouncing Ball",
                        type = LayerType.DRAWING.name,
                        frames = mapOf("0" to FrameContent(shapes = listOf(ball)))
                    ),
                    MotionPreset.BOUNCE_LOOP,
                    36
                )
                listOf(
                    AnimationScene(
                        name = "Bounce Cycle",
                        durationFrames = 36,
                        backgroundTemplate = BackgroundTemplate.COZY_STUDIO.name,
                        layers = listOf(
                            ballLayer,
                            AnimationLayer(name = "Motion Arcs", type = LayerType.DRAWING.name)
                        )
                    )
                )
            }
        }

        return AnimationProject(
            id = projectId,
            name = name.ifBlank { "Untitled Studio" },
            width = width,
            height = height,
            fps = fps,
            scenes = scenes,
            activeSceneId = scenes.first().id,
            savedCharacters = characterPresets,
            savedRigs = characterPresets.map { RigSolver.createRiggedCharacterFromSpec(it) } + listOf(
                RigSolver.createHumanoidRig(),
                RigSolver.createCartoonMascotRig()
            )
        )
    }
}
