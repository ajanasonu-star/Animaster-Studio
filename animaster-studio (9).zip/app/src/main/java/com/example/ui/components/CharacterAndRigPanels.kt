package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.HandPropKind
import com.example.data.model.LayerType
import com.example.data.model.RigBone
import com.example.data.model.SkeletalRig
import com.example.engine.InterpolationEngine
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigAttachmentArea
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.CanvasBackdrop
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CharacterCreatorPanel(
    uiState: StudioUiState,
    onApplyCharacter: (CharacterSpec, Boolean) -> Unit,
    onAutoRigCharacter: (CharacterSpec) -> Unit,
    onSaveTemplate: (CharacterSpec) -> Unit,
    onKeyframeExpressionPose: (String?, String?) -> Unit
) {
    val activeChar = uiState.selectedLayer?.character
    var draft by remember(activeChar?.id) {
        mutableStateOf(activeChar ?: ProceduralSmartTools.characterPresets.first())
    }

    LaunchedEffect(activeChar) {
        if (activeChar != null) draft = activeChar
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Live Character Preview Stage
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(175.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CanvasBackdrop)
                    .border(1.dp, StudioBorder, RoundedCornerShape(14.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawIntoCanvas { c ->
                        val nc = c.nativeCanvas
                        nc.save()
                        val previewChar = draft.copy(x = size.width / 2f, y = size.height * 0.56f, scale = 0.52f)
                        SceneRenderer.drawCharacter(nc, previewChar, 1f, null)
                        nc.restore()
                    }
                }
                Surface(
                    color = StudioSurfaceVariant.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clickable { draft = ProceduralSmartTools.randomizeCharacter() }
                        .testTag("randomize_character_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.Casino, contentDescription = "Randomize", tint = StudioCyan, modifier = Modifier.size(15.dp))
                        Text("Randomize", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                    }
                }
            }
        }

        // 4-View Turnaround Generator (Front / Left Side / Right Side / Back)
        item {
            Text("4-View Turnaround Angle", style = MaterialTheme.typography.labelSmall, color = StudioAmber, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CharacterViewAngle.entries.forEach { angle ->
                    FilterChip(
                        selected = draft.viewAngle == angle.name,
                        onClick = { draft = draft.copy(viewAngle = angle.name) },
                        label = { Text(angle.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("char_view_${angle.name.lowercase()}")
                    )
                }
            }
        }

        // Character Presets & Name
        item {
            OutlinedTextField(
                value = draft.name,
                onValueChange = { draft = draft.copy(name = it) },
                label = { Text("Character Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text("Quick Presets", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ProceduralSmartTools.characterPresets.forEach { preset ->
                    FilterChip(
                        selected = draft.name == preset.name,
                        onClick = { draft = preset.copy(x = draft.x, y = draft.y, viewAngle = draft.viewAngle) },
                        label = { Text(preset.name, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Expression & Pose
        item {
            Text("Facial Expression", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("HAPPY", "NEUTRAL", "SURPRISED", "ANGRY", "SAD", "WINK", "TALKING").forEach { exp ->
                    FilterChip(
                        selected = draft.expression == exp,
                        onClick = {
                            draft = draft.copy(expression = exp)
                            if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) {
                                onKeyframeExpressionPose(exp, null)
                            }
                        },
                        label = { Text(exp, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Character Pose", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("IDLE", "WAVE", "WALK_A", "WALK_B", "JUMP", "HERO", "SIT").forEach { pose ->
                    FilterChip(
                        selected = draft.pose == pose,
                        onClick = {
                            draft = draft.copy(pose = pose)
                            if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) {
                                onKeyframeExpressionPose(null, pose)
                            }
                        },
                        label = { Text(pose, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Face, Eyes, Hair, Outfit, Accessory
        item {
            OptionRow("Face", listOf("OVAL", "ROUND", "SQUARE", "CHIBI"), draft.faceShape) { draft = draft.copy(faceShape = it) }
            OptionRow("Eyes", listOf("ANIME", "DOT", "CARTOON", "COOL", "STAR"), draft.eyeStyle) { draft = draft.copy(eyeStyle = it) }
            OptionRow("Hair", listOf("SPIKY", "BOB", "PONYTAIL", "CURLY", "MOHAWK", "BALD"), draft.hairStyle) { draft = draft.copy(hairStyle = it) }
            OptionRow("Outfit", listOf("HOODIE", "TEE", "JACKET", "CAPE", "TUNIC"), draft.shirtStyle) { draft = draft.copy(shirtStyle = it) }
            OptionRow("Accessory", listOf("NONE", "GLASSES", "HEADPHONES", "CROWN", "SCARF", "HAT"), draft.accessory) { draft = draft.copy(accessory = it) }
        }

        // Skin, Hair & Outfit Colors
        item {
            ColorRow("Skin Tone", listOf(0xFFFFDFC4L, 0xFFF5C6A5L, 0xFFE0AC69L, 0xFFC68642L, 0xFF8D5524L), draft.skinToneArgb) {
                draft = draft.copy(skinToneArgb = it)
            }
            ColorRow("Hair Color", listOf(0xFF1F2937L, 0xFF7C2D12L, 0xFF4C1D95L, 0xFFEC4899L, 0xFF0284C7L, 0xFFF59E0BL), draft.hairColorArgb) {
                draft = draft.copy(hairColorArgb = it)
            }
            ColorRow("Shirt Color", listOf(0xFFFF6B35L, 0xFF2DD4BFL, 0xFFA78BFAL, 0xFFFBBF24L, 0xFF10B981L, 0xFFFB7185L), draft.shirtColorArgb) {
                draft = draft.copy(shirtColorArgb = it)
            }
        }

        // Apply / Auto-Rig / Save Actions
        item {
            Button(
                onClick = { onAutoRigCharacter(draft) },
                colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth().testTag("auto_rig_character_button")
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Auto-Rig Human (14 Bones) & Add to Scene", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onApplyCharacter(draft, false) },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    modifier = Modifier.weight(1f).testTag("apply_character_button")
                ) {
                    Text(
                        if (uiState.selectedLayer?.type == LayerType.CHARACTER.name) "Update Layer" else "Insert Static",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedButton(
                    onClick = { onSaveTemplate(draft) },
                    modifier = Modifier.testTag("save_character_template_button")
                ) {
                    Icon(Icons.Rounded.BookmarkAdd, contentDescription = "Save template", modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(4.dp))
            OutlinedButton(
                onClick = { onApplyCharacter(draft, true) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add as New Character Layer", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RiggingInspectorPanel(
    uiState: StudioUiState,
    customAssets: List<SkeletalRig> = emptyList(),
    onAddRigLayer: () -> Unit,
    onAutoRigSelectedLayer: () -> Unit,
    onInsertMascotRig: () -> Unit,
    onSetViewAngle: (CharacterViewAngle) -> Unit,
    onSetHandProp: (isRightHand: Boolean, prop: HandPropKind) -> Unit,
    onImportHandPropPng: (isRightHand: Boolean) -> Unit,
    onAddExtraRigBone: (area: RigAttachmentArea, propKind: HandPropKind?) -> Unit = { _, _ -> },
    onImportExtraRigPng: (area: RigAttachmentArea) -> Unit = {},
    onAttachCustomAsset: (asset: SkeletalRig, area: RigAttachmentArea) -> Unit = { _, _ -> },
    onOpenCustomAssetMaker: () -> Unit = {},
    onUpdateBone: (boneId: String, (RigBone) -> RigBone) -> Unit = { _, _ -> },
    onDeleteBone: (boneId: String) -> Unit = {},
    onSelectBone: (String) -> Unit,
    onAddChildBone: (String) -> Unit,
    onApplyPosePreset: (String) -> Unit,
    onToggleIk: () -> Unit,
    onToggleSkin: () -> Unit,
    onSaveRigTemplate: () -> Unit
) {
    val rig = uiState.selectedLayer?.rig
    var newBoneName by remember { mutableStateOf("Tail / Prop") }
    var editingRightHand by remember { mutableStateOf(true) }
    var selectedAttachArea by remember { mutableStateOf(RigAttachmentArea.RIGHT_HAND) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (rig == null) {
            item {
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.AccessibilityNew, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(34.dp))
                        Text("Auto-Rig Human Skeleton", style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                        Text(
                            "Automatically rig the selected character/image layer into 14 human joints (Head, Spine, Arms, Hands, Legs, Feet) with 2-Bone IK!",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                        Button(
                            onClick = onAutoRigSelectedLayer,
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                            modifier = Modifier.fillMaxWidth().testTag("auto_rig_selected_layer_btn")
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Auto-Rig Selected Layer (Human)", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onAddRigLayer,
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth().testTag("create_humanoid_rig_button")
                        ) {
                            Text("Create New Humanoid Rig", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = onInsertMascotRig, modifier = Modifier.fillMaxWidth()) {
                            Text("Create Cartoon Mascot Rig")
                        }
                    }
                }
            }
        } else {
            item {
                Button(
                    onClick = onAutoRigSelectedLayer,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth().testTag("upgrade_human_autorig_btn")
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Auto-Rig Human (14 Separate Joints + IK)", fontWeight = FontWeight.Bold)
                }
            }

            // 4-View Turnaround Angle (Keyframeable per frame!)
            item {
                val rootEval = InterpolationEngine.evaluatePuppetRoot(rig, uiState.currentFrame)
                Text("4-View Turnaround (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CharacterViewAngle.entries.forEach { angle ->
                        FilterChip(
                            selected = rootEval.viewAngle == angle.name,
                            onClick = { onSetViewAngle(angle) },
                            label = { Text(angle.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("rig_view_${angle.name.lowercase()}")
                        )
                    }
                }
            }

            // Attach Anything to Left or Right Hand (Built-in Props + Custom PNG Import!)
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Attach Item to Hand", style = MaterialTheme.typography.titleSmall, color = StudioEmerald)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = !editingRightHand,
                            onClick = { editingRightHand = false },
                            label = { Text("L-Hand", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = editingRightHand,
                            onClick = { editingRightHand = true },
                            label = { Text("R-Hand", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                val activeProp = if (editingRightHand) rig.rightHandProp else rig.leftHandProp
                val hasCustomPng = !(if (editingRightHand) rig.rightHandCustomImagePath else rig.leftHandCustomImagePath).isNullOrBlank()
                FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    HandPropKind.entries.forEach { prop ->
                        FilterChip(
                            selected = !hasCustomPng && activeProp == prop.name,
                            onClick = { onSetHandProp(editingRightHand, prop) },
                            label = { Text(prop.label, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("hand_prop_${prop.name.lowercase()}")
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(
                    onClick = { onImportHandPropPng(editingRightHand) },
                    modifier = Modifier.fillMaxWidth().testTag("import_png_to_hand_btn")
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (hasCustomPng) "Replace Custom PNG in ${if (editingRightHand) "Right" else "Left"} Hand"
                        else "Import Custom PNG into ${if (editingRightHand) "Right" else "Left"} Hand",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            // Extra Variable Rig & Attachments on ANY Body Area (Hands, Legs, Foot, Head, Chest, Hip, or Selected Bone!)
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth().testTag("extra_variable_rig_card")
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Rounded.Extension, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(16.dp))
                                Text(
                                    "Extra Variable Rig (Any Body Area)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = StudioCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            "Add movable extra rig bones + objects, custom PNGs, or saved Custom Assets onto Hands, Legs, Feet, Head, Chest, or Hip.",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextSecondary
                        )

                        // Area Picker Chips
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            RigAttachmentArea.entries.forEach { area ->
                                FilterChip(
                                    selected = selectedAttachArea == area,
                                    onClick = { selectedAttachArea = area },
                                    label = { Text(area.shortLabel, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("extra_rig_area_${area.name.lowercase()}")
                                )
                            }
                        }

                        // Primary Actions for Selected Area: Blank Variable Bone or Custom PNG
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { onAddExtraRigBone(selectedAttachArea, null) },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                                modifier = Modifier.weight(1f).testTag("add_extra_bone_btn")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("+ Rig Bone", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { onImportExtraRigPng(selectedAttachArea) },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                                modifier = Modifier.weight(1f).testTag("add_extra_png_rig_btn")
                            ) {
                                Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("+ PNG Object", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Quick Built-in Animated Prop Attached as Independent Extra Variable Bone
                        Text(
                            "Quick Attach Prop to ${selectedAttachArea.label}:",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioAmber
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            HandPropKind.entries.filter { it != HandPropKind.NONE }.forEach { prop ->
                                FilterChip(
                                    selected = false,
                                    onClick = { onAddExtraRigBone(selectedAttachArea, prop) },
                                    label = { Text("+ ${prop.label}", style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("extra_rig_prop_${prop.name.lowercase()}")
                                )
                            }
                        }

                        // Attach User's Saved Custom Rigged Assets directly onto the chosen body area!
                        HorizontalDivider(color = StudioBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "My Custom Assets (${customAssets.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = StudioEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            OutlinedButton(
                                onClick = onOpenCustomAssetMaker,
                                modifier = Modifier.testTag("open_custom_asset_maker_from_rig_btn")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("Make Asset", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                            }
                        }
                        if (customAssets.isEmpty()) {
                            Text(
                                "Tap \"Make Asset\" to build & rig your own reusable objects/props (sword, cape, wings, skateboard, custom PNG) and attach them to any area!",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        } else {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                customAssets.forEach { asset ->
                                    FilterChip(
                                        selected = false,
                                        onClick = { onAttachCustomAsset(asset, selectedAttachArea) },
                                        label = { Text("+ ${asset.name} (${asset.bones.size}b)", style = MaterialTheme.typography.labelSmall) },
                                        modifier = Modifier.testTag("attach_custom_asset_${asset.id}")
                                    )
                                }
                            }
                        }

                        // Live Tuning Sliders for Currently Selected Extra Variable Bone
                        val selBone = rig.bones.firstOrNull { it.id == uiState.selectedBoneId }
                        if (selBone != null && (selBone.isExtraRigBone || !selBone.boundImagePath.isNullOrBlank() || !selBone.attachedPropKind.isNullOrBlank())) {
                            HorizontalDivider(color = StudioBorder)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Tune: ${selBone.name}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StudioAmber,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(
                                    onClick = { onDeleteBone(selBone.id) },
                                    modifier = Modifier.size(28.dp).testTag("delete_extra_bone_${selBone.id}")
                                ) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete extra rig bone", tint = StudioRose, modifier = Modifier.size(17.dp))
                                }
                            }
                            Text(
                                "Object Scale: ${String.format("%.2fx", selBone.imageScale)} • Bone Len: ${selBone.length.toInt()}px",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextSecondary
                            )
                            Slider(
                                value = selBone.imageScale.coerceIn(0.1f, 6.0f),
                                onValueChange = { sc -> onUpdateBone(selBone.id) { it.copy(imageScale = sc) } },
                                valueRange = 0.1f..6.0f,
                                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan)
                            )
                            Slider(
                                value = selBone.length.coerceIn(18f, 260f),
                                onValueChange = { len -> onUpdateBone(selBone.id) { it.copy(length = len) } },
                                valueRange = 18f..260f,
                                colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber)
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("2-Bone Inverse Kinematics (IK)", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                    Switch(checked = rig.ikEnabled, onCheckedChange = { onToggleIk() })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Show Stylized Limb Mesh", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                    Switch(checked = rig.showSkinMesh, onCheckedChange = { onToggleSkin() })
                }
            }

            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Keyframe Pose Presets (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("IDLE", "WAVE", "WALK_A", "WALK_B", "JUMP").forEach { pose ->
                        FilterChip(
                            selected = false,
                            onClick = { onApplyPosePreset(pose) },
                            label = { Text(pose, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Add Child Bone", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                Spacer(Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = newBoneName,
                        onValueChange = { newBoneName = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { onAddChildBone(newBoneName) },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioCoral)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Add bone", modifier = Modifier.size(18.dp))
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Bone Hierarchy (${rig.bones.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                    OutlinedButton(onClick = onSaveRigTemplate) {
                        Text("Save Rig", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            items(rig.bones, key = { it.id }) { bone ->
                val isSel = uiState.selectedBoneId == bone.id
                Surface(
                    color = if (isSel) StudioSurfaceElevated else StudioSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (isSel) StudioCoral else StudioBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectBone(bone.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(bone.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                            Text(
                                text = "Parent: ${bone.parentId ?: "Root"} • Len ${bone.length.toInt()}px",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextMuted
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (bone.isExtraRigBone) {
                                IconButton(
                                    onClick = { onDeleteBone(bone.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete extra bone", tint = StudioRose, modifier = Modifier.size(15.dp))
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(bone.colorArgb))
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OptionRow(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            options.forEach { opt ->
                FilterChip(
                    selected = selected == opt,
                    onClick = { onSelect(opt) },
                    label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                )
            }
        }
    }
}

@Composable
private fun ColorRow(label: String, colors: List<Long>, selected: Long, onSelect: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.forEach { argb ->
                val isSel = selected == argb
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .border(if (isSel) 2.5.dp else 1.dp, if (isSel) StudioViolet else StudioBorder, CircleShape)
                        .clickable { onSelect(argb) }
                )
            }
        }
    }
}
