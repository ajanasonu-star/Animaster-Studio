package com.example.engine

import android.graphics.Path
import com.example.data.model.CharacterSpec
import com.example.data.model.CodedVectorPath
import com.example.data.model.CustomModelPart
import com.example.data.model.RigBone
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class CharacterCodeParseResult(
    val spec: CharacterSpec? = null,
    val rig: SkeletalRig? = null,
    val error: String? = null,
    val detectedFormat: String = "JSON" // "JSON" or "JS"
)

/**
 * Multi-Archetype Model Parser & Normal JavaScript (JS) HTML5 Canvas 2D Interpreter
 * for the "Create Character by Code" Builder.
 *
 * Supports:
 * 1. Multi-archetype JSON models (`"HUMANOID"`, `"VEGETABLE_FRUIT"`, `"ANIMAL"`, `"OBJECT"`)
 *    with `hasFace`, `customParts` (`"OVAL"`, `"ROUNDED_RECT"`, `"ORGANIC_BLOB"`, `"TAPERED_CONE"`,
 *    `"CAPSULE"`, `"CRESCENT"`, `"POLYGON"`), `0..N` custom `bones`, and SVG `paths`.
 * 2. Normal procedural HTML5 Canvas JavaScript drawing scripts (`ctx.fillStyle`, `ctx.strokeStyle`,
 *    `ctx.lineWidth`, `ctx.beginPath()`, `ctx.arc()`, `ctx.ellipse()`, `ctx.fillRect()`,
 *    `ctx.strokeRect()`, `ctx.roundRect()`, `ctx.moveTo()`, `ctx.lineTo()`,
 *    `ctx.quadraticCurveTo()`, `ctx.bezierCurveTo()`, `ctx.closePath()`, `ctx.fill()`,
 *    `ctx.stroke()`, `ctx.save()`, `ctx.restore()`, `ctx.translate()`, `ctx.rotate()`, `ctx.scale()`).
 */
object CharacterCodeParser {

    val AI_JSON_PROMPT_TEMPLATE: String = """
Generate a valid JSON model for Animaster Studio 2D Animation Engine.
Return ONLY a single raw JSON object (no markdown fences) matching one of the 4 supported modelType archetypes:
1. "HUMANOID" (human character with hair, face, shirt, pants, shoes, full biped skeleton)
2. "VEGETABLE_FRUIT" (talking or non-talking potato, tomato, carrot, apple, mango, etc. — NO human shirt/pants/shoes/neck)
3. "ANIMAL" (dog, cat, bird, fish, rabbit with ears, snout, tail, wings/paws — NO human clothing)
4. "OBJECT" (inanimate object like car, tree, house, lamp, sword, table — set "hasFace": false and "bones": [] for a rigid boneless prop, or add custom bones/face if animated)

JSON Schema:
{
  "name": "Model Name",
  "modelType": "HUMANOID | VEGETABLE_FRUIT | ANIMAL | OBJECT",
  "hasFace": true,
  "skinColor": "#E2A76F",
  "eyeStyle": "ANIME | ROUND | CUTE",
  "eyeColor": "#1E293B",
  "mouthStyle": "SMILE | HAPPY_OPEN | COOL",
  "hairStyle": "SPIKY | LONG | SHORT | NONE",
  "hairColor": "#1E293B",
  "shirtStyle": "HOODIE | KURTA | JACKET | TEE",
  "shirtColor": "#2563EB",
  "pantsColor": "#0F172A",
  "accessory": "NONE | GLASSES | CROWN | CAP | HEADBAND",
  "customParts": [
    {
      "name": "Body / Part Name",
      "shape": "OVAL | ROUNDED_RECT | ORGANIC_BLOB | TAPERED_CONE | CAPSULE | CRESCENT | POLYGON",
      "parentBoneId": "ROOT",
      "offsetX": 0,
      "offsetY": 0,
      "width": 120,
      "height": 150,
      "rotationDeg": 0,
      "cornerRadius": 20,
      "zIndex": 0,
      "fillColor": "#D97706",
      "secondaryColor": "#B45309",
      "strokeColor": "#451A03",
      "strokeWidth": 3.0,
      "spotsOrDimples": 6,
      "points": [{"x": -40, "y": -20}, {"x": 40, "y": -20}, {"x": 0, "y": 50}]
    }
  ],
  "bones": [
    {"id": "body", "name": "Body", "parentId": null, "length": 80, "angleDeg": -90}
  ],
  "paths": [
    {
      "attachTo": "ROOT | HEAD | TORSO",
      "fill": "#22C55E",
      "stroke": "#14532D",
      "strokeWidth": 2.5,
      "d": "M -15 -75 Q 0 -105 18 -80 Q 0 -65 -15 -75 Z"
    }
  ]
}
Create a detailed, expressive model for: [DESCRIBE YOUR HUMAN, VEGETABLE, ANIMAL, OR OBJECT HERE]
    """.trimIndent()

    val AI_JS_PROMPT_TEMPLATE: String = """
Write a normal HTML5 Canvas 2D JavaScript drawing script for Animaster Studio.
Return ONLY valid JavaScript code using standard `ctx` 2D canvas commands centered around (0, 0).
Optional top metadata comments you can include:
// @name: Model Name
// @modelType: OBJECT | VEGETABLE_FRUIT | ANIMAL | HUMANOID
// @hasFace: false

Supported standard JS Canvas commands:
- ctx.fillStyle = "#HEX"; ctx.strokeStyle = "#HEX"; ctx.lineWidth = 3;
- ctx.beginPath(); ctx.closePath(); ctx.fill(); ctx.stroke();
- ctx.moveTo(x, y); ctx.lineTo(x, y);
- ctx.quadraticCurveTo(cx, cy, x, y); ctx.bezierCurveTo(c1x, c1y, c2x, c2y, x, y);
- ctx.arc(x, y, radius, startAngle, endAngle);
- ctx.ellipse(x, y, radiusX, radiusY, rotation, startAngle, endAngle);
- ctx.fillRect(x, y, w, h); ctx.strokeRect(x, y, w, h); ctx.roundRect(x, y, w, h, r);
- ctx.save(); ctx.restore(); ctx.translate(x, y); ctx.rotate(rad); ctx.scale(sx, sy);

Draw a clean, layered 2D cartoon vector illustration centered at (0, 0) for: [DESCRIBE YOUR CHARACTER, VEGETABLE, ANIMAL, OR OBJECT HERE]
    """.trimIndent()

    val SAMPLE_HUMAN_JSON: String = """
{
  "name": "Cyber Nova",
  "modelType": "HUMANOID",
  "hasFace": true,
  "skinColor": "#F5C6A5",
  "hairStyle": "SPIKY",
  "hairColor": "#1E293B",
  "eyeStyle": "ANIME",
  "eyeColor": "#06B6D4",
  "mouthStyle": "SMILE",
  "shirtStyle": "HOODIE",
  "shirtColor": "#2563EB",
  "pantsColor": "#0F172A",
  "accessory": "GLASSES",
  "paths": [
    {
      "attachTo": "HEAD",
      "fill": "#FFD600",
      "stroke": "#0F172A",
      "strokeWidth": 2.5,
      "d": "M -18 -42 L -6 -62 L 0 -46 L 6 -62 L 18 -42 Q 0 -36 -18 -42 Z"
    },
    {
      "attachTo": "TORSO",
      "fill": "#38BDF8",
      "stroke": "#0F172A",
      "strokeWidth": 2.5,
      "d": "M 0 -22 L 14 0 L 0 22 L -14 0 Z"
    }
  ]
}
    """.trimIndent()

    val SAMPLE_POTATO_VEG_JSON: String = """
{
  "name": "Paplu Potato",
  "modelType": "VEGETABLE_FRUIT",
  "hasFace": true,
  "skinColor": "#D99B52",
  "eyeStyle": "ROUND",
  "eyeColor": "#1E293B",
  "mouthStyle": "HAPPY_OPEN",
  "hairStyle": "NONE",
  "customParts": [
    {
      "name": "Potato Tuber Body",
      "shape": "ORGANIC_BLOB",
      "parentBoneId": "body",
      "offsetX": 0,
      "offsetY": -10,
      "width": 135,
      "height": 165,
      "zIndex": 0,
      "fillColor": "#D99B52",
      "secondaryColor": "#B87A34",
      "strokeColor": "#5C3A14",
      "strokeWidth": 3.5,
      "spotsOrDimples": 7
    },
    {
      "name": "Sprout Leaf Left",
      "shape": "CRESCENT",
      "parentBoneId": "head",
      "offsetX": -12,
      "offsetY": -68,
      "width": 26,
      "height": 18,
      "rotationDeg": -28,
      "zIndex": 5,
      "fillColor": "#22C55E",
      "strokeColor": "#14532D",
      "strokeWidth": 2.5
    },
    {
      "name": "Sprout Leaf Right",
      "shape": "CRESCENT",
      "parentBoneId": "head",
      "offsetX": 14,
      "offsetY": -66,
      "width": 26,
      "height": 18,
      "rotationDeg": 25,
      "zIndex": 5,
      "fillColor": "#4ADE80",
      "strokeColor": "#14532D",
      "strokeWidth": 2.5
    }
  ]
}
    """.trimIndent()

    val SAMPLE_DOG_ANIMAL_JSON: String = """
{
  "name": "Bruno Puppy",
  "modelType": "ANIMAL",
  "hasFace": true,
  "skinColor": "#C68642",
  "eyeStyle": "ROUND",
  "eyeColor": "#1E1B18",
  "mouthStyle": "SMILE",
  "hairStyle": "NONE",
  "customParts": [
    {
      "name": "Wagging Tail",
      "shape": "CRESCENT",
      "parentBoneId": "tail",
      "offsetX": -56,
      "offsetY": -18,
      "width": 48,
      "height": 22,
      "rotationDeg": -40,
      "zIndex": -3,
      "fillColor": "#8D5524",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Back Left Leg",
      "shape": "CAPSULE",
      "parentBoneId": "leg_back_l",
      "offsetX": -36,
      "offsetY": 44,
      "width": 24,
      "height": 58,
      "zIndex": -2,
      "fillColor": "#A0622A",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Front Left Leg",
      "shape": "CAPSULE",
      "parentBoneId": "leg_front_l",
      "offsetX": 22,
      "offsetY": 44,
      "width": 24,
      "height": 58,
      "zIndex": -1,
      "fillColor": "#A0622A",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Puppy Torso",
      "shape": "CAPSULE",
      "parentBoneId": "body",
      "offsetX": -6,
      "offsetY": 6,
      "width": 124,
      "height": 74,
      "zIndex": 0,
      "fillColor": "#C68642",
      "secondaryColor": "#F3D2B3",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.2,
      "spotsOrDimples": 3
    },
    {
      "name": "Back Right Leg",
      "shape": "CAPSULE",
      "parentBoneId": "leg_back_r",
      "offsetX": -22,
      "offsetY": 48,
      "width": 24,
      "height": 58,
      "zIndex": 1,
      "fillColor": "#C68642",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Front Right Leg",
      "shape": "CAPSULE",
      "parentBoneId": "leg_front_r",
      "offsetX": 36,
      "offsetY": 48,
      "width": 24,
      "height": 58,
      "zIndex": 2,
      "fillColor": "#C68642",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Floppy Ear Left",
      "shape": "OVAL",
      "parentBoneId": "head",
      "offsetX": -34,
      "offsetY": -38,
      "width": 26,
      "height": 54,
      "rotationDeg": 18,
      "zIndex": 4,
      "fillColor": "#6B3E16",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Floppy Ear Right",
      "shape": "OVAL",
      "parentBoneId": "head",
      "offsetX": 34,
      "offsetY": -38,
      "width": 26,
      "height": 54,
      "rotationDeg": -18,
      "zIndex": 4,
      "fillColor": "#6B3E16",
      "strokeColor": "#3E2108",
      "strokeWidth": 3.0
    },
    {
      "name": "Puppy Snout & Nose",
      "shape": "OVAL",
      "parentBoneId": "head",
      "offsetX": 0,
      "offsetY": -18,
      "width": 44,
      "height": 28,
      "zIndex": 6,
      "fillColor": "#F5D6B8",
      "strokeColor": "#3E2108",
      "strokeWidth": 2.6
    }
  ]
}
    """.trimIndent()

    val SAMPLE_CAR_OBJECT_JS: String = """
// @name: Retro Red Cruiser
// @modelType: OBJECT
// @hasFace: false
function drawCar(ctx) {
  // Upper cabin roof
  ctx.fillStyle = "#DC2626";
  ctx.strokeStyle = "#0F172A";
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.roundRect(-65, -62, 125, 48, 18);
  ctx.fill();
  ctx.stroke();

  // Glass windows
  ctx.fillStyle = "#BAE6FD";
  ctx.beginPath();
  ctx.roundRect(-52, -54, 46, 30, 8);
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.roundRect(4, -54, 46, 30, 8);
  ctx.fill();
  ctx.stroke();

  // Main car chassis body
  ctx.fillStyle = "#EF4444";
  ctx.beginPath();
  ctx.roundRect(-110, -24, 220, 56, 16);
  ctx.fill();
  ctx.stroke();

  // Headlight & taillight
  ctx.fillStyle = "#FACC15";
  ctx.beginPath();
  ctx.arc(102, -4, 9, 0, 6.283);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#FB7185";
  ctx.beginPath();
  ctx.arc(-102, -4, 8, 0, 6.283);
  ctx.fill();
  ctx.stroke();

  // Rear & Front Tires
  ctx.fillStyle = "#1E293B";
  ctx.beginPath();
  ctx.arc(-62, 32, 26, 0, 6.283);
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(62, 32, 26, 0, 6.283);
  ctx.fill();
  ctx.stroke();

  // Alloy Rims
  ctx.fillStyle = "#E2E8F0";
  ctx.beginPath();
  ctx.arc(-62, 32, 12, 0, 6.283);
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(62, 32, 12, 0, 6.283);
  ctx.fill();
  ctx.stroke();
}
    """.trimIndent()

    val DEFAULT_TEMPLATE_JSON: String = SAMPLE_HUMAN_JSON
    val ROYAL_WIZARD_TEMPLATE_JSON: String = """
{
  "name": "Royal Wizard",
  "modelType": "HUMANOID",
  "hasFace": true,
  "skinColor": "#E8B490",
  "hairStyle": "LONG",
  "hairColor": "#E2E8F0",
  "eyeStyle": "ROUND",
  "eyeColor": "#A855F7",
  "mouthStyle": "SMILE",
  "shirtStyle": "KURTA",
  "shirtColor": "#6D28D9",
  "pantsColor": "#312E81",
  "accessory": "CROWN",
  "paths": [
    {
      "attachTo": "HEAD",
      "fill": "#7C3AED",
      "stroke": "#FACC15",
      "strokeWidth": 3.0,
      "d": "M -34 -34 Q 0 -46 34 -34 L 4 -92 C -2 -82 -16 -60 -34 -34 Z"
    },
    {
      "attachTo": "TORSO",
      "fill": "#FACC15",
      "stroke": "#1E1B4B",
      "strokeWidth": 2.0,
      "d": "M 0 -20 L 6 -6 L 20 -6 L 9 4 L 13 18 L 0 9 L -13 18 L -9 4 L -20 -6 L -6 -6 Z"
    }
  ]
}
    """.trimIndent()

    val CAPE_NINJA_TEMPLATE_JSON: String = """
{
  "name": "Shadow Striker",
  "modelType": "HUMANOID",
  "hasFace": true,
  "skinColor": "#F0C09A",
  "hairStyle": "SPIKY",
  "hairColor": "#0F172A",
  "eyeStyle": "ANIME",
  "eyeColor": "#EF4444",
  "mouthStyle": "COOL",
  "shirtStyle": "JACKET",
  "shirtColor": "#18181B",
  "pantsColor": "#09090B",
  "accessory": "HEADBAND",
  "paths": [
    {
      "attachTo": "HEAD",
      "fill": "#EF4444",
      "stroke": "#09090B",
      "strokeWidth": 2.5,
      "d": "M -36 -22 Q 0 -30 36 -22 L 36 -10 Q 0 -18 -36 -10 Z"
    },
    {
      "attachTo": "TORSO",
      "fill": "#DC2626",
      "stroke": "#09090B",
      "strokeWidth": 2.5,
      "d": "M -24 -28 C -10 -12 10 -12 24 -28 L 16 14 Q 0 26 -16 14 Z"
    }
  ]
}
    """.trimIndent()

    fun parseColorHex(raw: String?, fallback: Long): Long {
        if (raw.isNullOrBlank()) return fallback
        val cleaned = raw.trim().removeSurrounding("\"").removeSurrounding("'")
            .trim()
        if (cleaned.equals("none", ignoreCase = true) || cleaned.equals("transparent", ignoreCase = true)) {
            return 0x00000000L
        }
        // Named CSS colors support for JS Canvas scripts
        when (cleaned.lowercase(Locale.US)) {
            "black" -> return 0xFF000000L
            "white" -> return 0xFFFFFFFFL
            "red" -> return 0xFFEF4444L
            "green" -> return 0xFF22C55EL
            "blue" -> return 0xFF3B82F6L
            "yellow" -> return 0xFFFACC15L
            "orange" -> return 0xFFF97316L
            "purple" -> return 0xFFA855F7L
            "pink" -> return 0xFFEC4899L
            "brown" -> return 0xFF92400EL
            "gray", "grey" -> return 0xFF64748BL
            "cyan" -> return 0xFF06B6D4L
        }
        if (cleaned.startsWith("rgb", ignoreCase = true)) {
            val nums = Regex("[-+]?\\d*\\.?\\d+").findAll(cleaned).mapNotNull { it.value.toFloatOrNull() }.toList()
            if (nums.size >= 3) {
                val r = nums[0].toInt().coerceIn(0, 255).toLong()
                val g = nums[1].toInt().coerceIn(0, 255).toLong()
                val b = nums[2].toInt().coerceIn(0, 255).toLong()
                val a = if (nums.size >= 4) (nums[3].coerceIn(0f, 1f) * 255f).toInt().toLong() else 255L
                return (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val hexStr = cleaned.removePrefix("#").removePrefix("0x").removePrefix("0X")
        val parsed = hexStr.toLongOrNull(16) ?: return fallback
        return when (hexStr.length) {
            6 -> 0xFF000000L or parsed
            8 -> parsed
            3 -> {
                val r = ((parsed shr 8) and 0xF) * 17
                val g = ((parsed shr 4) and 0xF) * 17
                val b = (parsed and 0xF) * 17
                0xFF000000L or (r shl 16) or (g shl 8) or b
            }
            else -> fallback
        }
    }

    private val jsonMapAdapter by lazy {
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
        val type = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)
        moshi.adapter<Map<String, Any?>>(type)
    }

    private fun Map<*, *>.optStr(key: String, fallback: String): String {
        val v = this[key] ?: return fallback
        return v.toString().trim().ifBlank { fallback }
    }

    private fun Map<*, *>.optNum(key: String, fallback: Double): Double {
        val v = this[key] ?: return fallback
        return when (v) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: fallback
            else -> fallback
        }
    }

    private fun Map<*, *>.optBool(key: String, fallback: Boolean): Boolean {
        val v = this[key] ?: return fallback
        return when (v) {
            is Boolean -> v
            is String -> v.trim().equals("true", ignoreCase = true)
            is Number -> v.toInt() != 0
            else -> fallback
        }
    }

    /**
     * Auto-detects and parses either:
     * - Structured JSON (`{...}`) supporting `"HUMANOID"`, `"VEGETABLE_FRUIT"`, `"ANIMAL"`, and `"OBJECT"`
     * - Normal JavaScript (`JS`) HTML5 Canvas 2D drawing scripts (`ctx.beginPath()`, `ctx.arc()`, `ctx.fillRect()`, etc.)
     */
    fun parseCharacterCode(code: String): CharacterCodeParseResult {
        val trimmed = stripMarkdownCodeFences(code.trim())
        if (trimmed.isEmpty()) {
            return CharacterCodeParseResult(error = "Paste or enter JSON or JavaScript (ctx) code to preview.")
        }
        return if (looksLikeJavaScriptCanvasCode(trimmed)) {
            parseJsCanvasScript(trimmed)
        } else {
            parseJsonCharacterCode(trimmed)
        }
    }

    private fun stripMarkdownCodeFences(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) {
            val firstNewline = s.indexOf('\n')
            if (firstNewline != -1) {
                s = s.substring(firstNewline + 1)
            }
            if (s.endsWith("```")) {
                s = s.substring(0, s.length - 3)
            }
        }
        return s.trim()
    }

    private fun looksLikeJavaScriptCanvasCode(trimmed: String): Boolean {
        if (!trimmed.startsWith("{")) return true
        return trimmed.contains("ctx.") ||
            trimmed.contains("beginPath") ||
            trimmed.contains("fillRect") ||
            trimmed.contains("roundRect") ||
            trimmed.contains("function ")
    }

    private fun normalizeArchetype(raw: String): String {
        return when (raw.trim().uppercase(Locale.US)) {
            "HUMANOID", "HUMAN", "PERSON", "CHARACTER" -> "HUMANOID"
            "VEGETABLE_FRUIT", "VEGETABLE", "FRUIT", "VEG", "PLANT_FOOD", "POTATO", "TOMATO" -> "VEGETABLE_FRUIT"
            "ANIMAL", "QUADRUPED", "PET", "DOG", "CAT", "BIRD", "FISH", "CREATURE" -> "ANIMAL"
            "OBJECT", "PROP", "VEHICLE", "CAR", "ITEM", "INANIMATE", "FURNITURE", "BUILDING" -> "OBJECT"
            else -> "HUMANOID"
        }
    }

    private fun parseJsonCharacterCode(trimmed: String): CharacterCodeParseResult {
        return try {
            val json = jsonMapAdapter.fromJson(trimmed)
                ?: return CharacterCodeParseResult(error = "Expected a JSON object {...} or JS ctx script")
            val name = json.optStr("name", "Coded Model")
            val modelType = normalizeArchetype(json.optStr("modelType", json.optStr("archetype", "HUMANOID")))
            val defaultHasFace = modelType != "OBJECT"
            val hasFace = json.optBool("hasFace", defaultHasFace)

            val skinColor = parseColorHex(
                json.optStr("skinColor", json.optStr("bodyColor", json.optStr("fillColor", ""))),
                when (modelType) {
                    "VEGETABLE_FRUIT" -> 0xFFD99B52L
                    "ANIMAL" -> 0xFFC68642L
                    "OBJECT" -> 0xFF64748BL
                    else -> 0xFFF5C6A5L
                }
            )
            val hairStyle = json.optStr("hairStyle", if (modelType == "HUMANOID") "SPIKY" else "NONE").uppercase(Locale.US)
            val hairColor = parseColorHex(json.optStr("hairColor", ""), 0xFF1E293BL)
            val eyeStyle = json.optStr("eyeStyle", "ANIME").uppercase(Locale.US)
            val eyeColor = parseColorHex(json.optStr("eyeColor", ""), 0xFF06B6D4L)
            val mouthStyle = json.optStr("mouthStyle", "SMILE").uppercase(Locale.US)
            val faceShape = json.optStr("faceShape", "OVAL").uppercase(Locale.US)
            val shirtStyle = json.optStr("shirtStyle", "HOODIE").uppercase(Locale.US)
            val shirtColor = parseColorHex(json.optStr("shirtColor", ""), 0xFF2563EBL)
            val pantsColor = parseColorHex(json.optStr("pantsColor", ""), 0xFF0F172AL)
            val accessory = json.optStr("accessory", "NONE").uppercase(Locale.US)
            val shoulderWidth = json.optNum("shoulderWidth", 1.0).toFloat().coerceIn(0.65f, 1.55f)
            val bellyPlumpness = json.optNum("bellyPlumpness", 0.0).toFloat().coerceIn(0f, 1f)

            // Parse CustomModelParts ("customParts" or "parts")
            val parsedParts = mutableListOf<CustomModelPart>()
            val partsRaw = (json["customParts"] as? List<*>) ?: (json["parts"] as? List<*>)
            if (partsRaw != null) {
                for ((idx, item) in partsRaw.withIndex()) {
                    val obj = item as? Map<*, *> ?: continue
                    val partName = obj.optStr("name", "Part ${idx + 1}")
                    val shape = obj.optStr("shape", "OVAL").uppercase(Locale.US)
                    val parentBoneId = obj.optStr("parentBoneId", obj.optStr("attachTo", "ROOT"))
                    val offsetX = obj.optNum("offsetX", obj.optNum("x", 0.0)).toFloat()
                    val offsetY = obj.optNum("offsetY", obj.optNum("y", 0.0)).toFloat()
                    val width = obj.optNum("width", obj.optNum("w", 90.0)).toFloat().coerceIn(4f, 900f)
                    val height = obj.optNum("height", obj.optNum("h", 90.0)).toFloat().coerceIn(4f, 900f)
                    val rotationDeg = obj.optNum("rotationDeg", obj.optNum("rotation", 0.0)).toFloat()
                    val cornerRadius = obj.optNum("cornerRadius", 16.0).toFloat().coerceIn(0f, 300f)
                    val zIndex = obj.optNum("zIndex", idx.toDouble()).toInt()
                    val fillHex = obj.optStr("fillColor", obj.optStr("fill", "#D99B52"))
                    val secHex = obj.optStr("secondaryColor", "")
                    val strokeHex = obj.optStr("strokeColor", obj.optStr("stroke", "#1E293B"))
                    val strokeW = obj.optNum("strokeWidth", 2.8).toFloat().coerceIn(0f, 24f)
                    val spots = obj.optNum("spotsOrDimples", obj.optNum("spots", 0.0)).toInt().coerceIn(0, 32)

                    val pts = mutableListOf<Vec2>()
                    val ptsRaw = obj["points"] as? List<*>
                    if (ptsRaw != null) {
                        for (pt in ptsRaw) {
                            when (pt) {
                                is Map<*, *> -> {
                                    val px = pt.optNum("x", 0.0).toFloat()
                                    val py = pt.optNum("y", 0.0).toFloat()
                                    pts += Vec2(px, py)
                                }
                                is List<*> -> {
                                    val px = (pt.getOrNull(0) as? Number)?.toFloat() ?: 0f
                                    val py = (pt.getOrNull(1) as? Number)?.toFloat() ?: 0f
                                    pts += Vec2(px, py)
                                }
                            }
                        }
                    }

                    parsedParts += CustomModelPart(
                        name = partName,
                        shape = shape,
                        parentBoneId = parentBoneId,
                        offsetX = offsetX,
                        offsetY = offsetY,
                        width = width,
                        height = height,
                        rotationDeg = rotationDeg,
                        cornerRadius = cornerRadius,
                        zIndex = zIndex,
                        fillColorArgb = parseColorHex(fillHex, skinColor),
                        secondaryColorArgb = if (secHex.isBlank()) 0x00000000L else parseColorHex(secHex, 0x00000000L),
                        strokeColorArgb = parseColorHex(strokeHex, 0xFF1E293BL),
                        strokeWidth = strokeW,
                        spotsOrDimples = spots,
                        points = pts
                    )
                }
            }

            // Parse SVG-style paths
            val parsedPaths = mutableListOf<CodedVectorPath>()
            val pathsRaw = json["paths"] as? List<*>
            if (pathsRaw != null) {
                for ((idx, item) in pathsRaw.withIndex()) {
                    val obj = item as? Map<*, *> ?: continue
                    val d = obj.optStr("d", "")
                    if (d.isEmpty()) continue
                    val fillHex = obj.optStr("fill", "#FFD600")
                    val strokeHex = obj.optStr("stroke", "#0F172A")
                    val strokeW = obj.optNum("strokeWidth", 2.5).toFloat().coerceIn(0f, 24f)
                    val attachTo = obj.optStr("attachTo", if (modelType == "HUMANOID") "HEAD" else "ROOT")
                    val zIndex = obj.optNum("zIndex", idx.toDouble()).toInt()
                    parsedPaths += CodedVectorPath(
                        d = d,
                        fillColorArgb = parseColorHex(fillHex, 0xFFFFD600L),
                        strokeColorArgb = parseColorHex(strokeHex, 0xFF0F172AL),
                        strokeWidth = strokeW,
                        attachTo = attachTo,
                        zIndex = zIndex
                    )
                }
            }

            // Optional custom bones list (can be explicitly empty [] for 0-bone rigid objects!)
            val hasExplicitBonesKey = json.containsKey("bones")
            val customBones = mutableListOf<RigBone>()
            val bonesRaw = json["bones"] as? List<*>
            if (bonesRaw != null) {
                for (item in bonesRaw) {
                    val bObj = item as? Map<*, *> ?: continue
                    val bId = bObj.optStr("id", "bone_${customBones.size}")
                    val bName = bObj.optStr("name", bId)
                    val parentRaw = bObj["parentId"]?.toString()?.trim()
                    val parentId = if (parentRaw.isNullOrBlank() || parentRaw.equals("null", ignoreCase = true)) null else parentRaw
                    val length = bObj.optNum("length", 65.0).toFloat().coerceIn(10f, 400f)
                    val angle = bObj.optNum("angleDeg", bObj.optNum("localAngleDeg", -90.0)).toFloat()
                    val thickness = bObj.optNum("thickness", 18.0).toFloat().coerceIn(4f, 80f)
                    val bColor = parseColorHex(bObj.optStr("color", ""), skinColor)
                    val pivX = bObj.optNum("offsetX", bObj.optNum("basePivotOffsetX", 0.0)).toFloat()
                    val pivY = bObj.optNum("offsetY", bObj.optNum("basePivotOffsetY", 0.0)).toFloat()
                    customBones += RigBone(
                        id = bId,
                        name = bName,
                        parentId = parentId,
                        length = length,
                        localAngleDeg = angle,
                        thickness = thickness,
                        colorArgb = bColor,
                        basePivotOffsetX = pivX,
                        basePivotOffsetY = pivY
                    )
                }
            }

            val spec = CharacterSpec(
                name = name,
                skinToneArgb = skinColor,
                faceShape = faceShape,
                eyeStyle = eyeStyle,
                eyeColorArgb = eyeColor,
                mouthStyle = mouthStyle,
                hairStyle = hairStyle,
                hairColorArgb = hairColor,
                shirtStyle = shirtStyle,
                shirtColorArgb = shirtColor,
                pantsColorArgb = pantsColor,
                accessory = accessory,
                shoulderWidth = shoulderWidth,
                bellyPlumpness = bellyPlumpness,
                modelType = modelType,
                hasFace = hasFace,
                customParts = parsedParts,
                customCodePaths = parsedPaths,
                rawCode = trimmed
            )
            val rig = RigSolver.createRiggedCharacterFromSpec(
                spec = spec,
                rootX = 640f,
                rootY = 420f,
                customBonesOverride = if (hasExplicitBonesKey) customBones else null
            )
            CharacterCodeParseResult(spec = spec, rig = rig, error = null, detectedFormat = "JSON")
        } catch (e: Exception) {
            CharacterCodeParseResult(error = e.message?.take(120) ?: "Invalid JSON syntax", detectedFormat = "JSON")
        }
    }

    // =========================================================================
    // NORMAL JAVASCRIPT (JS) HTML5 CANVAS 2D DRAWING INTERPRETER
    // =========================================================================

    private data class JsTransformState(
        var tx: Float = 0f,
        var ty: Float = 0f,
        var rotRad: Float = 0f,
        var sx: Float = 1f,
        var sy: Float = 1f,
        var fillStyle: Long = 0xFF38BDF8L,
        var strokeStyle: Long = 0xFF0F172AL,
        var lineWidth: Float = 2.8f
    ) {
        fun transformX(x: Float, y: Float): Float {
            val scaledX = x * sx
            val scaledY = y * sy
            val c = cos(rotRad.toDouble()).toFloat()
            val s = sin(rotRad.toDouble()).toFloat()
            return tx + (scaledX * c - scaledY * s)
        }

        fun transformY(x: Float, y: Float): Float {
            val scaledX = x * sx
            val scaledY = y * sy
            val c = cos(rotRad.toDouble()).toFloat()
            val s = sin(rotRad.toDouble()).toFloat()
            return ty + (scaledX * s + scaledY * c)
        }
    }

    /**
     * Parses normal procedural HTML5 Canvas 2D JavaScript drawing code into native
     * [CodedVectorPath] vector paths + [CharacterSpec] + [SkeletalRig].
     */
    fun parseJsCanvasScript(script: String): CharacterCodeParseResult {
        return try {
            var modelName = "JS Canvas Model"
            var modelType = "OBJECT"
            var hasFace = false
            var ExplicitHasFace = false

            // Extract optional metadata comments or function name
            for (line in script.lines()) {
                val t = line.trim()
                val nameMatch = Regex("//\\s*@?name\\s*:\\s*(.+)", RegexOption.IGNORE_CASE).find(t)
                if (nameMatch != null) {
                    modelName = nameMatch.groupValues[1].trim()
                }
                val typeMatch = Regex("//\\s*@?(?:modelType|type|archetype)\\s*:\\s*([A-Za-z_]+)", RegexOption.IGNORE_CASE).find(t)
                if (typeMatch != null) {
                    modelType = normalizeArchetype(typeMatch.groupValues[1])
                }
                val faceMatch = Regex("//\\s*@?hasFace\\s*:\\s*(true|false)", RegexOption.IGNORE_CASE).find(t)
                if (faceMatch != null) {
                    hasFace = faceMatch.groupValues[1].equals("true", ignoreCase = true)
                    ExplicitHasFace = true
                }
            }
            if (modelName == "JS Canvas Model") {
                val fnMatch = Regex("function\\s+([A-Za-z0-9_]+)").find(script)
                if (fnMatch != null) {
                    val rawFn = fnMatch.groupValues[1].removePrefix("draw").ifBlank { "JS Object" }
                    modelName = rawFn.replaceFirstChar { it.uppercase() }
                }
            }
            if (!ExplicitHasFace) {
                hasFace = modelType != "OBJECT" && !script.contains("hasFace: false", ignoreCase = true)
            }

            // Strip JS comments before statement tokenization
            val noBlockComments = script.replace(Regex("/\\*[\\s\\S]*?\\*/"), "")
            val cleanLines = noBlockComments.lines().map { line ->
                val idx = line.indexOf("//")
                if (idx >= 0 && !line.substring(0, idx).contains("#")) line.substring(0, idx) else line
            }
            val body = cleanLines.joinToString("\n")

            val vars = mutableMapOf<String, Float>(
                "Math.PI" to PI.toFloat(),
                "PI" to PI.toFloat(),
                "width" to 200f,
                "height" to 200f,
                "cx" to 0f,
                "cy" to 0f,
                "x" to 0f,
                "y" to 0f
            )

            var state = JsTransformState()
            val stateStack = ArrayDeque<JsTransformState>()
            val currentSubPath = StringBuilder()
            val compiledPaths = mutableListOf<CodedVectorPath>()
            var PendingFill = false
            var PendingStroke = false

            fun fmt(v: Float): String = String.format(Locale.US, "%.2f", v)

            fun flushCurrentPath(doFill: Boolean, doStroke: Boolean) {
                val dStr = currentSubPath.toString().trim()
                if (dStr.isEmpty()) return
                compiledPaths += CodedVectorPath(
                    d = dStr,
                    fillColorArgb = if (doFill) state.fillStyle else 0x00000000L,
                    strokeColorArgb = if (doStroke) state.strokeStyle else 0x00000000L,
                    strokeWidth = if (doStroke) state.lineWidth else 0f,
                    attachTo = "ROOT",
                    zIndex = compiledPaths.size
                )
            }

            fun appendOvalPath(cx: Float, cy: Float, rx: Float, ry: Float) {
                val k = 0.5522848f
                val ox = rx * k
                val oy = ry * k
                val p0x = state.transformX(cx - rx, cy)
                val p0y = state.transformY(cx - rx, cy)
                val p1x = state.transformX(cx, cy - ry)
                val p1y = state.transformY(cx, cy - ry)
                val p2x = state.transformX(cx + rx, cy)
                val p2y = state.transformY(cx + rx, cy)
                val p3x = state.transformX(cx, cy + ry)
                val p3y = state.transformY(cx, cy + ry)

                val c1x = state.transformX(cx - rx, cy - oy)
                val c1y = state.transformY(cx - rx, cy - oy)
                val c2x = state.transformX(cx - ox, cy - ry)
                val c2y = state.transformY(cx - ox, cy - ry)

                val c3x = state.transformX(cx + ox, cy - ry)
                val c3y = state.transformY(cx + ox, cy - ry)
                val c4x = state.transformX(cx + rx, cy - oy)
                val c4y = state.transformY(cx + rx, cy - oy)

                val c5x = state.transformX(cx + rx, cy + oy)
                val c5y = state.transformY(cx + rx, cy + oy)
                val c6x = state.transformX(cx + ox, cy + ry)
                val c6y = state.transformY(cx + ox, cy + ry)

                val c7x = state.transformX(cx - ox, cy + ry)
                val c7y = state.transformY(cx - ox, cy + ry)
                val c8x = state.transformX(cx - rx, cy + oy)
                val c8y = state.transformY(cx - rx, cy + oy)

                currentSubPath.append("M ${fmt(p0x)} ${fmt(p0y)} ")
                currentSubPath.append("C ${fmt(c1x)} ${fmt(c1y)} ${fmt(c2x)} ${fmt(c2y)} ${fmt(p1x)} ${fmt(p1y)} ")
                currentSubPath.append("C ${fmt(c3x)} ${fmt(c3y)} ${fmt(c4x)} ${fmt(c4y)} ${fmt(p2x)} ${fmt(p2y)} ")
                currentSubPath.append("C ${fmt(c5x)} ${fmt(c5y)} ${fmt(c6x)} ${fmt(c6y)} ${fmt(p3x)} ${fmt(p3y)} ")
                currentSubPath.append("C ${fmt(c7x)} ${fmt(c7y)} ${fmt(c8x)} ${fmt(c8y)} ${fmt(p0x)} ${fmt(p0y)} Z ")
            }

            fun appendRoundRectPath(x: Float, y: Float, w: Float, h: Float, rRaw: Float) {
                val r = rRaw.coerceIn(0f, minOf( kotlin.math.abs(w), kotlin.math.abs(h) ) * 0.5f)
                if (r <= 0.5f) {
                    val p0x = state.transformX(x, y)
                    val p0y = state.transformY(x, y)
                    val p1x = state.transformX(x + w, y)
                    val p1y = state.transformY(x + w, y)
                    val p2x = state.transformX(x + w, y + h)
                    val p2y = state.transformY(x + w, y + h)
                    val p3x = state.transformX(x, y + h)
                    val p3y = state.transformY(x, y + h)
                    currentSubPath.append("M ${fmt(p0x)} ${fmt(p0y)} L ${fmt(p1x)} ${fmt(p1y)} L ${fmt(p2x)} ${fmt(p2y)} L ${fmt(p3x)} ${fmt(p3y)} Z ")
                    return
                }
                val x0 = x
                val y0 = y
                val x1 = x + w
                val y1 = y + h
                currentSubPath.append("M ${fmt(state.transformX(x0 + r, y0))} ${fmt(state.transformY(x0 + r, y0))} ")
                currentSubPath.append("L ${fmt(state.transformX(x1 - r, y0))} ${fmt(state.transformY(x1 - r, y0))} ")
                currentSubPath.append("Q ${fmt(state.transformX(x1, y0))} ${fmt(state.transformY(x1, y0))} ${fmt(state.transformX(x1, y0 + r))} ${fmt(state.transformY(x1, y0 + r))} ")
                currentSubPath.append("L ${fmt(state.transformX(x1, y1 - r))} ${fmt(state.transformY(x1, y1 - r))} ")
                currentSubPath.append("Q ${fmt(state.transformX(x1, y1))} ${fmt(state.transformY(x1, y1))} ${fmt(state.transformX(x1 - r, y1))} ${fmt(state.transformY(x1 - r, y1))} ")
                currentSubPath.append("L ${fmt(state.transformX(x0 + r, y1))} ${fmt(state.transformY(x0 + r, y1))} ")
                currentSubPath.append("Q ${fmt(state.transformX(x0, y1))} ${fmt(state.transformY(x0, y1))} ${fmt(state.transformX(x0, y1 - r))} ${fmt(state.transformY(x0, y1 - r))} ")
                currentSubPath.append("L ${fmt(state.transformX(x0, y0 + r))} ${fmt(state.transformY(x0, y0 + r))} ")
                currentSubPath.append("Q ${fmt(state.transformX(x0, y0))} ${fmt(state.transformY(x0, y0))} ${fmt(state.transformX(x0 + r, y0))} ${fmt(state.transformY(x0 + r, y0))} Z ")
            }

            // Split statements by semicolon or newline
            val statements = body.split(Regex("[;\n]")).map { it.trim() }.filter { it.isNotEmpty() }

            for (stmt in statements) {
                // Variable declarations: const/let/var name = expr
                val varMatch = Regex("^(?:const|let|var)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.+)$").find(stmt)
                if (varMatch != null) {
                    val vName = varMatch.groupValues[1]
                    val vExpr = varMatch.groupValues[2].trim()
                    val evaluated = evalJsNumericExpr(vExpr, vars)
                    if (evaluated != null) {
                        vars[vName] = evaluated
                    }
                    continue
                }

                // Style assignments: ctx.fillStyle = ..., ctx.strokeStyle = ..., ctx.lineWidth = ...
                val fillStyleMatch = Regex("(?:ctx|context|g)\\.fillStyle\\s*=\\s*(.+)$").find(stmt)
                if (fillStyleMatch != null) {
                    state.fillStyle = parseColorHex(fillStyleMatch.groupValues[1], state.fillStyle)
                    continue
                }
                val strokeStyleMatch = Regex("(?:ctx|context|g)\\.strokeStyle\\s*=\\s*(.+)$").find(stmt)
                if (strokeStyleMatch != null) {
                    state.strokeStyle = parseColorHex(strokeStyleMatch.groupValues[1], state.strokeStyle)
                    continue
                }
                val lineWidthMatch = Regex("(?:ctx|context|g)\\.lineWidth\\s*=\\s*(.+)$").find(stmt)
                if (lineWidthMatch != null) {
                    val lw = evalJsNumericExpr(lineWidthMatch.groupValues[1], vars)
                    if (lw != null) state.lineWidth = lw.coerceIn(0f, 30f)
                    continue
                }

                // Method calls: ctx.methodName(args)
                val callMatch = Regex("(?:ctx|context|g)\\.([A-Za-z0-9_]+)\\s*\\((.*)\\)").find(stmt) ?: continue
                val method = callMatch.groupValues[1]
                val argsRaw = splitJsArgs(callMatch.groupValues[2])
                val numArgs = argsRaw.map { evalJsNumericExpr(it, vars) ?: 0f }

                when (method) {
                    "save" -> stateStack.addLast(state.copy())
                    "restore" -> if (stateStack.isNotEmpty()) state = stateStack.removeLast()
                    "translate" -> if (numArgs.size >= 2) {
                        val dx = numArgs[0]
                        val dy = numArgs[1]
                        val nx = state.transformX(dx, dy)
                        val ny = state.transformY(dx, dy)
                        state.tx = nx
                        state.ty = ny
                    }
                    "rotate" -> if (numArgs.isNotEmpty()) {
                        state.rotRad += numArgs[0]
                    }
                    "scale" -> if (numArgs.size >= 2) {
                        state.sx *= numArgs[0]
                        state.sy *= numArgs[1]
                    }
                    "beginPath" -> {
                        if (PendingFill || PendingStroke) {
                            flushCurrentPath(PendingFill, PendingStroke)
                        }
                        currentSubPath.clear()
                        PendingFill = false
                        PendingStroke = false
                    }
                    "closePath" -> {
                        currentSubPath.append("Z ")
                    }
                    "moveTo" -> if (numArgs.size >= 2) {
                        val px = state.transformX(numArgs[0], numArgs[1])
                        val py = state.transformY(numArgs[0], numArgs[1])
                        currentSubPath.append("M ${fmt(px)} ${fmt(py)} ")
                    }
                    "lineTo" -> if (numArgs.size >= 2) {
                        val px = state.transformX(numArgs[0], numArgs[1])
                        val py = state.transformY(numArgs[0], numArgs[1])
                        currentSubPath.append("L ${fmt(px)} ${fmt(py)} ")
                    }
                    "quadraticCurveTo" -> if (numArgs.size >= 4) {
                        val cx = state.transformX(numArgs[0], numArgs[1])
                        val cy = state.transformY(numArgs[0], numArgs[1])
                        val px = state.transformX(numArgs[2], numArgs[3])
                        val py = state.transformY(numArgs[2], numArgs[3])
                        currentSubPath.append("Q ${fmt(cx)} ${fmt(cy)} ${fmt(px)} ${fmt(py)} ")
                    }
                    "bezierCurveTo" -> if (numArgs.size >= 6) {
                        val c1x = state.transformX(numArgs[0], numArgs[1])
                        val c1y = state.transformY(numArgs[0], numArgs[1])
                        val c2x = state.transformX(numArgs[2], numArgs[3])
                        val c2y = state.transformY(numArgs[2], numArgs[3])
                        val px = state.transformX(numArgs[4], numArgs[5])
                        val py = state.transformY(numArgs[4], numArgs[5])
                        currentSubPath.append("C ${fmt(c1x)} ${fmt(c1y)} ${fmt(c2x)} ${fmt(c2y)} ${fmt(px)} ${fmt(py)} ")
                    }
                    "arc" -> if (numArgs.size >= 3) {
                        val cx = numArgs[0]
                        val cy = numArgs[1]
                        val r = kotlin.math.abs(numArgs[2])
                        val startA = numArgs.getOrElse(3) { 0f }
                        val endA = numArgs.getOrElse(4) { (2.0 * PI).toFloat() }
                        val span = kotlin.math.abs(endA - startA)
                        if (span >= 5.8f) {
                            appendOvalPath(cx, cy, r, r)
                        } else {
                            val steps = 16
                            for (s in 0..steps) {
                                val a = startA + (endA - startA) * (s.toFloat() / steps)
                                val ax = state.transformX(cx + r * cos(a.toDouble()).toFloat(), cy + r * sin(a.toDouble()).toFloat())
                                val ay = state.transformY(cx + r * cos(a.toDouble()).toFloat(), cy + r * sin(a.toDouble()).toFloat())
                                currentSubPath.append(if (s == 0) "M ${fmt(ax)} ${fmt(ay)} " else "L ${fmt(ax)} ${fmt(ay)} ")
                            }
                        }
                    }
                    "ellipse" -> if (numArgs.size >= 4) {
                        val cx = numArgs[0]
                        val cy = numArgs[1]
                        val rx = kotlin.math.abs(numArgs[2])
                        val ry = kotlin.math.abs(numArgs[3])
                        appendOvalPath(cx, cy, rx, ry)
                    }
                    "rect" -> if (numArgs.size >= 4) {
                        appendRoundRectPath(numArgs[0], numArgs[1], numArgs[2], numArgs[3], 0f)
                    }
                    "roundRect" -> if (numArgs.size >= 4) {
                        val r = numArgs.getOrElse(4) { 12f }
                        appendRoundRectPath(numArgs[0], numArgs[1], numArgs[2], numArgs[3], r)
                    }
                    "fillRect" -> if (numArgs.size >= 4) {
                        if (PendingFill || PendingStroke) {
                            flushCurrentPath(PendingFill, PendingStroke)
                            PendingFill = false; PendingStroke = false
                        }
                        currentSubPath.clear()
                        appendRoundRectPath(numArgs[0], numArgs[1], numArgs[2], numArgs[3], 0f)
                        flushCurrentPath(doFill = true, doStroke = false)
                        currentSubPath.clear()
                    }
                    "strokeRect" -> if (numArgs.size >= 4) {
                        if (PendingFill || PendingStroke) {
                            flushCurrentPath(PendingFill, PendingStroke)
                            PendingFill = false; PendingStroke = false
                        }
                        currentSubPath.clear()
                        appendRoundRectPath(numArgs[0], numArgs[1], numArgs[2], numArgs[3], 0f)
                        flushCurrentPath(doFill = false, doStroke = true)
                        currentSubPath.clear()
                    }
                    "fill" -> {
                        PendingFill = true
                    }
                    "stroke" -> {
                        PendingStroke = true
                    }
                }
            }

            if (PendingFill || PendingStroke) {
                flushCurrentPath(PendingFill, PendingStroke)
            }

            if (compiledPaths.isEmpty()) {
                return CharacterCodeParseResult(
                    error = "No JS Canvas draw calls found. Use ctx.beginPath(), ctx.arc(), ctx.roundRect(), ctx.fill(), etc.",
                    detectedFormat = "JS"
                )
            }

            val spec = CharacterSpec(
                name = modelName,
                modelType = modelType,
                hasFace = hasFace,
                hairStyle = "NONE",
                customCodePaths = compiledPaths,
                rawCode = script
            )
            val rig = RigSolver.createRiggedCharacterFromSpec(
                spec = spec,
                rootX = 640f,
                rootY = 420f
            )
            CharacterCodeParseResult(
                spec = spec,
                rig = rig,
                error = null,
                detectedFormat = "JS"
            )
        } catch (e: Exception) {
            CharacterCodeParseResult(
                error = "JS Parse Error: ${e.message?.take(100) ?: "Invalid script"}",
                detectedFormat = "JS"
            )
        }
    }

    private fun splitJsArgs(argsStr: String): List<String> {
        if (argsStr.isBlank()) return emptyList()
        val result = mutableListOf<String>()
        var depth = 0
        val current = StringBuilder()
        for (ch in argsStr) {
            when (ch) {
                '(', '[' -> {
                    depth++
                    current.append(ch)
                }
                ')', ']' -> {
                    depth = (depth - 1).coerceAtLeast(0)
                    current.append(ch)
                }
                ',' -> {
                    if (depth == 0) {
                        result += current.toString().trim()
                        current.clear()
                    } else {
                        current.append(ch)
                    }
                }
                else -> current.append(ch)
            }
        }
        if (current.isNotBlank()) {
            result += current.toString().trim()
        }
        return result
    }

    private fun evalJsNumericExpr(rawExpr: String, vars: Map<String, Float>): Float? {
        var expr = rawExpr.trim()
            .removePrefix("[")
            .removeSuffix("]")
            .trim()
        if (expr.isEmpty()) return null
        expr.toFloatOrNull()?.let { return it }

        // Replace Math.PI and known variables
        expr = expr.replace("Math.PI", PI.toString())
        for ((k, v) in vars) {
            if (expr.contains(k)) {
                expr = expr.replace(Regex("\\b${Regex.escape(k)}\\b"), v.toString())
            }
        }
        expr.toFloatOrNull()?.let { return it }

        // Simple arithmetic parser (+, -, *, /)
        return try {
            evalSimpleArithmetic(expr)
        } catch (_: Exception) {
            null
        }
    }

    private fun evalSimpleArithmetic(s: String): Float? {
        val tokens = Regex("[-+*/()]|\\d+\\.\\d*|\\.\\d+|\\d+").findAll(s).map { it.value }.toList()
        if (tokens.isEmpty()) return null
        return ArithmeticEval(tokens).parseExpr()
    }

    private class ArithmeticEval(private val tokens: List<String>) {
        private var pos = 0

        fun parseExpr(): Float {
            var v = parseTerm()
            while (pos < tokens.size && (tokens[pos] == "+" || tokens[pos] == "-")) {
                val op = tokens[pos++]
                val rhs = parseTerm()
                v = if (op == "+") v + rhs else v - rhs
            }
            return v
        }

        private fun parseTerm(): Float {
            var v = parseFactor()
            while (pos < tokens.size && (tokens[pos] == "*" || tokens[pos] == "/")) {
                val op = tokens[pos++]
                val rhs = parseFactor()
                v = if (op == "*") v * rhs else if (rhs != 0f) v / rhs else 0f
            }
            return v
        }

        private fun parseFactor(): Float {
            if (pos >= tokens.size) return 0f
            val t = tokens[pos]
            if (t == "+") {
                pos++
                return parseFactor()
            }
            if (t == "-") {
                pos++
                return -parseFactor()
            }
            if (t == "(") {
                pos++
                val v = parseExpr()
                if (pos < tokens.size && tokens[pos] == ")") pos++
                return v
            }
            pos++
            return t.toFloatOrNull() ?: 0f
        }
    }

    sealed class SvgPathOp {
        data class MoveTo(val x: Float, val y: Float) : SvgPathOp()
        data class LineTo(val x: Float, val y: Float) : SvgPathOp()
        data class QuadTo(val cx: Float, val cy: Float, val x: Float, val y: Float) : SvgPathOp()
        data class CubicTo(val c1x: Float, val c1y: Float, val c2x: Float, val c2y: Float, val x: Float, val y: Float) : SvgPathOp()
        data object Close : SvgPathOp()
    }

    /**
     * Pure-Kotlin SVG path command parser (`M/m`, `L/l`, `H/h`, `V/v`, `Q/q`, `C/c`, `Z/z`).
     */
    fun parseSvgPathOps(d: String): List<SvgPathOp> {
        if (d.isBlank()) return emptyList()
        val tokenRegex = Regex("[MmLlHhVvQqCcZz]|[-+]?(?:\\d+\\.\\d*|\\.\\d+|\\d+)(?:[eE][-+]?\\d+)?")
        val tokens = tokenRegex.findAll(d).map { it.value }.toList()
        if (tokens.isEmpty()) return emptyList()

        val ops = mutableListOf<SvgPathOp>()
        var i = 0
        var cmd = ' '
        var curX = 0f
        var curY = 0f
        var startX = 0f
        var startY = 0f
        var hasMove = false

        fun nextFloat(): Float? {
            if (i >= tokens.size) return null
            val v = tokens[i].toFloatOrNull() ?: return null
            i++
            return v
        }

        while (i < tokens.size) {
            val t = tokens[i]
            if (t.length == 1 && t[0].isLetter()) {
                cmd = t[0]
                i++
                if (cmd == 'Z' || cmd == 'z') {
                    if (hasMove) {
                        ops += SvgPathOp.Close
                        curX = startX
                        curY = startY
                    }
                    continue
                }
            } else if (cmd == ' ') {
                break
            }

            when (cmd) {
                'M', 'm' -> {
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    curX = if (cmd == 'm') curX + x else x
                    curY = if (cmd == 'm') curY + y else y
                    startX = curX
                    startY = curY
                    ops += SvgPathOp.MoveTo(curX, curY)
                    hasMove = true
                    cmd = if (cmd == 'm') 'l' else 'L'
                }
                'L', 'l' -> {
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    curX = if (cmd == 'l') curX + x else x
                    curY = if (cmd == 'l') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(curX, curY)
                        startX = curX; startY = curY; hasMove = true
                    } else {
                        ops += SvgPathOp.LineTo(curX, curY)
                    }
                }
                'H', 'h' -> {
                    val x = nextFloat() ?: break
                    curX = if (cmd == 'h') curX + x else x
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(curX, curY)
                        startX = curX; startY = curY; hasMove = true
                    } else {
                        ops += SvgPathOp.LineTo(curX, curY)
                    }
                }
                'V', 'v' -> {
                    val y = nextFloat() ?: break
                    curY = if (cmd == 'v') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(curX, curY)
                        startX = curX; startY = curY; hasMove = true
                    } else {
                        ops += SvgPathOp.LineTo(curX, curY)
                    }
                }
                'Q', 'q' -> {
                    val cx = nextFloat() ?: break
                    val cy = nextFloat() ?: break
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    val qcx = if (cmd == 'q') curX + cx else cx
                    val qcy = if (cmd == 'q') curY + cy else cy
                    val qx = if (cmd == 'q') curX + x else x
                    val qy = if (cmd == 'q') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(qcx, qcy); startX = qcx; startY = qcy; hasMove = true
                    }
                    ops += SvgPathOp.QuadTo(qcx, qcy, qx, qy)
                    curX = qx; curY = qy
                }
                'C', 'c' -> {
                    val c1x = nextFloat() ?: break
                    val c1y = nextFloat() ?: break
                    val c2x = nextFloat() ?: break
                    val c2y = nextFloat() ?: break
                    val x = nextFloat() ?: break
                    val y = nextFloat() ?: break
                    val ac1x = if (cmd == 'c') curX + c1x else c1x
                    val ac1y = if (cmd == 'c') curY + c1y else c1y
                    val ac2x = if (cmd == 'c') curX + c2x else c2x
                    val ac2y = if (cmd == 'c') curY + c2y else c2y
                    val ax = if (cmd == 'c') curX + x else x
                    val ay = if (cmd == 'c') curY + y else y
                    if (!hasMove) {
                        ops += SvgPathOp.MoveTo(ac1x, ac1y); startX = ac1x; startY = ac1y; hasMove = true
                    }
                    ops += SvgPathOp.CubicTo(ac1x, ac1y, ac2x, ac2y, ax, ay)
                    curX = ax; curY = ay
                }
                else -> i++
            }
        }
        return if (hasMove) ops else emptyList()
    }

    /**
     * Parses SVG-style path commands (`M/m`, `L/l`, `H/h`, `V/v`, `Q/q`, `C/c`, `Z/z`)
     * into an [android.graphics.Path]. Returns null if the string has no valid commands.
     */
    fun parseSvgPathData(d: String): Path? {
        val ops = parseSvgPathOps(d)
        if (ops.isEmpty()) return null
        val path = Path()
        for (op in ops) {
            when (op) {
                is SvgPathOp.MoveTo -> path.moveTo(op.x, op.y)
                is SvgPathOp.LineTo -> path.lineTo(op.x, op.y)
                is SvgPathOp.QuadTo -> path.quadTo(op.cx, op.cy, op.x, op.y)
                is SvgPathOp.CubicTo -> path.cubicTo(op.c1x, op.c1y, op.c2x, op.c2y, op.x, op.y)
                is SvgPathOp.Close -> path.close()
            }
        }
        return path
    }
}
