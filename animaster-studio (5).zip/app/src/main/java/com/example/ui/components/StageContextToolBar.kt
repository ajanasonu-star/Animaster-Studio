package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Mood
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CharacterViewAngle
import com.example.data.model.CustomActionClip
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FaceMoodCategory
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.StageMoodPreset
import com.example.engine.InterpolationEngine
import com.example.engine.RigSolver
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StageContextToolTab
import com.example.ui.viewmodel.StudioUiState
import java.util.Locale
import kotlin.math.roundToInt

private val STAGE_VIEW_ANGLES = listOf(
    CharacterViewAngle.FRONT to "Front",
    CharacterViewAngle.FRONT_LEFT_34 to "Front-L 3/4",
    CharacterViewAngle.FRONT_RIGHT_34 to "Front-R 3/4",
    CharacterViewAngle.SIDE_LEFT to "Left Side",
    CharacterViewAngle.SIDE_RIGHT to "Right Side",
    CharacterViewAngle.BACK to "Back"
)

/**
 * Unified, collapsible Context Tool Selector Bar below the stage canvas.
 * Replaces cluttered stacked bars with 5 clean context tabs:
 * [Rigging], [Move], [Face], [Props], [Range] + a right-aligned [Hide Tools ▲/▼] toggle.
 */
@Composable
fun StageContextToolBar(
    uiState: StudioUiState,
    customActions: List<CustomActionClip>,
    onSelectTab: (StageContextToolTab) -> Unit,
    onToggleHideTools: () -> Unit,
    // Rigging tab callbacks
    onSelectViewAngle: (CharacterViewAngle) -> Unit,
    onToggleLockBone: () -> Unit,
    onToggleStretchRig: () -> Unit,
    onSetBoneLengthMultiplier: (Float) -> Unit,
    onResetBoneLength: () -> Unit,
    onResetBone: () -> Unit,
    onStepBoneZOrder: (moveUp: Boolean) -> Unit = {},
    // Move tab callbacks
    onToggleMoveChar: () -> Unit,
    onToggleMicroNudgeStep: () -> Unit,
    onMicroNudge: (dx: Float, dy: Float) -> Unit,
    onUpdateViewport: (zoom: Float, panX: Float, panY: Float) -> Unit,
    onResetViewport: () -> Unit,
    // Face tab callbacks
    onApplyMoodPreset: (StageMoodPreset) -> Unit,
    onSelectEyePack: (EyePackStyle) -> Unit,
    onSelectMouthPhoneme: (MouthPhoneme) -> Unit,
    onSelectEyeMood: (FaceMoodCategory) -> Unit,
    onSelectMouthMood: (FaceMoodCategory) -> Unit,
    onSelectEyebrow: (EyebrowStyle) -> Unit,
    onApplyQuickBrowExpression: (String) -> Unit = {},
    onSetEyeSpacing: (Float) -> Unit = {},
    onSetEyeScale: (Float) -> Unit = {},
    onSetBrowHeight: (leftY: Float?, rightY: Float?) -> Unit = { _, _ -> },
    onSetBrowTilt: (leftTilt: Float?, rightTilt: Float?) -> Unit = { _, _ -> },
    onSetBrowArch: (Float) -> Unit = {},
    onSetBrowSpacing: (Float) -> Unit = {},
    onToggleHeadBobEnabled: () -> Unit = {},
    onSetHeadBobMode: (String) -> Unit = {},
    onSetHeadBobIntensity: (Float) -> Unit = {},
    onSetLipSyncSensitivity: (Float) -> Unit = {},
    onSetLipSyncFrequencyRange: (minHz: Int, maxHz: Int) -> Unit = { _, _ -> },
    onApplyLipSyncFrequencyPreset: (String) -> Unit = {},
    onOpenSwapChar: () -> Unit,
    onResetPose: () -> Unit,
    // Props tab callbacks
    onSelectLayer: (String) -> Unit = {},
    onStartAttachBonePick: (propLayerId: String?) -> Unit = {},
    onAttachPropToBone: (propLayerId: String, hostLayerId: String, boneId: String) -> Unit,
    onDetachProp: (propLayerId: String) -> Unit,
    onCenterPropInPalm: (propLayerId: String) -> Unit,
    onToggleRotateProp: () -> Unit,
    onImportImage: () -> Unit = {},
    // Range tab callbacks
    onSetTimelineRange: (start: Int, end: Int) -> Unit,
    onTogglePlayRange: () -> Unit,
    onSaveCustomAction: (name: String, includeRoot: Boolean) -> Unit,
    onApplyCustomAction: (CustomActionClip) -> Unit
) {
    var showRangeNumbersDialog by remember { mutableStateOf(false) }
    var rangeStartInput by remember { mutableStateOf("1") }
    var rangeEndInput by remember { mutableStateOf("25") }
    var showSaveActionDialog by remember { mutableStateOf(false) }
    var customActionName by remember { mutableStateOf("") }
    var includeRootInAction by remember { mutableStateOf(true) }
    var showApplyActionDialog by remember { mutableStateOf(false) }

    val totalFrames = (uiState.activeScene?.durationFrames ?: 24).coerceAtLeast(1)

    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stage_context_tool_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Row 1: Category Selector Pills + Hide Tools (▲/▼) Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StageContextToolTab.entries.forEach { tab ->
                        val selected = uiState.activeContextToolTab == tab && !uiState.toolsDrawerHidden
                        val tabIcon = when (tab) {
                            StageContextToolTab.RIGGING -> Icons.Rounded.AccessibilityNew
                            StageContextToolTab.MOVE -> Icons.Rounded.OpenWith
                            StageContextToolTab.FACE -> Icons.Rounded.Mood
                            StageContextToolTab.PROPS -> Icons.Rounded.Category
                            StageContextToolTab.RANGE -> Icons.Rounded.Timeline
                        }
                        val tabAccent = when (tab) {
                            StageContextToolTab.RIGGING -> StudioCoral
                            StageContextToolTab.MOVE -> StudioCyan
                            StageContextToolTab.FACE -> StudioAmber
                            StageContextToolTab.PROPS -> StudioEmerald
                            StageContextToolTab.RANGE -> StudioViolet
                        }
                        val badgeActive = (tab == StageContextToolTab.MOVE && uiState.moveCharMode) ||
                            (tab == StageContextToolTab.RIGGING && uiState.stretchRigMode) ||
                            (tab == StageContextToolTab.PROPS && uiState.propRotateMode) ||
                            (tab == StageContextToolTab.RANGE && uiState.playRangeOnly)

                        Surface(
                            color = when {
                                selected -> tabAccent.copy(alpha = 0.22f)
                                badgeActive -> tabAccent.copy(alpha = 0.12f)
                                else -> StudioSurfaceVariant
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(
                                1.dp,
                                when {
                                    selected -> tabAccent
                                    badgeActive -> tabAccent.copy(alpha = 0.65f)
                                    else -> StudioBorder
                                }
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectTab(tab) }
                                .testTag("context_tab_${tab.name.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = tabIcon,
                                    contentDescription = tab.label,
                                    tint = if (selected || badgeActive) tabAccent else StudioTextSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = tab.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (selected || badgeActive) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected || badgeActive) tabAccent else StudioTextPrimary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // Prominent Hide Tools (▲/▼) Toggle on the right
                Surface(
                    color = if (uiState.toolsDrawerHidden) StudioCyan.copy(alpha = 0.2f) else StudioSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (uiState.toolsDrawerHidden) StudioCyan else StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onToggleHideTools)
                        .testTag("toggle_hide_tools_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = if (uiState.toolsDrawerHidden) "Tools" else "Hide",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.toolsDrawerHidden) StudioCyan else StudioTextSecondary,
                            maxLines = 1
                        )
                        Icon(
                            imageVector = if (uiState.toolsDrawerHidden) Icons.Rounded.ExpandMore else Icons.Rounded.ExpandLess,
                            contentDescription = if (uiState.toolsDrawerHidden) "Show Tools" else "Hide Tools",
                            tint = if (uiState.toolsDrawerHidden) StudioCyan else StudioTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Row 2: Collapsible Context Tool Strip
            AnimatedVisibility(
                visible = !uiState.toolsDrawerHidden,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    HorizontalDivider(color = StudioBorder.copy(alpha = 0.65f))
                    when (uiState.activeContextToolTab) {
                        StageContextToolTab.RIGGING -> RiggingContextStrip(
                            uiState = uiState,
                            onSelectViewAngle = onSelectViewAngle,
                            onToggleLockBone = onToggleLockBone,
                            onToggleStretchRig = onToggleStretchRig,
                            onSetBoneLengthMultiplier = onSetBoneLengthMultiplier,
                            onResetBoneLength = onResetBoneLength,
                            onResetBone = onResetBone,
                            onStepBoneZOrder = onStepBoneZOrder
                        )
                        StageContextToolTab.MOVE -> MoveContextStrip(
                            uiState = uiState,
                            onToggleMoveChar = onToggleMoveChar,
                            onToggleMicroNudgeStep = onToggleMicroNudgeStep,
                            onMicroNudge = onMicroNudge,
                            onUpdateViewport = onUpdateViewport,
                            onResetViewport = onResetViewport
                        )
                        StageContextToolTab.FACE -> FaceContextStrip(
                            uiState = uiState,
                            onApplyMoodPreset = onApplyMoodPreset,
                            onSelectEyePack = onSelectEyePack,
                            onSelectMouthPhoneme = onSelectMouthPhoneme,
                            onSelectEyeMood = onSelectEyeMood,
                            onSelectMouthMood = onSelectMouthMood,
                            onSelectEyebrow = onSelectEyebrow,
                            onApplyQuickBrowExpression = onApplyQuickBrowExpression,
                            onSetEyeSpacing = onSetEyeSpacing,
                            onSetEyeScale = onSetEyeScale,
                            onSetBrowHeight = onSetBrowHeight,
                            onSetBrowTilt = onSetBrowTilt,
                            onSetBrowArch = onSetBrowArch,
                            onSetBrowSpacing = onSetBrowSpacing,
                            onToggleHeadBobEnabled = onToggleHeadBobEnabled,
                            onSetHeadBobMode = onSetHeadBobMode,
                            onSetHeadBobIntensity = onSetHeadBobIntensity,
                            onSetLipSyncSensitivity = onSetLipSyncSensitivity,
                            onSetLipSyncFrequencyRange = onSetLipSyncFrequencyRange,
                            onApplyLipSyncFrequencyPreset = onApplyLipSyncFrequencyPreset,
                            onOpenSwapChar = onOpenSwapChar,
                            onResetPose = onResetPose
                        )
                        StageContextToolTab.PROPS -> PropsContextStrip(
                            uiState = uiState,
                            onSelectLayer = onSelectLayer,
                            onStartAttachBonePick = onStartAttachBonePick,
                            onAttachPropToBone = onAttachPropToBone,
                            onDetachProp = onDetachProp,
                            onCenterPropInPalm = onCenterPropInPalm,
                            onToggleRotateProp = onToggleRotateProp,
                            onImportImage = onImportImage
                        )
                        StageContextToolTab.RANGE -> RangeContextStrip(
                            uiState = uiState,
                            customActionsCount = customActions.size,
                            onSetStart = {
                                onSetTimelineRange(uiState.currentFrame, maxOf(uiState.currentFrame, uiState.rangeEndFrame))
                            },
                            onOpenNumbers = {
                                rangeStartInput = (uiState.rangeStartFrame + 1).toString()
                                rangeEndInput = (uiState.rangeEndFrame + 1).toString()
                                showRangeNumbersDialog = true
                            },
                            onSetEnd = {
                                onSetTimelineRange(minOf(uiState.rangeStartFrame, uiState.currentFrame), uiState.currentFrame)
                            },
                            onTogglePlayRange = onTogglePlayRange,
                            onOpenSaveAction = {
                                customActionName = "Action F${uiState.rangeStartFrame + 1}-${uiState.rangeEndFrame + 1}"
                                includeRootInAction = true
                                showSaveActionDialog = true
                            },
                            onOpenApplyAction = { showApplyActionDialog = true }
                        )
                    }
                }
            }
        }
    }

    // Exact Start / End Frame Number Dialog
    if (showRangeNumbersDialog) {
        AlertDialog(
            onDismissRequest = { showRangeNumbersDialog = false },
            containerColor = StudioSurfaceElevated,
            title = { Text("Set Exact Frame Range", color = StudioTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Frames 1 to $totalFrames. Play Range loops the full scene inside this interval.",
                        color = StudioTextSecondary,
                        fontSize = 12.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = rangeStartInput,
                            onValueChange = { rangeStartInput = it.filter(Char::isDigit) },
                            label = { Text("Start Frame") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = rangeEndInput,
                            onValueChange = { rangeEndInput = it.filter(Char::isDigit) },
                            label = { Text("End Frame") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val s = ((rangeStartInput.toIntOrNull() ?: 1) - 1).coerceIn(0, totalFrames - 1)
                        val e = ((rangeEndInput.toIntOrNull() ?: totalFrames) - 1).coerceIn(s, totalFrames - 1)
                        onSetTimelineRange(s, e)
                        showRangeNumbersDialog = false
                    }
                ) { Text("Apply Range", color = StudioAmber, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showRangeNumbersDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Extract / Save Action Dialog
    if (showSaveActionDialog) {
        AlertDialog(
            onDismissRequest = { showSaveActionDialog = false },
            containerColor = StudioSurfaceElevated,
            title = { Text("Extract / Save Action", color = StudioTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Extracts bone animation from F${uiState.rangeStartFrame + 1}–F${uiState.rangeEndFrame + 1} into your reusable Actions Library.",
                        color = StudioTextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = customActionName,
                        onValueChange = { customActionName = it },
                        label = { Text("Action Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Include Root Position & Mood", color = StudioTextPrimary, fontSize = 12.sp)
                        Switch(checked = includeRootInAction, onCheckedChange = { includeRootInAction = it })
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onSaveCustomAction(customActionName.ifBlank { "Custom Action" }, includeRootInAction)
                        showSaveActionDialog = false
                    }
                ) { Text("Save Action", color = StudioEmerald, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveActionDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Apply Saved Action Dialog
    if (showApplyActionDialog) {
        AlertDialog(
            onDismissRequest = { showApplyActionDialog = false },
            containerColor = StudioSurfaceElevated,
            title = { Text("Apply Saved Action at F${uiState.currentFrame + 1}", color = StudioTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                if (customActions.isEmpty()) {
                    Text(
                        "No saved actions yet. Select a frame range and tap Extract / Save Action first!",
                        color = StudioTextSecondary,
                        fontSize = 12.sp
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        customActions.forEach { clip ->
                            Surface(
                                color = StudioSurface,
                                shape = RoundedCornerShape(9.dp),
                                border = BorderStroke(1.dp, StudioBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(9.dp))
                                    .clickable {
                                        onApplyCustomAction(clip)
                                        showApplyActionDialog = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(clip.name, color = StudioTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("${clip.durationFrames} frames", color = StudioTextSecondary, fontSize = 10.sp)
                                    }
                                    Text("Apply", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showApplyActionDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun RiggingContextStrip(
    uiState: StudioUiState,
    onSelectViewAngle: (CharacterViewAngle) -> Unit,
    onToggleLockBone: () -> Unit,
    onToggleStretchRig: () -> Unit,
    onSetBoneLengthMultiplier: (Float) -> Unit,
    onResetBoneLength: () -> Unit,
    onResetBone: () -> Unit,
    onStepBoneZOrder: (moveUp: Boolean) -> Unit
) {
    val rig = uiState.selectedLayer?.rig
    if (rig == null) {
        Text(
            text = "Select a rigged character layer to access View, Per-Frame Body-Part Z-Order, Lock Bone, Stretch & Length controls.",
            fontSize = 10.sp,
            color = StudioTextMuted,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
        )
        return
    }
    val evalRoot = remember(rig, uiState.currentFrame) {
        InterpolationEngine.evaluatePuppetRoot(rig, uiState.currentFrame)
    }
    val curView = runCatching { CharacterViewAngle.valueOf(evalRoot.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
    val selectedBone = rig.bones.firstOrNull { it.id == uiState.selectedBoneId }
        ?: rig.bones.firstOrNull { it.id == "arm_r_low" }
        ?: rig.bones.firstOrNull()
    val isBoneLocked = selectedBone != null && RigSolver.isBoneLocked(rig, selectedBone)
    val evalLengths = remember(rig, uiState.currentFrame) {
        InterpolationEngine.evaluateBoneLengths(rig, uiState.currentFrame)
    }
    val zOrdersAtFrame = remember(rig, uiState.currentFrame) {
        InterpolationEngine.evaluateBoneZOrders(rig, uiState.currentFrame)
    }
    val curBoneZ = selectedBone?.let { zOrdersAtFrame[it.id] ?: it.zOrder } ?: 0
    val curMult = if (selectedBone != null && selectedBone.length > 0.5f) {
        val lenNow = evalLengths[selectedBone.id] ?: (selectedBone.length * selectedBone.limbLengthScale)
        (lenNow / selectedBone.length).coerceIn(0.2f, 2.5f)
    } else 1.0f

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurfaceVariant.copy(alpha = 0.55f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Sub-row 1: View Selector (Front, Front-L 3/4, Front-R 3/4, Left Side, Right Side, Back)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("View:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StudioTextSecondary)
            STAGE_VIEW_ANGLES.forEach { (angle, label) ->
                val active = curView == angle
                ContextPill(
                    label = label,
                    active = active,
                    accent = StudioCyan,
                    tag = "rig_view_${angle.name.lowercase()}",
                    onClick = { onSelectViewAngle(angle) }
                )
            }
        }

        // Sub-row 2: Per-Frame Body-Part Z-Order Badge (Z: #) + Layer Up (⬆) / Layer Down (⬇) + Lock Bone, Stretch, Length, Reset
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // Per-Frame Body-Part Z-Order Controls (Any Part Above/Below Any Part on Any Specific Frame)
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StudioViolet.copy(alpha = 0.75f)),
                modifier = Modifier.testTag("rig_bone_zorder_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Layers,
                        contentDescription = "Body Part Layer Rank",
                        tint = StudioViolet,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "${selectedBone?.name?.take(10) ?: "Part"} • Z: $curBoneZ",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioViolet
                    )
                }
            }
            ContextPill(
                label = "Layer Up ⬆",
                icon = Icons.Rounded.ArrowUpward,
                active = false,
                accent = StudioCyan,
                tag = "rig_layer_up_btn",
                onClick = { onStepBoneZOrder(true) }
            )
            ContextPill(
                label = "Layer Down ⬇",
                icon = Icons.Rounded.ArrowDownward,
                active = false,
                accent = StudioAmber,
                tag = "rig_layer_down_btn",
                onClick = { onStepBoneZOrder(false) }
            )

            ContextPill(
                label = if (isBoneLocked) "Locked" else "Lock Bone",
                icon = if (isBoneLocked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                active = isBoneLocked,
                accent = StudioCoral,
                tag = "rig_lock_bone_btn",
                onClick = onToggleLockBone
            )
            ContextPill(
                label = if (uiState.stretchRigMode) "Stretch: ON" else "Stretch",
                active = uiState.stretchRigMode,
                accent = StudioAmber,
                tag = "rig_stretch_toggle_btn",
                onClick = onToggleStretchRig
            )
            // Compact Bone Length Control (0.2x..2.5x)
            Surface(
                color = StudioSurface,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StudioBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "Len ${String.format(Locale.US, "%.1fx", curMult)}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioCyan
                    )
                    IconButton(
                        onClick = { onSetBoneLengthMultiplier((curMult - 0.1f).coerceAtLeast(0.2f)) },
                        modifier = Modifier.size(26.dp).testTag("rig_length_minus_btn")
                    ) {
                        Icon(Icons.Rounded.Remove, contentDescription = "Shrink bone length", tint = StudioTextPrimary, modifier = Modifier.size(14.dp))
                    }
                    Slider(
                        value = curMult,
                        onValueChange = { onSetBoneLengthMultiplier(it) },
                        valueRange = 0.2f..2.5f,
                        colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                        modifier = Modifier.width(88.dp).height(24.dp).testTag("rig_length_slider")
                    )
                    IconButton(
                        onClick = { onSetBoneLengthMultiplier((curMult + 0.1f).coerceAtMost(2.5f)) },
                        modifier = Modifier.size(26.dp).testTag("rig_length_plus_btn")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Extend bone length", tint = StudioTextPrimary, modifier = Modifier.size(14.dp))
                    }
                }
            }
            ContextPill(
                label = "Reset Size",
                active = false,
                accent = StudioEmerald,
                tag = "rig_reset_size_btn",
                onClick = onResetBoneLength
            )
            ContextPill(
                label = "Reset Bone",
                icon = Icons.Rounded.RestartAlt,
                active = false,
                accent = StudioAmber,
                tag = "stage_reset_bone_btn",
                onClick = onResetBone
            )
        }
    }
}

@Composable
private fun MoveContextStrip(
    uiState: StudioUiState,
    onToggleMoveChar: () -> Unit,
    onToggleMicroNudgeStep: () -> Unit,
    onMicroNudge: (dx: Float, dy: Float) -> Unit,
    onUpdateViewport: (zoom: Float, panX: Float, panY: Float) -> Unit,
    onResetViewport: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurfaceVariant.copy(alpha = 0.55f))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Dedicated "Move Char" Toggle Pill
        ContextPill(
            label = if (uiState.moveCharMode) "Move Char: ON" else "Move Char",
            icon = Icons.Rounded.OpenWith,
            active = uiState.moveCharMode,
            accent = StudioCyan,
            tag = "move_char_toggle_btn",
            onClick = onToggleMoveChar
        )

        // 1px / 5px Micro-Nudge D-Pad
        Surface(
            color = StudioSurface,
            shape = RoundedCornerShape(9.dp),
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.testTag("micro_nudge_dpad")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                Surface(
                    color = StudioCyan.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onToggleMicroNudgeStep)
                        .testTag("micro_nudge_step_btn")
                ) {
                    Text(
                        text = "${uiState.microNudgeStepPx.toInt()}px",
                        color = StudioCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
                IconButton(onClick = { onMicroNudge(-1f, 0f) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Rounded.KeyboardArrowLeft, contentDescription = "Nudge Left", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { onMicroNudge(0f, -1f) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Rounded.KeyboardArrowUp, contentDescription = "Nudge Up", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { onMicroNudge(0f, 1f) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Nudge Down", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { onMicroNudge(1f, 0f) }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Rounded.KeyboardArrowRight, contentDescription = "Nudge Right", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
            }
        }

        // Canvas Zoom - / % / + / Fit
        Surface(
            color = StudioSurface,
            shape = RoundedCornerShape(9.dp),
            border = BorderStroke(1.dp, StudioBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom - 0.25f).coerceAtLeast(0.4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Rounded.Remove, contentDescription = "Zoom out", tint = StudioTextPrimary, modifier = Modifier.size(16.dp))
                }
                Text(
                    text = "${(uiState.canvasZoom * 100).toInt()}%",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioCyan
                )
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom + 0.25f).coerceAtMost(4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Zoom in", tint = StudioTextPrimary, modifier = Modifier.size(16.dp))
                }
                IconButton(
                    onClick = onResetViewport,
                    modifier = Modifier.size(30.dp).testTag("canvas_fit_reset_btn")
                ) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Fit stage to screen", tint = StudioAmber, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun FaceContextStrip(
    uiState: StudioUiState,
    onApplyMoodPreset: (StageMoodPreset) -> Unit,
    onSelectEyePack: (EyePackStyle) -> Unit,
    onSelectMouthPhoneme: (MouthPhoneme) -> Unit,
    onSelectEyeMood: (FaceMoodCategory) -> Unit,
    onSelectMouthMood: (FaceMoodCategory) -> Unit,
    onSelectEyebrow: (EyebrowStyle) -> Unit,
    onApplyQuickBrowExpression: (String) -> Unit,
    onSetEyeSpacing: (Float) -> Unit,
    onSetEyeScale: (Float) -> Unit,
    onSetBrowHeight: (leftY: Float?, rightY: Float?) -> Unit,
    onSetBrowTilt: (leftTilt: Float?, rightTilt: Float?) -> Unit,
    onSetBrowArch: (Float) -> Unit,
    onSetBrowSpacing: (Float) -> Unit,
    onToggleHeadBobEnabled: () -> Unit,
    onSetHeadBobMode: (String) -> Unit,
    onSetHeadBobIntensity: (Float) -> Unit,
    onSetLipSyncSensitivity: (Float) -> Unit,
    onSetLipSyncFrequencyRange: (minHz: Int, maxHz: Int) -> Unit,
    onApplyLipSyncFrequencyPreset: (String) -> Unit,
    onOpenSwapChar: () -> Unit,
    onResetPose: () -> Unit
) {
    val selLayer = uiState.selectedLayer
    val rig = selLayer?.rig
    if (selLayer == null || (rig == null && selLayer.character == null)) {
        Text(
            text = "Select a character layer to switch facial expressions, Lip-Sync Frequency Filter, Decoupled Brows/Eyes, Head Bob & Swap Char.",
            fontSize = 10.sp,
            color = StudioTextMuted,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
        )
        return
    }
    var expandedFaceSets by remember { mutableStateOf(false) }
    var expandedBrowEyeSliders by remember { mutableStateOf(false) }
    var expandedLipSyncControls by remember { mutableStateOf(false) }
    val evalRoot = remember(rig, uiState.currentFrame) {
        rig?.let { InterpolationEngine.evaluatePuppetRoot(it, uiState.currentFrame) }
    }
    val curEye = evalRoot?.eyePack ?: rig?.eyePack ?: ""
    val curMouth = evalRoot?.mouthPhoneme ?: rig?.mouthPhoneme ?: ""
    val curBrow = evalRoot?.leftEyebrowStyle ?: rig?.leftEyebrowStyle ?: ""
    val curEyeMood = evalRoot?.activeEyeMood ?: rig?.activeEyeMood ?: ""
    val curMouthMood = evalRoot?.activeMouthMood ?: rig?.activeMouthMood ?: ""

    val headBobOn = (evalRoot?.headBobEnabled ?: rig?.headBobEnabled ?: true) && (rig?.headBobEnabled ?: true)
    val headBobMode = evalRoot?.headBobMode ?: rig?.headBobMode ?: "TALK_ONLY"
    val headBobIntensity = (evalRoot?.headBobIntensity ?: rig?.headBobIntensity ?: 0.4f).coerceIn(0f, 1f)

    val lipSyncSens = (evalRoot?.lipSyncSensitivity ?: rig?.lipSyncSensitivity ?: 1.0f).coerceIn(0.1f, 3.0f)
    val lipSyncMinHz = (evalRoot?.lipSyncMinFreqHz ?: rig?.lipSyncMinFreqHz ?: 250).coerceIn(60, 7800)
    val lipSyncMaxHz = (evalRoot?.lipSyncMaxFreqHz ?: rig?.lipSyncMaxFreqHz ?: 3500).coerceIn((lipSyncMinHz + 100).coerceAtLeast(300), 8000)

    val curEyeSpacing = (evalRoot?.eyeSpacing ?: rig?.eyeSpacing ?: 1.0f).coerceIn(0.5f, 1.8f)
    val curEyeScale = (evalRoot?.eyeScale ?: rig?.eyeScale ?: 1.0f).coerceIn(0.5f, 1.8f)
    val curLeftBrowY = (evalRoot?.leftBrowY ?: rig?.leftBrowY ?: 0f).coerceIn(-25f, 25f)
    val curRightBrowY = (evalRoot?.rightBrowY ?: rig?.rightBrowY ?: 0f).coerceIn(-25f, 25f)
    val curLeftBrowTilt = (evalRoot?.leftBrowTilt ?: rig?.leftBrowTilt ?: 0f).coerceIn(-45f, 45f)
    val curRightBrowTilt = (evalRoot?.rightBrowTilt ?: rig?.rightBrowTilt ?: 0f).coerceIn(-45f, 45f)
    val curBrowArch = (evalRoot?.browArch ?: rig?.browArch ?: 0f).coerceIn(-1f, 1f)
    val curBrowSpacing = (evalRoot?.browSpacing ?: rig?.browSpacing ?: 1.0f).coerceIn(0.5f, 1.8f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurfaceVariant.copy(alpha = 0.55f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Row 1: Quick Stage Moods + Head Bob ON/OFF + Brows & Eyes Sliders Toggle + Face Sets + Swap Char
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            StageMoodPreset.entries.forEach { preset ->
                val accent = when (preset) {
                    StageMoodPreset.NORMAL -> StudioTextPrimary
                    StageMoodPreset.TALKING -> StudioEmerald
                    StageMoodPreset.SUDDEN_CRY -> StudioCyan
                    StageMoodPreset.LAUGHING -> StudioAmber
                    StageMoodPreset.ANGRY -> StudioCoral
                    StageMoodPreset.SHOCKED -> StudioViolet
                    StageMoodPreset.BLINK -> StudioCyan
                }
                ContextPill(
                    label = preset.displayName,
                    active = false,
                    accent = accent,
                    tag = "stage_mood_${preset.name.lowercase()}",
                    onClick = { onApplyMoodPreset(preset) }
                )
            }
            if (rig != null) {
                ContextPill(
                    label = if (headBobOn) "Head Bob: ON (${(headBobIntensity * 100).roundToInt()}%)" else "Head Bob: OFF",
                    active = headBobOn,
                    accent = if (headBobOn) StudioEmerald else StudioCoral,
                    tag = "stage_head_bob_toggle_btn",
                    onClick = onToggleHeadBobEnabled
                )
                ContextPill(
                    label = if (expandedLipSyncControls) "Lip-Sync Hz (${(lipSyncSens * 100).roundToInt()}%) ▲" else "Lip-Sync Hz (${(lipSyncSens * 100).roundToInt()}%) ▼",
                    active = expandedLipSyncControls,
                    accent = StudioCoral,
                    tag = "stage_face_expand_lipsync_btn",
                    onClick = { expandedLipSyncControls = !expandedLipSyncControls }
                )
                ContextPill(
                    label = if (expandedBrowEyeSliders) "Brows & Eyes ▲" else "Brows & Eyes ▼",
                    active = expandedBrowEyeSliders,
                    accent = StudioViolet,
                    tag = "stage_face_expand_brow_eye_sliders_btn",
                    onClick = { expandedBrowEyeSliders = !expandedBrowEyeSliders }
                )
            }
            ContextPill(
                label = if (expandedFaceSets) "Face Sets ▲" else "Face Sets ▼",
                active = expandedFaceSets,
                accent = StudioCyan,
                tag = "stage_face_expand_eye_mouth_btn",
                onClick = { expandedFaceSets = !expandedFaceSets }
            )
            if (rig != null) {
                val hasSwapHere = selLayer.characterSwapKeyframes.containsKey(uiState.currentFrame)
                ContextPill(
                    label = if (hasSwapHere) "Swap Char ◆" else "Swap Char",
                    icon = Icons.Rounded.SwapHoriz,
                    active = hasSwapHere,
                    accent = if (hasSwapHere) StudioEmerald else StudioAmber,
                    tag = "stage_swap_char_btn",
                    onClick = onOpenSwapChar
                )
                ContextPill(
                    label = "Reset Pose",
                    active = false,
                    accent = StudioCoral,
                    tag = "stage_reset_pose_btn",
                    onClick = onResetPose
                )
            }
        }

        // Row 2: Always-accessible Head Bob Mode & Sway Intensity Strip when a rigged character is selected
        if (rig != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("Head Motion:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioEmerald)
                ContextPill(
                    label = if (headBobOn) "Bob: ON" else "Bob: OFF (Steady)",
                    active = headBobOn,
                    accent = if (headBobOn) StudioEmerald else StudioCoral,
                    tag = "face_strip_head_bob_on_off",
                    onClick = onToggleHeadBobEnabled
                )
                ContextPill(
                    label = "Talk Only",
                    active = headBobOn && headBobMode != "ALWAYS",
                    accent = StudioCyan,
                    tag = "face_strip_head_bob_talk_only",
                    onClick = { onSetHeadBobMode("TALK_ONLY") }
                )
                ContextPill(
                    label = "Always",
                    active = headBobOn && headBobMode == "ALWAYS",
                    accent = StudioAmber,
                    tag = "face_strip_head_bob_always",
                    onClick = { onSetHeadBobMode("ALWAYS") }
                )
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "Head Sway ${(headBobIntensity * 100).roundToInt()}%",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioEmerald
                        )
                        IconButton(
                            onClick = { onSetHeadBobIntensity((headBobIntensity - 0.1f).coerceIn(0f, 1f)) },
                            modifier = Modifier.size(22.dp).testTag("head_sway_minus_btn")
                        ) {
                            Icon(Icons.Rounded.Remove, contentDescription = "Decrease head sway", tint = StudioTextPrimary, modifier = Modifier.size(13.dp))
                        }
                        Slider(
                            value = headBobIntensity,
                            onValueChange = { onSetHeadBobIntensity(it) },
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(thumbColor = StudioEmerald, activeTrackColor = StudioEmerald),
                            modifier = Modifier.width(84.dp).height(22.dp).testTag("head_sway_intensity_slider")
                        )
                        IconButton(
                            onClick = { onSetHeadBobIntensity((headBobIntensity + 0.1f).coerceIn(0f, 1f)) },
                            modifier = Modifier.size(22.dp).testTag("head_sway_plus_btn")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Increase head sway", tint = StudioTextPrimary, modifier = Modifier.size(13.dp))
                        }
                    }
                }
            }
        }

        // Upgrade 1: Lip-Sync Mouth Sensitivity (10% - 300%) & Frequency Range Filter (Min Hz - Max Hz, 60-8000 Hz)
        AnimatedVisibility(visible = expandedLipSyncControls && rig != null) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // 1-Tap Frequency Band Preset Chips
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Band Filter:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioCoral)
                    listOf(
                        Triple("VOICE", "Voice (250–3500 Hz)", lipSyncMinHz == 250 && lipSyncMaxHz == 3500),
                        Triple("ALL", "All Sound (60–8000 Hz)", lipSyncMinHz == 60 && lipSyncMaxHz == 8000),
                        Triple("BASS", "Bass Only (60–300 Hz)", lipSyncMinHz == 60 && lipSyncMaxHz == 300),
                        Triple("HIGH", "High/Treble (3500–8000 Hz)", lipSyncMinHz == 3500 && lipSyncMaxHz == 8000)
                    ).forEach { (presetKey, label, isMatch) ->
                        ContextPill(
                            label = label,
                            active = isMatch,
                            accent = StudioCoral,
                            tag = "lipsync_preset_${presetKey.lowercase()}",
                            onClick = { onApplyLipSyncFrequencyPreset(presetKey) }
                        )
                    }
                }

                // Mouth Sensitivity Slider (10% - 300%) + Dual Min Hz / Max Hz Sliders (60 Hz - 8000 Hz)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CompactFaceSliderBox(
                        label = "Mouth Sens ${(lipSyncSens * 100).roundToInt()}%",
                        value = lipSyncSens,
                        range = 0.1f..3.0f,
                        step = 0.1f,
                        accent = StudioCoral,
                        tagPrefix = "stage_lipsync_sensitivity",
                        onChange = onSetLipSyncSensitivity
                    )
                    CompactFaceSliderBox(
                        label = "Min ${lipSyncMinHz} Hz",
                        value = lipSyncMinHz.toFloat(),
                        range = 60f..4000f,
                        step = 50f,
                        accent = StudioCyan,
                        tagPrefix = "stage_lipsync_min_hz",
                        onChange = { newMin ->
                            val clampedMin = newMin.roundToInt().coerceIn(60, 4000)
                            val safeMax = maxOf(lipSyncMaxHz, (clampedMin + 100).coerceAtLeast(300))
                            onSetLipSyncFrequencyRange(clampedMin, safeMax)
                        }
                    )
                    CompactFaceSliderBox(
                        label = "Max ${lipSyncMaxHz} Hz",
                        value = lipSyncMaxHz.toFloat(),
                        range = 300f..8000f,
                        step = 100f,
                        accent = StudioAmber,
                        tagPrefix = "stage_lipsync_max_hz",
                        onChange = { newMax ->
                            val clampedMax = newMax.roundToInt().coerceIn(300, 8000)
                            val safeMin = minOf(lipSyncMinHz, (clampedMax - 100).coerceAtLeast(60))
                            onSetLipSyncFrequencyRange(safeMin, clampedMax)
                        }
                    )
                }
            }
        }

        // Expandable Decoupled Eyebrows & Eye Separation / Scale Controls (Upgrade 4)
        AnimatedVisibility(visible = expandedBrowEyeSliders && rig != null) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // Quick Decoupled Brow Expression Presets
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Quick Brows:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioViolet)
                    listOf(
                        "NEUTRAL" to "Neutral",
                        "ANGRY" to "Angry Furrow",
                        "SAD" to "Sad / Worried",
                        "SURPRISED" to "Surprised High",
                        "SKEPTICAL_L" to "Skeptical L",
                        "SKEPTICAL_R" to "Skeptical R"
                    ).forEach { (key, label) ->
                        ContextPill(
                            label = label,
                            active = false,
                            accent = StudioViolet,
                            tag = "quick_brow_preset_${key.lowercase()}",
                            onClick = { onApplyQuickBrowExpression(key) }
                        )
                    }
                }

                // Independent Eye Spacing, Eye Scale, Brow Spacing, Brow Arch
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CompactFaceSliderBox(
                        label = "Eye Space ${String.format(Locale.US, "%.2fx", curEyeSpacing)}",
                        value = curEyeSpacing,
                        range = 0.5f..1.8f,
                        step = 0.05f,
                        accent = StudioCyan,
                        tagPrefix = "stage_eye_spacing",
                        onChange = onSetEyeSpacing
                    )
                    CompactFaceSliderBox(
                        label = "Eye Scale ${String.format(Locale.US, "%.2fx", curEyeScale)}",
                        value = curEyeScale,
                        range = 0.5f..1.8f,
                        step = 0.05f,
                        accent = StudioCyan,
                        tagPrefix = "stage_eye_scale",
                        onChange = onSetEyeScale
                    )
                    CompactFaceSliderBox(
                        label = "Brow Space ${String.format(Locale.US, "%.2fx", curBrowSpacing)}",
                        value = curBrowSpacing,
                        range = 0.5f..1.8f,
                        step = 0.05f,
                        accent = StudioViolet,
                        tagPrefix = "stage_brow_spacing",
                        onChange = onSetBrowSpacing
                    )
                    CompactFaceSliderBox(
                        label = "Brow Arch ${(curBrowArch * 100).roundToInt()}%",
                        value = curBrowArch,
                        range = -1f..1f,
                        step = 0.1f,
                        accent = StudioAmber,
                        tagPrefix = "stage_brow_arch",
                        onChange = onSetBrowArch
                    )
                }

                // Independent Left / Right Brow Height & Brow Furrow / Tilt (-45°..+45°)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CompactFaceSliderBox(
                        label = "L-Brow Y ${curLeftBrowY.roundToInt()}",
                        value = curLeftBrowY,
                        range = -25f..25f,
                        step = 2f,
                        accent = StudioViolet,
                        tagPrefix = "stage_left_brow_y",
                        onChange = { onSetBrowHeight(it, null) }
                    )
                    CompactFaceSliderBox(
                        label = "R-Brow Y ${curRightBrowY.roundToInt()}",
                        value = curRightBrowY,
                        range = -25f..25f,
                        step = 2f,
                        accent = StudioViolet,
                        tagPrefix = "stage_right_brow_y",
                        onChange = { onSetBrowHeight(null, it) }
                    )
                    CompactFaceSliderBox(
                        label = "L-Tilt ${curLeftBrowTilt.roundToInt()}°",
                        value = curLeftBrowTilt,
                        range = -45f..45f,
                        step = 3f,
                        accent = StudioCoral,
                        tagPrefix = "stage_left_brow_tilt",
                        onChange = { onSetBrowTilt(it, null) }
                    )
                    CompactFaceSliderBox(
                        label = "R-Tilt ${curRightBrowTilt.roundToInt()}°",
                        value = curRightBrowTilt,
                        range = -45f..45f,
                        step = 3f,
                        accent = StudioCoral,
                        tagPrefix = "stage_right_brow_tilt",
                        onChange = { onSetBrowTilt(null, it) }
                    )
                }
            }
        }

        AnimatedVisibility(visible = expandedFaceSets) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Visibility, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(13.dp))
                    Text("Eyes:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioCyan)
                    EyePackStyle.entries.forEach { eye ->
                        ContextPill(
                            label = eye.label,
                            active = curEye == eye.name,
                            accent = StudioCyan,
                            tag = "stage_eye_${eye.name.lowercase()}",
                            onClick = { onSelectEyePack(eye) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Face, contentDescription = null, tint = StudioCoral, modifier = Modifier.size(13.dp))
                    Text("Mouth:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioCoral)
                    MouthPhoneme.entries.forEach { mouth ->
                        ContextPill(
                            label = mouth.label,
                            active = curMouth == mouth.name,
                            accent = StudioCoral,
                            tag = "stage_mouth_${mouth.name.lowercase()}",
                            onClick = { onSelectMouthPhoneme(mouth) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Brows:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioViolet)
                    EyebrowStyle.entries.forEach { brow ->
                        ContextPill(
                            label = brow.label,
                            active = curBrow == brow.name,
                            accent = StudioViolet,
                            tag = "stage_brow_${brow.name.lowercase()}",
                            onClick = { onSelectEyebrow(brow) }
                        )
                    }
                    Text("• Sets:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StudioAmber)
                    FaceMoodCategory.entries.forEach { mood ->
                        ContextPill(
                            label = mood.label,
                            active = curEyeMood == mood.name && curMouthMood == mood.name,
                            accent = StudioAmber,
                            tag = "stage_faceset_${mood.name.lowercase()}",
                            onClick = {
                                onSelectEyeMood(mood)
                                onSelectMouthMood(mood)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactFaceSliderBox(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    accent: Color,
    tagPrefix: String,
    onChange: (Float) -> Unit
) {
    Surface(
        color = StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, StudioBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = accent)
            IconButton(
                onClick = { onChange((value - step).coerceIn(range.start, range.endInclusive)) },
                modifier = Modifier.size(22.dp).testTag("${tagPrefix}_minus")
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = "Decrease $label", tint = StudioTextPrimary, modifier = Modifier.size(12.dp))
            }
            Slider(
                value = value.coerceIn(range.start, range.endInclusive),
                onValueChange = onChange,
                valueRange = range,
                colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent),
                modifier = Modifier.width(74.dp).height(22.dp).testTag("${tagPrefix}_slider")
            )
            IconButton(
                onClick = { onChange((value + step).coerceIn(range.start, range.endInclusive)) },
                modifier = Modifier.size(22.dp).testTag("${tagPrefix}_plus")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Increase $label", tint = StudioTextPrimary, modifier = Modifier.size(12.dp))
            }
        }
    }
}

@Composable
private fun PropsContextStrip(
    uiState: StudioUiState,
    onSelectLayer: (String) -> Unit,
    onStartAttachBonePick: (propLayerId: String?) -> Unit,
    onAttachPropToBone: (propLayerId: String, hostLayerId: String, boneId: String) -> Unit,
    onDetachProp: (propLayerId: String) -> Unit,
    onCenterPropInPalm: (propLayerId: String) -> Unit,
    onToggleRotateProp: () -> Unit,
    onImportImage: () -> Unit
) {
    val allPropsAndImages = remember(uiState.activeScene?.layers) {
        uiState.activeScene?.layers.orEmpty().filter { l ->
            l.rig == null && l.type != LayerType.BACKGROUND.name && l.type != LayerType.VIDEO.name
        }.reversed()
    }
    val selectedLayer = uiState.selectedLayer
    val propLayer = selectedLayer?.takeIf { l ->
        l.rig == null && l.type != LayerType.BACKGROUND.name && l.type != LayerType.VIDEO.name
    } ?: allPropsAndImages.firstOrNull()

    val sceneCharacters = remember(uiState.activeScene?.layers) {
        uiState.activeScene?.layers.orEmpty().filter { it.rig != null }
    }
    var selectedHostIdx by remember(sceneCharacters.size) { mutableStateOf(0) }
    val hostChar = sceneCharacters.getOrNull(selectedHostIdx % sceneCharacters.size.coerceAtLeast(1))
    var propPickerOpen by remember { mutableStateOf(false) }
    var bonePickerOpen by remember { mutableStateOf(false) }

    val activeLink = remember(propLayer?.propBoneLinkKeyframes, propLayer?.propGrabKeyframes, uiState.currentFrame) {
        propLayer?.let { InterpolationEngine.evaluatePropBoneLink(it, uiState.currentFrame) }
    }
    val isAttached = activeLink != null && activeLink.isAttached &&
        !activeLink.targetCharacterLayerId.isNullOrBlank() && !activeLink.targetBoneId.isNullOrBlank()
    val attachedCharName = remember(activeLink, sceneCharacters) {
        sceneCharacters.firstOrNull { it.id == activeLink?.targetCharacterLayerId }?.name ?: ""
    }
    val attachedBoneName = remember(activeLink, sceneCharacters) {
        val h = sceneCharacters.firstOrNull { it.id == activeLink?.targetCharacterLayerId }
        h?.rig?.bones?.firstOrNull { it.id == activeLink?.targetBoneId }?.name ?: activeLink?.targetBoneId ?: ""
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurfaceVariant.copy(alpha = 0.55f))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        // 1. Target Object / Image Dropdown (works even when a Character is currently selected!)
        Box {
            ContextPill(
                label = if (propLayer != null) "Obj: ${propLayer.name.take(10)} ▾" else "No Prop/Img",
                active = propPickerOpen,
                accent = StudioTextPrimary,
                tag = "prop_strip_target_obj_btn",
                onClick = { if (allPropsAndImages.isNotEmpty()) propPickerOpen = true else onImportImage() }
            )
            DropdownMenu(
                expanded = propPickerOpen,
                onDismissRequest = { propPickerOpen = false },
                modifier = Modifier.background(StudioSurfaceElevated)
            ) {
                allPropsAndImages.forEach { obj ->
                    DropdownMenuItem(
                        text = { Text(obj.name, color = StudioTextPrimary, fontSize = 12.sp) },
                        onClick = {
                            propPickerOpen = false
                            onSelectLayer(obj.id)
                        }
                    )
                }
            }
        }

        // Quick + Import Image/Prop button
        ContextPill(
            label = "+ Import Img",
            active = false,
            accent = StudioCyan,
            tag = "prop_strip_import_img_btn",
            onClick = onImportImage
        )

        // 2. Attach to Any Bone (Tap on Canvas) Mode
        ContextPill(
            label = if (uiState.attachBonePickMode) "Tap Bone on Canvas..." else "Attach to Any Bone",
            icon = Icons.Rounded.Link,
            active = uiState.attachBonePickMode || !isAttached,
            accent = StudioEmerald,
            tag = "prop_attach_any_bone_btn",
            onClick = { onStartAttachBonePick(propLayer?.id) }
        )

        // 3. ALWAYS-VISIBLE "Detach Bone" Button (NEVER conditionally hidden!)
        ContextPill(
            label = if (isAttached) "Detach Bone ($attachedBoneName)" else "Detach Bone",
            icon = Icons.Rounded.LinkOff,
            active = isAttached,
            accent = StudioCoral,
            tag = "prop_detach_bone_always_btn",
            onClick = { if (propLayer != null) onDetachProp(propLayer.id) }
        )

        if (propLayer != null && hostChar != null) {
            if (sceneCharacters.size > 1) {
                ContextPill(
                    label = "Char: ${hostChar.name.take(9)} ▾",
                    active = false,
                    accent = StudioTextPrimary,
                    tag = "prop_bar_cycle_host_btn",
                    onClick = { selectedHostIdx = (selectedHostIdx + 1) % sceneCharacters.size }
                )
            }

            // 4. Pick ANY Bone Dropdown (lists EVERY bone on the character including custom +Extra Rig bones!)
            Box {
                ContextPill(
                    label = "Pick Bone ▾",
                    active = bonePickerOpen,
                    accent = StudioCyan,
                    tag = "prop_pick_bone_btn",
                    onClick = { bonePickerOpen = true }
                )
                DropdownMenu(
                    expanded = bonePickerOpen,
                    onDismissRequest = { bonePickerOpen = false },
                    modifier = Modifier.background(StudioSurfaceElevated)
                ) {
                    hostChar.rig?.bones.orEmpty().forEach { bone ->
                        val isCurrent = isAttached && activeLink?.targetCharacterLayerId == hostChar.id && activeLink.targetBoneId == bone.id
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (isCurrent) "✓ ${bone.name}" else bone.name,
                                    color = if (isCurrent) StudioEmerald else StudioTextPrimary,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            },
                            onClick = {
                                bonePickerOpen = false
                                onAttachPropToBone(propLayer.id, hostChar.id, bone.id)
                            }
                        )
                    }
                }
            }

            ContextPill(
                label = "Center Bone",
                active = false,
                accent = StudioCyan,
                tag = "prop_bar_center_palm_btn",
                onClick = { onCenterPropInPalm(propLayer.id) }
            )
        }

        // 5. Dedicated Rotate Prop Toggle (28dp circular ring around prop pivot)
        ContextPill(
            label = if (uiState.propRotateMode) "Rotate Prop: ON" else "Rotate Prop",
            active = uiState.propRotateMode,
            accent = StudioAmber,
            tag = "prop_bar_rotate_prop_btn",
            onClick = {
                if (propLayer != null && uiState.selectedLayerId != propLayer.id) {
                    onSelectLayer(propLayer.id)
                }
                onToggleRotateProp()
            }
        )

        if (isAttached && attachedCharName.isNotBlank()) {
            Text(
                text = "Locked: $attachedCharName → $attachedBoneName",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = StudioEmerald,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
private fun RangeContextStrip(
    uiState: StudioUiState,
    customActionsCount: Int,
    onSetStart: () -> Unit,
    onOpenNumbers: () -> Unit,
    onSetEnd: () -> Unit,
    onTogglePlayRange: () -> Unit,
    onOpenSaveAction: () -> Unit,
    onOpenApplyAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurfaceVariant.copy(alpha = 0.55f))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        ContextPill(
            label = "[ Start",
            active = false,
            accent = StudioAmber,
            tag = "timeline_range_set_start_btn",
            onClick = onSetStart
        )
        ContextPill(
            label = "F${uiState.rangeStartFrame + 1}–F${uiState.rangeEndFrame + 1} (${(uiState.rangeEndFrame - uiState.rangeStartFrame + 1).coerceAtLeast(1)}f)",
            active = uiState.playRangeOnly,
            accent = StudioAmber,
            tag = "timeline_range_numbers_btn",
            onClick = onOpenNumbers
        )
        ContextPill(
            label = "End ]",
            active = false,
            accent = StudioAmber,
            tag = "timeline_range_set_end_btn",
            onClick = onSetEnd
        )
        ContextPill(
            label = if (uiState.playRangeOnly) "Play Range: ON" else "Play Range",
            icon = Icons.Rounded.PlayArrow,
            active = uiState.playRangeOnly,
            accent = StudioEmerald,
            tag = "range_tab_play_range_btn",
            onClick = onTogglePlayRange
        )
        if (uiState.selectedLayer?.rig != null) {
            ContextPill(
                label = "Extract / Save Action",
                icon = Icons.Rounded.Add,
                active = false,
                accent = StudioEmerald,
                tag = "timeline_extract_save_action_btn",
                onClick = onOpenSaveAction
            )
            ContextPill(
                label = if (customActionsCount > 0) "Apply Action ($customActionsCount)" else "Apply Action",
                icon = Icons.Rounded.AutoAwesome,
                active = false,
                accent = StudioCyan,
                tag = "timeline_apply_action_btn",
                onClick = onOpenApplyAction
            )
        }
    }
}

@Composable
private fun ContextPill(
    label: String,
    icon: ImageVector? = null,
    active: Boolean,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) accent.copy(alpha = 0.24f) else StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (active) accent else accent.copy(alpha = 0.48f)),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = accent,
                    modifier = Modifier.size(13.dp)
                )
            }
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.SemiBold,
                color = if (active) accent else StudioTextPrimary,
                maxLines = 1
            )
        }
    }
}
