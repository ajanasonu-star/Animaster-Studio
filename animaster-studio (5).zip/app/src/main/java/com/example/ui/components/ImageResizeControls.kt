package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet

/**
 * Reusable Universal Image / PNG Resize & Squash-Stretch Control Box (`0.1x` – `3.5x`):
 * - Overall Size slider (scales Width X & Height Y proportionally)
 * - Stretch Width (X) slider (`0.1x` – `3.5x`)
 * - Squash Height (Y) slider (`0.1x` – `3.5x`)
 * - 1-tap Reset Size (1:1) button
 */
@Composable
fun ImageResizeSquashStretchBox(
    scaleX: Float,
    scaleY: Float,
    onOverallScaleChange: (Float) -> Unit,
    onScaleXChange: (Float) -> Unit,
    onScaleYChange: (Float) -> Unit,
    onResetSize: () -> Unit,
    modifier: Modifier = Modifier,
    title: String = "Image Resize & Squash / Stretch",
    accentColor: Color = StudioCyan,
    testTagPrefix: String = "img_resize"
) {
    val safeSx = if (scaleX.isFinite() && scaleX >= 0.05f) scaleX.coerceIn(0.1f, 3.5f) else 1f
    val safeSy = if (scaleY.isFinite() && scaleY >= 0.05f) scaleY.coerceIn(0.1f, 3.5f) else 1f
    val overall = ((safeSx + safeSy) * 0.5f).coerceIn(0.1f, 3.5f)

    Surface(
        color = StudioSurfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("${testTagPrefix}_box")
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AspectRatio,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onResetSize)
                        .testTag("${testTagPrefix}_reset_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Reset Size 1:1",
                            tint = StudioTextPrimary,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "Reset Size (1:1)",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextPrimary
                        )
                    }
                }
            }

            // 1. Overall Size (proportional scale)
            ResizeAxisSliderRow(
                label = "Overall Size",
                value = overall,
                color = StudioViolet,
                onValueChange = onOverallScaleChange,
                testTag = "${testTagPrefix}_overall_slider"
            )

            // 2. Stretch Width (X)
            ResizeAxisSliderRow(
                label = "Stretch W (X)",
                value = safeSx,
                color = StudioCyan,
                onValueChange = onScaleXChange,
                testTag = "${testTagPrefix}_scale_x_slider"
            )

            // 3. Squash Height (Y)
            ResizeAxisSliderRow(
                label = "Squash H (Y)",
                value = safeSy,
                color = StudioCoral,
                onValueChange = onScaleYChange,
                testTag = "${testTagPrefix}_scale_y_slider"
            )

            Text(
                text = "Tip: Drag corner handles on canvas for proportional resize, or edge handles to squash & stretch.",
                fontSize = 9.sp,
                color = StudioTextSecondary
            )
        }
    }
}

@Composable
private fun ResizeAxisSliderRow(
    label: String,
    value: Float,
    color: Color,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = StudioTextPrimary,
            modifier = Modifier.width(74.dp)
        )
        Slider(
            value = value.coerceIn(0.1f, 3.5f),
            onValueChange = { onValueChange(it.coerceIn(0.1f, 3.5f)) },
            valueRange = 0.1f..3.5f,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color,
                inactiveTrackColor = StudioSurface
            ),
            modifier = Modifier
                .weight(1f)
                .testTag(testTag)
        )
        Text(
            text = String.format("%.2fx", value),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = StudioAmber,
            modifier = Modifier.width(38.dp)
        )
    }
}
