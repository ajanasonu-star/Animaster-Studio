package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LayerType
import com.example.engine.InterpolationEngine
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.viewmodel.StudioUiState

@Composable
fun PropsAndAnyBoneAttachmentSection(
    uiState: StudioUiState,
    onSelectLayer: (String) -> Unit,
    onImportImage: () -> Unit,
    onStartAttachBonePick: (propLayerId: String?) -> Unit,
    onAttachLayerToBone: (propLayerId: String, hostLayerId: String, boneId: String) -> Unit,
    onDetachLayerFromBone: (propLayerId: String) -> Unit,
    onCenterLayerOnBone: (propLayerId: String) -> Unit,
    onToggleRotateProp: () -> Unit,
    onSetLayerScaleXY: (layerId: String, overallScale: Float?, scaleX: Float?, scaleY: Float?, reset: Boolean) -> Unit = { _, _, _, _, _ -> }
) {
    val scene = uiState.activeScene
    val allLayers = scene?.layers.orEmpty()
    val propAndImageLayers = remember(allLayers) {
        allLayers.filter { l ->
            l.rig == null && l.type != LayerType.BACKGROUND.name && l.type != LayerType.VIDEO.name
        }.reversed()
    }
    val characterLayers = remember(allLayers) {
        allLayers.filter { it.rig != null }
    }

    // Resolve target prop/image layer — works smoothly even when a character is currently selected on stage!
    val targetPropLayer = remember(uiState.selectedLayerId, propAndImageLayers) {
        propAndImageLayers.firstOrNull { it.id == uiState.selectedLayerId }
            ?: propAndImageLayers.firstOrNull()
    }

    var targetDropdownOpen by remember { mutableStateOf(false) }
    var hostDropdownOpen by remember { mutableStateOf(false) }
    var boneDropdownOpen by remember { mutableStateOf(false) }
    var chosenHostCharId by remember(characterLayers.size) {
        mutableStateOf(characterLayers.firstOrNull()?.id)
    }
    val selectedHostChar = characterLayers.firstOrNull { it.id == chosenHostCharId }
        ?: characterLayers.firstOrNull()

    val activeLink = remember(targetPropLayer?.propBoneLinkKeyframes, targetPropLayer?.propGrabKeyframes, uiState.currentFrame) {
        targetPropLayer?.let { InterpolationEngine.evaluatePropBoneLink(it, uiState.currentFrame) }
    }
    val isAttached = activeLink != null && activeLink.isAttached &&
        !activeLink.targetCharacterLayerId.isNullOrBlank() && !activeLink.targetBoneId.isNullOrBlank()
    val lockedCharLayer = remember(activeLink, characterLayers) {
        characterLayers.firstOrNull { it.id == activeLink?.targetCharacterLayerId }
    }
    val lockedBoneName = remember(activeLink, lockedCharLayer) {
        lockedCharLayer?.rig?.bones?.firstOrNull { it.id == activeLink?.targetBoneId }?.name
            ?: activeLink?.targetBoneId ?: ""
    }

    // Active Bone Attachments across ALL prop/image layers in the scene
    val activeAttachments = remember(propAndImageLayers, characterLayers, uiState.currentFrame) {
        propAndImageLayers.mapNotNull { obj ->
            val lnk = InterpolationEngine.evaluatePropBoneLink(obj, uiState.currentFrame)
            if (lnk != null && lnk.isAttached && !lnk.targetCharacterLayerId.isNullOrBlank() && !lnk.targetBoneId.isNullOrBlank()) {
                val host = characterLayers.firstOrNull { it.id == lnk.targetCharacterLayerId }
                val bName = host?.rig?.bones?.firstOrNull { it.id == lnk.targetBoneId }?.name ?: lnk.targetBoneId
                Triple(obj, host?.name ?: "Character", bName)
            } else null
        }
    }

    Surface(
        color = StudioSurfaceVariant,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (isAttached) StudioEmerald.copy(alpha = 0.65f) else StudioBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("props_any_bone_card")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header + Quick "+ Import Image/Prop" button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Rounded.Link, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(18.dp))
                    Text(
                        text = "Props & Bone Attachment",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextPrimary
                    )
                }
                Surface(
                    color = StudioCyan.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onImportImage)
                        .testTag("props_panel_import_image_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = "Import Image or Prop", tint = StudioCyan, modifier = Modifier.size(14.dp))
                        Text("+ Import Image/Prop", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StudioCyan)
                    }
                }
            }

            // 1. Target Object / Image Selector Dropdown
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Target Prop / Imported Image",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextSecondary
                )
                Box(modifier = Modifier.fillMaxWidth()) {
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                if (propAndImageLayers.isNotEmpty()) targetDropdownOpen = true else onImportImage()
                            }
                            .testTag("props_target_object_selector")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val label = if (targetPropLayer != null) {
                                val isImg = targetPropLayer.frames.values.any { it.images.isNotEmpty() }
                                "${targetPropLayer.name} (${if (isImg) "Image" else "Prop"})"
                            } else {
                                "No Prop/Image yet — tap + Import Image/Prop"
                            }
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = if (targetPropLayer != null) StudioTextPrimary else StudioTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(Icons.Rounded.ArrowDropDown, contentDescription = "Select target object", tint = StudioCyan)
                        }
                    }
                    DropdownMenu(
                        expanded = targetDropdownOpen,
                        onDismissRequest = { targetDropdownOpen = false },
                        modifier = Modifier.background(StudioSurfaceElevated)
                    ) {
                        propAndImageLayers.forEach { layer ->
                            val isImg = layer.frames.values.any { it.images.isNotEmpty() }
                            val isSel = layer.id == targetPropLayer?.id
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${if (isSel) "✓ " else ""}${layer.name} (${if (isImg) "Image" else "Prop"})",
                                        color = if (isSel) StudioEmerald else StudioTextPrimary,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                },
                                onClick = {
                                    targetDropdownOpen = false
                                    onSelectLayer(layer.id)
                                }
                            )
                        }
                    }
                }
            }

            // 2. Attachment Status Badge
            Surface(
                color = if (isAttached) StudioEmerald.copy(alpha = 0.16f) else StudioSurface,
                shape = RoundedCornerShape(9.dp),
                border = BorderStroke(1.dp, if (isAttached) StudioEmerald.copy(alpha = 0.7f) else StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isAttached) Icons.Rounded.Link else Icons.Rounded.LinkOff,
                        contentDescription = null,
                        tint = if (isAttached) StudioEmerald else StudioTextMuted,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = if (isAttached) {
                            "Locked to: ${lockedCharLayer?.name ?: "Character"} → $lockedBoneName (F${uiState.currentFrame + 1})"
                        } else {
                            "Status: Free / Detached at F${uiState.currentFrame + 1}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isAttached) StudioEmerald else StudioTextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 3. Prominent ALWAYS-VISIBLE Primary Action Bar: "Attach to Any Bone" & "Detach Bone" (NEVER hidden!)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onStartAttachBonePick(targetPropLayer?.id) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.attachBonePickMode) StudioAmber else StudioEmerald,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("props_panel_attach_any_bone_btn")
                ) {
                    Icon(Icons.Rounded.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (uiState.attachBonePickMode) "Tap Bone..." else "Attach to Any Bone",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // PERMANENTLY VISIBLE Detach Bone button (NEVER wrapped in if (isAttached)!)
                Button(
                    onClick = {
                        if (targetPropLayer != null) {
                            onDetachLayerFromBone(targetPropLayer.id)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAttached) StudioCoral else StudioCoral.copy(alpha = 0.72f),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("props_panel_detach_bone_btn")
                ) {
                    Icon(Icons.Rounded.LinkOff, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "Detach Bone",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 4. Always-Visible Rotate Prop (28dp ring) & Center on Bone buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (targetPropLayer != null && uiState.selectedLayerId != targetPropLayer.id) {
                            onSelectLayer(targetPropLayer.id)
                        }
                        onToggleRotateProp()
                    },
                    border = BorderStroke(1.dp, if (uiState.propRotateMode) StudioAmber else StudioBorder),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("props_panel_rotate_prop_btn")
                ) {
                    Icon(
                        Icons.Rounded.RotateRight,
                        contentDescription = null,
                        tint = if (uiState.propRotateMode) StudioAmber else StudioTextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (uiState.propRotateMode) "Rotate Prop: ON" else "Rotate Prop",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (uiState.propRotateMode) StudioAmber else StudioTextPrimary
                    )
                }
                OutlinedButton(
                    onClick = {
                        if (targetPropLayer != null) onCenterLayerOnBone(targetPropLayer.id)
                    },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("props_panel_center_bone_btn")
                ) {
                    Text(
                        text = "Center on Bone",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = StudioCyan
                    )
                }
            }

            // 4b. Universal Image / Prop Resize & Squash-Stretch Sliders (0.1x – 3.5x + Reset 1:1)
            if (targetPropLayer != null && scene != null) {
                val propTf = InterpolationEngine.evaluateLayerTransform(
                    targetPropLayer,
                    uiState.currentFrame,
                    scene.durationFrames
                )
                ImageResizeSquashStretchBox(
                    scaleX = propTf.scaleX,
                    scaleY = propTf.scaleY,
                    onOverallScaleChange = { onSetLayerScaleXY(targetPropLayer.id, it, null, null, false) },
                    onScaleXChange = { onSetLayerScaleXY(targetPropLayer.id, null, it, null, false) },
                    onScaleYChange = { onSetLayerScaleXY(targetPropLayer.id, null, null, it, false) },
                    onResetSize = { onSetLayerScaleXY(targetPropLayer.id, null, null, null, true) },
                    title = "Resize & Squash / Stretch (${targetPropLayer.name})",
                    accentColor = StudioCyan,
                    testTagPrefix = "props_img_resize"
                )
            }

            // 5. Select Character & ANY Bone Dropdown (1-tap binding to Head, Chest, Arm, Hand, Foot, or +Extra Rig bones)
            if (characterLayers.isNotEmpty() && targetPropLayer != null && selectedHostChar != null) {
                Text(
                    text = "Quick Bind: Select Character & Any Bone",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Character Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = StudioSurface,
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, StudioBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(9.dp))
                                .clickable { hostDropdownOpen = true }
                                .testTag("props_host_char_dropdown")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = selectedHostChar.name,
                                    fontSize = 11.sp,
                                    color = StudioTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Rounded.ArrowDropDown, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(16.dp))
                            }
                        }
                        DropdownMenu(
                            expanded = hostDropdownOpen,
                            onDismissRequest = { hostDropdownOpen = false },
                            modifier = Modifier.background(StudioSurfaceElevated)
                        ) {
                            characterLayers.forEach { ch ->
                                DropdownMenuItem(
                                    text = { Text(ch.name, color = StudioTextPrimary, fontSize = 12.sp) },
                                    onClick = {
                                        hostDropdownOpen = false
                                        chosenHostCharId = ch.id
                                    }
                                )
                            }
                        }
                    }

                    // Bone Dropdown (EVERY bone in the selected character including custom +Extra Rig bones!)
                    Box(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = StudioEmerald.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, StudioEmerald.copy(alpha = 0.65f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(9.dp))
                                .clickable { boneDropdownOpen = true }
                                .testTag("props_any_bone_dropdown")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isAttached && lockedCharLayer?.id == selectedHostChar.id) {
                                        "Bone: $lockedBoneName"
                                    } else {
                                        "Pick Any Bone"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StudioEmerald,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Rounded.ArrowDropDown, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(16.dp))
                            }
                        }
                        DropdownMenu(
                            expanded = boneDropdownOpen,
                            onDismissRequest = { boneDropdownOpen = false },
                            modifier = Modifier.background(StudioSurfaceElevated)
                        ) {
                            selectedHostChar.rig?.bones.orEmpty().forEach { bone ->
                                val isCur = isAttached &&
                                    activeLink?.targetCharacterLayerId == selectedHostChar.id &&
                                    activeLink.targetBoneId == bone.id
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = if (isCur) "✓ ${bone.name}" else bone.name,
                                            color = if (isCur) StudioEmerald else StudioTextPrimary,
                                            fontWeight = if (isCur) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp
                                        )
                                    },
                                    onClick = {
                                        boneDropdownOpen = false
                                        onAttachLayerToBone(targetPropLayer.id, selectedHostChar.id, bone.id)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 6. "Active Bone Attachments" Section — 1-tap Detach at Current Frame even without selecting the layer first!
            HorizontalDivider(color = StudioBorder)
            Text(
                text = "Active Bone Attachments (${activeAttachments.size})",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (activeAttachments.isNotEmpty()) StudioEmerald else StudioTextMuted
            )
            if (activeAttachments.isEmpty()) {
                Text(
                    text = "No objects locked to a bone at F${uiState.currentFrame + 1}. Tap \"Attach to Any Bone\" or pick a bone above.",
                    fontSize = 11.sp,
                    color = StudioTextMuted
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    activeAttachments.forEach { (objLayer, hostName, boneName) ->
                        Surface(
                            color = StudioSurface,
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, StudioEmerald.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 9.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onSelectLayer(objLayer.id) }
                                ) {
                                    Text(
                                        text = objLayer.name,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StudioTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Locked to: $hostName → $boneName",
                                        fontSize = 10.sp,
                                        color = StudioEmerald,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Surface(
                                    color = StudioCoral,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onDetachLayerFromBone(objLayer.id) }
                                        .testTag("active_attachment_detach_${objLayer.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(Icons.Rounded.LinkOff, contentDescription = null, tint = Color.Black, modifier = Modifier.size(13.dp))
                                        Text(
                                            text = "Detach at F${uiState.currentFrame + 1}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
