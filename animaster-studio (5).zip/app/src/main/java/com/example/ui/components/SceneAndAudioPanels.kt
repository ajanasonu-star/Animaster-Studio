package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneTransition
import com.example.data.model.SceneVfxType
import com.example.data.model.SubtitleStyle
import com.example.data.model.VoiceEffectType
import com.example.engine.BuiltInAudioPreset
import com.example.engine.InterpolationEngine
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SceneCameraInspectorPanel(
    uiState: StudioUiState,
    onSelectScene: (String) -> Unit,
    onAddScene: () -> Unit,
    onDeleteScene: (String) -> Unit,
    onSetDuration: (Int) -> Unit,
    onAddFrames: (Int) -> Unit,
    onSetBackgroundTemplate: (BackgroundTemplate) -> Unit,
    onSetBackgroundColor: (Long) -> Unit = {},
    onSetBackgroundScrollSpeed: (Float) -> Unit,
    onSetColorGrade: (SceneColorGrade) -> Unit,
    onToggleVfx: (SceneVfxType) -> Unit,
    onAddScreenEffectClip: (SceneVfxType) -> Unit = {},
    onUpdateScreenEffectClipRange: (clipId: String, startFrame: Int, endFrame: Int) -> Unit = { _, _, _ -> },
    onRemoveScreenEffectClip: (clipId: String) -> Unit = {},
    onAddSubtitle: (text: String, speaker: String, durationFrames: Int, style: SubtitleStyle, colorArgb: Long) -> Unit,
    onDeleteSubtitle: (String) -> Unit,
    onSetTransition: (SceneTransition) -> Unit,
    onUpdateCamera: (Float, Float, Float, Float) -> Unit,
    onToggleCameraFrame: () -> Unit = {},
    onToggleCameraHud: () -> Unit = {},
    onCameraFollowSelected: () -> Unit,
    onCameraDollyZoom: () -> Unit = {},
    onCameraPanAcross: () -> Unit = {},
    onCameraShake: () -> Unit,
    onJumpToFrame: (Int) -> Unit = {},
    onDeleteCameraKeyframe: (Int) -> Unit = {},
    onResetCamera: () -> Unit,
    onSetDepthBlur: (Float) -> Unit = {},
    onToggleForegroundPlane: () -> Unit = {},
    onSetCameraFollowLayer: (String?) -> Unit = {},
    onUpdateSpotlight: (enabled: Boolean?, x: Float?, y: Float?, radius: Float?, intensity: Float?, colorArgb: Long?) -> Unit = { _, _, _, _, _, _ -> },
    onUpdateWatermark: (text: String?, opacity: Float?, corner: String?, clear: Boolean) -> Unit = { _, _, _, _ -> },
    onImportWatermarkLogo: () -> Unit = {},
    onDuplicateScene: (String) -> Unit = {},
    onUpdateBackgroundRange: (startFrame: Int, endFrame: Int) -> Unit = { _, _ -> },
    onUpdateLightingRange: (startFrame: Int, endFrame: Int) -> Unit = { _, _ -> }
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val cam = InterpolationEngine.evaluateCamera(scene, uiState.currentFrame)

    var subtitleText by remember { mutableStateOf("") }
    var subtitleSpeaker by remember { mutableStateOf("") }
    var subtitleStyle by remember { mutableStateOf(SubtitleStyle.YOUTUBE_BOLD) }
    var subtitleDuration by remember { mutableIntStateOf(36) }
    var subtitleColorArgb by remember { mutableStateOf(0xFFFFE066L) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Scenes list
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Scenes (${project.scenes.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
                OutlinedButton(onClick = onAddScene, modifier = Modifier.testTag("add_scene_button")) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("New Scene", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                project.scenes.forEach { s ->
                    val active = s.id == scene.id
                    Surface(
                        color = if (active) StudioSurfaceElevated else StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (active) StudioCoral else StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectScene(s.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(s.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                                Text(
                                    "${s.durationFrames} frames • ${s.layers.size} layers • ${s.audioTracks.size} audio clips",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioTextMuted
                                )
                            }
                            IconButton(
                                onClick = { onDuplicateScene(s.id) },
                                modifier = Modifier.size(30.dp).testTag("duplicate_scene_${s.id}")
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = "Duplicate scene/episode", tint = StudioCyan, modifier = Modifier.size(15.dp))
                            }
                            if (project.scenes.size > 1) {
                                IconButton(onClick = { onDeleteScene(s.id) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete scene", tint = StudioRose, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Unlimited Duration, Aesthetic Backdrops & VFX
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text(
                "Scene Duration: ${scene.durationFrames} frames (${String.format("%.1fs", scene.durationFrames.toFloat() / project.fps.coerceAtLeast(1))})",
                style = MaterialTheme.typography.labelMedium,
                color = StudioTextPrimary
            )
            Slider(
                value = scene.durationFrames.toFloat().coerceIn(12f, 2000f),
                onValueChange = { onSetDuration(it.toInt()) },
                valueRange = 12f..2000f,
                colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(10, 50, 100).forEach { delta ->
                    OutlinedButton(
                        onClick = { onAddFrames(delta) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("+$delta F", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Background, Horror & Pastel Backdrops", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BackgroundTemplate.entries.forEach { tpl ->
                    FilterChip(
                        selected = scene.backgroundTemplate == tpl.name,
                        onClick = { onSetBackgroundTemplate(tpl) },
                        label = { Text(tpl.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            ProColorPickerWithSliders(
                label = "Stage / Background Color",
                selectedColorArgb = scene.backgroundColorArgb,
                onColorChanged = onSetBackgroundColor,
                presets = listOf(0xFF0F172AL, 0xFFFFFFFFL, 0xFF1E293BL, 0xFF38BDF8L, 0xFF22C55EL, 0xFFFEF08AL, 0xFF7C3AEDL),
                accentColor = StudioCyan,
                initiallyExpanded = false,
                testTagPrefix = "scene_bg_color"
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Auto-Scroll BG: ${String.format("%.1f", scene.backgroundScrollSpeed)} px/f",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudioCyan
                )
                if (scene.backgroundScrollSpeed != 0f) {
                    OutlinedButton(onClick = { onSetBackgroundScrollSpeed(0f) }) {
                        Text("Stop", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Slider(
                value = scene.backgroundScrollSpeed.coerceIn(-8f, 8f),
                onValueChange = { onSetBackgroundScrollSpeed(it) },
                valueRange = -8f..8f,
                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                modifier = Modifier.testTag("scene_bg_scroll_slider")
            )
            // Module 9: Multi-Plane Depth Foreground & Background Depth Blur
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Multi-Plane Foreground (Pillars/Trees)", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                Switch(checked = scene.foregroundPlaneEnabled, onCheckedChange = { onToggleForegroundPlane() })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Depth Blur ${(scene.backgroundDepthBlur * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioViolet, modifier = Modifier.width(96.dp))
                Slider(
                    value = scene.backgroundDepthBlur.coerceIn(0f, 1f),
                    onValueChange = onSetDepthBlur,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet),
                    modifier = Modifier.weight(1f).testTag("scene_depth_blur_slider")
                )
            }
            Spacer(Modifier.height(8.dp))
            val bgStart = scene.backgroundStartFrame.coerceAtLeast(0)
            val bgEnd = if (scene.backgroundEndFrame >= bgStart) scene.backgroundEndFrame else (scene.durationFrames - 1).coerceAtLeast(bgStart)
            FrameRangeControlBar(
                title = "Background Visibility Range",
                accentColor = StudioCyan,
                startFrame = bgStart,
                endFrame = bgEnd,
                currentFrame = uiState.currentFrame,
                onUpdateRange = { s, e -> onUpdateBackgroundRange(s, e) },
                onDelete = if (scene.backgroundStartFrame > 0 || scene.backgroundEndFrame >= 0) {
                    { onUpdateBackgroundRange(0, -1) }
                } else null,
                tagPrefix = "scene_bg_range"
            )
            Spacer(Modifier.height(8.dp))
            Text("Cinematic Color Grading & Lighting Range", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneColorGrade.entries.forEach { grade ->
                    FilterChip(
                        selected = scene.colorGrade == grade.name,
                        onClick = { onSetColorGrade(grade) },
                        label = { Text(grade.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("scene_grade_${grade.name.lowercase()}")
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            val lightStart = scene.lightingStartFrame.coerceAtLeast(0)
            val lightEnd = if (scene.lightingEndFrame >= lightStart) scene.lightingEndFrame else (scene.durationFrames - 1).coerceAtLeast(lightStart)
            FrameRangeControlBar(
                title = "Lighting & Color Grade Range",
                accentColor = StudioAmber,
                startFrame = lightStart,
                endFrame = lightEnd,
                currentFrame = uiState.currentFrame,
                onUpdateRange = { s, e -> onUpdateLightingRange(s, e) },
                onDelete = if (scene.lightingStartFrame > 0 || scene.lightingEndFrame >= 0) {
                    { onUpdateLightingRange(0, -1) }
                } else null,
                tagPrefix = "scene_lighting_range"
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Weather, Sunlight & Cinematic VFX (Frame Range Bounded)",
                style = MaterialTheme.typography.titleSmall,
                color = StudioViolet,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Tap any effect to add or toggle a frame-bounded clip [Start Frame .. End Frame]",
                style = MaterialTheme.typography.labelSmall,
                color = StudioTextSecondary
            )
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneVfxType.entries.forEach { vfx ->
                    val active = vfx.name in scene.activeVfx || scene.screenEffectClips.any { it.effectType == vfx.name }
                    FilterChip(
                        selected = active,
                        onClick = { onToggleVfx(vfx) },
                        label = { Text(vfx.label, style = MaterialTheme.typography.labelSmall) },
                        modifier = Modifier.testTag("scene_vfx_${vfx.name.lowercase()}")
                    )
                }
            }
            if (scene.screenEffectClips.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scene.screenEffectClips.forEach { clip ->
                        val vfxLabel = runCatching { SceneVfxType.valueOf(clip.effectType).label }.getOrDefault(clip.effectType)
                        FrameRangeControlBar(
                            title = "VFX: $vfxLabel",
                            accentColor = StudioViolet,
                            startFrame = clip.startFrame,
                            endFrame = clip.endFrame,
                            currentFrame = uiState.currentFrame,
                            onUpdateRange = { s, e -> onUpdateScreenEffectClipRange(clip.id, s, e) },
                            onDelete = { onRemoveScreenEffectClip(clip.id) },
                            tagPrefix = "vfx_clip_${clip.effectType.lowercase()}"
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Scene Transition", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SceneTransition.entries.forEach { tr ->
                    FilterChip(
                        selected = scene.transition == tr.name,
                        onClick = { onSetTransition(tr) },
                        label = { Text(tr.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Dynamic YouTube Subtitles & Captions Creator
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("YouTube Subtitles & Captions (${scene.subtitles.size})", style = MaterialTheme.typography.titleSmall, color = StudioCoral)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = subtitleSpeaker,
                onValueChange = { subtitleSpeaker = it },
                label = { Text("Speaker (optional, e.g. GHOST)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = subtitleText,
                onValueChange = { subtitleText = it },
                label = { Text("Caption line (e.g. Wait... who's there?!)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("subtitle_text_input")
            )
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SubtitleStyle.entries.forEach { st ->
                    FilterChip(
                        selected = subtitleStyle == st,
                        onClick = {
                            subtitleStyle = st
                            subtitleColorArgb = when (st) {
                                SubtitleStyle.HORROR_DRIP -> 0xFFFF3B5CL
                                SubtitleStyle.YOUTUBE_BOLD -> 0xFFFFE066L
                                SubtitleStyle.COMIC_BOX -> 0xFF38BDF8L
                                SubtitleStyle.CINEMATIC -> 0xFFFFFFFFL
                            }
                        },
                        label = { Text(st.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            ProColorPickerWithSliders(
                label = "Subtitle Text Color",
                selectedColorArgb = subtitleColorArgb,
                onColorChanged = { subtitleColorArgb = it },
                presets = listOf(0xFFFFE066L, 0xFFFFFFFFL, 0xFFFF3B5CL, 0xFF38BDF8L, 0xFF34D399L, 0xFFF97316L),
                accentColor = StudioCoral,
                initiallyExpanded = false,
                testTagPrefix = "scene_subtitle_color"
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Hold ${subtitleDuration}F", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(68.dp))
                Slider(
                    value = subtitleDuration.toFloat(),
                    onValueChange = { subtitleDuration = it.toInt() },
                    valueRange = 12f..120f,
                    modifier = Modifier.weight(1f)
                )
            }
            Button(
                onClick = {
                    onAddSubtitle(subtitleText, subtitleSpeaker, subtitleDuration, subtitleStyle, subtitleColorArgb)
                    subtitleText = ""
                },
                enabled = subtitleText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                modifier = Modifier.fillMaxWidth().testTag("add_subtitle_button")
            ) {
                Text("+ Add Caption at F${uiState.currentFrame + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            if (scene.subtitles.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    scene.subtitles.forEach { cue ->
                        Surface(
                            color = StudioSurfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, StudioBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (cue.speakerName.isNotBlank()) "${cue.speakerName}: ${cue.text}" else cue.text,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = StudioTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "F${cue.startFrame + 1}–F${cue.endFrame + 1} • ${cue.style}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StudioTextMuted
                                    )
                                }
                                IconButton(onClick = { onDeleteSubtitle(cue.id) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete caption", tint = StudioRose, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Cinematic Camera Motion Director
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Videocam, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(18.dp))
                    Text("Camera Motion Director (F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                }
                IconButton(onClick = onResetCamera, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.RestartAlt, contentDescription = "Reset camera", tint = StudioTextSecondary)
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = uiState.showCameraFrame,
                    onClick = onToggleCameraFrame,
                    label = { Text("View Frame", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("camera_toggle_frame_btn")
                )
                FilterChip(
                    selected = uiState.showCameraHud,
                    onClick = onToggleCameraHud,
                    label = { Text("On-Stage HUD", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("camera_toggle_hud_btn")
                )
            }
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onCameraFollowSelected,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber, contentColor = Color.Black),
                    modifier = Modifier.testTag("camera_follow_char_btn")
                ) {
                    Text("Follow Char", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCameraDollyZoom,
                    modifier = Modifier.testTag("camera_dolly_zoom_btn")
                ) {
                    Text("Dolly Zoom", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }
                OutlinedButton(
                    onClick = onCameraPanAcross,
                    modifier = Modifier.testTag("camera_pan_across_btn")
                ) {
                    Text("Pan Across", style = MaterialTheme.typography.labelSmall, color = StudioViolet)
                }
                OutlinedButton(
                    onClick = onCameraShake,
                    modifier = Modifier.testTag("camera_shake_btn")
                ) {
                    Text("Handheld Shake", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                }
            }
            Spacer(Modifier.height(6.dp))
            CameraSlider("Zoom ${String.format("%.2fx", cam.zoom)}", cam.zoom, 0.3f..4.0f) {
                onUpdateCamera(cam.panX, cam.panY, it, cam.rotationDeg)
            }
            CameraSlider("Pan X ${cam.panX.toInt()}", cam.panX, -800f..800f) {
                onUpdateCamera(it, cam.panY, cam.zoom, cam.rotationDeg)
            }
            CameraSlider("Pan Y ${cam.panY.toInt()}", cam.panY, -600f..600f) {
                onUpdateCamera(cam.panX, it, cam.zoom, cam.rotationDeg)
            }
            CameraSlider("Tilt ${cam.rotationDeg.toInt()}°", cam.rotationDeg, -180f..180f) {
                onUpdateCamera(cam.panX, cam.panY, cam.zoom, it)
            }
            if (scene.cameraKeyframes.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Camera Keyframes (${scene.cameraKeyframes.size}) • Ease In-Out",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextMuted
                )
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scene.cameraKeyframes.forEach { kf ->
                        Surface(
                            color = if (kf.frame == uiState.currentFrame) StudioAmber.copy(alpha = 0.22f) else StudioSurfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (kf.frame == uiState.currentFrame) StudioAmber else StudioBorder),
                            modifier = Modifier.clickable { onJumpToFrame(kf.frame) }
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 8.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    "F${kf.frame + 1} (${String.format("%.1fx", kf.zoom)})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioTextPrimary
                                )
                                if (scene.cameraKeyframes.size > 1) {
                                    IconButton(
                                        onClick = { onDeleteCameraKeyframe(kf.frame) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete camera keyframe", tint = StudioRose, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Module 9: Live Camera Auto-Follow Character
            Spacer(Modifier.height(8.dp))
            Text("Live Camera Follow Target", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = scene.cameraFollowLayerId == null,
                    onClick = { onSetCameraFollowLayer(null) },
                    label = { Text("Off", style = MaterialTheme.typography.labelSmall) }
                )
                scene.layers.filter { it.rig != null || it.character != null }.forEach { chLayer ->
                    FilterChip(
                        selected = scene.cameraFollowLayerId == chLayer.id,
                        onClick = { onSetCameraFollowLayer(chLayer.id) },
                        label = { Text(chLayer.name, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Module 9: Directional Spotlight & Channel Brand Watermark / Logo
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Directional Spotlight", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                Switch(
                    checked = scene.spotlightEnabled,
                    onCheckedChange = { onUpdateSpotlight(it, null, null, null, null, null) }
                )
            }
            if (scene.spotlightEnabled) {
                CameraSlider("Spot X ${(scene.spotlightX * 100).toInt()}%", scene.spotlightX, 0f..1f) {
                    onUpdateSpotlight(null, it, null, null, null, null)
                }
                CameraSlider("Spot Y ${(scene.spotlightY * 100).toInt()}%", scene.spotlightY, 0f..1f) {
                    onUpdateSpotlight(null, null, it, null, null, null)
                }
                CameraSlider("Radius ${(scene.spotlightRadius * 100).toInt()}%", scene.spotlightRadius, 0.15f..1f) {
                    onUpdateSpotlight(null, null, null, it, null, null)
                }
                CameraSlider("Power ${(scene.spotlightIntensity * 100).toInt()}%", scene.spotlightIntensity, 0.1f..1f) {
                    onUpdateSpotlight(null, null, null, null, it, null)
                }
                Spacer(Modifier.height(6.dp))
                ProColorPickerWithSliders(
                    label = "Spotlight Tint Color",
                    selectedColorArgb = scene.spotlightColorArgb,
                    onColorChanged = { argb -> onUpdateSpotlight(null, null, null, null, null, argb) },
                    presets = listOf(0xFFFFF3B0L, 0xFFFFFFFFL, 0xFF38BDF8L, 0xFFFF6B35L, 0xFFC084FCL, 0xFF34D399L),
                    accentColor = StudioAmber,
                    initiallyExpanded = false,
                    testTagPrefix = "scene_spotlight_color"
                )
            }

            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Channel Brand Watermark / Logo (Visible on Export)", style = MaterialTheme.typography.titleSmall, color = StudioEmerald)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = scene.watermarkText,
                onValueChange = { onUpdateWatermark(it, null, null, false) },
                label = { Text("Channel Name / @Handle") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("scene_watermark_input")
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onImportWatermarkLogo, modifier = Modifier.weight(1f)) {
                    Text(if (scene.watermarkImagePath.isNullOrBlank()) "+ Logo PNG" else "Replace Logo", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }
                if (scene.watermarkText.isNotBlank() || !scene.watermarkImagePath.isNullOrBlank()) {
                    OutlinedButton(onClick = { onUpdateWatermark(null, null, null, true) }) {
                        Text("Clear", style = MaterialTheme.typography.labelSmall, color = StudioRose)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("TOP_LEFT" to "Top-L", "TOP_RIGHT" to "Top-R", "BOTTOM_LEFT" to "Bot-L", "BOTTOM_RIGHT" to "Bot-R").forEach { (key, lbl) ->
                    FilterChip(
                        selected = scene.watermarkCorner == key,
                        onClick = { onUpdateWatermark(null, null, key, false) },
                        label = { Text(lbl, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            CameraSlider("Opacity ${(scene.watermarkOpacity * 100).toInt()}%", scene.watermarkOpacity, 0.1f..1f) {
                onUpdateWatermark(null, it, null, false)
            }
        }
    }
}

@Composable
private fun CameraSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
            modifier = Modifier.weight(1f)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AudioStudioInspectorPanel(
    uiState: StudioUiState,
    onRequestRecordVoice: () -> Unit,
    onStopVoiceRecording: () -> Unit,
    onImportAudio: () -> Unit,
    onAddBuiltInPreset: (BuiltInAudioPreset) -> Unit,
    onPreviewTrack: (AudioTrackItem) -> Unit,
    onUpdateTrack: (AudioTrackItem) -> Unit,
    onApplyVoiceEffect: (AudioTrackItem, VoiceEffectType) -> Unit,
    onDeleteTrack: (String) -> Unit,
    onToggleAutoDuck: (String) -> Unit = {},
    onSelectAudioClip: (String?) -> Unit = {},
    onSplitAudioClip: (String?) -> Unit = {},
    onCopyAudioClip: (String?) -> Unit = {},
    onPasteAudioClip: () -> Unit = {},
    onSetAudioClipFrameRange: (clipId: String, startFrame: Int, endFrame: Int) -> Unit = { _, _, _ -> },
    onSetAudioClipTrimMs: (clipId: String, trimStartMs: Long?, trimEndMs: Long?) -> Unit = { _, _, _ -> },
    onSetAudioClipFadeMs: (clipId: String, fadeInMs: Long?, fadeOutMs: Long?) -> Unit = { _, _, _ -> },
    onSetAudioClipVolume: (clipId: String, volume: Float) -> Unit = { _, _ -> },
    onSetAudioClipSpeedAndPitch: (clipId: String, speed: Float?, pitch: Float?) -> Unit = { _, _, _ -> },
    onSetAudioClipTrackLane: (clipId: String, trackIndex: Int) -> Unit = { _, _ -> },
    onToggleAudioTrackLaneMute: (trackIndex: Int) -> Unit = {},
    onSetLipSyncSensitivity: (Float) -> Unit = {},
    onSetLipSyncFrequencyRange: (minHz: Int, maxHz: Int) -> Unit = { _, _ -> },
    onApplyLipSyncFrequencyPreset: (String) -> Unit = {}
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return
    val sceneTracks = scene.audioTracks
    val fps = project.fps.coerceAtLeast(1)
    var pendingDeleteTrack by remember { mutableStateOf<AudioTrackItem?>(null) }
    val activeRig = uiState.selectedLayer?.rig ?: scene.layers.firstNotNullOfOrNull { it.rig }
    val evalRoot = remember(activeRig, uiState.currentFrame) {
        activeRig?.let { InterpolationEngine.evaluatePuppetRoot(it, uiState.currentFrame) }
    }
    val lipSyncSens = (evalRoot?.lipSyncSensitivity ?: activeRig?.lipSyncSensitivity ?: 1.0f).coerceIn(0.1f, 3.0f)
    val lipSyncMinHz = (evalRoot?.lipSyncMinFreqHz ?: activeRig?.lipSyncMinFreqHz ?: 250).coerceIn(60, 7800)
    val lipSyncMaxHz = (evalRoot?.lipSyncMaxFreqHz ?: activeRig?.lipSyncMaxFreqHz ?: 3500).coerceIn((lipSyncMinHz + 100).coerceAtLeast(300), 8000)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Upgrade 1: Real-Time Lip-Sync Mouth Sensitivity & 16-Band Frequency Range Filter (Min Hz - Max Hz)
        item {
            Surface(
                color = StudioSurfaceVariant,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth().testTag("audio_lipsync_filter_card")
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Lip-Sync Mouth Sensitivity & Frequency Band Filter",
                        style = MaterialTheme.typography.titleSmall,
                        color = StudioCoral,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "16-Band Spectral Filter (${lipSyncMinHz} Hz – ${lipSyncMaxHz} Hz) • Sensitivity ${(lipSyncSens * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioTextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            Triple("VOICE", "Voice (250–3500 Hz)", lipSyncMinHz == 250 && lipSyncMaxHz == 3500),
                            Triple("ALL", "All Sound (60–8000 Hz)", lipSyncMinHz == 60 && lipSyncMaxHz == 8000),
                            Triple("BASS", "Bass Only (60–300 Hz)", lipSyncMinHz == 60 && lipSyncMaxHz == 300),
                            Triple("HIGH", "High/Treble (3500–8000 Hz)", lipSyncMinHz == 3500 && lipSyncMaxHz == 8000)
                        ).forEach { (presetKey, label, isMatch) ->
                            FilterChip(
                                selected = isMatch,
                                onClick = { onApplyLipSyncFrequencyPreset(presetKey) },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("audio_lipsync_preset_${presetKey.lowercase()}")
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Mouth Sens ${(lipSyncSens * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCoral,
                            modifier = Modifier.width(108.dp)
                        )
                        Slider(
                            value = lipSyncSens,
                            onValueChange = onSetLipSyncSensitivity,
                            valueRange = 0.1f..3.0f,
                            colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                            modifier = Modifier.weight(1f).testTag("audio_lipsync_sensitivity_slider")
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Min Freq ${lipSyncMinHz} Hz",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCyan,
                            modifier = Modifier.width(108.dp)
                        )
                        Slider(
                            value = lipSyncMinHz.toFloat().coerceIn(60f, 4000f),
                            onValueChange = { newMin ->
                                val clampedMin = newMin.toInt().coerceIn(60, 4000)
                                val safeMax = maxOf(lipSyncMaxHz, (clampedMin + 100).coerceAtLeast(300))
                                onSetLipSyncFrequencyRange(clampedMin, safeMax)
                            },
                            valueRange = 60f..4000f,
                            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                            modifier = Modifier.weight(1f).testTag("audio_lipsync_min_hz_slider")
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Max Freq ${lipSyncMaxHz} Hz",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioAmber,
                            modifier = Modifier.width(108.dp)
                        )
                        Slider(
                            value = lipSyncMaxHz.toFloat().coerceIn(300f, 8000f),
                            onValueChange = { newMax ->
                                val clampedMax = newMax.toInt().coerceIn(300, 8000)
                                val safeMin = minOf(lipSyncMinHz, (clampedMax - 100).coerceAtLeast(60))
                                onSetLipSyncFrequencyRange(safeMin, clampedMax)
                            },
                            valueRange = 300f..8000f,
                            colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
                            modifier = Modifier.weight(1f).testTag("audio_lipsync_max_hz_slider")
                        )
                    }
                }
            }
        }

        // Episode-Isolated Audio Studio Banner + 3-Track Lane Mixer Header
        item {
            Surface(
                color = StudioSurfaceVariant,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, StudioEmerald.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth().testTag("episode_audio_mixer_card")
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Episode Audio: ${scene.name} (${sceneTracks.size} clips)",
                                style = MaterialTheme.typography.titleSmall,
                                color = StudioEmerald,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Isolated per scene/episode • 3 Multi-Track Lanes (Voice / SFX / Music)",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextSecondary
                            )
                        }
                        if (uiState.copiedAudioClip != null) {
                            OutlinedButton(
                                onClick = onPasteAudioClip,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp).testTag("audio_paste_clip_top_btn")
                            ) {
                                Icon(Icons.Rounded.ContentPaste, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Paste @ F${uiState.currentFrame + 1}", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                            }
                        }
                    }

                    // 3 Stacked Track Lanes with Per-Lane Mute (🔇) Toggles
                    listOf(
                        Triple(0, "Track 1: Voice", StudioCoral),
                        Triple(1, "Track 2: SFX", StudioCyan),
                        Triple(2, "Track 3: Music", StudioAmber)
                    ).forEach { (laneIdx, laneTitle, laneColor) ->
                        val laneMuted = scene.audioTrackMuted[laneIdx] == true
                        val laneCount = sceneTracks.count { it.trackIndex.coerceIn(0, 2) == laneIdx }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(StudioSurfaceElevated)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = laneTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (laneMuted) StudioTextMuted else laneColor,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "($laneCount clips)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioTextMuted
                                )
                            }
                            FilterChip(
                                selected = laneMuted,
                                onClick = { onToggleAudioTrackLaneMute(laneIdx) },
                                label = {
                                    Text(
                                        if (laneMuted) "🔇 Muted" else "🔊 Active",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.height(26.dp).testTag("audio_lane_mute_$laneIdx")
                            )
                        }
                    }
                }
            }
        }

        // Voice Recording & Import
        item {
            Text("Voice & Audio Import (Added to ${scene.name} at F${uiState.currentFrame + 1})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (uiState.isRecordingVoice) onStopVoiceRecording() else onRequestRecordVoice()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isRecordingVoice) StudioRose else StudioCoral
                    ),
                    modifier = Modifier.weight(1f).testTag("voice_record_button")
                ) {
                    Icon(
                        if (uiState.isRecordingVoice) Icons.Rounded.Stop else Icons.Rounded.Mic,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (uiState.isRecordingVoice) "Stop Rec" else "Record Voice", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onImportAudio,
                    modifier = Modifier.weight(1f).testTag("import_audio_button")
                ) {
                    Icon(Icons.Rounded.AudioFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Import Audio", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (uiState.isRecordingVoice) {
                Spacer(Modifier.height(8.dp))
                Text("Recording live audio...", style = MaterialTheme.typography.labelSmall, color = StudioRose)
                LinearProgressIndicator(
                    progress = { uiState.voiceAmplitude.coerceIn(0.05f, 1f) },
                    color = StudioRose,
                    trackColor = StudioSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                )
            }
        }

        // Built-in Offline SFX & Music Synth
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(16.dp))
                Text("Offline SFX & Music Synth", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            }
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BuiltInAudioPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { onAddBuiltInPreset(preset) },
                        label = { Text(preset.title, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // Episode Audio Clips & Pro Audio Editing Toolbar
        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text(
                "Episode Audio Clips (${sceneTracks.size})",
                style = MaterialTheme.typography.titleSmall,
                color = StudioTextSecondary
            )
        }

        if (sceneTracks.isEmpty()) {
            item {
                Text(
                    "This scene/episode starts with an empty audio timeline. Record your voice, import MP3/WAV/M4A/OGG, or tap any offline SFX/Music preset above to place a clip at F${uiState.currentFrame + 1}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextMuted
                )
            }
        } else {
            items(sceneTracks, key = { it.id }) { track ->
                val isSelected = uiState.selectedAudioTrackId == track.id
                val isClipMuted = track.isMuted || track.muted
                val isClipLooping = track.isLooping || track.loopClip
                val srcDurMs = maxOf(track.sourceDurationMs, track.durationMs, 250L)
                val effectiveTrimEnd = if (track.trimEndMs > track.trimStartMs) track.trimEndMs else srcDurMs
                val speedSafe = track.speed.coerceIn(0.5f, 2.0f)
                val naturalFrames = (((effectiveTrimEnd - track.trimStartMs).coerceAtLeast(80L) / speedSafe) / 1000f * fps).toInt().coerceAtLeast(1)
                val resolvedEndFrame = if (track.endFrame >= track.startFrame) track.endFrame else (track.startFrame + naturalFrames - 1).coerceAtLeast(track.startFrame)
                val laneIdx = track.trackIndex.coerceIn(0, 2)
                val laneAccent = when (laneIdx) {
                    0 -> StudioCoral
                    1 -> StudioCyan
                    else -> StudioAmber
                }

                Surface(
                    color = if (isSelected) StudioSurfaceElevated else StudioSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) laneAccent else StudioBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectAudioClip(track.id) }
                        .testTag("audio_clip_card_${track.id}")
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(track.name, style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "F${track.startFrame + 1}..F${resolvedEndFrame + 1} • ${(effectiveTrimEnd - track.trimStartMs).coerceAtLeast(80L)}ms • ${String.format("%.2fx", track.speed)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = laneAccent
                                )
                            }
                            IconButton(onClick = { onPreviewTrack(track) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Preview track", tint = StudioEmerald)
                            }
                            IconButton(
                                onClick = {
                                    val nextMute = !isClipMuted
                                    onUpdateTrack(track.copy(muted = nextMute, isMuted = nextMute))
                                },
                                modifier = Modifier.size(32.dp).testTag("audio_mute_btn_${track.id}")
                            ) {
                                Icon(
                                    if (isClipMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                                    contentDescription = "Mute toggle",
                                    tint = if (isClipMuted) StudioTextMuted else StudioCyan
                                )
                            }
                            IconButton(
                                onClick = { pendingDeleteTrack = track },
                                modifier = Modifier.size(32.dp).testTag("delete_audio_${track.id}")
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete track", tint = StudioRose)
                            }
                        }

                        // Track Lane Assignment Chips (Track 1: Voice, Track 2: SFX, Track 3: Music)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            listOf(
                                0 to "Track 1: Voice",
                                1 to "Track 2: SFX",
                                2 to "Track 3: Music"
                            ).forEach { (idx, label) ->
                                FilterChip(
                                    selected = laneIdx == idx,
                                    onClick = { onSetAudioClipTrackLane(track.id, idx) },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.height(26.dp).testTag("audio_clip_${track.id}_lane_$idx")
                                )
                            }
                        }

                        // Quick Edit Action Row: Split / Cut (✂️), Copy, Paste, Loop (🔁 ON/OFF)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    onSelectAudioClip(track.id)
                                    onSplitAudioClip(track.id)
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(28.dp).testTag("audio_split_btn_${track.id}")
                            ) {
                                Icon(Icons.Rounded.ContentCut, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("Split ✂️", style = MaterialTheme.typography.labelSmall, color = StudioAmber)
                            }
                            OutlinedButton(
                                onClick = { onCopyAudioClip(track.id) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(28.dp).testTag("audio_copy_btn_${track.id}")
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("Copy", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                            }
                            OutlinedButton(
                                onClick = onPasteAudioClip,
                                enabled = uiState.copiedAudioClip != null,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f).height(28.dp).testTag("audio_paste_btn_${track.id}")
                            ) {
                                Icon(Icons.Rounded.ContentPaste, contentDescription = null, tint = StudioEmerald, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("Paste", style = MaterialTheme.typography.labelSmall, color = StudioEmerald)
                            }
                            FilterChip(
                                selected = isClipLooping,
                                onClick = {
                                    val nextLoop = !isClipLooping
                                    onUpdateTrack(track.copy(loopClip = nextLoop, isLooping = nextLoop))
                                },
                                label = { Text(if (isClipLooping) "🔁 Loop ON" else "🔁 Loop OFF", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.height(28.dp).testTag("audio_loop_toggle_${track.id}")
                            )
                        }

                        // Mini Waveform Bar Strip with Fade In / Fade Out Visual Envelope
                        if (track.waveformPeaks.isNotEmpty()) {
                            val peaksToShow = track.waveformPeaks.take(36)
                            val totalClipMs = (effectiveTrimEnd - track.trimStartMs).coerceAtLeast(100L).toFloat()
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0D1117))
                                    .padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                peaksToShow.forEachIndexed { i, peak ->
                                    val frac = i.toFloat() / peaksToShow.size.coerceAtLeast(1)
                                    val posMs = frac * totalClipMs
                                    val fadeInEnv = if (track.fadeInMs > 0L) (posMs / track.fadeInMs.toFloat()).coerceIn(0.15f, 1f) else 1f
                                    val remMs = (totalClipMs - posMs).coerceAtLeast(0f)
                                    val fadeOutEnv = if (track.fadeOutMs > 0L) (remMs / track.fadeOutMs.toFloat()).coerceIn(0.15f, 1f) else 1f
                                    val envPeak = (peak * fadeInEnv * fadeOutEnv * track.volume.coerceIn(0.2f, 1.5f)).coerceIn(0.08f, 1f)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height((envPeak * 23f).coerceIn(3f, 23f).dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(if (isClipMuted) StudioTextMuted else laneAccent)
                                    )
                                }
                            }
                        }

                        // Universal Start Frame & End Frame Range Control Bar (-, [Here], +)
                        FrameRangeControlBar(
                            title = "Clip Range (F${track.startFrame + 1}..F${resolvedEndFrame + 1})",
                            accentColor = laneAccent,
                            startFrame = track.startFrame,
                            endFrame = resolvedEndFrame,
                            currentFrame = uiState.currentFrame,
                            onUpdateRange = { s, e -> onSetAudioClipFrameRange(track.id, s, e) },
                            onDelete = null,
                            tagPrefix = "audio_range_${track.id}"
                        )

                        // Volume (0% - 150%)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vol ${(track.volume * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioEmerald, modifier = Modifier.width(76.dp))
                            Slider(
                                value = track.volume.coerceIn(0f, 1.5f),
                                onValueChange = { onSetAudioClipVolume(track.id, it) },
                                valueRange = 0f..1.5f,
                                colors = SliderDefaults.colors(thumbColor = StudioEmerald, activeTrackColor = StudioEmerald),
                                modifier = Modifier.weight(1f).testTag("audio_vol_slider_${track.id}")
                            )
                        }

                        // Trim Start & Trim End (non-destructive source audio trim)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Trim In ${String.format("%.1fs", track.trimStartMs / 1000f)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(76.dp))
                            Slider(
                                value = track.trimStartMs.toFloat().coerceIn(0f, (effectiveTrimEnd - 80L).coerceAtLeast(0L).toFloat()),
                                onValueChange = { onSetAudioClipTrimMs(track.id, it.toLong(), null) },
                                valueRange = 0f..(srcDurMs - 80L).coerceAtLeast(100L).toFloat(),
                                modifier = Modifier.weight(1f).testTag("audio_trim_in_slider_${track.id}")
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Trim Out ${String.format("%.1fs", effectiveTrimEnd / 1000f)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(76.dp))
                            Slider(
                                value = effectiveTrimEnd.toFloat().coerceIn((track.trimStartMs + 80L).toFloat(), srcDurMs.toFloat().coerceAtLeast(250f)),
                                onValueChange = { onSetAudioClipTrimMs(track.id, null, it.toLong()) },
                                valueRange = 80f..srcDurMs.toFloat().coerceAtLeast(250f),
                                modifier = Modifier.weight(1f).testTag("audio_trim_out_slider_${track.id}")
                            )
                        }

                        // Fade In & Fade Out Sliders (0s - 3s)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Fade In ${String.format("%.1fs", track.fadeInMs / 1000f)}", style = MaterialTheme.typography.labelSmall, color = StudioCyan, modifier = Modifier.width(76.dp))
                            Slider(
                                value = track.fadeInMs.toFloat().coerceIn(0f, 3000f),
                                onValueChange = { onSetAudioClipFadeMs(track.id, it.toLong(), null) },
                                valueRange = 0f..3000f,
                                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                                modifier = Modifier.weight(1f).testTag("audio_fade_in_slider_${track.id}")
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Fade Out ${String.format("%.1fs", track.fadeOutMs / 1000f)}", style = MaterialTheme.typography.labelSmall, color = StudioCyan, modifier = Modifier.width(76.dp))
                            Slider(
                                value = track.fadeOutMs.toFloat().coerceIn(0f, 3000f),
                                onValueChange = { onSetAudioClipFadeMs(track.id, null, it.toLong()) },
                                valueRange = 0f..3000f,
                                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                                modifier = Modifier.weight(1f).testTag("audio_fade_out_slider_${track.id}")
                            )
                        }

                        // Speed (0.5x - 2.0x) & Pitch (0.5x - 2.0x)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Speed ${String.format("%.2fx", track.speed)}", style = MaterialTheme.typography.labelSmall, color = StudioAmber, modifier = Modifier.width(76.dp))
                            Slider(
                                value = track.speed.coerceIn(0.5f, 2.0f),
                                onValueChange = { onSetAudioClipSpeedAndPitch(track.id, it, null) },
                                valueRange = 0.5f..2.0f,
                                colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
                                modifier = Modifier.weight(1f).testTag("audio_speed_slider_${track.id}")
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Pitch ${String.format("%.2fx", track.pitch)}", style = MaterialTheme.typography.labelSmall, color = StudioViolet, modifier = Modifier.width(76.dp))
                            Slider(
                                value = track.pitch.coerceIn(0.5f, 2.0f),
                                onValueChange = { onSetAudioClipSpeedAndPitch(track.id, null, it) },
                                valueRange = 0.5f..2.0f,
                                colors = SliderDefaults.colors(thumbColor = StudioViolet, activeTrackColor = StudioViolet),
                                modifier = Modifier.weight(1f).testTag("audio_pitch_slider_${track.id}")
                            )
                        }

                        // Module 8: Auto-Duck Music toggle (automatically lowers BGM to 28% during voice dialogue!)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Auto-Duck Music under Voice", style = MaterialTheme.typography.labelSmall, color = StudioAmber)
                            Switch(
                                checked = track.autoDuckMusic,
                                onCheckedChange = { onToggleAutoDuck(track.id) }
                            )
                        }

                        // Offline Voice Changer FX (Cartoon Kid, Deep Monster, Ghost Echo, Robot)
                        Text("Voice Changer FX", style = MaterialTheme.typography.labelSmall, color = StudioViolet)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            VoiceEffectType.entries.forEach { fx ->
                                FilterChip(
                                    selected = track.voiceEffect == fx.name,
                                    onClick = { onApplyVoiceEffect(track, fx) },
                                    label = { Text(fx.label, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("voice_fx_${fx.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDeleteTrack?.let { track ->
        AlertDialog(
            onDismissRequest = { pendingDeleteTrack = null },
            containerColor = StudioSurfaceElevated,
            title = { Text("Delete Audio Track?", color = StudioTextPrimary) },
            text = { Text("Remove \"${track.name}\" from ${scene.name}?", color = StudioTextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteTrack(track.id)
                        pendingDeleteTrack = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRose)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteTrack = null }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}
