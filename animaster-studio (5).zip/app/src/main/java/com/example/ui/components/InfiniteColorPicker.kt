package com.example.ui.components

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

/**
 * Infinite Color Picker with interactive HSV (Rainbow Hue, Saturation, Brightness)
 * and RGB (Red, Green, Blue) gradient sliders + live swatch preview & #RRGGBB readout.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InfiniteColorPicker(
    selectedColorArgb: Long,
    onColorChanged: (Long) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "Infinite Color",
    compact: Boolean = false,
    accentColor: Color = StudioCoral,
    showQuickSwatches: Boolean = true,
    quickSwatches: List<Long> = StudioColorSwatches,
    testTagPrefix: String = "infinite_color"
) {
    val initialHsv = remember(selectedColorArgb) {
        FloatArray(3).also { AndroidColor.colorToHSV(selectedColorArgb.toInt(), it) }
    }
    var hue by remember { mutableFloatStateOf(initialHsv[0]) }
    var sat by remember { mutableFloatStateOf(initialHsv[1]) }
    var value by remember { mutableFloatStateOf(initialHsv[2]) }
    var useRgbMode by remember { mutableStateOf(false) }

    // Sync local HSV when external color changes (e.g. swatch tap or eyedropper),
    // while preserving user's chosen Hue when Saturation or Brightness hits 0.
    LaunchedEffect(selectedColorArgb) {
        val currentComputed = hsvToOpaqueArgb(hue, sat, value)
        if ((currentComputed and 0x00FFFFFFL) != (selectedColorArgb and 0x00FFFFFFL)) {
            val hsv = FloatArray(3)
            AndroidColor.colorToHSV(selectedColorArgb.toInt(), hsv)
            if (hsv[1] > 0.01f && hsv[2] > 0.01f) {
                hue = hsv[0]
            }
            sat = hsv[1]
            value = hsv[2]
        }
    }

    val colorInt = selectedColorArgb.toInt()
    val r = AndroidColor.red(colorInt)
    val g = AndroidColor.green(colorInt)
    val b = AndroidColor.blue(colorInt)
    val hexText = remember(selectedColorArgb) {
        String.format("#%06X", (selectedColorArgb.toInt() and 0xFFFFFF))
    }

    val pureHueColor = remember(hue) { Color(hsvToOpaqueArgb(hue, 1f, 1f).toInt()) }
    val desaturatedAtValue = remember(value) { Color(hsvToOpaqueArgb(hue, 0f, value).toInt()) }
    val saturatedAtValue = remember(hue, value) { Color(hsvToOpaqueArgb(hue, 1f, value).toInt()) }
    val brightAtSat = remember(hue, sat) { Color(hsvToOpaqueArgb(hue, sat, 1f).toInt()) }

    val rainbowColors = remember {
        listOf(
            Color(0xFFFF0000),
            Color(0xFFFFFF00),
            Color(0xFF00FF00),
            Color(0xFF00FFFF),
            Color(0xFF0000FF),
            Color(0xFFFF00FF),
            Color(0xFFFF0000)
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("${testTagPrefix}_picker"),
        verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp)
    ) {
        // Header row: Preview Swatch + Label + Hex + HSV/RGB mode toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(if (compact) 24.dp else 30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(colorInt))
                        .border(1.5.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                        .testTag("${testTagPrefix}_preview")
                )
                Column {
                    Text(
                        text = label,
                        style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelMedium,
                        color = StudioTextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = hexText,
                        fontSize = if (compact) 9.sp else 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = StudioTextSecondary
                    )
                }
            }

            // Compact HSV / RGB pill switcher
            Surface(
                color = StudioSurfaceVariant,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, StudioBorder)
            ) {
                Row(modifier = Modifier.padding(2.dp)) {
                    listOf(false to "HSV", true to "RGB").forEach { (rgb, title) ->
                        val active = useRgbMode == rgb
                        Surface(
                            color = if (active) accentColor else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { useRgbMode = rgb }
                                .testTag("${testTagPrefix}_mode_${title.lowercase()}")
                        ) {
                            Text(
                                text = title,
                                fontSize = if (compact) 9.sp else 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (active) Color(0xFF0F172A) else StudioTextSecondary,
                                modifier = Modifier.padding(
                                    horizontal = if (compact) 7.dp else 9.dp,
                                    vertical = 3.dp
                                )
                            )
                        }
                    }
                }
            }
        }

        if (!useRgbMode) {
            // 1. Infinite Rainbow Hue Slider (0° - 360°)
            GradientColorBarSlider(
                label = "H",
                valueText = "${hue.toInt()}°",
                fraction = (hue / 360f).coerceIn(0f, 1f),
                gradientColors = rainbowColors,
                thumbColor = pureHueColor,
                compact = compact,
                onFractionChange = { f ->
                    hue = (f * 360f).coerceIn(0f, 360f)
                    onColorChanged(hsvToOpaqueArgb(hue, sat, value))
                },
                modifier = Modifier.testTag("${testTagPrefix}_hue_slider")
            )

            // 2. Saturation Slider (0% - 100%)
            GradientColorBarSlider(
                label = "S",
                valueText = "${(sat * 100).toInt()}%",
                fraction = sat.coerceIn(0f, 1f),
                gradientColors = listOf(desaturatedAtValue, saturatedAtValue),
                thumbColor = Color(colorInt),
                compact = compact,
                onFractionChange = { f ->
                    sat = f.coerceIn(0f, 1f)
                    onColorChanged(hsvToOpaqueArgb(hue, sat, value))
                },
                modifier = Modifier.testTag("${testTagPrefix}_sat_slider")
            )

            // 3. Brightness / Value Slider (0% - 100%)
            GradientColorBarSlider(
                label = "B",
                valueText = "${(value * 100).toInt()}%",
                fraction = value.coerceIn(0f, 1f),
                gradientColors = listOf(Color.Black, brightAtSat),
                thumbColor = Color(colorInt),
                compact = compact,
                onFractionChange = { f ->
                    value = f.coerceIn(0f, 1f)
                    onColorChanged(hsvToOpaqueArgb(hue, sat, value))
                },
                modifier = Modifier.testTag("${testTagPrefix}_val_slider")
            )
        } else {
            // RGB Channel Sliders (0 - 255 each -> 16.7M exact colors)
            GradientColorBarSlider(
                label = "R",
                valueText = "$r",
                fraction = r / 255f,
                gradientColors = listOf(Color(0, g, b), Color(255, g, b)),
                thumbColor = Color(r, g, b),
                compact = compact,
                onFractionChange = { f ->
                    val nr = (f * 255f).toInt().coerceIn(0, 255)
                    onColorChanged(rgbToOpaqueArgb(nr, g, b))
                },
                modifier = Modifier.testTag("${testTagPrefix}_r_slider")
            )
            GradientColorBarSlider(
                label = "G",
                valueText = "$g",
                fraction = g / 255f,
                gradientColors = listOf(Color(r, 0, b), Color(r, 255, b)),
                thumbColor = Color(r, g, b),
                compact = compact,
                onFractionChange = { f ->
                    val ng = (f * 255f).toInt().coerceIn(0, 255)
                    onColorChanged(rgbToOpaqueArgb(r, ng, b))
                },
                modifier = Modifier.testTag("${testTagPrefix}_g_slider")
            )
            GradientColorBarSlider(
                label = "B",
                valueText = "$b",
                fraction = b / 255f,
                gradientColors = listOf(Color(r, g, 0), Color(r, g, 255)),
                thumbColor = Color(r, g, b),
                compact = compact,
                onFractionChange = { f ->
                    val nb = (f * 255f).toInt().coerceIn(0, 255)
                    onColorChanged(rgbToOpaqueArgb(r, g, nb))
                },
                modifier = Modifier.testTag("${testTagPrefix}_b_slider")
            )
        }

        // Optional Quick Swatches row for 1-tap favorites
        if (showQuickSwatches && quickSwatches.isNotEmpty()) {
            Spacer(Modifier.height(2.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 7.dp),
                verticalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 7.dp)
            ) {
                quickSwatches.forEach { argb ->
                    val isSel = (selectedColorArgb and 0x00FFFFFFL) == (argb and 0x00FFFFFFL)
                    Box(
                        modifier = Modifier
                            .size(if (compact) 21.dp else 26.dp)
                            .clip(CircleShape)
                            .background(Color(argb.toInt()))
                            .border(
                                width = if (isSel) 2.5.dp else 1.dp,
                                color = if (isSel) Color.White else StudioBorder,
                                shape = CircleShape
                            )
                            .clickable { onColorChanged(argb) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GradientColorBarSlider(
    label: String,
    valueText: String,
    fraction: Float,
    gradientColors: List<Color>,
    thumbColor: Color,
    compact: Boolean,
    onFractionChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val latestOnChange by rememberUpdatedState(onFractionChange)
    val trackHeight = if (compact) 22.dp else 26.dp

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            fontSize = if (compact) 10.sp else 11.sp,
            fontWeight = FontWeight.Bold,
            color = StudioCyan,
            modifier = Modifier.width(14.dp)
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .height(trackHeight)
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val w = size.width.toFloat().coerceAtLeast(1f)
                        latestOnChange((offset.x / w).coerceIn(0f, 1f))
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        val w = size.width.toFloat().coerceAtLeast(1f)
                        latestOnChange((change.position.x / w).coerceIn(0f, 1f))
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(trackHeight)
            ) {
                val barH = if (compact) 12.dp.toPx() else 14.dp.toPx()
                val topY = (size.height - barH) / 2f
                val corner = barH / 2f

                drawRoundRect(
                    brush = Brush.horizontalGradient(gradientColors),
                    topLeft = Offset(0f, topY),
                    size = Size(size.width, barH),
                    cornerRadius = CornerRadius(corner, corner)
                )
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.25f),
                    topLeft = Offset(0f, topY),
                    size = Size(size.width, barH),
                    cornerRadius = CornerRadius(corner, corner),
                    style = Stroke(width = 1.dp.toPx())
                )

                val thumbR = if (compact) 8.5.dp.toPx() else 10.dp.toPx()
                val thumbX = (fraction.coerceIn(0f, 1f) * size.width).coerceIn(thumbR, size.width - thumbR)
                val thumbCenter = Offset(thumbX, size.height / 2f)

                // Dark shadow ring for contrast on bright colors
                drawCircle(
                    color = Color.Black.copy(alpha = 0.45f),
                    radius = thumbR + 1.5.dp.toPx(),
                    center = thumbCenter
                )
                drawCircle(
                    color = thumbColor,
                    radius = thumbR,
                    center = thumbCenter
                )
                drawCircle(
                    color = Color.White,
                    radius = thumbR,
                    center = thumbCenter,
                    style = Stroke(width = 2.2.dp.toPx())
                )
            }
        }

        Text(
            text = valueText,
            fontSize = if (compact) 9.sp else 10.sp,
            fontFamily = FontFamily.Monospace,
            color = StudioTextSecondary,
            modifier = Modifier.width(if (compact) 28.dp else 34.dp)
        )
    }
}

private fun hsvToOpaqueArgb(hue: Float, sat: Float, value: Float): Long {
    val c = AndroidColor.HSVToColor(floatArrayOf(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f)))
    return (c.toLong() and 0x00FFFFFFL) or 0xFF000000L
}

private fun rgbToOpaqueArgb(r: Int, g: Int, b: Int): Long {
    val c = AndroidColor.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
    return (c.toLong() and 0x00FFFFFFL) or 0xFF000000L
}

/**
 * Universal Pro Color Picker with Quick Preset Swatches + Smooth Hue (0°–360°),
 * Saturation (0%–100%), and Brightness (0%–100%) sliders + Live Preview & Hex readout.
 * Designed to replace every swatch-only color picker across Animaster Studio.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProColorPickerWithSliders(
    label: String,
    selectedColorArgb: Long,
    onColorChanged: (Long) -> Unit,
    modifier: Modifier = Modifier,
    presets: List<Long> = StudioColorSwatches,
    accentColor: Color = StudioCoral,
    compact: Boolean = true,
    initiallyExpanded: Boolean = true,
    testTagPrefix: String = "pro_color"
) {
    var slidersExpanded by remember { mutableStateOf(initiallyExpanded) }
    val hexText = remember(selectedColorArgb) {
        String.format("#%06X", (selectedColorArgb.toInt() and 0xFFFFFF))
    }

    Surface(
        color = StudioSurfaceVariant.copy(alpha = 0.65f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, StudioBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("${testTagPrefix}_container")
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(selectedColorArgb.toInt()))
                            .border(1.5.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                            .testTag("${testTagPrefix}_swatch_preview")
                    )
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = hexText,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = StudioTextSecondary
                    )
                }

                Surface(
                    color = if (slidersExpanded) accentColor.copy(alpha = 0.22f) else StudioSurfaceVariant,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (slidersExpanded) accentColor else StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { slidersExpanded = !slidersExpanded }
                        .testTag("${testTagPrefix}_toggle_sliders")
                ) {
                    Text(
                        text = if (slidersExpanded) "H/S/B ▲" else "H/S/B ▼",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (slidersExpanded) accentColor else StudioTextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            if (presets.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presets.forEach { argb ->
                        val isSel = (selectedColorArgb and 0x00FFFFFFL) == (argb and 0x00FFFFFFL)
                        Box(
                            modifier = Modifier
                                .size(if (compact) 22.dp else 26.dp)
                                .clip(CircleShape)
                                .background(Color(argb.toInt()))
                                .border(
                                    width = if (isSel) 2.5.dp else 1.dp,
                                    color = if (isSel) Color.White else StudioBorder,
                                    shape = CircleShape
                                )
                                .clickable { onColorChanged(argb) }
                        )
                    }
                }
            }

            if (slidersExpanded) {
                InfiniteColorPicker(
                    selectedColorArgb = selectedColorArgb,
                    onColorChanged = onColorChanged,
                    label = "$label Sliders",
                    compact = compact,
                    accentColor = accentColor,
                    showQuickSwatches = false,
                    testTagPrefix = testTagPrefix
                )
            }
        }
    }
}

