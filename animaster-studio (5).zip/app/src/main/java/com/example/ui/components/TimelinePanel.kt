package com.example.ui.components

import java.util.Locale

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CallSplit
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.FirstPage
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LastPage
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClipAnimationPreset
import com.example.data.model.CustomActionClip
import com.example.data.model.LayerType
import com.example.data.model.SkeletalRig
import com.example.data.model.TargetedLoopType
import com.example.engine.InterpolationEngine
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioBorderSubtle
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.TrackSelectionKind

/**
 * Pure Frame-by-Frame Keyframe Timeline supporting 1 to 2,000+ frames smoothly
 * with explicit keyframe, frame copy/paste, and keyframed character swap controls.
 */
@Composable
fun TimelinePanel(
    uiState: StudioUiState,
    onTogglePlay: () -> Unit,
    onStepFrame: (Int) -> Unit,
    onSelectFrame: (Int) -> Unit,
    onAddFrames: (Int) -> Unit,
    onSelectLayer: (String) -> Unit,
    onSelectTrackTarget: (TrackSelectionKind, String) -> Unit,
    onToggleTrackTools: () -> Unit,
    onCutTrack: () -> Unit,
    onMidCutTrack: () -> Unit,
    onDuplicateTrack: () -> Unit,
    onDeleteTrack: () -> Unit,
    onRemixTrack: () -> Unit,
    onMoveTrackOrder: (Boolean) -> Unit,
    onToggleTrackVisibility: () -> Unit,
    onMoveLayerOrder: (String, Boolean) -> Unit,
    onToggleLayerVisibility: (String) -> Unit,
    onToggleLayerLock: (String) -> Unit = {},
    onToggleTextVisibility: (String) -> Unit,
    onToggleAudioMute: (String) -> Unit,
    onSetFps: (Int) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleOnionSkin: () -> Unit,
    onToggleGhostFrames: () -> Unit,
    onAddBlankCel: () -> Unit,
    onDuplicateCel: () -> Unit,
    onInsertKeyframe: () -> Unit,
    onDeleteKeyframe: () -> Unit = {},
    onCopyFrame: () -> Unit = {},
    onPasteFrame: () -> Unit = {},
    onOpenSwapChar: () -> Unit = {},
    onSetTimelineRange: (Int, Int) -> Unit = { _, _ -> },
    onTogglePlayRange: () -> Unit = {},
    onHideFromHere: () -> Unit = {},
    onShowFromHere: () -> Unit = {},
    onSetVisibleRange: (Int, Int) -> Unit = { _, _ -> },
    onClearVisibilityRanges: () -> Unit = {},
    onApplyTargetedLoop: (TargetedLoopType, Int, Int) -> Unit = { _, _, _ -> },
    onSaveCustomAction: (String) -> Unit = {},
    onSaveCustomActionWithOptions: (String, Boolean) -> Unit = { name, _ -> onSaveCustomAction(name) },
    customActions: List<CustomActionClip> = emptyList(),
    onApplyCustomAction: (CustomActionClip) -> Unit = {},
    onStepSelectedBoneZOrder: (bringForward: Boolean) -> Unit = {},
    onBatchShiftColorRange: (Int, Int, Float) -> Unit = { _, _, _ -> },
    onCopyFrameRange: (Int, Int) -> Unit = { _, _ -> },
    onPasteAutoLoopFillRange: (Int, Int) -> Unit = { _, _ -> },
    onSaveAnimatedFxClip: (String, Int, Int) -> Unit = { _, _, _ -> },
    myCharacters: List<SkeletalRig> = emptyList(),
    onUndo: () -> Unit = {},
    onRedo: () -> Unit = {},
    onCopyClip: () -> Unit = {},
    onPasteClip: () -> Unit = {},
    onTrimLayerBounds: (String, Int, Int) -> Unit = { _, _, _ -> },
    onMoveLayerClip: (String, Int) -> Unit = { _, _ -> },
    onMoveLayerClip2D: (String, Int, Int, Boolean) -> Unit = { id, ns, _, _ -> onMoveLayerClip(id, ns) },
    onReplaceLayerCharacter: (String, SkeletalRig) -> Unit = { _, _ -> },
    onUpdateLayerAnimations: (String, ClipAnimationPreset, ClipAnimationPreset, ClipAnimationPreset, Int) -> Unit = { _, _, _, _, _ -> },
    onAddExtraTrack: (String, LayerType, Int, ClipAnimationPreset, ClipAnimationPreset, ClipAnimationPreset) -> Unit = { _, _, _, _, _, _ -> },
    onTrimAudioBounds: (String, Int, Int) -> Unit = { _, _, _ -> },
    onMoveAudioTrack: (String, Int) -> Unit = { _, _ -> },
    onToggleAudioLoop: (String) -> Unit = {},
    onToggleAudioTrackLaneMute: (Int) -> Unit = {},
    onSplitAudioClip: (String?) -> Unit = {},
    onCopyAudioClip: (String?) -> Unit = {},
    onPasteAudioClip: () -> Unit = {},
    compactMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return

    val totalFrames = scene.durationFrames.coerceAtLeast(1)
    val lazyFrameState = rememberLazyListState()
    val verticalTrackScroll = rememberScrollState()

    var fpsMenuExpanded by remember { mutableStateOf(false) }
    var addFramesMenuExpanded by remember { mutableStateOf(false) }
    var loopMenuExpanded by remember { mutableStateOf(false) }
    var showSaveActionDialog by remember { mutableStateOf(false) }
    var customActionName by remember { mutableStateOf("My Action") }
    var includeRootInAction by remember { mutableStateOf(true) }
    var showApplyActionDialog by remember { mutableStateOf(false) }
    var showRangeNumbersDialog by remember { mutableStateOf(false) }
    var rangeStartInput by remember { mutableStateOf((uiState.rangeStartFrame + 1).toString()) }
    var rangeEndInput by remember { mutableStateOf((uiState.rangeEndFrame + 1).toString()) }
    var showSaveFxClipDialog by remember { mutableStateOf(false) }
    var fxClipName by remember { mutableStateOf("FX Loop") }
    var showJumpDialog by remember { mutableStateOf(false) }
    var jumpInput by remember { mutableStateOf((uiState.currentFrame + 1).toString()) }
    var tracksExpanded by remember { mutableStateOf(true) }

    val sceneAudioTracks = scene.audioTracks

    val activeTargetHidden = remember(
        uiState.selectedTrackKind,
        uiState.selectedLayer,
        uiState.selectedText,
        uiState.selectedAudioTrackId,
        sceneAudioTracks
    ) {
        when (uiState.selectedTrackKind) {
            TrackSelectionKind.LAYER -> uiState.selectedLayer?.visible == false
            TrackSelectionKind.TEXT -> uiState.selectedText?.visible == false
            TrackSelectionKind.AUDIO -> {
                val tr = sceneAudioTracks.firstOrNull { it.id == uiState.selectedAudioTrackId }
                    ?: sceneAudioTracks.firstOrNull()
                tr?.muted == true || tr?.isMuted == true
            }
        }
    }

    val activeTargetLabel = remember(
        uiState.selectedTrackKind,
        uiState.selectedLayer,
        uiState.selectedText,
        uiState.selectedAudioTrackId,
        sceneAudioTracks
    ) {
        when (uiState.selectedTrackKind) {
            TrackSelectionKind.LAYER -> "Layer: ${uiState.selectedLayer?.name ?: "None"}"
            TrackSelectionKind.TEXT -> "Text: ${uiState.selectedText?.text?.take(12) ?: "None"}"
            TrackSelectionKind.AUDIO -> {
                val tr = sceneAudioTracks.firstOrNull { it.id == uiState.selectedAudioTrackId }
                    ?: sceneAudioTracks.firstOrNull()
                "Audio: ${tr?.name?.take(12) ?: "None"}"
            }
        }
    }

    // Keep playhead visible automatically when scrubbing, jumping, or playing across 1,000+ frames
    LaunchedEffect(uiState.currentFrame) {
        val visibleItems = lazyFrameState.layoutInfo.visibleItemsInfo
        if (visibleItems.isNotEmpty()) {
            val firstIdx = visibleItems.first().index
            val lastIdx = visibleItems.last().index
            if (uiState.currentFrame < firstIdx || uiState.currentFrame > lastIdx - 1) {
                lazyFrameState.scrollToItem((uiState.currentFrame - 3).coerceAtLeast(0))
            }
        }
    }

    val reversedLayers = remember(scene.layers) { scene.layers.reversed() }
    val layerZOrderKeyframesMap = remember(scene.layers) {
        scene.layers.associate { layer ->
            val boneZSet = layer.rig?.boneZOrderKeyframes?.keys?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            val partZSet = layer.rig?.rootKeyframes?.filter { it.partZOrder.isNotEmpty() }?.map { it.frame }?.toSet() ?: emptySet()
            layer.id to (boneZSet + partZSet)
        }
    }
    val layerSwapKeyframesMap = remember(scene.layers) {
        scene.layers.associate { layer ->
            layer.id to layer.characterSwapKeyframes.keys
        }
    }
    val layerKeyframesMap = remember(scene.layers) {
        scene.layers.associate { layer ->
            val tfSet = layer.keyframes.map { it.frame }.toSet()
            val rigPoseSet = layer.rig?.poseKeyframes?.keys?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            val rigRootSet = layer.rig?.rootKeyframes?.map { it.frame }?.toSet() ?: emptySet()
            val rigZSet = layer.rig?.boneZOrderKeyframes?.keys?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            val swapSet = layer.characterSwapKeyframes.keys
            layer.id to (tfSet + rigPoseSet + rigRootSet + rigZSet + swapSet)
        }
    }
    val cameraKeySet = remember(scene.cameraKeyframes) { scene.cameraKeyframes.map { it.frame }.toSet() }

    val seconds = uiState.currentFrame.toFloat() / project.fps.coerceAtLeast(1).toFloat()
    val timecode = String.format(Locale.US, "F%d/%d • %04.1fs", uiState.currentFrame + 1, totalFrames, seconds)

    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 1. Transport, Unlimited "+ Add Frames", Jump & Keyframe Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StudioSurfaceVariant)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Undo / Redo quick controls right on the Frame-by-Frame timeline bar
                IconButton(
                    onClick = onUndo,
                    enabled = uiState.canUndo,
                    modifier = Modifier.size(34.dp).testTag("timeline_undo_btn")
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.Undo,
                        contentDescription = "Undo",
                        tint = if (uiState.canUndo) StudioTextPrimary else StudioTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onRedo,
                    enabled = uiState.canRedo,
                    modifier = Modifier.size(34.dp).testTag("timeline_redo_btn")
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.Redo,
                        contentDescription = "Redo",
                        tint = if (uiState.canRedo) StudioTextPrimary else StudioTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
                // First Frame & -10 Jump
                IconButton(
                    onClick = { onSelectFrame(0) },
                    modifier = Modifier.size(34.dp).testTag("timeline_first_frame")
                ) {
                    Icon(Icons.Rounded.FirstPage, contentDescription = "First frame", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = { onStepFrame(-10) },
                    modifier = Modifier.size(34.dp).testTag("timeline_back_10")
                ) {
                    Icon(Icons.Rounded.FastRewind, contentDescription = "Back 10 frames", tint = StudioTextSecondary, modifier = Modifier.size(17.dp))
                }
                IconButton(
                    onClick = { onStepFrame(-1) },
                    modifier = Modifier.size(36.dp).testTag("timeline_prev_frame")
                ) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous frame", tint = StudioTextPrimary)
                }

                // Play / Pause
                Surface(
                    color = StudioCoral,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onTogglePlay)
                        .testTag("timeline_play_pause")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (uiState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (uiState.isPlaying) "Pause" else "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }

                // Play Range Toggle right next to Play/Pause (strictly plays/loops inside [rangeStartFrame..rangeEndFrame])
                Surface(
                    color = if (uiState.playRangeOnly) StudioAmber else StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(
                        1.dp,
                        if (uiState.playRangeOnly) StudioAmber else StudioBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onTogglePlayRange)
                        .testTag("timeline_play_range_toggle")
                ) {
                    Text(
                        text = if (uiState.playRangeOnly) "Range ${uiState.rangeStartFrame + 1}-${uiState.rangeEndFrame + 1}" else "Play Range",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (uiState.playRangeOnly) Color.Black else StudioAmber,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp)
                    )
                }

                IconButton(
                    onClick = { onStepFrame(1) },
                    modifier = Modifier.size(36.dp).testTag("timeline_next_frame")
                ) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next frame", tint = StudioTextPrimary)
                }
                IconButton(
                    onClick = { onStepFrame(10) },
                    modifier = Modifier.size(34.dp).testTag("timeline_fwd_10")
                ) {
                    Icon(Icons.Rounded.FastForward, contentDescription = "Forward 10 frames", tint = StudioTextSecondary, modifier = Modifier.size(17.dp))
                }
                IconButton(
                    onClick = { onSelectFrame(totalFrames - 1) },
                    modifier = Modifier.size(34.dp).testTag("timeline_last_frame")
                ) {
                    Icon(Icons.Rounded.LastPage, contentDescription = "Last frame", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }

                // Interactive Timecode Pill -> Tap to Jump to Any Frame (1..2000)
                Surface(
                    color = StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            jumpInput = (uiState.currentFrame + 1).toString()
                            showJumpDialog = true
                        }
                        .testTag("timeline_jump_frame_btn")
                ) {
                    Text(
                        text = timecode,
                        style = MaterialTheme.typography.labelMedium,
                        color = StudioTextPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                // "+ Add Frames" (+10, +50, +100) Dropdown for Unlimited Cartoon Length
                Box {
                    Surface(
                        color = StudioEmerald.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioEmerald),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { addFramesMenuExpanded = true }
                            .testTag("timeline_add_frames_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = "Add Frames", tint = StudioEmerald, modifier = Modifier.size(14.dp))
                            Text("Frames", style = MaterialTheme.typography.labelSmall, color = StudioEmerald, fontWeight = FontWeight.Bold)
                        }
                    }
                    DropdownMenu(
                        expanded = addFramesMenuExpanded,
                        onDismissRequest = { addFramesMenuExpanded = false }
                    ) {
                        listOf(10, 50, 100, 250).forEach { delta ->
                            DropdownMenuItem(
                                text = { Text("+$delta Frames (Total: ${(totalFrames + delta).coerceAtMost(2000)})") },
                                onClick = {
                                    addFramesMenuExpanded = false
                                    onAddFrames(delta)
                                }
                            )
                        }
                    }
                }

                TimelineToggleChip(
                    label = "Loop",
                    active = uiState.isLooping,
                    accent = StudioCyan,
                    onClick = onToggleLoop
                )

                // FPS Selector
                Box {
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clickable { fpsMenuExpanded = true }
                            .testTag("fps_selector")
                    ) {
                        Text(
                            text = "${project.fps} FPS",
                            style = MaterialTheme.typography.labelMedium,
                            color = StudioAmber,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = fpsMenuExpanded,
                        onDismissRequest = { fpsMenuExpanded = false }
                    ) {
                        listOf(12, 24, 30, 60).forEach { fps ->
                            DropdownMenuItem(
                                text = { Text("$fps FPS") },
                                onClick = {
                                    fpsMenuExpanded = false
                                    onSetFps(fps)
                                }
                            )
                        }
                    }
                }

                TimelineToggleChip(
                    label = "Onion",
                    active = uiState.onionSkinEnabled,
                    accent = StudioViolet,
                    onClick = onToggleOnionSkin
                )
                TimelineToggleChip(
                    label = "Ghost",
                    active = uiState.ghostFramesEnabled,
                    accent = StudioCyan,
                    onClick = onToggleGhostFrames
                )

                // Single-Button Collapsible Multi-Track Editing Tools Toggle
                Surface(
                    color = if (uiState.trackToolsExpanded) StudioCoral.copy(alpha = 0.24f) else StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (uiState.trackToolsExpanded) StudioCoral else StudioAmber),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onToggleTrackTools)
                        .testTag("timeline_track_tools_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Tune,
                            contentDescription = "Track Tools",
                            tint = if (uiState.trackToolsExpanded) StudioCoral else StudioAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (uiState.trackToolsExpanded) "Hide Tools" else "Track Tools",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (uiState.trackToolsExpanded) StudioCoral else StudioAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Prominent Frame-by-Frame Keyframe, Copy/Paste & Character Swap Controls
                TimelineActionPill(
                    icon = Icons.Rounded.Diamond,
                    label = "+ Keyframe",
                    tint = StudioViolet,
                    onClick = onInsertKeyframe,
                    tag = "timeline_add_keyframe_btn"
                )
                TimelineActionPill(
                    icon = Icons.Rounded.Delete,
                    label = "Del Key",
                    tint = StudioCoral,
                    onClick = onDeleteKeyframe,
                    tag = "timeline_delete_keyframe_btn"
                )
                TimelineActionPill(
                    icon = Icons.Rounded.ContentCopy,
                    label = "Copy Frame",
                    tint = StudioCyan,
                    onClick = onCopyFrame,
                    tag = "timeline_copy_frame_btn"
                )
                TimelineActionPill(
                    icon = Icons.Rounded.ContentPaste,
                    label = "Paste Frame",
                    tint = StudioEmerald,
                    onClick = onPasteFrame,
                    tag = "timeline_paste_frame_btn"
                )
                TimelineActionPill(
                    icon = Icons.Rounded.SwapHoriz,
                    label = "Swap Char",
                    tint = StudioAmber,
                    onClick = onOpenSwapChar,
                    tag = "timeline_swap_char_btn"
                )
                TimelineActionPill(icon = Icons.Rounded.Add, label = "Cel", tint = StudioTextPrimary, onClick = onAddBlankCel)
                TimelineActionPill(icon = Icons.Rounded.ContentCopy, label = "Dup Cel", tint = StudioTextPrimary, onClick = onDuplicateCel)

                if (!compactMode) {
                    IconButton(
                        onClick = { tracksExpanded = !tracksExpanded },
                        modifier = Modifier.size(34.dp).testTag("timeline_collapse_toggle")
                    ) {
                        Icon(
                            imageVector = if (tracksExpanded) Icons.Rounded.ExpandMore else Icons.Rounded.ExpandLess,
                            contentDescription = if (tracksExpanded) "Collapse tracks" else "Expand tracks",
                            tint = StudioTextSecondary
                        )
                    }
                }
            }

            // Collapsible 1-Row Multi-Track Tool Bar (Cut, Mid-Cut, Duplicate, Delete, Remix)
            // Hidden behind the single "Track Tools" button so the preview area stays maximally visible!
            AnimatedVisibility(visible = uiState.trackToolsExpanded) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StudioSurfaceElevated)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = StudioSurface,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, StudioBorder)
                    ) {
                        Text(
                            text = activeTargetLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCyan,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        )
                    }
                    TimelineActionPill(
                        icon = Icons.Rounded.ArrowUpward,
                        label = "Up",
                        tint = StudioCyan,
                        onClick = { onMoveTrackOrder(true) },
                        tag = "track_tool_move_up"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ArrowDownward,
                        label = "Down",
                        tint = StudioAmber,
                        onClick = { onMoveTrackOrder(false) },
                        tag = "track_tool_move_down"
                    )
                    TimelineActionPill(
                        icon = if (activeTargetHidden) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                        label = if (activeTargetHidden) "Show" else "Hide",
                        tint = if (activeTargetHidden) StudioEmerald else StudioTextSecondary,
                        onClick = onToggleTrackVisibility,
                        tag = "track_tool_toggle_hide"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ContentCut,
                        label = "Cut",
                        tint = StudioAmber,
                        onClick = onCutTrack,
                        tag = "track_tool_cut"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.CallSplit,
                        label = "Mid-Cut",
                        tint = StudioCyan,
                        onClick = onMidCutTrack,
                        tag = "track_tool_midcut"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ContentCopy,
                        label = "Duplicate",
                        tint = StudioEmerald,
                        onClick = onDuplicateTrack,
                        tag = "track_tool_duplicate"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.AutoAwesome,
                        label = "Remix",
                        tint = StudioViolet,
                        onClick = onRemixTrack,
                        tag = "track_tool_remix"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.Delete,
                        label = "Delete",
                        tint = Color(0xFFF87171),
                        onClick = onDeleteTrack,
                        tag = "track_tool_delete"
                    )
                    if (uiState.selectedTrackKind == TrackSelectionKind.AUDIO || sceneAudioTracks.isNotEmpty()) {
                        TimelineActionPill(
                            icon = Icons.Rounded.ContentCut,
                            label = "Split Audio ✂️",
                            tint = StudioAmber,
                            onClick = { onSplitAudioClip(uiState.selectedAudioTrackId) },
                            tag = "track_tool_audio_split"
                        )
                        TimelineActionPill(
                            icon = Icons.Rounded.ContentCopy,
                            label = "Copy Audio",
                            tint = StudioCyan,
                            onClick = { onCopyAudioClip(uiState.selectedAudioTrackId) },
                            tag = "track_tool_audio_copy"
                        )
                        TimelineActionPill(
                            icon = Icons.Rounded.ContentPaste,
                            label = "Paste Audio",
                            tint = StudioEmerald,
                            onClick = onPasteAudioClip,
                            tag = "track_tool_audio_paste"
                        )
                        val selAudio = sceneAudioTracks.firstOrNull { it.id == uiState.selectedAudioTrackId }
                            ?: sceneAudioTracks.firstOrNull()
                        if (selAudio != null) {
                            TimelineActionPill(
                                icon = Icons.Rounded.GraphicEq,
                                label = if (selAudio.isLooping || selAudio.loopClip) "🔁 Loop ON" else "🔁 Loop OFF",
                                tint = if (selAudio.isLooping || selAudio.loopClip) StudioEmerald else StudioTextSecondary,
                                onClick = { onToggleAudioLoop(selAudio.id) },
                                tag = "track_tool_audio_loop"
                            )
                        }
                    }
                    // Module 8: Frame-Range Visibility, Targeted Loops & Custom Action Saver
                    TimelineActionPill(
                        icon = Icons.Rounded.FirstPage,
                        label = "In F${uiState.rangeStartFrame + 1}",
                        tint = StudioAmber,
                        onClick = { onSetTimelineRange(uiState.currentFrame, maxOf(uiState.currentFrame + 1, uiState.rangeEndFrame)) },
                        tag = "track_tool_set_range_in"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.LastPage,
                        label = "Out F${uiState.rangeEndFrame + 1}",
                        tint = StudioAmber,
                        onClick = { onSetTimelineRange(minOf(uiState.rangeStartFrame, uiState.currentFrame), uiState.currentFrame) },
                        tag = "track_tool_set_range_out"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.VisibilityOff,
                        label = "Hide From Here",
                        tint = StudioCoral,
                        onClick = onHideFromHere,
                        tag = "track_tool_hide_from_here"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.Visibility,
                        label = "Show Here",
                        tint = StudioEmerald,
                        onClick = onShowFromHere,
                        tag = "track_tool_show_here"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.Tune,
                        label = "Vis F${uiState.rangeStartFrame + 1}-${uiState.rangeEndFrame + 1}",
                        tint = StudioCyan,
                        onClick = { onSetVisibleRange(uiState.rangeStartFrame, uiState.rangeEndFrame) },
                        tag = "track_tool_set_vis_range"
                    )
                    if (uiState.selectedLayer?.visibilityRanges?.isNotEmpty() == true) {
                        TimelineActionPill(
                            icon = Icons.Rounded.Visibility,
                            label = "Reset Vis",
                            tint = StudioTextSecondary,
                            onClick = onClearVisibilityRanges,
                            tag = "track_tool_reset_vis"
                        )
                    }
                    if (uiState.selectedLayer?.rig != null) {
                        Box {
                            TimelineActionPill(
                                icon = Icons.Rounded.AutoAwesome,
                                label = "Loop Range",
                                tint = StudioViolet,
                                onClick = { loopMenuExpanded = true },
                                tag = "track_tool_loop_range"
                            )
                            DropdownMenu(
                                expanded = loopMenuExpanded,
                                onDismissRequest = { loopMenuExpanded = false }
                            ) {
                                TargetedLoopType.entries.forEach { loopType ->
                                    DropdownMenuItem(
                                        text = { Text("${loopType.label} (F${uiState.rangeStartFrame + 1}–F${uiState.rangeEndFrame + 1})") },
                                        onClick = {
                                            loopMenuExpanded = false
                                            onApplyTargetedLoop(loopType, uiState.rangeStartFrame, uiState.rangeEndFrame)
                                        }
                                    )
                                }
                            }
                        }
                        TimelineActionPill(
                            icon = Icons.Rounded.Add,
                            label = "Save Action",
                            tint = StudioEmerald,
                            onClick = {
                                customActionName = "Action F${uiState.rangeStartFrame + 1}-${uiState.rangeEndFrame + 1}"
                                showSaveActionDialog = true
                            },
                            tag = "track_tool_save_custom_action"
                        )
                        if (uiState.selectedBoneId != null) {
                            TimelineActionPill(
                                icon = Icons.Rounded.ArrowUpward,
                                label = "Part Z+1",
                                tint = StudioCyan,
                                onClick = { onStepSelectedBoneZOrder(true) },
                                tag = "track_tool_part_z_forward"
                            )
                            TimelineActionPill(
                                icon = Icons.Rounded.ArrowDownward,
                                label = "Part Z-1",
                                tint = StudioAmber,
                                onClick = { onStepSelectedBoneZOrder(false) },
                                tag = "track_tool_part_z_backward"
                            )
                        }
                    }
                    // Module 10: Universal Multi-Frame Batch Color/Hue, Copy Range, Auto-Loop Paste & Save FX Clip
                    TimelineActionPill(
                        icon = Icons.Rounded.AutoAwesome,
                        label = "Hue +35°",
                        tint = StudioViolet,
                        onClick = { onBatchShiftColorRange(uiState.rangeStartFrame, uiState.rangeEndFrame, 35f) },
                        tag = "track_tool_batch_hue"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.ContentCopy,
                        label = "Copy F${uiState.rangeStartFrame + 1}-${uiState.rangeEndFrame + 1}",
                        tint = StudioCyan,
                        onClick = { onCopyFrameRange(uiState.rangeStartFrame, uiState.rangeEndFrame) },
                        tag = "track_tool_copy_range"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.FastForward,
                        label = if (uiState.copiedRangeFrames.isNotEmpty()) "Auto-Loop (${uiState.copiedRangeFrames.size}f)" else "Auto-Loop Fill",
                        tint = StudioEmerald,
                        onClick = { onPasteAutoLoopFillRange(uiState.rangeStartFrame, uiState.rangeEndFrame) },
                        tag = "track_tool_autoloop_fill"
                    )
                    TimelineActionPill(
                        icon = Icons.Rounded.Add,
                        label = "Save FX Clip",
                        tint = StudioCoral,
                        onClick = {
                            fxClipName = "FX F${uiState.rangeStartFrame + 1}-${uiState.rangeEndFrame + 1}"
                            showSaveFxClipDialog = true
                        },
                        tag = "track_tool_save_fx_clip"
                    )
                }
            }

            HorizontalDivider(color = StudioBorderSubtle)

            // Smooth Playhead Scrubber Bar across 1..2000 frames
            if (totalFrames > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                        .background(StudioSurface)
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("SCRUB", style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                    Slider(
                        value = uiState.currentFrame.toFloat().coerceIn(0f, (totalFrames - 1).toFloat()),
                        onValueChange = { onSelectFrame(it.toInt()) },
                        valueRange = 0f..(totalFrames - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = StudioCoral,
                            activeTrackColor = StudioCoral,
                            inactiveTrackColor = StudioBorder
                        ),
                        modifier = Modifier.weight(1f).testTag("timeline_scrubber")
                    )
                }
            }

            // Colored Range Indicator Pills Bar for active Preset Character Animations, Motion Path, Screen/Weather Effects, Background & Lighting
            val selLayerForPills = uiState.selectedLayer
            val hasMotionPathRangePill = selLayerForPills != null && selLayerForPills.motionPath.size >= 2
            val hasPresetPills = !selLayerForPills?.presetAnimations.isNullOrEmpty() || !selLayerForPills?.targetedLoops.isNullOrEmpty()
            val hasVfxPills = scene.screenEffectClips.isNotEmpty()
            val hasBgRangePill = scene.backgroundStartFrame > 0 || scene.backgroundEndFrame >= 0
            val hasLightingRangePill = scene.lightingStartFrame > 0 || scene.lightingEndFrame >= 0
            if (hasMotionPathRangePill || hasPresetPills || hasVfxPills || hasBgRangePill || hasLightingRangePill) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StudioSurfaceVariant.copy(alpha = 0.7f))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                        .testTag("timeline_range_indicator_pills_row"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (hasMotionPathRangePill && selLayerForPills != null) {
                        val pStart = selLayerForPills.motionPathStartFrame.coerceAtLeast(0)
                        val pEnd = if (selLayerForPills.motionPathEndFrame > pStart) selLayerForPills.motionPathEndFrame else (pStart + 10)
                        val activeNow = uiState.currentFrame in pStart..pEnd
                        Surface(
                            color = if (activeNow) StudioCoral.copy(alpha = 0.25f) else StudioSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (activeNow) StudioCoral else StudioCoral.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelectFrame(pStart) }
                        ) {
                            Text(
                                text = "Path F${pStart + 1}–F${pEnd + 1}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioCoral,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    selLayerForPills?.presetAnimations?.forEach { clip ->
                        val activeNow = uiState.currentFrame in clip.startFrame..clip.endFrame
                        Surface(
                            color = if (activeNow) StudioCyan.copy(alpha = 0.25f) else StudioSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (activeNow) StudioCyan else StudioCyan.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelectFrame(clip.startFrame) }
                        ) {
                            Text(
                                text = "${clip.actionKind} F${clip.startFrame + 1}–F${clip.endFrame + 1}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    selLayerForPills?.targetedLoops?.forEach { loop ->
                        val activeNow = uiState.currentFrame in loop.startFrame..loop.endFrame
                        Surface(
                            color = if (activeNow) StudioEmerald.copy(alpha = 0.25f) else StudioSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (activeNow) StudioEmerald else StudioEmerald.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelectFrame(loop.startFrame) }
                        ) {
                            Text(
                                text = "Loop:${loop.loopType} F${loop.startFrame + 1}–F${loop.endFrame + 1}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioEmerald,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    scene.screenEffectClips.forEach { vfxClip ->
                        val activeNow = uiState.currentFrame in vfxClip.startFrame..vfxClip.endFrame
                        Surface(
                            color = if (activeNow) StudioViolet.copy(alpha = 0.25f) else StudioSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (activeNow) StudioViolet else StudioViolet.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelectFrame(vfxClip.startFrame) }
                        ) {
                            Text(
                                text = "VFX:${vfxClip.effectType} F${vfxClip.startFrame + 1}–F${vfxClip.endFrame + 1}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioViolet,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (hasBgRangePill) {
                        val bStart = scene.backgroundStartFrame.coerceAtLeast(0)
                        val bEnd = if (scene.backgroundEndFrame >= bStart) scene.backgroundEndFrame else (totalFrames - 1).coerceAtLeast(bStart)
                        val activeNow = uiState.currentFrame in bStart..bEnd
                        Surface(
                            color = if (activeNow) StudioCyan.copy(alpha = 0.22f) else StudioSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (activeNow) StudioCyan else StudioCyan.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelectFrame(bStart) }
                        ) {
                            Text(
                                text = "BG F${bStart + 1}–F${bEnd + 1}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (hasLightingRangePill) {
                        val lStart = scene.lightingStartFrame.coerceAtLeast(0)
                        val lEnd = if (scene.lightingEndFrame >= lStart) scene.lightingEndFrame else (totalFrames - 1).coerceAtLeast(lStart)
                        val activeNow = uiState.currentFrame in lStart..lEnd
                        Surface(
                            color = if (activeNow) StudioAmber.copy(alpha = 0.22f) else StudioSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (activeNow) StudioAmber else StudioAmber.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelectFrame(lStart) }
                        ) {
                            Text(
                                text = "Light F${lStart + 1}–F${lEnd + 1}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioAmber,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            if (tracksExpanded && !compactMode) {
                // 2. Strict Non-Overlapping Virtualized Multi-Track Frame Mode Dopesheet (1..2,000+ frames)
                // Fixed 40.dp row height + 4.dp vertical spacing + .clipToBounds() prevents any row overlap.
                val rowHeightDp = 40.dp
                val rowSpacingDp = 4.dp
                val rulerHeightDp = 24.dp
                val audioLaneDefs = remember {
                    listOf(
                        Triple(0, "T1: Voice", StudioCoral),
                        Triple(1, "T2: SFX", StudioCyan),
                        Triple(2, "T3: Music", StudioAmber)
                    )
                }
                val rowCount = reversedLayers.size + scene.animatedTexts.size + 1 + audioLaneDefs.size
                val trackAreaHeight = if (uiState.trackToolsExpanded) 136.dp else 164.dp
                val totalTracksHeight = (24 + rowCount * 44 + 8).dp.coerceAtLeast(trackAreaHeight)
                val yellowHighlight = Color(0xFFFFD600)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(trackAreaHeight)
                        .background(StudioSurface)
                        .verticalScroll(verticalTrackScroll)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(totalTracksHeight)
                    ) {
                        // Pinned 96.dp Left Layer Column (Name, Eye, Lock) — strictly non-overlapping 40.dp rows
                        Column(
                            modifier = Modifier
                                .width(96.dp)
                                .fillMaxHeight()
                                .background(StudioSurfaceVariant),
                            verticalArrangement = Arrangement.spacedBy(rowSpacingDp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(rulerHeightDp)
                                    .background(StudioSurfaceVariant)
                                    .border(0.5.dp, StudioBorderSubtle)
                                    .clipToBounds()
                                    .padding(horizontal = 5.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    "LAYERS (${scene.layers.size})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioTextMuted,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            reversedLayers.forEach { layer ->
                                val isSelected = uiState.selectedTrackKind == TrackSelectionKind.LAYER && layer.id == uiState.selectedLayer?.id
                                val dotColor = when {
                                    !layer.visible -> StudioTextMuted.copy(alpha = 0.45f)
                                    isSelected -> yellowHighlight
                                    layer.rig != null -> StudioViolet
                                    layer.type == LayerType.VIDEO.name -> StudioAmber
                                    else -> StudioCyan
                                }
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(rowHeightDp)
                                        .clipToBounds()
                                        .background(
                                            when {
                                                !layer.visible -> StudioSurface.copy(alpha = 0.55f)
                                                isSelected -> StudioSurfaceElevated
                                                else -> StudioSurface
                                            }
                                        )
                                        .border(
                                            width = if (isSelected) 2.dp else 0.5.dp,
                                            color = if (isSelected) yellowHighlight else StudioBorderSubtle
                                        )
                                        .clickable {
                                            onSelectLayer(layer.id)
                                            onSelectTrackTarget(TrackSelectionKind.LAYER, layer.id)
                                        }
                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(dotColor)
                                        )
                                        Text(
                                            text = layer.name,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 9.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = when {
                                                !layer.visible -> StudioTextMuted
                                                isSelected -> yellowHighlight
                                                else -> StudioTextPrimary
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(18.dp)
                                                .clip(CircleShape)
                                                .clickable { onToggleLayerVisibility(layer.id) }
                                                .testTag("timeline_layer_eye_${layer.id}"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (layer.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                                contentDescription = if (layer.visible) "Hide layer" else "Show layer",
                                                tint = if (layer.visible) StudioTextPrimary else StudioCoral,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(18.dp)
                                                .clip(CircleShape)
                                                .clickable { onToggleLayerLock(layer.id) }
                                                .testTag("timeline_layer_lock_${layer.id}"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (layer.locked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                                                contentDescription = if (layer.locked) "Unlock layer" else "Lock layer",
                                                tint = if (layer.locked) StudioCoral else StudioTextMuted,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .clickable { onMoveLayerOrder(layer.id, true) }
                                                .testTag("timeline_layer_up_${layer.id}"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move layer forward", tint = StudioCyan, modifier = Modifier.size(11.dp))
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .clickable { onMoveLayerOrder(layer.id, false) }
                                                .testTag("timeline_layer_down_${layer.id}"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move layer backward", tint = StudioAmber, modifier = Modifier.size(11.dp))
                                        }
                                    }
                                }
                            }
                            // Separate Animated Text Track headers
                            scene.animatedTexts.forEach { txt ->
                                val isSelectedText = uiState.selectedTrackKind == TrackSelectionKind.TEXT && uiState.selectedTextId == txt.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(rowHeightDp)
                                        .clipToBounds()
                                        .background(if (isSelectedText) StudioSurfaceElevated else StudioSurface)
                                        .border(if (isSelectedText) 2.dp else 0.5.dp, if (isSelectedText) yellowHighlight else StudioBorderSubtle)
                                        .clickable { onSelectTrackTarget(TrackSelectionKind.TEXT, txt.id) }
                                        .padding(horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(Icons.Rounded.Title, contentDescription = null, tint = if (txt.visible) StudioCyan else StudioTextMuted, modifier = Modifier.size(12.dp))
                                    Text(
                                        txt.text.ifBlank { "Text" },
                                        fontSize = 9.sp,
                                        color = when {
                                            !txt.visible -> StudioTextMuted
                                            isSelectedText -> yellowHighlight
                                            else -> StudioCyan
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .clickable { onToggleTextVisibility(txt.id) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (txt.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                            contentDescription = if (txt.visible) "Hide text" else "Show text",
                                            tint = if (txt.visible) StudioCyan else StudioCoral,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                            // Camera header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(rowHeightDp)
                                    .clipToBounds()
                                    .background(StudioSurface)
                                    .border(0.5.dp, StudioBorderSubtle)
                                    .padding(horizontal = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Rounded.Videocam, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(12.dp))
                                Text("Camera", fontSize = 9.sp, color = StudioAmber, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            // 3 Stacked Episode-Isolated Audio Track Lanes (Track 1: Voice, Track 2: SFX, Track 3: Music)
                            audioLaneDefs.forEach { (laneIdx, laneLabel, laneColor) ->
                                val laneClips = sceneAudioTracks.filter { it.trackIndex.coerceIn(0, 2) == laneIdx }
                                val isLaneMuted = scene.audioTrackMuted[laneIdx] == true
                                val isSelectedAudioLane = uiState.selectedTrackKind == TrackSelectionKind.AUDIO &&
                                    laneClips.any { it.id == uiState.selectedAudioTrackId }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(rowHeightDp)
                                        .clipToBounds()
                                        .background(if (isSelectedAudioLane) StudioSurfaceElevated else StudioSurface)
                                        .border(
                                            if (isSelectedAudioLane) 2.dp else 0.5.dp,
                                            if (isSelectedAudioLane) yellowHighlight else StudioBorderSubtle
                                        )
                                        .clickable {
                                            val clipToPick = laneClips.firstOrNull {
                                                uiState.currentFrame >= it.startFrame
                                            } ?: laneClips.firstOrNull()
                                            if (clipToPick != null) {
                                                onSelectTrackTarget(TrackSelectionKind.AUDIO, clipToPick.id)
                                            }
                                        }
                                        .padding(horizontal = 4.dp)
                                        .testTag("timeline_audio_lane_header_$laneIdx"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.GraphicEq,
                                        contentDescription = null,
                                        tint = if (isLaneMuted) StudioTextMuted else laneColor,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = if (laneClips.isEmpty()) laneLabel else "$laneLabel (${laneClips.size})",
                                        fontSize = 8.5.sp,
                                        fontWeight = if (isSelectedAudioLane) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isLaneMuted) StudioTextMuted else if (isSelectedAudioLane) yellowHighlight else laneColor,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .clickable { onToggleAudioTrackLaneMute(laneIdx) }
                                            .testTag("timeline_audio_lane_mute_$laneIdx"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isLaneMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                                            contentDescription = if (isLaneMuted) "Unmute lane" else "Mute lane",
                                            tint = if (isLaneMuted) StudioCoral else laneColor,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Right Virtualized LazyRow of Frame Columns (strictly matched 40.dp rows + 4.dp spacing + clipToBounds)
                        LazyRow(
                            state = lazyFrameState,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .testTag("timeline_virtualized_frames")
                        ) {
                            items(count = totalFrames, key = { it }) { f ->
                                val isCurrent = f == uiState.currentFrame
                                Column(
                                    modifier = Modifier
                                        .width(28.dp)
                                        .fillMaxHeight(),
                                    verticalArrangement = Arrangement.spacedBy(rowSpacingDp)
                                ) {
                                    // Ruler cell with bright [ Start ... End ] range bracket indicators
                                    val inRange = f in uiState.rangeStartFrame..uiState.rangeEndFrame
                                    val isRangeStart = f == uiState.rangeStartFrame
                                    val isRangeEnd = f == uiState.rangeEndFrame
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(rulerHeightDp)
                                            .clipToBounds()
                                            .background(
                                                when {
                                                    isCurrent -> StudioCoral
                                                    isRangeStart || isRangeEnd -> StudioAmber.copy(alpha = 0.45f)
                                                    inRange -> StudioAmber.copy(alpha = 0.22f)
                                                    else -> StudioSurface
                                                }
                                            )
                                            .border(
                                                width = if (isRangeStart || isRangeEnd) 1.dp else 0.5.dp,
                                                color = if (isRangeStart || isRangeEnd) StudioAmber else StudioBorderSubtle
                                            )
                                            .clickable { onSelectFrame(f) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = when {
                                                isCurrent -> "${f + 1}"
                                                isRangeStart && isRangeEnd -> "[${f + 1}]"
                                                isRangeStart -> "[${f + 1}"
                                                isRangeEnd -> "${f + 1}]"
                                                f % 5 == 0 -> "${f + 1}"
                                                else -> "·"
                                            },
                                            fontSize = 9.sp,
                                            color = if (isCurrent) Color.Black else if (inRange) StudioAmber else StudioTextMuted,
                                            fontWeight = if (isCurrent || isRangeStart || isRangeEnd) FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1
                                        )
                                    }

                                    // Layer cells (40.dp fixed height, clipped, shared diamond keyframe markers)
                                    reversedLayers.forEach { layer ->
                                        val isSelectedLayer = uiState.selectedTrackKind == TrackSelectionKind.LAYER && layer.id == uiState.selectedLayer?.id
                                        val hasCel = layer.frames.containsKey(f.toString())
                                        val hasKf = layerKeyframesMap[layer.id]?.contains(f) == true
                                        val hasZOrderKf = layerZOrderKeyframesMap[layer.id]?.contains(f) == true
                                        val hasSwapKf = layerSwapKeyframesMap[layer.id]?.contains(f) == true
                                        val isVisHere = InterpolationEngine.isLayerVisibleAtFrame(layer, f)
                                        val hasLoopHere = layer.targetedLoops.any { f in it.startFrame..it.endFrame }
                                        val hasPresetHere = layer.presetAnimations.any { f in it.startFrame..it.endFrame }
                                        val pStart = layer.motionPathStartFrame.coerceAtLeast(0)
                                        val pEnd = if (layer.motionPathEndFrame > pStart) layer.motionPathEndFrame else (pStart + 10)
                                        val hasPathHere = layer.motionPath.size >= 2 && f in pStart..pEnd
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(rowHeightDp)
                                                .clipToBounds()
                                                .background(
                                                    when {
                                                        !isVisHere -> Color(0xFF1F1218)
                                                        isCurrent -> StudioCoral.copy(alpha = 0.24f)
                                                        hasPresetHere -> StudioCyan.copy(alpha = 0.22f)
                                                        hasLoopHere -> StudioViolet.copy(alpha = 0.22f)
                                                        hasPathHere -> StudioCoral.copy(alpha = 0.16f)
                                                        hasCel -> StudioCyan.copy(alpha = 0.14f)
                                                        isSelectedLayer -> yellowHighlight.copy(alpha = 0.08f)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(
                                                    width = if (isSelectedLayer && isCurrent) 1.5.dp else 0.5.dp,
                                                    color = if (isSelectedLayer) yellowHighlight.copy(alpha = 0.55f) else StudioBorderSubtle
                                                )
                                                .clickable {
                                                    onSelectLayer(layer.id)
                                                    onSelectTrackTarget(TrackSelectionKind.LAYER, layer.id)
                                                    onSelectFrame(f)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (hasSwapKf) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(10.dp)
                                                        .rotate(45f)
                                                        .background(StudioEmerald)
                                                        .border(1.2.dp, Color.White)
                                                )
                                            } else if (hasZOrderKf) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(9.dp)
                                                        .rotate(45f)
                                                        .background(yellowHighlight)
                                                        .border(1.dp, Color.Black)
                                                )
                                            } else if (hasKf) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .rotate(45f)
                                                        .background(if (isSelectedLayer) yellowHighlight else if (layer.rig != null) StudioCyan else StudioViolet)
                                                        .border(0.8.dp, Color.Black.copy(alpha = 0.7f))
                                                )
                                            } else if (hasCel) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(StudioCyan)
                                                )
                                            }
                                        }
                                    }

                                    // Separate Animated Text track cells
                                    scene.animatedTexts.forEach { txt ->
                                        val insideText = f in txt.startFrame..txt.endFrame
                                        val isSelText = uiState.selectedTrackKind == TrackSelectionKind.TEXT && uiState.selectedTextId == txt.id
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(rowHeightDp)
                                                .clipToBounds()
                                                .background(
                                                    when {
                                                        isCurrent -> StudioCoral.copy(alpha = 0.24f)
                                                        insideText && isSelText -> StudioCyan.copy(alpha = 0.36f)
                                                        insideText -> StudioCyan.copy(alpha = 0.18f)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(0.5.dp, if (isSelText) yellowHighlight.copy(alpha = 0.5f) else StudioBorderSubtle)
                                                .clickable {
                                                    onSelectTrackTarget(TrackSelectionKind.TEXT, txt.id)
                                                    onSelectFrame(f)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (f == txt.startFrame || f == txt.endFrame) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(StudioCyan)
                                                )
                                            }
                                        }
                                    }

                                    // Camera & Screen VFX cell
                                    val hasVfxHere = scene.screenEffectClips.any { f in it.startFrame..it.endFrame }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(rowHeightDp)
                                            .clipToBounds()
                                            .background(
                                                when {
                                                    isCurrent -> StudioCoral.copy(alpha = 0.18f)
                                                    hasVfxHere -> StudioViolet.copy(alpha = 0.22f)
                                                    else -> Color.Transparent
                                                }
                                            )
                                            .border(0.5.dp, StudioBorderSubtle)
                                            .clickable { onSelectFrame(f) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (cameraKeySet.contains(f)) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .rotate(45f)
                                                    .background(StudioAmber)
                                            )
                                        }
                                    }

                                    // 3 Stacked Episode-Isolated Audio Lane cells with waveform bars & fade-in/out envelope
                                    audioLaneDefs.forEach { (laneIdx, _, laneColor) ->
                                        val isLaneMuted = scene.audioTrackMuted[laneIdx] == true
                                        val laneClips = sceneAudioTracks.filter { it.trackIndex.coerceIn(0, 2) == laneIdx }
                                        val fpsSafe = project.fps.coerceAtLeast(1)
                                        val activeClip = laneClips.firstOrNull { track ->
                                            val srcDur = maxOf(track.sourceDurationMs, track.durationMs, 200L)
                                            val effTrimEnd = if (track.trimEndMs > track.trimStartMs) track.trimEndMs else srcDur
                                            val spd = track.speed.coerceIn(0.5f, 2.0f)
                                            val natFrames = (((effTrimEnd - track.trimStartMs).coerceAtLeast(80L) / spd) / 1000f * fpsSafe).toInt().coerceAtLeast(1)
                                            val endF = if (track.endFrame >= track.startFrame) track.endFrame else (track.startFrame + natFrames - 1)
                                            f in track.startFrame..endF
                                        }
                                        val isClipSelected = activeClip != null &&
                                            uiState.selectedTrackKind == TrackSelectionKind.AUDIO &&
                                            uiState.selectedAudioTrackId == activeClip.id
                                        val isMutedHere = isLaneMuted || activeClip?.muted == true || activeClip?.isMuted == true

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(rowHeightDp)
                                                .clipToBounds()
                                                .background(
                                                    when {
                                                        isCurrent -> StudioCoral.copy(alpha = 0.2f)
                                                        activeClip != null -> laneColor.copy(alpha = if (isMutedHere) 0.07f else if (isClipSelected) 0.30f else 0.18f)
                                                        else -> Color.Transparent
                                                    }
                                                )
                                                .border(
                                                    width = if (isClipSelected) 1.dp else 0.5.dp,
                                                    color = if (isClipSelected) yellowHighlight.copy(alpha = 0.7f) else StudioBorderSubtle
                                                )
                                                .clickable {
                                                    if (activeClip != null) {
                                                        onSelectTrackTarget(TrackSelectionKind.AUDIO, activeClip.id)
                                                    } else {
                                                        laneClips.firstOrNull()?.let { onSelectTrackTarget(TrackSelectionKind.AUDIO, it.id) }
                                                    }
                                                    onSelectFrame(f)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (activeClip != null) {
                                                val srcDur = maxOf(activeClip.sourceDurationMs, activeClip.durationMs, 200L)
                                                val effTrimEnd = if (activeClip.trimEndMs > activeClip.trimStartMs) activeClip.trimEndMs else srcDur
                                                val spd = activeClip.speed.coerceIn(0.5f, 2.0f)
                                                val natFrames = (((effTrimEnd - activeClip.trimStartMs).coerceAtLeast(80L) / spd) / 1000f * fpsSafe).toInt().coerceAtLeast(1)
                                                val endF = if (activeClip.endFrame >= activeClip.startFrame) activeClip.endFrame else (activeClip.startFrame + natFrames - 1)
                                                val spanFrames = (endF - activeClip.startFrame + 1).coerceAtLeast(1)
                                                val relF = (f - activeClip.startFrame).coerceAtLeast(0)
                                                val cycF = if (activeClip.isLooping || activeClip.loopClip) relF % natFrames else relF
                                                val peaks = activeClip.waveformPeaks
                                                val baseIdx = if (peaks.isNotEmpty()) {
                                                    ((cycF.toFloat() / natFrames.coerceAtLeast(1)) * peaks.size).toInt().coerceIn(0, peaks.lastIndex)
                                                } else -1

                                                // Calculate Fade-In & Fade-Out ramp factor for visual waveform height
                                                val elapsedMs = (relF.toFloat() / fpsSafe.toFloat()) * 1000f
                                                val remainingMs = ((spanFrames - relF).toFloat() / fpsSafe.toFloat()) * 1000f
                                                val fadeInFactor = if (activeClip.fadeInMs > 0L) (elapsedMs / activeClip.fadeInMs.toFloat()).coerceIn(0.2f, 1f) else 1f
                                                val fadeOutFactor = if (activeClip.fadeOutMs > 0L) (remainingMs / activeClip.fadeOutMs.toFloat()).coerceIn(0.2f, 1f) else 1f
                                                val envGain = (fadeInFactor * fadeOutFactor * activeClip.volume.coerceIn(0.2f, 1.5f)).coerceIn(0.15f, 1.25f)

                                                if (baseIdx >= 0) {
                                                    Row(
                                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        for (sub in 0..2) {
                                                            val pIdx = (baseIdx + sub).coerceIn(0, peaks.lastIndex)
                                                            val bh = (peaks[pIdx] * 24f * envGain).coerceIn(4f, 28f)
                                                            Box(
                                                                modifier = Modifier
                                                                    .width(4.dp)
                                                                    .height(bh.dp)
                                                                    .clip(RoundedCornerShape(1.5.dp))
                                                                    .background(
                                                                        if (isMutedHere) StudioTextMuted else laneColor
                                                                    )
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSaveActionDialog) {
        AlertDialog(
            onDismissRequest = { showSaveActionDialog = false },
            containerColor = StudioSurface,
            title = { Text("Extract & Save Reusable Action", color = StudioTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Extracts bone rotation keyframes from F${uiState.rangeStartFrame + 1} to F${uiState.rangeEndFrame + 1} into your Actions Library for 1-tap reuse on any character.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                    OutlinedTextField(
                        value = customActionName,
                        onValueChange = { customActionName = it },
                        label = { Text("Action name (e.g. Walk, Stand Up)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("save_action_name_input")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Include Root Movement", color = StudioTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Save character X/Y travel along with limb poses", color = StudioTextSecondary, fontSize = 10.sp)
                        }
                        Switch(
                            checked = includeRootInAction,
                            onCheckedChange = { includeRootInAction = it },
                            modifier = Modifier.testTag("save_action_include_root_switch")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveCustomActionWithOptions(customActionName, includeRootInAction)
                        showSaveActionDialog = false
                    },
                    modifier = Modifier.testTag("confirm_save_action_btn")
                ) { Text("Save Action") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveActionDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showApplyActionDialog) {
        AlertDialog(
            onDismissRequest = { showApplyActionDialog = false },
            containerColor = StudioSurface,
            title = { Text("Apply Saved Action at F${uiState.currentFrame + 1}", color = StudioTextPrimary) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (customActions.isEmpty()) {
                        Text(
                            "No saved actions yet. Select a frame range ([ Start ... End ]) on any character and tap \"Extract / Save Action\" first.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                    } else {
                        Text(
                            "Pastes onto \"${uiState.selectedLayer?.name ?: "Character"}\" with automatic boundary hold keyframes so surrounding poses stay intact.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                        customActions.forEach { clip ->
                            Surface(
                                color = StudioSurfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, StudioBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        onApplyCustomAction(clip)
                                        showApplyActionDialog = false
                                    }
                                    .testTag("apply_action_item_${clip.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(clip.name, color = StudioTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            "${clip.durationFrames} frames • ${clip.poseKeyframes.size} pose keys${if (clip.rootKeyframes.isNotEmpty()) " • +Root" else ""}",
                                            color = StudioTextSecondary,
                                            fontSize = 10.sp
                                        )
                                    }
                                    Text("Apply", color = StudioCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showApplyActionDialog = false }) { Text("Close") }
            }
        )
    }

    if (showRangeNumbersDialog) {
        AlertDialog(
            onDismissRequest = { showRangeNumbersDialog = false },
            containerColor = StudioSurface,
            title = { Text("Set Exact Frame Range", color = StudioTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter Start Frame and End Frame (1 – $totalFrames) for isolated playback or action extraction.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = rangeStartInput,
                            onValueChange = { rangeStartInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Start Frame") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("range_start_number_input")
                        )
                        OutlinedTextField(
                            value = rangeEndInput,
                            onValueChange = { rangeEndInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("End Frame") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("range_end_number_input")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val s = ((rangeStartInput.toIntOrNull() ?: 1) - 1).coerceIn(0, (totalFrames - 1).coerceAtLeast(0))
                        val e = ((rangeEndInput.toIntOrNull() ?: totalFrames) - 1).coerceIn(s, (totalFrames - 1).coerceAtLeast(0))
                        onSetTimelineRange(s, e)
                        showRangeNumbersDialog = false
                    },
                    modifier = Modifier.testTag("confirm_range_numbers_btn")
                ) { Text("Set Range") }
            },
            dismissButton = {
                TextButton(onClick = { showRangeNumbersDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showSaveFxClipDialog) {
        AlertDialog(
            onDismissRequest = { showSaveFxClipDialog = false },
            containerColor = StudioSurface,
            title = { Text("Save Animated FX Clip", color = StudioTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Saves frames F${uiState.rangeStartFrame + 1}–F${uiState.rangeEndFrame + 1} as a reusable looping FX clip (fire, water, dust, aura).",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                    OutlinedTextField(
                        value = fxClipName,
                        onValueChange = { fxClipName = it },
                        label = { Text("FX Clip Name") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveAnimatedFxClip(fxClipName, uiState.rangeStartFrame, uiState.rangeEndFrame)
                    showSaveFxClipDialog = false
                }) { Text("Save FX Clip") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveFxClipDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showJumpDialog) {
        AlertDialog(
            onDismissRequest = { showJumpDialog = false },
            containerColor = StudioSurface,
            title = { Text("Jump to Frame (1 – $totalFrames)", color = StudioTextPrimary) },
            text = {
                OutlinedTextField(
                    value = jumpInput,
                    onValueChange = { txt -> jumpInput = txt.filter { it.isDigit() } },
                    label = { Text("Frame number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                Button(onClick = {
                    val target = (jumpInput.toIntOrNull() ?: 1).coerceIn(1, totalFrames) - 1
                    onSelectFrame(target)
                    showJumpDialog = false
                }) { Text("Jump") }
            },
            dismissButton = {
                TextButton(onClick = { showJumpDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun TimelineToggleChip(
    label: String,
    active: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) accent.copy(alpha = 0.2f) else StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (active) accent else StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) accent else StudioTextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun TimelineActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    tag: String? = null
) {
    Surface(
        color = StudioSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.45f)),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .then(if (tag != null) Modifier.testTag(tag) else Modifier)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = tint, fontWeight = FontWeight.SemiBold)
        }
    }
}
