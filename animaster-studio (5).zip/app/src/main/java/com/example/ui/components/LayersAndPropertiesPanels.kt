package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Polyline
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LocalAssetEntity
import com.example.data.model.CharacterSpec
import com.example.data.model.EasingType
import com.example.data.model.LayerType
import com.example.data.model.SkeletalRig
import com.example.engine.InterpolationEngine
import com.example.engine.MotionPreset
import com.example.engine.ProceduralPropKind
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState

val StudioColorSwatches = listOf(
    0xFFFFFFFFL, 0xFF0F172AL, 0xFFFF6B35L, 0xFFFB7185L,
    0xFFFBBF24L, 0xFF34D399L, 0xFF2DD4BFL, 0xFF38BDF8L,
    0xFF818CF8L, 0xFFA78BFAL, 0xFFF472B6L, 0xFF94A3B8L
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LayersInspectorPanel(
    uiState: StudioUiState,
    onSelectLayer: (String) -> Unit,
    onAddLayer: (LayerType) -> Unit,
    onOpenImportCharacter: () -> Unit,
    onImportVideo: () -> Unit,
    onDeleteLayer: (String) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onToggleLock: (String) -> Unit,
    onMoveOrder: (String, Boolean) -> Unit,
    onMoveToExtreme: (String, Boolean) -> Unit,
    onUpdateOpacity: (String, Float) -> Unit,
    onUpdateParallax: (String, Float) -> Unit,
    onApplyMotionPreset: (MotionPreset) -> Unit,
    onClearCel: () -> Unit,
    onClearMotionPath: () -> Unit,
    onDetachLayerFromBone: (String) -> Unit = {},
    onSetLayerScaleXY: (layerId: String, overallScale: Float?, scaleX: Float?, scaleY: Float?, reset: Boolean) -> Unit = { _, _, _, _, _ -> }
) {
    val scene = uiState.activeScene ?: return
    val selected = uiState.selectedLayer

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenImportCharacter,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioViolet),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("layers_import_character_btn")
                ) {
                    Icon(Icons.Rounded.AccessibilityNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Import Char", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onImportVideo,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("layers_import_video_btn")
                ) {
                    Icon(Icons.Rounded.VideoLibrary, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Import Video", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Add Layer", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                LayerType.entries.filter { it != LayerType.VIDEO }.forEach { type ->
                    Surface(
                        color = StudioSurfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onAddLayer(type) }
                            .testTag("add_layer_${type.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(14.dp))
                            Text(type.displayName, style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary)
                        }
                    }
                }
            }
        }

        val orderedLayers = scene.layers.reversed()
        items(orderedLayers, key = { it.id }) { layer ->
            val zPos = orderedLayers.indexOf(layer) + 1
            val posBadge = when {
                zPos == 1 -> "Front #1"
                zPos == orderedLayers.size -> "Back #$zPos"
                else -> "Layer #$zPos"
            }
            val isSel = layer.id == selected?.id
            val kfCount = layer.keyframes.size +
                (layer.rig?.poseKeyframes?.size ?: 0) +
                (layer.rig?.rootKeyframes?.size ?: 0)
            Surface(
                color = if (isSel) StudioSurfaceElevated else StudioSurfaceVariant,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (isSel) StudioCoral else StudioBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectLayer(layer.id) }
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val isAttachablePropOrImage = layer.rig == null &&
                            layer.type != LayerType.BACKGROUND.name &&
                            layer.type != LayerType.VIDEO.name
                        val layerLink = if (isAttachablePropOrImage) {
                            InterpolationEngine.evaluatePropBoneLink(layer, uiState.currentFrame)
                        } else null
                        val layerIsAttached = layerLink != null && layerLink.isAttached &&
                            !layerLink.targetCharacterLayerId.isNullOrBlank() && !layerLink.targetBoneId.isNullOrBlank()
                        val linkedHostLayer = if (layerIsAttached) {
                            scene.layers.firstOrNull { it.id == layerLink?.targetCharacterLayerId }
                        } else null
                        val linkedBoneName = if (layerIsAttached) {
                            linkedHostLayer?.rig?.bones?.firstOrNull { it.id == layerLink?.targetBoneId }?.name
                                ?: layerLink?.targetBoneId ?: ""
                        } else ""

                        val hasImportedImg = layer.frames.values.any { it.images.isNotEmpty() }
                        val icon = when {
                            layer.type == LayerType.CHARACTER.name -> Icons.Rounded.Face
                            layer.type == LayerType.RIG.name -> Icons.Rounded.AccessibilityNew
                            layer.type == LayerType.VIDEO.name -> Icons.Rounded.VideoLibrary
                            hasImportedImg -> Icons.Rounded.Image
                            else -> Icons.Rounded.Brush
                        }
                        Icon(icon, contentDescription = null, tint = if (!layer.visible) StudioTextMuted else if (isSel) StudioCoral else StudioCyan, modifier = Modifier.size(18.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                layer.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = if (layer.visible) StudioTextPrimary else StudioTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = buildString {
                                    append("$posBadge • ${if (hasImportedImg) "IMAGE" else layer.type} • $kfCount KF")
                                    if (layerIsAttached) {
                                        append(" • Locked: ${linkedHostLayer?.name ?: "Char"} → $linkedBoneName")
                                    }
                                    if (!layer.visible) append(" • HIDDEN")
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = when {
                                    !layer.visible -> StudioCoral
                                    layerIsAttached -> StudioEmerald
                                    else -> StudioTextMuted
                                },
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        // Always-visible Detach Bone chip on every Prop & gallery-imported Image row!
                        if (isAttachablePropOrImage) {
                            Surface(
                                color = if (layerIsAttached) StudioCoral.copy(alpha = 0.24f) else StudioSurface,
                                shape = RoundedCornerShape(7.dp),
                                border = BorderStroke(1.dp, if (layerIsAttached) StudioCoral else StudioBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(7.dp))
                                    .clickable { onDetachLayerFromBone(layer.id) }
                                    .testTag("layer_detach_bone_${layer.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.LinkOff,
                                        contentDescription = "Detach Bone",
                                        tint = if (layerIsAttached) StudioCoral else StudioTextSecondary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "Detach",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (layerIsAttached) StudioCoral else StudioTextSecondary
                                    )
                                }
                            }
                        }
                        IconButton(onClick = { onToggleVisibility(layer.id) }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                if (layer.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                contentDescription = "Toggle visibility",
                                tint = if (layer.visible) StudioTextPrimary else StudioCoral,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(onClick = { onToggleLock(layer.id) }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                if (layer.locked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                                contentDescription = "Toggle lock",
                                tint = if (layer.locked) StudioCoral else StudioTextMuted,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        IconButton(onClick = { onMoveOrder(layer.id, true) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move forward", tint = StudioCyan, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { onMoveOrder(layer.id, false) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move backward", tint = StudioAmber, modifier = Modifier.size(16.dp))
                        }
                        if (scene.layers.size > 1) {
                            IconButton(onClick = { onDeleteLayer(layer.id) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete layer", tint = StudioRose, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    if (isSel) {
                        if (scene.layers.size > 1) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onMoveToExtreme(layer.id, true) },
                                    modifier = Modifier.weight(1f).testTag("layer_bring_front_btn")
                                ) {
                                    Text("Bring Front", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                                }
                                OutlinedButton(
                                    onClick = { onMoveToExtreme(layer.id, false) },
                                    modifier = Modifier.weight(1f).testTag("layer_send_back_btn")
                                ) {
                                    Text("Send Back", style = MaterialTheme.typography.labelSmall, color = StudioAmber)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Opacity ${(layer.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                            Slider(
                                value = layer.opacity,
                                onValueChange = { onUpdateOpacity(layer.id, it) },
                                valueRange = 0f..1f,
                                colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Parallax ${String.format("%.2fx", layer.parallaxDepth)}", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(86.dp))
                            Slider(
                                value = layer.parallaxDepth,
                                onValueChange = { onUpdateParallax(layer.id, it) },
                                valueRange = 0.3f..1.8f,
                                colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (layer.rig == null && layer.type != LayerType.VIDEO.name) {
                            val layerTf = InterpolationEngine.evaluateLayerTransform(layer, uiState.currentFrame, scene.durationFrames)
                            ImageResizeSquashStretchBox(
                                scaleX = layerTf.scaleX,
                                scaleY = layerTf.scaleY,
                                onOverallScaleChange = { onSetLayerScaleXY(layer.id, it, null, null, false) },
                                onScaleXChange = { onSetLayerScaleXY(layer.id, null, it, null, false) },
                                onScaleYChange = { onSetLayerScaleXY(layer.id, null, null, it, false) },
                                onResetSize = { onSetLayerScaleXY(layer.id, null, null, null, true) },
                                title = "Layer Resize & Squash / Stretch",
                                accentColor = StudioCyan,
                                testTagPrefix = "layer_img_resize"
                            )
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, tint = StudioViolet, modifier = Modifier.size(16.dp))
                Text("Offline Motion Presets", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
            }
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MotionPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { onApplyMotionPreset(preset) },
                        label = { Text(preset.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onClearCel, modifier = Modifier.weight(1f)) {
                    Text("Clear Cel", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = onClearMotionPath, modifier = Modifier.weight(1f)) {
                    Text("Clear Path", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertiesInspectorPanel(
    uiState: StudioUiState,
    onSetPrimaryColor: (Long) -> Unit,
    onSetGradientColor: (Long) -> Unit,
    onToggleGradient: (Boolean) -> Unit,
    onSetBrushSize: (Float) -> Unit,
    onSetBrushOpacity: (Float) -> Unit,
    onToggleFillShapes: (Boolean) -> Unit,
    onSetPolygonSides: (Int) -> Unit,
    onSetEasing: (EasingType) -> Unit,
    onNudgeTransform: (Float, Float, Float, Float) -> Unit,
    onInsertKeyframe: () -> Unit,
    onDeleteKeyframe: () -> Unit,
    onSetAbsoluteTransformXY: (rotationDeg: Float?, scaleX: Float?, scaleY: Float?, reset: Boolean) -> Unit = { _, _, _, _ -> },
    onSetPivotMode: (String) -> Unit = {},
    onUpdateLayerEffects: (groundShadow: Boolean?, rimLightColorArgb: Long?, clearRimLight: Boolean, maskToLayerBelow: Boolean?, motionBlurStrength: Float?) -> Unit = { _, _, _, _, _ -> },
    // Universal Props & Any-Bone Attachment callbacks
    onSelectLayer: (String) -> Unit = {},
    onImportImage: () -> Unit = {},
    onStartAttachBonePick: (propLayerId: String?) -> Unit = {},
    onAttachLayerToBone: (propLayerId: String, hostLayerId: String, boneId: String) -> Unit = { _, _, _ -> },
    onDetachLayerFromBone: (propLayerId: String) -> Unit = {},
    onCenterLayerOnBone: (propLayerId: String) -> Unit = {},
    onToggleRotateProp: () -> Unit = {},
    onSetLayerScaleXY: (layerId: String, overallScale: Float?, scaleX: Float?, scaleY: Float?, reset: Boolean) -> Unit = { _, _, _, _, _ -> }
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("props_attachment_panel"),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Dedicated Props & Universal Any-Bone Attachment Section (ALWAYS at top of Props tab!)
        item {
            PropsAndAnyBoneAttachmentSection(
                uiState = uiState,
                onSelectLayer = onSelectLayer,
                onImportImage = onImportImage,
                onStartAttachBonePick = onStartAttachBonePick,
                onAttachLayerToBone = onAttachLayerToBone,
                onDetachLayerFromBone = onDetachLayerFromBone,
                onCenterLayerOnBone = onCenterLayerOnBone,
                onToggleRotateProp = onToggleRotateProp,
                onSetLayerScaleXY = onSetLayerScaleXY
            )
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Infinite Color & Gradient", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(8.dp))
            InfiniteColorPicker(
                selectedColorArgb = uiState.primaryColorArgb,
                onColorChanged = onSetPrimaryColor,
                label = "Primary Brush & Fill",
                compact = false,
                accentColor = StudioCoral,
                testTagPrefix = "props_primary_color"
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Gradient Fill / Stroke", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                Switch(checked = uiState.useGradient, onCheckedChange = onToggleGradient)
            }
            if (uiState.useGradient) {
                Spacer(Modifier.height(6.dp))
                InfiniteColorPicker(
                    selectedColorArgb = uiState.gradientColorArgb,
                    onColorChanged = onSetGradientColor,
                    label = "Gradient End Color",
                    compact = true,
                    accentColor = StudioCyan,
                    testTagPrefix = "props_gradient_color"
                )
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Stroke & Shape Settings", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Size ${uiState.brushSize.toInt()}px", style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary, modifier = Modifier.width(78.dp))
                Slider(
                    value = uiState.brushSize,
                    onValueChange = onSetBrushSize,
                    valueRange = 1f..64f,
                    colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Alpha ${(uiState.brushOpacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary, modifier = Modifier.width(78.dp))
                Slider(
                    value = uiState.brushOpacity,
                    onValueChange = onSetBrushOpacity,
                    valueRange = 0.1f..1f,
                    colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Fill Closed Shapes", style = MaterialTheme.typography.bodyMedium, color = StudioTextPrimary)
                Switch(checked = uiState.fillShapes, onCheckedChange = onToggleFillShapes)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Polygon ${uiState.polygonSides} sides", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary, modifier = Modifier.width(105.dp))
                Slider(
                    value = uiState.polygonSides.toFloat(),
                    onValueChange = { onSetPolygonSides(it.toInt()) },
                    valueRange = 3f..10f,
                    steps = 6,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Keyframe & Transform", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                EasingType.entries.forEach { easing ->
                    FilterChip(
                        selected = uiState.activeEasing == easing,
                        onClick = { onSetEasing(easing) },
                        label = { Text(easing.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, -15f, 0f) }, modifier = Modifier.weight(1f)) {
                    Text("-15°", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, 15f, 0f) }, modifier = Modifier.weight(1f)) {
                    Text("+15°", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, 0f, -0.15f) }, modifier = Modifier.weight(1f)) {
                    Text("-Scale", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onNudgeTransform(0f, 0f, 0f, 0.15f) }, modifier = Modifier.weight(1f)) {
                    Text("+Scale", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onInsertKeyframe,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioViolet, contentColor = Color.Black),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Set Keyframe", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(onClick = onDeleteKeyframe, modifier = Modifier.weight(1f)) {
                    Text("Remove KF", style = MaterialTheme.typography.labelMedium, color = StudioRose)
                }
            }

            // Modules 1 & 2: Pivot Toggle, 360° Fine Rotation & Independent X/Y Squash & Stretch Sliders
            val selLayer = uiState.selectedLayer
            val activeSc = uiState.activeScene
            if (selLayer != null && activeSc != null) {
                val tf = InterpolationEngine.evaluateLayerTransform(selLayer, uiState.currentFrame, activeSc.durationFrames)
                val normRot = (((tf.rotationDeg % 360f) + 540f) % 360f) - 180f
                Spacer(Modifier.height(10.dp))
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(8.dp))
                Text("Squash, Stretch & Pivot", style = MaterialTheme.typography.titleSmall, color = StudioCyan)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selLayer.pivotMode != "BOTTOM_FEET",
                        onClick = { onSetPivotMode("CENTER") },
                        label = { Text("Pivot: Center", style = MaterialTheme.typography.labelSmall) }
                    )
                    FilterChip(
                        selected = selLayer.pivotMode == "BOTTOM_FEET",
                        onClick = { onSetPivotMode("BOTTOM_FEET") },
                        label = { Text("Pivot: Feet", style = MaterialTheme.typography.labelSmall) }
                    )
                    OutlinedButton(onClick = { onSetAbsoluteTransformXY(null, null, null, true) }) {
                        Text("Reset", style = MaterialTheme.typography.labelSmall, color = StudioAmber)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Rotate ${normRot.toInt()}°", style = MaterialTheme.typography.labelSmall, color = StudioCoral, modifier = Modifier.width(84.dp))
                    Slider(
                        value = normRot.coerceIn(-180f, 180f),
                        onValueChange = { onSetAbsoluteTransformXY(it, null, null, false) },
                        valueRange = -180f..180f,
                        colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                        modifier = Modifier.weight(1f).testTag("props_rotation_slider")
                    )
                }
                Spacer(Modifier.height(6.dp))
                ImageResizeSquashStretchBox(
                    scaleX = tf.scaleX,
                    scaleY = tf.scaleY,
                    onOverallScaleChange = { onSetLayerScaleXY(selLayer.id, it, null, null, false) },
                    onScaleXChange = { onSetLayerScaleXY(selLayer.id, null, it, null, false) },
                    onScaleYChange = { onSetLayerScaleXY(selLayer.id, null, null, it, false) },
                    onResetSize = { onSetLayerScaleXY(selLayer.id, null, null, null, true) },
                    title = "Resize & Squash / Stretch (${selLayer.name})",
                    accentColor = StudioViolet,
                    testTagPrefix = "props_transform_resize"
                )

                // Module 9: Broadcast Layer Lighting, Ground Shadow, Masking & Motion Blur
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(8.dp))
                Text("Lighting, Shadow, Mask & Blur", style = MaterialTheme.typography.titleSmall, color = StudioAmber)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Ground Contact Shadow", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                    Switch(
                        checked = selLayer.groundShadowEnabled,
                        onCheckedChange = { onUpdateLayerEffects(it, null, false, null, null) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Mask / Clip to Layer Below", style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary)
                    Switch(
                        checked = selLayer.maskToLayerBelow,
                        onCheckedChange = { onUpdateLayerEffects(null, null, false, it, null) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Rim Light Glow", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                    FilterChip(
                        selected = selLayer.rimLightColorArgb == null || selLayer.rimLightColorArgb == 0L,
                        onClick = { onUpdateLayerEffects(null, null, true, null, null) },
                        label = { Text("Off", style = MaterialTheme.typography.labelSmall) }
                    )
                }
                Spacer(Modifier.height(4.dp))
                ProColorPickerWithSliders(
                    label = "Rim Light Color",
                    selectedColorArgb = selLayer.rimLightColorArgb?.takeIf { it != 0L } ?: 0xFFFDE047L,
                    onColorChanged = { onUpdateLayerEffects(null, it, false, null, null) },
                    presets = listOf(0xFFFDE047L, 0xFF38BDF8L, 0xFFEF4444L, 0xFF34D399L, 0xFFA78BFAL, 0xFFFFFFFFL),
                    accentColor = StudioAmber,
                    initiallyExpanded = selLayer.rimLightColorArgb != null && selLayer.rimLightColorArgb != 0L,
                    testTagPrefix = "props_rim_light_color"
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Motion Blur ${(selLayer.motionBlurStrength * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = StudioCyan, modifier = Modifier.width(104.dp))
                    Slider(
                        value = selLayer.motionBlurStrength.coerceIn(0f, 1f),
                        onValueChange = { onUpdateLayerEffects(null, null, false, null, it) },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssetsLibraryPanel(
    uiState: StudioUiState,
    localAssets: List<LocalAssetEntity>,
    customAssets: List<SkeletalRig> = emptyList(),
    onImportImage: () -> Unit,
    onImportSvg: () -> Unit,
    onImportVideo: () -> Unit,
    onInsertProp: (ProceduralPropKind) -> Unit,
    onInsertLocalImage: (String, String) -> Unit,
    onInsertSavedCharacter: (CharacterSpec) -> Unit,
    onInsertSavedRig: (SkeletalRig) -> Unit,
    onOpenCustomAssetMaker: () -> Unit = {},
    onEditCustomAsset: (SkeletalRig) -> Unit = {},
    onInsertCustomAssetToScene: (SkeletalRig) -> Unit = {},
    onAttachCustomAssetToRig: (SkeletalRig) -> Unit = {},
    onDeleteCustomAsset: (String) -> Unit = {},
    onDeleteLocalAsset: (LocalAssetEntity) -> Unit = {},
    onDeleteSavedCharacter: (String) -> Unit = {},
    onDeleteSavedRig: (String) -> Unit = {}
) {
    val project = uiState.activeProject ?: return
    val importedAssets = localAssets.filter { it.category != "RIGGED_CHARACTER" && it.category != "CUSTOM_ASSET" }

    var pendingDeleteLabel by remember { mutableStateOf<String?>(null) }
    var pendingDeleteAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Import Media (Offline)", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onImportImage,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                    modifier = Modifier.weight(1f).testTag("import_image_asset_button")
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("PNG/JPG", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = onImportSvg,
                    modifier = Modifier.weight(1f).testTag("import_svg_asset_button")
                ) {
                    Icon(Icons.Rounded.Polyline, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("SVG", style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(
                onClick = onImportVideo,
                modifier = Modifier.fillMaxWidth().testTag("import_video_asset_button")
            ) {
                Icon(Icons.Rounded.VideoLibrary, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Import Video Background / Reference (MP4 / WebM)", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Procedural Vector Props", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ProceduralPropKind.entries.forEach { kind ->
                    FilterChip(
                        selected = false,
                        onClick = { onInsertProp(kind) },
                        label = { Text(kind.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("My Custom Rigged Assets (${customAssets.size})", style = MaterialTheme.typography.titleSmall, color = StudioCyan)
                Button(
                    onClick = onOpenCustomAssetMaker,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCyan, contentColor = Color.Black),
                    modifier = Modifier.testTag("assets_create_custom_asset_btn")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("Make Asset", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(4.dp))
            if (customAssets.isEmpty()) {
                Text(
                    "Build your own rigged weapons, capes, wings, skateboards, or custom PNG props — save them here & attach to any character's hand, leg, head, or body!",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextMuted
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val hasSelectedRig = uiState.selectedLayer?.rig != null
                    customAssets.forEach { asset ->
                        Surface(
                            color = StudioSurfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            asset.name,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = StudioTextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "${asset.bones.size} movable rig bones",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StudioTextMuted
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            pendingDeleteLabel = "Custom Asset \"${asset.name}\""
                                            pendingDeleteAction = { onDeleteCustomAsset(asset.id) }
                                        },
                                        modifier = Modifier.size(28.dp).testTag("delete_custom_asset_${asset.id}")
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete custom asset", tint = StudioRose, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (hasSelectedRig) {
                                        Button(
                                            onClick = { onAttachCustomAssetToRig(asset) },
                                            colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                                            modifier = Modifier.weight(1f).testTag("assets_attach_to_rig_${asset.id}")
                                        ) {
                                            Text("Attach to Rig", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = { onInsertCustomAssetToScene(asset) },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("+ Scene", style = MaterialTheme.typography.labelSmall, color = StudioCyan)
                                    }
                                    OutlinedButton(
                                        onClick = { onEditCustomAsset(asset) }
                                    ) {
                                        Text("Edit", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Saved Characters (${project.savedCharacters.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                project.savedCharacters.forEach { spec ->
                    Surface(
                        color = StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onInsertSavedCharacter(spec) }
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(spec.shirtColorArgb)))
                            Text(spec.name, style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
                            IconButton(
                                onClick = {
                                    pendingDeleteLabel = "Saved Character \"${spec.name}\""
                                    pendingDeleteAction = { onDeleteSavedCharacter(spec.id) }
                                },
                                modifier = Modifier.size(26.dp).testTag("delete_saved_char_${spec.id}")
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete saved character", tint = StudioRose, modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(color = StudioBorder)
            Spacer(Modifier.height(6.dp))
            Text("Saved Rigs (${project.savedRigs.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                project.savedRigs.forEach { rig ->
                    Surface(
                        color = StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onInsertSavedRig(rig) }
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("${rig.name} (${rig.bones.size}b)", style = MaterialTheme.typography.labelSmall, color = StudioTextPrimary)
                            IconButton(
                                onClick = {
                                    pendingDeleteLabel = "Saved Rig \"${rig.name}\""
                                    pendingDeleteAction = { onDeleteSavedRig(rig.id) }
                                },
                                modifier = Modifier.size(26.dp).testTag("delete_saved_rig_${rig.id}")
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete saved rig", tint = StudioRose, modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }

        if (importedAssets.isNotEmpty()) {
            item {
                HorizontalDivider(color = StudioBorder)
                Spacer(Modifier.height(6.dp))
                Text("Imported Assets (${importedAssets.size})", style = MaterialTheme.typography.titleSmall, color = StudioTextSecondary)
            }
            items(importedAssets, key = { it.id }) { asset ->
                Surface(
                    color = StudioSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val path = asset.filePath
                            if (!path.isNullOrBlank()) onInsertLocalImage(path, asset.name)
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            if (asset.category == "VIDEO") Icons.Rounded.VideoLibrary else Icons.Rounded.Image,
                            contentDescription = null,
                            tint = StudioCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(asset.name, style = MaterialTheme.typography.bodySmall, color = StudioTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(asset.category, style = MaterialTheme.typography.labelSmall, color = StudioTextMuted)
                        }
                        if (!asset.filePath.isNullOrBlank()) {
                            Text("Insert", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                        }
                        IconButton(
                            onClick = {
                                pendingDeleteLabel = "Imported Asset \"${asset.name}\""
                                pendingDeleteAction = { onDeleteLocalAsset(asset) }
                            },
                            modifier = Modifier.size(32.dp).testTag("delete_local_asset_${asset.id}")
                        ) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete imported asset", tint = StudioRose, modifier = Modifier.size(17.dp))
                        }
                    }
                }
            }
        }
    }

    if (pendingDeleteLabel != null && pendingDeleteAction != null) {
        AlertDialog(
            onDismissRequest = {
                pendingDeleteLabel = null
                pendingDeleteAction = null
            },
            containerColor = StudioSurfaceElevated,
            title = { Text("Delete Permanently?", color = StudioTextPrimary) },
            text = { Text("Remove ${pendingDeleteLabel}?", color = StudioTextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        pendingDeleteAction?.invoke()
                        pendingDeleteLabel = null
                        pendingDeleteAction = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioRose)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingDeleteLabel = null
                    pendingDeleteAction = null
                }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}
