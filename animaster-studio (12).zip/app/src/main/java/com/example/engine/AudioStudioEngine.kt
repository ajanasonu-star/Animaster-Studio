package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.webkit.MimeTypeMap
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.FacialTimingConfig
import com.example.data.model.MouthPhoneme
import com.example.data.model.VoiceEffectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

enum class BuiltInAudioPreset(val title: String, val kind: AudioTrackKind, val durationSec: Float) {
    SFX_POP("Cartoon Pop", AudioTrackKind.SFX, 0.35f),
    SFX_BOING("Spring Boing", AudioTrackKind.SFX, 0.75f),
    SFX_WHOOSH("Fast Whoosh", AudioTrackKind.SFX, 0.55f),
    SFX_SPARKLE("Magic Chime", AudioTrackKind.SFX, 0.9f),
    SFX_FOOTSTEP("Soft Step", AudioTrackKind.SFX, 0.25f),
    SFX_JUMPSCARE("Horror Scare", AudioTrackKind.SFX, 0.95f),
    SFX_GHOST_MOAN("Ghost Wail", AudioTrackKind.SFX, 1.5f),
    SFX_THUNDER("Thunder Clap", AudioTrackKind.SFX, 1.6f),
    SFX_HEARTBEAT("Suspense Pulse", AudioTrackKind.SFX, 2.0f),
    MUSIC_SYNTH_LOOP("Studio Synth Loop", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_PLAYFUL_BEAT("Playful Marimba", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_HORROR_DRONE("Horror Ambience", AudioTrackKind.MUSIC, 4.0f)
}

class AudioStudioEngine(private val context: Context) {

    enum class BlinkPhase { OPEN, HALF_BLINK, CLOSED }

    private val audioDir: File by lazy {
        File(context.filesDir, "audio").apply { mkdirs() }
    }

    private var activeRecorder: AudioRecord? = null
    @Volatile
    private var isRecordingFlag = false
    private val activePlayers = mutableListOf<MediaPlayer>()

    @SuppressLint("MissingPermission")
    suspend fun recordVoiceToWav(
        onAmplitude: (Float) -> Unit,
        onFinished: (AudioTrackItem?) -> Unit
    ) = withContext(Dispatchers.IO) {
        val sampleRate = 22050
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, encoding).coerceAtLeast(2048)

        val recorder = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, encoding, minBuf * 2)
        }.getOrNull()

        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        activeRecorder = recorder
        isRecordingFlag = true
        val pcmStream = ByteArrayOutputStream()
        val buffer = ShortArray(1024)

        try {
            recorder.startRecording()
            while (isRecordingFlag && isActive) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    var peak = 0
                    val byteBuf = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until read) {
                        val s = buffer[i]
                        byteBuf.putShort(s)
                        val a = abs(s.toInt())
                        if (a > peak) peak = a
                    }
                    pcmStream.write(byteBuf.array())
                    val norm = (peak / 32768f).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main) { onAmplitude(norm) }
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
            activeRecorder = null
            isRecordingFlag = false
        }

        val pcmBytes = pcmStream.toByteArray()
        if (pcmBytes.size < 400) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        val file = File(audioDir, "voice_${System.currentTimeMillis()}.wav")
        writeWavFile(file, pcmBytes, sampleRate)
        val durationMs = ((pcmBytes.size / 2.0) / sampleRate * 1000.0).toLong().coerceAtLeast(200L)
        val peaks = extractPeaksFromPcm16(pcmBytes, 48)
        val track = AudioTrackItem(
            id = UUID.randomUUID().toString(),
            name = "Voice Take ${(System.currentTimeMillis() % 1000)}",
            filePath = file.absolutePath,
            originalFilePath = file.absolutePath,
            kind = AudioTrackKind.VOICE.name,
            voiceEffect = VoiceEffectType.NORMAL.name,
            startFrame = 0,
            durationMs = durationMs,
            trimStartMs = 0L,
            trimEndMs = durationMs,
            volume = 0.95f,
            fadeInMs = 50L,
            fadeOutMs = 80L,
            waveformPeaks = peaks
        )
        withContext(Dispatchers.Main) { onFinished(track) }
    }

    fun stopVoiceRecording() {
        isRecordingFlag = false
    }

    suspend fun synthesizeBuiltInPreset(preset: BuiltInAudioPreset, startFrame: Int): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val sampleRate = 22050
            val totalSamples = (sampleRate * preset.durationSec).toInt()
            val pcm = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
            val rng = Random(preset.ordinal * 997 + 13)

            for (i in 0 until totalSamples) {
                val t = i.toFloat() / sampleRate.toFloat()
                val progress = i.toFloat() / totalSamples.toFloat()
                val sample = when (preset) {
                    BuiltInAudioPreset.SFX_POP -> {
                        val freq = 220f + 560f * progress
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 14f)
                    }
                    BuiltInAudioPreset.SFX_BOING -> {
                        val freq = 140f + 240f * sin(2.0 * PI * 9.0 * t).toFloat()
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 3.2f)
                    }
                    BuiltInAudioPreset.SFX_WHOOSH -> {
                        val env = sin(PI * progress).toFloat()
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.45f
                        val tone = sin(2.0 * PI * (180f + 420f * progress) * t).toFloat() * 0.35f
                        (noise + tone) * env
                    }
                    BuiltInAudioPreset.SFX_SPARKLE -> {
                        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f)
                        val noteIdx = (progress * notes.size).toInt().coerceIn(0, notes.lastIndex)
                        val localT = t - (noteIdx * (preset.durationSec / notes.size))
                        val env = exp(-localT.coerceAtLeast(0f) * 8f)
                        (sin(2.0 * PI * notes[noteIdx] * t) + 0.4 * sin(4.0 * PI * notes[noteIdx] * t)).toFloat() * 0.6f * env
                    }
                    BuiltInAudioPreset.SFX_FOOTSTEP -> {
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.5f
                        val thud = sin(2.0 * PI * (95f - 45f * progress) * t).toFloat() * 0.6f
                        (noise + thud) * exp(-t * 22f)
                    }
                    BuiltInAudioPreset.SFX_JUMPSCARE -> {
                        val shriek = sin(2.0 * PI * (680f + 420f * sin(t * 28.0)) * t).toFloat() * 0.45f
                        val dissonance = sin(2.0 * PI * 725.0 * t).toFloat() * 0.38f
                        val rumble = sin(2.0 * PI * 62.0 * t).toFloat() * 0.4f
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.35f
                        (shriek + dissonance + rumble + noise) * exp(-t * 3.1f)
                    }
                    BuiltInAudioPreset.SFX_GHOST_MOAN -> {
                        val env = sin(PI * progress).toFloat()
                        val vibrato = sin(2.0 * PI * 5.2 * t).toFloat() * 28f
                        val freq = 340f - 140f * progress + vibrato
                        val wail = sin(2.0 * PI * freq * t).toFloat() * 0.55f +
                            sin(2.0 * PI * (freq * 1.5f) * t).toFloat() * 0.22f
                        val breath = (rng.nextFloat() * 2f - 1f) * 0.14f
                        (wail + breath) * env
                    }
                    BuiltInAudioPreset.SFX_THUNDER -> {
                        val crack = (rng.nextFloat() * 2f - 1f) * exp(-t * 6.5f) * 0.7f
                        val roll = (rng.nextFloat() * 2f - 1f) * (0.4f + 0.3f * sin(t * 9.0).toFloat()) * exp(-t * 1.4f)
                        val sub = sin(2.0 * PI * (52f - 18f * progress) * t).toFloat() * exp(-t * 1.8f) * 0.5f
                        crack + roll * 0.55f + sub
                    }
                    BuiltInAudioPreset.SFX_HEARTBEAT -> {
                        val cycle = t % 0.85f
                        val beat1 = if (cycle < 0.16f) sin(2.0 * PI * 58.0 * cycle).toFloat() * exp(-cycle * 22f) else 0f
                        val beat2 = if (cycle in 0.22f..0.38f) {
                            val lt = cycle - 0.22f
                            sin(2.0 * PI * 50.0 * lt).toFloat() * exp(-lt * 24f) * 0.75f
                        } else 0f
                        (beat1 + beat2) * 0.95f
                    }
                    BuiltInAudioPreset.MUSIC_SYNTH_LOOP -> {
                        val stepDur = 0.2f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val chord = floatArrayOf(261.63f, 329.63f, 392.0f, 329.63f, 220.0f, 261.63f, 349.23f, 392.0f)
                        val f = chord[step % chord.size]
                        val bass = sin(2.0 * PI * (f / 2f) * t).toFloat() * 0.32f
                        val lead = sin(2.0 * PI * f * t).toFloat() * exp(-localT * 6.5f) * 0.45f
                        (bass + lead) * (1f - 0.1f * progress)
                    }
                    BuiltInAudioPreset.MUSIC_PLAYFUL_BEAT -> {
                        val stepDur = 0.16f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val scale = floatArrayOf(392f, 440f, 523.25f, 587.33f, 659.25f, 587.33f, 523.25f, 440f)
                        val f = scale[step % scale.size]
                        sin(2.0 * PI * f * t).toFloat() * exp(-localT * 11f) * 0.65f
                    }
                    BuiltInAudioPreset.MUSIC_HORROR_DRONE -> {
                        val drone1 = sin(2.0 * PI * 55.0 * t).toFloat() * 0.38f
                        val drone2 = sin(2.0 * PI * 58.27 * t).toFloat() * 0.32f
                        val eerieHigh = sin(2.0 * PI * (466.16 + 8.0 * sin(t * 1.7)) * t).toFloat() * 0.12f
                        val wind = (rng.nextFloat() * 2f - 1f) * 0.08f * (0.5f + 0.5f * sin(t * 2.1).toFloat())
                        (drone1 + drone2 + eerieHigh + wind) * sin(PI * progress).toFloat().coerceAtLeast(0.25f)
                    }
                }
                val s16 = (sample.coerceIn(-0.98f, 0.98f) * 32000f).toInt().toShort()
                pcm.putShort(s16)
            }

            val pcmBytes = pcm.array()
            val file = File(audioDir, "preset_${preset.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(file, pcmBytes, sampleRate)
            val durationMs = (preset.durationSec * 1000L).toLong()
            AudioTrackItem(
                id = UUID.randomUUID().toString(),
                name = preset.title,
                filePath = file.absolutePath,
                originalFilePath = file.absolutePath,
                kind = preset.kind.name,
                voiceEffect = VoiceEffectType.NORMAL.name,
                startFrame = startFrame,
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                volume = 0.85f,
                fadeInMs = 40L,
                fadeOutMs = 100L,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 44)
            )
        }

    /**
     * Real offline PCM16 Voice Changer DSP for Cartoon Kid, Deep Monster, Ghost Echo & Robot voices.
     */
    suspend fun applyVoiceEffect(track: AudioTrackItem, effect: VoiceEffectType): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val basePath = track.originalFilePath.ifBlank { track.filePath }
            val sourceFile = File(basePath)
            if (!sourceFile.exists()) return@withContext track.copy(voiceEffect = effect.name)

            if (effect == VoiceEffectType.NORMAL) {
                val bytes = runCatching { sourceFile.readBytes() }.getOrNull()
                val wav = bytes?.let { parseWavPcm16(it) }
                val durMs = wav?.let { ((it.samples.size.toDouble() / it.sampleRate) * 1000.0).toLong().coerceAtLeast(200L) }
                    ?: track.durationMs
                val restoredPeaks = if (wav != null) {
                    val bb = ByteBuffer.allocate(wav.samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                    wav.samples.forEach { bb.putShort(it) }
                    extractPeaksFromPcm16(bb.array(), 48)
                } else track.waveformPeaks
                return@withContext track.copy(
                    filePath = basePath,
                    originalFilePath = basePath,
                    voiceEffect = effect.name,
                    durationMs = durMs,
                    trimStartMs = 0L,
                    trimEndMs = durMs,
                    waveformPeaks = restoredPeaks
                )
            }

            val rawBytes = runCatching { sourceFile.readBytes() }.getOrNull()
                ?: return@withContext track.copy(voiceEffect = effect.name)
            val parsed = parseWavPcm16(rawBytes)
                ?: return@withContext track.copy(voiceEffect = effect.name)

            val processedSamples = processVoicePcm16(parsed.samples, parsed.sampleRate, effect)
            val outBytes = ByteBuffer.allocate(processedSamples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            processedSamples.forEach { outBytes.putShort(it) }
            val pcmBytes = outBytes.array()

            val outFile = File(audioDir, "fx_${effect.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(outFile, pcmBytes, parsed.sampleRate)
            val durationMs = ((processedSamples.size.toDouble() / parsed.sampleRate) * 1000.0).toLong().coerceAtLeast(200L)
            track.copy(
                filePath = outFile.absolutePath,
                originalFilePath = basePath,
                voiceEffect = effect.name,
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 48)
            )
        }

    suspend fun importAudioUri(uri: Uri, displayName: String, startFrame: Int): AudioTrackItem? =
        withContext(Dispatchers.IO) {
            val mimeType = runCatching { context.contentResolver.getType(uri) }.getOrNull()
            val nameExt = displayName.substringAfterLast('.', "").lowercase(Locale.US)
                .takeIf { it in setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "3gp", "amr", "opus") }
            val mimeExt = mimeType?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
                ?.lowercase(Locale.US)
                ?.takeIf { it.isNotBlank() && it.length <= 5 }
            val ext = nameExt ?: mimeExt ?: "m4a"
            val outFile = File(audioDir, "import_${System.currentTimeMillis()}.$ext")
            val result = runCatching {
                val inputStream = runCatching { context.contentResolver.openInputStream(uri) }.getOrNull()
                    ?: runCatching { context.contentResolver.openAssetFileDescriptor(uri, "r")?.createInputStream() }.getOrNull()
                    ?: return@runCatching null
                inputStream.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                if (!outFile.exists() || outFile.length() <= 0L) {
                    runCatching { outFile.delete() }
                    return@runCatching null
                }

                val durationMs = runCatching {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(outFile.absolutePath)
                        mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                            ?.toLongOrNull()?.coerceAtLeast(300L) ?: 3000L
                    } finally {
                        runCatching { mmr.release() }
                    }
                }.getOrDefault(3000L)

                // Read bounded header/body bytes (max 512 KB) to compute waveform peaks without OOM on huge files
                val sampleBytes = readBoundedBytes(outFile, maxBytes = 512 * 1024)
                val peaks = if (sampleBytes.size > 44 && String(sampleBytes.copyOfRange(0, 4)) == "RIFF") {
                    extractPeaksFromPcm16(sampleBytes.copyOfRange(44, sampleBytes.size), 48)
                } else {
                    extractApproximatePeaks(sampleBytes, 48)
                }

                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    name = displayName.substringBeforeLast('.').ifBlank { "Imported Audio" },
                    filePath = outFile.absolutePath,
                    originalFilePath = outFile.absolutePath,
                    kind = AudioTrackKind.MUSIC.name,
                    voiceEffect = VoiceEffectType.NORMAL.name,
                    startFrame = startFrame,
                    durationMs = durationMs,
                    trimStartMs = 0L,
                    trimEndMs = durationMs,
                    volume = 0.85f,
                    fadeInMs = 80L,
                    fadeOutMs = 120L,
                    waveformPeaks = peaks
                )
            }.getOrNull()
            if (result == null) {
                runCatching { if (outFile.exists()) outFile.delete() }
            }
            result
        }

    private fun readBoundedBytes(file: File, maxBytes: Int): ByteArray {
        return runCatching {
            val toRead = file.length().coerceAtMost(maxBytes.toLong()).toInt().coerceAtLeast(0)
            if (toRead == 0) return@runCatching ByteArray(0)
            val buf = ByteArray(toRead)
            FileInputStream(file).use { fis ->
                var offset = 0
                while (offset < toRead) {
                    val n = fis.read(buf, offset, toRead - offset)
                    if (n <= 0) break
                    offset += n
                }
                if (offset == toRead) buf else buf.copyOf(offset)
            }
        }.getOrDefault(ByteArray(0))
    }

    fun previewTrack(track: AudioTrackItem) {
        stopAllPlayback()
        if (track.muted || track.filePath.isBlank()) return
        val file = File(track.filePath)
        if (!file.exists() || file.length() <= 0L) return
        val mp = MediaPlayer()
        runCatching {
            mp.apply {
                setDataSource(file.absolutePath)
                prepare()
                setVolume(track.volume, track.volume)
                if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                setOnCompletionListener {
                    it.release()
                    activePlayers.remove(it)
                }
                start()
            }
            activePlayers.add(mp)
        }.onFailure {
            runCatching { mp.release() }
        }
    }

    fun triggerTracksForFrame(tracks: List<AudioTrackItem>, frame: Int) {
        tracks.filter { !it.muted && it.startFrame == frame && it.filePath.isNotBlank() }.forEach { track ->
            val file = File(track.filePath)
            if (file.exists() && file.length() > 0L) {
                val mp = MediaPlayer()
                runCatching {
                    mp.apply {
                        setDataSource(file.absolutePath)
                        prepare()
                        setVolume(track.volume, track.volume)
                        if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                        setOnCompletionListener {
                            it.release()
                            activePlayers.remove(it)
                        }
                        start()
                    }
                    activePlayers.add(mp)
                }.onFailure {
                    runCatching { mp.release() }
                }
            }
        }
    }

    fun stopAllPlayback() {
        val copy = activePlayers.toList()
        activePlayers.clear()
        copy.forEach { mp ->
            runCatching {
                if (mp.isPlaying) mp.stop()
                mp.release()
            }
        }
    }

    private fun writeWavFile(file: File, pcmData: ByteArray, sampleRate: Int) {
        val channels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + dataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1) // PCM
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort((channels * bitsPerSample / 8).toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray())
            putInt(dataSize)
        }
        FileOutputStream(file).use { out ->
            out.write(header.array())
            out.write(pcmData)
        }
    }

    private fun extractPeaksFromPcm16(pcmBytes: ByteArray, bars: Int): List<Float> {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return List(bars) { 0.15f }
        val step = (sampleCount / bars).coerceAtLeast(1)
        val bb = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)
        val peaks = mutableListOf<Float>()
        for (b in 0 until bars) {
            var maxAmp = 0
            val start = b * step
            val end = ((b + 1) * step).coerceAtMost(sampleCount)
            for (s in start until end) {
                val v = abs(bb.getShort(s * 2).toInt())
                if (v > maxAmp) maxAmp = v
            }
            peaks.add((maxAmp / 32768f).coerceIn(0.08f, 1f))
        }
        return peaks
    }

    private fun extractApproximatePeaks(bytes: ByteArray, bars: Int): List<Float> {
        if (bytes.isEmpty()) return List(bars) { 0.25f }
        val step = (bytes.size / bars).coerceAtLeast(1)
        return List(bars) { b ->
            val idx = (b * step).coerceIn(0, bytes.lastIndex)
            val norm = abs(bytes[idx].toInt()) / 128f
            norm.coerceIn(0.15f, 0.95f)
        }
    }

    data class ParsedWav(val sampleRate: Int, val samples: ShortArray)

    companion object {
        fun parseWavPcm16(bytes: ByteArray): ParsedWav? {
            if (bytes.size <= 44) return null
            if (String(bytes.copyOfRange(0, 4)) != "RIFF") return null
            if (String(bytes.copyOfRange(8, 12)) != "WAVE") return null
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

            var channels = 1
            var sampleRate = 22050
            var bits = 16
            var foundFmt = false
            var dataOffset = -1
            var dataSize = 0

            var cursor = 12
            while (cursor + 8 <= bytes.size) {
                val chunkId = String(bytes.copyOfRange(cursor, cursor + 4))
                val chunkSize = bb.getInt(cursor + 4).coerceAtLeast(0)
                val bodyStart = cursor + 8
                if (chunkId == "fmt " && bodyStart + 16 <= bytes.size) {
                    channels = bb.getShort(bodyStart + 2).toInt().coerceIn(1, 8)
                    sampleRate = bb.getInt(bodyStart + 4).coerceIn(8000, 48000)
                    bits = bb.getShort(bodyStart + 14).toInt()
                    foundFmt = true
                } else if (chunkId == "data") {
                    dataOffset = bodyStart
                    dataSize = chunkSize.coerceAtMost((bytes.size - bodyStart).coerceAtLeast(0))
                    break
                }
                val padded = chunkSize + (chunkSize and 1)
                if (padded <= 0) break
                cursor = bodyStart + padded
            }

            if (!foundFmt || bits != 16 || dataOffset < 0 || dataSize <= 0) return null
            val frameCount = dataSize / (2 * channels)
            if (frameCount <= 0) return null
            val mono = ShortArray(frameCount)
            for (i in 0 until frameCount) {
                var sum = 0
                for (c in 0 until channels) {
                    val pos = dataOffset + (i * channels + c) * 2
                    if (pos + 1 < bytes.size) sum += bb.getShort(pos).toInt()
                }
                mono[i] = (sum / channels).toShort()
            }
            return ParsedWav(sampleRate, mono)
        }

        fun processVoicePcm16(
            input: ShortArray,
            sampleRate: Int,
            effect: VoiceEffectType
        ): ShortArray {
            if (input.isEmpty() || effect == VoiceEffectType.NORMAL) return input
            return when (effect) {
                VoiceEffectType.CHIPMUNK -> resamplePitch(input, 1.48f)
                VoiceEffectType.DEEP_MONSTER -> {
                    val pitched = resamplePitch(input, 0.68f)
                    ShortArray(pitched.size) { i ->
                        val t = i.toDouble() / sampleRate.toDouble()
                        val growl = 1.0 + 0.18 * sin(2.0 * PI * 32.0 * t)
                        (pitched[i] * growl).toInt().coerceIn(-32767, 32767).toShort()
                    }
                }
                VoiceEffectType.GHOST_ECHO -> {
                    val pitched = resamplePitch(input, 0.90f)
                    val tailSamples = (sampleRate * 0.55f).toInt()
                    val out = FloatArray(pitched.size + tailSamples)
                    val d1 = (sampleRate * 0.17f).toInt().coerceAtLeast(1)
                    val d2 = (sampleRate * 0.34f).toInt().coerceAtLeast(1)
                    for (i in out.indices) {
                        var v = if (i < pitched.size) pitched[i].toFloat() else 0f
                        if (i >= d1) v += out[i - d1] * 0.45f
                        if (i >= d2) v += out[i - d2] * 0.25f
                        out[i] = v.coerceIn(-32767f, 32767f)
                    }
                    ShortArray(out.size) { out[it].toInt().toShort() }
                }
                VoiceEffectType.ROBOT -> {
                    ShortArray(input.size) { i ->
                        val t = i.toDouble() / sampleRate.toDouble()
                        val carrier = sin(2.0 * PI * 58.0 * t)
                        val mod = input[i] * (0.45 + 0.55 * carrier)
                        // Subtle bit-crushed metallic edge
                        val stepped = ((mod / 2048.0).toInt() * 2048.0)
                        (mod * 0.72 + stepped * 0.28).toInt().coerceIn(-32767, 32767).toShort()
                    }
                }
                VoiceEffectType.NORMAL -> input
            }
        }

        private fun resamplePitch(input: ShortArray, speedFactor: Float): ShortArray {
            val outLen = (input.size / speedFactor).toInt().coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = i * speedFactor
                val i0 = srcPos.toInt().coerceIn(0, input.lastIndex)
                val i1 = (i0 + 1).coerceAtMost(input.lastIndex)
                val frac = srcPos - i0
                val sample = input[i0] * (1f - frac) + input[i1] * frac
                sample.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        /**
         * Resamples mono 16-bit PCM samples from [srcSampleRate] to [targetSampleRate]
         * using linear interpolation so mixed audio tracks always align cleanly at 44100Hz.
         */
        fun resampleMonoPcm16(
            input: ShortArray,
            srcSampleRate: Int,
            targetSampleRate: Int
        ): ShortArray {
            if (input.isEmpty() || srcSampleRate <= 0 || targetSampleRate <= 0 || srcSampleRate == targetSampleRate) {
                return input.copyOf()
            }
            val ratio = srcSampleRate.toDouble() / targetSampleRate.toDouble()
            val outLen = (input.size / ratio).toInt().coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = i * ratio
                val i0 = srcPos.toInt().coerceIn(0, input.lastIndex)
                val i1 = (i0 + 1).coerceAtMost(input.lastIndex)
                val frac = (srcPos - i0).toFloat()
                val sample = input[i0] * (1f - frac) + input[i1] * frac
                sample.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        /**
         * Mixes all active WAV tracks into a single mono 44.1kHz PCM16 timeline buffer
         * for real offline AAC audio muxing inside exported MP4 videos.
         * Uniformly resamples every track to [targetSampleRate] (44100Hz) and applies
         * smooth Auto-Ducking to BGM tracks whenever Voiceover tracks speak!
         */
        fun mixTracksToPcm16(
            tracks: List<AudioTrackItem>,
            totalFrames: Int,
            fps: Int,
            targetSampleRate: Int = 44100,
            startFrameOffset: Int = 0
        ): ShortArray? {
            val active = tracks.filter { !it.muted && it.filePath.isNotBlank() }
            if (active.isEmpty() || totalFrames <= 0) return null
            val durationSec = totalFrames.toDouble() / fps.coerceAtLeast(1).toDouble()
            val totalSamples = (durationSec * targetSampleRate).toInt().coerceAtLeast(1024)
            val voiceBus = FloatArray(totalSamples)
            val voiceEnvelope = FloatArray(totalSamples)
            val otherBus = FloatArray(totalSamples)
            val duckedMusicBus = FloatArray(totalSamples)
            var wroteAny = false

            fun mixIntoBus(track: AudioTrackItem, targetBus: FloatArray, recordEnvelope: Boolean) {
                val file = File(track.filePath)
                if (!file.exists()) return
                val bytes = runCatching { file.readBytes() }.getOrNull() ?: return
                val parsed = parseWavPcm16(bytes) ?: return
                wroteAny = true

                val relativeStartFrames = track.startFrame - startFrameOffset
                val startSec = relativeStartFrames.toDouble() / fps.coerceAtLeast(1).toDouble()
                val dstStart = (startSec * targetSampleRate).toInt()
                val trimStartSample = ((track.trimStartMs / 1000.0) * parsed.sampleRate).toInt().coerceIn(0, parsed.samples.size)
                val trimEndSample = ((track.trimEndMs / 1000.0) * parsed.sampleRate).toInt().coerceIn(trimStartSample, parsed.samples.size)
                val srcSpan = (trimEndSample - trimStartSample).coerceAtLeast(1)
                val ratio = parsed.sampleRate.toDouble() / targetSampleRate.toDouble()
                val dstSpan = (srcSpan / ratio).toInt().coerceAtLeast(1)
                val fadeInSamples = ((track.fadeInMs / 1000.0) * targetSampleRate).toInt().coerceAtLeast(1)
                val fadeOutSamples = ((track.fadeOutMs / 1000.0) * targetSampleRate).toInt().coerceAtLeast(1)

                for (k in 0 until dstSpan) {
                    val dstIdx = dstStart + k
                    if (dstIdx < 0) continue
                    if (dstIdx >= totalSamples) break
                    val srcPos = trimStartSample + k * ratio
                    val s0 = srcPos.toInt().coerceIn(0, parsed.samples.lastIndex)
                    val s1 = (s0 + 1).coerceAtMost(parsed.samples.lastIndex)
                    val frac = (srcPos - s0).toFloat()
                    var sample = (parsed.samples[s0] * (1f - frac) + parsed.samples[s1] * frac) * track.volume
                    if (k < fadeInSamples) sample *= (k.toFloat() / fadeInSamples)
                    val rem = dstSpan - k
                    if (rem < fadeOutSamples) sample *= (rem.toFloat() / fadeOutSamples)
                    targetBus[dstIdx] += sample
                    if (recordEnvelope) {
                        val mag = abs(sample) / 32768f
                        if (mag > voiceEnvelope[dstIdx]) voiceEnvelope[dstIdx] = mag
                    }
                }
            }

            // Pass 1: Mix voice tracks first so we know exact speech segments for Auto-Ducking
            active.forEach { track ->
                when {
                    track.kind == AudioTrackKind.VOICE.name -> mixIntoBus(track, voiceBus, recordEnvelope = true)
                    track.kind == AudioTrackKind.MUSIC.name && track.autoDuckMusic -> mixIntoBus(track, duckedMusicBus, recordEnvelope = false)
                    else -> mixIntoBus(track, otherBus, recordEnvelope = false)
                }
            }
            if (!wroteAny) return null

            // Smooth attack/release voice ducking gain envelope (ducks BGM smoothly down to 28% during speech)
            var currentGain = 1.0f
            val attackCoeff = 0.004f
            val releaseCoeff = 0.0005f
            return ShortArray(totalSamples) { i ->
                val isVoiceActive = voiceEnvelope[i] > 0.045f
                val targetGain = if (isVoiceActive) 0.28f else 1.0f
                val coeff = if (targetGain < currentGain) attackCoeff else releaseCoeff
                currentGain += (targetGain - currentGain) * coeff
                val combined = voiceBus[i] + otherBus[i] + duckedMusicBus[i] * currentGain
                combined.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        /**
         * Resolves a manual Frame or Second interval setting into exact integer frame count at [fps].
         */
        fun resolveIntervalFrames(
            framesValue: Int,
            secondsValue: Float,
            useSeconds: Boolean,
            fps: Int,
            minFrames: Int = 1,
            maxFrames: Int = 240
        ): Int {
            val safeFps = fps.coerceAtLeast(1)
            val raw = if (useSeconds) {
                kotlin.math.round(secondsValue.coerceIn(0.05f, 10.0f) * safeFps).toInt()
            } else {
                framesValue
            }
            return raw.coerceIn(minFrames, maxFrames)
        }

        fun resolveLipSyncIntervalFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.lipSyncIntervalFrames,
                secondsValue = timing.lipSyncIntervalSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 1,
                maxFrames = 120
            )

        fun resolveBlinkIntervalFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.blinkIntervalFrames,
                secondsValue = timing.blinkIntervalSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 4,
                maxFrames = 300
            )

        fun resolveBlinkDurationFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.blinkDurationFrames,
                secondsValue = timing.blinkDurationSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 1,
                maxFrames = 36
            )

        fun resolveEmotionCycleFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.emotionLoopSpeedFrames,
                secondsValue = timing.emotionLoopSpeedSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 1,
                maxFrames = 120
            )

        /**
         * Evaluates smooth multi-stage eye blink phase (OPEN -> HALF_BLINK -> CLOSED -> HALF_BLINK -> OPEN)
         * governed strictly by the user's manual Frame or Second blink interval and hold duration.
         */
        fun evaluateBlinkPhase(frame: Int, fps: Int, timing: FacialTimingConfig): BlinkPhase {
            val period = resolveBlinkIntervalFrames(timing, fps)
            val dur = resolveBlinkDurationFrames(timing, fps).coerceAtMost((period - 1).coerceAtLeast(1))
            val safeFrame = frame.coerceAtLeast(0)
            val phase = safeFrame % period
            if (phase >= dur) return BlinkPhase.OPEN
            return when {
                dur <= 1 -> BlinkPhase.CLOSED
                dur == 2 -> if (phase == 0) BlinkPhase.HALF_BLINK else BlinkPhase.CLOSED
                phase == 0 || phase == dur - 1 -> BlinkPhase.HALF_BLINK
                else -> BlinkPhase.CLOSED
            }
        }

        /**
         * Evaluates normalized voice waveform energy (0f..1f) stepped at the user's exact Lip-Sync Change Interval.
         */
        fun evaluateVoiceEnergyWithTiming(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            timing: FacialTimingConfig = FacialTimingConfig()
        ): Pair<Float, Int> {
            val voiceTracks = audioTracks.filter { !it.muted && it.waveformPeaks.isNotEmpty() }
                .sortedByDescending { it.kind == AudioTrackKind.VOICE.name }
            if (voiceTracks.isEmpty()) return 0f to 0

            val safeFps = fps.coerceAtLeast(1)
            val stepFrames = resolveLipSyncIntervalFrames(timing, safeFps)
            val stepBucket = frame.coerceAtLeast(0) / stepFrames
            val sampledFrame = stepBucket * stepFrames

            var maxEnergy = 0f
            for (track in voiceTracks) {
                val clipFrames = (((track.trimEndMs - track.trimStartMs).coerceAtLeast(200L) / 1000f) * safeFps)
                    .toInt().coerceAtLeast(1)
                if (sampledFrame >= track.startFrame && sampledFrame < track.startFrame + clipFrames) {
                    val rel = (sampledFrame - track.startFrame).toFloat() / clipFrames.toFloat()
                    val idx = (rel * track.waveformPeaks.size).toInt().coerceIn(0, track.waveformPeaks.lastIndex)
                    val energy = track.waveformPeaks[idx] * track.volume
                    if (energy > maxEnergy) maxEnergy = energy
                }
            }
            return maxEnergy.coerceIn(0f, 1.2f) to stepBucket
        }

        /**
         * Evaluates voice audio energy stepped cleanly at the user's exact Lip-Sync Change Interval
         * (frames or seconds) so mouth transitions never jitter faster than configured.
         */
        fun evaluateLipSyncPhonemeWithTiming(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            timing: FacialTimingConfig = FacialTimingConfig()
        ): MouthPhoneme {
            val (maxEnergy, stepBucket) = evaluateVoiceEnergyWithTiming(audioTracks, frame, fps, timing)
            return when {
                maxEnergy < 0.14f -> MouthPhoneme.REST
                maxEnergy < 0.30f -> MouthPhoneme.HALF_OPEN
                maxEnergy < 0.50f -> if (stepBucket % 2 == 0) MouthPhoneme.E else MouthPhoneme.I
                maxEnergy < 0.72f -> if (stepBucket % 2 == 0) MouthPhoneme.O else MouthPhoneme.U
                else -> MouthPhoneme.A
            }
        }

        /**
         * Module 5: Smart Auto-Dubbing 6-Frame Mouth Mood Evaluator.
         * - During voice speech: automatically triggers Frames 3..6 driven by audio amplitude & lip-sync interval.
         * - During silent pauses: automatically falls back to Frames 1..2 while preserving the active emotion
         *   (e.g., Crying stays silently crying on Frame 2 during pauses instead of snapping to neutral!).
         */
        fun evaluateMouthMoodFrame(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            timing: FacialTimingConfig = FacialTimingConfig(),
            activeMouthMood: String = com.example.data.model.FaceMoodCategory.NORMAL.name
        ): Int {
            val (energy, stepBucket) = evaluateVoiceEnergyWithTiming(audioTracks, frame, fps, timing)
            val isSilent = energy < 0.14f
            if (isSilent) {
                val emoCycle = resolveEmotionCycleFrames(timing, fps).coerceAtLeast(2)
                val isExpressiveMood = activeMouthMood != com.example.data.model.FaceMoodCategory.NORMAL.name
                return if (isExpressiveMood) {
                    if ((frame / emoCycle) % 3 == 0) 1 else 2
                } else {
                    if ((frame / (emoCycle * 2)) % 4 == 0) 2 else 1
                }
            }
            return when {
                energy < 0.30f -> 3 // Soft speech
                energy < 0.52f -> 4 // Medium speech
                energy < 0.74f -> if (stepBucket % 3 == 0) 6 else 5 // Wide speech with accent
                else -> 6 // Peak emotion accent
            }
        }

        /**
         * Module 6: Auto-Dialogue Head Bounce.
         * Returns (headNodDeg in -6f..6f, chinBouncePx in 0f..5f) synced to voice syllables when speaking.
         */
        fun evaluateDialogueHeadBounce(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            enabled: Boolean,
            timing: FacialTimingConfig = FacialTimingConfig()
        ): Pair<Float, Float> {
            if (!enabled) return 0f to 0f
            val (energy, _) = evaluateVoiceEnergyWithTiming(audioTracks, frame, fps, timing)
            if (energy < 0.14f) return 0f to 0f
            val intensity = ((energy - 0.14f) / 0.86f).coerceIn(0f, 1f)
            val syllableWave = sin(frame * 0.62).toFloat()
            val nodDeg = (syllableWave * (1.2f + intensity * 4.8f)).coerceIn(-6f, 6f)
            val chinBouncePx = (kotlin.math.abs(syllableWave) * intensity * 4.2f).coerceIn(0f, 5f)
            return nodDeg to chinBouncePx
        }
    }
}
