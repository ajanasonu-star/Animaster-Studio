package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.CustomEyeSlot
import com.example.data.model.CustomMouthSlot
import com.example.data.model.FaceMoodCategory
import com.example.data.model.HandGesturePose
import com.example.data.model.ScreenMode
import com.example.ui.components.ScreenSettingsDialog
import com.example.ui.screens.CharacterRigStudioScreen
import com.example.ui.screens.EditorWorkspaceScreen
import com.example.ui.screens.FrameByFrameCelStudioScreen
import com.example.ui.screens.ProjectHubScreen
import com.example.ui.theme.AnimasterStudioTheme
import com.example.ui.viewmodel.StudioDestination
import com.example.ui.viewmodel.StudioViewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnimasterStudioTheme {
                AnimasterAppRoot()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        // Module 11: Silent crash-recovery snapshot whenever app is backgrounded
        runCatching {
            ViewModelProvider(this)[StudioViewModel::class.java].saveCrashRecoverySnapshotNow()
        }
    }
}

@Composable
private fun AnimasterAppRoot(
    viewModel: StudioViewModel = viewModel()
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val baseDensity = LocalDensity.current

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val recoverySnapshot by viewModel.recoverySnapshot.collectAsStateWithLifecycle()
    val localAssets by viewModel.localAssets.collectAsStateWithLifecycle()
    val myCharacters by viewModel.myCharacters.collectAsStateWithLifecycle()
    val customAssets by viewModel.customAssets.collectAsStateWithLifecycle()
    val customActions by viewModel.customActions.collectAsStateWithLifecycle()

    // Apply User's Screen & Display Orientation Preference live
    LaunchedEffect(uiState.displaySettings.screenMode) {
        activity?.requestedOrientation = when (uiState.displaySettings.screenMode) {
            ScreenMode.AUTO_RESPONSIVE -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            ScreenMode.LOCK_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ScreenMode.LOCK_PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    // Zero-permission Android Photo Picker for PNG/JPG canvas import
    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importImageFromUri(uri)
    }

    // Zero-permission Android Photo Picker for MP4/WebM Video Background / Reference import
    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importVideoLayerFromUri(uri)
    }

    // Zero-permission Android Photo Picker for PNG Body Part bound to a specific bone in Character & Rig Studio
    var pendingBoneIdForImage by remember { mutableStateOf<String?>(null) }
    val pickBonePartImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val boneId = pendingBoneIdForImage
        pendingBoneIdForImage = null
        if (uri != null && boneId != null) {
            viewModel.bindPickedImageToDraftBone(boneId, uri)
        }
    }

    // Zero-permission Android Photo Picker for Single-Image 2D Mesh Skinning in Character & Rig Studio
    val pickSingleMeshImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.bindPickedImageToDraftSingleMesh(uri)
    }

    // Zero-permission Android Photo Picker for attaching any custom PNG into Left or Right Hand
    var pendingHandTargetIsRight by remember { mutableStateOf(true) }
    var pendingHandTargetIsStudioDraft by remember { mutableStateOf(false) }
    val pickHandPropPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            if (pendingHandTargetIsStudioDraft) {
                viewModel.setStudioDraftHandCustomPng(pendingHandTargetIsRight, uri)
            } else {
                viewModel.setPuppetHandCustomPng(pendingHandTargetIsRight, uri)
            }
        }
    }

    // Zero-permission Android Photo Picker for attaching a custom PNG onto an Extra Variable Rig Bone on any area
    var pendingExtraRigArea by remember { mutableStateOf(com.example.engine.RigAttachmentArea.RIGHT_HAND) }
    val pickExtraRigPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.attachCustomPngToNewExtraBone(pendingExtraRigArea, uri)
        }
    }

    // Zero-permission Android Photo Picker for Custom Eye & Mouth PNG multi-pose slots in Character & Rig Studio
    var pendingEyeSlot by remember { mutableStateOf<CustomEyeSlot?>(null) }
    val pickEyeSlotPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val slot = pendingEyeSlot
        pendingEyeSlot = null
        if (uri != null && slot != null) {
            viewModel.bindPickedImageToDraftEyeSlot(slot, uri)
        }
    }

    var pendingMouthSlot by remember { mutableStateOf<CustomMouthSlot?>(null) }
    val pickMouthSlotPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val slot = pendingMouthSlot
        pendingMouthSlot = null
        if (uri != null && slot != null) {
            viewModel.bindPickedImageToDraftMouthSlot(slot, uri)
        }
    }

    // Modules 4, 5 & 8: Zero-permission Android Photo Pickers for Unified Eye Layers, Mood Sets, Custom Nose & Hand Poses
    var pendingEyeContainerTarget by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    val pickEyeContainerPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = pendingEyeContainerTarget
        pendingEyeContainerTarget = null
        if (uri != null && target != null) {
            viewModel.importStudioEyeContainerPartFromUri(target.first, target.second, uri)
        }
    }

    var pendingEyeMoodSlotTarget by remember { mutableStateOf<Pair<FaceMoodCategory, String>?>(null) }
    val pickEyeMoodSlotPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = pendingEyeMoodSlotTarget
        pendingEyeMoodSlotTarget = null
        if (uri != null && target != null) {
            viewModel.importStudioEyeMoodSlotFromUri(target.first, target.second, uri)
        }
    }

    var pendingMouthMoodSlotTarget by remember { mutableStateOf<Pair<FaceMoodCategory, Int>?>(null) }
    val pickMouthMoodSlotPngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val target = pendingMouthMoodSlotTarget
        pendingMouthMoodSlotTarget = null
        if (uri != null && target != null) {
            viewModel.importStudioMouthMoodSlotFromUri(target.first, target.second, uri)
        }
    }

    val pickCustomNosePngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.importStudioCustomNoseFromUri(uri)
        }
    }

    var pendingCustomHandPose by remember { mutableStateOf<HandGesturePose?>(null) }
    val pickCustomHandPosePngLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val pose = pendingCustomHandPose
        pendingCustomHandPose = null
        if (uri != null && pose != null) {
            viewModel.importStudioCustomHandPoseFromUri(pose, uri)
        }
    }

    // SAF OpenDocument for SVG import
    val importSvgLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importSvgFromUri(uri)
    }

    // SAF OpenDocument for Audio file import
    val importAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val resolvedName = runCatching {
                context.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
            }.getOrNull()
            val name = resolvedName?.takeIf { it.isNotBlank() }
                ?: uri.lastPathSegment?.substringAfterLast('/')
                ?: "Audio Track"
            viewModel.importAudioFromUri(uri, name)
        }
    }

    // Zero-permission Photo Picker for Channel Brand Watermark Logo PNG (Module 9)
    val pickWatermarkLogoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importWatermarkLogoFromUri(uri)
    }

    // SAF OpenDocument for Portable .animaster ZIP or Legacy JSON project import (Module 10)
    val importProjectLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importProjectFromUri(uri)
    }

    // SAF CreateDocument for Portable .animaster ZIP Project Backup (bundles project.json + all PNG/audio assets!)
    var pendingBackupProjectId by remember { mutableStateOf<String?>(null) }
    val exportProjectArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val pid = pendingBackupProjectId
        pendingBackupProjectId = null
        if (uri != null) viewModel.exportProjectArchiveToUri(projectId = pid, targetUri = uri)
    }

    // SAF CreateDocument / OpenDocument for Portable Character/Rig Backup & Restore (.animaster-rig)
    val exportDraftRigLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) viewModel.exportDraftRigToUri(uri)
    }
    val importDraftRigLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importDraftRigFromUri(uri)
    }

    // SAF CreateDocument for saving rendered PNG / ZIP / GIF / MP4 / WebM to any folder on the phone
    var pendingExportSaveFile by remember { mutableStateOf<File?>(null) }
    val saveExportToDeviceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val src = pendingExportSaveFile
        pendingExportSaveFile = null
        if (uri != null && src != null) {
            viewModel.saveExportFileToUri(src, uri)
        }
    }

    // Runtime RECORD_AUDIO permission launcher for Voice Recording
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startVoiceRecording()
        } else {
            viewModel.showToast("Microphone permission is needed to record voice")
        }
    }

    // Apply User UI Scale Setting (75%, 85%, 100%, 115%) cleanly via CompositionLocal Density
    val uiScale = uiState.displaySettings.uiScale.coerceIn(0.75f, 1.15f)
    val scaledDensity = remember(baseDensity, uiScale) {
        Density(
            density = baseDensity.density * uiScale,
            fontScale = baseDensity.fontScale * uiScale
        )
    }

    CompositionLocalProvider(LocalDensity provides scaledDensity) {
        when (uiState.destination) {
            StudioDestination.CEL_STUDIO -> {
                FrameByFrameCelStudioScreen(viewModel = viewModel)
            }

            StudioDestination.CHARACTER_RIG_STUDIO -> {
                CharacterRigStudioScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onPickImageForBone = { boneId ->
                        pendingBoneIdForImage = boneId
                        pickBonePartImageLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickSingleMeshImage = {
                        pickSingleMeshImageLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickHandPropPng = { isRightHand ->
                        pendingHandTargetIsRight = isRightHand
                        pendingHandTargetIsStudioDraft = true
                        pickHandPropPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickEyeSlotPng = { slot ->
                        pendingEyeSlot = slot
                        pickEyeSlotPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickMouthSlotPng = { slot ->
                        pendingMouthSlot = slot
                        pickMouthSlotPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickEyeContainerPng = { isRight, subLayer ->
                        pendingEyeContainerTarget = isRight to subLayer
                        pickEyeContainerPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickEyeMoodSlotPng = { mood, slotKey ->
                        pendingEyeMoodSlotTarget = mood to slotKey
                        pickEyeMoodSlotPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickMouthMoodSlotPng = { mood, frameIdx ->
                        pendingMouthMoodSlotTarget = mood to frameIdx
                        pickMouthMoodSlotPngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickCustomNosePng = {
                        pickCustomNosePngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickCustomHandPosePng = { pose ->
                        pendingCustomHandPose = pose
                        pickCustomHandPosePngLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onExportRigBackup = {
                        val safe = uiState.studioDraftRig.name.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "character" }
                        exportDraftRigLauncher.launch("${safe}.animaster")
                    },
                    onImportRigBackup = {
                        importDraftRigLauncher.launch(arrayOf("*/*"))
                    }
                )
            }

            StudioDestination.EDITOR -> {
                if (uiState.activeProject != null) {
                    EditorWorkspaceScreen(
                        viewModel = viewModel,
                        uiState = uiState,
                        localAssets = localAssets,
                        myCharacters = myCharacters,
                        customAssets = customAssets,
                        customActions = customActions,
                        onBackToHub = { viewModel.closeProjectToHub() },
                        onImportImage = {
                            pickImageLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onImportHandPropPng = { isRightHand ->
                            pendingHandTargetIsRight = isRightHand
                            pendingHandTargetIsStudioDraft = false
                            pickHandPropPngLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onImportExtraRigPng = { area ->
                            pendingExtraRigArea = area
                            pickExtraRigPngLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onImportWatermarkLogo = {
                            pickWatermarkLogoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onImportSvg = { importSvgLauncher.launch(arrayOf("image/svg+xml", "text/xml", "*/*")) },
                        onImportVideo = {
                            pickVideoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        onImportAudio = { importAudioLauncher.launch(arrayOf("audio/*")) },
                        onRequestRecordVoice = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                viewModel.startVoiceRecording()
                            } else {
                                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        onExportProjectJson = {
                            pendingBackupProjectId = uiState.activeProject?.id
                            val safe = (uiState.activeProject?.name ?: "project").replace(Regex("[^A-Za-z0-9_\\-]"), "_")
                            exportProjectArchiveLauncher.launch("${safe}.animaster")
                        },
                        onSaveExportedToDevice = { file, _ ->
                            pendingExportSaveFile = file
                            saveExportToDeviceLauncher.launch(file.name)
                        },
                        onShareExportedFile = { file, mime ->
                            runCatching {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    file
                                )
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = mime
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share Exported Animation"))
                            }.onFailure {
                                viewModel.showToast("Could not open share sheet")
                            }
                        }
                    )
                } else {
                    ProjectHubScreen(
                        projects = projects,
                        myCharacters = myCharacters,
                        recoverySnapshot = recoverySnapshot,
                        statusBanner = uiState.statusBanner,
                        onOpenProject = { viewModel.openProject(it) },
                        onCreateProject = { name, w, h, fps, tpl ->
                            viewModel.createNewProject(name, w, h, fps, tpl)
                        },
                        onDeleteProject = { viewModel.deleteProject(it) },
                        onDeleteMyCharacter = { viewModel.deleteMyCharacter(it) },
                        onImportProject = { importProjectLauncher.launch(arrayOf("*/*")) },
                        onBackupProject = { summary ->
                            pendingBackupProjectId = summary.id
                            val safe = summary.name.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "project" }
                            exportProjectArchiveLauncher.launch("${safe}.animaster")
                        },
                        onOpenCharacterRigStudio = { viewModel.openCharacterRigStudio(it) },
                        onOpenCelStudio = { viewModel.openCelStudio() },
                        onOpenScreenSettings = { viewModel.openScreenSettingsDialog(true) },
                        onRecoverAutosave = { viewModel.recoverAutosave(it) },
                        onDismissRecovery = { viewModel.dismissRecovery() }
                    )
                }
            }

            StudioDestination.HUB -> {
                ProjectHubScreen(
                    projects = projects,
                    myCharacters = myCharacters,
                    recoverySnapshot = recoverySnapshot,
                    statusBanner = uiState.statusBanner,
                    onOpenProject = { viewModel.openProject(it) },
                    onCreateProject = { name, w, h, fps, tpl ->
                        viewModel.createNewProject(name, w, h, fps, tpl)
                    },
                    onDeleteProject = { viewModel.deleteProject(it) },
                    onDeleteMyCharacter = { viewModel.deleteMyCharacter(it) },
                    onImportProject = { importProjectLauncher.launch(arrayOf("*/*")) },
                    onBackupProject = { summary ->
                        pendingBackupProjectId = summary.id
                        val safe = summary.name.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "project" }
                        exportProjectArchiveLauncher.launch("${safe}.animaster")
                    },
                    onOpenCharacterRigStudio = { viewModel.openCharacterRigStudio(it) },
                    onOpenCelStudio = { viewModel.openCelStudio() },
                    onOpenScreenSettings = { viewModel.openScreenSettingsDialog(true) },
                    onRecoverAutosave = { viewModel.recoverAutosave(it) },
                    onDismissRecovery = { viewModel.dismissRecovery() }
                )
            }
        }

        // Global Screen & Display Settings Dialog (accessible from both Project Hub & Editor Top Bar)
        if (uiState.showScreenSettingsDialog) {
            ScreenSettingsDialog(
                settings = uiState.displaySettings,
                showFitStageAction = uiState.destination == StudioDestination.EDITOR && uiState.activeProject != null,
                fastProxyPreviewMode = uiState.fastProxyPreviewMode,
                onToggleFastProxyPreviewMode = { viewModel.toggleFastProxyPreviewMode() },
                onSelectScreenMode = { viewModel.setScreenMode(it) },
                onSelectUiScale = { viewModel.setUiScale(it) },
                onFitStageToScreen = {
                    viewModel.resetCanvasViewport()
                    viewModel.showToast("Stage fitted to screen")
                },
                onDismiss = { viewModel.openScreenSettingsDialog(false) }
            )
        }
    }
}
