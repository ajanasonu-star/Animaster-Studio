package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.LocalAssetEntity
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FaceComboPreset
import com.example.data.model.FaceMoodCategory
import com.example.data.model.MouthPhoneme
import com.example.data.model.NoseStylePreset
import com.example.data.model.SkeletalRig
import com.example.engine.CharacterCodeParser
import com.example.engine.EvaluatedPuppetRoot
import com.example.engine.InterpolationEngine
import com.example.engine.SceneRenderer
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import java.io.File
import kotlin.math.roundToInt

/**
 * Module 2: In-Project Image & Part Library Picker Dialog.
 * Lists every PNG previously imported or sketched in the project so users never re-import from Gallery.
 */
@Composable
fun ProjectImageLibraryDialog(
    title: String = "Project Image & Part Library",
    images: List<LocalAssetEntity>,
    onSelectPath: (String) -> Unit,
    onImportNewFromGallery: (() -> Unit)? = null,
    onOpenSketcher: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 560.dp)
                .border(1.dp, StudioBorder, RoundedCornerShape(18.dp))
                .testTag("project_image_library_dialog"),
            shape = RoundedCornerShape(18.dp),
            color = PanelSurface
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Collections, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(20.dp))
                        Text(title, color = StudioTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close Library", tint = StudioTextSecondary)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (onImportNewFromGallery != null) {
                        Button(
                            onClick = {
                                onDismiss()
                                onImportNewFromGallery()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCyan),
                            modifier = Modifier.weight(1f).testTag("library_pick_gallery_btn")
                        ) {
                            Text("Import From Gallery", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                    if (onOpenSketcher != null) {
                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onOpenSketcher()
                            },
                            modifier = Modifier.weight(1f).testTag("library_open_sketcher_btn")
                        ) {
                            Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(16.dp), tint = StudioCoral)
                            Spacer(Modifier.width(4.dp))
                            Text("Draw / Cut Part", color = StudioCoral, fontSize = 12.sp)
                        }
                    }
                }

                HorizontalDivider(color = StudioBorder)

                val validImages = remember(images) {
                    images.filter { it.filePath.isNotBlank() && File(it.filePath).exists() }
                }

                if (validImages.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No saved project PNG parts yet.\nImport from Gallery or Draw / Cut a transparent part!",
                            color = StudioTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 94.dp),
                        modifier = Modifier.weight(1f, fill = false).heightIn(max = 360.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(validImages, key = { it.id }) { item ->
                            val thumb = remember(item.filePath) {
                                runCatching {
                                    val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                                    BitmapFactory.decodeFile(item.filePath, opts)?.asImageBitmap()
                                }.getOrNull()
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PanelElevated,
                                border = BorderStroke(1.dp, StudioBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        onSelectPath(item.filePath)
                                        onDismiss()
                                    }
                            ) {
                                Column(
                                    modifier = Modifier.padding(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(1f)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF1E2433)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (thumb != null) {
                                            Image(
                                                bitmap = thumb,
                                                contentDescription = item.name,
                                                contentScale = ContentScale.Fit,
                                                modifier = Modifier.fillMaxSize().padding(4.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = item.name,
                                        color = StudioTextPrimary,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class SketchStroke(
    val points: List<Offset>,
    val color: Color,
    val widthPx: Float,
    val isEraser: Boolean
)

/**
 * Module 10: Dedicated Transparent Part Sketcher ("Draw / Cut Face Part") + 1-Tap Magic Background Eraser.
 */
@Composable
fun PartSketcherAndMagicEraserDialog(
    projectImages: List<LocalAssetEntity>,
    onSaveSketchedBitmap: (Bitmap, String) -> Unit,
    onEraseBackgroundColor: (sourcePath: String, xNorm: Float, yNorm: Float, tolerance: Int) -> Unit,
    onDismiss: () -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) } // 0 = Draw Transparent PNG, 1 = Magic Background Eraser
    var partName by remember { mutableStateOf("face_part") }
    var brushColorArgb by remember { mutableStateOf(0xFF111827L) }
    val brushColor = Color(brushColorArgb.toInt())
    var brushWidth by remember { mutableFloatStateOf(14f) }
    var eraserMode by remember { mutableStateOf(false) }
    val strokes = remember { mutableStateListOf<SketchStroke>() }
    var activePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var canvasPxSize by remember { mutableStateOf(Size(512f, 512f)) }

    // Magic Background Eraser state
    val validImages = remember(projectImages) {
        projectImages.filter { it.filePath.isNotBlank() && File(it.filePath).exists() }
    }
    var selectedImagePath by remember(validImages) { mutableStateOf(validImages.firstOrNull()?.filePath) }
    var sampleXNorm by remember { mutableFloatStateOf(0.05f) }
    var sampleYNorm by remember { mutableFloatStateOf(0.05f) }
    var magicTolerance by remember { mutableFloatStateOf(46f) }

    val quickColors = listOf(
        0xFF111827L, 0xFFFFFFFFL, 0xFFE11D48L, 0xFFF97316L,
        0xFFFACC15L, 0xFF22C55EL, 0xFF38BDF8L, 0xFFA855F7L,
        0xFFF4C2A1L, 0xFF8D5524L
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 640.dp)
                .border(1.dp, StudioBorder, RoundedCornerShape(18.dp))
                .testTag("part_sketcher_magic_eraser_dialog"),
            shape = RoundedCornerShape(18.dp),
            color = PanelSurface
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Transparent Part Sketcher & Magic Eraser", color = StudioTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        label = { Text("Draw Transparent PNG", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(15.dp)) },
                        modifier = Modifier.testTag("tab_draw_transparent_png")
                    )
                    FilterChip(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        label = { Text("Magic BG Eraser", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(15.dp)) },
                        modifier = Modifier.testTag("tab_magic_bg_eraser")
                    )
                }

                if (activeTab == 0) {
                    OutlinedTextField(
                        value = partName,
                        onValueChange = { partName = it },
                        label = { Text("Part Name (e.g. happy_eye, angry_mouth)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Checkerboard transparent sketchpad
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.5.dp, StudioCyan, RoundedCornerShape(12.dp))
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(brushColor, brushWidth, eraserMode) {
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            canvasPxSize = Size(size.width.toFloat(), size.height.toFloat())
                                            activePoints = listOf(offset)
                                        },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            activePoints = activePoints + change.position
                                        },
                                        onDragEnd = {
                                            if (activePoints.isNotEmpty()) {
                                                strokes.add(SketchStroke(activePoints, brushColor, brushWidth, eraserMode))
                                            }
                                            activePoints = emptyList()
                                        }
                                    )
                                }
                        ) {
                            canvasPxSize = size
                            // Draw checkerboard background so transparency is crystal clear
                            val cell = 16.dp.toPx()
                            var row = 0
                            var y = 0f
                            while (y < size.height) {
                                var col = 0
                                var x = 0f
                                while (x < size.width) {
                                    drawRect(
                                        color = if ((row + col) % 2 == 0) Color(0xFF283044) else Color(0xFF1D2434),
                                        topLeft = Offset(x, y),
                                        size = Size(cell, cell)
                                    )
                                    x += cell
                                    col++
                                }
                                y += cell
                                row++
                            }

                            fun drawList(list: List<Offset>, c: Color, w: Float) {
                                if (list.size == 1) {
                                    drawCircle(c, radius = w * 0.5f, center = list.first())
                                } else if (list.size > 1) {
                                    val path = androidx.compose.ui.graphics.Path().apply {
                                        moveTo(list.first().x, list.first().y)
                                        for (i in 1 until list.size) lineTo(list[i].x, list[i].y)
                                    }
                                    drawPath(
                                        path = path,
                                        color = c,
                                        style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                    )
                                }
                            }

                            strokes.forEach { st ->
                                drawList(st.points, if (st.isEraser) Color(0xFF1D2434) else st.color, st.widthPx)
                            }
                            if (activePoints.isNotEmpty()) {
                                drawList(activePoints, if (eraserMode) Color(0xFF1D2434) else brushColor, brushWidth)
                            }
                        }
                    }

                    // Color Palette + Hue / Saturation / Brightness Sliders
                    ProColorPickerWithSliders(
                        label = "Sketcher Brush Color",
                        selectedColorArgb = brushColorArgb,
                        onColorChanged = { argb ->
                            eraserMode = false
                            brushColorArgb = argb
                        },
                        presets = quickColors,
                        accentColor = StudioCyan,
                        initiallyExpanded = true,
                        testTagPrefix = "part_sketcher_color"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = eraserMode,
                            onClick = { eraserMode = !eraserMode },
                            label = { Text("Eraser", fontSize = 11.sp) }
                        )
                        IconButton(onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) }) {
                            Icon(Icons.Default.Undo, contentDescription = "Undo Stroke", tint = StudioTextPrimary)
                        }
                        IconButton(onClick = { strokes.clear() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear Sketchpad", tint = StudioCoral)
                        }
                        Text("Size ${brushWidth.toInt()}", color = StudioTextSecondary, fontSize = 11.sp)
                        Slider(
                            value = brushWidth,
                            onValueChange = { brushWidth = it },
                            valueRange = 4f..44f,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Button(
                        onClick = {
                            val outSize = 512
                            val bmp = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
                            val c = android.graphics.Canvas(bmp)
                            val sx = outSize / canvasPxSize.width.coerceAtLeast(1f)
                            val sy = outSize / canvasPxSize.height.coerceAtLeast(1f)
                            strokes.forEach { st ->
                                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    style = Paint.Style.STROKE
                                    strokeCap = Paint.Cap.ROUND
                                    strokeJoin = Paint.Join.ROUND
                                    strokeWidth = st.widthPx * ((sx + sy) * 0.5f)
                                    if (st.isEraser) {
                                        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                                    } else {
                                        color = st.color.toArgb()
                                    }
                                }
                                if (st.points.size == 1) {
                                    p.style = Paint.Style.FILL
                                    c.drawCircle(st.points[0].x * sx, st.points[0].y * sy, p.strokeWidth * 0.5f, p)
                                } else if (st.points.size > 1) {
                                    val path = Path().apply {
                                        moveTo(st.points[0].x * sx, st.points[0].y * sy)
                                        for (i in 1 until st.points.size) lineTo(st.points[i].x * sx, st.points[i].y * sy)
                                    }
                                    c.drawPath(path, p)
                                }
                            }
                            onSaveSketchedBitmap(bmp, partName.ifBlank { "face_part" })
                            onDismiss()
                        },
                        enabled = strokes.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = StudioEmerald),
                        modifier = Modifier.fillMaxWidth().height(46.dp).testTag("save_transparent_png_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Save Transparent PNG to Library", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Tab 1: 1-Tap Magic Background Eraser
                    Text(
                        "Select any imported image below, tap its background color to sample, then click Erase Background!",
                        color = StudioTextSecondary,
                        fontSize = 11.sp
                    )
                    if (validImages.isEmpty()) {
                        Text("Import an image first to use Magic Background Eraser.", color = StudioAmber, fontSize = 12.sp)
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            validImages.take(12).forEach { img ->
                                FilterChip(
                                    selected = selectedImagePath == img.filePath,
                                    onClick = { selectedImagePath = img.filePath },
                                    label = { Text(img.name, fontSize = 11.sp, maxLines = 1) }
                                )
                            }
                        }

                        val previewBmp = remember(selectedImagePath) {
                            selectedImagePath?.let { p ->
                                runCatching {
                                    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                                    BitmapFactory.decodeFile(p, opts)?.asImageBitmap()
                                }.getOrNull()
                            }
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1A2232))
                                .border(1.dp, StudioViolet, RoundedCornerShape(12.dp))
                                .pointerInput(Unit) {
                                    detectTapGestures { pos ->
                                        sampleXNorm = (pos.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                                        sampleYNorm = (pos.y / size.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (previewBmp != null) {
                                Image(
                                    bitmap = previewBmp,
                                    contentDescription = "Tap background to erase",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val cx = sampleXNorm * size.width
                                val cy = sampleYNorm * size.height
                                drawCircle(StudioCoral, radius = 12f, center = Offset(cx, cy), style = Stroke(3f))
                                drawCircle(Color.White, radius = 4f, center = Offset(cx, cy))
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Color Tolerance: ${magicTolerance.roundToInt()}", color = StudioTextPrimary, fontSize = 12.sp)
                            Spacer(Modifier.width(10.dp))
                            Slider(
                                value = magicTolerance,
                                onValueChange = { magicTolerance = it },
                                valueRange = 10f..140f,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Button(
                            onClick = {
                                val p = selectedImagePath ?: return@Button
                                onEraseBackgroundColor(p, sampleXNorm, sampleYNorm, magicTolerance.roundToInt())
                                onDismiss()
                            },
                            enabled = selectedImagePath != null,
                            colors = ButtonDefaults.buttonColors(containerColor = StudioViolet),
                            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("apply_magic_bg_eraser_btn")
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Erase Background & Save Transparent PNG", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Modules 4, 5 & 6: Collapsible On-Stage Face & Mood Swapper Dock.
 * Supports separate Eye/Mouth Mood Sets, Interactive Eye-Look Joystick, Sync/Unlink Pupils,
 * 2.5D Face Turn Parallax, Independent Left & Right Eyebrows, Noses, Combos, and Face FX Horror Triggers.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FaceAndMoodSwapperDock(
    rig: SkeletalRig,
    currentFrame: Int,
    onSelectEyeMood: (FaceMoodCategory) -> Unit,
    onSelectMouthMood: (FaceMoodCategory) -> Unit,
    onSelectEyePack: (EyePackStyle) -> Unit,
    onSelectMouthPhoneme: (MouthPhoneme) -> Unit,
    onSetPupilLook: (lx: Float, ly: Float, rx: Float, ry: Float) -> Unit,
    onToggleSyncPupils: () -> Unit,
    onSelectNoseStyle: (NoseStylePreset) -> Unit,
    onSetHeadTurn25D: (Float) -> Unit,
    onToggleDialogueHeadBounce: () -> Unit,
    onSelectLeftEyebrow: (EyebrowStyle) -> Unit,
    onSelectRightEyebrow: (EyebrowStyle) -> Unit,
    onSaveCombo: (String) -> Unit,
    onApplyCombo: (FaceComboPreset) -> Unit,
    onTriggerFaceFx: (name: String, duration: Int, flashColor: Long?) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val eval = remember(rig, currentFrame) { InterpolationEngine.evaluatePuppetRoot(rig, currentFrame) }
    var activeTab by remember { mutableIntStateOf(0) } // 0=Mood Sets, 1=Eyes, 2=Mouths, 3=Noses, 4=2.5D/Brows, 5=FX/Combos
    var comboName by remember { mutableStateOf("") }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(max = 250.dp)
            .border(1.5.dp, StudioCyan.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
            .testTag("face_mood_swapper_dock"),
        shape = RoundedCornerShape(16.dp),
        color = StudioSurface.copy(alpha = 0.96f),
        shadowElevation = 10.dp
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Face, contentDescription = null, tint = StudioCyan, modifier = Modifier.size(16.dp))
                    Text(
                        "Face & Mood Swapper (F${currentFrame + 1})",
                        color = StudioTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close Face Dock", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                }
            }

            // Tab Strip
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Mood Sets", "Eyes + Joystick", "Mouths", "Noses", "2.5D / Brows", "Combos & FX").forEachIndexed { idx, label ->
                    FilterChip(
                        selected = activeTab == idx,
                        onClick = { activeTab = idx },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }

            when (activeTab) {
                0 -> {
                    Text("EYE MOOD SET (Independent from Mouth)", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        FaceMoodCategory.entries.forEach { mood ->
                            FilterChip(
                                selected = eval.activeEyeMood == mood.name,
                                onClick = { onSelectEyeMood(mood) },
                                label = { Text(mood.label, fontSize = 11.sp) },
                                modifier = Modifier.testTag("stage_eye_mood_${mood.name.lowercase()}")
                            )
                        }
                    }
                    Text("MOUTH MOOD SET (Smart Auto-Dub: Talk F3–6 / Pause F1–2)", color = StudioCoral, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        FaceMoodCategory.entries.forEach { mood ->
                            FilterChip(
                                selected = eval.activeMouthMood == mood.name,
                                onClick = { onSelectMouthMood(mood) },
                                label = { Text(mood.label, fontSize = 11.sp) },
                                modifier = Modifier.testTag("stage_mouth_mood_${mood.name.lowercase()}")
                            )
                        }
                    }
                }

                1 -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Interactive Eye-Look Joystick Pad
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .clip(CircleShape)
                                .background(PanelElevated)
                                .border(1.5.dp, StudioCyan, CircleShape)
                                .pointerInput(rig.syncPupils) {
                                    detectDragGestures { change, _ ->
                                        change.consume()
                                        val cx = size.width / 2f
                                        val cy = size.height / 2f
                                        val r = (minOf(size.width, size.height) * 0.44f).coerceAtLeast(1f)
                                        val nx = ((change.position.x - cx) / r).coerceIn(-1f, 1f)
                                        val ny = ((change.position.y - cy) / r).coerceIn(-1f, 1f)
                                        onSetPupilLook(nx, ny, nx, ny)
                                    }
                                }
                                .testTag("eye_look_joystick_pad"),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val cx = size.width / 2f
                                val cy = size.height / 2f
                                val r = size.minDimension * 0.36f
                                drawLine(StudioBorder, Offset(cx - r, cy), Offset(cx + r, cy), 1f)
                                drawLine(StudioBorder, Offset(cx, cy - r), Offset(cx, cy + r), 1f)
                                drawCircle(
                                    StudioCyan,
                                    radius = 9.dp.toPx(),
                                    center = Offset(cx + eval.leftPupilX * r, cy + eval.leftPupilY * r)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = rig.syncPupils,
                                    onClick = onToggleSyncPupils,
                                    label = { Text(if (rig.syncPupils) "Sync Pupils ON" else "Unlinked Pupils", fontSize = 10.sp) },
                                    leadingIcon = {
                                        Icon(
                                            if (rig.syncPupils) Icons.Default.Link else Icons.Default.LinkOff,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    },
                                    modifier = Modifier.testTag("toggle_sync_pupils_btn")
                                )
                                OutlinedButton(onClick = { onSetPupilLook(0f, 0f, 0f, 0f) }) {
                                    Text("Center", fontSize = 10.sp)
                                }
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(
                                    EyePackStyle.AUTO_BLINK, EyePackStyle.HAPPY, EyePackStyle.ANGRY,
                                    EyePackStyle.SAD_TEARS, EyePackStyle.SURPRISED, EyePackStyle.SCARED_HORROR
                                ).forEach { pack ->
                                    FilterChip(
                                        selected = eval.eyePack == pack.name,
                                        onClick = { onSelectEyePack(pack) },
                                        label = { Text(pack.label, fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        MouthPhoneme.entries.forEach { ph ->
                            FilterChip(
                                selected = eval.mouthPhoneme == ph.name,
                                onClick = { onSelectMouthPhoneme(ph) },
                                label = { Text(ph.label, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                3 -> {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        NoseStylePreset.entries.forEach { nose ->
                            FilterChip(
                                selected = rig.noseStyle == nose.name,
                                onClick = { onSelectNoseStyle(nose) },
                                label = { Text(nose.label, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                4 -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "2.5D Head Turn: ${(eval.headTurn25D * 100f).roundToInt()}%",
                            color = StudioCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.width(126.dp)
                        )
                        Slider(
                            value = eval.headTurn25D,
                            onValueChange = onSetHeadTurn25D,
                            valueRange = -1f..1f,
                            modifier = Modifier.weight(1f).testTag("head_turn_25d_slider")
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Auto-Dialogue Head Nod & Chin Bounce", color = StudioTextPrimary, fontSize = 11.sp)
                        Switch(
                            checked = rig.autoDialogueHeadBounce,
                            onCheckedChange = { onToggleDialogueHeadBounce() }
                        )
                    }
                    Text("Left Eyebrow (Independent)", color = StudioViolet, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        EyebrowStyle.entries.forEach { b ->
                            FilterChip(
                                selected = eval.leftEyebrowStyle == b.name,
                                onClick = { onSelectLeftEyebrow(b) },
                                label = { Text("L: ${b.label}", fontSize = 10.sp) }
                            )
                        }
                    }
                    Text("Right Eyebrow (Independent)", color = StudioAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        EyebrowStyle.entries.forEach { b ->
                            FilterChip(
                                selected = eval.rightEyebrowStyle == b.name,
                                onClick = { onSelectRightEyebrow(b) },
                                label = { Text("R: ${b.label}", fontSize = 10.sp) }
                            )
                        }
                    }
                }

                5 -> {
                    Text("1-TAP FACE FX / HORROR TRIGGERS (Keyframed)", color = StudioCoral, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { onTriggerFaceFx("Horror Scream", 24, 0x55FF1744L) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioCoral),
                            modifier = Modifier.testTag("trigger_horror_face_fx_btn")
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Horror Scream FX", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onTriggerFaceFx("Ghostly Flash", 18, 0x5522D3EEL) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioViolet)
                        ) {
                            Text("Ghost Flash FX", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onTriggerFaceFx("Golden Divine Glow", 20, 0x44FACC15L) },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioAmber)
                        ) {
                            Text("Divine Glow FX", color = Color(0xFF0F172A), fontSize = 11.sp)
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = comboName,
                            onValueChange = { comboName = it },
                            placeholder = { Text("Combo name", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = {
                            onSaveCombo(comboName.ifBlank { "Combo ${rig.savedFaceCombos.size + 1}" })
                            comboName = ""
                        }) {
                            Text("Save Combo", fontSize = 11.sp)
                        }
                    }
                    if (rig.savedFaceCombos.isNotEmpty()) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            rig.savedFaceCombos.forEach { combo ->
                                FilterChip(
                                    selected = false,
                                    onClick = { onApplyCombo(combo) },
                                    label = { Text(combo.name, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Module 4: "Create Character by Code" Builder Dialog.
 * Accepts JSON character definitions + custom SVG vector paths (M/L/Q/C/Z),
 * renders a real-time live character preview canvas, and saves directly into My Characters & Stage/Swap Char.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateCharacterByCodeDialog(
    onSaveAndAdd: (SkeletalRig) -> Unit,
    onDismiss: () -> Unit
) {
    var codeText by remember { mutableStateOf(CharacterCodeParser.DEFAULT_TEMPLATE_JSON) }
    val parseResult = remember(codeText) {
        CharacterCodeParser.parseCharacterCode(codeText)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 700.dp)
                .testTag("create_character_by_code_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = PanelSurface,
            border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Create Character by Code",
                            style = MaterialTheme.typography.titleMedium,
                            color = StudioTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Edit JSON colors, hair, outfit & custom M/L/Q/C/Z vector paths with instant live preview",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioTextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                    }
                }

                // Sample Template Picker Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = codeText == CharacterCodeParser.DEFAULT_TEMPLATE_JSON,
                        onClick = { codeText = CharacterCodeParser.DEFAULT_TEMPLATE_JSON },
                        label = { Text("Cyber Nova", fontSize = 11.sp) },
                        modifier = Modifier.testTag("code_template_cyber_nova")
                    )
                    FilterChip(
                        selected = codeText == CharacterCodeParser.ROYAL_WIZARD_TEMPLATE_JSON,
                        onClick = { codeText = CharacterCodeParser.ROYAL_WIZARD_TEMPLATE_JSON },
                        label = { Text("Royal Wizard", fontSize = 11.sp) },
                        modifier = Modifier.testTag("code_template_royal_wizard")
                    )
                    FilterChip(
                        selected = codeText == CharacterCodeParser.CAPE_NINJA_TEMPLATE_JSON,
                        onClick = { codeText = CharacterCodeParser.CAPE_NINJA_TEMPLATE_JSON },
                        label = { Text("Shadow Striker", fontSize = 11.sp) },
                        modifier = Modifier.testTag("code_template_shadow_striker")
                    )
                }

                // Real-Time Live Character Preview Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0E1422))
                        .border(
                            1.5.dp,
                            if (parseResult.rig != null) StudioEmerald.copy(alpha = 0.7f) else StudioCoral.copy(alpha = 0.8f),
                            RoundedCornerShape(12.dp)
                        )
                        .testTag("coded_character_live_preview"),
                    contentAlignment = Alignment.Center
                ) {
                    val previewRig = parseResult.rig
                    if (previewRig != null) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val cx = size.width / 2f
                            val cy = size.height * 0.56f
                            // Subtle preview grid
                            val gridStep = 24f
                            var gx = 0f
                            while (gx < size.width) {
                                drawLine(Color(0x18FFFFFF), Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 1f)
                                gx += gridStep
                            }
                            var gy = 0f
                            while (gy < size.height) {
                                drawLine(Color(0x18FFFFFF), Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
                                gy += gridStep
                            }
                            drawIntoCanvas { composeCanvas ->
                                val nc = composeCanvas.nativeCanvas
                                val fitScale = (size.height / 360f).coerceIn(0.38f, 0.85f)
                                nc.save()
                                SceneRenderer.drawSkeletalRig(
                                    canvas = nc,
                                    rig = previewRig,
                                    puppetRoot = EvaluatedPuppetRoot(
                                        rootX = cx,
                                        rootY = cy,
                                        scale = fitScale,
                                        flippedHorizontal = false,
                                        eyePack = previewRig.eyePack,
                                        mouthPhoneme = previewRig.mouthPhoneme
                                    ),
                                    angles = emptyMap(),
                                    frame = 0,
                                    fps = 24,
                                    audioTracks = emptyList(),
                                    alpha = 1f,
                                    tintColorArgb = null,
                                    showOverlay = false,
                                    isSelectedPuppet = false,
                                    selectedBoneId = null
                                )
                                nc.restore()
                            }
                        }
                    } else {
                        Text(
                            text = parseResult.error ?: "Invalid JSON",
                            color = StudioCoral,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // Live Validation Status Pill
                Surface(
                    color = if (parseResult.rig != null) StudioEmerald.copy(alpha = 0.14f) else StudioCoral.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (parseResult.rig != null) StudioEmerald else StudioCoral),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (parseResult.rig != null) {
                            "Valid Character Code • \"${parseResult.rig.name}\" (${parseResult.rig.characterAppearance?.customCodePaths?.size ?: 0} custom vector paths)"
                        } else {
                            "Syntax Error: ${parseResult.error ?: "Check JSON syntax"}"
                        },
                        color = if (parseResult.rig != null) StudioEmerald else StudioCoral,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // Code Editor Text Field
                OutlinedTextField(
                    value = codeText,
                    onValueChange = { codeText = it },
                    label = { Text("Character JSON & Vector Paths (M/L/Q/C/Z)") },
                    textStyle = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = StudioTextPrimary
                    ),
                    minLines = 8,
                    maxLines = 14,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("character_code_editor_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Button(
                        enabled = parseResult.rig != null,
                        onClick = {
                            parseResult.rig?.let { rig ->
                                onSaveAndAdd(rig)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioEmerald),
                        modifier = Modifier.testTag("save_and_add_coded_character_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Black)
                        Spacer(Modifier.width(6.dp))
                        Text("Save & Add Character", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

