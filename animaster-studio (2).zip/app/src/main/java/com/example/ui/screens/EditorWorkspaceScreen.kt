package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.ChangeHistory
import androidx.compose.material.icons.rounded.Circle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Colorize
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.CropSquare
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.FormatColorFill
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.HorizontalRule
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PanTool
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Mood
import androidx.compose.material.icons.rounded.Visibility
import com.example.data.local.LocalAssetEntity
import com.example.data.model.CharacterSpec
import com.example.data.model.CustomActionClip
import com.example.data.model.EditorTool
import com.example.data.model.ExportFormat
import com.example.data.model.EyePackStyle
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.SkeletalRig
import com.example.data.model.StageMoodPreset
import com.example.engine.BoneZOrderAction
import com.example.engine.InterpolationEngine
import com.example.engine.ProceduralSmartTools
import com.example.engine.RigSolver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AssetsLibraryPanel
import com.example.ui.components.AudioStudioInspectorPanel
import com.example.ui.components.CanvasStage
import com.example.ui.components.CharacterCreatorPanel
import com.example.ui.components.CreateCharacterByCodeDialog
import com.example.ui.components.ExportStudioDialog
import com.example.ui.components.FaceAndMoodSwapperDock
import com.example.ui.components.ImportCharacterDialog
import com.example.ui.components.InfiniteColorPicker
import com.example.ui.components.LayersInspectorPanel
import com.example.ui.components.PartSketcherAndMagicEraserDialog
import com.example.ui.components.PropertiesInspectorPanel
import com.example.ui.components.RiggingInspectorPanel
import com.example.ui.components.SceneCameraInspectorPanel
import com.example.ui.components.StageContextToolBar
import com.example.ui.components.StudioColorSwatches
import com.example.ui.components.TextStudioInspectorPanel
import com.example.ui.components.TimelinePanel
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.InspectorTab
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.StudioViewModel
import java.io.File

private val StageCoreTools = listOf(
    EditorTool.RIG_EDIT,
    EditorTool.SELECT,
    EditorTool.MOTION_PATH,
    EditorTool.HAND_PAN
)

private val PaintDrawerTools = listOf(
    EditorTool.PENCIL,
    EditorTool.BRUSH,
    EditorTool.AIRBRUSH,
    EditorTool.ERASER,
    EditorTool.BUCKET,
    EditorTool.PEN_BEZIER,
    EditorTool.LINE,
    EditorTool.RECTANGLE,
    EditorTool.CIRCLE,
    EditorTool.POLYGON,
    EditorTool.TEXT,
    EditorTool.EYEDROPPER
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorWorkspaceScreen(
    viewModel: StudioViewModel,
    uiState: StudioUiState,
    localAssets: List<LocalAssetEntity>,
    myCharacters: List<SkeletalRig>,
    customAssets: List<SkeletalRig>,
    customActions: List<CustomActionClip> = emptyList(),
    onBackToHub: () -> Unit,
    onImportImage: () -> Unit,
    onImportHandPropPng: (isRightHand: Boolean) -> Unit,
    onImportExtraRigPng: (com.example.engine.RigAttachmentArea) -> Unit,
    onImportWatermarkLogo: () -> Unit = {},
    onImportSvg: () -> Unit,
    onImportVideo: () -> Unit,
    onImportAudio: () -> Unit,
    onRequestRecordVoice: () -> Unit,
    onExportProjectJson: () -> Unit,
    onSaveExportedToDevice: (File, ExportFormat) -> Unit,
    onShareExportedFile: (File, String) -> Unit
) {
    val project = uiState.activeProject ?: return
    val animatedFxClips by viewModel.animatedFxClips.collectAsStateWithLifecycle()
    val projectImageLibrary by viewModel.projectImageLibrary.collectAsStateWithLifecycle()
    var showExportDialog by remember { mutableStateOf(false) }
    var showSwapCharDialog by remember { mutableStateOf(false) }
    var showCreateByCodeDialog by remember { mutableStateOf(false) }
    var inspectorWidthDp by remember { mutableFloatStateOf(300f) }

    BackHandler {
        when {
            uiState.attachBonePickMode -> viewModel.cancelAttachBonePickMode()
            uiState.showFaceMoodDock -> viewModel.toggleFaceMoodDock()
            uiState.paintDrawerOpen -> viewModel.setPaintDrawerOpen(false)
            uiState.mobileInspectorOpen -> viewModel.setMobileInspectorOpen(false)
            else -> onBackToHub()
        }
    }

    Scaffold(
        containerColor = StudioBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown) {
                        when {
                            event.isCtrlPressed && event.key == Key.Z -> { viewModel.undo(); true }
                            event.isCtrlPressed && event.key == Key.Y -> { viewModel.redo(); true }
                            event.key == Key.Spacebar -> { viewModel.togglePlayback(); true }
                            event.key == Key.DirectionLeft -> { viewModel.stepFrame(-1); true }
                            event.key == Key.DirectionRight -> { viewModel.stepFrame(1); true }
                            event.key == Key.B -> { viewModel.selectTool(EditorTool.BRUSH); true }
                            event.key == Key.P -> { viewModel.selectTool(EditorTool.PENCIL); true }
                            event.key == Key.E -> { viewModel.selectTool(EditorTool.ERASER); true }
                            event.key == Key.G -> { viewModel.selectTool(EditorTool.BUCKET); true }
                            event.key == Key.V -> { viewModel.selectTool(EditorTool.SELECT); true }
                            event.key == Key.K -> { viewModel.selectTool(EditorTool.RIG_EDIT); true }
                            event.key == Key.O -> { viewModel.toggleOnionSkin(); true }
                            else -> false
                        }
                    } else false
                }
        ) {
            // 3-tier Auto-Fit Responsive Detection:
            // < 600dp: Mobile Portrait | 600dp..1024dp: Mobile Landscape / Tablet | > 1024dp: Desktop
            val isTabletOrLandscape = maxWidth >= 600.dp
            val isDesktop = maxWidth > 1024.dp
            val effectiveInspectorWidth = if (isDesktop) inspectorWidthDp.coerceIn(280f, 440f) else inspectorWidthDp.coerceIn(240f, 320f)

            Column(modifier = Modifier.fillMaxSize()) {
                // 1. Scrollable Universal Auto-Fit Studio Top Bar (with unified Import menu!)
                StudioTopToolbar(
                    projectName = project.name,
                    sceneName = uiState.activeScene?.name ?: "Scene 1",
                    primaryColorArgb = uiState.primaryColorArgb,
                    canUndo = uiState.canUndo,
                    canRedo = uiState.canRedo,
                    isWide = isTabletOrLandscape,
                    onBack = onBackToHub,
                    onOpenCharStudio = { viewModel.openCharacterRigStudio(uiState.selectedLayer?.rig) },
                    onOpenCelStudio = { viewModel.openCelStudio() },
                    onOpenImportChar = { viewModel.openImportCharacterSheet(true) },
                    onImportImage = onImportImage,
                    onImportHandPropPng = onImportHandPropPng,
                    onImportSvg = onImportSvg,
                    onImportVideo = onImportVideo,
                    onImportAudio = onImportAudio,
                    onUndo = { viewModel.undo() },
                    onRedo = { viewModel.redo() },
                    onSave = { viewModel.saveProjectNow() },
                    onOpenScreenSettings = { viewModel.openScreenSettingsDialog(true) },
                    onExport = {
                        viewModel.clearExportResult()
                        showExportDialog = true
                    },
                    onOpenMobileInspector = {
                        viewModel.openPropsPanel()
                    }
                )

                // 2. Main Workspace (Always-Visible Animated Preview Stage + Adaptive Docked Inspector)
                val showInlineMobileInspector = !isTabletOrLandscape && uiState.mobileInspectorOpen
                Row(
                    modifier = Modifier
                        .weight(if (showInlineMobileInspector) 0.54f else 1f)
                        .fillMaxWidth()
                ) {
                    // Clean Left Rail: Single "Paint Tools" Drawer Toggle + Core Stage Controls
                    CompactStageToolRail(
                        activeTool = uiState.activeTool,
                        paintDrawerOpen = uiState.paintDrawerOpen,
                        primaryColorArgb = uiState.primaryColorArgb,
                        onTogglePaintDrawer = { viewModel.togglePaintDrawer() },
                        onSelectTool = { tool ->
                            viewModel.selectTool(tool)
                            if (tool in StageCoreTools) viewModel.setPaintDrawerOpen(false)
                        }
                    )

                    // Center Canvas Stage + Overlay Collapsible Paint Drawer
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        CanvasStage(
                            uiState = uiState,
                            onCommitStroke = { viewModel.commitStroke(it) },
                            onCommitShape = { viewModel.commitShape(it) },
                            onPaintBucket = { x, y -> viewModel.applyPaintBucket(x, y) },
                            onPickColor = { x, y -> viewModel.pickColorAt(x, y) },
                            onAddText = { txt, x, y, inAnim, loopAnim ->
                                viewModel.addTextItem(txt, x, y, 68f, inAnim, loopAnim)
                            },
                            onSelectText = { viewModel.selectText(it) },
                            onMoveText = { id, x, y, rec -> viewModel.moveAnimatedText(id, x, y, rec) },
                            onUpdateText = { id, rec, fn -> viewModel.updateAnimatedText(id, rec, fn) },
                            onDuplicateText = { viewModel.duplicateAnimatedText(it) },
                            onDeleteText = { viewModel.deleteAnimatedText(it) },
                            onOpenTextStudio = {
                                viewModel.setInspectorTab(InspectorTab.TEXT)
                                if (!isTabletOrLandscape) viewModel.setMobileInspectorOpen(true)
                            },
                            onDirectTransform = { dx, dy, sf, dRot, rec ->
                                viewModel.updateSelectedLayerDirectTransform(
                                    dx = dx,
                                    dy = dy,
                                    scaleFactor = sf,
                                    rotationDeltaDeg = dRot,
                                    recordUndo = rec
                                )
                            },
                            onDirectTransformXY = { dx, dy, sf, sx, sy, dRot, rec ->
                                viewModel.updateSelectedLayerDirectTransform(
                                    dx = dx,
                                    dy = dy,
                                    scaleFactor = sf,
                                    scaleXFactor = sx,
                                    scaleYFactor = sy,
                                    rotationDeltaDeg = dRot,
                                    recordUndo = rec
                                )
                            },
                            onSetAbsoluteTransform = { rot, sc, reset ->
                                viewModel.setSelectedLayerTransformAbsolute(
                                    rotationDeg = rot,
                                    scale = sc,
                                    reset = reset,
                                    recordUndo = reset
                                )
                            },
                            onSelectLayer = { viewModel.selectLayer(it) },
                            onSelectBone = { viewModel.selectBone(it) },
                            onDragRigBone = { bid, pt, rec -> viewModel.dragRigBoneTo(bid, pt, rec) },
                            onRotateRigBoneDelta = { bid, dAng, rec -> viewModel.rotateRigBoneByDelta(bid, dAng, rec) },
                            onRotatePropDelta = { dAng, rec -> viewModel.rotateSelectedPropByDelta(dAng, rec) },
                            onMovePuppetRoot = { x, y, rec -> viewModel.movePuppetRoot(x, y, rec) },
                            onTogglePuppetFlip = { viewModel.togglePuppetFlipHorizontal() },
                            onTogglePuppetAutoWalk = { viewModel.togglePuppetAutoWalk() },
                            onTogglePuppetGhostMode = { viewModel.toggleSelectedLayerGhostMode() },
                            onCyclePuppetViewAngle = { viewModel.cyclePuppetViewAngle() },
                            onCyclePuppetHandProp = { isRight -> viewModel.cyclePuppetHandProp(isRight) },
                            onCyclePuppetEyePack = { viewModel.setPuppetEyePack(it) },
                            onCyclePuppetMouthPhoneme = { viewModel.setPuppetMouthPhoneme(it) },
                            onApplyPuppetPose = { viewModel.applyRigPosePreset(it) },
                            onOpenImportCharacter = { viewModel.openImportCharacterSheet(true) },
                            onToggleCameraHud = { viewModel.toggleCameraHud() },
                            onUpdateCamera = { px, py, z, r -> viewModel.updateCameraKeyframeAtCurrentFrame(px, py, z, r) },
                            onCameraDollyZoom = { viewModel.applyCameraDollyZoomAtCurrentFrame() },
                            onCameraPanAcross = { viewModel.applyCameraPanAcrossAtCurrentFrame() },
                            onCameraShake = { viewModel.applyCameraShakeAtCurrentFrame() },
                            onResetCamera = { viewModel.resetCameraKeyframes() },
                            onToggleCharacterActions = { viewModel.toggleCharacterActionsExpanded() },
                            onOpenExtraRigPanel = {
                                viewModel.setInspectorTab(InspectorTab.RIG)
                                if (!isTabletOrLandscape) viewModel.setMobileInspectorOpen(true)
                            },
                            onToggleStretchRig = { viewModel.toggleStretchRigMode() },
                            onToggleLiveRecord = { viewModel.toggleLiveRecordMode() },
                            onRecordLivePad = { viewModel.recordLiveActingPad(it) },
                            onAddMotionPathPoint = { viewModel.addMotionPathPoint(it) },
                            onSetMotionPath = { viewModel.setMotionPathPoints(it) },
                            onUndoMotionPathPoint = { viewModel.undoLastMotionPathPoint() },
                            onReverseMotionPath = { viewModel.reverseMotionPath() },
                            onToggleMotionPathOrient = { viewModel.toggleMotionPathOrient() },
                            onCycleMotionPathEasing = { viewModel.cycleMotionPathEasing() },
                            onClearMotionPath = { viewModel.clearMotionPath() },
                            onUpdateViewport = { z, px, py -> viewModel.updateCanvasViewport(z, px, py) },
                            onResetViewport = { viewModel.resetCanvasViewport() },
                            onMicroNudge = { dx, dy -> viewModel.microNudgeActiveSelection(dx, dy) },
                            onToggleMicroNudgeStep = { viewModel.toggleMicroNudgeStep() },
                            onToggleFaceMoodDock = { viewModel.toggleFaceMoodDock() },
                            onPickBoneForAttachment = { hostId, boneId ->
                                viewModel.completeAttachBonePickFromCanvas(hostId, boneId)
                            },
                            onCancelAttachBonePick = { viewModel.cancelAttachBonePickMode() }
                        )

                        // Modules 4, 5 & 6: Collapsible On-Stage Face & Mood Swapper Dock
                        val dockRig = uiState.selectedLayer?.rig
                        androidx.compose.animation.AnimatedVisibility(
                            visible = uiState.showFaceMoodDock && dockRig != null && !uiState.isPlaying,
                            enter = fadeIn(),
                            exit = fadeOut(),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            if (dockRig != null) {
                                FaceAndMoodSwapperDock(
                                    rig = dockRig,
                                    currentFrame = uiState.currentFrame,
                                    onSelectEyeMood = { viewModel.setStageActiveEyeMood(it) },
                                    onSelectMouthMood = { viewModel.setStageActiveMouthMood(it) },
                                    onSelectEyePack = { viewModel.setPuppetEyePack(it) },
                                    onSelectMouthPhoneme = { viewModel.setPuppetMouthPhoneme(it) },
                                    onSetPupilLook = { lx, ly, rx, ry -> viewModel.setStagePupilLook(lx, ly, rx, ry) },
                                    onToggleSyncPupils = { viewModel.toggleStageSyncPupils() },
                                    onSelectNoseStyle = { viewModel.setStageNoseStyle(it) },
                                    onSetHeadTurn25D = { viewModel.setStageHeadTurn25D(it) },
                                    onToggleDialogueHeadBounce = { viewModel.toggleStageDialogueHeadBounce() },
                                    onSelectLeftEyebrow = { viewModel.setStageLeftEyebrow(it) },
                                    onSelectRightEyebrow = { viewModel.setStageRightEyebrow(it) },
                                    onSaveCombo = { viewModel.saveStageFaceCombo(it) },
                                    onApplyCombo = { viewModel.applyStageFaceCombo(it) },
                                    onTriggerFaceFx = { name, dur, flash ->
                                        viewModel.triggerFaceFxAtCurrentFrame(
                                            fxName = name,
                                            durationFrames = dur,
                                            flashColorArgb = flash
                                        )
                                    },
                                    onClose = { viewModel.toggleFaceMoodDock() }
                                )
                            }
                        }

                        // Collapsible Single-Button Paint Tools Drawer (compact so live preview stays unobstructed!)
                        androidx.compose.animation.AnimatedVisibility(
                            visible = uiState.paintDrawerOpen,
                            enter = expandHorizontally() + fadeIn(),
                            exit = shrinkHorizontally() + fadeOut(),
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = 6.dp, top = 6.dp, bottom = 6.dp)
                        ) {
                            CollapsiblePaintDrawer(
                                uiState = uiState,
                                onSelectTool = { tool ->
                                    viewModel.selectTool(tool)
                                },
                                onSetColor = { viewModel.setPrimaryColor(it) },
                                onSetBrushSize = { viewModel.setBrushSize(it) },
                                onClose = { viewModel.setPaintDrawerOpen(false) }
                            )
                        }

                        // Floating Status Banner
                        androidx.compose.animation.AnimatedVisibility(
                            visible = uiState.statusBanner != null,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 12.dp)
                        ) {
                            Surface(
                                color = StudioSurfaceElevated.copy(alpha = 0.95f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, StudioCoral)
                            ) {
                                Text(
                                    text = uiState.statusBanner.orEmpty(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StudioTextPrimary,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }

                    // Tablet / Landscape / Desktop Docked & Resizable Right Inspector Panel
                    if (isTabletOrLandscape) {
                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .fillMaxHeight()
                                .background(StudioBorder)
                                .pointerInput(Unit) {
                                    detectHorizontalDragGestures { _, dragAmount ->
                                        inspectorWidthDp = (inspectorWidthDp - dragAmount * 0.6f).coerceIn(240f, 440f)
                                    }
                                }
                        )
                        Surface(
                            color = StudioSurface,
                            modifier = Modifier
                                .width(effectiveInspectorWidth.dp)
                                .fillMaxHeight()
                        ) {
                            InspectorHost(
                                viewModel = viewModel,
                                uiState = uiState,
                                localAssets = localAssets,
                                customAssets = customAssets,
                                customActions = customActions,
                                onImportImage = onImportImage,
                                onImportHandPropPng = onImportHandPropPng,
                                onImportExtraRigPng = onImportExtraRigPng,
                                onImportWatermarkLogo = onImportWatermarkLogo,
                                onImportSvg = onImportSvg,
                                onImportVideo = onImportVideo,
                                onImportAudio = onImportAudio,
                                onRequestRecordVoice = onRequestRecordVoice,
                                onOpenCreateByCode = { showCreateByCodeDialog = true }
                            )
                        }
                    }
                }

                // 3. Mobile Portrait Quick Inspector Dock Strip (< 600dp)
                // Tapping any tab opens an inline split-screen drawer BELOW the live Animated Preview Stage (never blocking/dimming it!)
                if (!isTabletOrLandscape) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(StudioSurfaceVariant)
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        InspectorTab.entries.forEach { tab ->
                            val selected = uiState.activeInspectorTab == tab && uiState.mobileInspectorOpen
                            Surface(
                                color = if (selected) StudioCoral.copy(alpha = 0.22f) else StudioSurface,
                                shape = RoundedCornerShape(9.dp),
                                border = BorderStroke(1.dp, if (selected) StudioCoral else StudioBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(9.dp))
                                    .clickable {
                                        if (tab == InspectorTab.PROPS) {
                                            if (uiState.mobileInspectorOpen && uiState.activeInspectorTab == InspectorTab.PROPS) {
                                                viewModel.setMobileInspectorOpen(false)
                                            } else {
                                                viewModel.openPropsPanel()
                                            }
                                        } else if (uiState.mobileInspectorOpen && uiState.activeInspectorTab == tab) {
                                            viewModel.setMobileInspectorOpen(false)
                                        } else {
                                            viewModel.setInspectorTab(tab)
                                            viewModel.setMobileInspectorOpen(true)
                                        }
                                    }
                                    .testTag("mobile_tab_${tab.name.lowercase()}")
                            ) {
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) StudioCoral else StudioTextPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                // 3b. Unified Collapsible Context Tool Selector Bar ([Rigging], [Move], [Face], [Props], [Range] + Hide Tools)
                StageContextToolBar(
                    uiState = uiState,
                    customActions = customActions,
                    onSelectTab = { viewModel.selectContextToolTab(it) },
                    onToggleHideTools = { viewModel.toggleToolsDrawerHidden() },
                    onSelectViewAngle = { viewModel.setPuppetViewAngle(it) },
                    onToggleLockBone = { viewModel.toggleSelectedBoneLock() },
                    onToggleStretchRig = { viewModel.toggleStretchRigMode() },
                    onSetBoneLengthMultiplier = { mult -> viewModel.setSelectedBoneLengthMultiplier(mult, recordUndo = false) },
                    onResetBoneLength = { viewModel.resetSelectedBoneLength() },
                    onResetBone = { viewModel.resetSelectedBoneOnStage() },
                    onToggleMoveChar = { viewModel.toggleMoveCharMode() },
                    onToggleMicroNudgeStep = { viewModel.toggleMicroNudgeStep() },
                    onMicroNudge = { dx, dy -> viewModel.microNudgeActiveSelection(dx, dy) },
                    onUpdateViewport = { z, px, py -> viewModel.updateCanvasViewport(z, px, py) },
                    onResetViewport = { viewModel.resetCanvasViewport() },
                    onApplyMoodPreset = { viewModel.applyStageMoodPreset(it) },
                    onSelectEyePack = { viewModel.setPuppetEyePack(it) },
                    onSelectMouthPhoneme = { viewModel.setPuppetMouthPhoneme(it) },
                    onSelectEyeMood = { viewModel.setStageActiveEyeMood(it) },
                    onSelectMouthMood = { viewModel.setStageActiveMouthMood(it) },
                    onSelectEyebrow = { brow ->
                        viewModel.setStageLeftEyebrow(brow)
                        viewModel.setStageRightEyebrow(brow)
                    },
                    onOpenSwapChar = { showSwapCharDialog = true },
                    onResetPose = { viewModel.resetFullRigPoseOnStage() },
                    onSelectLayer = { viewModel.selectLayer(it) },
                    onStartAttachBonePick = { propId -> viewModel.startAttachBonePickMode(propId) },
                    onAttachPropToBone = { propId, hostId, boneId -> viewModel.attachLayerToBone(propId, hostId, boneId) },
                    onDetachProp = { propId -> viewModel.detachLayerFromBoneAtCurrentFrame(propId) },
                    onCenterPropInPalm = { propId -> viewModel.centerLayerPropOnBone(propId) },
                    onToggleRotateProp = { viewModel.togglePropRotateMode() },
                    onImportImage = onImportImage,
                    onSetTimelineRange = { s, e -> viewModel.setTimelineRange(s, e) },
                    onTogglePlayRange = { viewModel.togglePlayRangeOnly() },
                    onSaveCustomAction = { name, incRoot -> viewModel.saveSelectedRangeAsCustomAction(name, incRoot) },
                    onApplyCustomAction = { clip -> viewModel.applyCustomActionToSelectedLayer(clip) }
                )

                // 4. Pure Frame-by-Frame Keyframe Timeline
                TimelinePanel(
                    uiState = uiState,
                    onTogglePlay = { viewModel.togglePlayback() },
                    onStepFrame = { viewModel.stepFrame(it) },
                    onSelectFrame = { viewModel.setCurrentFrame(it) },
                    onAddFrames = { viewModel.addFrames(it) },
                    onSelectLayer = { viewModel.selectLayer(it) },
                    onSelectTrackTarget = { kind, id -> viewModel.selectTrackTarget(kind, id) },
                    onToggleTrackTools = { viewModel.toggleTrackToolsExpanded() },
                    onCutTrack = { viewModel.cutSelectedTrackAtPlayhead() },
                    onMidCutTrack = { viewModel.midCutSelectedTrackAtPlayhead() },
                    onDuplicateTrack = { viewModel.duplicateSelectedTrack() },
                    onDeleteTrack = { viewModel.deleteSelectedTrack() },
                    onRemixTrack = { viewModel.remixSelectedTrack() },
                    onMoveTrackOrder = { up -> viewModel.moveSelectedTrackOrder(up) },
                    onToggleTrackVisibility = { viewModel.toggleSelectedTrackVisibility() },
                    onMoveLayerOrder = { id, up -> viewModel.moveLayerOrder(id, up) },
                    onToggleLayerVisibility = { id -> viewModel.toggleLayerVisibility(id) },
                    onToggleLayerLock = { id -> viewModel.toggleLayerLock(id) },
                    onToggleTextVisibility = { id -> viewModel.toggleTextVisibility(id) },
                    onToggleAudioMute = { id -> viewModel.toggleAudioMute(id) },
                    onSetFps = { viewModel.setFps(it) },
                    onToggleLoop = { viewModel.toggleLooping() },
                    onToggleOnionSkin = { viewModel.toggleOnionSkin() },
                    onToggleGhostFrames = { viewModel.toggleGhostFrames() },
                    onAddBlankCel = { viewModel.addBlankCelAtCurrentFrame() },
                    onDuplicateCel = { viewModel.duplicatePreviousCelToCurrentFrame() },
                    onInsertKeyframe = { viewModel.insertOrUpdateKeyframeAtCurrentFrame() },
                    onDeleteKeyframe = { viewModel.deleteKeyframeAtCurrentFrame() },
                    onCopyFrame = { viewModel.copyCurrentFrameToClipboard() },
                    onPasteFrame = { viewModel.pasteFrameFromClipboard() },
                    onOpenSwapChar = { showSwapCharDialog = true },
                    onSetTimelineRange = { s, e -> viewModel.setTimelineRange(s, e) },
                    onTogglePlayRange = { viewModel.togglePlayRangeOnly() },
                    onHideFromHere = { viewModel.hideSelectedLayerFromCurrentFrame() },
                    onShowFromHere = { viewModel.showSelectedLayerFromCurrentFrame() },
                    onSetVisibleRange = { s, e -> viewModel.setSelectedLayerVisibleRange(s, e) },
                    onClearVisibilityRanges = { viewModel.clearSelectedLayerVisibilityRanges() },
                    onApplyTargetedLoop = { t, s, e -> viewModel.applyTargetedLoopToSelectedLayer(t, s, e) },
                    onSaveCustomAction = { name -> viewModel.saveSelectedRangeAsCustomAction(name) },
                    onSaveCustomActionWithOptions = { name, incRoot -> viewModel.saveSelectedRangeAsCustomAction(name, incRoot) },
                    customActions = customActions,
                    onApplyCustomAction = { clip -> viewModel.applyCustomActionToSelectedLayer(clip) },
                    onStepSelectedBoneZOrder = { bringForward ->
                        val boneId = uiState.selectedBoneId ?: uiState.selectedLayer?.rig?.bones?.firstOrNull()?.id
                        if (boneId != null) {
                            viewModel.adjustSelectedLayerBoneZOrder(
                                boneId,
                                if (bringForward) BoneZOrderAction.BRING_FORWARD else BoneZOrderAction.SEND_BACKWARD
                            )
                        }
                    },
                    onBatchShiftColorRange = { s, e, hue -> viewModel.batchShiftColorInRange(s, e, hue) },
                    onCopyFrameRange = { s, e -> viewModel.copyFramesInRange(s, e) },
                    onPasteAutoLoopFillRange = { s, e -> viewModel.pasteAutoLoopFillRange(s, e) },
                    onSaveAnimatedFxClip = { name, s, e -> viewModel.saveCelRangeAsAnimatedFxClip(name, s, e) },
                    myCharacters = myCharacters,
                    onUndo = { viewModel.undo() },
                    onRedo = { viewModel.redo() },
                    onCopyClip = { viewModel.copySelectedLayerClip() },
                    onPasteClip = { viewModel.pasteCopiedLayerClipAtPlayhead() },
                    onTrimLayerBounds = { id, s, e -> viewModel.trimLayerClipBounds(id, s, e) },
                    onMoveLayerClip = { id, ns -> viewModel.moveLayerClipToFrame(id, ns) },
                    onMoveLayerClip2D = { id, ns, dy, lift -> viewModel.moveLayerClip2D(id, ns, dy, lift) },
                    onReplaceLayerCharacter = { id, rig -> viewModel.replaceLayerCharacterWithRig(id, rig) },
                    onUpdateLayerAnimations = { id, iA, oA, lA, f -> viewModel.updateLayerClipAnimations(id, iA, oA, lA, f) },
                    onAddExtraTrack = { name, lt, dur, iA, oA, lA -> viewModel.addExtraTrackClip(name, lt, dur, iA, oA, lA) },
                    onTrimAudioBounds = { id, s, e -> viewModel.trimAudioTrackBounds(id, s, e) },
                    onMoveAudioTrack = { id, ns -> viewModel.moveAudioTrackToFrame(id, ns) },
                    onToggleAudioLoop = { id -> viewModel.toggleAudioTrackLoop(id) },
                    compactMode = showInlineMobileInspector
                )

                // 5. Non-Blocking Inline Docked Mobile Inspector (keeps top Animated Preview 100% live & undimmed!)
                if (showInlineMobileInspector) {
                    Surface(
                        color = StudioSurface,
                        border = BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.46f)
                            .testTag("mobile_inline_inspector_pane")
                    ) {
                        InspectorHost(
                            viewModel = viewModel,
                            uiState = uiState,
                            localAssets = localAssets,
                            customAssets = customAssets,
                            customActions = customActions,
                            onImportImage = onImportImage,
                            onImportHandPropPng = onImportHandPropPng,
                            onImportExtraRigPng = onImportExtraRigPng,
                            onImportWatermarkLogo = onImportWatermarkLogo,
                            onImportSvg = onImportSvg,
                            onImportVideo = onImportVideo,
                            onImportAudio = onImportAudio,
                            onRequestRecordVoice = onRequestRecordVoice,
                            onOpenCreateByCode = { showCreateByCodeDialog = true },
                            onCloseMobile = { viewModel.setMobileInspectorOpen(false) }
                        )
                    }
                }
            }
        }
    }

    // Multi-Character Import Dialog
    if (uiState.showImportCharacterSheet) {
        ImportCharacterDialog(
            myCharacters = myCharacters,
            onImportCharacter = { rig -> viewModel.importRiggedCharacterIntoScene(rig) },
            onEditInCharStudio = { rig -> viewModel.openCharacterRigStudio(rig) },
            onDeleteMyCharacter = { id -> viewModel.deleteMyCharacter(id) },
            onDismiss = { viewModel.openImportCharacterSheet(false) }
        )
    }

    // Keyframed Character Swap Picker Dialog (Step-Hold Interpolation at currentFrame)
    if (showSwapCharDialog) {
        val activeLayer = uiState.selectedLayer
        val hasSwapOnFrame = activeLayer?.characterSwapKeyframes?.containsKey(uiState.currentFrame) == true
        val currentSwappedId = activeLayer?.let { InterpolationEngine.evaluateCharacterSwapId(it, uiState.currentFrame) }
        SwapCharacterAtFrameDialog(
            currentFrame = uiState.currentFrame,
            activeLayerName = activeLayer?.name ?: "Character",
            activeSwapCharacterId = currentSwappedId,
            hasSwapOnCurrentFrame = hasSwapOnFrame,
            myCharacters = myCharacters,
            builtInPresets = ProceduralSmartTools.characterPresets,
            onSelectCustomRig = { rig ->
                viewModel.swapActiveLayerCharacterAtCurrentFrame(rig)
                showSwapCharDialog = false
            },
            onSelectPreset = { spec ->
                viewModel.swapActiveLayerCharacterWithPresetAtCurrentFrame(spec)
                showSwapCharDialog = false
            },
            onRemoveSwapAtFrame = {
                viewModel.removeCharacterSwapAtCurrentFrame()
                showSwapCharDialog = false
            },
            onDismiss = { showSwapCharDialog = false }
        )
    }

    // Export Modal
    if (showExportDialog) {
        ExportStudioDialog(
            uiState = uiState,
            onDismiss = { showExportDialog = false },
            onStartExport = { viewModel.runLocalExport(it) },
            onSaveExportedToDevice = onSaveExportedToDevice,
            onShareExportedFile = onShareExportedFile,
            onExportProjectJson = onExportProjectJson
        )
    }

    // Transparent Part Sketcher & Magic Background Eraser Dialog
    if (uiState.showPartSketcherDialog) {
        PartSketcherAndMagicEraserDialog(
            projectImages = projectImageLibrary,
            onSaveSketchedBitmap = { bmp, name ->
                viewModel.saveSketcherBitmapAsPng(bmp, name) { savedPath ->
                    viewModel.insertLocalImageFile(savedPath, name)
                }
            },
            onEraseBackgroundColor = { srcPath, sx, sy, tol ->
                viewModel.eraseBackgroundColorAndSavePng(srcPath, sx, sy, tol) { savedPath ->
                    viewModel.insertLocalImageFile(savedPath, "Cutout PNG")
                }
            },
            onDismiss = { viewModel.setShowPartSketcherDialog(false) }
        )
    }

    // Module 4: Create Character by Code Dialog
    if (showCreateByCodeDialog) {
        CreateCharacterByCodeDialog(
            onSaveAndAdd = { codedRig ->
                viewModel.saveAndAddCodedCharacter(codedRig, addToStage = true)
            },
            onDismiss = { showCreateByCodeDialog = false }
        )
    }
}

@Composable
private fun StudioTopToolbar(
    projectName: String,
    sceneName: String,
    primaryColorArgb: Long,
    canUndo: Boolean,
    canRedo: Boolean,
    isWide: Boolean,
    onBack: () -> Unit,
    onOpenCharStudio: () -> Unit,
    onOpenCelStudio: () -> Unit = {},
    onOpenImportChar: () -> Unit,
    onImportImage: () -> Unit,
    onImportHandPropPng: (isRightHand: Boolean) -> Unit,
    onImportSvg: () -> Unit,
    onImportVideo: () -> Unit,
    onImportAudio: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSave: () -> Unit,
    onOpenScreenSettings: () -> Unit,
    onExport: () -> Unit,
    onOpenMobileInspector: () -> Unit
) {
    var importMenuOpen by remember { mutableStateOf(false) }

    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(34.dp).testTag("editor_back_button")) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to projects", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
            }
            Column(modifier = Modifier.width(if (isWide) 136.dp else 78.dp)) {
                Text(
                    text = projectName,
                    style = MaterialTheme.typography.titleSmall,
                    color = StudioTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = sceneName,
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Dedicated Character & Rig Studio button
            Surface(
                color = StudioViolet.copy(alpha = 0.22f),
                shape = RoundedCornerShape(9.dp),
                border = BorderStroke(1.dp, StudioViolet),
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .clickable(onClick = onOpenCharStudio)
                    .testTag("topbar_char_studio_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Face, contentDescription = "Character & Rig Studio", tint = StudioViolet, modifier = Modifier.size(15.dp))
                    Text("Char Studio", style = MaterialTheme.typography.labelSmall, color = StudioViolet, fontWeight = FontWeight.Bold)
                }
            }

            // Dedicated Frame-by-Frame Cel Studio button (Module 7)
            Surface(
                color = StudioCoral.copy(alpha = 0.20f),
                shape = RoundedCornerShape(9.dp),
                border = BorderStroke(1.dp, StudioCoral),
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .clickable(onClick = onOpenCelStudio)
                    .testTag("topbar_cel_studio_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Brush, contentDescription = "Frame-by-Frame Cel Studio", tint = StudioCoral, modifier = Modifier.size(15.dp))
                    Text("Cel Studio", style = MaterialTheme.typography.labelSmall, color = StudioCoral, fontWeight = FontWeight.Bold)
                }
            }

            // Unified Clear "Import" Dropdown right in the Animation Section!
            Box {
                Surface(
                    color = StudioCyan.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(9.dp),
                    border = BorderStroke(1.dp, StudioCyan),
                    modifier = Modifier
                        .clip(RoundedCornerShape(9.dp))
                        .clickable { importMenuOpen = true }
                        .testTag("topbar_import_menu_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.FileUpload, contentDescription = "Import", tint = StudioCyan, modifier = Modifier.size(15.dp))
                        Text("Import", style = MaterialTheme.typography.labelSmall, color = StudioCyan, fontWeight = FontWeight.Bold)
                    }
                }
                DropdownMenu(
                    expanded = importMenuOpen,
                    onDismissRequest = { importMenuOpen = false }
                ) {
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.AccessibilityNew, contentDescription = null, tint = StudioViolet) },
                        text = { Text("Import Character (Cast & Presets)") },
                        onClick = { importMenuOpen = false; onOpenImportChar() }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = StudioCoral) },
                        text = { Text("Import PNG into Right Hand") },
                        onClick = { importMenuOpen = false; onImportHandPropPng(true) }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = StudioCoral) },
                        text = { Text("Import PNG into Left Hand") },
                        onClick = { importMenuOpen = false; onImportHandPropPng(false) }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = StudioCyan) },
                        text = { Text("Import Image / Background (PNG/JPG)") },
                        onClick = { importMenuOpen = false; onImportImage() }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.Gesture, contentDescription = null, tint = StudioCyan) },
                        text = { Text("Import Vector (SVG)") },
                        onClick = { importMenuOpen = false; onImportSvg() }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.Movie, contentDescription = null, tint = StudioViolet) },
                        text = { Text("Import Video Layer (MP4/WebM)") },
                        onClick = { importMenuOpen = false; onImportVideo() }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Rounded.AudioFile, contentDescription = null, tint = StudioCyan) },
                        text = { Text("Import Audio (MP3/WAV)") },
                        onClick = { importMenuOpen = false; onImportAudio() }
                    )
                }
            }

            if (!isWide) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color(primaryColorArgb))
                        .border(2.dp, StudioBorder, CircleShape)
                        .clickable(onClick = onOpenMobileInspector)
                        .testTag("quick_color_swatch")
                )
            }

            IconButton(onClick = onUndo, enabled = canUndo, modifier = Modifier.size(36.dp).testTag("undo_button")) {
                Icon(
                    Icons.AutoMirrored.Rounded.Undo,
                    contentDescription = "Undo",
                    tint = if (canUndo) StudioTextPrimary else StudioTextMuted
                )
            }
            IconButton(onClick = onRedo, enabled = canRedo, modifier = Modifier.size(36.dp).testTag("redo_button")) {
                Icon(
                    Icons.AutoMirrored.Rounded.Redo,
                    contentDescription = "Redo",
                    tint = if (canRedo) StudioTextPrimary else StudioTextMuted
                )
            }
            IconButton(onClick = onSave, modifier = Modifier.size(36.dp).testTag("save_button")) {
                Icon(Icons.Rounded.Save, contentDescription = "Save locally", tint = StudioCyan)
            }
            IconButton(onClick = onOpenScreenSettings, modifier = Modifier.size(36.dp).testTag("topbar_screen_settings_btn")) {
                Icon(Icons.Rounded.Settings, contentDescription = "Screen & Display Settings", tint = StudioTextSecondary)
            }
            Surface(
                color = StudioCoral,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onExport)
                    .testTag("open_export_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = "Export", tint = Color.Black, modifier = Modifier.size(16.dp))
                    Text("Export", style = MaterialTheme.typography.labelMedium, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun CompactStageToolRail(
    activeTool: EditorTool,
    paintDrawerOpen: Boolean,
    primaryColorArgb: Long,
    onTogglePaintDrawer: () -> Unit,
    onSelectTool: (EditorTool) -> Unit
) {
    val isUsingPaintTool = activeTool in PaintDrawerTools

    Surface(
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .width(58.dp)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Single Prominent "Paint Tools" Collapsible Drawer Toggle Button
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (paintDrawerOpen || isUsingPaintTool) StudioCoral else StudioSurfaceElevated
                    )
                    .border(
                        width = 1.5.dp,
                        color = if (paintDrawerOpen || isUsingPaintTool) StudioCoral else StudioBorder,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable(onClick = onTogglePaintDrawer)
                    .testTag("paint_tools_drawer_toggle"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = if (isUsingPaintTool) toolIcon(activeTool) else Icons.Rounded.Palette,
                        contentDescription = "Paint Tools Drawer",
                        tint = if (paintDrawerOpen || isUsingPaintTool) Color.Black else StudioCoral,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Paint",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (paintDrawerOpen || isUsingPaintTool) Color.Black else StudioTextPrimary,
                        maxLines = 1
                    )
                }
            }

            // Active color dot indicator
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color(primaryColorArgb))
                    .border(1.5.dp, Color.White, CircleShape)
                    .clickable(onClick = onTogglePaintDrawer)
            )

            HorizontalDivider(color = StudioBorder, modifier = Modifier.padding(horizontal = 8.dp))

            // Core Direct-Manipulation Stage Tools (Puppet Rig, Select/Resize/Rotate, Motion Path, Pan)
            StageCoreTools.forEach { tool ->
                val isSelected = activeTool == tool
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) StudioCyan.copy(alpha = 0.22f) else Color.Transparent)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.dp,
                            color = if (isSelected) StudioCyan else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectTool(tool) }
                        .testTag("tool_${tool.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = toolIcon(tool),
                            contentDescription = tool.label,
                            tint = if (isSelected) StudioCyan else StudioTextSecondary,
                            modifier = Modifier.size(19.dp)
                        )
                        Text(
                            text = tool.label,
                            fontSize = 9.sp,
                            color = if (isSelected) StudioCyan else StudioTextMuted,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CollapsiblePaintDrawer(
    uiState: StudioUiState,
    onSelectTool: (EditorTool) -> Unit,
    onSetColor: (Long) -> Unit,
    onSetBrushSize: (Float) -> Unit,
    onClose: () -> Unit
) {
    Surface(
        color = StudioSurface.copy(alpha = 0.96f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.7f)),
        shadowElevation = 8.dp,
        modifier = Modifier
            .width(236.dp)
            .testTag("paint_tools_drawer_panel")
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Palette, contentDescription = null, tint = StudioCoral, modifier = Modifier.size(16.dp))
                    Text("Paint & Draw Tools", color = StudioTextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close Paint Drawer", tint = StudioTextSecondary, modifier = Modifier.size(16.dp))
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PaintDrawerTools.forEach { tool ->
                    val isSel = uiState.activeTool == tool
                    Surface(
                        color = if (isSel) StudioCoral.copy(alpha = 0.24f) else StudioSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isSel) StudioCoral else StudioBorder),
                        modifier = Modifier
                            .width(66.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectTool(tool) }
                            .testTag("tool_${tool.name.lowercase()}")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = toolIcon(tool),
                                contentDescription = tool.label,
                                tint = if (isSel) StudioCoral else StudioTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = tool.label,
                                fontSize = 9.sp,
                                color = if (isSel) StudioCoral else StudioTextSecondary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = StudioBorder)

            InfiniteColorPicker(
                selectedColorArgb = uiState.primaryColorArgb,
                onColorChanged = onSetColor,
                label = "Infinite Color",
                compact = true,
                accentColor = StudioCoral,
                testTagPrefix = "drawer_color"
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Size ${uiState.brushSize.toInt()}", fontSize = 10.sp, color = StudioTextSecondary, modifier = Modifier.width(44.dp))
                Slider(
                    value = uiState.brushSize,
                    onValueChange = onSetBrushSize,
                    valueRange = 1f..60f,
                    colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun InspectorHost(
    viewModel: StudioViewModel,
    uiState: StudioUiState,
    localAssets: List<LocalAssetEntity>,
    customAssets: List<SkeletalRig>,
    customActions: List<CustomActionClip> = emptyList(),
    onImportImage: () -> Unit,
    onImportHandPropPng: (isRightHand: Boolean) -> Unit,
    onImportExtraRigPng: (com.example.engine.RigAttachmentArea) -> Unit,
    onImportWatermarkLogo: () -> Unit = {},
    onImportSvg: () -> Unit,
    onImportVideo: () -> Unit,
    onImportAudio: () -> Unit,
    onRequestRecordVoice: () -> Unit,
    onOpenCreateByCode: () -> Unit = {},
    onCloseMobile: (() -> Unit)? = null
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurfaceVariant)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            InspectorTab.entries.forEach { tab ->
                val sel = uiState.activeInspectorTab == tab
                Surface(
                    color = if (sel) StudioCoral else StudioSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.setInspectorTab(tab) }
                ) {
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (sel) Color.Black else StudioTextSecondary,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                    )
                }
            }
            if (onCloseMobile != null) {
                IconButton(onClick = onCloseMobile, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close inspector", tint = StudioTextSecondary)
                }
            }
        }
        HorizontalDivider(color = StudioBorder)

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (uiState.activeInspectorTab) {
                InspectorTab.LAYERS -> LayersInspectorPanel(
                    uiState = uiState,
                    onSelectLayer = { viewModel.selectLayer(it) },
                    onAddLayer = { viewModel.addLayer(it) },
                    onOpenImportCharacter = { viewModel.openImportCharacterSheet(true) },
                    onImportVideo = onImportVideo,
                    onDeleteLayer = { viewModel.deleteLayer(it) },
                    onToggleVisibility = { viewModel.toggleLayerVisibility(it) },
                    onToggleLock = { viewModel.toggleLayerLock(it) },
                    onMoveOrder = { id, up -> viewModel.moveLayerOrder(id, up) },
                    onMoveToExtreme = { id, toFront -> viewModel.moveLayerToExtreme(id, toFront) },
                    onUpdateOpacity = { id, op -> viewModel.updateLayerOpacity(id, op) },
                    onUpdateParallax = { id, p -> viewModel.updateLayerParallax(id, p) },
                    onApplyMotionPreset = { viewModel.applyMotionPresetToSelectedLayer(it) },
                    onClearCel = { viewModel.clearCurrentCel() },
                    onClearMotionPath = { viewModel.clearMotionPath() },
                    onDetachLayerFromBone = { layerId -> viewModel.detachLayerFromBoneAtCurrentFrame(layerId) },
                    onSetLayerScaleXY = { id, overall, sx, sy, reset ->
                        viewModel.setLayerScaleXY(id, overallScale = overall, scaleX = sx, scaleY = sy, reset = reset, recordUndo = reset)
                    }
                )
                InspectorTab.TEXT -> TextStudioInspectorPanel(
                    uiState = uiState,
                    onAddBlankText = {
                        val proj = uiState.activeProject
                        viewModel.addTextItem(
                            text = "NEW TITLE!",
                            x = (proj?.width ?: 1280) * 0.5f,
                            y = (proj?.height ?: 720) * 0.28f
                        )
                    },
                    onAddPreset = { viewModel.addAnimatedTextPreset(it) },
                    onSelectText = { viewModel.selectText(it) },
                    onUpdateText = { id, rec, fn -> viewModel.updateAnimatedText(id, rec, fn) },
                    onDuplicateText = { viewModel.duplicateAnimatedText(it) },
                    onDeleteText = { viewModel.deleteAnimatedText(it) },
                    onSetStartNow = { viewModel.setSelectedTextStartToCurrentFrame() },
                    onSetEndNow = { viewModel.setSelectedTextEndToCurrentFrame() }
                )
                InspectorTab.PROPS -> PropertiesInspectorPanel(
                    uiState = uiState,
                    onSetPrimaryColor = { viewModel.setPrimaryColor(it) },
                    onSetGradientColor = { viewModel.setGradientColor(it) },
                    onToggleGradient = { viewModel.toggleGradient(it) },
                    onSetBrushSize = { viewModel.setBrushSize(it) },
                    onSetBrushOpacity = { viewModel.setBrushOpacity(it) },
                    onToggleFillShapes = { viewModel.toggleFillShapes(it) },
                    onSetPolygonSides = { viewModel.setPolygonSides(it) },
                    onSetEasing = { viewModel.setActiveEasing(it) },
                    onNudgeTransform = { dx, dy, dr, ds -> viewModel.nudgeSelectedLayerTransform(dx, dy, dr, ds, true) },
                    onInsertKeyframe = { viewModel.insertOrUpdateKeyframeAtCurrentFrame() },
                    onDeleteKeyframe = { viewModel.deleteKeyframeAtCurrentFrame() },
                    onSetAbsoluteTransformXY = { rot, sx, sy, reset ->
                        viewModel.setSelectedLayerTransformAbsolute(
                            rotationDeg = rot,
                            scaleX = sx,
                            scaleY = sy,
                            reset = reset,
                            recordUndo = reset
                        )
                    },
                    onSetPivotMode = { viewModel.setSelectedLayerPivotMode(it) },
                    onUpdateLayerEffects = { shadow, rim, clearRim, mask, blur ->
                        viewModel.updateSelectedLayerEffects(shadow, rim, clearRim, mask, blur)
                    },
                    onSelectLayer = { viewModel.selectLayer(it) },
                    onImportImage = onImportImage,
                    onStartAttachBonePick = { propId -> viewModel.startAttachBonePickMode(propId) },
                    onAttachLayerToBone = { propId, hostId, boneId -> viewModel.attachLayerToBone(propId, hostId, boneId) },
                    onDetachLayerFromBone = { propId -> viewModel.detachLayerFromBoneAtCurrentFrame(propId) },
                    onCenterLayerOnBone = { propId -> viewModel.centerLayerPropOnBone(propId) },
                    onToggleRotateProp = { viewModel.togglePropRotateMode() },
                    onSetLayerScaleXY = { id, overall, sx, sy, reset ->
                        viewModel.setLayerScaleXY(id, overallScale = overall, scaleX = sx, scaleY = sy, reset = reset, recordUndo = reset)
                    }
                )
                InspectorTab.CHARACTER -> CharacterCreatorPanel(
                    uiState = uiState,
                    onApplyCharacter = { spec, asNew -> viewModel.upsertCharacterLayer(spec, asNew) },
                    onAutoRigCharacter = { spec -> viewModel.autoRigCharacterSpecIntoScene(spec) },
                    onSaveTemplate = { viewModel.saveCharacterTemplate(it) },
                    onKeyframeExpressionPose = { exp, pose -> viewModel.setCharacterFrameExpressionOrPose(exp, pose) },
                    onOpenCreateByCode = onOpenCreateByCode
                )
                InspectorTab.RIG -> RiggingInspectorPanel(
                    uiState = uiState,
                    customAssets = customAssets,
                    customActions = customActions,
                    onAddRigLayer = {
                        viewModel.addLayer(LayerType.RIG)
                        viewModel.selectTool(EditorTool.RIG_EDIT)
                    },
                    onAutoRigSelectedLayer = { viewModel.autoRigSelectedLayer() },
                    onInsertMascotRig = { viewModel.insertSavedRig(RigSolver.createCartoonMascotRig()) },
                    onSetViewAngle = { viewModel.setPuppetViewAngle(it) },
                    onSetHandProp = { isRight, prop -> viewModel.setStageHandPropSocket(isRight, prop) },
                    onImportHandPropPng = onImportHandPropPng,
                    onAddExtraRigBone = { area, prop -> viewModel.addExtraRigBoneToSelectedLayer(area, prop) },
                    onImportExtraRigPng = onImportExtraRigPng,
                    onAttachCustomAsset = { asset, area -> viewModel.attachCustomAssetToSelectedLayer(asset, area) },
                    onOpenCustomAssetMaker = { viewModel.openCustomAssetMaker() },
                    onUpdateBone = { bid, fn -> viewModel.updateSelectedLayerBone(bid, false, fn) },
                    onDeleteBone = { bid -> viewModel.deleteBoneFromSelectedLayer(bid) },
                    onSelectBone = { viewModel.selectBone(it) },
                    onAddChildBone = { viewModel.addChildBoneToRig(it) },
                    onApplyPosePreset = { viewModel.applyRigPosePreset(it) },
                    onToggleIk = { viewModel.toggleRigIkMode() },
                    onToggleSkin = { viewModel.toggleRigSkinMesh() },
                    onSaveRigTemplate = { viewModel.saveRigTemplate() },
                    onToggleStretchRig = { viewModel.toggleStretchRigMode() },
                    onToggleLiveRecord = { viewModel.toggleLiveRecordMode() },
                    onSetHandGesture = { isRight, pose -> viewModel.setPuppetHandGesture(isRight, pose) },
                    onSetEyebrow = { viewModel.setPuppetEyebrow(it) },
                    onToggleAutoDialogue = { viewModel.togglePuppetAutoDialogueActing() },
                    onApplyAutoAction = { viewModel.applyAutoAction(it) },
                    onApplyCustomAction = { viewModel.applyCustomActionToSelectedLayer(it) },
                    onDeleteCustomAction = { viewModel.deleteCustomAction(it) },
                    onUpdateBoneScaleAndSpring = { bid, len, wSc, lSc, stiff, damp ->
                        viewModel.updateSelectedBoneScaleAndSpring(bid, len, wSc, lSc, stiff, damp)
                    },
                    onApplyBonePartBehavior = { bid, preset ->
                        viewModel.applySelectedBonePartBehaviorPreset(bid, preset)
                    },
                    onSetBehaviorPreset = { preset ->
                        viewModel.setPuppetBehaviorPreset(preset)
                    },
                    onAdjustBoneZOrder = { bid, action ->
                        viewModel.adjustSelectedLayerBoneZOrder(bid, action)
                    },
                    onApplyAutoHumanLayerOrder = {
                        viewModel.applySelectedLayerAutoHumanLayerOrder()
                    },
                    onClearZOrderKeyframe = {
                        viewModel.clearSelectedLayerZOrderKeyframeAtCurrentFrame()
                    },
                    onUpdateFacialTiming = { transform ->
                        viewModel.updateSelectedRigFacialTiming(transform)
                    },
                    onToggleBoneLock = { bid -> viewModel.toggleStageBoneLock(bid) },
                    onToggleDetachBone = { bid, grav -> viewModel.toggleDetachBoneAtCurrentFrame(bid, grav) },
                    onSetPropGrabTarget = { hostId, boneId -> viewModel.setLayerPropGrabTargetAtCurrentFrame(hostId, boneId) },
                    onAddFormMorph = { name, spec, fx -> viewModel.addFormMorphKeyframeAtCurrentFrame(name, spec, null, fx) },
                    onSetLayerOpacityKf = { op -> viewModel.setLayerOpacityKeyframeAtCurrentFrame(op) },
                    onToggleInstantVisibilityKf = { vis -> viewModel.toggleInstantVisibilityKeyframeAtCurrentFrame(vis) },
                    onSetCameraShakeFlash = { sh, fl, col -> viewModel.setCameraShakeAndFlashAtCurrentFrame(sh, fl, col, null) },
                    onToggleUnlockCore = { viewModel.toggleUnlockCoreBones() }
                )
                InspectorTab.SCENE -> SceneCameraInspectorPanel(
                    uiState = uiState,
                    onSelectScene = { viewModel.selectScene(it) },
                    onAddScene = { viewModel.addScene("Scene ${(uiState.activeProject?.scenes?.size ?: 0) + 1}") },
                    onDeleteScene = { viewModel.deleteScene(it) },
                    onSetDuration = { viewModel.setSceneDuration(it) },
                    onAddFrames = { viewModel.addFrames(it) },
                    onSetBackgroundTemplate = { viewModel.setSceneBackgroundTemplate(it) },
                    onSetBackgroundColor = { viewModel.setSceneBackgroundColor(it) },
                    onSetBackgroundScrollSpeed = { viewModel.setSceneBackgroundScrollSpeed(it) },
                    onSetColorGrade = { viewModel.setSceneColorGrade(it) },
                    onToggleVfx = { viewModel.toggleSceneVfx(it) },
                    onAddSubtitle = { text, speaker, dur, style, color ->
                        viewModel.addSubtitleAtCurrentFrame(text, speaker, dur, style, color)
                    },
                    onDeleteSubtitle = { viewModel.deleteSubtitle(it) },
                    onSetTransition = { viewModel.setSceneTransition(it) },
                    onUpdateCamera = { px, py, z, r -> viewModel.updateCameraKeyframeAtCurrentFrame(px, py, z, r) },
                    onToggleCameraFrame = { viewModel.toggleCameraFrame() },
                    onToggleCameraHud = { viewModel.toggleCameraHud() },
                    onCameraFollowSelected = { viewModel.applyCameraFollowSelectedLayer() },
                    onCameraDollyZoom = { viewModel.applyCameraDollyZoomAtCurrentFrame() },
                    onCameraPanAcross = { viewModel.applyCameraPanAcrossAtCurrentFrame() },
                    onCameraShake = { viewModel.applyCameraShakeAtCurrentFrame() },
                    onJumpToFrame = { viewModel.setCurrentFrame(it) },
                    onDeleteCameraKeyframe = { viewModel.deleteCameraKeyframeAtFrame(it) },
                    onResetCamera = { viewModel.resetCameraKeyframes() },
                    onSetDepthBlur = { viewModel.setSceneDepthBlur(it) },
                    onToggleForegroundPlane = { viewModel.toggleSceneForegroundPlane() },
                    onSetCameraFollowLayer = { viewModel.setSceneCameraFollow(it) },
                    onUpdateSpotlight = { en, x, y, r, i, c -> viewModel.updateSceneSpotlight(en, x, y, r, i, c) },
                    onUpdateWatermark = { t, op, corner, clr -> viewModel.updateSceneWatermark(t, op, corner, clr) },
                    onImportWatermarkLogo = onImportWatermarkLogo
                )
                InspectorTab.AUDIO -> AudioStudioInspectorPanel(
                    uiState = uiState,
                    onRequestRecordVoice = onRequestRecordVoice,
                    onStopVoiceRecording = { viewModel.stopVoiceRecording() },
                    onImportAudio = onImportAudio,
                    onAddBuiltInPreset = { viewModel.addBuiltInAudioPreset(it) },
                    onPreviewTrack = { viewModel.previewAudioTrack(it) },
                    onUpdateTrack = { viewModel.updateAudioTrack(it) },
                    onApplyVoiceEffect = { track, fx -> viewModel.applyVoiceEffectToTrack(track, fx) },
                    onDeleteTrack = { viewModel.deleteAudioTrack(it) },
                    onToggleAutoDuck = { viewModel.toggleAudioAutoDuck(it) }
                )
                InspectorTab.ASSETS -> Column(modifier = Modifier.fillMaxSize()) {
                    val clips by viewModel.animatedFxClips.collectAsStateWithLifecycle()
                    if (clips.isNotEmpty()) {
                        Surface(
                            color = StudioSurfaceVariant,
                            border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Saved Animated FX Clips (1-Tap Loop Insert)", style = MaterialTheme.typography.labelSmall, color = StudioCoral, fontWeight = FontWeight.Bold)
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    clips.forEach { clip ->
                                        Surface(
                                            color = StudioCoral.copy(alpha = 0.16f),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, StudioCoral),
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable { viewModel.insertAnimatedFxClipOntoStage(clip, loopCount = 3) }
                                        ) {
                                            Text(
                                                "${clip.name} (${clip.durationFrames}f ×3)",
                                                fontSize = 10.sp,
                                                color = StudioTextPrimary,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = StudioViolet.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, StudioViolet),
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.setShowPartSketcherDialog(true) }
                                .testTag("assets_open_part_sketcher_btn")
                        ) {
                            Text(
                                "Draw Transparent PNG / Magic BG Eraser",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioViolet,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        AssetsLibraryPanel(
                            uiState = uiState,
                            localAssets = localAssets,
                            customAssets = customAssets,
                            onImportImage = onImportImage,
                            onImportSvg = onImportSvg,
                            onImportVideo = onImportVideo,
                            onInsertProp = { viewModel.insertProceduralProp(it) },
                            onInsertLocalImage = { path, name -> viewModel.insertLocalImageFile(path, name) },
                            onInsertSavedCharacter = { viewModel.upsertCharacterLayer(it, true) },
                            onInsertSavedRig = { viewModel.insertSavedRig(it) },
                            onOpenCustomAssetMaker = { viewModel.openCustomAssetMaker() },
                            onEditCustomAsset = { viewModel.openCharacterRigStudio(it) },
                            onInsertCustomAssetToScene = { viewModel.insertCustomAssetIntoScene(it) },
                            onAttachCustomAssetToRig = { viewModel.attachCustomAssetToSelectedLayer(it, com.example.engine.RigAttachmentArea.RIGHT_HAND) },
                            onDeleteCustomAsset = { viewModel.deleteCustomAsset(it) },
                            onDeleteLocalAsset = { viewModel.deleteLocalAssetWithFile(it) },
                            onDeleteSavedCharacter = { viewModel.deleteProjectSavedCharacter(it) },
                            onDeleteSavedRig = { viewModel.deleteProjectSavedRig(it) }
                        )
                    }
                }
            }
        }
    }
}



@Composable
private fun SwapCharacterAtFrameDialog(
    currentFrame: Int,
    activeLayerName: String,
    activeSwapCharacterId: String?,
    hasSwapOnCurrentFrame: Boolean,
    myCharacters: List<SkeletalRig>,
    builtInPresets: List<CharacterSpec>,
    onSelectCustomRig: (SkeletalRig) -> Unit,
    onSelectPreset: (CharacterSpec) -> Unit,
    onRemoveSwapAtFrame: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(20.dp))
                    Text(
                        text = "Swap Character at F${currentFrame + 1}",
                        color = StudioTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Layer \"$activeLayerName\" • Inserts a ◆ step-hold swap keyframe (preserves position, scale & pose)",
                    color = StudioTextSecondary,
                    fontSize = 11.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (hasSwapOnCurrentFrame) {
                    Surface(
                        color = StudioCoral.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, StudioCoral),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onRemoveSwapAtFrame)
                            .testTag("swap_char_remove_keyframe_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Remove Swap Keyframe ◆ at F${currentFrame + 1}",
                                color = StudioCoral,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text("Revert", color = StudioCoral, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                if (myCharacters.isNotEmpty()) {
                    Text(
                        "SAVED CUSTOM CHARACTERS (${myCharacters.size})",
                        color = StudioCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    myCharacters.forEach { rig ->
                        val isActive = activeSwapCharacterId == rig.id
                        val outfitTint = rig.characterAppearance?.shirtColorArgb?.let { Color(it) } ?: StudioCyan
                        Surface(
                            color = if (isActive) StudioEmerald.copy(alpha = 0.18f) else StudioSurface,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isActive) StudioEmerald else StudioBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectCustomRig(rig) }
                                .testTag("swap_custom_char_${rig.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(outfitTint.copy(alpha = 0.28f))
                                        .border(1.5.dp, outfitTint, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.Face, contentDescription = null, tint = outfitTint, modifier = Modifier.size(18.dp))
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        rig.name.ifBlank { "Custom Character" },
                                        color = StudioTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${rig.bones.size} bones • ${rig.rigCategory}",
                                        color = StudioTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    if (isActive) "Active ◆" else "Swap",
                                    color = if (isActive) StudioEmerald else StudioAmber,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Text(
                    "BUILT-IN CHARACTERS (${builtInPresets.size})",
                    color = StudioAmber,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                builtInPresets.forEach { spec ->
                    val stableId = "preset_${spec.name.lowercase().replace(Regex("[^a-z0-9]+"), "_")}"
                    val isActive = activeSwapCharacterId == stableId
                    val accent = Color(spec.shirtColorArgb)
                    Surface(
                        color = if (isActive) StudioEmerald.copy(alpha = 0.18f) else StudioSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isActive) StudioEmerald else StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectPreset(spec) }
                            .testTag("swap_preset_char_$stableId")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(spec.skinToneArgb))
                                    .border(2.dp, accent, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    spec.name.take(1).uppercase(),
                                    color = Color.Black,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    spec.name,
                                    color = StudioTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "${spec.shirtStyle} • ${spec.hairStyle}",
                                    color = StudioTextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                            Text(
                                if (isActive) "Active ◆" else "Swap",
                                color = if (isActive) StudioEmerald else StudioAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = StudioTextSecondary)
            }
        }
    )
}

private fun toolIcon(tool: EditorTool): ImageVector = when (tool) {
    EditorTool.PENCIL -> Icons.Rounded.Create
    EditorTool.BRUSH -> Icons.Rounded.Brush
    EditorTool.AIRBRUSH -> Icons.Rounded.Grain
    EditorTool.ERASER -> Icons.Rounded.AutoFixHigh
    EditorTool.BUCKET -> Icons.Rounded.FormatColorFill
    EditorTool.PEN_BEZIER -> Icons.Rounded.Gesture
    EditorTool.LINE -> Icons.Rounded.HorizontalRule
    EditorTool.RECTANGLE -> Icons.Rounded.CropSquare
    EditorTool.CIRCLE -> Icons.Rounded.Circle
    EditorTool.POLYGON -> Icons.Rounded.ChangeHistory
    EditorTool.TEXT -> Icons.Rounded.TextFields
    EditorTool.EYEDROPPER -> Icons.Rounded.Colorize
    EditorTool.SELECT -> Icons.Rounded.OpenWith
    EditorTool.RIG_EDIT -> Icons.Rounded.AccessibilityNew
    EditorTool.MOTION_PATH -> Icons.Rounded.Timeline
    EditorTool.HAND_PAN -> Icons.Rounded.PanTool
}



