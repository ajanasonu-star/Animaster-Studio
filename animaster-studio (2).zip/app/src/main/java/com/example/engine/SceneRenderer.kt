package com.example.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.util.LruCache
import android.graphics.BlurMaskFilter
import android.graphics.PorterDuffXfermode
import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationProject
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.BackgroundTemplate
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterSpec
import com.example.data.model.CharacterViewAngle
import com.example.data.model.CustomEyeContainer
import com.example.data.model.CustomEyeSlot
import com.example.data.model.CustomMouthSlot
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FaceAngleAdjustment
import com.example.data.model.FaceFeatureTransform
import com.example.data.model.FaceLayersConfig
import com.example.data.model.FaceMoodCategory
import com.example.data.model.FacialTimingConfig
import com.example.data.model.FrameContent
import com.example.data.model.HandGesturePose
import com.example.data.model.HandPropKind
import com.example.data.model.ImportedImageItem
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.NoseStylePreset
import com.example.data.model.PartBehaviorPreset
import com.example.data.model.RigBone
import com.example.data.model.SceneColorGrade
import com.example.data.model.SceneVfxType
import com.example.data.model.ShapeKind
import com.example.data.model.SkeletalRig
import com.example.data.model.SubtitleCue
import com.example.data.model.SubtitleStyle
import com.example.data.model.TextBoxStyle
import com.example.data.model.TextFontStyle
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.TextOutAnimation
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Deterministic high-performance 2D Canvas renderer shared between the live editor,
 * Character & Rig Studio, and the offline PNG / GIF / MP4 / WebM export pipeline.
 */
object SceneRenderer {

    private val bitmapCache = object : LruCache<String, Bitmap>(96) {}
    private val videoFrameCache = object : LruCache<String, Bitmap>(16) {}

    private const val MAX_PART_BITMAP_DIM = 1024
    private const val MAX_BG_BITMAP_DIM = 1920

    /**
     * Module 11: Mobile RAM Protection — Fast Proxy Preview (Low RAM Mode) caps preview textures at 512px/960px.
     * Automatically bypassed during high-resolution exports.
     */
    @Volatile
    var fastProxyPreviewMode: Boolean = false

    fun clearBitmapCache() {
        bitmapCache.evictAll()
    }

    const val PRISMA_ROTATION_RING_RADIUS = 28f

    /**
     * Pre-decodes all character PNGs, facial sprites, props, and background images once into
     * the in-memory bitmap cache before export loops so HD MP4 export renders 3x-5x faster.
     */
    fun prewarmProjectBitmaps(project: AnimationProject) {
        fun prewarmRig(rig: SkeletalRig) {
            rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            rig.customNoseImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            rig.leftHandCustomImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            rig.rightHandCustomImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            rig.bones.forEach { b ->
                b.boundImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            }
            rig.customEyeSlots.values.forEach { getCachedBitmap(it, forceFullRes = true) }
            rig.customMouthSlots.values.forEach { getCachedBitmap(it, forceFullRes = true) }
            rig.customHandPoseSlots.values.forEach { getCachedBitmap(it, forceFullRes = true) }
            listOf(rig.leftEyeContainer, rig.rightEyeContainer).forEach { ec ->
                ec.scleraImagePath?.let { getCachedBitmap(it, forceFullRes = true) }
                ec.pupilImagePath?.let { getCachedBitmap(it, forceFullRes = true) }
                ec.eyelidImagePath?.let { getCachedBitmap(it, forceFullRes = true) }
            }
            val fl = rig.faceLayers
            fl.leftBrowImagePath?.let { getCachedBitmap(it, forceFullRes = true) }
            fl.rightBrowImagePath?.let { getCachedBitmap(it, forceFullRes = true) }
            fl.eyeBuilderFrames.forEach { getCachedBitmap(it, forceFullRes = true) }
            fl.mouthBuilderFrames.forEach { getCachedBitmap(it, forceFullRes = true) }
            fl.browBuilderFrames.forEach { getCachedBitmap(it, forceFullRes = true) }
            rig.eyeMoodSets.values.forEach { es ->
                listOf(es.openImagePath, es.halfBlinkImagePath, es.closedImagePath, es.pupilImagePath, es.eyelidImagePath)
                    .forEach { p -> p?.let { getCachedBitmap(it, forceFullRes = true) } }
            }
            rig.mouthMoodSets.values.forEach { ms ->
                listOf(
                    ms.frame1SilentClosed,
                    ms.frame2SilentIdle,
                    ms.frame3SoftSpeech,
                    ms.frame4MediumSpeech,
                    ms.frame5WideSpeech,
                    ms.frame6PeakEmotion
                ).forEach { p -> p?.let { getCachedBitmap(it, forceFullRes = true) } }
            }
            rig.handPropSocketKeyframes.forEach { kp ->
                kp.customImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            }
        }
        project.scenes.forEach { sc ->
            sc.watermarkImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it, forceFullRes = true) }
            sc.layers.forEach { layer ->
                val isBg = layer.type == LayerType.BACKGROUND.name
                layer.frames.values.forEach { fc ->
                    fc.images.forEach { img -> getCachedBitmap(img.filePath, isBackground = isBg, forceFullRes = true) }
                }
                layer.rig?.let(::prewarmRig)
                layer.characterSwapRigs.values.forEach(::prewarmRig)
            }
        }
    }

    fun getCachedBitmap(path: String, isBackground: Boolean = false, forceFullRes: Boolean = false): Bitmap? {
        if (path.isBlank()) return null
        val useProxy = fastProxyPreviewMode && !forceFullRes
        val maxDim = when {
            isBackground && useProxy -> 960
            isBackground -> MAX_BG_BITMAP_DIM
            useProxy -> 512
            else -> MAX_PART_BITMAP_DIM
        }
        val cacheKey = "$path@$maxDim"
        bitmapCache.get(cacheKey)?.let { if (!it.isRecycled) return it }
        val file = File(path)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        return runCatching {
            // Module 11: Strict OOM-safe downsampling (1024px parts / 1920px backgrounds; half in Fast Proxy mode)
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, boundsOpts)
            val rawW = boundsOpts.outWidth
            val rawH = boundsOpts.outHeight
            if (rawW <= 0 || rawH <= 0) return@runCatching null
            var sampleSize = 1
            while ((rawW / sampleSize) > maxDim || (rawH / sampleSize) > maxDim) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inSampleSize = sampleSize
            }
            BitmapFactory.decodeFile(path, decodeOpts)?.also { bitmapCache.put(cacheKey, it) }
        }.getOrNull()
    }

    private fun getCachedVideoFrame(path: String, timeUs: Long): Bitmap? {
        if (path.isBlank()) return null
        val file = File(path)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        // Bucket video frame lookups to 100ms intervals for smooth scrubbing performance
        val bucketUs = (timeUs / 100_000L) * 100_000L
        val key = "$path@$bucketUs"
        videoFrameCache.get(key)?.let { if (!it.isRecycled) return it }
        return runCatching {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(path)
                val bmp = mmr.getFrameAtTime(bucketUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                bmp?.also { videoFrameCache.put(key, it) }
            } finally {
                runCatching { mmr.release() }
            }
        }.getOrNull()
    }

    fun renderSceneToBitmap(
        scene: AnimationScene,
        frame: Int,
        outWidth: Int,
        outHeight: Int,
        projectWidth: Int,
        projectHeight: Int,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = false,
        showMotionPaths: Boolean = false,
        selectedLayerId: String? = null,
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false
    ): Bitmap {
        val bmp = Bitmap.createBitmap(outWidth.coerceAtLeast(16), outHeight.coerceAtLeast(16), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (transparentBackground && !chromaKeyGreen) {
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        }
        val sx = outWidth.toFloat() / projectWidth.toFloat()
        val sy = outHeight.toFloat() / projectHeight.toFloat()
        canvas.scale(sx, sy)
        renderScene(
            canvas = canvas,
            scene = scene,
            frame = frame,
            projectWidth = projectWidth.toFloat(),
            projectHeight = projectHeight.toFloat(),
            fps = fps,
            audioTracks = audioTracks,
            onionSkin = onionSkin,
            ghostFrames = ghostFrames,
            showRigBones = showRigBones,
            showMotionPaths = showMotionPaths,
            showSelectionBox = false,
            selectedLayerId = if (showRigBones) selectedLayerId else null,
            selectedBoneId = null,
            selectedTextId = null,
            transparentBackground = transparentBackground,
            chromaKeyGreen = chromaKeyGreen
        )
        return bmp
    }

    /**
     * Zero-allocation frame renderer for high-speed hardware-accelerated MP4 export:
     * clears and draws directly into a caller-owned reusable ARGB_8888 Bitmap + Canvas.
     */
    fun renderSceneIntoBitmap(
        targetBitmap: Bitmap,
        targetCanvas: Canvas,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Int,
        projectHeight: Int,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false
    ) {
        val outWidth = targetBitmap.width.coerceAtLeast(16)
        val outHeight = targetBitmap.height.coerceAtLeast(16)
        targetCanvas.save()
        if (transparentBackground && !chromaKeyGreen) {
            targetCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        }
        val sx = outWidth.toFloat() / projectWidth.toFloat()
        val sy = outHeight.toFloat() / projectHeight.toFloat()
        targetCanvas.scale(sx, sy)
        renderScene(
            canvas = targetCanvas,
            scene = scene,
            frame = frame,
            projectWidth = projectWidth.toFloat(),
            projectHeight = projectHeight.toFloat(),
            fps = fps,
            audioTracks = audioTracks,
            onionSkin = false,
            ghostFrames = false,
            showRigBones = false,
            showMotionPaths = false,
            showSelectionBox = false,
            selectedLayerId = null,
            selectedBoneId = null,
            selectedTextId = null,
            transparentBackground = transparentBackground,
            chromaKeyGreen = chromaKeyGreen
        )
        targetCanvas.restore()
    }

    fun renderScene(
        canvas: Canvas,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Float,
        projectHeight: Float,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList(),
        onionSkin: Boolean = false,
        ghostFrames: Boolean = false,
        showRigBones: Boolean = true,
        showMotionPaths: Boolean = true,
        showSelectionBox: Boolean = false,
        showCameraFrame: Boolean = false,
        selectedLayerId: String? = null,
        selectedBoneId: String? = null,
        selectedTextId: String? = null,
        activePreviewStroke: DrawStroke? = null,
        activePreviewShape: VectorShape? = null,
        activePreviewMotionPath: List<Vec2>? = null,
        transparentBackground: Boolean = false,
        chromaKeyGreen: Boolean = false,
        celOnionNext: Boolean = true,
        celOnionOpacity: Float = 0.34f,
        propRotateMode: Boolean = false,
        moveCharMode: Boolean = false,
        bonePickHighlightMode: Boolean = false
    ) {
        val rawCamera = InterpolationEngine.evaluateCamera(scene, frame, projectWidth, projectHeight)
        // Module 11: Deterministic Keyframeable Camera Shake jitter
        val camera = if (rawCamera.shakeIntensity > 0.01f) {
            val amp = rawCamera.shakeIntensity.coerceIn(0f, 1f)
            val rng = Random(frame * 7919 + 31)
            rawCamera.copy(
                panX = rawCamera.panX + (rng.nextFloat() * 2f - 1f) * 28f * amp,
                panY = rawCamera.panY + (rng.nextFloat() * 2f - 1f) * 22f * amp,
                rotationDeg = rawCamera.rotationDeg + (rng.nextFloat() * 2f - 1f) * 3.8f * amp
            )
        } else rawCamera

        // 1. Background (with automatic continuous scroll + optional Background Depth Blur)
        val scrollOffsetX = frame * scene.backgroundScrollSpeed * 2.5f
        val bgPanX = camera.panX * 0.35f + scrollOffsetX
        val bgPanY = camera.panY * 0.35f
        if (chromaKeyGreen) {
            canvas.drawColor(Color.rgb(0, 255, 0))
        } else if (!transparentBackground) {
            drawBackgroundTemplate(
                canvas = canvas,
                templateName = scene.backgroundTemplate,
                bgColorArgb = scene.backgroundColorArgb,
                w = projectWidth,
                h = projectHeight,
                panX = bgPanX,
                panY = bgPanY,
                frame = frame
            )
            // Soft atmospheric Depth-of-Field blur veil when Background Depth Blur > 0
            if (scene.backgroundDepthBlur > 0.02f) {
                val blurStrength = scene.backgroundDepthBlur.coerceIn(0f, 1f)
                val veilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(
                        projectWidth * 0.5f,
                        projectHeight * 0.45f,
                        hypot(projectWidth, projectHeight) * 0.7f,
                        Color.argb((blurStrength * 42f).toInt(), 255, 255, 255),
                        Color.argb((blurStrength * 115f).toInt(), 15, 23, 42),
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, projectWidth, projectHeight, veilPaint)
            }
        }

        // Visible layers at this exact frame (respecting Module 8 Frame-Range Visibility!)
        val activeVisibleLayers = scene.layers.filter { layer ->
            layer.visible && InterpolationEngine.isLayerVisibleAtFrame(layer, frame)
        }

        // 2. Onion-Skin Watermark Trail (both Standard Studio AND Module 7 Cel Studio Auto-Hide Onion Watermark)
        if (onionSkin || ghostFrames) {
            val offsets = if (ghostFrames) listOf(-3, -2, -1, 1, 2) else if (celOnionNext) listOf(-1, 1) else listOf(-1)
            for (delta in offsets) {
                val targetF = frame + delta
                if (targetF in 0 until scene.durationFrames) {
                    scene.layers.filter {
                        it.visible && it.type != LayerType.VIDEO.name &&
                            InterpolationEngine.isLayerVisibleAtFrame(it, targetF)
                    }.forEach { layer ->
                        val isCel = layer.isCelFrameByFrame
                        val alpha = when {
                            isCel && delta == -1 -> celOnionOpacity.coerceIn(0.12f, 0.65f)
                            isCel && delta == 1 -> (celOnionOpacity * 0.72f).coerceIn(0.10f, 0.50f)
                            kotlin.math.abs(delta) == 1 -> 0.25f
                            else -> 0.14f
                        }
                        val tint = when {
                            isCel && delta < 0 -> 0xFFFB7185L // Rose-red previous cel watermark
                            isCel && delta > 0 -> 0xFF22D3EEL // Cyan next cel watermark
                            delta < 0 -> 0xFFA78BFAL
                            else -> 0xFF2DD4BFL
                        }
                        drawLayerAtFrame(
                            canvas = canvas,
                            scene = scene,
                            layer = layer,
                            frame = targetF,
                            fps = fps,
                            audioTracks = audioTracks,
                            camera = camera,
                            projectWidth = projectWidth,
                            projectHeight = projectHeight,
                            overrideAlpha = alpha,
                            tintColorArgb = tint,
                            showRigOverlay = showRigBones && !isCel,
                            isSelectedLayer = false,
                            selectedBoneId = null,
                            maskLayerBelow = null,
                            allowEffects = false
                        )
                    }
                }
            }
        }

        // 3. Current Frame Layers (Mid-ground -> Multi-Plane Foreground Props -> Foreground Overlays)
        val midLayers = activeVisibleLayers.filter { it.parallaxDepth <= 1.15f }
        val foreLayers = activeVisibleLayers.filter { it.parallaxDepth > 1.15f }

        fun renderLayerList(list: List<AnimationLayer>, allOrdered: List<AnimationLayer>) {
            list.forEach { layer ->
                val isSel = layer.id == selectedLayerId
                val idxInAll = allOrdered.indexOfFirst { it.id == layer.id }
                val belowLayer = if (layer.maskToLayerBelow && idxInAll > 0) allOrdered[idxInAll - 1] else null

                drawLayerAtFrame(
                    canvas = canvas,
                    scene = scene,
                    layer = layer,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    camera = camera,
                    projectWidth = projectWidth,
                    projectHeight = projectHeight,
                    overrideAlpha = null,
                    tintColorArgb = null,
                    showRigOverlay = showRigBones,
                    isSelectedLayer = isSel,
                    selectedBoneId = if (isSel) selectedBoneId else null,
                    maskLayerBelow = belowLayer,
                    allowEffects = true,
                    moveCharMode = moveCharMode && isSel,
                    bonePickHighlightMode = bonePickHighlightMode
                )

                // Direct On-Canvas Touch Handles for selected layer in SELECT mode AND for any selected Image/Prop layer
                val isEditableImageOrProp = layer.rig == null &&
                    layer.type != LayerType.BACKGROUND.name &&
                    layer.type != LayerType.VIDEO.name &&
                    layer.type != LayerType.RIG.name
                if (isSel && !propRotateMode && !bonePickHighlightMode && (showSelectionBox || isEditableImageOrProp)) {
                    val bounds = computeEffectiveLayerBounds(
                        scene = scene,
                        layer = layer,
                        frame = frame,
                        projectWidth = projectWidth,
                        projectHeight = projectHeight,
                        audioTracks = audioTracks,
                        fps = fps
                    )
                    if (bounds != null) {
                        val pivot = computeLayerPivot(layer, frame, scene.durationFrames, projectWidth, projectHeight)
                        val propWorld = InterpolationEngine.resolvePropWorldTransform(
                            scene = scene,
                            layer = layer,
                            pivot = pivot,
                            frame = frame,
                            audioTracks = audioTracks,
                            fps = fps
                        )
                        canvas.save()
                        applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)
                        drawSelectionTouchHandles(canvas, bounds, propWorld.worldAngleDeg, layer.pivotMode)
                        canvas.restore()
                    }
                }

                // Dedicated Prisma 3D-Style Circular Prop Rotation Ring when "Rotate Prop" is active on a rigid prop layer
                if (propRotateMode && isSel && layer.rig == null) {
                    val pivot = computeLayerPivot(layer, frame, scene.durationFrames, projectWidth, projectHeight)
                    val propWorld = InterpolationEngine.resolvePropWorldTransform(
                        scene = scene,
                        layer = layer,
                        pivot = pivot,
                        frame = frame,
                        audioTracks = audioTracks,
                        fps = fps
                    )
                    canvas.save()
                    applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)
                    drawPropRotationRing(
                        canvas = canvas,
                        centerX = propWorld.worldX,
                        centerY = propWorld.worldY,
                        angleDeg = propWorld.worldAngleDeg,
                        label = layer.name,
                        isAttached = propWorld.isAttached
                    )
                    canvas.restore()
                }

                if (showMotionPaths && layer.motionPath.size >= 2) {
                    canvas.save()
                    applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)
                    drawMotionPathOverlay(
                        canvas = canvas,
                        points = layer.motionPath,
                        isSelected = isSel,
                        currentProgress = InterpolationEngine.evaluateMotionPathProgress(layer, frame, scene.durationFrames)
                    )
                    canvas.restore()
                }
            }
        }

        renderLayerList(midLayers, activeVisibleLayers)

        // 3b. Multi-Plane Foreground Architecture / Trees (rendered IN FRONT of mid-ground characters!)
        if (scene.foregroundPlaneEnabled && !transparentBackground && !chromaKeyGreen) {
            drawBackgroundForegroundPlane(
                canvas = canvas,
                templateName = scene.backgroundTemplate,
                w = projectWidth,
                h = projectHeight,
                panX = camera.panX * 1.25f + scrollOffsetX * 1.35f,
                panY = camera.panY * 1.15f,
                frame = frame
            )
        }

        renderLayerList(foreLayers, activeVisibleLayers)

        // 4. Aesthetic, Weather & Horror Scene VFX Overlays
        if (scene.activeVfx.isNotEmpty() && !chromaKeyGreen) {
            drawSceneVfx(canvas, scene.activeVfx, projectWidth, projectHeight, frame)
        }

        // 4a. Directional Spotlight / Sunlight Cone (Module 9)
        if (scene.spotlightEnabled && !chromaKeyGreen) {
            drawDirectionalSpotlight(canvas, scene, projectWidth, projectHeight)
        }

        // 4b. Cinematic Color Grading Filter (Horror Cold, Midnight, Retro VHS, Noir B&W, Warm Glow)
        if (!chromaKeyGreen && !transparentBackground && scene.colorGrade != SceneColorGrade.NONE.name) {
            drawColorGradeOverlay(canvas, scene.colorGrade, projectWidth, projectHeight, frame)
        }

        // 4c. Dynamic YouTube Subtitles & Captions Track
        if (scene.subtitles.isNotEmpty()) {
            drawSubtitles(canvas, scene.subtitles, frame, projectWidth, projectHeight)
        }

        // 4d. Kinetic Animated Text & Title Layers (visible across scene timeline)
        if (scene.animatedTexts.isNotEmpty()) {
            scene.animatedTexts.filter { it.visible }.forEach { textItem ->
                drawTextItem(
                    canvas = canvas,
                    item = textItem,
                    frame = frame,
                    layerAlpha = 1f,
                    tintColorArgb = null,
                    isSelected = (textItem.id == selectedTextId)
                )
            }
        }

        // 4e. Channel Brand Watermark / Logo (rendered cleanly on BOTH preview and export!)
        if (!scene.watermarkText.isNullOrBlank() || !scene.watermarkImagePath.isNullOrBlank()) {
            drawChannelWatermark(canvas, scene, projectWidth, projectHeight)
        }

        // 5. Live in-progress stroke / shape / motion path preview (exact selected layer transform for 0px offset!)
        val previewLayer = scene.layers.firstOrNull { it.id == selectedLayerId }
        if (activePreviewStroke != null || activePreviewShape != null) {
            canvas.save()
            val parallax = previewLayer?.parallaxDepth ?: 1f
            applyCameraTransform(canvas, camera, projectWidth, projectHeight, parallax)
            if (previewLayer != null) {
                val tf = InterpolationEngine.evaluateLayerTransform(previewLayer, frame, scene.durationFrames)
                val bgShiftX = InterpolationEngine.computeBgScrollShiftX(previewLayer, scene, frame, projectWidth)
                val pivot = computeLayerPivot(previewLayer, frame, scene.durationFrames, projectWidth, projectHeight)
                canvas.translate(pivot.x + tf.x + bgShiftX, pivot.y + tf.y)
                canvas.rotate(tf.rotationDeg)
                canvas.scale(tf.scaleX, tf.scaleY)
                canvas.translate(-pivot.x, -pivot.y)
            }
            activePreviewStroke?.let { drawStroke(canvas, it, 1f, null) }
            activePreviewShape?.let { drawVectorShape(canvas, it, 1f, null) }
            canvas.restore()
        }
        if (activePreviewMotionPath != null && activePreviewMotionPath.size >= 2) {
            canvas.save()
            applyCameraTransform(canvas, camera, projectWidth, projectHeight, previewLayer?.parallaxDepth ?: 1f)
            drawMotionPathOverlay(canvas, activePreviewMotionPath, isSelected = true, currentProgress = null)
            canvas.restore()
        }

        // 5b. Module 11: Keyframeable Action Impact Flash & Face FX Horror Flash Overlay
        if (!chromaKeyGreen && camera.impactFlashAlpha > 0.01f) {
            val fc = camera.impactFlashColorArgb.toInt()
            val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(
                    (camera.impactFlashAlpha.coerceIn(0f, 1f) * 235f).toInt(),
                    Color.red(fc),
                    Color.green(fc),
                    Color.blue(fc)
                )
            }
            canvas.drawRect(0f, 0f, projectWidth, projectHeight, flashPaint)
        }
        if (!chromaKeyGreen) {
            activeVisibleLayers.mapNotNull { it.rig }.forEach { rig ->
                val trig = rig.faceFxTriggers.firstOrNull { frame in it.frame..(it.frame + it.durationFrames) }
                val trigFlash = trig?.flashColorArgb
                if (trig != null && trigFlash != null) {
                    val pulse = sin(((frame - trig.frame).toFloat() / trig.durationFrames.coerceAtLeast(1)) * PI).toFloat()
                    val cInt = trigFlash.toInt()
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb(
                            (Color.alpha(cInt) * pulse.coerceIn(0f, 1f)).toInt(),
                            Color.red(cInt),
                            Color.green(cInt),
                            Color.blue(cInt)
                        )
                    }
                    canvas.drawRect(0f, 0f, projectWidth, projectHeight, p)
                }
            }
        }

        // 6. Visual Camera Motion Director Viewfinder Frame (editor HUD only; never on export!)
        if (showCameraFrame) {
            drawCameraViewportFrame(canvas, camera, projectWidth, projectHeight)
        }
    }

    private fun drawDirectionalSpotlight(
        canvas: Canvas,
        scene: AnimationScene,
        w: Float,
        h: Float
    ) {
        val sx = (scene.spotlightX.coerceIn(0f, 1f)) * w
        val sy = (scene.spotlightY.coerceIn(0f, 1f)) * h
        val r = (scene.spotlightRadius.coerceIn(0.15f, 1.5f)) * max(w, h) * 0.65f
        val intensity = scene.spotlightIntensity.coerceIn(0.05f, 1f)
        val cInt = scene.spotlightColorArgb.toInt()
        val cr = Color.red(cInt); val cg = Color.green(cInt); val cb = Color.blue(cInt)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        // Subtle theatrical darkening outside the spotlight cone
        paint.shader = RadialGradient(
            sx, sy, r * 1.45f,
            intArrayOf(
                Color.argb((intensity * 115f).toInt().coerceIn(0, 255), cr, cg, cb),
                Color.argb((intensity * 45f).toInt().coerceIn(0, 255), cr, cg, cb),
                Color.argb((intensity * 105f).toInt().coerceIn(0, 255), 2, 6, 23)
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    private fun drawChannelWatermark(
        canvas: Canvas,
        scene: AnimationScene,
        w: Float,
        h: Float
    ) {
        val op = (scene.watermarkOpacity.coerceIn(0.08f, 1f) * 255f).toInt()
        val margin = 26f
        val corner = scene.watermarkCorner.uppercase()
        val logoBmp = scene.watermarkImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        val text = scene.watermarkText.trim()

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            alpha = op
            textSize = (min(w, h) * 0.036f).coerceIn(18f, 36f)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(4f, 1.5f, 1.5f, Color.argb((op * 0.8f).toInt(), 0, 0, 0))
        }
        val logoSize = if (logoBmp != null) 46f else 0f
        val textW = if (text.isNotEmpty()) textPaint.measureText(text) else 0f
        val gap = if (logoBmp != null && text.isNotEmpty()) 10f else 0f
        val totalW = logoSize + gap + textW
        val totalH = max(logoSize, textPaint.textSize * 1.15f)

        val left = when (corner) {
            "TOP_LEFT", "BOTTOM_LEFT" -> margin
            else -> w - margin - totalW
        }
        val top = when (corner) {
            "TOP_LEFT", "TOP_RIGHT" -> margin
            else -> h - margin - totalH
        }

        // Subtle dark translucent badge behind channel brand
        val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((op * 0.42f).toInt(), 10, 14, 24)
        }
        canvas.drawRoundRect(
            RectF(left - 12f, top - 8f, left + totalW + 12f, top + totalH + 8f),
            12f, 12f, pillPaint
        )

        var curX = left
        if (logoBmp != null) {
            val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = op }
            canvas.drawBitmap(logoBmp, null, RectF(curX, top + (totalH - logoSize) / 2f, curX + logoSize, top + (totalH + logoSize) / 2f), lp)
            curX += logoSize + gap
        }
        if (text.isNotEmpty()) {
            canvas.drawText(text, curX, top + totalH * 0.72f, textPaint)
        }
    }

    private fun drawCameraViewportFrame(canvas: Canvas, camera: EvaluatedCamera, w: Float, h: Float) {
        val margin = 16f
        val rect = RectF(margin, margin, w - margin, h - margin)

        // Subtle rule-of-thirds guides
        val thirdPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x44FBBF24
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }
        canvas.drawLine(w / 3f, margin, w / 3f, h - margin, thirdPaint)
        canvas.drawLine(w * 2f / 3f, margin, w * 2f / 3f, h - margin, thirdPaint)
        canvas.drawLine(margin, h / 3f, w - margin, h / 3f, thirdPaint)
        canvas.drawLine(margin, h * 2f / 3f, w - margin, h * 2f / 3f, thirdPaint)

        // Outer cinematic amber border + corner viewfinder brackets
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCFBBF24.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRect(rect, framePaint)

        val bracketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFF6B35.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
        }
        val bLen = 42f
        // Top-Left
        canvas.drawLine(rect.left, rect.top, rect.left + bLen, rect.top, bracketPaint)
        canvas.drawLine(rect.left, rect.top, rect.left, rect.top + bLen, bracketPaint)
        // Top-Right
        canvas.drawLine(rect.right - bLen, rect.top, rect.right, rect.top, bracketPaint)
        canvas.drawLine(rect.right, rect.top, rect.right, rect.top + bLen, bracketPaint)
        // Bottom-Left
        canvas.drawLine(rect.left, rect.bottom - bLen, rect.left, rect.bottom, bracketPaint)
        canvas.drawLine(rect.left, rect.bottom, rect.left + bLen, rect.bottom, bracketPaint)
        // Bottom-Right
        canvas.drawLine(rect.right - bLen, rect.bottom, rect.right, rect.bottom, bracketPaint)
        canvas.drawLine(rect.right, rect.bottom - bLen, rect.right, rect.bottom, bracketPaint)

        // Center crosshair
        val cx = w / 2f
        val cy = h / 2f
        canvas.drawLine(cx - 16f, cy, cx + 16f, cy, framePaint)
        canvas.drawLine(cx, cy - 16f, cx, cy + 16f, framePaint)

        // Live Camera Telemetry Pill
        val label = String.format(
            Locale.US,
            "CAM %.2fx  •  PAN (%d, %d)  •  TILT %d°",
            camera.zoom, camera.panX.toInt(), camera.panY.toInt(), camera.rotationDeg.toInt()
        )
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFBBF24.toInt()
            textSize = 20f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val tw = textPaint.measureText(label) + 28f
        val pill = RectF(cx - tw / 2f, rect.bottom - 42f, cx + tw / 2f, rect.bottom - 10f)
        val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC0D0F14.toInt() }
        canvas.drawRoundRect(pill, 12f, 12f, pillBg)
        canvas.drawRoundRect(pill, 12f, 12f, framePaint)
        canvas.drawText(label, cx, pill.centerY() + 7f, textPaint)
    }

    /**
     * Computes raw untransformed visual bounds of a layer's artwork/rig so Module 1
     * Center-Pivot vs Bottom-Feet scaling NEVER jumps up or down on stage!
     */
    fun computeRawLayerContentBounds(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int
    ): RectF? {
        val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        fun include(x: Float, y: Float) {
            if (!x.isFinite() || !y.isFinite()) return
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }

        content?.strokes?.forEach { s -> s.points.forEach { include(it.x, it.y) } }
        content?.shapes?.filter { it.kind != ShapeKind.FILL_BACKDROP.name }?.forEach { s ->
            include(s.startX, s.startY); include(s.endX, s.endY)
        }
        content?.images?.forEach { img ->
            val sx = if (img.scaleX.isFinite() && img.scaleX >= 0.05f) img.scaleX else 1f
            val sy = if (img.scaleY.isFinite() && img.scaleY >= 0.05f) img.scaleY else 1f
            val hw = (img.width * sx) / 2f
            val hh = (img.height * sy) / 2f
            include(img.x - hw, img.y - hh)
            include(img.x + hw, img.y + hh)
        }
        content?.texts?.forEach { t ->
            val tb = computeTextBounds(t)
            include(tb.left, tb.top); include(tb.right, tb.bottom)
        }
        layer.character?.let { c ->
            include(c.x - 90f * c.scale, c.y - 170f * c.scale)
            include(c.x + 90f * c.scale, c.y + 170f * c.scale)
        }
        InterpolationEngine.resolveEffectiveRigAtFrame(layer, frame)?.let { rig ->
            val pRoot = InterpolationEngine.evaluatePuppetRootWithPath(layer, rig, frame, totalFrames)
            val angles = InterpolationEngine.evaluateRigAnglesWithPath(layer, rig, frame, totalFrames)
            val lengths = InterpolationEngine.evaluateBoneLengths(rig, frame)
            val viewAngle = runCatching { CharacterViewAngle.valueOf(pRoot.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
            val effFlip = isLeftFacingView(viewAngle, pRoot.flippedHorizontal)
            val solved = RigSolver.solveForwardKinematics(
                rig = rig,
                angleOverrides = angles,
                rootX = pRoot.rootX,
                rootY = pRoot.rootY,
                scale = pRoot.scale,
                flippedHorizontal = effFlip,
                lengthOverrides = lengths,
                scaleX = pRoot.scaleX,
                scaleY = pRoot.scaleY,
                frame = frame,
                viewAngle = viewAngle
            )
            solved.forEach { sb ->
                include(sb.start.x - 28f * pRoot.scale * pRoot.scaleX, sb.start.y - 28f * pRoot.scale * pRoot.scaleY)
                include(sb.end.x + 28f * pRoot.scale * pRoot.scaleX, sb.end.y + 28f * pRoot.scale * pRoot.scaleY)
            }
            if (!rig.singleMeshImagePath.isNullOrBlank()) {
                val mRect = computeSingleMeshRect(rig, pRoot)
                include(mRect.left, mRect.top)
                include(mRect.right, mRect.bottom)
            }
        }
        if (!minX.isFinite() || !minY.isFinite()) return null
        return RectF(minX, minY, maxX, maxY)
    }

    fun computeLayerPivot(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int,
        projectWidth: Float,
        projectHeight: Float
    ): Vec2 {
        val raw = computeRawLayerContentBounds(layer, frame, totalFrames)
            ?: return Vec2(projectWidth / 2f, projectHeight / 2f)
        return if (layer.pivotMode == "BOTTOM_FEET") {
            Vec2(raw.centerX(), raw.bottom)
        } else {
            Vec2(raw.centerX(), raw.centerY())
        }
    }

    fun computeLayerBounds(
        layer: AnimationLayer,
        frame: Int,
        totalFrames: Int,
        projectWidth: Float,
        projectHeight: Float
    ): RectF? {
        val raw = computeRawLayerContentBounds(layer, frame, totalFrames) ?: return null
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, totalFrames)
        val pivot = if (layer.pivotMode == "BOTTOM_FEET") {
            Vec2(raw.centerX(), raw.bottom)
        } else {
            Vec2(raw.centerX(), raw.centerY())
        }
        val sx = if (tf.scaleX.isFinite() && tf.scaleX >= 0.05f) tf.scaleX else 1f
        val sy = if (tf.scaleY.isFinite() && tf.scaleY >= 0.05f) tf.scaleY else 1f
        val tx1 = (raw.left - pivot.x) * sx + pivot.x + tf.x
        val ty1 = (raw.top - pivot.y) * sy + pivot.y + tf.y
        val tx2 = (raw.right - pivot.x) * sx + pivot.x + tf.x
        val ty2 = (raw.bottom - pivot.y) * sy + pivot.y + tf.y
        return RectF(min(tx1, tx2) - 16f, min(ty1, ty2) - 16f, max(tx1, tx2) + 16f, max(ty1, ty2) + 16f)
    }

    /**
     * Computes accurate on-canvas bounding box for a layer, honoring rigid bone attachment
     * world coordinates when the prop/image is attached to a character bone.
     */
    fun computeEffectiveLayerBounds(
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        projectWidth: Float,
        projectHeight: Float,
        audioTracks: List<AudioTrackItem> = emptyList(),
        fps: Int = 24
    ): RectF? {
        val raw = computeRawLayerContentBounds(layer, frame, scene.durationFrames) ?: return null
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val pivot = if (layer.pivotMode == "BOTTOM_FEET") {
            Vec2(raw.centerX(), raw.bottom)
        } else {
            Vec2(raw.centerX(), raw.centerY())
        }
        val propWorld = InterpolationEngine.resolvePropWorldTransform(
            scene = scene,
            layer = layer,
            pivot = pivot,
            frame = frame,
            audioTracks = audioTracks,
            fps = fps
        )
        val sx = if (tf.scaleX.isFinite() && tf.scaleX >= 0.05f) tf.scaleX else 1f
        val sy = if (tf.scaleY.isFinite() && tf.scaleY >= 0.05f) tf.scaleY else 1f
        val cx = if (propWorld.isAttached) propWorld.worldX else (pivot.x + tf.x)
        val cy = if (propWorld.isAttached) propWorld.worldY else (pivot.y + tf.y)
        val tx1 = (raw.left - pivot.x) * sx + cx
        val ty1 = (raw.top - pivot.y) * sy + cy
        val tx2 = (raw.right - pivot.x) * sx + cx
        val ty2 = (raw.bottom - pivot.y) * sy + cy
        return RectF(min(tx1, tx2) - 16f, min(ty1, ty2) - 16f, max(tx1, tx2) + 16f, max(ty1, ty2) + 16f)
    }

    fun isLeftFacingView(viewAngle: CharacterViewAngle, flippedHorizontal: Boolean): Boolean {
        val leftFacing = viewAngle == CharacterViewAngle.SIDE_LEFT ||
            viewAngle == CharacterViewAngle.FRONT_LEFT_34 ||
            viewAngle == CharacterViewAngle.BACK_LEFT_34
        return if (leftFacing) !flippedHorizontal else flippedHorizontal
    }

    fun isLeftFacingView(viewAngleName: String, flippedHorizontal: Boolean): Boolean {
        val parsed = runCatching { CharacterViewAngle.valueOf(viewAngleName) }.getOrDefault(CharacterViewAngle.FRONT)
        return isLeftFacingView(parsed, flippedHorizontal)
    }

    data class BoundPartBoxInfo(
        val center: Vec2,
        val topLeft: Vec2,
        val topRight: Vec2,
        val bottomLeft: Vec2,
        val bottomRight: Vec2,
        val edgeLeft: Vec2,
        val edgeRight: Vec2,
        val edgeTop: Vec2,
        val edgeBottom: Vec2,
        val halfW: Float,
        val halfH: Float,
        val rotRad: Float
    )

    /** Pure-Kotlin [left, top, right, bottom] bounds for single-mesh PNG (JVM unit-test safe). */
    fun computeSingleMeshBounds(rig: SkeletalRig, puppetRoot: EvaluatedPuppetRoot): FloatArray {
        val effectiveScaleX = puppetRoot.scale * puppetRoot.scaleX * rig.baseScaleX.coerceIn(0.1f, 5.0f) * rig.singleMeshScale.coerceIn(0.05f, 8.0f)
        val effectiveScaleY = puppetRoot.scale * puppetRoot.scaleY * rig.baseScaleY.coerceIn(0.1f, 5.0f) * rig.singleMeshScale.coerceIn(0.05f, 8.0f)
        val halfW = (rig.singleMeshWidth * effectiveScaleX) / 2f
        val halfH = (rig.singleMeshHeight * effectiveScaleY) / 2f
        val cx = puppetRoot.rootX + rig.singleMeshOffsetX * puppetRoot.scale * puppetRoot.scaleX
        val cy = puppetRoot.rootY + rig.singleMeshOffsetY * puppetRoot.scale * puppetRoot.scaleY
        return floatArrayOf(
            cx - halfW,
            cy - halfH * 1.15f,
            cx + halfW,
            cy + halfH * 0.85f
        )
    }

    fun computeSingleMeshRect(rig: SkeletalRig, puppetRoot: EvaluatedPuppetRoot): RectF {
        val b = computeSingleMeshBounds(rig, puppetRoot)
        return RectF(b[0], b[1], b[2], b[3])
    }

    fun computeBoundBonePartBox(
        sb: SolvedBone,
        scale: Float,
        effectiveFlipped: Boolean
    ): BoundPartBoxInfo? {
        val partPath = sb.bone.boundImagePath?.takeIf { it.isNotBlank() } ?: return null
        val partBmp = getCachedBitmap(partPath) ?: return null
        val preset = runCatching { PartBehaviorPreset.valueOf(sb.bone.partBehaviorPreset) }
            .getOrDefault(PartBehaviorPreset.RIGID)
        val rawBoneLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y)
        val baseLen = if (preset == PartBehaviorPreset.RIGID) (sb.bone.length * scale).coerceAtLeast(16f) else rawBoneLen
        val stretchRatio = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
            (rawBoneLen / (sb.bone.length * scale).coerceAtLeast(1f)).coerceIn(0.4f, 3.0f)
        } else 1f
        val squashW = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
            (1f / kotlin.math.sqrt(stretchRatio)).coerceIn(0.5f, 1.8f)
        } else 1f
        val drawH = (baseLen * 1.25f * sb.bone.imageScale * sb.bone.limbLengthScale.coerceIn(0.3f, 3.0f) * sb.bone.baseScaleY.coerceIn(0.1f, 5.0f)).coerceAtLeast(24f)
        val aspect = partBmp.width.toFloat() / partBmp.height.coerceAtLeast(1).toFloat()
        val drawW = (drawH / sb.bone.baseScaleY.coerceIn(0.1f, 5.0f) * aspect * sb.bone.limbWidthScale.coerceIn(0.3f, 3.0f) * sb.bone.baseScaleX.coerceIn(0.1f, 5.0f) * squashW).coerceAtLeast(20f)
        val rotDeg = Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat() - 90f + sb.bone.imageRotationOffsetDeg
        val rotRad = Math.toRadians(rotDeg.toDouble()).toFloat()
        val cosR = cos(rotRad.toDouble()).toFloat()
        val sinR = sin(rotRad.toDouble()).toFloat()
        val flipX = if (effectiveFlipped) -1f else 1f
        val left = -drawW / 2f + sb.bone.pivotOffsetX * scale
        val right = drawW / 2f + sb.bone.pivotOffsetX * scale
        val top = -drawH * 0.12f + sb.bone.pivotOffsetY * scale
        val bottom = drawH * 0.88f + sb.bone.pivotOffsetY * scale
        fun toWorld(lx: Float, ly: Float): Vec2 {
            val fx = lx * flipX
            return Vec2(
                sb.start.x + fx * cosR - ly * sinR,
                sb.start.y + fx * sinR + ly * cosR
            )
        }
        val midX = (left + right) * 0.5f
        val midY = (top + bottom) * 0.5f
        return BoundPartBoxInfo(
            center = toWorld(midX, midY),
            topLeft = toWorld(left, top),
            topRight = toWorld(right, top),
            bottomLeft = toWorld(left, bottom),
            bottomRight = toWorld(right, bottom),
            edgeLeft = toWorld(left, midY),
            edgeRight = toWorld(right, midY),
            edgeTop = toWorld(midX, top),
            edgeBottom = toWorld(midX, bottom),
            halfW = drawW * 0.5f,
            halfH = drawH * 0.5f,
            rotRad = rotRad
        )
    }

    data class ResolvedFaceTransform(
        val visible: Boolean,
        val offsetX: Float,
        val offsetY: Float,
        val scaleX: Float,
        val scaleY: Float,
        val rotationDeg: Float,
        val alphaMultiplier: Float,
        val isSideProfile: Boolean,
        val isBack34Peek: Boolean,
        val eyeOffsetX: Float = 0f,
        val eyeOffsetY: Float = 0f,
        val eyeScale: Float = 1f,
        val eyeRotationDeg: Float = 0f,
        val mouthOffsetX: Float = 0f,
        val mouthOffsetY: Float = 0f,
        val mouthScale: Float = 1f,
        val mouthRotationDeg: Float = 0f
    )

    /**
     * Resolves 8-view perspective-aware facial placement + foreshortening merged with any
     * per-angle manual fine-tune lock saved in [rig.perAngleFaceFit].
     */
    fun resolveViewAwareFaceTransform(
        rig: SkeletalRig,
        viewAngle: CharacterViewAngle
    ): ResolvedFaceTransform {
        // Full Back view automatically hides front facial overlays
        if (viewAngle == CharacterViewAngle.BACK) {
            return ResolvedFaceTransform(
                visible = false,
                offsetX = 0f,
                offsetY = 0f,
                scaleX = 1f,
                scaleY = 1f,
                rotationDeg = 0f,
                alphaMultiplier = 0f,
                isSideProfile = false,
                isBack34Peek = false
            )
        }

        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34

        val autoShiftX = when {
            isFront34 -> 12f
            isSide -> 22f
            isBack34 -> 34f
            else -> 0f
        }
        val autoScaleX = when {
            isFront34 -> 0.86f
            isSide -> 0.68f
            isBack34 -> 0.42f
            else -> 1.0f
        }
        val autoScaleY = if (isBack34) 0.92f else 1.0f
        val autoAlpha = if (isBack34) 0.84f else 1.0f

        val baseScale = rig.faceOverlayScale.coerceIn(0.2f, 4.0f)
        val angleOverride = rig.perAngleFaceFit[viewAngle.name]

        return if (angleOverride != null && angleOverride.isManualOverride) {
            ResolvedFaceTransform(
                visible = true,
                offsetX = rig.faceOverlayOffsetX + autoShiftX + angleOverride.offsetX,
                offsetY = rig.faceOverlayOffsetY + angleOverride.offsetY,
                scaleX = (baseScale * autoScaleX * angleOverride.scaleX).coerceIn(0.15f, 5.0f),
                scaleY = (baseScale * autoScaleY * angleOverride.scaleY).coerceIn(0.15f, 5.0f),
                rotationDeg = rig.faceOverlayRotationDeg + angleOverride.rotationDeg,
                alphaMultiplier = autoAlpha,
                isSideProfile = isSide || isBack34,
                isBack34Peek = isBack34,
                eyeOffsetX = angleOverride.eyeOffsetX,
                eyeOffsetY = angleOverride.eyeOffsetY,
                eyeScale = angleOverride.eyeScale.coerceIn(0.25f, 3.5f),
                eyeRotationDeg = angleOverride.eyeRotationDeg,
                mouthOffsetX = angleOverride.mouthOffsetX,
                mouthOffsetY = angleOverride.mouthOffsetY,
                mouthScale = angleOverride.mouthScale.coerceIn(0.25f, 3.5f),
                mouthRotationDeg = angleOverride.mouthRotationDeg
            )
        } else {
            ResolvedFaceTransform(
                visible = true,
                offsetX = rig.faceOverlayOffsetX + autoShiftX,
                offsetY = rig.faceOverlayOffsetY,
                scaleX = (baseScale * autoScaleX).coerceIn(0.15f, 5.0f),
                scaleY = (baseScale * autoScaleY).coerceIn(0.15f, 5.0f),
                rotationDeg = rig.faceOverlayRotationDeg,
                alphaMultiplier = autoAlpha,
                isSideProfile = isSide || isBack34,
                isBack34Peek = isBack34,
                eyeOffsetX = angleOverride?.eyeOffsetX ?: 0f,
                eyeOffsetY = angleOverride?.eyeOffsetY ?: 0f,
                eyeScale = (angleOverride?.eyeScale ?: 1f).coerceIn(0.25f, 3.5f),
                eyeRotationDeg = angleOverride?.eyeRotationDeg ?: 0f,
                mouthOffsetX = angleOverride?.mouthOffsetX ?: 0f,
                mouthOffsetY = angleOverride?.mouthOffsetY ?: 0f,
                mouthScale = (angleOverride?.mouthScale ?: 1f).coerceIn(0.25f, 3.5f),
                mouthRotationDeg = angleOverride?.mouthRotationDeg ?: 0f
            )
        }
    }

    /**
     * Analyzes the Head bone artwork bounds (segmented head PNG, single-mesh upper head zone,
     * or procedural head bone geometry) and returns anatomically accurate face offset & scale.
     */
    fun computeSmartHeadAutoFit(rig: SkeletalRig): Triple<Float, Float, Float> {
        val headBone = rig.bones.firstOrNull {
            it.id == "neck" || it.name.contains("Head", ignoreCase = true)
        }
        // 1. Segmented Head PNG bound directly to Head bone
        val headImgPath = headBone?.boundImagePath
        if (headBone != null && !headImgPath.isNullOrBlank()) {
            val bmp = getCachedBitmap(headImgPath)
            if (bmp != null && bmp.width > 0 && bmp.height > 0) {
                val bounds = findOpaqueAlphaBounds(bmp)
                val targetLen = (headBone.length * headBone.limbLengthScale).coerceAtLeast(36f)
                val aspect = bmp.width.toFloat() / bmp.height.toFloat().coerceAtLeast(1f)
                val drawH = targetLen * headBone.imageScale * headBone.baseScaleY
                val drawW = drawH * aspect * headBone.limbWidthScale * headBone.baseScaleX
                val contentW = drawW * (bounds.right - bounds.left).coerceAtLeast(0.25f)
                val contentH = drawH * (bounds.bottom - bounds.top).coerceAtLeast(0.25f)
                val centerNormX = (bounds.left + bounds.right) * 0.5f - 0.5f
                val centerNormY = (bounds.top + bounds.bottom) * 0.5f - 0.5f
                val offsetX = headBone.pivotOffsetX + centerNormX * drawW
                val offsetY = headBone.pivotOffsetY + centerNormY * drawH + contentH * 0.04f
                val fittedScale = (min(contentW / 86f, contentH / 92f)).coerceIn(0.35f, 3.2f)
                return Triple(offsetX.coerceIn(-300f, 300f), offsetY.coerceIn(-300f, 300f), fittedScale)
            }
        }

        // 2. Single-Mesh full-body custom PNG: scan upper head region (top 32% of opaque body)
        if (!rig.singleMeshImagePath.isNullOrBlank()) {
            val bmp = getCachedBitmap(rig.singleMeshImagePath)
            if (bmp != null && bmp.width > 0 && bmp.height > 0) {
                val bodyBounds = findOpaqueAlphaBounds(bmp)
                val headRegionTop = bodyBounds.top
                val headRegionBottom = (bodyBounds.top + (bodyBounds.bottom - bodyBounds.top) * 0.30f).coerceAtMost(bodyBounds.bottom)
                val headBounds = findOpaqueAlphaBounds(bmp, topFrac = headRegionTop, bottomFrac = headRegionBottom)

                val rootEval = EvaluatedPuppetRoot(
                    rootX = rig.rootX,
                    rootY = rig.rootY,
                    scale = rig.scale,
                    flippedHorizontal = rig.flippedHorizontal,
                    viewAngle = CharacterViewAngle.FRONT.name,
                    eyePack = rig.eyePack,
                    mouthPhoneme = rig.mouthPhoneme
                )
                val meshRect = computeSingleMeshRect(rig, rootEval)
                val headWorldLeft = meshRect.left + headBounds.left * meshRect.width()
                val headWorldRight = meshRect.left + headBounds.right * meshRect.width()
                val headWorldTop = meshRect.top + headBounds.top * meshRect.height()
                val headWorldBottom = meshRect.top + headBounds.bottom * meshRect.height()
                val headWorldCx = (headWorldLeft + headWorldRight) * 0.5f
                val headWorldCy = headWorldTop + (headWorldBottom - headWorldTop) * 0.54f
                val headWorldW = (headWorldRight - headWorldLeft).coerceAtLeast(36f)
                val headWorldH = (headWorldBottom - headWorldTop).coerceAtLeast(36f)

                val solved = RigSolver.solveForwardKinematics(
                    rig = rig,
                    angleOverrides = rig.bones.associate { it.id to it.localAngleDeg },
                    rootX = rig.rootX,
                    rootY = rig.rootY,
                    scale = rig.scale,
                    flippedHorizontal = false,
                    scaleX = rig.scaleX,
                    scaleY = rig.scaleY
                )
                val solvedHead = solved.firstOrNull { it.bone.id == "neck" || it.bone.name.contains("Head", ignoreCase = true) }
                val baseX = if (solvedHead != null) (solvedHead.start.x + solvedHead.end.x * 2f) / 3f else rig.rootX
                val baseY = if (solvedHead != null) (solvedHead.start.y + solvedHead.end.y * 2f) / 3f else rig.rootY - 90f * rig.scale
                val invScale = 1f / rig.scale.coerceAtLeast(0.1f)
                val offsetX = ((headWorldCx - baseX) * invScale).coerceIn(-300f, 300f)
                val offsetY = ((headWorldCy - baseY) * invScale).coerceIn(-300f, 300f)
                val fittedScale = (min(headWorldW / 90f, headWorldH / 92f) * invScale).coerceIn(0.35f, 3.2f)
                return Triple(offsetX, offsetY, fittedScale)
            }
        }

        // 3. Procedural / Skeleton-only fallback: snap cleanly to Head bone center
        val boneScale = if (headBone != null) {
            ((headBone.length * headBone.limbLengthScale) / 68f).coerceIn(0.55f, 2.2f)
        } else 1.0f
        return Triple(0f, 0f, boneScale)
    }

    private fun findOpaqueAlphaBounds(
        bmp: Bitmap,
        topFrac: Float = 0f,
        bottomFrac: Float = 1f
    ): RectF {
        val w = bmp.width
        val h = bmp.height
        val yStart = (h * topFrac).toInt().coerceIn(0, (h - 1).coerceAtLeast(0))
        val yEnd = (h * bottomFrac).toInt().coerceIn(yStart + 1, h)
        val stepX = (w / 48).coerceAtLeast(1)
        val stepY = ((yEnd - yStart) / 48).coerceAtLeast(1)
        var minX = w
        var minY = yEnd
        var maxX = 0
        var maxY = yStart
        var found = false
        var y = yStart
        while (y < yEnd) {
            var x = 0
            while (x < w) {
                val alpha = (bmp.getPixel(x, y) ushr 24) and 0xFF
                if (alpha > 20) {
                    found = true
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
                x += stepX
            }
            y += stepY
        }
        return if (!found || maxX <= minX || maxY <= minY) {
            RectF(0.2f, topFrac, 0.8f, bottomFrac)
        } else {
            RectF(
                minX.toFloat() / w.toFloat(),
                minY.toFloat() / h.toFloat(),
                (maxX + stepX).coerceAtMost(w).toFloat() / w.toFloat(),
                (maxY + stepY).coerceAtMost(h).toFloat() / h.toFloat()
            )
        }
    }

    fun computeFaceOverlayWorldCenter(
        rig: SkeletalRig,
        puppetRoot: EvaluatedPuppetRoot,
        angles: Map<String, Float>
    ): Vec2 {
        val viewAngle = runCatching { CharacterViewAngle.valueOf(puppetRoot.viewAngle) }
            .getOrDefault(CharacterViewAngle.FRONT)
        val effFlip = isLeftFacingView(viewAngle, puppetRoot.flippedHorizontal)
        val solved = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = angles,
            rootX = puppetRoot.rootX,
            rootY = puppetRoot.rootY,
            scale = puppetRoot.scale,
            flippedHorizontal = effFlip,
            scaleX = puppetRoot.scaleX,
            scaleY = puppetRoot.scaleY,
            viewAngle = viewAngle
        )
        val headBone = solved.firstOrNull { it.bone.id == "neck" || it.bone.name.contains("Head", ignoreCase = true) }
        val baseX = if (headBone != null) (headBone.start.x + headBone.end.x * 2f) / 3f else puppetRoot.rootX
        val baseY = if (headBone != null) (headBone.start.y + headBone.end.y * 2f) / 3f else puppetRoot.rootY - 90f * puppetRoot.scale * puppetRoot.scaleY
        val flipSign = if (effFlip) -1f else 1f
        val resolved = resolveViewAwareFaceTransform(rig, viewAngle)
        return Vec2(
            baseX + resolved.offsetX * puppetRoot.scale * puppetRoot.scaleX * flipSign,
            baseY + resolved.offsetY * puppetRoot.scale * puppetRoot.scaleY
        )
    }

    private fun drawSelectionTouchHandles(
        canvas: Canvas,
        rect: RectF,
        rotationDeg: Float = 0f,
        pivotMode: String = "CENTER"
    ) {
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF2DD4BF.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
        }
        canvas.drawRect(rect, boxPaint)

        val whiteStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3.2f }

        // Pivot indicator crosshair (True Center vs Bottom-Feet)
        val pivX = rect.centerX()
        val pivY = if (pivotMode == "BOTTOM_FEET") rect.bottom else rect.centerY()
        val pivPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFBBF24.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 2.6f
        }
        canvas.drawCircle(pivX, pivY, 7f, pivPaint)
        canvas.drawLine(pivX - 11f, pivY, pivX + 11f, pivY, pivPaint)
        canvas.drawLine(pivX, pivY - 11f, pivX, pivY + 11f, pivPaint)

        // Prominent Top 360-Degree Rotation Handle with Glow Halo
        val rotX = rect.centerX()
        val rotY = rect.top - 52f
        val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFF6B35.toInt()
            strokeWidth = 3.5f
        }
        canvas.drawLine(rect.centerX(), rect.top, rotX, rotY, stemPaint)
        val rotGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FF6B35; style = Paint.Style.FILL }
        val rotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
        canvas.drawCircle(rotX, rotY, 26f, rotGlow)
        canvas.drawCircle(rotX, rotY, 17f, rotFill)
        canvas.drawCircle(rotX, rotY, 17f, whiteStroke)
        val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 2.6f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawArc(RectF(rotX - 8f, rotY - 8f, rotX + 8f, rotY + 8f), -45f, 250f, false, arcPaint)
        if (kotlin.math.abs(rotationDeg) > 0.5f) {
            val degPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFFE066.toInt()
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.LEFT
            }
            canvas.drawText("${rotationDeg.toInt()}°", rotX + 24f, rotY + 6f, degPaint)
        }

        // 4 Prominent Corner Uniform Resize Handles with Touch Halos
        val cornerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x442DD4BF; style = Paint.Style.FILL }
        val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt(); style = Paint.Style.FILL }
        listOf(
            Vec2(rect.left, rect.top),
            Vec2(rect.right, rect.top),
            Vec2(rect.left, rect.bottom),
            Vec2(rect.right, rect.bottom)
        ).forEach { corner ->
            canvas.drawCircle(corner.x, corner.y, 22f, cornerGlow)
            canvas.drawCircle(corner.x, corner.y, 13.5f, handleFill)
            canvas.drawCircle(corner.x, corner.y, 13.5f, whiteStroke)
        }

        // Module 2: 4 Edge Mid-Point Squash & Stretch Handles (Left/Right = Scale X, Top/Bottom = Scale Y)
        val edgeXFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA78BFA.toInt(); style = Paint.Style.FILL }
        val edgeYFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFBBF24.toInt(); style = Paint.Style.FILL }
        // Left & Right (Width Squash/Stretch)
        listOf(Vec2(rect.left, rect.centerY()), Vec2(rect.right, rect.centerY())).forEach { p ->
            val pill = RectF(p.x - 7f, p.y - 16f, p.x + 7f, p.y + 16f)
            canvas.drawRoundRect(pill, 7f, 7f, edgeXFill)
            canvas.drawRoundRect(pill, 7f, 7f, whiteStroke)
        }
        // Top & Bottom (Height Squash/Stretch)
        listOf(Vec2(rect.centerX(), rect.top), Vec2(rect.centerX(), rect.bottom)).forEach { p ->
            val pill = RectF(p.x - 16f, p.y - 7f, p.x + 16f, p.y + 7f)
            canvas.drawRoundRect(pill, 7f, 7f, edgeYFill)
            canvas.drawRoundRect(pill, 7f, 7f, whiteStroke)
        }
    }

    private fun applyCameraTransform(
        canvas: Canvas,
        camera: EvaluatedCamera,
        w: Float,
        h: Float,
        parallax: Float
    ) {
        canvas.translate(w / 2f, h / 2f)
        canvas.rotate(camera.rotationDeg)
        val effectiveZoom = 1f + (camera.zoom - 1f) * parallax
        canvas.scale(effectiveZoom, effectiveZoom)
        canvas.translate(-w / 2f - camera.panX * parallax, -h / 2f - camera.panY * parallax)
    }

    private fun drawLayerAtFrame(
        canvas: Canvas,
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        camera: EvaluatedCamera,
        projectWidth: Float,
        projectHeight: Float,
        overrideAlpha: Float?,
        tintColorArgb: Long?,
        showRigOverlay: Boolean,
        isSelectedLayer: Boolean,
        selectedBoneId: String?,
        maskLayerBelow: AnimationLayer? = null,
        allowEffects: Boolean = true,
        moveCharMode: Boolean = false,
        bonePickHighlightMode: Boolean = false
    ) {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val combinedAlpha = ((overrideAlpha ?: (layer.opacity * tf.opacity))).coerceIn(0f, 1f)
        if (combinedAlpha <= 0.01f) return

        // Module 9: Directional Motion Blur & Speed Afterimages (trailing faded ghosts from previous frames)
        if (allowEffects && overrideAlpha == null && layer.motionBlurStrength > 0.03f && frame > 0) {
            val strength = layer.motionBlurStrength.coerceIn(0f, 1f)
            val steps = if (strength > 0.55f) 3 else 2
            for (k in steps downTo 1) {
                val prevF = (frame - k).coerceAtLeast(0)
                val ghostAlpha = combinedAlpha * strength * (0.34f / k)
                if (ghostAlpha > 0.02f) {
                    drawLayerCore(
                        canvas = canvas,
                        scene = scene,
                        layer = layer,
                        frame = prevF,
                        fps = fps,
                        audioTracks = audioTracks,
                        camera = camera,
                        projectWidth = projectWidth,
                        projectHeight = projectHeight,
                        combinedAlpha = ghostAlpha,
                        tintColorArgb = tintColorArgb,
                        showRigOverlay = false,
                        isSelectedLayer = false,
                        selectedBoneId = null,
                        drawContactShadow = false,
                        rimLightColorArgb = null
                    )
                }
            }
        }

        // Module 9: Layer Masking / Clip to Layer Below (PorterDuff DST_IN offscreen composite)
        if (allowEffects && maskLayerBelow != null && overrideAlpha == null) {
            val saveCount = canvas.saveLayer(0f, 0f, projectWidth, projectHeight, null)
            drawLayerCore(
                canvas = canvas,
                scene = scene,
                layer = layer,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                camera = camera,
                projectWidth = projectWidth,
                projectHeight = projectHeight,
                combinedAlpha = combinedAlpha,
                tintColorArgb = tintColorArgb,
                showRigOverlay = false,
                isSelectedLayer = isSelectedLayer,
                selectedBoneId = selectedBoneId,
                drawContactShadow = layer.groundShadowEnabled,
                rimLightColorArgb = layer.rimLightColorArgb
            )
            val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            val maskSave = canvas.saveLayer(0f, 0f, projectWidth, projectHeight, maskPaint)
            drawLayerCore(
                canvas = canvas,
                scene = scene,
                layer = maskLayerBelow,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                camera = camera,
                projectWidth = projectWidth,
                projectHeight = projectHeight,
                combinedAlpha = 1f,
                tintColorArgb = null,
                showRigOverlay = false,
                isSelectedLayer = false,
                selectedBoneId = null,
                drawContactShadow = false,
                rimLightColorArgb = null
            )
            canvas.restoreToCount(maskSave)
            canvas.restoreToCount(saveCount)
            // Keep rig overlay unclipped when editing
            if (showRigOverlay && layer.type == LayerType.RIG.name && layer.rig != null) {
                drawLayerCore(
                    canvas = canvas,
                    scene = scene,
                    layer = layer,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    camera = camera,
                    projectWidth = projectWidth,
                    projectHeight = projectHeight,
                    combinedAlpha = 0f,
                    tintColorArgb = null,
                    showRigOverlay = true,
                    isSelectedLayer = isSelectedLayer,
                    selectedBoneId = selectedBoneId,
                    drawContactShadow = false,
                    rimLightColorArgb = null
                )
            }
            return
        }

        drawLayerCore(
            canvas = canvas,
            scene = scene,
            layer = layer,
            frame = frame,
            fps = fps,
            audioTracks = audioTracks,
            camera = camera,
            projectWidth = projectWidth,
            projectHeight = projectHeight,
            combinedAlpha = combinedAlpha,
            tintColorArgb = tintColorArgb,
            showRigOverlay = showRigOverlay,
            isSelectedLayer = isSelectedLayer,
            selectedBoneId = selectedBoneId,
            drawContactShadow = allowEffects && overrideAlpha == null && layer.groundShadowEnabled,
            rimLightColorArgb = if (allowEffects && overrideAlpha == null) layer.rimLightColorArgb else null,
            moveCharMode = moveCharMode,
            bonePickHighlightMode = bonePickHighlightMode
        )
    }

    private fun drawLayerCore(
        canvas: Canvas,
        scene: AnimationScene,
        layer: AnimationLayer,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        camera: EvaluatedCamera,
        projectWidth: Float,
        projectHeight: Float,
        combinedAlpha: Float,
        tintColorArgb: Long?,
        showRigOverlay: Boolean,
        isSelectedLayer: Boolean,
        selectedBoneId: String?,
        drawContactShadow: Boolean,
        rimLightColorArgb: Long?,
        moveCharMode: Boolean = false,
        bonePickHighlightMode: Boolean = false
    ) {
        val tf = InterpolationEngine.evaluateLayerTransform(layer, frame, scene.durationFrames)
        val rawBounds = computeRawLayerContentBounds(layer, frame, scene.durationFrames)
        val pivot = when {
            rawBounds == null -> Vec2(projectWidth / 2f, projectHeight / 2f)
            layer.pivotMode == "BOTTOM_FEET" -> Vec2(rawBounds.centerX(), rawBounds.bottom)
            else -> Vec2(rawBounds.centerX(), rawBounds.centerY())
        }

        canvas.save()
        applyCameraTransform(canvas, camera, projectWidth, projectHeight, layer.parallaxDepth)

        // Seamless horizontal background scrolling for custom Background layers
        val bgAutoShiftX = InterpolationEngine.computeBgScrollShiftX(layer, scene, frame, projectWidth)

        // Variable Prop Grab Target — rigid child-bone attachment to Hand L/R with independent rotation & zero-jump release
        val propWorld = InterpolationEngine.resolvePropWorldTransform(
            scene = scene,
            layer = layer,
            pivot = pivot,
            frame = frame,
            audioTracks = audioTracks,
            fps = fps
        )

        val safeScaleX = if (tf.scaleX.isFinite() && tf.scaleX >= 0.05f) tf.scaleX else 1f
        val safeScaleY = if (tf.scaleY.isFinite() && tf.scaleY >= 0.05f) tf.scaleY else 1f
        val safePivotX = if (pivot.x.isFinite()) pivot.x else projectWidth / 2f
        val safePivotY = if (pivot.y.isFinite()) pivot.y else projectHeight / 2f

        if (propWorld.isAttached) {
            val wx = if (propWorld.worldX.isFinite()) propWorld.worldX else (safePivotX + tf.x)
            val wy = if (propWorld.worldY.isFinite()) propWorld.worldY else (safePivotY + tf.y)
            val wRot = if (propWorld.worldAngleDeg.isFinite()) propWorld.worldAngleDeg else tf.rotationDeg
            canvas.translate(wx, wy)
            canvas.rotate(wRot)
            canvas.scale(safeScaleX, safeScaleY)
            canvas.translate(-safePivotX, -safePivotY)
        } else {
            // Detached / Free World Transform with strict finite & non-zero scale guards (NEVER vanishes on detach!)
            val tx = (safePivotX + tf.x + bgAutoShiftX).let { if (it.isFinite()) it else safePivotX }
            val ty = (safePivotY + tf.y).let { if (it.isFinite()) it else safePivotY }
            val rot = if (tf.rotationDeg.isFinite()) tf.rotationDeg else 0f
            canvas.translate(tx, ty)
            canvas.rotate(rot)
            canvas.scale(safeScaleX, safeScaleY)
            canvas.translate(-safePivotX, -safePivotY)
        }

        // Module 9: Automatic Ground Contact Shadow underneath layer bounds/feet
        if (drawContactShadow && rawBounds != null && combinedAlpha > 0.05f) {
            val shadowW = (rawBounds.width() * 0.42f).coerceIn(32f, 220f)
            val shadowH = (shadowW * 0.24f).coerceIn(10f, 36f)
            val sx = rawBounds.centerX()
            val sy = rawBounds.bottom + 4f
            val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    sx, sy, shadowW,
                    Color.argb((combinedAlpha * 115f).toInt().coerceIn(0, 255), 2, 6, 23),
                    Color.TRANSPARENT,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawOval(RectF(sx - shadowW, sy - shadowH, sx + shadowW, sy + shadowH), shadowPaint)
        }

        // Video Background / Reference Layer
        if (layer.type == LayerType.VIDEO.name && !layer.videoFilePath.isNullOrBlank() && combinedAlpha > 0.01f) {
            val timeUs = ((frame.toDouble() / fps.coerceAtLeast(1)) * 1_000_000.0).toLong()
            val vBmp = getCachedVideoFrame(layer.videoFilePath, timeUs)
            if (vBmp != null) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = (combinedAlpha * 255).toInt().coerceIn(0, 255)
                }
                canvas.drawBitmap(vBmp, null, RectF(0f, 0f, projectWidth, projectHeight), p)
            }
        }

        // Module 9: Same-Track Character Form Morph evaluation
        val activeMorph = InterpolationEngine.evaluateFormMorph(layer, frame)
        val isBgLayer = layer.type == LayerType.BACKGROUND.name

        // Helper to draw layer visual payload (reused for optional Rim Light edge glow pass!)
        fun drawPayload(drawAlpha: Float, drawTint: Long?, overlayBones: Boolean) {
            val content = InterpolationEngine.resolveFrameContent(layer, frame, holdPrevious = true)
            if (content != null && drawAlpha > 0.01f) {
                val filteredContent = if (layer.type == LayerType.RIG.name && layer.rig != null && content.images.isNotEmpty()) {
                    val rigPaths = buildSet {
                        layer.rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let(::add)
                        layer.rig.bones.mapNotNull { it.boundImagePath?.takeIf { p -> p.isNotBlank() } }.forEach(::add)
                    }
                    if (rigPaths.isNotEmpty()) {
                        content.copy(images = content.images.filterNot { it.filePath in rigPaths })
                    } else content
                } else content
                drawFrameContent(canvas, filteredContent, drawAlpha, drawTint, frame, isBackground = isBgLayer)
            }

            if (layer.type == LayerType.CHARACTER.name && drawAlpha > 0.01f) {
                val swappedId = InterpolationEngine.evaluateCharacterSwapId(layer, frame)
                val swappedSpec = swappedId?.let { layer.characterSwapRigs[it]?.characterAppearance }
                val charSpec = activeMorph?.form?.characterSpec ?: swappedSpec ?: content?.characterOverride ?: layer.character
                if (charSpec != null) {
                    drawCharacter(canvas, charSpec, drawAlpha, drawTint, frame, fps, audioTracks)
                }
            }

            if (layer.type == LayerType.RIG.name && layer.rig != null) {
                val swappedRig = InterpolationEngine.resolveEffectiveRigAtFrame(layer, frame) ?: layer.rig
                val effectiveRig = if (activeMorph != null) {
                    swappedRig.copy(
                        characterAppearance = activeMorph.form.characterSpec ?: swappedRig.characterAppearance,
                        singleMeshImagePath = activeMorph.form.singleMeshImagePath ?: swappedRig.singleMeshImagePath
                    )
                } else swappedRig
                val puppetRoot = InterpolationEngine.evaluatePuppetRootWithPath(layer, effectiveRig, frame, scene.durationFrames, audioTracks = audioTracks, fps = fps)
                val angles = InterpolationEngine.evaluateRigAnglesWithPath(layer, effectiveRig, frame, scene.durationFrames, audioTracks = audioTracks, fps = fps)
                drawSkeletalRig(
                    canvas = canvas,
                    rig = effectiveRig,
                    puppetRoot = puppetRoot,
                    angles = angles,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    alpha = drawAlpha,
                    tintColorArgb = drawTint,
                    showOverlay = overlayBones,
                    isSelectedPuppet = isSelectedLayer,
                    selectedBoneId = selectedBoneId,
                    moveCharMode = moveCharMode,
                    bonePickHighlightMode = bonePickHighlightMode
                )
            }
        }

        // Module 9: Subtle Back Rim Light Glow pass behind character/object
        if (rimLightColorArgb != null && combinedAlpha > 0.05f) {
            canvas.save()
            canvas.translate(-6f, -5f)
            drawPayload(combinedAlpha * 0.42f, rimLightColorArgb, false)
            canvas.restore()
            canvas.save()
            canvas.translate(6f, -3f)
            drawPayload(combinedAlpha * 0.28f, rimLightColorArgb, false)
            canvas.restore()
        }

        drawPayload(combinedAlpha, tintColorArgb, showRigOverlay)

        // Module 9: Form Morph Transition FX Burst (FLASH / SMOKE puff ring on same track!)
        if (activeMorph != null && activeMorph.transitionProgress in 0f..1f && tintColorArgb == null) {
            val t = activeMorph.transitionProgress
            val cx = rawBounds?.centerX() ?: pivot.x
            val cy = rawBounds?.centerY() ?: pivot.y
            val radius = (rawBounds?.let { max(it.width(), it.height()) * 0.65f } ?: 140f) * (0.4f + t * 0.9f)
            val fade = sin(t * PI).toFloat().coerceIn(0f, 1f)
            when (activeMorph.form.transitionFx) {
                "FLASH" -> {
                    val flashP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = RadialGradient(
                            cx, cy, radius.coerceAtLeast(24f),
                            Color.argb((fade * 230f).toInt(), 255, 250, 220),
                            Color.argb(0, 255, 220, 120),
                            Shader.TileMode.CLAMP
                        )
                    }
                    canvas.drawCircle(cx, cy, radius, flashP)
                }
                "SMOKE" -> {
                    val smokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb((fade * 195f).toInt(), 226, 232, 240)
                    }
                    for (i in 0 until 8) {
                        val ang = (i / 8.0) * 2.0 * PI + t * 0.8
                        val px = cx + cos(ang).toFloat() * radius * 0.55f
                        val py = cy + sin(ang).toFloat() * radius * 0.55f
                        canvas.drawCircle(px, py, (26f + (i % 3) * 14f) * (0.6f + t * 0.6f), smokeP)
                    }
                }
            }
        }

        canvas.restore()
    }

    private fun drawFrameContent(
        canvas: Canvas,
        content: FrameContent,
        alpha: Float,
        tintColorArgb: Long?,
        frame: Int = 0,
        isBackground: Boolean = false
    ) {
        content.images.forEach { img -> drawImportedImage(canvas, img, alpha, tintColorArgb, isBackground) }
        content.shapes.forEach { shape -> drawVectorShape(canvas, shape, alpha, tintColorArgb) }
        content.strokes.forEach { stroke -> drawStroke(canvas, stroke, alpha, tintColorArgb) }
        content.texts.forEach { textItem -> drawTextItem(canvas, textItem, frame, alpha, tintColorArgb, false) }
    }

    private fun drawImportedImage(
        canvas: Canvas,
        item: ImportedImageItem,
        layerAlpha: Float,
        tintColorArgb: Long?,
        isBackground: Boolean = false
    ) {
        val bmp = getCachedBitmap(item.filePath, isBackground = isBackground) ?: return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (layerAlpha * item.opacity * 255).toInt().coerceIn(0, 255)
            if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
        }
        val safeSx = if (item.scaleX.isFinite() && item.scaleX >= 0.05f) item.scaleX.coerceIn(0.05f, 6f) else 1f
        val safeSy = if (item.scaleY.isFinite() && item.scaleY >= 0.05f) item.scaleY.coerceIn(0.05f, 6f) else 1f
        canvas.save()
        canvas.translate(item.x, item.y)
        canvas.rotate(item.rotationDeg)
        canvas.scale(safeSx, safeSy)
        val dst = RectF(-item.width / 2f, -item.height / 2f, item.width / 2f, item.height / 2f)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
    }

    private fun buildTintColorFilter(tintArgb: Long): ColorMatrixColorFilter {
        val r = Color.red(tintArgb.toInt()) / 255f
        val g = Color.green(tintArgb.toInt()) / 255f
        val b = Color.blue(tintArgb.toInt()) / 255f
        return ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    r, 0f, 0f, 0f, 30f,
                    0f, g, 0f, 0f, 30f,
                    0f, 0f, b, 0f, 30f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    private fun drawStroke(canvas: Canvas, stroke: DrawStroke, layerAlpha: Float, tintColorArgb: Long?) {
        if (stroke.points.isEmpty()) return
        val effectiveAlpha = (layerAlpha * stroke.opacity * 255).toInt().coerceIn(0, 255)
        val baseColor = (tintColorArgb ?: stroke.colorArgb).toInt()

        if (stroke.tool == EditorTool.AIRBRUSH.name) {
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = baseColor
                style = Paint.Style.FILL
                alpha = (effectiveAlpha * 0.25f).toInt().coerceIn(8, 255)
            }
            val spread = stroke.strokeWidth * 1.4f
            val rng = Random(stroke.id.hashCode())
            stroke.points.forEach { pt ->
                repeat(10) {
                    val a = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * spread
                    canvas.drawCircle(
                        pt.x + cos(a) * r,
                        pt.y + sin(a) * r,
                        (stroke.strokeWidth * 0.14f).coerceAtLeast(1.5f),
                        dotPaint
                    )
                }
            }
            return
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = baseColor
            style = if (stroke.isClosedBezier) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
            strokeWidth = if (stroke.tool == EditorTool.PENCIL.name) {
                (stroke.strokeWidth * 0.55f).coerceAtLeast(1.5f)
            } else {
                stroke.strokeWidth
            }
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = effectiveAlpha
        }

        if (stroke.gradientEndArgb != null && tintColorArgb == null && stroke.points.size >= 2) {
            val first = stroke.points.first()
            val last = stroke.points.last()
            paint.shader = LinearGradient(
                first.x, first.y, last.x, last.y,
                stroke.colorArgb.toInt(),
                stroke.gradientEndArgb.toInt(),
                Shader.TileMode.CLAMP
            )
        }

        if (stroke.points.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(stroke.points[0].x, stroke.points[0].y, paint.strokeWidth / 2f, paint)
            return
        }

        val path = Path().apply {
            moveTo(stroke.points[0].x, stroke.points[0].y)
            for (i in 1 until stroke.points.size) {
                val prev = stroke.points[i - 1]
                val curr = stroke.points[i]
                val midX = (prev.x + curr.x) / 2f
                val midY = (prev.y + curr.y) / 2f
                quadTo(prev.x, prev.y, midX, midY)
            }
            val last = stroke.points.last()
            lineTo(last.x, last.y)
            if (stroke.isClosedBezier) close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawVectorShape(canvas: Canvas, shape: VectorShape, layerAlpha: Float, tintColorArgb: Long?) {
        val alphaInt = (layerAlpha * shape.opacity * 255).toInt().coerceIn(0, 255)
        val kind = runCatching { ShapeKind.valueOf(shape.kind) }.getOrDefault(ShapeKind.RECTANGLE)
        val rect = RectF(
            min(shape.startX, shape.endX),
            min(shape.startY, shape.endY),
            max(shape.startX, shape.endX),
            max(shape.startY, shape.endY)
        )

        canvas.save()
        if (shape.rotationDeg != 0f) canvas.rotate(shape.rotationDeg, rect.centerX(), rect.centerY())

        val fillPaint = shape.fillColorArgb?.let { fillHex ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = (tintColorArgb ?: fillHex).toInt()
                alpha = alphaInt
                if (shape.gradientEndArgb != null && tintColorArgb == null) {
                    shader = LinearGradient(
                        rect.left, rect.top, rect.right, rect.bottom,
                        fillHex.toInt(), shape.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                    )
                }
            }
        }

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: shape.strokeColorArgb).toInt()
            strokeWidth = shape.strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (kind) {
            ShapeKind.LINE -> canvas.drawLine(shape.startX, shape.startY, shape.endX, shape.endY, strokePaint)
            ShapeKind.RECTANGLE -> {
                fillPaint?.let { canvas.drawRoundRect(rect, 10f, 10f, it) }
                if (shape.strokeWidth > 0f) canvas.drawRoundRect(rect, 10f, 10f, strokePaint)
            }
            ShapeKind.FILL_BACKDROP -> fillPaint?.let { canvas.drawRect(rect, it) }
            ShapeKind.CIRCLE -> {
                fillPaint?.let { canvas.drawOval(rect, it) }
                if (shape.strokeWidth > 0f) canvas.drawOval(rect, strokePaint)
            }
            ShapeKind.POLYGON -> {
                val sides = shape.polygonSides.coerceIn(3, 12)
                val cx = rect.centerX(); val cy = rect.centerY()
                val rx = rect.width() / 2f; val ry = rect.height() / 2f
                val path = Path()
                for (i in 0 until sides) {
                    val angle = (i * 2.0 * PI / sides) - PI / 2.0
                    val px = cx + (cos(angle) * rx).toFloat()
                    val py = cy + (sin(angle) * ry).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                fillPaint?.let { canvas.drawPath(path, it) }
                if (shape.strokeWidth > 0f) canvas.drawPath(path, strokePaint)
            }
        }
        canvas.restore()
    }

    private fun resolveTextTypeface(fontStyleName: String, fallbackBold: Boolean): Typeface {
        return when (runCatching { TextFontStyle.valueOf(fontStyleName) }.getOrNull()) {
            TextFontStyle.BOLD_CARTOON -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            TextFontStyle.SERIF_HORROR -> Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            TextFontStyle.MONO_TECH -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            TextFontStyle.CLASSIC_CLEAN -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            TextFontStyle.COMIC_ITALIC -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            null -> if (fallbackBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    fun computeTextBounds(item: CanvasTextItem): RectF {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = item.fontSize.coerceIn(16f, 220f)
            typeface = resolveTextTypeface(item.fontStyle, item.isBold)
        }
        val lines = item.text.ifBlank { "Text" }.split("\n")
        val maxW = lines.maxOfOrNull { paint.measureText(it) }?.coerceAtLeast(80f) ?: 120f
        val lineH = item.fontSize * 1.18f
        val totalH = (lines.size * lineH).coerceAtLeast(item.fontSize)
        val padX = 34f
        val padY = 24f
        return RectF(
            item.x - maxW / 2f - padX,
            item.y - totalH / 2f - padY,
            item.x + maxW / 2f + padX,
            item.y + totalH / 2f + padY
        )
    }

    private fun drawTextItem(
        canvas: Canvas,
        item: CanvasTextItem,
        frame: Int,
        layerAlpha: Float,
        tintColorArgb: Long?,
        isSelected: Boolean
    ) {
        if (item.text.isBlank()) return
        if (frame < item.startFrame || frame > item.endFrame) return

        val inAnim = runCatching { TextInAnimation.valueOf(item.inAnimation) }.getOrDefault(TextInAnimation.NONE)
        val loopAnim = runCatching { TextLoopAnimation.valueOf(item.loopAnimation) }.getOrDefault(TextLoopAnimation.NONE)
        val outAnim = runCatching { TextOutAnimation.valueOf(item.outAnimation) }.getOrDefault(TextOutAnimation.NONE)
        val boxStyle = runCatching { TextBoxStyle.valueOf(item.boxStyle) }.getOrDefault(TextBoxStyle.NONE)

        val localFrame = (frame - item.startFrame).coerceAtLeast(0)
        val inDur = item.inDurationFrames.coerceAtLeast(1)
        val inT = (localFrame.toFloat() / inDur.toFloat()).coerceIn(0f, 1f)

        val remainingFrames = if (item.endFrame < 9000) (item.endFrame - frame).coerceAtLeast(0) else 9999
        val outDur = item.outDurationFrames.coerceAtLeast(1)
        val outT = if (outAnim != TextOutAnimation.NONE && remainingFrames < outDur) {
            1f - (remainingFrames.toFloat() / outDur.toFloat()).coerceIn(0f, 1f)
        } else 0f

        var animDx = 0f
        var animDy = 0f
        var animScaleX = 1f
        var animScaleY = 1f
        var animRot = 0f
        var animAlpha = (layerAlpha * item.opacity).coerceIn(0f, 1f)
        var visibleText = item.text

        // 1. Entrance Animation
        when (inAnim) {
            TextInAnimation.POP_BOUNCE -> {
                if (inT < 1f) {
                    val sc = when {
                        inT < 0.55f -> (inT / 0.55f) * 1.26f
                        inT < 0.80f -> 1.26f - ((inT - 0.55f) / 0.25f) * 0.34f
                        else -> 0.92f + ((inT - 0.80f) / 0.20f) * 0.08f
                    }
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (inT * 2.5f).coerceIn(0f, 1f)
                }
            }
            TextInAnimation.TYPEWRITER -> {
                if (inT < 1f) {
                    val count = (item.text.length * inT).toInt().coerceIn(1, item.text.length)
                    val caret = if ((localFrame / 3) % 2 == 0) "|" else ""
                    visibleText = item.text.take(count) + caret
                }
            }
            TextInAnimation.SLIDE_UP -> {
                val ease = 1f - (1f - inT) * (1f - inT) * (1f - inT)
                animDy += (1f - ease) * 110f
                animAlpha *= ease
            }
            TextInAnimation.SLIDE_LEFT -> {
                val ease = 1f - (1f - inT) * (1f - inT) * (1f - inT)
                animDx += (1f - ease) * 190f
                animAlpha *= ease
            }
            TextInAnimation.ZOOM_SLAM -> {
                if (inT < 1f) {
                    val sc = 2.6f - 1.6f * (inT * inT)
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (inT * 2f).coerceIn(0f, 1f)
                } else if (localFrame - inDur in 0..4) {
                    val amp = (5 - (localFrame - inDur)) * 4f
                    animDx += if (localFrame % 2 == 0) amp else -amp
                    animDy += if (localFrame % 3 == 0) -amp * 0.6f else amp * 0.6f
                }
            }
            TextInAnimation.SPIN_POP -> {
                val ease = 1f - (1f - inT) * (1f - inT)
                animScaleX *= ease.coerceAtLeast(0.05f)
                animScaleY *= ease.coerceAtLeast(0.05f)
                animRot += (1f - ease) * -360f
                animAlpha *= ease
            }
            TextInAnimation.FADE_IN -> {
                animAlpha *= inT
            }
            TextInAnimation.DROP_LETTERS, TextInAnimation.NONE -> Unit
        }

        // 2. Continuous Loop Animation
        val spd = item.loopSpeed.coerceIn(0.25f, 3f)
        val phase = localFrame * 0.28f * spd
        when (loopAnim) {
            TextLoopAnimation.BOUNCE -> {
                val b = kotlin.math.abs(sin(phase.toDouble())).toFloat()
                animDy -= b * 24f
                animScaleX *= (1.06f - b * 0.10f)
                animScaleY *= (0.94f + b * 0.12f)
            }
            TextLoopAnimation.FLOAT -> {
                animDy += sin(phase.toDouble() * 0.6).toFloat() * 14f
                animRot += cos(phase.toDouble() * 0.45).toFloat() * 3.5f
            }
            TextLoopAnimation.SHAKE_HORROR -> {
                val rng = Random(frame * 97 + item.id.hashCode())
                animDx += (rng.nextFloat() - 0.5f) * 14f * spd
                animDy += (rng.nextFloat() - 0.5f) * 12f * spd
                animRot += (rng.nextFloat() - 0.5f) * 4.5f
            }
            TextLoopAnimation.PULSE -> {
                val p = 1f + 0.11f * sin(phase.toDouble() * 1.1).toFloat()
                animScaleX *= p
                animScaleY *= p
            }
            TextLoopAnimation.GLITCH -> {
                if ((frame % 9) in 0..2) {
                    val rng = Random(frame * 131)
                    animDx += (rng.nextFloat() - 0.5f) * 12f
                }
            }
            TextLoopAnimation.WAVE, TextLoopAnimation.RAINBOW, TextLoopAnimation.NONE -> Unit
        }

        // 3. Exit Animation
        if (outT > 0f) {
            when (outAnim) {
                TextOutAnimation.FADE_OUT -> animAlpha *= (1f - outT)
                TextOutAnimation.POP_OUT -> {
                    val sc = (1f - outT).coerceAtLeast(0.01f)
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.SLIDE_DOWN -> {
                    animDy += outT * outT * 110f
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.ZOOM_OUT -> {
                    val sc = 1f + outT * 1.3f
                    animScaleX *= sc
                    animScaleY *= sc
                    animAlpha *= (1f - outT)
                }
                TextOutAnimation.NONE -> Unit
            }
        }

        val alphaInt = (animAlpha * 255f).toInt().coerceIn(0, 255)
        if (alphaInt <= 2) return

        val tf = resolveTextTypeface(item.fontStyle, item.isBold)
        val textSizePx = item.fontSize.coerceIn(16f, 220f)
        val lines = visibleText.split("\n")

        val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textSizePx
            typeface = tf
        }
        val maxLineW = lines.maxOfOrNull { measurePaint.measureText(it) }?.coerceAtLeast(40f) ?: 80f
        val lineHeight = textSizePx * 1.18f
        val totalTextH = lines.size * lineHeight

        canvas.save()
        canvas.translate(item.x + animDx, item.y + animDy)
        canvas.rotate(item.rotationDeg + animRot)
        canvas.scale(animScaleX, animScaleY)

        // 4. Optional Box / Banner / Speech Bubble Backdrop
        val boxPadX = 28f
        val boxPadY = 18f
        val boxRect = RectF(
            -maxLineW / 2f - boxPadX,
            -totalTextH / 2f - boxPadY,
            maxLineW / 2f + boxPadX,
            totalTextH / 2f + boxPadY
        )
        when (boxStyle) {
            TextBoxStyle.COMIC_BANNER -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = item.boxColorArgb.toInt()
                    alpha = (alphaInt * 0.92f).toInt()
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                    color = item.colorArgb.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 14f, 14f, bg)
                canvas.drawRoundRect(boxRect, 14f, 14f, brd)
            }
            TextBoxStyle.YOUTUBE_PILL -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (item.boxColorArgb == 0xDD0F172AL) 0xEEEF4444.toInt() else item.boxColorArgb.toInt()
                    alpha = alphaInt
                }
                val radius = boxRect.height() * 0.5f
                canvas.drawRoundRect(boxRect, radius, radius, bg)
            }
            TextBoxStyle.SPEECH_BUBBLE -> {
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFAFFFFFF.toInt()
                    alpha = alphaInt
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 5f
                    color = 0xFF0F172AL.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 26f, 26f, bg)
                canvas.drawRoundRect(boxRect, 26f, 26f, brd)
                val tail = Path().apply {
                    moveTo(-18f, boxRect.bottom - 2f)
                    lineTo(-34f, boxRect.bottom + 28f)
                    lineTo(10f, boxRect.bottom - 2f)
                    close()
                }
                canvas.drawPath(tail, bg)
                canvas.drawPath(tail, brd)
            }
            TextBoxStyle.HORROR_BLOOD -> {
                val slash = Path().apply {
                    moveTo(boxRect.left - 18f, boxRect.top + 8f)
                    lineTo(boxRect.right + 22f, boxRect.top - 6f)
                    lineTo(boxRect.right + 8f, boxRect.bottom + 6f)
                    lineTo(boxRect.left - 26f, boxRect.bottom - 4f)
                    close()
                }
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xE622050A.toInt()
                    alpha = alphaInt
                }
                val brd = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                    color = 0xFFEF4444.toInt()
                    alpha = alphaInt
                }
                canvas.drawPath(slash, bg)
                canvas.drawPath(slash, brd)
            }
            TextBoxStyle.OUTLINE_GLOW -> {
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 14f
                    color = item.colorArgb.toInt()
                    alpha = (alphaInt * 0.35f).toInt()
                }
                val crisp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 3.5f
                    color = item.colorArgb.toInt()
                    alpha = alphaInt
                }
                canvas.drawRoundRect(boxRect, 18f, 18f, glow)
                canvas.drawRoundRect(boxRect, 18f, 18f, crisp)
            }
            TextBoxStyle.NONE -> Unit
        }

        // 5. Prepare Fill, Stroke, Shadow & Glow Paints
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textSizePx
            typeface = tf
            textAlign = Paint.Align.CENTER
            style = Paint.Style.FILL
            color = (tintColorArgb ?: item.colorArgb).toInt()
            alpha = alphaInt
        }

        if (tintColorArgb == null) {
            if (loopAnim == TextLoopAnimation.RAINBOW) {
                val shift = (frame * 6f * spd) % 360f
                val c1 = Color.HSVToColor(alphaInt, floatArrayOf(shift, 0.85f, 1f))
                val c2 = Color.HSVToColor(alphaInt, floatArrayOf((shift + 120f) % 360f, 0.85f, 1f))
                val c3 = Color.HSVToColor(alphaInt, floatArrayOf((shift + 240f) % 360f, 0.85f, 1f))
                fillPaint.shader = LinearGradient(
                    -maxLineW / 2f, 0f, maxLineW / 2f, 0f,
                    intArrayOf(c1, c2, c3), null, Shader.TileMode.CLAMP
                )
            } else if (item.gradientEndArgb != null) {
                fillPaint.shader = LinearGradient(
                    0f, -totalTextH / 2f, 0f, totalTextH / 2f,
                    item.colorArgb.toInt(), item.gradientEndArgb.toInt(), Shader.TileMode.CLAMP
                )
            }
        }

        val strokePaint = if (item.strokeWidth > 0.5f) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.STROKE
                strokeWidth = item.strokeWidth
                strokeJoin = Paint.Join.ROUND
                color = (tintColorArgb ?: item.strokeColorArgb).toInt()
                alpha = alphaInt
            }
        } else null

        val shadowPaint = if (item.shadowEnabled) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.FILL
                color = 0xAA000000.toInt()
                alpha = (alphaInt * 0.65f).toInt()
            }
        } else null

        val glowPaint = if (item.glowEnabled || boxStyle == TextBoxStyle.OUTLINE_GLOW) {
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textSizePx
                typeface = tf
                textAlign = Paint.Align.CENTER
                style = Paint.Style.STROKE
                strokeWidth = item.strokeWidth + 14f
                strokeJoin = Paint.Join.ROUND
                color = (tintColorArgb ?: item.colorArgb).toInt()
                alpha = (alphaInt * 0.34f).toInt()
            }
        } else null

        val perCharMode = (loopAnim == TextLoopAnimation.WAVE) || (inAnim == TextInAnimation.DROP_LETTERS && inT < 1f)
        val startBaselineY = -totalTextH / 2f + textSizePx * 0.88f

        lines.forEachIndexed { lineIdx, line ->
            val baseY = startBaselineY + lineIdx * lineHeight

            // Cyber Glitch RGB chromatic ghosts
            if (loopAnim == TextLoopAnimation.GLITCH && (frame % 9) in 0..2 && tintColorArgb == null) {
                val cyanP = Paint(fillPaint).apply { shader = null; color = 0xAA22D3EE.toInt() }
                val pinkP = Paint(fillPaint).apply { shader = null; color = 0xAAFB7185.toInt() }
                canvas.drawText(line, -7f, baseY - 2f, cyanP)
                canvas.drawText(line, 7f, baseY + 2f, pinkP)
            }

            if (perCharMode) {
                val lineW = measurePaint.measureText(line)
                var curX = -lineW / 2f
                line.forEachIndexed { charIdx, ch ->
                    val chStr = ch.toString()
                    val chW = measurePaint.measureText(chStr)
                    val cx = curX + chW / 2f
                    var cy = baseY
                    var chAlpha = alphaInt

                    if (loopAnim == TextLoopAnimation.WAVE) {
                        cy += sin((phase + charIdx * 0.55f).toDouble()).toFloat() * (textSizePx * 0.22f)
                    }
                    if (inAnim == TextInAnimation.DROP_LETTERS && inT < 1f) {
                        val charDelay = charIdx.toFloat() / (line.length.coerceAtLeast(1) + 2).toFloat()
                        val ct = ((inT - charDelay * 0.55f) / 0.45f).coerceIn(0f, 1f)
                        val drop = (1f - ct) * (1f - ct) * 110f
                        cy -= drop
                        chAlpha = (alphaInt * ct).toInt().coerceIn(0, 255)
                    }

                    if (chAlpha > 2) {
                        shadowPaint?.let {
                            it.alpha = (chAlpha * 0.65f).toInt()
                            canvas.drawText(chStr, cx + 5f, cy + 6f, it)
                        }
                        glowPaint?.let {
                            it.alpha = (chAlpha * 0.34f).toInt()
                            canvas.drawText(chStr, cx, cy, it)
                        }
                        strokePaint?.let {
                            it.alpha = chAlpha
                            canvas.drawText(chStr, cx, cy, it)
                        }
                        fillPaint.alpha = chAlpha
                        canvas.drawText(chStr, cx, cy, fillPaint)
                    }
                    curX += chW
                }
            } else {
                shadowPaint?.let { canvas.drawText(line, 5f, baseY + 6f, it) }
                glowPaint?.let { canvas.drawText(line, 0f, baseY, it) }
                strokePaint?.let { canvas.drawText(line, 0f, baseY, it) }
                canvas.drawText(line, 0f, baseY, fillPaint)
            }
        }

        // 6. Editor Selection Frame (only when selected & not playing/exporting)
        if (isSelected) {
            val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 3f
                color = 0xFF2DD4BF.toInt()
                pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
            }
            val selRect = RectF(boxRect.left - 8f, boxRect.top - 8f, boxRect.right + 8f, boxRect.bottom + 8f)
            canvas.drawRoundRect(selRect, 12f, 12f, selPaint)
            val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt() }
            canvas.drawCircle(selRect.left, selRect.top, 7f, dotFill)
            canvas.drawCircle(selRect.right, selRect.top, 7f, dotFill)
            canvas.drawCircle(selRect.left, selRect.bottom, 7f, dotFill)
            canvas.drawCircle(selRect.right, selRect.bottom, 7f, dotFill)
        }

        canvas.restore()
    }

    /**
     * Live Frame-Animated Facial Expressions (Custom Multi-Pose Eye/Mouth PNG Slots + Built-in Vector Presets,
     * Talking Loop, Audio Lip-Sync, Crying Tears, Laughing, Auto-Blinking with Half-Blink, Angry, Scared/Horror,
     * Shocked, and Manual Frame/Second Interval Timing).
     */
    fun drawModularFaceRig(
        canvas: Canvas,
        eyePackName: String,
        mouthPhonemeName: String,
        eyeColorArgb: Long,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        alphaInt: Int,
        tintColorArgb: Long?,
        isSideProfile: Boolean = false,
        eyebrowStyleName: String = EyebrowStyle.NORMAL.name,
        customEyeSlots: Map<String, String> = emptyMap(),
        customMouthSlots: Map<String, String> = emptyMap(),
        facialTiming: FacialTimingConfig = FacialTimingConfig(),
        faceTransform: ResolvedFaceTransform? = null,
        rig: SkeletalRig? = null,
        puppetRoot: EvaluatedPuppetRoot? = null,
        showAlignmentGuides: Boolean = false
    ) {
        val eyePack = runCatching { EyePackStyle.valueOf(eyePackName) }.getOrDefault(EyePackStyle.AUTO_BLINK)
        val defaultBrow = runCatching { EyebrowStyle.valueOf(eyebrowStyleName) }.getOrDefault(EyebrowStyle.NORMAL)
        val leftBrowStyle = runCatching {
            EyebrowStyle.valueOf(puppetRoot?.leftEyebrowStyle ?: rig?.leftEyebrowStyle ?: eyebrowStyleName)
        }.getOrDefault(defaultBrow)
        val rightBrowStyle = runCatching {
            EyebrowStyle.valueOf(puppetRoot?.rightEyebrowStyle ?: rig?.rightEyebrowStyle ?: eyebrowStyleName)
        }.getOrDefault(defaultBrow)
        val requestedMouth = runCatching { MouthPhoneme.valueOf(mouthPhonemeName) }.getOrDefault(MouthPhoneme.AUTO_LIPSYNC)
        val safeFps = fps.coerceAtLeast(1)
        val effectiveAlpha = (alphaInt * (faceTransform?.alphaMultiplier ?: 1f)).toInt().coerceIn(0, 255)

        val activeEyeMoodName = puppetRoot?.activeEyeMood ?: rig?.activeEyeMood ?: FaceMoodCategory.NORMAL.name
        val activeMouthMoodName = puppetRoot?.activeMouthMood ?: rig?.activeMouthMood ?: FaceMoodCategory.NORMAL.name
        val headTurn25D = (puppetRoot?.headTurn25D ?: rig?.headTurn25D ?: 0f).coerceIn(-1f, 1f)
        val leftPupilX = (puppetRoot?.leftPupilX ?: rig?.leftPupilX ?: 0f).coerceIn(-1f, 1f)
        val leftPupilY = (puppetRoot?.leftPupilY ?: rig?.leftPupilY ?: 0f).coerceIn(-1f, 1f)
        val syncPupils = rig?.syncPupils ?: true
        val rightPupilX = if (syncPupils) leftPupilX else (puppetRoot?.rightPupilX ?: rig?.rightPupilX ?: 0f).coerceIn(-1f, 1f)
        val rightPupilY = if (syncPupils) leftPupilY else (puppetRoot?.rightPupilY ?: rig?.rightPupilY ?: 0f).coerceIn(-1f, 1f)

        // Manual Frame/Second Lip-Sync Change Interval
        val lipStepFrames = AudioStudioEngine.resolveLipSyncIntervalFrames(facialTiming, safeFps)
        val emotionCycleFrames = AudioStudioEngine.resolveEmotionCycleFrames(facialTiming, safeFps)
        val emotionCycleRad = (frame.toDouble() / emotionCycleFrames.coerceAtLeast(1).toDouble()) * 2.0 * PI

        // Module 5: Check active Face FX / Horror Trigger keyframe (pre-made animated eye & mouth files locked at frame!)
        val activeFaceFx = rig?.faceFxTriggers?.firstOrNull { frame in it.frame..(it.frame + it.durationFrames) }

        // Resolve live frame-animated mouth phoneme (Continuous Talking Loop OR Audio Lip-Sync)
        val activeMouth = when (requestedMouth) {
            MouthPhoneme.AUTO_LIPSYNC -> AudioStudioEngine.evaluateLipSyncPhonemeWithTiming(
                audioTracks = audioTracks,
                frame = frame,
                fps = safeFps,
                timing = facialTiming
            )
            MouthPhoneme.TALKING_LOOP -> {
                val talkCycle = listOf(
                    MouthPhoneme.REST,
                    MouthPhoneme.HALF_OPEN,
                    MouthPhoneme.A,
                    MouthPhoneme.HALF_OPEN,
                    MouthPhoneme.O,
                    MouthPhoneme.E,
                    MouthPhoneme.HALF_OPEN,
                    MouthPhoneme.A
                )
                talkCycle[(frame.coerceAtLeast(0) / lipStepFrames) % talkCycle.size]
            }
            else -> requestedMouth
        }

        fun fill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = effectiveAlpha
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = effectiveAlpha
        }

        // Subtle animated head emotion motion governed by Emotion Loop Speed!
        val isLaughing = eyePack == EyePackStyle.LAUGHING || requestedMouth == MouthPhoneme.LAUGHING || activeEyeMoodName == FaceMoodCategory.LAUGHING.name
        val isCrying = eyePack == EyePackStyle.SAD_TEARS || requestedMouth == MouthPhoneme.CRYING || activeEyeMoodName == FaceMoodCategory.CRYING.name
        val isScared = eyePack == EyePackStyle.SCARED_HORROR || requestedMouth == MouthPhoneme.SCARED || activeEyeMoodName == FaceMoodCategory.SCARED.name || activeEyeMoodName == FaceMoodCategory.WITCH_HORROR.name

        val faceJitterX = when {
            isScared -> sin(emotionCycleRad * 2.2).toFloat() * 2.2f
            isCrying -> sin(emotionCycleRad * 1.4).toFloat() * 1.2f
            else -> 0f
        }
        val faceBounceY = when {
            isLaughing -> -kotlin.math.abs(sin(emotionCycleRad)).toFloat() * 5.2f
            isCrying -> sin(emotionCycleRad * 0.9).toFloat() * 2.4f
            else -> 0f
        }

        // Module 6: 2.5D Face Turn Parallax shifts Eyes/Nose/Mouth faster than Head outline!
        val parallaxShiftX = headTurn25D * 20f
        val parallaxScaleX = (1f - kotlin.math.abs(headTurn25D) * 0.16f).coerceIn(0.75f, 1f)

        canvas.save()
        canvas.translate(faceJitterX + parallaxShiftX, faceBounceY)
        canvas.scale(parallaxScaleX, 1f)

        // Manual Frame/Second Auto-Blink Interval & Duration (OPEN -> HALF_BLINK -> CLOSED -> HALF_BLINK -> OPEN)
        val blinkPhase = if (eyePack == EyePackStyle.AUTO_BLINK) {
            AudioStudioEngine.evaluateBlinkPhase(frame, safeFps, facialTiming)
        } else {
            AudioStudioEngine.BlinkPhase.OPEN
        }
        val isHalfBlinkNow = eyePack == EyePackStyle.HALF_BLINK || blinkPhase == AudioStudioEngine.BlinkPhase.HALF_BLINK
        val isClosedBlinkNow = eyePack == EyePackStyle.CLOSED_BLINK || blinkPhase == AudioStudioEngine.BlinkPhase.CLOSED

        // Determine active Custom Eye Slot + Separate EyeMoodSet + Unified Single-Container Left/Right Eyes
        val activeEyeSlot = when {
            isClosedBlinkNow -> CustomEyeSlot.CLOSED_BLINK
            isHalfBlinkNow -> CustomEyeSlot.HALF_BLINK
            eyePack == EyePackStyle.HAPPY || eyePack == EyePackStyle.LAUGHING -> CustomEyeSlot.HAPPY_LAUGHING
            eyePack == EyePackStyle.SAD_TEARS -> CustomEyeSlot.CRYING_TEARS
            eyePack == EyePackStyle.ANGRY -> CustomEyeSlot.ANGRY_FURROWED
            eyePack == EyePackStyle.SURPRISED || eyePack == EyePackStyle.SCARED_HORROR -> CustomEyeSlot.SHOCKED_WIDE
            eyePack == EyePackStyle.WINK -> CustomEyeSlot.CLOSED_BLINK
            else -> CustomEyeSlot.OPEN_NORMAL
        }
        val fxEyePath = activeFaceFx?.eyeAnimPaths?.takeIf { it.isNotEmpty() }?.let { paths ->
            val relIdx = ((frame - activeFaceFx.frame).coerceAtLeast(0) / lipStepFrames.coerceAtLeast(1)) % paths.size
            paths[relIdx]
        }
        val activeEyeMoodSet = rig?.eyeMoodSets?.get(activeEyeMoodName)
        val moodEyePath = when {
            isClosedBlinkNow -> activeEyeMoodSet?.closedImagePath ?: activeEyeMoodSet?.openImagePath
            isHalfBlinkNow -> activeEyeMoodSet?.halfBlinkImagePath ?: activeEyeMoodSet?.openImagePath
            else -> activeEyeMoodSet?.openImagePath
        }
        val leftEyeContainer = rig?.leftEyeContainer
        val rightEyeContainer = rig?.rightEyeContainer
        val hasUnifiedEyeContainers = (leftEyeContainer?.scleraImagePath?.isNotBlank() == true) ||
            (rightEyeContainer?.scleraImagePath?.isNotBlank() == true)

        val fl = rig?.faceLayers ?: FaceLayersConfig()
        val eyeBuilderPath = fl.eyeBuilderFrames.takeIf { it.isNotEmpty() }?.let { frames ->
            val idx = when (activeEyeSlot) {
                CustomEyeSlot.CLOSED_BLINK -> (frames.size - 1).coerceAtLeast(0)
                CustomEyeSlot.HALF_BLINK -> (frames.size / 2).coerceIn(0, frames.lastIndex)
                else -> (frame / 6) % frames.size
            }
            frames[idx]
        }
        val customEyePath = fxEyePath
            ?: moodEyePath
            ?: eyeBuilderPath
            ?: customEyeSlots[activeEyeSlot.name]
            ?: customEyeSlots[CustomEyeSlot.OPEN_NORMAL.name]?.takeIf { customEyeSlots.isNotEmpty() }
        val customEyeBmp = customEyePath?.let { getCachedBitmap(it) }
        val eyeY = -8f
        canvas.save()
        if (faceTransform != null) {
            canvas.translate(faceTransform.eyeOffsetX, faceTransform.eyeOffsetY)
            canvas.rotate(faceTransform.eyeRotationDeg, 0f, eyeY)
            canvas.scale(faceTransform.eyeScale, faceTransform.eyeScale, 0f, eyeY)
        }
        val avgEyeOffX = (fl.leftEye.offsetX + fl.rightEye.offsetX) * 0.5f
        val avgEyeOffY = (fl.leftEye.offsetY + fl.rightEye.offsetY) * 0.5f
        val avgEyeScaleX = (((fl.leftEye.scale * fl.leftEye.scaleX) + (fl.rightEye.scale * fl.rightEye.scaleX)) * 0.5f).coerceIn(0.1f, 4f)
        val avgEyeScaleY = (((fl.leftEye.scale * fl.leftEye.scaleY) + (fl.rightEye.scale * fl.rightEye.scaleY)) * 0.5f).coerceIn(0.1f, 4f)
        if (avgEyeOffX != 0f || avgEyeOffY != 0f || avgEyeScaleX != 1f || avgEyeScaleY != 1f) {
            canvas.translate(avgEyeOffX, avgEyeOffY)
            canvas.scale(avgEyeScaleX, avgEyeScaleY, 0f, eyeY)
        }

        // Helper for Module 4: Unified Single-Container Eye with Automatic Sclera Alpha-Masking (SRC_ATOP)
        fun drawAlphaMaskedEyeUnit(
            cx: Float,
            cy: Float,
            boxW: Float,
            boxH: Float,
            scleraBmp: Bitmap,
            pupilBmp: Bitmap?,
            eyelidBmp: Bitmap?,
            eyelidColorArgb: Long,
            pupilNormX: Float,
            pupilNormY: Float,
            pupilScale: Float,
            maxPupilOffsetPx: Float
        ) {
            val dst = RectF(cx - boxW / 2f, cy - boxH / 2f, cx + boxW / 2f, cy + boxH / 2f)
            val layerSave = canvas.saveLayer(dst.left - 8f, dst.top - 8f, dst.right + 8f, dst.bottom + 8f, null)
            val basePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = effectiveAlpha
                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
            }
            // 1. Sclera Base (defines the alpha mask boundary!)
            canvas.drawBitmap(scleraBmp, null, dst, basePaint)

            // 2. Pupil / Iris clipped strictly inside Sclera alpha via SRC_ATOP!
            val px = cx + pupilNormX * maxPupilOffsetPx.coerceIn(4f, 24f)
            val py = cy + pupilNormY * (maxPupilOffsetPx * 0.72f).coerceIn(3f, 18f)
            val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = effectiveAlpha
                xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
            }
            if (pupilBmp != null) {
                val pSize = (min(boxW, boxH) * 0.56f * pupilScale.coerceIn(0.4f, 2.2f))
                val pRect = RectF(px - pSize / 2f, py - pSize / 2f, px + pSize / 2f, py + pSize / 2f)
                canvas.drawBitmap(pupilBmp, null, pRect, pupilPaint)
            } else {
                val irisR = (min(boxW, boxH) * 0.28f * pupilScale.coerceIn(0.4f, 2.2f))
                pupilPaint.style = Paint.Style.FILL
                pupilPaint.color = (tintColorArgb ?: eyeColorArgb).toInt()
                canvas.drawCircle(px, py, irisR, pupilPaint)
                pupilPaint.color = (tintColorArgb ?: 0xFF0F172AL).toInt()
                canvas.drawCircle(px, py, irisR * 0.55f, pupilPaint)
                pupilPaint.color = Color.WHITE
                canvas.drawCircle(px - irisR * 0.3f, py - irisR * 0.35f, irisR * 0.24f, pupilPaint)
            }

            // 3. Automatic Eyelid Shutter (custom PNG OR skin-tone eyelid curtain clipped to Sclera!)
            val shutterFrac = when {
                isClosedBlinkNow -> 1.0f
                isHalfBlinkNow -> 0.52f
                else -> 0f
            }
            if (shutterFrac > 0.01f) {
                val lidRect = RectF(dst.left, dst.top, dst.right, dst.top + dst.height() * shutterFrac)
                val lidPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = effectiveAlpha
                    xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
                    color = (tintColorArgb ?: eyelidColorArgb).toInt()
                }
                if (eyelidBmp != null) {
                    canvas.drawBitmap(eyelidBmp, null, lidRect, lidPaint)
                } else {
                    canvas.drawRect(lidRect, lidPaint)
                }
            }
            canvas.restoreToCount(layerSave)
        }

        if (fxEyePath == null && hasUnifiedEyeContainers && leftEyeContainer != null && rightEyeContainer != null) {
            // Render Module 4 Unified Single-Container Left & Right Eyes with Sclera Alpha Masking!
            val skinFallback = rig.characterAppearance?.skinToneArgb ?: leftEyeContainer.eyelidColorArgb
            val units = if (isSideProfile) {
                listOf(Triple(14f + fl.rightEye.offsetX, rightEyeContainer, rightPupilX to rightPupilY))
            } else {
                listOf(
                    Triple(-18f + (fl.leftEye.offsetX - avgEyeOffX), leftEyeContainer, leftPupilX to leftPupilY),
                    Triple(18f + (fl.rightEye.offsetX - avgEyeOffX), rightEyeContainer, rightPupilX to rightPupilY)
                )
            }
            units.forEachIndexed { uIdx, (ex, container, pLook) ->
                val eyeLayerCfg = if (isSideProfile || uIdx == 1) fl.rightEye else fl.leftEye
                if (!eyeLayerCfg.visible) return@forEachIndexed
                val scleraBmp = (container.scleraImagePath ?: rightEyeContainer.scleraImagePath ?: leftEyeContainer.scleraImagePath)
                    ?.let { getCachedBitmap(it) }
                val pupilBmp = (container.pupilImagePath ?: activeEyeMoodSet?.pupilImagePath)?.let { getCachedBitmap(it) }
                val lidBmp = (container.eyelidImagePath ?: activeEyeMoodSet?.eyelidImagePath)?.let { getCachedBitmap(it) }
                if (scleraBmp != null) {
                    val boxW = if (isSideProfile) 24f else 28f
                    val aspect = scleraBmp.height.toFloat() / scleraBmp.width.toFloat().coerceAtLeast(1f)
                    val boxH = (boxW * aspect).coerceIn(18f, 36f)
                    drawAlphaMaskedEyeUnit(
                        cx = ex,
                        cy = eyeY,
                        boxW = boxW,
                        boxH = boxH,
                        scleraBmp = scleraBmp,
                        pupilBmp = pupilBmp,
                        eyelidBmp = lidBmp,
                        eyelidColorArgb = skinFallback,
                        pupilNormX = pLook.first,
                        pupilNormY = pLook.second,
                        pupilScale = container.pupilScale,
                        maxPupilOffsetPx = container.maxPupilOffsetPx
                    )
                }
            }
        } else if (customEyeBmp != null) {
            // Render Custom Drawn / Imported PNG Eyes or EyeMoodSet PNG (with Sclera Alpha-Masked Pupil when pupil supplied!)
            val targetW = if (isSideProfile) 38f else 66f
            val aspect = customEyeBmp.height.toFloat() / customEyeBmp.width.toFloat().coerceAtLeast(1f)
            val targetH = (targetW * aspect).coerceIn(16f, 64f)
            val cx = if (isSideProfile) 14f else 0f
            val moodPupilBmp = activeEyeMoodSet?.pupilImagePath?.let { getCachedBitmap(it) }
            val moodLidBmp = activeEyeMoodSet?.eyelidImagePath?.let { getCachedBitmap(it) }
            if (moodPupilBmp != null && fxEyePath == null) {
                drawAlphaMaskedEyeUnit(
                    cx = cx,
                    cy = eyeY,
                    boxW = targetW,
                    boxH = targetH,
                    scleraBmp = customEyeBmp,
                    pupilBmp = moodPupilBmp,
                    eyelidBmp = moodLidBmp,
                    eyelidColorArgb = rig?.characterAppearance?.skinToneArgb ?: 0xFFF5C6A5L,
                    pupilNormX = leftPupilX,
                    pupilNormY = leftPupilY,
                    pupilScale = 0.65f,
                    maxPupilOffsetPx = 10f
                )
            } else {
                val dst = RectF(cx - targetW / 2f, eyeY - targetH / 2f, cx + targetW / 2f, eyeY + targetH / 2f)
                val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = effectiveAlpha
                    if (tintColorArgb != null) {
                        colorFilter = android.graphics.PorterDuffColorFilter(tintColorArgb.toInt(), PorterDuff.Mode.SRC_IN)
                    }
                }
                val needsSyntheticBlinkSquish = fxEyePath == null && (isClosedBlinkNow || isHalfBlinkNow) &&
                    customEyeSlots[activeEyeSlot.name].isNullOrBlank() &&
                    (if (isClosedBlinkNow) activeEyeMoodSet?.closedImagePath else activeEyeMoodSet?.halfBlinkImagePath).isNullOrBlank()
                canvas.save()
                if (needsSyntheticBlinkSquish) {
                    val blinkSy = if (isClosedBlinkNow) 0.14f else 0.52f
                    canvas.scale(1f, blinkSy, cx, eyeY)
                }
                canvas.drawBitmap(customEyeBmp, null, dst, bmpPaint)
                canvas.restore()
            }

            // Animated falling tear overlay when Crying & no custom crying PNG tears baked in
            if (isCrying && customEyeSlots[CustomEyeSlot.CRYING_TEARS.name].isNullOrBlank() && activeEyeMoodSet?.openImagePath.isNullOrBlank()) {
                val tearSpeed = (frame.toFloat() / emotionCycleFrames.coerceAtLeast(1).toFloat())
                val drop1 = ((tearSpeed * 34f) % 34f)
                val drop2 = (((tearSpeed + 0.5f) * 34f) % 34f)
                val tearPaint = fill(0xFF38BDF8L)
                val tearXs = if (isSideProfile) listOf(14f) else listOf(-18f, 18f)
                tearXs.forEachIndexed { idx, ex ->
                    val d = if (idx == 0) drop1 else drop2
                    canvas.drawOval(RectF(ex - 3.6f, eyeY + 10f + d, ex + 3.6f, eyeY + 21f + d), tearPaint)
                }
            }
        } else {
            val eyeXs = if (isSideProfile) listOf(18f) else listOf(-18f, 18f)
            eyeXs.forEachIndexed { idx, ex ->
                val activeBrow = if (idx == 0 && !isSideProfile) leftBrowStyle else rightBrowStyle
                val pLookX = if (idx == 0 && !isSideProfile) leftPupilX else rightPupilX
                val pLookY = if (idx == 0 && !isSideProfile) leftPupilY else rightPupilY
                when {
                    isClosedBlinkNow || (eyePack == EyePackStyle.WINK && (isSideProfile || idx == 1)) -> {
                        canvas.drawArc(RectF(ex - 9f, eyeY - 4f, ex + 9f, eyeY + 8f), 195f, 150f, false, stroke)
                    }
                    isHalfBlinkNow -> {
                        val eyeRx = if (isSideProfile) 8.2f else 10.2f
                        canvas.drawOval(RectF(ex - eyeRx, eyeY - 5.5f, ex + eyeRx, eyeY + 6.5f), fill(0xFFFFFFFFL))
                        canvas.drawCircle(ex + pLookX * 4f, eyeY + 1f + pLookY * 2f, 5.0f, fill(eyeColorArgb))
                        canvas.drawCircle(ex + pLookX * 4f, eyeY + 1f + pLookY * 2f, 2.8f, fill(0xFF0F172AL))
                        canvas.drawOval(RectF(ex - eyeRx, eyeY - 5.5f, ex + eyeRx, eyeY + 6.5f), stroke)
                        canvas.drawLine(ex - eyeRx, eyeY - 2f, ex + eyeRx, eyeY - 2f, stroke)
                    }
                    eyePack == EyePackStyle.HAPPY || eyePack == EyePackStyle.LAUGHING -> {
                        val squintLift = if (isLaughing) sin(emotionCycleRad * 2.0).toFloat() * 1.8f else 0f
                        canvas.drawArc(
                            RectF(ex - 11f, eyeY - 7f + squintLift, ex + 11f, eyeY + 9f + squintLift),
                            195f, 150f, false, stroke
                        )
                        if (isLaughing) {
                            canvas.drawOval(
                                RectF(ex - 9f, eyeY + 9f, ex + 9f, eyeY + 17f),
                                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = (tintColorArgb ?: 0xFFFF7AA2L).toInt()
                                    alpha = (effectiveAlpha * 0.48f).toInt()
                                }
                            )
                        }
                    }
                    else -> {
                        val baseShiftX = when {
                            isScared -> sin(emotionCycleRad * 2.0 + idx).toFloat() * 2.0f
                            isSideProfile -> 3.5f
                            eyePack == EyePackStyle.SIDE_LOOK -> 4.5f
                            else -> 0f
                        }
                        val pupilShiftX = (baseShiftX + pLookX * 5.2f).coerceIn(-6.2f, 6.2f)
                        val pupilShiftY = ((if (isScared) cos(emotionCycleRad * 2.4 + idx).toFloat() * 1.6f else 0f) + pLookY * 4.5f).coerceIn(-5.2f, 5.2f)
                        val eyePulse = if (eyePack == EyePackStyle.SURPRISED) 1f + 0.06f * sin(emotionCycleRad).toFloat() else 1f
                        val eyeR = (when (eyePack) {
                            EyePackStyle.SURPRISED, EyePackStyle.SCARED_HORROR -> 13f
                            else -> 10.5f
                        }) * eyePulse
                        val eyeRx = if (isSideProfile) eyeR * 0.78f else eyeR
                        canvas.drawOval(RectF(ex - eyeRx, eyeY - eyeR * 1.15f, ex + eyeRx, eyeY + eyeR * 1.15f), fill(0xFFFFFFFFL))

                        val irisR = when (eyePack) {
                            EyePackStyle.SCARED_HORROR -> 3.6f
                            EyePackStyle.SURPRISED -> 5.2f
                            else -> 6.8f
                        }
                        canvas.drawCircle(ex + pupilShiftX, eyeY + 1f + pupilShiftY, irisR, fill(eyeColorArgb))
                        canvas.drawCircle(ex + pupilShiftX, eyeY + 1f + pupilShiftY, irisR * 0.55f, fill(0xFF0F172AL))
                        canvas.drawCircle(ex - 2.5f + pupilShiftX * 0.5f, eyeY - 3.5f + pupilShiftY * 0.4f, 2.6f, fill(0xFFFFFFFFL))
                        canvas.drawOval(RectF(ex - eyeRx, eyeY - eyeR * 1.15f, ex + eyeRx, eyeY + eyeR * 1.15f), stroke)

                        // Live Animated Falling Tear Drops governed by Emotion Loop Speed!
                        if (isCrying) {
                            canvas.drawOval(RectF(ex - 8f, eyeY + 7f, ex + 8f, eyeY + 13f), fill(0xFF7DD3FCL))
                            val cycleProgress = (frame.toFloat() / emotionCycleFrames.coerceAtLeast(1).toFloat())
                            val drop1 = (((cycleProgress + idx * 0.33f) * 34f) % 34f)
                            val drop2 = (((cycleProgress + 0.5f + idx * 0.21f) * 34f) % 34f)
                            val tearPaint = fill(0xFF38BDF8L)
                            canvas.drawOval(RectF(ex - 4.2f, eyeY + 11f + drop1, ex + 4.2f, eyeY + 23f + drop1), tearPaint)
                            canvas.drawOval(RectF(ex - 2.8f + (if (idx == 0) -4f else 4f), eyeY + 10f + drop2, ex + 2.8f + (if (idx == 0) -4f else 4f), eyeY + 19f + drop2), tearPaint)
                        }

                        // Animated Horror Sweat Drop
                        if (isScared && (isSideProfile || idx == 1)) {
                            val sweatDrop = (((frame.toFloat() / emotionCycleFrames.coerceAtLeast(1).toFloat()) * 18f) % 18f)
                            canvas.drawOval(RectF(ex + 13f, eyeY - 12f + sweatDrop, ex + 19f, eyeY - 2f + sweatDrop), fill(0xFF7DD3FCL))
                        }
                    }
                }
                val browTremble = when {
                    isCrying -> sin(emotionCycleRad * 1.8 + idx).toFloat() * 1.6f
                    eyePack == EyePackStyle.ANGRY -> sin(emotionCycleRad * 2.0).toFloat() * 1.1f
                    isScared -> sin(emotionCycleRad * 2.5).toFloat() * 1.5f
                    else -> 0f
                }
                val browLift = when {
                    activeBrow == EyebrowStyle.RAISED -> -8.5f
                    activeBrow == EyebrowStyle.ANGRY -> 2.5f
                    activeBrow == EyebrowStyle.WORRIED -> -2.5f
                    eyePack == EyePackStyle.SURPRISED || eyePack == EyePackStyle.SCARED_HORROR -> -7f
                    eyePack == EyePackStyle.LAUGHING -> -3f
                    else -> 0f
                } + browTremble
                val tilt = when {
                    activeBrow == EyebrowStyle.ANGRY -> if (idx == 0 && !isSideProfile) 7.5f else -7.5f
                    activeBrow == EyebrowStyle.WORRIED -> if (idx == 0 && !isSideProfile) -6.5f else 6.5f
                    activeBrow == EyebrowStyle.RAISED -> if (idx == 0 && !isSideProfile) -2f else 2f
                    eyePack == EyePackStyle.ANGRY -> if (idx == 0 && !isSideProfile) 6.5f else -6.5f
                    eyePack == EyePackStyle.SAD_TEARS || eyePack == EyePackStyle.SCARED_HORROR -> if (idx == 0 && !isSideProfile) -5.5f else 5.5f
                    else -> 0f
                }
                canvas.drawLine(ex - 8.5f, eyeY - 17f + browLift - tilt, ex + 8.5f, eyeY - 17f + browLift + tilt, stroke)
            }
        }
        // Module 5: Separate Same-Size Alignment Guide Box for Eyes (editor only)
        if (showAlignmentGuides && tintColorArgb == null) {
            val eyeGuide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF06B6D4.toInt()
                style = Paint.Style.STROKE
                strokeWidth = 2f
                pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            }
            canvas.drawRect(RectF(-35f, eyeY - 18f, 35f, eyeY + 18f), eyeGuide)
        }
        // Custom PNG Eyebrows / Watermark Builder Eyebrow frames (from FaceLayersConfig)
        val browBuilderBmp = fl.browBuilderFrames.takeIf { it.isNotEmpty() }?.let { frames ->
            val idx = (frame.coerceAtLeast(0) / emotionCycleFrames.coerceAtLeast(1)) % frames.size
            getCachedBitmap(frames[idx])
        }
        val leftBrowBmp = fl.leftBrowImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) } ?: browBuilderBmp
        val rightBrowBmp = fl.rightBrowImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) } ?: browBuilderBmp
        if (leftBrowBmp != null || rightBrowBmp != null) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = effectiveAlpha
                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
            }
            val browSlots = if (isSideProfile) {
                listOf(Triple(16f, fl.rightBrow, rightBrowBmp ?: leftBrowBmp))
            } else {
                listOf(
                    Triple(-18f, fl.leftBrow, leftBrowBmp),
                    Triple(18f, fl.rightBrow, rightBrowBmp)
                )
            }
            browSlots.forEach { (baseBx, browTf, bmp) ->
                if (bmp != null && browTf.visible) {
                    val bw = 24f * (browTf.scale * browTf.scaleX).coerceIn(0.1f, 4f)
                    val aspect = bmp.height.toFloat() / bmp.width.coerceAtLeast(1).toFloat()
                    val bh = (24f * browTf.scale * browTf.scaleY * aspect).coerceIn(4f, 48f)
                    val bx = baseBx + browTf.offsetX
                    val by = eyeY - 17f + browTf.offsetY
                    canvas.save()
                    canvas.rotate(browTf.rotationDeg, bx, by)
                    canvas.drawBitmap(bmp, null, RectF(bx - bw / 2f, by - bh / 2f, bx + bw / 2f, by + bh / 2f), bp)
                    canvas.restore()
                }
            }
        }
        canvas.restore()

        // Module 5 & Master Face Builder: Custom PNG Nose OR Built-in Nose Style Preset with FaceLayersConfig offset/scale/rotation
        val noseBmp = rig?.customNoseImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        val noseStyle = runCatching { NoseStylePreset.valueOf(rig?.noseStyle ?: NoseStylePreset.CLASSIC.name) }
            .getOrDefault(NoseStylePreset.CLASSIC)
        val noseX = (if (isSideProfile) 24f else headTurn25D * 4f) + fl.nose.offsetX
        val noseY = 6f + fl.nose.offsetY
        if (fl.nose.visible) {
            canvas.save()
            canvas.rotate(fl.nose.rotationDeg, noseX, noseY)
            canvas.scale(
                (fl.nose.scale * fl.nose.scaleX).coerceIn(0.1f, 4f),
                (fl.nose.scale * fl.nose.scaleY).coerceIn(0.1f, 4f),
                noseX,
                noseY
            )
            if (noseBmp != null) {
                val np = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = effectiveAlpha }
                canvas.drawBitmap(noseBmp, null, RectF(noseX - 10f, noseY - 10f, noseX + 10f, noseY + 10f), np)
            } else if (!isSideProfile && noseStyle != NoseStylePreset.HIDDEN && rig != null) {
                val noseStroke = Paint(stroke).apply { strokeWidth = 2.8f }
                when (noseStyle) {
                    NoseStylePreset.CLASSIC -> {
                        canvas.drawArc(RectF(noseX - 4f, noseY - 5f, noseX + 4f, noseY + 4f), 20f, 140f, false, noseStroke)
                    }
                    NoseStylePreset.BUTTON -> {
                        canvas.drawOval(RectF(noseX - 4.5f, noseY - 3f, noseX + 4.5f, noseY + 3.5f), noseStroke)
                    }
                    NoseStylePreset.SHARP -> {
                        val p = Path().apply { moveTo(noseX, noseY - 9f); lineTo(noseX + 6f, noseY + 4f); lineTo(noseX - 3f, noseY + 4f) }
                        canvas.drawPath(p, noseStroke)
                    }
                    NoseStylePreset.MINIMAL -> {
                        canvas.drawCircle(noseX, noseY, 2.6f, noseStroke)
                    }
                    NoseStylePreset.HOOKED_WITCH -> {
                        val p = Path().apply {
                            moveTo(noseX - 2f, noseY - 10f)
                            quadTo(noseX + 14f, noseY + 2f, noseX + 2f, noseY + 10f)
                            lineTo(noseX - 4f, noseY + 5f)
                        }
                        canvas.drawPath(p, noseStroke)
                    }
                    NoseStylePreset.HIDDEN -> Unit
                }
            }
            canvas.restore()
        }

        // Module 5: Strictly Separate 6-Frame MouthMoodSet + Smart Auto-Dubbing (speaking 3..6 vs silent 1..2 preserving emotion!)
        val fxMouthPath = activeFaceFx?.mouthAnimPaths?.takeIf { it.isNotEmpty() }?.let { paths ->
            val relIdx = ((frame - activeFaceFx.frame).coerceAtLeast(0) / lipStepFrames.coerceAtLeast(1)) % paths.size
            paths[relIdx]
        }
        val activeMouthMoodSet = rig?.mouthMoodSets?.get(activeMouthMoodName)
        val hasMouthMoodFrames = activeMouthMoodSet != null && listOfNotNull(
            activeMouthMoodSet.frame1SilentClosed,
            activeMouthMoodSet.frame2SilentIdle,
            activeMouthMoodSet.frame3SoftSpeech,
            activeMouthMoodSet.frame4MediumSpeech,
            activeMouthMoodSet.frame5WideSpeech,
            activeMouthMoodSet.frame6PeakEmotion
        ).any { it.isNotBlank() }

        val moodMouthPath = if (hasMouthMoodFrames && activeMouthMoodSet != null) {
            val moodFrameIdx = AudioStudioEngine.evaluateMouthMoodFrame(
                audioTracks = audioTracks,
                frame = frame,
                fps = safeFps,
                timing = facialTiming,
                activeMouthMood = activeMouthMoodName
            )
            when (moodFrameIdx) {
                1 -> activeMouthMoodSet.frame1SilentClosed ?: activeMouthMoodSet.frame2SilentIdle
                2 -> activeMouthMoodSet.frame2SilentIdle ?: activeMouthMoodSet.frame1SilentClosed
                3 -> activeMouthMoodSet.frame3SoftSpeech ?: activeMouthMoodSet.frame4MediumSpeech ?: activeMouthMoodSet.frame1SilentClosed
                4 -> activeMouthMoodSet.frame4MediumSpeech ?: activeMouthMoodSet.frame3SoftSpeech ?: activeMouthMoodSet.frame5WideSpeech
                5 -> activeMouthMoodSet.frame5WideSpeech ?: activeMouthMoodSet.frame4MediumSpeech ?: activeMouthMoodSet.frame6PeakEmotion
                else -> activeMouthMoodSet.frame6PeakEmotion ?: activeMouthMoodSet.frame5WideSpeech ?: activeMouthMoodSet.frame4MediumSpeech
            } ?: activeMouthMoodSet.frame1SilentClosed
        } else null

        // Determine active legacy Custom Mouth Slot fallback
        val activeMouthSlot = when (activeMouth) {
            MouthPhoneme.REST -> CustomMouthSlot.CLOSED_IDLE
            MouthPhoneme.HALF_OPEN, MouthPhoneme.I, MouthPhoneme.U, MouthPhoneme.E -> CustomMouthSlot.HALF_OPEN_TALK
            MouthPhoneme.A, MouthPhoneme.O, MouthPhoneme.SHOCK -> CustomMouthSlot.WIDE_OPEN_LOUD
            MouthPhoneme.SMILE, MouthPhoneme.LAUGHING -> CustomMouthSlot.SMILE_LAUGH
            MouthPhoneme.CRYING -> CustomMouthSlot.SAD_CRYING
            MouthPhoneme.ANGRY_SHOUT, MouthPhoneme.SCARED -> CustomMouthSlot.ANGRY_SHOUT
            else -> CustomMouthSlot.CLOSED_IDLE
        }
        val mouthBuilderPath = fl.mouthBuilderFrames.takeIf { it.isNotEmpty() }?.let { frames ->
            val idx = (frame.coerceAtLeast(0) / lipStepFrames.coerceAtLeast(1)) % frames.size
            frames[idx]
        }
        val customMouthPath = fxMouthPath
            ?: moodMouthPath
            ?: mouthBuilderPath
            ?: customMouthSlots[activeMouthSlot.name]
            ?: customMouthSlots[CustomMouthSlot.CLOSED_IDLE.name]?.takeIf { customMouthSlots.isNotEmpty() }
        val customMouthBmp = customMouthPath?.let { getCachedBitmap(it) }

        // Animated Mouth (Custom 6-Frame Mood Set PNGs OR Watermark Builder Frames OR Legacy Multi-Pose PNGs OR Vector Phonemes)
        val mouthX = (if (isSideProfile) 24f else 0f) + fl.mouth.offsetX
        val mouthScaleX = if (isSideProfile) 0.72f else 1f
        val mouthY = 18f + fl.mouth.offsetY
        val mouthFill = fill(rig?.characterAppearance?.mouthColorArgb ?: 0xFFBE123CL)
        val tongueFill = fill(0xFFFB7185L)
        val teethFill = fill(0xFFFFFFFFL)
        canvas.save()
        if (faceTransform != null) {
            canvas.translate(faceTransform.mouthOffsetX, faceTransform.mouthOffsetY)
            canvas.rotate(faceTransform.mouthRotationDeg, mouthX, mouthY)
            canvas.scale(faceTransform.mouthScale, faceTransform.mouthScale, mouthX, mouthY)
        }
        canvas.rotate(fl.mouth.rotationDeg, mouthX, mouthY)
        canvas.scale(
            (fl.mouth.scale * fl.mouth.scaleX).coerceIn(0.1f, 4f),
            (fl.mouth.scale * fl.mouth.scaleY).coerceIn(0.1f, 4f),
            mouthX,
            mouthY
        )
        canvas.translate(mouthX, 0f)
        canvas.scale(mouthScaleX, 1f)
        if (customMouthBmp != null) {
            val targetW = 42f
            val aspect = customMouthBmp.height.toFloat() / customMouthBmp.width.toFloat().coerceAtLeast(1f)
            val targetH = (targetW * aspect).coerceIn(14f, 44f)
            val pulseY = when (activeMouth) {
                MouthPhoneme.LAUGHING -> 1f + 0.16f * kotlin.math.abs(sin(emotionCycleRad)).toFloat()
                MouthPhoneme.CRYING -> 1f + 0.12f * sin(emotionCycleRad).toFloat()
                MouthPhoneme.ANGRY_SHOUT -> 1f + 0.10f * kotlin.math.abs(sin(emotionCycleRad * 1.5)).toFloat()
                else -> 1f
            }
            val dst = RectF(-targetW / 2f, mouthY - (targetH * pulseY) / 2f, targetW / 2f, mouthY + (targetH * pulseY) / 2f)
            val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = effectiveAlpha
                if (tintColorArgb != null) {
                    colorFilter = android.graphics.PorterDuffColorFilter(tintColorArgb.toInt(), PorterDuff.Mode.SRC_IN)
                }
            }
            canvas.drawBitmap(customMouthBmp, null, dst, bmpPaint)
        } else {
            when (activeMouth) {
                MouthPhoneme.LAUGHING -> {
                    val openPulse = 1f + 0.22f * kotlin.math.abs(sin(emotionCycleRad)).toFloat()
                    val rect = RectF(-18f, mouthY - 8f, 18f, mouthY + 14f * openPulse)
                    canvas.drawArc(rect, 0f, 180f, true, mouthFill)
                    canvas.drawRect(RectF(-14f, mouthY - 1f, 14f, mouthY + 4f), teethFill)
                    canvas.drawOval(RectF(-9f, mouthY + 5f * openPulse, 9f, mouthY + 13f * openPulse), tongueFill)
                    canvas.drawArc(rect, 0f, 180f, true, stroke)
                }
                MouthPhoneme.CRYING -> {
                    val sobPulse = 1f + 0.18f * sin(emotionCycleRad).toFloat()
                    val tremble = sin(emotionCycleRad * 2.0).toFloat() * 1.4f
                    val cryRect = RectF(-15f, mouthY - 4f + tremble, 15f, mouthY + 15f * sobPulse + tremble)
                    canvas.drawArc(cryRect, 180f, 180f, true, mouthFill)
                    canvas.drawArc(cryRect, 180f, 180f, true, stroke)
                }
                MouthPhoneme.ANGRY_SHOUT -> {
                    val shoutPulse = 1f + 0.16f * kotlin.math.abs(sin(emotionCycleRad * 1.4)).toFloat()
                    val angryRect = RectF(-16f, mouthY - 7f * shoutPulse, 16f, mouthY + 11f * shoutPulse)
                    canvas.drawRoundRect(angryRect, 6f, 6f, mouthFill)
                    canvas.drawRect(RectF(-12f, mouthY - 6f * shoutPulse, 12f, mouthY - 1f), teethFill)
                    canvas.drawRect(RectF(-11f, mouthY + 5f * shoutPulse, 11f, mouthY + 9f * shoutPulse), teethFill)
                    canvas.drawRoundRect(angryRect, 6f, 6f, stroke)
                }
                MouthPhoneme.SCARED -> {
                    val shake = sin(emotionCycleRad * 2.4).toFloat() * 2f
                    val scaredRect = RectF(-13f, mouthY - 9f + shake, 13f, mouthY + 13f + shake)
                    canvas.drawRoundRect(scaredRect, 8f, 8f, mouthFill)
                    canvas.drawRect(RectF(-9f, mouthY - 7f + shake, 9f, mouthY - 2f + shake), teethFill)
                    canvas.drawRect(RectF(-9f, mouthY + 6f + shake, 9f, mouthY + 10f + shake), teethFill)
                    canvas.drawRoundRect(scaredRect, 8f, 8f, stroke)
                }
                MouthPhoneme.HALF_OPEN -> {
                    canvas.drawOval(RectF(-12f, mouthY - 4.5f, 12f, mouthY + 6.5f), mouthFill)
                    canvas.drawLine(-9f, mouthY - 1.5f, 9f, mouthY - 1.5f, Paint(stroke).apply { color = Color.WHITE; strokeWidth = 2.6f })
                    canvas.drawOval(RectF(-12f, mouthY - 4.5f, 12f, mouthY + 6.5f), stroke)
                }
                MouthPhoneme.REST -> {
                    canvas.drawArc(RectF(-12f, mouthY - 5f, 12f, mouthY + 6f), 15f, 150f, false, stroke)
                }
                MouthPhoneme.SMILE -> {
                    canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 12f), 0f, 180f, true, teethFill)
                    canvas.drawArc(RectF(-16f, mouthY - 8f, 16f, mouthY + 12f), 0f, 180f, true, stroke)
                }
                MouthPhoneme.A -> {
                    canvas.drawOval(RectF(-14f, mouthY - 8f, 14f, mouthY + 14f), mouthFill)
                    canvas.drawRect(RectF(-10f, mouthY - 7f, 10f, mouthY - 2f), teethFill)
                    canvas.drawOval(RectF(-14f, mouthY - 8f, 14f, mouthY + 14f), stroke)
                }
                MouthPhoneme.E -> {
                    canvas.drawRoundRect(RectF(-16f, mouthY - 5f, 16f, mouthY + 7f), 6f, 6f, mouthFill)
                    canvas.drawLine(-13f, mouthY, 13f, mouthY, Paint(stroke).apply { color = Color.WHITE; strokeWidth = 3f })
                    canvas.drawRoundRect(RectF(-16f, mouthY - 5f, 16f, mouthY + 7f), 6f, 6f, stroke)
                }
                MouthPhoneme.I -> {
                    canvas.drawRoundRect(RectF(-14f, mouthY - 4f, 14f, mouthY + 4f), 4f, 4f, teethFill)
                    canvas.drawRoundRect(RectF(-14f, mouthY - 4f, 14f, mouthY + 4f), 4f, 4f, stroke)
                }
                MouthPhoneme.O -> {
                    canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), mouthFill)
                    canvas.drawOval(RectF(-9f, mouthY - 8f, 9f, mouthY + 11f), stroke)
                }
                MouthPhoneme.U -> {
                    canvas.drawCircle(0f, mouthY + 1f, 6.5f, mouthFill)
                    canvas.drawCircle(0f, mouthY + 1f, 6.5f, stroke)
                }
                MouthPhoneme.SHOCK -> {
                    canvas.drawOval(RectF(-12f, mouthY - 11f, 12f, mouthY + 15f), mouthFill)
                    canvas.drawOval(RectF(-12f, mouthY - 11f, 12f, mouthY + 15f), stroke)
                }
                else -> {
                    canvas.drawArc(RectF(-12f, mouthY - 5f, 12f, mouthY + 6f), 15f, 150f, false, stroke)
                }
            }
        }
        // Module 5: Separate Same-Size Alignment Guide Box for Mouth (editor only)
        if (showAlignmentGuides && tintColorArgb == null) {
            val mouthGuide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFBBF24.toInt()
                style = Paint.Style.STROKE
                strokeWidth = 2f
                pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            }
            canvas.drawRect(RectF(-22f, mouthY - 14f, 22f, mouthY + 16f), mouthGuide)
        }
        canvas.restore()
        canvas.restore()
    }

    fun drawCharacter(
        canvas: Canvas,
        c: CharacterSpec,
        layerAlpha: Float,
        tintColorArgb: Long?,
        frame: Int = 0,
        fps: Int = 24,
        audioTracks: List<AudioTrackItem> = emptyList()
    ) {
        val alphaInt = (layerAlpha * 255).toInt().coerceIn(0, 255)
        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 4.5f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        canvas.save()
        canvas.translate(c.x, c.y)
        val viewAngle = runCatching { CharacterViewAngle.valueOf(c.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val isBack = viewAngle == CharacterViewAngle.BACK
        val sideFlipX = if (viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.BACK_LEFT_34) -1f else 1f
        canvas.scale(c.scale * c.baseScaleX.coerceIn(0.1f, 5.0f) * sideFlipX, c.scale * c.baseScaleY.coerceIn(0.1f, 5.0f))

        val legSpread = when (c.pose) {
            "WALK_A" -> 34f; "WALK_B" -> -34f; "JUMP" -> 42f; "HERO" -> 28f; else -> 18f
        }
        val bodyBob = when (c.pose) {
            "JUMP" -> -36f; "SIT" -> 28f; "WALK_A", "WALK_B" -> -6f; else -> 0f
        }
        canvas.translate(0f, bodyBob)

        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((alphaInt * 0.28f).toInt(), 0, 0, 0)
        }
        canvas.drawOval(RectF(-58f, 152f - bodyBob, 58f, 174f - bodyBob), shadowPaint)

        val pantsPaint = pFill(c.pantsColorArgb)
        val shirtPaint = pFill(c.shirtColorArgb)
        val skinPaint = pFill(c.skinToneArgb)
        val dupattaPaint = pFill(c.dupattaColorArgb)
        val leftArmAngle = when (c.pose) { "JUMP" -> -140f; "HERO" -> -25f; "WALK_A" -> 28f; "WALK_B" -> -28f; else -> 18f }
        val rightArmAngle = when (c.pose) { "WAVE" -> -135f; "JUMP" -> 140f; "HERO" -> 25f; "WALK_A" -> -28f; "WALK_B" -> 28f; else -> -18f }

        val torsoHalfW = (if (isSide) 28f else if (isFront34 || isBack34) 36f else 42f) * c.shoulderWidth.coerceIn(0.7f, 1.5f)
        val bellyExtra = c.bellyPlumpness.coerceIn(0f, 1f) * 20f
        val torsoHScale = c.torsoScale.coerceIn(0.75f, 1.4f)

        if (c.shirtStyle == "CAPE" && !isBack && !isBack34) {
            val capePath = if (isSide) {
                Path().apply { moveTo(-24f, -4f); lineTo(4f, -4f); lineTo(-14f, 118f); lineTo(-58f, 118f); close() }
            } else {
                Path().apply { moveTo(-36f, -6f); lineTo(36f, -6f); lineTo(66f, 118f); lineTo(-66f, 118f); close() }
            }
            canvas.drawPath(capePath, shirtPaint); canvas.drawPath(capePath, outline)
        }

        if (isSide) {
            // Far arm behind torso
            canvas.save()
            canvas.translate(8f, 6f); canvas.rotate(-leftArmAngle)
            canvas.drawRoundRect(RectF(-10f, 0f, 10f, 66f), 10f, 10f, shirtPaint)
            canvas.drawRoundRect(RectF(-10f, 0f, 10f, 66f), 10f, 10f, outline)
            canvas.drawCircle(0f, 68f, 10f, skinPaint); canvas.drawCircle(0f, 68f, 10f, outline)
            canvas.restore()

            val legFar = RectF(-14f - legSpread * 0.45f, 68f, 10f - legSpread * 0.25f, if (c.pose == "SIT") 124f else 156f)
            val legNear = RectF(-8f + legSpread * 0.25f, 68f, 16f + legSpread * 0.45f, if (c.pose == "SIT") 124f else 156f)
            canvas.drawRoundRect(legFar, 12f, 12f, pantsPaint); canvas.drawRoundRect(legFar, 12f, 12f, outline)
            canvas.drawRoundRect(legNear, 12f, 12f, pantsPaint); canvas.drawRoundRect(legNear, 12f, 12f, outline)

            val torso = RectF(-torsoHalfW, -14f * torsoHScale, torsoHalfW + bellyExtra, 82f * torsoHScale)
            canvas.drawRoundRect(torso, 22f, 22f, shirtPaint); canvas.drawRoundRect(torso, 22f, 22f, outline)
            drawTraditionalTorsoDetails(canvas, c, torso, shirtPaint, pantsPaint, dupattaPaint, outline, isBack = false)

            canvas.save()
            canvas.translate(-4f, 6f); canvas.rotate(rightArmAngle)
            canvas.drawRoundRect(RectF(-11f, 0f, 11f, 68f), 10f, 10f, shirtPaint)
            canvas.drawRoundRect(RectF(-11f, 0f, 11f, 68f), 10f, 10f, outline)
            canvas.drawCircle(0f, 70f, 10.5f, skinPaint); canvas.drawCircle(0f, 70f, 10.5f, outline)
            canvas.restore()
        } else {
            val legL = RectF(-30f - legSpread * 0.4f, 68f, -6f - legSpread * 0.2f, if (c.pose == "SIT") 124f else 156f)
            val legR = RectF(6f + legSpread * 0.2f, 68f, 30f + legSpread * 0.4f, if (c.pose == "SIT") 124f else 156f)
            if (c.shirtStyle == "SAREE" || c.shirtStyle == "PANJABI_DHOTI" || c.shirtStyle == "VILLAGE_GHOST") {
                val drapeRect = RectF(-36f - bellyExtra * 0.4f, 64f, 36f + bellyExtra * 0.4f, 152f)
                canvas.drawRoundRect(drapeRect, 14f, 14f, pantsPaint)
                canvas.drawRoundRect(drapeRect, 14f, 14f, outline)
                // Pleat line
                canvas.drawLine(0f, 68f, 0f, 150f, outline)
            } else {
                canvas.drawRoundRect(legL, 12f, 12f, pantsPaint); canvas.drawRoundRect(legL, 12f, 12f, outline)
                canvas.drawRoundRect(legR, 12f, 12f, pantsPaint); canvas.drawRoundRect(legR, 12f, 12f, outline)
            }

            val torso = RectF(-torsoHalfW - bellyExtra * 0.5f, -14f * torsoHScale, torsoHalfW + bellyExtra * 0.5f, 82f * torsoHScale)
            canvas.drawRoundRect(torso, 24f + bellyExtra * 0.4f, 24f + bellyExtra * 0.4f, shirtPaint)
            canvas.drawRoundRect(torso, 24f + bellyExtra * 0.4f, 24f + bellyExtra * 0.4f, outline)
            drawTraditionalTorsoDetails(canvas, c, torso, shirtPaint, pantsPaint, dupattaPaint, outline, isBack = isBack || isBack34)
            if (c.customCodePaths.isNotEmpty()) {
                canvas.save()
                canvas.translate(0f, torso.centerY())
                drawCustomCodePaths(canvas, c.customCodePaths, "TORSO", alphaInt, tintColorArgb)
                canvas.restore()
            }

            listOf(Triple(-torsoHalfW, leftArmAngle, 1f), Triple(torsoHalfW, rightArmAngle, 1f)).forEach { (ax, ang, _) ->
                canvas.save()
                canvas.translate(ax, 4f); canvas.rotate(ang)
                canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, shirtPaint)
                canvas.drawRoundRect(RectF(-12f, 0f, 12f, 68f), 11f, 11f, outline)
                if (c.hasBangles) {
                    val bPaint = pFill(c.banglesColorArgb)
                    canvas.drawRect(-12f, 52f, 12f, 57f, bPaint)
                    canvas.drawRect(-12f, 58f, 12f, 62f, bPaint)
                }
                canvas.drawCircle(0f, 70f, 11f, skinPaint); canvas.drawCircle(0f, 70f, 11f, outline)
                canvas.restore()
            }

            if ((isBack || isBack34) && c.shirtStyle == "CAPE") {
                val capePath = Path().apply {
                    moveTo(-38f, -8f); lineTo(38f, -8f); lineTo(62f, 124f); lineTo(-62f, 124f); close()
                }
                canvas.drawPath(capePath, shirtPaint); canvas.drawPath(capePath, outline)
            }
            if ((isBack || isBack34) && c.shirtStyle == "HOODIE") {
                canvas.drawArc(RectF(-30f, -20f, 30f, 28f), 0f, 180f, true, shirtPaint)
                canvas.drawArc(RectF(-30f, -20f, 30f, 28f), 0f, 180f, true, outline)
            }
        }

        // Clean Neck tucked cleanly under lower chin/jawline above torso & shirt collar (zero gap!)
        val neckRect = RectF(-12f, -34f * torsoHScale, 12f, -6f * torsoHScale)
        canvas.drawRoundRect(neckRect, 8f, 8f, skinPaint)
        canvas.drawRoundRect(neckRect, 8f, 8f, outline)

        // Head Group ALWAYS rendered LAST / TOPMOST above neck, shirt collar, chest, shoulders & limbs!
        canvas.save()
        canvas.translate(0f, -66f * torsoHScale)
        drawHeadSculpt(canvas, c, skinPaint, pFill(c.hairColorArgb), outline, alphaInt, tintColorArgb, frame, fps, audioTracks, viewAngle)
        canvas.restore()

        canvas.restore()
    }

    private fun drawTraditionalTorsoDetails(
        canvas: Canvas,
        c: CharacterSpec,
        torso: RectF,
        shirtPaint: Paint,
        pantsPaint: Paint,
        dupattaPaint: Paint,
        outline: Paint,
        isBack: Boolean
    ) {
        when (c.shirtStyle) {
            "SAREE" -> {
                // Diagonal Saree Pallu / Anchhal drape across chest or back
                val pallu = Path().apply {
                    if (isBack) {
                        moveTo(torso.left + 8f, torso.top + 4f)
                        lineTo(torso.left + 32f, torso.top + 4f)
                        lineTo(torso.right - 8f, torso.bottom + 26f)
                        lineTo(torso.right - 34f, torso.bottom + 26f)
                    } else {
                        moveTo(torso.left + 6f, torso.top + 4f)
                        lineTo(torso.left + 30f, torso.top + 4f)
                        lineTo(torso.right - 4f, torso.bottom)
                        lineTo(torso.right - 28f, torso.bottom)
                    }
                    close()
                }
                canvas.drawPath(pallu, dupattaPaint)
                canvas.drawPath(pallu, outline)
            }
            "SALWAR_KAMEEZ" -> {
                // U-drape Dupatta scarf across shoulders
                val dup = Path().apply {
                    moveTo(torso.left + 6f, torso.top + 4f)
                    quadTo(torso.centerX(), torso.bottom - 14f, torso.right - 6f, torso.top + 4f)
                }
                val dupStroke = Paint(dupattaPaint).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 14f
                    strokeCap = Paint.Cap.ROUND
                }
                canvas.drawPath(dup, dupStroke)
            }
            "PANJABI_DHOTI", "KURTA_PAJAMA" -> {
                // Classic Kurta / Panjabi placket & collar border + longer hem
                val hemRect = RectF(torso.left - 3f, torso.bottom - 10f, torso.right + 3f, torso.bottom + 22f)
                canvas.drawRoundRect(hemRect, 10f, 10f, shirtPaint)
                canvas.drawRoundRect(hemRect, 10f, 10f, outline)
                if (!isBack) {
                    canvas.drawLine(torso.centerX(), torso.top + 4f, torso.centerX(), torso.centerY() + 6f, outline)
                    canvas.drawCircle(torso.centerX(), torso.top + 18f, 3f, dupattaPaint)
                    canvas.drawCircle(torso.centerX(), torso.top + 32f, 3f, dupattaPaint)
                }
                if (c.shirtStyle == "PANJABI_DHOTI") {
                    // Folded Uttariyo / Zamindar shawl over shoulder
                    val shawl = RectF(torso.left + 4f, torso.top + 2f, torso.left + 22f, torso.bottom + 14f)
                    canvas.drawRoundRect(shawl, 6f, 6f, dupattaPaint)
                    canvas.drawRoundRect(shawl, 6f, 6f, outline)
                }
            }
            "TANTRIK_ROBE" -> {
                // Rudraksha bead mala necklace
                for (i in -3..3) {
                    val mx = torso.centerX() + i * 9f
                    val my = torso.top + 24f + (12f - kotlin.math.abs(i) * 3.5f)
                    canvas.drawCircle(mx, my, 4.5f, dupattaPaint)
                    canvas.drawCircle(mx, my, 4.5f, outline)
                }
            }
            "VILLAGE_GHOST" -> {
                // Tattered spectral hem strips
                val ragged = Path().apply {
                    moveTo(torso.left, torso.bottom - 4f)
                    lineTo(torso.left - 8f, torso.bottom + 26f)
                    lineTo(torso.centerX() - 12f, torso.bottom + 12f)
                    lineTo(torso.centerX(), torso.bottom + 32f)
                    lineTo(torso.centerX() + 14f, torso.bottom + 12f)
                    lineTo(torso.right + 8f, torso.bottom + 24f)
                    lineTo(torso.right, torso.bottom - 4f)
                    close()
                }
                canvas.drawPath(ragged, shirtPaint)
            }
        }
    }

    /**
     * Computes 2.5D cylindrical hair parallax shifts `(frontHairShiftX, backHairShiftX)` in local head space
     * (where `+X` is always the turned face direction after horizontal view mirroring).
     * - Front-L / Front-R 3/4: Front hair shifts `+12px` with eyes/nose; Back hair shifts `-6px` opposite for 3D skull volume.
     * - Dynamic `headTurn25D` adds smooth cylindrical counter-parallax.
     */
    fun computeHairParallaxOffsets(
        viewAngle: CharacterViewAngle,
        headTurn25D: Float = 0f
    ): Pair<Float, Float> {
        val turn = headTurn25D.coerceIn(-1f, 1f)
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val frontShiftX = when {
            isFront34 -> 12f + turn * 10f
            isBack34 -> 8f + turn * 6f
            else -> turn * 10f
        }
        val backShiftX = when {
            isFront34 -> -6f - turn * 6f
            isBack34 -> -10f - turn * 5f
            else -> -turn * 6f
        }
        return frontShiftX to backShiftX
    }

    private fun drawHeadSculpt(
        canvas: Canvas,
        c: CharacterSpec,
        skinPaint: Paint,
        hairPaint: Paint,
        outline: Paint,
        alphaInt: Int,
        tintColorArgb: Long?,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        viewAngle: CharacterViewAngle = CharacterViewAngle.FRONT,
        eyebrowStyleName: String = EyebrowStyle.NORMAL.name,
        customEyeSlots: Map<String, String> = emptyMap(),
        customMouthSlots: Map<String, String> = emptyMap(),
        facialTiming: FacialTimingConfig = FacialTimingConfig(),
        faceTransform: ResolvedFaceTransform? = null,
        rig: SkeletalRig? = null,
        puppetRoot: EvaluatedPuppetRoot? = null,
        showAlignmentGuides: Boolean = false
    ) {
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val isBack = viewAngle == CharacterViewAngle.BACK
        val headTurn25D = (puppetRoot?.headTurn25D ?: rig?.headTurn25D ?: 0f).coerceIn(-1f, 1f)
        val (frontHairShiftX, backHairShiftX) = computeHairParallaxOffsets(viewAngle, headTurn25D)

        val headRect = when {
            isSide -> RectF(-42f, -56f, 44f, 52f)
            isFront34 || isBack34 -> RectF(-46f, -56f, 46f, 52f)
            c.faceShape == "ROUND" -> RectF(-54f, -56f, 54f, 52f)
            c.faceShape == "SQUARE" -> RectF(-50f, -56f, 50f, 52f)
            c.faceShape == "CHIBI" -> RectF(-60f, -62f, 60f, 54f)
            else -> RectF(-48f, -58f, 48f, 52f)
        }
        val r = if (c.faceShape == "SQUARE") 20f else 50f

        fun drawTraditionalBackHair(shiftX: Float) {
            when (c.hairStyle) {
                "BRAID_BENI" -> {
                    for (seg in 0..4) {
                        val cy = 36f + seg * 20f
                        val sw = (17f - seg * 1.8f).coerceAtLeast(7f)
                        canvas.drawOval(RectF(shiftX - sw, cy - 12f, shiftX + sw, cy + 12f), hairPaint)
                        canvas.drawOval(RectF(shiftX - sw, cy - 12f, shiftX + sw, cy + 12f), outline)
                    }
                    val rib = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFDC2626.toInt(); alpha = alphaInt }
                    canvas.drawRoundRect(RectF(shiftX - 10f, 118f, shiftX + 10f, 128f), 4f, 4f, rib)
                }
                "TRADITIONAL_BUN" -> {
                    canvas.drawCircle(shiftX, 22f, 25f, hairPaint)
                    canvas.drawCircle(shiftX, 22f, 25f, outline)
                    val gajra = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFFFFFBF0.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; alpha = alphaInt
                    }
                    canvas.drawArc(RectF(shiftX - 23f, 0f, shiftX + 23f, 44f), 200f, 140f, false, gajra)
                }
                "SAGE_JATA" -> {
                    canvas.drawCircle(shiftX, -70f, 22f, hairPaint)
                    canvas.drawCircle(shiftX, -70f, 22f, outline)
                    canvas.drawRoundRect(RectF(shiftX - 42f, -10f, shiftX + 42f, 76f), 18f, 18f, hairPaint)
                }
                "LONG_GHOST" -> {
                    val hairFlow = Path().apply {
                        moveTo(headRect.left - 8f + shiftX * 0.4f, -14f)
                        lineTo(headRect.left - 18f + shiftX * 0.6f, 116f)
                        lineTo(headRect.centerX() - 16f + shiftX * 0.5f, 96f)
                        lineTo(headRect.centerX() + shiftX * 0.5f, 124f)
                        lineTo(headRect.centerX() + 18f + shiftX * 0.5f, 98f)
                        lineTo(headRect.right + 16f + shiftX * 0.4f, 114f)
                        lineTo(headRect.right + 8f + shiftX * 0.4f, -14f)
                        close()
                    }
                    canvas.drawPath(hairFlow, hairPaint)
                    canvas.drawPath(hairFlow, outline)
                }
            }
        }

        // =========================================================================
        // PASS 1 (BEHIND HEAD BASE SHAPE): Back Hair Silhouette with 2.5D Depth Shift!
        // =========================================================================
        if (!isBack && !isBack34) {
            canvas.save()
            canvas.translate(backHairShiftX, 0f)
            if (isSide) {
                // Authentic side-profile occipital / back-of-skull hair mass curving smoothly behind head
                val sideBackPath = Path().apply {
                    moveTo(-6f, headRect.top - 10f)
                    cubicTo(-54f, headRect.top - 8f, -64f, -14f, -54f, 26f)
                    cubicTo(-48f, 48f, -26f, 52f, -14f, 42f)
                    lineTo(-10f, -10f)
                    close()
                }
                canvas.drawPath(sideBackPath, hairPaint)
                canvas.drawPath(sideBackPath, outline)
            }
            when (c.hairStyle) {
                "LONG_GHOST" -> {
                    drawTraditionalBackHair(if (isSide) -18f else 0f)
                }
                "BRAID_BENI" -> {
                    val bx = if (isSide) -42f else if (isFront34) -44f else -42f
                    for (seg in 0..3) {
                        canvas.drawOval(RectF(bx - 12f, 20f + seg * 18f, bx + 12f, 38f + seg * 18f), hairPaint)
                        canvas.drawOval(RectF(bx - 12f, 20f + seg * 18f, bx + 12f, 38f + seg * 18f), outline)
                    }
                }
                "TRADITIONAL_BUN" -> {
                    val bx = if (isSide) -56f else if (isFront34) -46f else 0f
                    val by = if (isSide || isFront34) 8f else -68f
                    canvas.drawCircle(bx, by, 21f, hairPaint)
                    canvas.drawCircle(bx, by, 21f, outline)
                }
                "SAGE_JATA" -> {
                    canvas.drawCircle(if (isSide) -12f else 0f, -72f, 22f, hairPaint)
                    canvas.drawCircle(if (isSide) -12f else 0f, -72f, 22f, outline)
                    canvas.drawRoundRect(RectF(headRect.left - 12f, -16f, headRect.right + 8f, 64f), 20f, 20f, hairPaint)
                }
                "PONYTAIL" -> {
                    val ponyRect = if (isSide) {
                        RectF(-82f, -38f, -34f, 24f)
                    } else if (isFront34) {
                        RectF(-78f, -44f, -34f, 18f)
                    } else {
                        RectF(36f, -54f, 82f, 6f)
                    }
                    canvas.drawOval(ponyRect, hairPaint)
                    canvas.drawOval(ponyRect, outline)
                }
                "BOB" -> {
                    if (isSide) {
                        canvas.drawRoundRect(RectF(-56f, -30f, -14f, 52f), 16f, 16f, hairPaint)
                        canvas.drawRoundRect(RectF(-56f, -30f, -14f, 52f), 16f, 16f, outline)
                    } else {
                        canvas.drawRoundRect(RectF(headRect.left - 12f, -26f, headRect.right + 12f, 48f), 18f, 18f, hairPaint)
                        canvas.drawRoundRect(RectF(headRect.left - 12f, -26f, headRect.right + 12f, 48f), 18f, 18f, outline)
                    }
                }
                "CURLY" -> {
                    val leftEnd = if (isSide) -52f else headRect.left - 8f
                    val rightEnd = if (isSide) -12f else headRect.right + 8f
                    canvas.drawCircle(leftEnd, -24f, 20f, hairPaint)
                    canvas.drawCircle(leftEnd, -24f, 20f, outline)
                    if (!isSide) {
                        canvas.drawCircle(rightEnd, -24f, 20f, hairPaint)
                        canvas.drawCircle(rightEnd, -24f, 20f, outline)
                    }
                }
                "SPIKY" -> {
                    // Subtle back-crown silhouette behind head that shifts opposite to face turn in 3/4
                    val backCrown = Path().apply {
                        moveTo(headRect.left - 6f, -12f)
                        lineTo(headRect.left - 16f, -50f)
                        lineTo(headRect.centerX(), -68f)
                        lineTo(headRect.right + 12f, -46f)
                        lineTo(headRect.right + 4f, -12f)
                        close()
                    }
                    canvas.drawPath(backCrown, hairPaint)
                    canvas.drawPath(backCrown, outline)
                }
            }
            canvas.restore()
        }

        // =========================================================================
        // PASS 2: Head Base Shape (Skin Tone + Silhouette)
        // =========================================================================
        if (isSide) {
            val nosePath = Path().apply {
                moveTo(38f, -10f); lineTo(54f, 4f); lineTo(40f, 12f); close()
            }
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawPath(nosePath, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
            canvas.drawPath(nosePath, outline)
        } else if (isBack34) {
            val cheekProfile = Path().apply {
                moveTo(36f, -20f)
                quadTo(52f, -2f, 44f, 24f)
                quadTo(34f, 42f, 18f, 46f)
                close()
            }
            canvas.drawPath(cheekProfile, skinPaint)
            canvas.drawPath(cheekProfile, outline)
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
        } else if (isFront34) {
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
            val nose34 = Path().apply { moveTo(18f, -6f); lineTo(28f, 5f); lineTo(18f, 11f) }
            canvas.drawPath(nose34, outline)
        } else {
            canvas.drawRoundRect(headRect, r, r, skinPaint)
            canvas.drawRoundRect(headRect, r, r, outline)
        }

        // =========================================================================
        // PASS 3: Face Features (Eyes 3-Layer, Eyebrows, Nose, Mouth, Bindi, Facial Hair)
        //         AND PASS 4: Front Hair / Fringe / Sideburns (OVER Upper Forehead!)
        // =========================================================================
        if (isBack || isBack34) {
            // Full Back-of-Head Hair completely covering the back of the head (3/4 Back leaves slight cheek edge)
            val backHairRect = if (isBack34) {
                RectF(headRect.left - 7f, headRect.top - 9f, headRect.right - 12f, headRect.bottom - 2f)
            } else {
                RectF(headRect.left - 6f, headRect.top - 9f, headRect.right + 6f, headRect.bottom + 2f)
            }
            canvas.drawRoundRect(backHairRect, 48f, 48f, hairPaint)
            canvas.drawRoundRect(backHairRect, 48f, 48f, outline)
            val backCenterX = if (isBack34) -12f else 0f
            drawTraditionalBackHair(backCenterX)
            when (c.hairStyle) {
                "SPIKY" -> {
                    val spikes = Path().apply {
                        moveTo(-54f, -14f); lineTo(-66f, -58f); lineTo(-34f, -52f)
                        lineTo(-20f, -86f); lineTo(0f, -62f); lineTo(22f, -84f)
                        lineTo(36f, -52f); lineTo(66f, -58f); lineTo(54f, -14f); close()
                    }
                    canvas.drawPath(spikes, hairPaint); canvas.drawPath(spikes, outline)
                }
                "PONYTAIL" -> {
                    canvas.drawOval(RectF(backCenterX - 22f, -12f, backCenterX + 22f, 66f), hairPaint)
                    canvas.drawOval(RectF(backCenterX - 22f, -12f, backCenterX + 22f, 66f), outline)
                }
                "CURLY" -> {
                    for (i in -2..2) {
                        canvas.drawCircle(i * 22f, -54f + kotlin.math.abs(i) * 6f, 22f, hairPaint)
                        canvas.drawCircle(i * 22f, -54f + kotlin.math.abs(i) * 6f, 22f, outline)
                    }
                }
                "MOHAWK" -> {
                    val mohawk = Path().apply {
                        moveTo(-16f, -52f); lineTo(-22f, -94f); lineTo(0f, -82f); lineTo(22f, -94f); lineTo(16f, -52f); close()
                    }
                    canvas.drawPath(mohawk, hairPaint); canvas.drawPath(mohawk, outline)
                }
            }
            if (isBack34) {
                val peekTf = faceTransform
                canvas.save()
                if (peekTf != null) {
                    canvas.translate(peekTf.offsetX, peekTf.offsetY)
                    canvas.rotate(peekTf.rotationDeg)
                    canvas.scale(peekTf.scaleX, peekTf.scaleY)
                } else {
                    canvas.translate(34f, 0f)
                    canvas.scale(0.42f, 0.92f)
                }
                drawModularFaceRig(
                    canvas = canvas,
                    eyePackName = c.eyePack,
                    mouthPhonemeName = c.mouthPhoneme,
                    eyeColorArgb = c.eyeColorArgb,
                    frame = frame,
                    fps = fps,
                    audioTracks = audioTracks,
                    alphaInt = (alphaInt * 0.84f).toInt(),
                    tintColorArgb = tintColorArgb,
                    isSideProfile = true,
                    eyebrowStyleName = eyebrowStyleName,
                    customEyeSlots = customEyeSlots,
                    customMouthSlots = customMouthSlots,
                    facialTiming = facialTiming,
                    faceTransform = peekTf
                )
                canvas.restore()
            }
        } else {
            // PASS 3: Face Features (Eyes, Brows, Nose, Mouth, Bindi, Facial Hair)
            canvas.save()
            if (faceTransform != null) {
                canvas.translate(faceTransform.offsetX, faceTransform.offsetY)
                canvas.rotate(faceTransform.rotationDeg)
                canvas.scale(faceTransform.scaleX, faceTransform.scaleY)
            } else {
                if (isFront34) {
                    canvas.translate(12f, 0f)
                    canvas.scale(0.86f, 1f)
                }
            }
            drawModularFaceRig(
                canvas = canvas,
                eyePackName = c.eyePack,
                mouthPhonemeName = c.mouthPhoneme,
                eyeColorArgb = c.eyeColorArgb,
                frame = frame,
                fps = fps,
                audioTracks = audioTracks,
                alphaInt = alphaInt,
                tintColorArgb = tintColorArgb,
                isSideProfile = faceTransform?.isSideProfile ?: isSide,
                eyebrowStyleName = eyebrowStyleName,
                customEyeSlots = customEyeSlots,
                customMouthSlots = customMouthSlots,
                facialTiming = facialTiming,
                faceTransform = faceTransform,
                rig = rig,
                puppetRoot = puppetRoot,
                showAlignmentGuides = showAlignmentGuides
            )

            if (c.hasBindi) {
                val bindiP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = (tintColorArgb ?: c.bindiColorArgb).toInt()
                    alpha = alphaInt
                }
                val bx = if (isSide) 34f else 0f
                canvas.drawCircle(bx, -23f, 5.2f, bindiP)
            }

            val mx = if (isSide) 24f else 0f
            when (c.facialHair) {
                "MUSTACHE" -> {
                    val m = Path().apply {
                        moveTo(mx, 10f); quadTo(mx - 16f, 6f, mx - 24f, 16f)
                        quadTo(mx - 10f, 18f, mx, 14f)
                        quadTo(mx + 10f, 18f, mx + 24f, 16f)
                        quadTo(mx + 16f, 6f, mx, 10f); close()
                    }
                    canvas.drawPath(m, hairPaint); canvas.drawPath(m, outline)
                }
                "THICK_MUSTACHE" -> {
                    val m = Path().apply {
                        moveTo(mx, 8f); quadTo(mx - 18f, 2f, mx - 34f, 16f)
                        quadTo(mx - 26f, 24f, mx - 14f, 19f)
                        lineTo(mx, 16f)
                        lineTo(mx + 14f, 19f)
                        quadTo(mx + 26f, 24f, mx + 34f, 16f)
                        quadTo(mx + 18f, 2f, mx, 8f); close()
                    }
                    canvas.drawPath(m, hairPaint); canvas.drawPath(m, outline)
                }
                "SAGE_BEARD", "ROYAL_BEARD" -> {
                    val len = if (c.facialHair == "SAGE_BEARD") 68f else 48f
                    val beard = Path().apply {
                        moveTo(mx - 34f, 14f)
                        quadTo(mx - 30f, len, mx, len + 12f)
                        quadTo(mx + 30f, len, mx + 34f, 14f)
                        quadTo(mx, 28f, mx - 34f, 14f)
                        close()
                    }
                    canvas.drawPath(beard, hairPaint); canvas.drawPath(beard, outline)
                }
            }
            canvas.restore()

            // =========================================================================
            // PASS 4 (OVER UPPER FOREHEAD AFTER FACE FEATURES):
            // Front Hair / Fringe / Bangs / Sideburns with True 2.5D Parallax & Profile Turn!
            // =========================================================================
            canvas.save()
            val frontScaleX = if (isFront34) 0.92f else 1f
            if (!isSide) {
                canvas.translate(frontHairShiftX, 0f)
                canvas.scale(frontScaleX, 1f)
            } else {
                canvas.translate(headTurn25D * 4f, 0f)
            }

            if (c.hairStyle == "BRAID_BENI" || c.hairStyle == "TRADITIONAL_BUN" || c.hairStyle == "LONG_GHOST" || c.hairStyle == "SAGE_JATA") {
                if (isSide) {
                    // Authentic side-profile crown & sweeping sideburn/forehead wave (not a flat front cap)
                    val sideCrown = Path().apply {
                        moveTo(-46f, 16f)
                        cubicTo(-52f, -38f, -26f, -66f, 12f, -62f)
                        cubicTo(34f, -60f, 44f, -44f, 42f, -26f)
                        quadTo(16f, -34f, 2f, -14f)
                        quadTo(-8f, 6f, -16f, 20f)
                        quadTo(-30f, 24f, -46f, 16f)
                        close()
                    }
                    canvas.drawPath(sideCrown, hairPaint)
                    canvas.drawPath(sideCrown, outline)
                } else {
                    if (c.hairStyle == "LONG_GHOST") {
                        canvas.drawRoundRect(RectF(-54f, -30f, -36f, 68f), 11f, 11f, hairPaint)
                        canvas.drawRoundRect(RectF(34f, -30f, 52f, 68f), 11f, 11f, hairPaint)
                    }
                    // Classic parted hairline arch shifted with 2.5D front-hair parallax
                    canvas.drawArc(RectF(-50f, -66f, 50f, 10f), 185f, 170f, true, hairPaint)
                    canvas.drawArc(RectF(-50f, -66f, 50f, 10f), 185f, 170f, false, outline)
                }
            } else {
                when (c.hairStyle) {
                    "SPIKY" -> {
                        val spikes = if (isSide) {
                            // Authentic Side Profile: curved skull back, crown spikes, tapered forehead fringe & sideburn
                            Path().apply {
                                moveTo(-48f, 22f)
                                lineTo(-60f, -14f)
                                lineTo(-48f, -44f)
                                lineTo(-34f, -74f)
                                lineTo(-8f, -62f)
                                lineTo(18f, -80f)
                                lineTo(38f, -52f)
                                lineTo(50f, -28f)
                                quadTo(26f, -34f, 10f, -24f)
                                lineTo(-4f, -8f)
                                lineTo(-12f, 16f)
                                quadTo(-30f, 28f, -48f, 22f)
                                close()
                            }
                        } else {
                            Path().apply {
                                moveTo(-50f, -20f); lineTo(-60f, -58f); lineTo(-30f, -50f)
                                lineTo(-18f, -84f); lineTo(2f, -60f); lineTo(22f, -82f)
                                lineTo(34f, -50f); lineTo(60f, -56f); lineTo(50f, -20f)
                                quadTo(4f, -42f, -50f, -20f); close()
                            }
                        }
                        canvas.drawPath(spikes, hairPaint); canvas.drawPath(spikes, outline)
                    }
                    "BOB" -> {
                        if (isSide) {
                            // Side-profile bob: full curved back crown + diagonal temple fringe sweeping toward brow
                            val sideBob = Path().apply {
                                moveTo(-52f, 36f)
                                cubicTo(-58f, -26f, -36f, -68f, 8f, -66f)
                                cubicTo(36f, -64f, 48f, -44f, 44f, -22f)
                                quadTo(22f, -32f, 6f, -18f)
                                quadTo(-8f, 6f, -14f, 42f)
                                close()
                            }
                            canvas.drawPath(sideBob, hairPaint)
                            canvas.drawPath(sideBob, outline)
                        } else {
                            canvas.drawArc(RectF(-56f, -70f, 56f, 26f), 180f, 180f, true, hairPaint)
                            canvas.drawArc(RectF(-56f, -70f, 56f, 26f), 180f, 180f, false, outline)
                            // Front cheek framing bangs
                            canvas.drawRoundRect(RectF(-54f, -26f, -38f, 28f), 10f, 10f, hairPaint)
                            canvas.drawRoundRect(RectF(36f, -26f, 52f, 28f), 10f, 10f, hairPaint)
                        }
                    }
                    "PONYTAIL" -> {
                        if (isSide) {
                            val sidePonyCrown = Path().apply {
                                moveTo(-46f, 14f)
                                cubicTo(-52f, -38f, -24f, -68f, 14f, -64f)
                                cubicTo(36f, -60f, 44f, -42f, 42f, -24f)
                                quadTo(14f, -36f, -4f, -14f)
                                quadTo(-18f, 8f, -46f, 14f)
                                close()
                            }
                            canvas.drawPath(sidePonyCrown, hairPaint)
                            canvas.drawPath(sidePonyCrown, outline)
                        } else {
                            canvas.drawArc(RectF(-50f, -68f, 50f, 14f), 180f, 180f, true, hairPaint)
                            canvas.drawArc(RectF(-50f, -68f, 50f, 14f), 180f, 180f, false, outline)
                        }
                    }
                    "CURLY" -> {
                        if (isSide) {
                            // Side-profile curly crown wrapping back of skull + forehead curls
                            val curlCenters = listOf(-44f to -16f, -40f to -40f, -18f to -58f, 8f to -60f, 30f to -46f, 40f to -28f)
                            curlCenters.forEach { (cx, cy) ->
                                canvas.drawCircle(cx, cy, 19f, hairPaint)
                                canvas.drawCircle(cx, cy, 19f, outline)
                            }
                        } else {
                            for (i in -2..2) {
                                canvas.drawCircle(i * 21f, -56f + kotlin.math.abs(i) * 6f, 20f, hairPaint)
                                canvas.drawCircle(i * 21f, -56f + kotlin.math.abs(i) * 6f, 20f, outline)
                            }
                        }
                    }
                    "MOHAWK" -> {
                        val mohawk = if (isSide) {
                            Path().apply {
                                moveTo(-46f, 6f)
                                lineTo(-64f, -26f)
                                lineTo(-42f, -62f)
                                lineTo(-12f, -92f)
                                lineTo(24f, -84f)
                                lineTo(42f, -44f)
                                quadTo(8f, -52f, -28f, -24f)
                                close()
                            }
                        } else {
                            Path().apply {
                                moveTo(-16f, -52f); lineTo(-24f, -94f); lineTo(0f, -82f); lineTo(24f, -94f); lineTo(16f, -52f); close()
                            }
                        }
                        canvas.drawPath(mohawk, hairPaint); canvas.drawPath(mohawk, outline)
                    }
                }
            }
            canvas.restore()
        }

        // =========================================================================
        // PASS 5: Head Accessories (Glasses, Headphones, Crown, Hat) + Custom Code Paths
        // =========================================================================
        fun pAcc(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL; color = (tintColorArgb ?: argb).toInt(); alpha = alphaInt
        }
        when (c.accessory) {
            "GLASSES" -> if (!isBack && !isBack34) {
                val f = Paint(outline).apply { strokeWidth = 3.8f }
                val gShift = if (isFront34) 10f else 0f
                if (isSide) {
                    canvas.drawRoundRect(RectF(8f, -22f, 34f, 6f), 6f, 6f, f)
                    canvas.drawLine(-8f, -8f, 8f, -8f, f)
                } else {
                    canvas.drawRoundRect(RectF(-34f + gShift, -22f, -4f + gShift, 6f), 6f, 6f, f)
                    canvas.drawRoundRect(RectF(4f + gShift, -22f, 34f + gShift, 6f), 6f, 6f, f)
                    canvas.drawLine(-4f + gShift, -8f, 4f + gShift, -8f, f)
                }
            }
            "HEADPHONES" -> {
                canvas.drawArc(RectF(-56f, -72f, 56f, 22f), 180f, 180f, false, Paint(outline).apply {
                    color = (tintColorArgb ?: 0xFF2DD4BFL).toInt(); strokeWidth = 8f
                })
                if (isSide) {
                    canvas.drawRoundRect(RectF(-20f, -18f, 6f, 20f), 10f, 10f, pAcc(0xFF2DD4BFL))
                } else {
                    canvas.drawRoundRect(RectF(-68f, -22f, -50f, 14f), 8f, 8f, pAcc(0xFF2DD4BFL))
                    canvas.drawRoundRect(RectF(50f, -22f, 68f, 14f), 8f, 8f, pAcc(0xFF2DD4BFL))
                }
            }
            "CROWN", "ROYAL_CROWN" -> {
                val crown = Path().apply {
                    moveTo(-30f, -56f); lineTo(-36f, -92f); lineTo(-14f, -74f)
                    lineTo(0f, -104f); lineTo(14f, -74f); lineTo(36f, -92f); lineTo(30f, -56f); close()
                }
                canvas.drawPath(crown, pAcc(0xFFFBBF24L)); canvas.drawPath(crown, outline)
                canvas.drawCircle(0f, -70f, 5f, pAcc(0xFFEF4444L))
            }
            "HAT" -> {
                canvas.drawRoundRect(RectF(-58f, -58f, 58f, -44f), 6f, 6f, pAcc(0xFF334155L))
                canvas.drawRoundRect(RectF(-36f, -94f, 36f, -54f), 14f, 14f, pAcc(0xFF334155L))
                canvas.drawRoundRect(RectF(-58f, -58f, 58f, -44f), 6f, 6f, outline)
            }
        }

        if (c.customCodePaths.isNotEmpty()) {
            drawCustomCodePaths(canvas, c.customCodePaths, "HEAD", alphaInt, tintColorArgb)
        }
    }

    private fun drawCustomCodePaths(
        canvas: Canvas,
        paths: List<com.example.data.model.CodedVectorPath>,
        attachTarget: String,
        alphaInt: Int,
        tintColorArgb: Long?
    ) {
        paths.forEach { item ->
            if (!item.attachTo.equals(attachTarget, ignoreCase = true)) return@forEach
            val parsedPath = CharacterCodeParser.parseSvgPathData(item.d) ?: return@forEach
            val fillAlpha = ((item.fillColorArgb ushr 24) and 0xFF).toInt()
            if (fillAlpha > 0) {
                val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = (tintColorArgb ?: item.fillColorArgb).toInt()
                    alpha = ((fillAlpha * alphaInt) / 255).coerceIn(0, 255)
                }
                canvas.drawPath(parsedPath, fillP)
            }
            val strokeAlpha = ((item.strokeColorArgb ushr 24) and 0xFF).toInt()
            if (strokeAlpha > 0 && item.strokeWidth > 0.1f) {
                val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    color = (tintColorArgb ?: item.strokeColorArgb).toInt()
                    strokeWidth = item.strokeWidth
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                    alpha = ((strokeAlpha * alphaInt) / 255).coerceIn(0, 255)
                }
                canvas.drawPath(parsedPath, strokeP)
            }
        }
    }

    private fun drawPropRotationRing(
        canvas: Canvas,
        centerX: Float,
        centerY: Float,
        angleDeg: Float,
        label: String,
        isAttached: Boolean
    ) {
        val ringR = PRISMA_ROTATION_RING_RADIUS + 4f
        val accentColor = if (isAttached) 0xFF2DD4BFL else 0xFFFFD600L

        val backingRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xAA0A0F1C.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawCircle(centerX, centerY, ringR, backingRing)

        val mainRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 2.2f
        }
        canvas.drawCircle(centerX, centerY, ringR, mainRing)

        val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCFFFFFF.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 1.3f
            strokeCap = Paint.Cap.ROUND
        }
        for (deg in 0 until 360 step 30) {
            val rad = Math.toRadians(deg.toDouble())
            val isMajor = deg % 90 == 0
            val inner = ringR - (if (isMajor) 4.5f else 2.5f)
            val outer = ringR + (if (isMajor) 2.5f else 1.2f)
            canvas.drawLine(
                centerX + (cos(rad) * inner).toFloat(),
                centerY + (sin(rad) * inner).toFloat(),
                centerX + (cos(rad) * outer).toFloat(),
                centerY + (sin(rad) * outer).toFloat(),
                tickPaint
            )
        }

        val handleRad = Math.toRadians((angleDeg - 90f).toDouble())
        val handleX = centerX + (cos(handleRad) * ringR).toFloat()
        val handleY = centerY + (sin(handleRad) * ringR).toFloat()
        val spokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCC06B6D4.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
        }
        canvas.drawLine(centerX, centerY, handleX, handleY, spokePaint)

        val pivotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF06B6D4.toInt()
            style = Paint.Style.FILL
        }
        val whiteRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
        }
        canvas.drawCircle(centerX, centerY, 4.5f, pivotFill)
        canvas.drawCircle(centerX, centerY, 4.5f, whiteRing)

        val knobGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (accentColor and 0x00FFFFFFL or 0x55000000L).toInt()
            style = Paint.Style.FILL
        }
        val knobFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor.toInt()
            style = Paint.Style.FILL
        }
        val knobStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF0A0F1C.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
        }
        canvas.drawCircle(handleX, handleY, 8.5f, knobGlow)
        canvas.drawCircle(handleX, handleY, 4.5f, knobFill)
        canvas.drawCircle(handleX, handleY, 4.5f, knobStroke)

        val degInt = angleDeg.toInt()
        val signPrefix = if (degInt > 0) "+" else ""
        val badgeText = "${label.take(12)} $signPrefix${degInt}°"
        val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor.toInt()
            textSize = 14f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val bw = badgeTextPaint.measureText(badgeText) + 16f
        val by = (centerY - ringR - 18f).coerceAtLeast(24f)
        val badgeRect = RectF(centerX - bw / 2f, by - 11f, centerX + bw / 2f, by + 11f)
        val badgeBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xEB0B1220.toInt()
            style = Paint.Style.FILL
        }
        val badgeBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
        }
        canvas.drawRoundRect(badgeRect, 10f, 10f, badgeBg)
        canvas.drawRoundRect(badgeRect, 10f, 10f, badgeBorder)
        canvas.drawText(badgeText, centerX, by + 7f, badgeTextPaint)
    }

    /**
     * Renders a complete Skeletal Rig Puppet with:
     * 1) 4-View Turnaround support (Front, Left Side, Right Side, Back),
     * 2) Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh) if singleMeshImagePath is set,
     * 3) Segmented Bone-to-Image PNG Part Binding (boundImagePath per bone),
     * 4) Bound Procedural Cartoon Character 14-bone limbs, hands, feet & head with Modular Eyes & Auto Lip-Sync,
     * 5) Built-in Hand Props & Custom PNG attachments bound directly to Left & Right Hands,
     * 6) Color-coded Toontastic/TweenCraft IK Limb Handles + Central Root Move Handle.
     */
    fun drawSkeletalRig(
        canvas: Canvas,
        rig: SkeletalRig,
        puppetRoot: EvaluatedPuppetRoot,
        angles: Map<String, Float>,
        frame: Int,
        fps: Int,
        audioTracks: List<AudioTrackItem>,
        alpha: Float,
        tintColorArgb: Long?,
        showOverlay: Boolean,
        isSelectedPuppet: Boolean,
        selectedBoneId: String?,
        highlightMeshBox: Boolean = false,
        highlightFaceTarget: Boolean = false,
        moveCharMode: Boolean = false,
        bonePickHighlightMode: Boolean = false
    ) {
        val viewAngle = runCatching { CharacterViewAngle.valueOf(puppetRoot.viewAngle) }
            .getOrDefault(CharacterViewAngle.FRONT)
        val isSide = viewAngle == CharacterViewAngle.SIDE_LEFT || viewAngle == CharacterViewAngle.SIDE_RIGHT
        val isFront34 = viewAngle == CharacterViewAngle.FRONT_LEFT_34 || viewAngle == CharacterViewAngle.FRONT_RIGHT_34
        val isBack34 = viewAngle == CharacterViewAngle.BACK_LEFT_34 || viewAngle == CharacterViewAngle.BACK_RIGHT_34
        val isBack = viewAngle == CharacterViewAngle.BACK
        val isAnyBack = isBack || isBack34
        val isSideOr34 = isSide || isFront34 || isBack34
        val effectiveFlipped = isLeftFacingView(viewAngle, puppetRoot.flippedHorizontal)
        val lengthOverrides = InterpolationEngine.evaluateBoneLengths(rig, frame)

        val meshBmp = rig.singleMeshImagePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        val hasSingleMesh = meshBmp != null
        val hasBoundParts = rig.bones.any { !it.boundImagePath.isNullOrBlank() && getCachedBitmap(it.boundImagePath) != null }
        val hasCharacterSpec = rig.characterAppearance != null
        val hasAssignedArtwork = hasSingleMesh || hasBoundParts || hasCharacterSpec

        val effRigScaleX = puppetRoot.scaleX * (if (hasSingleMesh) 1f else rig.baseScaleX.coerceIn(0.1f, 5.0f))
        val effRigScaleY = puppetRoot.scaleY * (if (hasSingleMesh) 1f else rig.baseScaleY.coerceIn(0.1f, 5.0f))
        val detachedBones = InterpolationEngine.evaluateDetachedBones(rig, frame, fps)

        val solved = RigSolver.solveForwardKinematics(
            rig = rig,
            angleOverrides = angles,
            rootX = puppetRoot.rootX,
            rootY = puppetRoot.rootY,
            scale = puppetRoot.scale,
            flippedHorizontal = effectiveFlipped,
            lengthOverrides = lengthOverrides,
            scaleX = effRigScaleX,
            scaleY = effRigScaleY,
            frame = frame,
            detachedBones = detachedBones,
            viewAngle = viewAngle
        )
        val alphaInt = (alpha * 255).toInt().coerceIn(0, 255)
        val scale = puppetRoot.scale
        val scaleX = effRigScaleX
        val scaleY = effRigScaleY

        val isHorrorMood = puppetRoot.behaviorPreset == CharacterBehaviorPreset.HORROR_GHOSTLY.name
        if (hasAssignedArtwork && tintColorArgb == null && (alpha in 0.12f..0.84f || isHorrorMood)) {
            val auraColor = if (isHorrorMood) 0x66A5F3FC else 0x557DD3FC
            val auraZero = if (isHorrorMood) 0x00A5F3FC else 0x007DD3FC
            val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    puppetRoot.rootX,
                    puppetRoot.rootY - 40f * scale * scaleY,
                    168f * scale,
                    auraColor,
                    auraZero,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY - 40f * scale * scaleY, 168f * scale, auraPaint)
        }

        // A. Single-Image 2D Mesh Skinning (Canvas.drawBitmapMesh) with Unrestricted Scale (0.05x–8.0x) & Free X/Y Squash/Stretch
        if (meshBmp != null) {
            val restSolved = RigSolver.solveForwardKinematics(
                rig = rig,
                angleOverrides = emptyMap(),
                rootX = puppetRoot.rootX,
                rootY = puppetRoot.rootY,
                scale = scale,
                flippedHorizontal = effectiveFlipped,
                scaleX = scaleX,
                scaleY = scaleY,
                viewAngle = viewAngle
            )
            val meshRect = computeSingleMeshRect(rig, puppetRoot)
            val verts = RigSolver.computeDeformedMeshVertices(restSolved, solved, meshRect, 8, 8)
            val meshPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                this.alpha = alphaInt
                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
            }
            canvas.drawBitmapMesh(meshBmp, 8, 8, verts, 0, null, 0, meshPaint)

            if (showOverlay && highlightMeshBox && tintColorArgb == null) {
                val boxP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFFA78BFA.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 3.5f
                    pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
                }
                canvas.drawRect(meshRect, boxP)
                val cornerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA78BFA.toInt(); style = Paint.Style.FILL }
                val cornerStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f }
                listOf(
                    Vec2(meshRect.left, meshRect.top),
                    Vec2(meshRect.right, meshRect.top),
                    Vec2(meshRect.left, meshRect.bottom),
                    Vec2(meshRect.right, meshRect.bottom)
                ).forEach { c ->
                    canvas.drawCircle(c.x, c.y, 13f, cornerFill)
                    canvas.drawCircle(c.x, c.y, 13f, cornerStroke)
                }
                // 4 Edge Mid-Point Squish & Stretch Handles (Left/Right = Cyan Scale X, Top/Bottom = Coral Scale Y)
                val edgeXFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF06B6D4.toInt(); style = Paint.Style.FILL }
                val edgeYFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
                val midX = meshRect.centerX()
                val midY = meshRect.centerY()
                // Left & Right pill handles
                listOf(meshRect.left, meshRect.right).forEach { ex ->
                    val pill = RectF(ex - 9f, midY - 18f, ex + 9f, midY + 18f)
                    canvas.drawRoundRect(pill, 6f, 6f, edgeXFill)
                    canvas.drawRoundRect(pill, 6f, 6f, cornerStroke)
                }
                // Top & Bottom pill handles
                listOf(meshRect.top, meshRect.bottom).forEach { ey ->
                    val pill = RectF(midX - 18f, ey - 9f, midX + 18f, ey + 9f)
                    canvas.drawRoundRect(pill, 6f, 6f, edgeYFill)
                    canvas.drawRoundRect(pill, 6f, 6f, cornerStroke)
                }
            }
        }

        // B. Depth-ordered limbs/torso for ALL 8 Turnaround Angles (including 3/4 Front & 3/4 Back!)
        val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.8f * scale
            strokeCap = Paint.Cap.ROUND
            this.alpha = alphaInt
        }

        val evaluatedZOrders = InterpolationEngine.evaluateBoneZOrders(rig, frame)
        // Always auto-adapt depth order when switching away from Front view unless user explicitly keyframed bone Z-order!
        val hasExplicitZOrders = rig.boneZOrderKeyframes.isNotEmpty() ||
            (viewAngle == CharacterViewAngle.FRONT && rig.bones.any { it.zOrder != 0 })

        fun isHeadGroupBone(bone: RigBone): Boolean {
            val id = bone.id.lowercase()
            val n = bone.name.lowercase()
            if (id == "neck_base") return false
            return id == "neck" || n.contains("head") || n.contains("face") || n.contains("hair") || n.contains("hat") || n.contains("crown")
        }

        /**
         * Strict 5-Tier Bottom-to-Top Z-Order across ALL views (Front, 3/4, Side, Back):
         *   1. Far/Back Arm & Far/Back Leg
         *   2. Pelvis, Pants, Torso & Shirt
         *   3. Neck (neck_base, tucked cleanly under chin/jawline)
         *   4. Near/Front Arm & Near/Front Leg
         *   5. Head Group (ALWAYS TOPMOST LAYER — never behind neck, collar, chest, shoulders or limbs!)
         */
        fun fallbackBoneDepthOrder(boneId: String): Int {
            if (boneId == "neck") return 5
            if (boneId == "neck_base") return 3
            val isTorsoCore = boneId == "spine" || boneId == "waist" || boneId == "pelvis" ||
                boneId.startsWith("shoulder") || boneId.startsWith("hip")
            if (isTorsoCore) return 2
            return when {
                isSide || isFront34 -> if (boneId.contains("_l")) 1 else 4
                isBack34 -> if (boneId.contains("_r")) 1 else 4
                isBack -> 4
                else -> if (boneId.startsWith("leg_") || boneId.startsWith("foot_")) 1 else 4
            }
        }

        fun rawBoneZ(bone: RigBone): Int {
            return if (hasExplicitZOrders) {
                evaluatedZOrders[bone.id] ?: bone.zOrder
            } else {
                fallbackBoneDepthOrder(bone.id) * 10
            }
        }

        val maxNonHeadZ = solved.filter { !isHeadGroupBone(it.bone) }
            .maxOfOrNull { rawBoneZ(it.bone) } ?: 100

        fun resolvedZ(bone: RigBone): Int {
            val base = rawBoneZ(bone)
            // ALWAYS enforce Head Group as topmost anatomical layer across all views & joint rotations!
            return if (isHeadGroupBone(bone)) {
                max(base, max(maxNonHeadZ + 100, 500))
            } else {
                base
            }
        }

        // Unified Z-Order render queue (strictly sorted by zOrder ascending: Back -> Front, for both live preview & MP4/PNG export)
        class RigRenderQueueItem(val zOrder: Int, val subOrder: Int, val draw: () -> Unit)
        val renderQueue = ArrayList<RigRenderQueueItem>(solved.size + 6)

        val leftHandBone = solved.firstOrNull { it.bone.id == "hand_l" }
            ?: solved.firstOrNull { it.bone.id == "arm_l_low" }
        val rightHandBone = solved.firstOrNull { it.bone.id == "hand_r" }
            ?: solved.firstOrNull { it.bone.id == "arm_r_low" }
        val headBone = solved.firstOrNull { it.bone.id == "neck" || it.bone.name.contains("Head", ignoreCase = true) }

        if (rig.showSkinMesh) {
            solved.forEachIndexed { idx, sb ->
                val boneZ = resolvedZ(sb.bone)
                val tieOrder = fallbackBoneDepthOrder(sb.bone.id) * 100 + idx
                renderQueue += RigRenderQueueItem(zOrder = boneZ, subOrder = tieOrder) {
                    val partPath = sb.bone.boundImagePath
                    if (!partPath.isNullOrBlank()) {
                        val partBmp = getCachedBitmap(partPath)
                        if (partBmp != null) {
                            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                                this.alpha = alphaInt
                                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                            }
                            val preset = runCatching { PartBehaviorPreset.valueOf(sb.bone.partBehaviorPreset) }
                                .getOrDefault(PartBehaviorPreset.RIGID)
                            val rawBoneLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y)
                            val baseLen = if (preset == PartBehaviorPreset.RIGID) {
                                (sb.bone.length * scale).coerceAtLeast(16f) // Rigid locks exact scale/rotation with zero distortion
                            } else rawBoneLen
                            val stretchRatio = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
                                (rawBoneLen / (sb.bone.length * scale).coerceAtLeast(1f)).coerceIn(0.4f, 3.0f)
                            } else 1f
                            val squashW = if (preset == PartBehaviorPreset.ELASTIC_RUBBER || sb.bone.allowElasticStretch) {
                                (1f / kotlin.math.sqrt(stretchRatio)).coerceIn(0.5f, 1.8f)
                            } else 1f
                            val partScaleX = sb.bone.baseScaleX.coerceIn(0.1f, 5.0f)
                            val partScaleY = sb.bone.baseScaleY.coerceIn(0.1f, 5.0f)
                            val drawH = (baseLen * 1.25f * sb.bone.imageScale * sb.bone.limbLengthScale.coerceIn(0.3f, 3.0f) * partScaleY).coerceAtLeast(24f)
                            val aspect = partBmp.width.toFloat() / partBmp.height.coerceAtLeast(1).toFloat()
                            val drawW = ((drawH / partScaleY) * aspect * sb.bone.limbWidthScale.coerceIn(0.3f, 3.0f) * partScaleX * squashW).coerceAtLeast(20f)
                            val rotDeg = Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat()

                            canvas.save()
                            canvas.translate(sb.start.x, sb.start.y)
                            canvas.rotate(rotDeg - 90f + sb.bone.imageRotationOffsetDeg)
                            if (effectiveFlipped) canvas.scale(-1f, 1f)
                            val dst = RectF(
                                -drawW / 2f + sb.bone.pivotOffsetX * scale,
                                -drawH * 0.12f + sb.bone.pivotOffsetY * scale,
                                drawW / 2f + sb.bone.pivotOffsetX * scale,
                                drawH * 0.88f + sb.bone.pivotOffsetY * scale
                            )
                            if (preset == PartBehaviorPreset.SOFT_CLOTH) {
                                // 65% Smooth Cloth Multi-Bone Bend Mesh for Shirts, Sarees & Skirts
                                val cols = 4
                                val rows = 4
                                val meshVerts = FloatArray((cols + 1) * (rows + 1) * 2)
                                val deltaBend = ((sb.worldAngleDeg - sb.bone.localAngleDeg).coerceIn(-65f, 65f) / 65f) * (sb.bone.meshBendSmoothness.coerceIn(0.2f, 1f))
                                val wavePhase = frame * 0.22
                                var vi = 0
                                for (r in 0..rows) {
                                    val vf = r.toFloat() / rows.toFloat()
                                    val bendX = (vf * vf) * drawW * 0.22f * deltaBend + sin(wavePhase + vf * 2.2).toFloat() * (vf * drawW * 0.05f)
                                    val y = dst.top + vf * dst.height()
                                    for (c in 0..cols) {
                                        val uf = c.toFloat() / cols.toFloat()
                                        meshVerts[vi++] = dst.left + uf * dst.width() + bendX
                                        meshVerts[vi++] = y
                                    }
                                }
                                canvas.drawBitmapMesh(partBmp, cols, rows, meshVerts, 0, null, 0, imgPaint)
                            } else {
                                canvas.drawBitmap(partBmp, null, dst, imgPaint)
                            }
                            // Draw Squish/Stretch Bounding Box + 4 Corners + 4 Edge Mid-Point Handles for selected Bone Part PNG!
                            if (showOverlay && highlightMeshBox && tintColorArgb == null && sb.bone.id == selectedBoneId) {
                                val boxP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = 0xFF2DD4BF.toInt()
                                    style = Paint.Style.STROKE
                                    strokeWidth = 3f
                                    pathEffect = DashPathEffect(floatArrayOf(10f, 6f), 0f)
                                }
                                canvas.drawRect(dst, boxP)
                                val cornerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFA78BFA.toInt(); style = Paint.Style.FILL }
                                val edgeXFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF06B6D4.toInt(); style = Paint.Style.FILL }
                                val edgeYFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B35.toInt(); style = Paint.Style.FILL }
                                val strokeW = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.5f }
                                listOf(
                                    dst.left to dst.top, dst.right to dst.top,
                                    dst.left to dst.bottom, dst.right to dst.bottom
                                ).forEach { (cx, cy) ->
                                    canvas.drawCircle(cx, cy, 11f, cornerFill)
                                    canvas.drawCircle(cx, cy, 11f, strokeW)
                                }
                                val mx = dst.centerX()
                                val my = dst.centerY()
                                listOf(dst.left, dst.right).forEach { ex ->
                                    val pill = RectF(ex - 7.5f, my - 14f, ex + 7.5f, my + 14f)
                                    canvas.drawRoundRect(pill, 5f, 5f, edgeXFill)
                                    canvas.drawRoundRect(pill, 5f, 5f, strokeW)
                                }
                                listOf(dst.top, dst.bottom).forEach { ey ->
                                    val pill = RectF(mx - 14f, ey - 7.5f, mx + 14f, ey + 7.5f)
                                    canvas.drawRoundRect(pill, 5f, 5f, edgeYFill)
                                    canvas.drawRoundRect(pill, 5f, 5f, strokeW)
                                }
                            }
                            canvas.restore()
                        }
                    } else if (!hasSingleMesh && hasCharacterSpec) {
                        val isHead = sb.bone.id == "neck" || sb.bone.name.equals("Head", ignoreCase = true)
                        // Remove extra floating intermediate capsule segments at Pelvis, Waist, Shoulder L/R & Hip L/R:
                        // the unified torso (`spine`) renders one clean single-piece body/shirt covering pelvis -> chest!
                        val isHiddenIntermediateSegment = sb.bone.id in setOf(
                            "pelvis", "waist", "shoulder_l", "shoulder_r", "hip_l", "hip_r"
                        )
                        if (!isHead && !isHiddenIntermediateSegment) {
                            val charSpec = rig.characterAppearance
                            val isFarSideLimb = (isSide || isFront34) && sb.bone.id.contains("_l") || (isBack34 && sb.bone.id.contains("_r"))
                            val widthScale = sb.bone.limbWidthScale.coerceIn(0.3f, 3.0f)
                            val bodyFactor = if (sb.bone.id == "spine") {
                                val viewTorsoWidthFactor = when {
                                    isSide -> 0.56f
                                    isFront34 || isBack34 -> 0.80f
                                    else -> 1.0f
                                }
                                viewTorsoWidthFactor * charSpec.shoulderWidth.coerceIn(0.7f, 1.5f) * (1f + charSpec.bellyPlumpness.coerceIn(0f, 1f) * 0.45f)
                            } else 1f
                            val effectiveThickness = sb.bone.thickness * bodyFactor * widthScale
                            val baseFillColor = if (isFarSideLimb && tintColorArgb == null) {
                                darkenArgb(sb.bone.colorArgb, 0.82f)
                            } else {
                                (tintColorArgb ?: sb.bone.colorArgb).toInt()
                            }

                            if (sb.bone.id == "spine") {
                                // Render ONE seamless, single-piece body/shirt spanning from Pelvis base through Waist to Chest top!
                                val solvedById = solved.associateBy { it.bone.id }
                                val pelvisBone = solvedById["pelvis"]
                                val torsoBottom = pelvisBone?.start ?: sb.start
                                val torsoTop = sb.end
                                val midX = (torsoBottom.x + torsoTop.x) * 0.5f
                                val midY = (torsoBottom.y + torsoTop.y) * 0.5f
                                val fullTorsoLen = hypot(torsoTop.x - torsoBottom.x, torsoTop.y - torsoBottom.y).coerceAtLeast(48f * scale)
                                val spineAng = Math.toDegrees(atan2((torsoTop.y - torsoBottom.y).toDouble(), (torsoTop.x - torsoBottom.x).toDouble())).toFloat() + 90f
                                val minTorsoHalfW = if (isSide) 16f else 24f
                                val halfW = ((effectiveThickness * 0.68f).coerceAtLeast(minTorsoHalfW) * scale * scaleX)

                                canvas.save()
                                canvas.translate(midX, midY)
                                canvas.rotate(spineAng)
                                if (effectiveFlipped) canvas.scale(-1f, 1f)
                                val dupP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: charSpec.dupattaColorArgb).toInt(); this.alpha = alphaInt }
                                val shP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = baseFillColor; this.alpha = alphaInt }
                                val ptP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: charSpec.pantsColorArgb).toInt(); this.alpha = alphaInt }

                                // Unified rounded torso & shirt silhouette (slim curved side-profile when in Left/Right Side view!)
                                val tRect = RectF(-halfW, -fullTorsoLen * 0.52f, halfW, fullTorsoLen * 0.50f)
                                val cornerR = (halfW * 0.65f).coerceAtLeast(13f * scale)
                                if (isSide) {
                                    // True Side-Profile Torso silhouette (curved chest facing +X, slightly straighter back on -X)
                                    val sidePath = Path().apply {
                                        moveTo(-halfW * 0.78f, -fullTorsoLen * 0.48f)
                                        cubicTo(
                                            halfW * 0.30f, -fullTorsoLen * 0.54f,
                                            halfW * 1.15f, -fullTorsoLen * 0.25f,
                                            halfW * 1.05f, fullTorsoLen * 0.05f
                                        )
                                        cubicTo(
                                            halfW * 0.98f, fullTorsoLen * 0.34f,
                                            halfW * 0.75f, fullTorsoLen * 0.50f,
                                            0f, fullTorsoLen * 0.50f
                                        )
                                        cubicTo(
                                            -halfW * 0.85f, fullTorsoLen * 0.50f,
                                            -halfW * 0.95f, fullTorsoLen * 0.20f,
                                            -halfW * 0.90f, -fullTorsoLen * 0.15f
                                        )
                                        cubicTo(
                                            -halfW * 0.88f, -fullTorsoLen * 0.35f,
                                            -halfW * 0.86f, -fullTorsoLen * 0.46f,
                                            -halfW * 0.78f, -fullTorsoLen * 0.48f
                                        )
                                        close()
                                    }
                                    canvas.drawPath(sidePath, shP)
                                    val hemRect = RectF(-halfW * 0.86f, fullTorsoLen * 0.30f, halfW * 0.86f, fullTorsoLen * 0.50f)
                                    canvas.drawRoundRect(hemRect, cornerR * 0.5f, cornerR * 0.5f, ptP)
                                    canvas.drawPath(sidePath, outlinePaint)
                                } else {
                                    canvas.drawRoundRect(tRect, cornerR, cornerR, shP)
                                    val hemRect = RectF(-halfW * 0.96f, fullTorsoLen * 0.30f, halfW * 0.96f, fullTorsoLen * 0.50f)
                                    canvas.drawRoundRect(hemRect, cornerR * 0.55f, cornerR * 0.55f, ptP)
                                    canvas.drawRoundRect(tRect, cornerR, cornerR, outlinePaint)
                                }

                                if (charSpec.bellyPlumpness > 0.1f) {
                                    val bellyR = (18f + charSpec.bellyPlumpness * 22f) * scale
                                    val bellyP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = baseFillColor; this.alpha = alphaInt }
                                    val bellyOffsetX = if (isSide) halfW * 0.35f else 0f
                                    canvas.drawOval(RectF(bellyOffsetX - bellyR * 1.15f, -bellyR * 0.25f, bellyOffsetX + bellyR * 1.15f, bellyR * 1.15f), bellyP)
                                    canvas.drawOval(RectF(bellyOffsetX - bellyR * 1.15f, -bellyR * 0.25f, bellyOffsetX + bellyR * 1.15f, bellyR * 1.15f), outlinePaint)
                                }
                                drawTraditionalTorsoDetails(canvas, charSpec, tRect, shP, ptP, dupP, outlinePaint, isBack = isAnyBack)
                                if (charSpec.customCodePaths.isNotEmpty()) {
                                    canvas.save()
                                    canvas.scale(scale * scaleX, scale * scaleY)
                                    drawCustomCodePaths(canvas, charSpec.customCodePaths, "TORSO", alphaInt, tintColorArgb)
                                    canvas.restore()
                                }
                                canvas.restore()
                            } else if (sb.bone.id == "foot_l" || sb.bone.id == "foot_r") {
                                // Crisp cartoon shoe colored with CharacterSpec.shoeColorArgb pointing cleanly in facing direction!
                                val footLen = hypot(sb.end.x - sb.start.x, sb.end.y - sb.start.y).coerceAtLeast(20f * scale)
                                val footAng = if (isSide) {
                                    if (effectiveFlipped) 180f else 0f
                                } else {
                                    Math.toDegrees(atan2((sb.end.y - sb.start.y).toDouble(), (sb.end.x - sb.start.x).toDouble())).toFloat()
                                }
                                val shoeH = (effectiveThickness * 0.85f * scale * scaleY).coerceAtLeast(12f * scale)
                                val shoeW = (footLen * 1.28f).coerceAtLeast(24f * scale)
                                val shoeColorInt = if (isFarSideLimb && tintColorArgb == null) {
                                    darkenArgb(charSpec.shoeColorArgb, 0.82f)
                                } else {
                                    (tintColorArgb ?: charSpec.shoeColorArgb).toInt()
                                }
                                val shoeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = shoeColorInt
                                    style = Paint.Style.FILL
                                    this.alpha = alphaInt
                                }
                                val solePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = if (tintColorArgb != null) tintColorArgb.toInt() else 0xFFE2E8F0.toInt()
                                    style = Paint.Style.FILL
                                    this.alpha = alphaInt
                                }
                                canvas.save()
                                canvas.translate(sb.start.x, sb.start.y)
                                canvas.rotate(footAng)
                                val shoeRect = RectF(-shoeH * 0.45f, -shoeH * 0.55f, shoeW, shoeH * 0.52f)
                                canvas.drawRoundRect(shoeRect, shoeH * 0.48f, shoeH * 0.48f, shoeFill)
                                val soleRect = if (kotlin.math.abs(footAng) > 90f) {
                                    RectF(-shoeH * 0.38f, -shoeH * 0.55f, shoeW * 0.96f, -shoeH * 0.30f)
                                } else {
                                    RectF(-shoeH * 0.38f, shoeH * 0.28f, shoeW * 0.96f, shoeH * 0.52f)
                                }
                                canvas.drawRoundRect(soleRect, 4f * scale, 4f * scale, solePaint)
                                canvas.drawRoundRect(shoeRect, shoeH * 0.48f, shoeH * 0.48f, outlinePaint)
                                canvas.restore()
                            } else {
                                val limbOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = (tintColorArgb ?: 0xFF0F172AL).toInt()
                                    strokeWidth = (effectiveThickness + 6f) * scale * ((scaleX + scaleY) * 0.5f)
                                    strokeCap = Paint.Cap.ROUND
                                    style = Paint.Style.STROKE
                                    this.alpha = alphaInt
                                }
                                val limbFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = baseFillColor
                                    strokeWidth = effectiveThickness * scale * ((scaleX + scaleY) * 0.5f)
                                    strokeCap = Paint.Cap.ROUND
                                    style = Paint.Style.STROKE
                                    this.alpha = alphaInt
                                }
                                if (sb.bone.id == "neck_base") {
                                    // Tuck neck cleanly into torso collar & up underneath lower chin/jawline so there is NEVER a gap!
                                    val dx = sb.end.x - sb.start.x
                                    val dy = sb.end.y - sb.start.y
                                    val len = hypot(dx, dy).coerceAtLeast(1f)
                                    val ux = dx / len
                                    val uy = dy / len
                                    val tuckStartX = sb.start.x - ux * 6f * scale
                                    val tuckStartY = sb.start.y - uy * 6f * scale
                                    val tuckEndX = sb.end.x + ux * 10f * scale
                                    val tuckEndY = sb.end.y + uy * 10f * scale
                                    canvas.drawLine(tuckStartX, tuckStartY, tuckEndX, tuckEndY, limbOutline)
                                    canvas.drawLine(tuckStartX, tuckStartY, tuckEndX, tuckEndY, limbFill)
                                } else {
                                    canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbOutline)
                                    canvas.drawLine(sb.start.x, sb.start.y, sb.end.x, sb.end.y, limbFill)
                                }
                            }

                            if (isAnyBack && sb.bone.id == "spine" && charSpec.shirtStyle == "HOODIE") {
                                val hoodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    style = Paint.Style.FILL; color = baseFillColor; this.alpha = alphaInt
                                }
                                canvas.drawCircle(sb.end.x, sb.end.y + 8f * scale, 22f * scale, hoodPaint)
                                canvas.drawCircle(sb.end.x, sb.end.y + 8f * scale, 22f * scale, outlinePaint)
                            }

                            // Traditional Bangles on forearms near wrists
                            if (charSpec.hasBangles && (sb.bone.id == "arm_l_low" || sb.bone.id == "arm_r_low")) {
                                val bPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = (tintColorArgb ?: charSpec.banglesColorArgb).toInt()
                                    style = Paint.Style.STROKE
                                    strokeWidth = 5f * scale
                                    this.alpha = alphaInt
                                }
                                val wx = sb.start.x + (sb.end.x - sb.start.x) * 0.82f
                                val wy = sb.start.y + (sb.end.y - sb.start.y) * 0.82f
                                canvas.drawCircle(wx, wy, 9.5f * scale, bPaint)
                            }

                            // Module 4 & 8: Expressive Cartoon Hand Gestures & Palm-Flip / Water-Cupping Poses (+ custom PNG slots)!
                            if (sb.bone.id == "hand_l" || sb.bone.id == "hand_r") {
                                val gestureName = if (sb.bone.id == "hand_l") puppetRoot.leftHandGesture else puppetRoot.rightHandGesture
                                drawExpressiveCartoonHand(
                                    canvas = canvas,
                                    handBone = sb,
                                    gestureName = gestureName,
                                    skinColor = baseFillColor,
                                    outlinePaint = outlinePaint,
                                    scale = scale,
                                    flipped = effectiveFlipped,
                                    alphaInt = alphaInt,
                                    customHandPosePath = rig.customHandPoseSlots[gestureName]
                                )
                            }
                        }
                    }

                    // Render attached built-in prop graphic on ANY extra variable rig bone
                    val extraProp = sb.bone.attachedPropKind
                    if (!extraProp.isNullOrBlank() && extraProp != HandPropKind.NONE.name) {
                        drawHandProp(
                            canvas = canvas,
                            handBone = sb,
                            propKindName = extraProp,
                            customImagePath = null,
                            propScale = sb.bone.imageScale * scale,
                            flipped = effectiveFlipped,
                            alphaInt = alphaInt,
                            tintColorArgb = tintColorArgb,
                            frame = frame
                        )
                    }
                }
            }
        }

        // B2. Module 1: Point-to-Point Mesh Pinning — Localized Rubber Cloth Bridges ONLY between pinned anchors!
        if (rig.showSkinMesh && rig.meshPins.isNotEmpty()) {
            val solvedById = solved.associateBy { it.bone.id }
            rig.meshPins.forEach { pin ->
                val boneA = solvedById[pin.boneAId]
                val boneB = solvedById[pin.boneBId]
                if (boneA != null && boneB != null) {
                    val pinZ = max(resolvedZ(boneA.bone), resolvedZ(boneB.bone))
                    renderQueue += RigRenderQueueItem(zOrder = pinZ, subOrder = 910) {
                        val clothVerts = RigSolver.computePinnedClothBridgeVertices(pin, boneA, boneB, cols = 6, rows = 4)
                        val srcPath = boneA.bone.boundImagePath ?: boneB.bone.boundImagePath ?: rig.singleMeshImagePath
                        val srcBmp = srcPath?.let { getCachedBitmap(it) }
                        if (srcBmp != null) {
                            val bridgePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                                this.alpha = alphaInt
                                if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                            }
                            canvas.drawBitmapMesh(srcBmp, 6, 4, clothVerts, 0, null, 0, bridgePaint)
                        } else {
                            // Clean fabric patch bridge connecting procedural outfit limbs
                            val pA = RigSolver.resolvePinWorldPoint(boneA, pin.localAnchorA)
                            val pB = RigSolver.resolvePinWorldPoint(boneB, pin.localAnchorB)
                            val clothP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = (tintColorArgb ?: boneA.bone.colorArgb).toInt()
                                style = Paint.Style.STROKE
                                strokeWidth = (pin.radiusPx * 0.55f * scale).coerceIn(10f, 52f)
                                strokeCap = Paint.Cap.ROUND
                                this.alpha = alphaInt
                            }
                            canvas.drawLine(pA.x, pA.y, pB.x, pB.y, clothP)
                        }
                    }
                }
            }
        }

        val hasAnyCustomFaceData = rig.showFaceOverlayOnCustomImage ||
            rig.customEyeSlots.isNotEmpty() ||
            rig.customMouthSlots.isNotEmpty() ||
            rig.eyeMoodSets.isNotEmpty() ||
            rig.mouthMoodSets.isNotEmpty() ||
            !rig.leftEyeContainer.scleraImagePath.isNullOrBlank() ||
            !rig.rightEyeContainer.scleraImagePath.isNullOrBlank() ||
            !rig.customNoseImagePath.isNullOrBlank() ||
            !rig.faceLayers.leftBrowImagePath.isNullOrBlank() ||
            !rig.faceLayers.rightBrowImagePath.isNullOrBlank() ||
            rig.faceLayers.eyeBuilderFrames.isNotEmpty() ||
            rig.faceLayers.mouthBuilderFrames.isNotEmpty() ||
            rig.faceLayers.browBuilderFrames.isNotEmpty()

        // Module 6: Auto-Dialogue Head Bounce (1°–6° head nods & micro chin bounce synced to voice syllables!)
        val (dialogueNodDeg, dialogueChinBouncePx) = AudioStudioEngine.evaluateDialogueHeadBounce(
            audioTracks = audioTracks,
            frame = frame,
            fps = fps,
            enabled = rig.autoDialogueHeadBounce,
            timing = rig.facialTiming
        )

        // C. Head Sculpt + Modular Pre-Animated Eyes, Eyebrow Acting & Auto Lip-Sync snapped to Head bone Z-Order!
        if (headBone != null) {
            val headZ = resolvedZ(headBone.bone)
            renderQueue += RigRenderQueueItem(zOrder = headZ, subOrder = 950) {
                val headAngle = Math.toDegrees(
                    atan2((headBone.end.y - headBone.start.y).toDouble(), (headBone.end.x - headBone.start.x).toDouble())
                ).toFloat() + 90f + dialogueNodDeg
                val headCenterX = (headBone.start.x + headBone.end.x * 2f) / 3f
                val headCenterY = (headBone.start.y + headBone.end.y * 2f) / 3f + dialogueChinBouncePx * scale

                canvas.save()
                canvas.translate(headCenterX, headCenterY)
                canvas.rotate(headAngle)
                canvas.scale(if (effectiveFlipped) -scale * scaleX else scale * scaleX, scale * scaleY)

                val resolvedFace = resolveViewAwareFaceTransform(rig, viewAngle)
                val spec = rig.characterAppearance?.copy(
                    eyePack = puppetRoot.eyePack,
                    mouthPhoneme = puppetRoot.mouthPhoneme,
                    viewAngle = viewAngle.name
                )
                if (spec != null && headBone.bone.boundImagePath.isNullOrBlank() && !hasSingleMesh) {
                    val skinP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: spec.skinToneArgb).toInt(); this.alpha = alphaInt }
                    val hairP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (tintColorArgb ?: spec.hairColorArgb).toInt(); this.alpha = alphaInt }
                    drawHeadSculpt(
                        canvas = canvas,
                        c = spec,
                        skinPaint = skinP,
                        hairPaint = hairP,
                        outline = outlinePaint,
                        alphaInt = alphaInt,
                        tintColorArgb = tintColorArgb,
                        frame = frame,
                        fps = fps,
                        audioTracks = audioTracks,
                        viewAngle = viewAngle,
                        eyebrowStyleName = puppetRoot.eyebrowStyle,
                        customEyeSlots = rig.customEyeSlots,
                        customMouthSlots = rig.customMouthSlots,
                        facialTiming = rig.facialTiming,
                        faceTransform = resolvedFace,
                        rig = rig,
                        puppetRoot = puppetRoot,
                        showAlignmentGuides = showOverlay && rig.showFaceAlignmentGuides
                    )
                    if (showOverlay && highlightFaceTarget && resolvedFace.visible && tintColorArgb == null) {
                        canvas.save()
                        canvas.translate(resolvedFace.offsetX, resolvedFace.offsetY)
                        canvas.rotate(resolvedFace.rotationDeg)
                        canvas.scale(resolvedFace.scaleX, resolvedFace.scaleY)
                        val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFF06B6D4.toInt()
                            style = Paint.Style.STROKE
                            strokeWidth = 3f / max(resolvedFace.scaleX, resolvedFace.scaleY).coerceAtLeast(0.25f)
                            pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
                        }
                        canvas.drawCircle(0f, 4f, 42f, guideP)
                        canvas.restore()
                    }
                } else if (hasAssignedArtwork && hasAnyCustomFaceData && resolvedFace.visible) {
                    canvas.save()
                    canvas.translate(resolvedFace.offsetX, resolvedFace.offsetY)
                    canvas.rotate(resolvedFace.rotationDeg)
                    canvas.scale(resolvedFace.scaleX, resolvedFace.scaleY)
                    drawModularFaceRig(
                        canvas = canvas,
                        eyePackName = puppetRoot.eyePack,
                        mouthPhonemeName = puppetRoot.mouthPhoneme,
                        eyeColorArgb = rig.characterAppearance?.eyeColorArgb ?: 0xFF2DD4BFL,
                        frame = frame,
                        fps = fps,
                        audioTracks = audioTracks,
                        alphaInt = alphaInt,
                        tintColorArgb = tintColorArgb,
                        isSideProfile = resolvedFace.isSideProfile,
                        eyebrowStyleName = puppetRoot.eyebrowStyle,
                        customEyeSlots = rig.customEyeSlots,
                        customMouthSlots = rig.customMouthSlots,
                        facialTiming = rig.facialTiming,
                        faceTransform = resolvedFace,
                        rig = rig,
                        puppetRoot = puppetRoot,
                        showAlignmentGuides = showOverlay && rig.showFaceAlignmentGuides
                    )
                    if (showOverlay && highlightFaceTarget && tintColorArgb == null) {
                        val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFF06B6D4.toInt()
                            style = Paint.Style.STROKE
                            strokeWidth = 3f / max(resolvedFace.scaleX, resolvedFace.scaleY).coerceAtLeast(0.25f)
                            pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
                        }
                        canvas.drawCircle(0f, 4f, 42f, guideP)
                    }
                    canvas.restore()
                }
                canvas.restore()
            }
        } else if (hasAssignedArtwork && hasAnyCustomFaceData) {
            val resolvedFace = resolveViewAwareFaceTransform(rig, viewAngle)
            if (resolvedFace.visible) {
                val fallbackFaceZ = (rig.bones.maxOfOrNull { resolvedZ(it) } ?: 8) + 1
                renderQueue += RigRenderQueueItem(zOrder = fallbackFaceZ, subOrder = 950) {
                    canvas.save()
                    canvas.translate(
                        puppetRoot.rootX + resolvedFace.offsetX * scale * scaleX,
                        puppetRoot.rootY - 90f * scale * scaleY + resolvedFace.offsetY * scale * scaleY + dialogueChinBouncePx * scale
                    )
                    canvas.rotate(resolvedFace.rotationDeg + dialogueNodDeg)
                    canvas.scale(
                        (if (effectiveFlipped) -scale * scaleX else scale * scaleX) * resolvedFace.scaleX,
                        scale * scaleY * resolvedFace.scaleY
                    )
                    drawModularFaceRig(
                        canvas = canvas,
                        eyePackName = puppetRoot.eyePack,
                        mouthPhonemeName = puppetRoot.mouthPhoneme,
                        eyeColorArgb = rig.characterAppearance?.eyeColorArgb ?: 0xFF2DD4BFL,
                        frame = frame,
                        fps = fps,
                        audioTracks = audioTracks,
                        alphaInt = alphaInt,
                        tintColorArgb = tintColorArgb,
                        isSideProfile = resolvedFace.isSideProfile,
                        eyebrowStyleName = puppetRoot.eyebrowStyle,
                        customEyeSlots = rig.customEyeSlots,
                        customMouthSlots = rig.customMouthSlots,
                        facialTiming = rig.facialTiming,
                        faceTransform = resolvedFace,
                        rig = rig,
                        puppetRoot = puppetRoot,
                        showAlignmentGuides = showOverlay && rig.showFaceAlignmentGuides
                    )
                    if (showOverlay && highlightFaceTarget && tintColorArgb == null) {
                        val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFF06B6D4.toInt()
                            style = Paint.Style.STROKE
                            strokeWidth = 3f / max(resolvedFace.scaleX, resolvedFace.scaleY).coerceAtLeast(0.25f)
                            pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
                        }
                        canvas.drawCircle(0f, 4f, 42f, guideP)
                    }
                    canvas.restore()
                }
            }
        }

        // C2. Keyframeable Variable Hand-Held Prop Sockets sorted directly on top of their hand bones' Z-Order!
        val (leftPropKind, leftPropImg) = InterpolationEngine.evaluateHandPropSocket(rig, isRightHand = false, frame = frame)
        if (leftHandBone != null && (leftPropKind != HandPropKind.NONE.name || !leftPropImg.isNullOrBlank())) {
            val leftPropZ = resolvedZ(leftHandBone.bone)
            renderQueue += RigRenderQueueItem(zOrder = leftPropZ, subOrder = 980) {
                drawHandProp(
                    canvas = canvas,
                    handBone = leftHandBone,
                    propKindName = leftPropKind,
                    customImagePath = leftPropImg,
                    propScale = rig.handPropScale * scale,
                    flipped = effectiveFlipped,
                    alphaInt = alphaInt,
                    tintColorArgb = tintColorArgb,
                    frame = frame
                )
            }
        }
        val (rightPropKind, rightPropImg) = InterpolationEngine.evaluateHandPropSocket(rig, isRightHand = true, frame = frame)
        if (rightHandBone != null && (rightPropKind != HandPropKind.NONE.name || !rightPropImg.isNullOrBlank())) {
            val rightPropZ = resolvedZ(rightHandBone.bone)
            renderQueue += RigRenderQueueItem(zOrder = rightPropZ, subOrder = 990) {
                drawHandProp(
                    canvas = canvas,
                    handBone = rightHandBone,
                    propKindName = rightPropKind,
                    customImagePath = rightPropImg,
                    propScale = rig.handPropScale * scale,
                    flipped = effectiveFlipped,
                    alphaInt = alphaInt,
                    tintColorArgb = tintColorArgb,
                    frame = frame
                )
            }
        }

        // Execute strictly sorted Back -> Front draw passes (identical for live preview & MP4/PNG export!)
        renderQueue.sortedWith(compareBy<RigRenderQueueItem>({ it.zOrder }, { it.subOrder })).forEach { it.draw() }

        // D0. Editor-only Point-to-Point Mesh Pinning Stitch Indicators (never shown on export!)
        if (showOverlay && rig.meshPins.isNotEmpty() && tintColorArgb == null) {
            val solvedById = solved.associateBy { it.bone.id }
            val stitchLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF06B6D4.toInt()
                style = Paint.Style.STROKE
                strokeWidth = 3f
                pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
            }
            val pinDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF2DD4BF.toInt()
                style = Paint.Style.FILL
            }
            val pinRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 2.5f
            }
            rig.meshPins.forEach { pin ->
                val bA = solvedById[pin.boneAId]
                val bB = solvedById[pin.boneBId]
                if (bA != null && bB != null) {
                    val pA = RigSolver.resolvePinWorldPoint(bA, pin.localAnchorA)
                    val pB = RigSolver.resolvePinWorldPoint(bB, pin.localAnchorB)
                    canvas.drawLine(pA.x, pA.y, pB.x, pB.y, stitchLine)
                    canvas.drawCircle(pA.x, pA.y, 7.5f, pinDot); canvas.drawCircle(pA.x, pA.y, 7.5f, pinRing)
                    canvas.drawCircle(pB.x, pB.y, 7.5f, pinDot); canvas.drawCircle(pB.x, pB.y, 7.5f, pinRing)
                }
            }
        }

        // D. Skeleton Wireframe & Active Limb/Head Joint Handles
        // In bonePickHighlightMode ("Attach to Any Bone"), highlight ALL bones/joints across ALL characters!
        if (showOverlay || bonePickHighlightMode) {
            val parentIds = rig.bones.mapNotNull { it.parentId }.toSet()
            solved.forEach { sb ->
                // Hide redundant yellow dots & bone capsules on structurally fixed core bones unless Unlock Core OR Bone-Pick Mode is ON
                if (!bonePickHighlightMode && !rig.unlockCoreBones && (RigSolver.isBoneStructurallyFixed(rig, sb.bone) || sb.bone.id == "neck_base")) {
                    return@forEach
                }
                val isSelectedBone = sb.bone.id == selectedBoneId && tintColorArgb == null
                val isLeafBone = sb.bone.id !in parentIds
                val isEndEffector = isLeafBone || sb.bone.id.startsWith("hand_") || sb.bone.id.startsWith("foot_") || sb.bone.id == "neck"
                val limbAccent = when {
                    bonePickHighlightMode -> 0xFF10B981.toInt() // Bright Emerald pick target across all characters!
                    tintColorArgb != null -> tintColorArgb.toInt()
                    isSelectedBone -> 0xFFFF6B35.toInt()
                    sb.bone.id.startsWith("hand_") || sb.bone.id.startsWith("wing_") -> 0xFF06B6D4.toInt()
                    sb.bone.id.startsWith("arm") -> 0xFF2DD4BF.toInt()
                    sb.bone.id.startsWith("foot_") || sb.bone.id.startsWith("tail") -> 0xFFC084FC.toInt()
                    sb.bone.id.startsWith("leg") -> 0xFFA78BFA.toInt()
                    else -> 0xFFFBBF24.toInt()
                }

                val bonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = limbAccent
                    style = Paint.Style.STROKE
                    strokeWidth = if (bonePickHighlightMode) 3.2f else if (isSelectedBone) 4.4f else 2.6f
                    this.alpha = if (tintColorArgb != null) (alphaInt * 1.4f).toInt().coerceAtMost(180) else 240
                }
                val dx = sb.end.x - sb.start.x
                val dy = sb.end.y - sb.start.y
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val ux = dx / len; val uy = dy / len
                val px = -uy; val py = ux
                val midX = sb.start.x + dx * 0.22f
                val midY = sb.start.y + dy * 0.22f
                val w = (len * 0.11f).coerceIn(3.5f, 10.5f)

                val bonePath = Path().apply {
                    moveTo(sb.start.x, sb.start.y)
                    lineTo(midX + px * w, midY + py * w)
                    lineTo(sb.end.x, sb.end.y)
                    lineTo(midX - px * w, midY - py * w)
                    close()
                }
                canvas.drawPath(bonePath, bonePaint)

                if (bonePickHighlightMode && tintColorArgb == null) {
                    // Glowing tap-target dots on EVERY bone/joint across ALL characters so user can bind to ANY bone!
                    val targetHalo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0x6610B981
                        style = Paint.Style.FILL
                    }
                    val targetFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF10B981.toInt()
                        style = Paint.Style.FILL
                    }
                    val targetRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.WHITE
                        style = Paint.Style.STROKE
                        strokeWidth = 2.6f
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, 20f, targetHalo)
                    canvas.drawCircle(sb.end.x, sb.end.y, 11.5f, targetFill)
                    canvas.drawCircle(sb.end.x, sb.end.y, 11.5f, targetRing)
                } else if (tintColorArgb == null && isSelectedPuppet) {
                    val handleRadius = when {
                        isSelectedBone -> 15.5f
                        isEndEffector -> 13f
                        else -> 9.5f
                    }
                    // Glowing touch halo so users can easily spot and grab IK joints on mobile!
                    val haloRadius = if (isSelectedBone) 28f else if (isEndEffector) 22f else 15f
                    val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                        this.alpha = if (isSelectedBone) 95 else 52
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, haloRadius, haloPaint)

                    val jointFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                    }
                    val ringStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.WHITE
                        style = Paint.Style.STROKE
                        strokeWidth = if (isSelectedBone) 3.4f else if (isEndEffector) 2.8f else 2f
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, handleRadius, jointFill)
                    canvas.drawCircle(sb.end.x, sb.end.y, handleRadius, ringStroke)

                    // Draw crisp mini padlock badge next to explicitly locked joints!
                    if (RigSolver.isBoneLocked(rig, sb.bone)) {
                        val lx = sb.end.x + handleRadius + 4f
                        val ly = sb.end.y - handleRadius - 2f
                        val lockBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFF0A0F1C.toInt()
                            style = Paint.Style.FILL
                        }
                        val lockAccent = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFFFF6B35.toInt()
                            style = Paint.Style.FILL
                        }
                        val shackleP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xFFFFD600.toInt()
                            style = Paint.Style.STROKE
                            strokeWidth = 2.0f
                        }
                        canvas.drawCircle(lx, ly, 10f, lockBg)
                        canvas.drawArc(RectF(lx - 4f, ly - 7f, lx + 4f, ly), 180f, 180f, false, shackleP)
                        canvas.drawRoundRect(RectF(lx - 5f, ly - 1.5f, lx + 5f, ly + 5.5f), 2f, 2f, lockAccent)
                    }
                } else {
                    val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = limbAccent
                        style = Paint.Style.FILL
                        this.alpha = if (tintColorArgb != null) (alphaInt * 1.5f).toInt().coerceAtMost(190) else 220
                    }
                    canvas.drawCircle(sb.end.x, sb.end.y, 5.5f, dot)
                }
            }

            // Central Root / Hip Move Handle (Prominent Glowing Cyan in Move Char mode, Coral in normal mode)
            if (tintColorArgb == null && isSelectedPuppet) {
                val rootAccent = if (moveCharMode) 0xFF06B6D4.toInt() else 0xFFFF6B35.toInt()
                val outerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (moveCharMode) 0x4806B6D4 else 0x38FF6B35
                    style = Paint.Style.FILL
                }
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (moveCharMode) 0x7706B6D4 else 0x66FF6B35
                    style = Paint.Style.FILL
                }
                val rootFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = rootAccent
                    style = Paint.Style.FILL
                }
                val rootRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.STROKE
                    strokeWidth = 3.0f
                }
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, if (moveCharMode) 38f else 30f, outerGlow)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, if (moveCharMode) 26f else 20f, glow)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, if (moveCharMode) 18f else 14f, rootFill)
                canvas.drawCircle(puppetRoot.rootX, puppetRoot.rootY, if (moveCharMode) 18f else 14f, rootRing)
                val crossArm = if (moveCharMode) 10f else 7f
                canvas.drawLine(puppetRoot.rootX - crossArm, puppetRoot.rootY, puppetRoot.rootX + crossArm, puppetRoot.rootY, rootRing)
                canvas.drawLine(puppetRoot.rootX, puppetRoot.rootY - crossArm, puppetRoot.rootX, puppetRoot.rootY + crossArm, rootRing)

                // Compact 28dp Yellow Rotation Ring centered on selected bone's pivot (hidden in Move Char mode)
                val selectedSolved = if (moveCharMode) null else selectedBoneId?.let { bid -> solved.firstOrNull { it.bone.id == bid } }
                if (selectedSolved != null) {
                    val isLocked = RigSolver.isBoneLocked(rig, selectedSolved.bone)
                    val px = selectedSolved.start.x
                    val py = selectedSolved.start.y
                    val ringR = PRISMA_ROTATION_RING_RADIUS

                    // Compact dark halo ring for crisp contrast without covering neighboring joints
                    val backingRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xAA0A0F1C.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 5.5f
                    }
                    canvas.drawCircle(px, py, ringR, backingRing)

                    // Sleek 2.0f bright yellow ring (coral-dashed cue when bone is locked)
                    val mainRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLocked) 0xFFFF6B35.toInt() else 0xFFFFD600.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 2.0f
                        if (isLocked) pathEffect = DashPathEffect(floatArrayOf(5f, 4f), 0f)
                    }
                    canvas.drawCircle(px, py, ringR, mainRing)

                    // Subtle compact tick marks every 30°
                    val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xBBFFFFFF.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 1.2f
                        strokeCap = Paint.Cap.ROUND
                    }
                    for (deg in 0 until 360 step 30) {
                        val rad = Math.toRadians(deg.toDouble())
                        val isMajor = deg % 90 == 0
                        val inner = ringR - (if (isMajor) 4.0f else 2.2f)
                        val outer = ringR + (if (isMajor) 2.2f else 1.2f)
                        canvas.drawLine(
                            px + (cos(rad) * inner).toFloat(),
                            py + (sin(rad) * inner).toFloat(),
                            px + (cos(rad) * outer).toFloat(),
                            py + (sin(rad) * outer).toFloat(),
                            tickPaint
                        )
                    }

                    // Active bone spoke + compact 8dp handle dot on ring circumference
                    val boneRad = Math.toRadians(selectedSolved.worldAngleDeg.toDouble())
                    val handleX = px + (cos(boneRad) * ringR).toFloat()
                    val handleY = py + (sin(boneRad) * ringR).toFloat()
                    val spokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xCC06B6D4.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 1.5f
                        pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
                    }
                    canvas.drawLine(px, py, handleX, handleY, spokePaint)

                    // Small pivot dot
                    val pivotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF06B6D4.toInt()
                        style = Paint.Style.FILL
                    }
                    val pivotStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.WHITE
                        style = Paint.Style.STROKE
                        strokeWidth = 1.6f
                    }
                    canvas.drawCircle(px, py, 4.0f, pivotFill)
                    canvas.drawCircle(px, py, 4.0f, pivotStroke)

                    // Compact 4.5f-radius (9dp) draggable handle dot on ring circumference
                    val knobGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLocked) 0x44FF6B35 else 0x55FFD600
                        style = Paint.Style.FILL
                    }
                    val knobFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLocked) 0xFFFF6B35.toInt() else 0xFFFFD600.toInt()
                        style = Paint.Style.FILL
                    }
                    val knobStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF0A0F1C.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 1.8f
                    }
                    canvas.drawCircle(handleX, handleY, 8.5f, knobGlow)
                    canvas.drawCircle(handleX, handleY, 4.5f, knobFill)
                    canvas.drawCircle(handleX, handleY, 4.5f, knobStroke)

                    // Compact Angle Badge Pill above the ring
                    val curLocal = angles[selectedSolved.bone.id] ?: selectedSolved.bone.localAngleDeg
                    val relDeg = (curLocal - selectedSolved.bone.localAngleDeg).toInt()
                    val signPrefix = if (relDeg > 0) "+" else ""
                    val lockSuffix = if (isLocked) " 🔒" else ""
                    val badgeText = "${selectedSolved.bone.name} $signPrefix${relDeg}°$lockSuffix"
                    val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLocked) 0xFFFF6B35.toInt() else 0xFFFFD600.toInt()
                        textSize = 14f
                        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                        textAlign = Paint.Align.CENTER
                    }
                    val bw = badgeTextPaint.measureText(badgeText) + 16f
                    val by = (py - ringR - 18f).coerceAtLeast(24f)
                    val badgeRect = RectF(px - bw / 2f, by - 11f, px + bw / 2f, by + 11f)
                    val badgeBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xEB0B1220.toInt()
                        style = Paint.Style.FILL
                    }
                    val badgeBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = if (isLocked) 0xFFFF6B35.toInt() else 0xFFFFD600.toInt()
                        style = Paint.Style.STROKE
                        strokeWidth = 1.6f
                    }
                    canvas.drawRoundRect(badgeRect, 7f, 7f, badgeBg)
                    canvas.drawRoundRect(badgeRect, 7f, 7f, badgeBorder)
                    canvas.drawText(badgeText, px, by + 5f, badgeTextPaint)
                }
            }
        }
    }

    private fun darkenArgb(argb: Long, factor: Float): Int {
        val c = argb.toInt()
        val r = (Color.red(c) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(c) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(c) * factor).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(c), r, g, b)
    }

    /**
     * Module 4: Renders 7 Expressive Cartoon Hand Gestures (Relaxed, Open Palm / Talking,
     * Pointing Finger, Namaste / Folded Hands, Fist, Thumbs Up, Holding Prop) snapped to hand bones!
     */
    private fun drawExpressiveCartoonHand(
        canvas: Canvas,
        handBone: SolvedBone,
        gestureName: String,
        skinColor: Int,
        outlinePaint: Paint,
        scale: Float,
        flipped: Boolean,
        alphaInt: Int,
        customHandPosePath: String? = null
    ) {
        val pose = runCatching { HandGesturePose.valueOf(gestureName) }.getOrDefault(HandGesturePose.RELAXED)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = skinColor
            alpha = alphaInt
        }
        val handOutline = Paint(outlinePaint).apply { strokeWidth = 2.6f * scale }
        val angleDeg = Math.toDegrees(
            atan2((handBone.end.y - handBone.start.y).toDouble(), (handBone.end.x - handBone.start.x).toDouble())
        ).toFloat()

        canvas.save()
        canvas.translate(handBone.end.x, handBone.end.y)
        canvas.rotate(angleDeg)
        canvas.scale(scale, if (flipped) -scale else scale)

        // Module 8: Support user-imported Custom Hand Pose PNG slot for any palm angle/gesture!
        val customBmp = customHandPosePath?.takeIf { it.isNotBlank() }?.let { getCachedBitmap(it) }
        if (customBmp != null) {
            val hp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = alphaInt }
            canvas.drawBitmap(customBmp, null, RectF(-16f, -18f, 28f, 18f), hp)
            canvas.restore()
            return
        }

        when (pose) {
            HandGesturePose.RELAXED -> {
                canvas.drawOval(RectF(-10f, -9f, 12f, 9f), fill)
                canvas.drawOval(RectF(-10f, -9f, 12f, 9f), handOutline)
            }
            HandGesturePose.OPEN_PALM, HandGesturePose.PALM_FRONT -> {
                // Expressive splayed front palm + 4 fingers + thumb + inner palm crease
                canvas.drawOval(RectF(-9f, -10f, 10f, 10f), fill)
                listOf(-12f to 18f, -5f to 22f, 3f to 21f, 10f to 17f).forEach { (fy, fx) ->
                    canvas.drawRoundRect(RectF(2f, fy - 3f, fx, fy + 3f), 3f, 3f, fill)
                    canvas.drawRoundRect(RectF(2f, fy - 3f, fx, fy + 3f), 3f, 3f, handOutline)
                }
                canvas.drawRoundRect(RectF(-4f, -18f, 6f, -7f), 3f, 3f, fill)
                canvas.drawRoundRect(RectF(-4f, -18f, 6f, -7f), 3f, 3f, handOutline)
                canvas.drawOval(RectF(-9f, -10f, 10f, 10f), handOutline)
                if (pose == HandGesturePose.PALM_FRONT) {
                    canvas.drawArc(RectF(-4f, -5f, 7f, 6f), 20f, 140f, false, handOutline)
                }
            }
            HandGesturePose.PALM_BACK -> {
                // Back-of-hand dorsal silhouette with subtle knuckle ticks
                val backFill = Paint(fill).apply { color = darkenArgb(skinColor.toLong(), 0.94f) }
                canvas.drawRoundRect(RectF(-10f, -10f, 12f, 10f), 7f, 7f, backFill)
                listOf(-11f to 19f, -4f to 22f, 3f to 21f, 9f to 16f).forEach { (fy, fx) ->
                    canvas.drawRoundRect(RectF(4f, fy - 2.6f, fx, fy + 2.6f), 2.6f, 2.6f, backFill)
                    canvas.drawRoundRect(RectF(4f, fy - 2.6f, fx, fy + 2.6f), 2.6f, 2.6f, handOutline)
                }
                canvas.drawRoundRect(RectF(-10f, -10f, 12f, 10f), 7f, 7f, handOutline)
                canvas.drawLine(3f, -6f, 3f, 6f, handOutline)
            }
            HandGesturePose.PALM_UP_OPEN -> {
                // Supinated Palm-Up open receiving hand
                val upPath = Path().apply {
                    moveTo(-10f, 4f); quadTo(2f, 12f, 22f, 2f); lineTo(24f, -4f); quadTo(6f, 2f, -10f, -4f); close()
                }
                canvas.drawPath(upPath, fill); canvas.drawPath(upPath, handOutline)
                canvas.drawRoundRect(RectF(-2f, -11f, 12f, -4f), 3f, 3f, fill)
                canvas.drawRoundRect(RectF(-2f, -11f, 12f, -4f), 3f, 3f, handOutline)
            }
            HandGesturePose.CUPPED_DRINKING_WATER -> {
                // Deeply cupped hand holding shimmering drinking water (authentic Indian/Bengali folk storytelling!)
                val cupPath = Path().apply {
                    moveTo(-11f, -3f)
                    quadTo(0f, 16f, 21f, 6f)
                    quadTo(26f, -3f, 18f, -8f)
                    quadTo(8f, 3f, -11f, -3f)
                    close()
                }
                canvas.drawPath(cupPath, fill)
                val waterFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xCC38BDF8.toInt()
                    alpha = (alphaInt * 0.85f).toInt()
                }
                canvas.drawOval(RectF(-3f, -4f, 17f, 5f), waterFill)
                canvas.drawPath(cupPath, handOutline)
                canvas.drawArc(RectF(-4f, 0f, 16f, 11f), 15f, 145f, false, handOutline)
            }
            HandGesturePose.POINTING -> {
                // Curled palm + extended index pointing finger
                canvas.drawCircle(0f, 2f, 10f, fill)
                canvas.drawRoundRect(RectF(4f, -9f, 26f, -2f), 3.5f, 3.5f, fill)
                canvas.drawRoundRect(RectF(4f, -9f, 26f, -2f), 3.5f, 3.5f, handOutline)
                canvas.drawCircle(0f, 2f, 10f, handOutline)
            }
            HandGesturePose.NAMASTE -> {
                // Respectful Indian / Bengali folded upright palm blade
                val palm = Path().apply {
                    moveTo(-8f, -4f); lineTo(18f, -14f); lineTo(24f, -6f); lineTo(12f, 10f); lineTo(-8f, 8f); close()
                }
                canvas.drawPath(palm, fill); canvas.drawPath(palm, handOutline)
                canvas.drawLine(0f, -2f, 18f, -8f, handOutline)
            }
            HandGesturePose.FIST -> {
                canvas.drawRoundRect(RectF(-11f, -11f, 13f, 11f), 6f, 6f, fill)
                canvas.drawRoundRect(RectF(-11f, -11f, 13f, 11f), 6f, 6f, handOutline)
                canvas.drawLine(-4f, -2f, 10f, -2f, handOutline)
                canvas.drawLine(-4f, 4f, 10f, 4f, handOutline)
            }
            HandGesturePose.THUMBS_UP -> {
                canvas.drawRoundRect(RectF(-10f, -6f, 11f, 11f), 5f, 5f, fill)
                canvas.drawRoundRect(RectF(-4f, -24f, 5f, -3f), 4f, 4f, fill)
                canvas.drawRoundRect(RectF(-4f, -24f, 5f, -3f), 4f, 4f, handOutline)
                canvas.drawRoundRect(RectF(-10f, -6f, 11f, 11f), 5f, 5f, handOutline)
            }
            HandGesturePose.HOLDING_PROP -> {
                canvas.drawCircle(0f, 0f, 11.5f, fill)
                canvas.drawCircle(0f, 0f, 11.5f, handOutline)
                canvas.drawArc(RectF(-8f, -8f, 8f, 8f), 20f, 140f, false, handOutline)
            }
        }
        canvas.restore()
    }

    /**
     * Renders any built-in Hand Prop or Custom Imported PNG attached directly to a character's Left or Right Hand bone!
     */
    private fun drawHandProp(
        canvas: Canvas,
        handBone: SolvedBone,
        propKindName: String,
        customImagePath: String?,
        propScale: Float,
        flipped: Boolean,
        alphaInt: Int,
        tintColorArgb: Long?,
        frame: Int
    ) {
        val propKind = runCatching { HandPropKind.valueOf(propKindName) }.getOrDefault(HandPropKind.NONE)
        if (propKind == HandPropKind.NONE && customImagePath.isNullOrBlank()) return

        val boneAngleDeg = Math.toDegrees(
            atan2((handBone.end.y - handBone.start.y).toDouble(), (handBone.end.x - handBone.start.x).toDouble())
        ).toFloat()

        canvas.save()
        canvas.translate(handBone.end.x, handBone.end.y)
        canvas.rotate(boneAngleDeg + 90f)
        canvas.scale(if (flipped) -propScale else propScale, propScale)

        // Custom imported PNG takes priority when attached
        if (!customImagePath.isNullOrBlank()) {
            val bmp = getCachedBitmap(customImagePath)
            if (bmp != null) {
                val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = alphaInt
                    if (tintColorArgb != null) colorFilter = buildTintColorFilter(tintColorArgb)
                }
                val maxDim = 92f
                val aspect = bmp.width.toFloat() / bmp.height.coerceAtLeast(1).toFloat()
                val drawW = if (aspect >= 1f) maxDim else maxDim * aspect
                val drawH = if (aspect >= 1f) maxDim / aspect else maxDim
                canvas.drawBitmap(bmp, null, RectF(-drawW / 2f, -drawH * 0.85f, drawW / 2f, drawH * 0.15f), imgPaint)
            }
            canvas.restore()
            return
        }

        fun pFill(argb: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = (tintColorArgb ?: argb).toInt()
            alpha = alphaInt
        }
        val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = (tintColorArgb ?: 0xFF0F172AL).toInt()
            strokeWidth = 3.2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            alpha = alphaInt
        }

        when (propKind) {
            HandPropKind.SWORD -> {
                val blade = Path().apply {
                    moveTo(-7f, -12f); lineTo(-6f, -94f); lineTo(0f, -112f); lineTo(6f, -94f); lineTo(7f, -12f); close()
                }
                canvas.drawPath(blade, pFill(0xFFE2E8F0L)); canvas.drawPath(blade, outline)
                canvas.drawLine(0f, -14f, 0f, -96f, Paint(outline).apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f })
                canvas.drawRoundRect(RectF(-18f, -16f, 18f, -7f), 4f, 4f, pFill(0xFFFBBF24L))
                canvas.drawRoundRect(RectF(-18f, -16f, 18f, -7f), 4f, 4f, outline)
                canvas.drawRoundRect(RectF(-5f, -7f, 5f, 16f), 4f, 4f, pFill(0xFF78350FL))
                canvas.drawRoundRect(RectF(-5f, -7f, 5f, 16f), 4f, 4f, outline)
            }
            HandPropKind.MIC -> {
                canvas.drawRoundRect(RectF(-5f, -34f, 5f, 14f), 4f, 4f, pFill(0xFF1E293BL))
                canvas.drawRoundRect(RectF(-5f, -34f, 5f, 14f), 4f, 4f, outline)
                canvas.drawCircle(0f, -44f, 14f, pFill(0xFF94A3B8L))
                canvas.drawCircle(0f, -44f, 14f, outline)
                canvas.drawLine(-13f, -44f, 13f, -44f, Paint(outline).apply { strokeWidth = 2.5f })
                canvas.drawCircle(0f, -16f, 3f, pFill(0xFFEF4444L))
            }
            HandPropKind.FLASHLIGHT -> {
                if (tintColorArgb == null) {
                    val beam = Path().apply {
                        moveTo(-10f, -42f); lineTo(10f, -42f); lineTo(58f, -210f); lineTo(-58f, -210f); close()
                    }
                    val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = LinearGradient(0f, -42f, 0f, -210f, 0x88FEF08A.toInt(), 0x00FEF08A, Shader.TileMode.CLAMP)
                    }
                    canvas.drawPath(beam, beamPaint)
                }
                canvas.drawRoundRect(RectF(-7f, -32f, 7f, 16f), 5f, 5f, pFill(0xFF334155L))
                canvas.drawRoundRect(RectF(-7f, -32f, 7f, 16f), 5f, 5f, outline)
                canvas.drawRoundRect(RectF(-12f, -44f, 12f, -30f), 4f, 4f, pFill(0xFFFBBF24L))
                canvas.drawRoundRect(RectF(-12f, -44f, 12f, -30f), 4f, 4f, outline)
            }
            HandPropKind.MAGIC_WAND -> {
                canvas.drawRoundRect(RectF(-4f, -72f, 4f, 14f), 3f, 3f, pFill(0xFF7C3AEDL))
                canvas.drawRoundRect(RectF(-4f, -72f, 4f, 14f), 3f, 3f, outline)
                val pulse = 1f + 0.14f * sin(frame * 0.35).toFloat()
                canvas.save()
                canvas.translate(0f, -78f); canvas.scale(pulse, pulse)
                if (tintColorArgb == null) {
                    canvas.drawCircle(0f, 0f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FDE047 })
                }
                val star = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 16f else 7f
                    val a = (i * PI / 5.0) - PI / 2.0
                    val sx = (cos(a) * r).toFloat(); val sy = (sin(a) * r).toFloat()
                    if (i == 0) star.moveTo(sx, sy) else star.lineTo(sx, sy)
                }
                star.close()
                canvas.drawPath(star, pFill(0xFFFDE047L)); canvas.drawPath(star, outline)
                canvas.restore()
            }
            HandPropKind.PHONE -> {
                canvas.drawRoundRect(RectF(-15f, -46f, 15f, 4f), 6f, 6f, pFill(0xFF0F172AL))
                canvas.drawRoundRect(RectF(-15f, -46f, 15f, 4f), 6f, 6f, outline)
                canvas.drawRoundRect(RectF(-12f, -41f, 12f, -4f), 3f, 3f, pFill(0xFF38BDF8L))
                canvas.drawCircle(0f, -1f, 2f, pFill(0xFF94A3B8L))
            }
            HandPropKind.HORROR_AXE -> {
                canvas.drawRoundRect(RectF(-5f, -88f, 5f, 18f), 4f, 4f, pFill(0xFF57534EL))
                canvas.drawRoundRect(RectF(-5f, -88f, 5f, 18f), 4f, 4f, outline)
                val axeHead = Path().apply {
                    moveTo(2f, -84f); quadTo(36f, -92f, 36f, -54f); quadTo(18f, -52f, 2f, -64f); close()
                }
                canvas.drawPath(axeHead, pFill(0xFFCBD5E1L)); canvas.drawPath(axeHead, outline)
                val edgeTint = Path().apply {
                    moveTo(24f, -86f); quadTo(36f, -72f, 32f, -56f); lineTo(24f, -60f); close()
                }
                canvas.drawPath(edgeTint, pFill(0xFFDC2626L))
            }
            HandPropKind.LANTERN -> {
                if (tintColorArgb == null) {
                    val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        shader = RadialGradient(0f, -26f, 64f, 0x88FB923C.toInt(), 0x00FB923C, Shader.TileMode.CLAMP)
                    }
                    canvas.drawCircle(0f, -26f, 64f, glow)
                }
                canvas.drawArc(RectF(-10f, -56f, 10f, -38f), 180f, 180f, false, outline)
                canvas.drawRoundRect(RectF(-15f, -44f, 15f, -10f), 6f, 6f, pFill(0xFFFEF08AL))
                canvas.drawRoundRect(RectF(-15f, -44f, 15f, -10f), 6f, 6f, outline)
                canvas.drawRect(RectF(-18f, -48f, 18f, -42f), pFill(0xFF1E293BL))
                canvas.drawRect(RectF(-18f, -12f, 18f, -6f), pFill(0xFF1E293BL))
            }
            HandPropKind.COFFEE -> {
                canvas.drawRoundRect(RectF(-13f, -34f, 13f, 2f), 5f, 5f, pFill(0xFFFFFFFFL))
                canvas.drawRoundRect(RectF(-13f, -34f, 13f, 2f), 5f, 5f, outline)
                canvas.drawRect(RectF(-12f, -22f, 12f, -10f), pFill(0xFFB45309L))
                canvas.drawRoundRect(RectF(-15f, -40f, 15f, -32f), 4f, 4f, pFill(0xFF334155L))
                canvas.drawRoundRect(RectF(-15f, -40f, 15f, -32f), 4f, 4f, outline)
            }
            HandPropKind.SIGN -> {
                canvas.drawRoundRect(RectF(-4f, -44f, 4f, 14f), 3f, 3f, pFill(0xFF92400EL))
                canvas.drawRoundRect(RectF(-4f, -44f, 4f, 14f), 3f, 3f, outline)
                canvas.drawRoundRect(RectF(-38f, -86f, 38f, -40f), 10f, 10f, pFill(0xFFEF4444L))
                canvas.drawRoundRect(RectF(-38f, -86f, 38f, -40f), 10f, 10f, outline)
                val subText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = 18f
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    alpha = alphaInt
                }
                canvas.drawText("SUB!", 0f, -57f, subText)
            }
            HandPropKind.NONE -> Unit
        }
        canvas.restore()
    }

    private fun drawMotionPathOverlay(
        canvas: Canvas,
        points: List<Vec2>,
        isSelected: Boolean,
        currentProgress: Float? = null
    ) {
        if (points.size < 2) return
        val smoothPts = InterpolationEngine.buildSmoothSplinePoints(points, subdivisionsPerSegment = 12)
        val path = Path().apply {
            moveTo(smoothPts[0].x, smoothPts[0].y)
            for (i in 1 until smoothPts.size) lineTo(smoothPts[i].x, smoothPts[i].y)
        }

        // Soft glow under path for visibility over dark & bright cartoons
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isSelected) 0x55FF6B35 else 0x44A78BFA
            style = Paint.Style.STROKE
            strokeWidth = 9f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        canvas.drawPath(path, glowPaint)

        val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isSelected) 0xFFFF6B35.toInt() else 0xFFA78BFA.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            strokeCap = Paint.Cap.ROUND
            pathEffect = DashPathEffect(floatArrayOf(14f, 9f), 0f)
        }
        canvas.drawPath(path, pathPaint)

        // Direction chevrons at 25%, 50%, 75% along the smooth curve
        val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFE066.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 3f
            strokeCap = Paint.Cap.ROUND
        }
        listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
            val s = InterpolationEngine.sampleSmoothPath(points, frac)
            canvas.save()
            canvas.translate(s.position.x, s.position.y)
            canvas.rotate(s.tangentAngleDeg)
            canvas.drawLine(-8f, -6f, 4f, 0f, arrowPaint)
            canvas.drawLine(-8f, 6f, 4f, 0f, arrowPaint)
            canvas.restore()
        }

        // Start (emerald) & End (coral) anchor dots + subtle intermediate waypoints
        val waypointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xBBFBBF24.toInt(); style = Paint.Style.FILL }
        val step = (points.size / 14).coerceAtLeast(1)
        for (i in 1 until points.lastIndex step step) {
            canvas.drawCircle(points[i].x, points[i].y, 4.5f, waypointPaint)
        }
        val startPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF34D399.toInt(); style = Paint.Style.FILL }
        val endPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFB7185.toInt(); style = Paint.Style.FILL }
        val whiteStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.5f }
        canvas.drawCircle(points.first().x, points.first().y, 8f, startPaint)
        canvas.drawCircle(points.first().x, points.first().y, 8f, whiteStroke)
        canvas.drawCircle(points.last().x, points.last().y, 8f, endPaint)
        canvas.drawCircle(points.last().x, points.last().y, 8f, whiteStroke)

        // Live playhead marker showing exact position along path at current frame
        if (currentProgress != null) {
            val curSample = InterpolationEngine.sampleSmoothPath(points, currentProgress)
            val markerGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x662DD4BF; style = Paint.Style.FILL }
            val markerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2DD4BF.toInt(); style = Paint.Style.FILL }
            canvas.drawCircle(curSample.position.x, curSample.position.y, 15f, markerGlow)
            canvas.drawCircle(curSample.position.x, curSample.position.y, 8f, markerFill)
            canvas.drawCircle(curSample.position.x, curSample.position.y, 8f, whiteStroke)
        }
    }

    private fun drawSceneVfx(
        canvas: Canvas,
        activeVfx: List<String>,
        w: Float,
        h: Float,
        frame: Int
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        activeVfx.forEach { name ->
            when (runCatching { SceneVfxType.valueOf(name) }.getOrNull()) {
                SceneVfxType.FIREFLIES -> {
                    val rng = Random(101)
                    repeat(28) { i ->
                        val bx = rng.nextFloat() * w
                        val by = rng.nextFloat() * h
                        val fx = (bx + sin((frame + i * 7) * 0.08) * 38f).toFloat()
                        val fy = (by + cos((frame + i * 5) * 0.06) * 28f).toFloat()
                        val pulse = (0.45f + 0.55f * sin((frame + i * 11) * 0.16).toFloat()).coerceIn(0.15f, 1f)
                        paint.style = Paint.Style.FILL
                        paint.color = Color.argb((pulse * 80).toInt(), 251, 191, 36)
                        canvas.drawCircle(fx, fy, 16f, paint)
                        paint.color = Color.argb((pulse * 240).toInt(), 254, 240, 138)
                        canvas.drawCircle(fx, fy, 4.5f, paint)
                    }
                }
                SceneVfxType.FLOWER_PETALS -> {
                    val rng = Random(202)
                    repeat(32) { i ->
                        val startX = rng.nextFloat() * w
                        val startY = rng.nextFloat() * h
                        val px = (startX + frame * (2.5f + i % 3) + sin((frame + i * 9) * 0.12) * 24f).toFloat() % (w + 40f) - 20f
                        val py = (startY + frame * (4.2f + (i % 4))) % (h + 40f) - 20f
                        paint.style = Paint.Style.FILL
                        paint.color = if (i % 2 == 0) 0xDDF9A8D4.toInt() else 0xDDFBCFE8.toInt()
                        canvas.save()
                        canvas.translate(px, py)
                        canvas.rotate((frame * 5 + i * 25).toFloat())
                        canvas.drawOval(RectF(-9f, -5f, 9f, 5f), paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.SUNBEAMS -> {
                    paint.style = Paint.Style.FILL
                    val beamAlpha = (36 + 12 * sin(frame * 0.06)).toInt()
                    paint.shader = LinearGradient(0f, 0f, w * 0.7f, h, Color.argb(beamAlpha, 254, 240, 138), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    listOf(0.12f, 0.36f, 0.62f).forEach { startFrac ->
                        val p = Path().apply {
                            moveTo(w * startFrac, 0f)
                            lineTo(w * (startFrac + 0.12f), 0f)
                            lineTo(w * (startFrac + 0.34f), h)
                            lineTo(w * (startFrac + 0.16f), h)
                            close()
                        }
                        canvas.drawPath(p, paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.HIGH_SUNLIGHT -> {
                    val sunX = w * 0.84f
                    val sunY = h * 0.16f
                    val pulse = (1f + 0.06f * sin(frame * 0.08)).toFloat()

                    // Warm atmospheric sunlight wash
                    paint.style = Paint.Style.FILL
                    paint.shader = RadialGradient(
                        sunX, sunY, max(w, h) * 0.95f,
                        intArrayOf(0x99FFFBEB.toInt(), 0x55FDE047, 0x22FB923C, 0x00FDE047),
                        floatArrayOf(0f, 0.22f, 0.55f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null

                    // Rotating volumetric golden god-rays radiating from sun orb
                    val rayCount = 12
                    val rayLen = hypot(w, h) * 1.05f
                    val baseRot = (frame * 0.45f) % 360f
                    paint.shader = RadialGradient(
                        sunX, sunY, rayLen * 0.78f,
                        0x4AFEF08A, 0x00FEF08A, Shader.TileMode.CLAMP
                    )
                    for (i in 0 until rayCount) {
                        val angleDeg = baseRot + i * (360f / rayCount)
                        val a1 = Math.toRadians((angleDeg - 6.5f).toDouble())
                        val a2 = Math.toRadians((angleDeg + 6.5f).toDouble())
                        val rayPath = Path().apply {
                            moveTo(sunX, sunY)
                            lineTo(sunX + cos(a1).toFloat() * rayLen, sunY + sin(a1).toFloat() * rayLen)
                            lineTo(sunX + cos(a2).toFloat() * rayLen, sunY + sin(a2).toFloat() * rayLen)
                            close()
                        }
                        canvas.drawPath(rayPath, paint)
                    }
                    paint.shader = null

                    // Radiant sun corona & crisp bright core
                    paint.shader = RadialGradient(
                        sunX, sunY, 130f * pulse,
                        intArrayOf(0xFFFFFFFF.toInt(), 0xEEFEF08A.toInt(), 0x44FACC15, 0x00FACC15),
                        floatArrayOf(0f, 0.34f, 0.68f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawCircle(sunX, sunY, 130f * pulse, paint)
                    paint.shader = null

                    // Cinematic circular lens-flare bokeh rings along diagonal towards bottom-left
                    val centerX = w * 0.5f
                    val centerY = h * 0.5f
                    val dx = centerX - sunX
                    val dy = centerY - sunY
                    listOf(
                        Triple(0.45f, 34f, 0x38FEF08A),
                        Triple(0.85f, 22f, 0x35FDBA74),
                        Triple(1.22f, 52f, 0x2AFDE047),
                        Triple(1.55f, 18f, 0x40FFFFFF)
                    ).forEach { (frac, r, col) ->
                        val fx = sunX + dx * frac + sin(frame * 0.05 + frac * 4f).toFloat() * 4f
                        val fy = sunY + dy * frac
                        paint.style = Paint.Style.FILL
                        paint.color = col
                        canvas.drawCircle(fx, fy, r * pulse, paint)
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 2f
                        paint.color = 0x44FFFBEB
                        canvas.drawCircle(fx, fy, r * pulse, paint)
                    }
                }
                SceneVfxType.GOLDEN_HOUR -> {
                    paint.style = Paint.Style.FILL
                    paint.shader = LinearGradient(
                        0f, 0f, 0f, h,
                        intArrayOf(0x55FB923C, 0x3AFBBF24, 0x18FDE68A, 0x38EA580C),
                        floatArrayOf(0f, 0.38f, 0.72f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null
                    // Shimmering floating golden bokeh dust motes
                    val rng = Random(808)
                    repeat(30) { i ->
                        val mx = ((rng.nextFloat() * w + frame * (0.8f + i % 3) + sin((frame + i * 9) * 0.07) * 18f).toFloat() % w + w) % w
                        val my = ((rng.nextFloat() * h - frame * (0.5f + (i % 2) * 0.6f)) % h + h) % h
                        val glow = (0.4f + 0.6f * sin((frame + i * 13) * 0.12).toFloat()).coerceIn(0.2f, 1f)
                        paint.color = Color.argb((glow * 95).toInt(), 254, 240, 138)
                        canvas.drawCircle(mx, my, 5f + (i % 6) * 2.5f, paint)
                    }
                }
                SceneVfxType.STORM -> {
                    // 1. Dark storm atmospheric tint
                    paint.style = Paint.Style.FILL
                    paint.shader = LinearGradient(
                        0f, 0f, 0f, h,
                        intArrayOf(0x880F172A.toInt(), 0x441E293B, 0x220F172A),
                        floatArrayOf(0f, 0.45f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null

                    // 2. Rolling dark storm clouds across the top sky
                    val cloudDrift = (frame * 2.8f) % (w + 320f)
                    for (i in 0..6) {
                        val cx = ((i * (w / 5f) + cloudDrift) % (w + 320f)) - 160f
                        val cy = h * (0.06f + (i % 2) * 0.05f)
                        paint.shader = RadialGradient(
                            cx, cy, 175f,
                            0xC81E293B.toInt(), 0x001E293B, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(cx - 210f, cy - 85f, cx + 210f, cy + 75f), paint)
                    }
                    paint.shader = null

                    // 3. Heavy wind-driven slanted storm rain sheets
                    paint.style = Paint.Style.STROKE
                    val rng = Random(909)
                    repeat(110) { i ->
                        val depth = if (i % 3 == 0) 1.35f else 0.85f
                        val rx = ((rng.nextFloat() * w - frame * 18f * depth) % w + w) % w
                        val ry = ((rng.nextFloat() * h + frame * 36f * depth) % h + h) % h
                        paint.strokeWidth = 1.6f * depth
                        paint.color = if (depth > 1f) 0xAABAE6FD.toInt() else 0x6694A3B8
                        canvas.drawLine(rx, ry, rx - 18f * depth, ry + 42f * depth, paint)
                    }

                    // 4. Driving wind mist streaks
                    paint.strokeWidth = 2.4f
                    paint.color = 0x33E2E8F0
                    repeat(10) { i ->
                        val wy = h * (0.18f + (i * 0.08f))
                        val wx = ((w - ((frame * (24f + i * 3) + i * 190f) % (w + 240f))) + 120f)
                        canvas.drawLine(wx, wy, wx - 110f, wy + 18f, paint)
                    }

                    // 5. Ground rain splashes
                    paint.strokeWidth = 1.8f
                    paint.color = 0x88BAE6FD.toInt()
                    repeat(18) { i ->
                        val phase = ((frame + i * 5) % 10) / 10f
                        val sx = ((rng.nextFloat() * w + (frame / 10) * 73f) % w + w) % w
                        val sy = h * (0.86f + (i % 4) * 0.032f)
                        val r = 4f + phase * 16f
                        paint.alpha = ((1f - phase) * 160).toInt().coerceIn(0, 255)
                        canvas.drawOval(RectF(sx - r, sy - r * 0.32f, sx + r, sy + r * 0.32f), paint)
                    }
                    paint.alpha = 255

                    // 6. Periodic thunder & branching lightning bolts
                    val cycle = frame % 44
                    if (cycle == 10 || cycle == 12 || cycle == 33) {
                        paint.style = Paint.Style.FILL
                        paint.color = if (cycle == 10) 0x77E0F2FE else 0x44FFFFFF
                        canvas.drawRect(0f, 0f, w, h, paint)

                        val boltX = if (cycle == 33) w * 0.28f else w * 0.68f
                        val mainBolt = Path().apply {
                            moveTo(boltX, 0f)
                            lineTo(boltX - 32f, h * 0.19f)
                            lineTo(boltX + 20f, h * 0.24f)
                            lineTo(boltX - 42f, h * 0.52f)
                            lineTo(boltX + 14f, h * 0.56f)
                            lineTo(boltX - 24f, h * 0.84f)
                        }
                        val branchBolt = Path().apply {
                            moveTo(boltX + 20f, h * 0.24f)
                            lineTo(boltX + 68f, h * 0.42f)
                            lineTo(boltX + 46f, h * 0.55f)
                        }
                        paint.style = Paint.Style.STROKE
                        paint.strokeCap = Paint.Cap.ROUND
                        paint.strokeWidth = 11f
                        paint.color = 0x8838BDF8.toInt()
                        canvas.drawPath(mainBolt, paint)
                        paint.strokeWidth = 6f
                        canvas.drawPath(branchBolt, paint)
                        paint.strokeWidth = 4f
                        paint.color = Color.WHITE
                        canvas.drawPath(mainBolt, paint)
                        paint.strokeWidth = 2.5f
                        canvas.drawPath(branchBolt, paint)
                    }
                }
                SceneVfxType.RAIN -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.2f
                    paint.color = 0x99BAE6FD.toInt()
                    val rng = Random(303)
                    repeat(62) { i ->
                        val rx = ((rng.nextFloat() * w - frame * 6.5f) % w + w) % w
                        val ry = ((rng.nextFloat() * h + frame * 26f) % h + h) % h
                        canvas.drawLine(rx, ry, rx - 8f, ry + 30f, paint)
                    }
                    // Subtle ground splash ripples
                    paint.strokeWidth = 1.5f
                    repeat(10) { i ->
                        val phase = ((frame + i * 6) % 12) / 12f
                        val sx = ((rng.nextFloat() * w) % w + w) % w
                        val sy = h * (0.88f + (i % 3) * 0.03f)
                        val r = 3f + phase * 12f
                        paint.color = Color.argb(((1f - phase) * 140).toInt().coerceIn(0, 255), 186, 230, 253)
                        canvas.drawOval(RectF(sx - r, sy - r * 0.3f, sx + r, sy + r * 0.3f), paint)
                    }
                }
                SceneVfxType.HEAVY_RAIN -> {
                    // Cool misty rain atmosphere
                    paint.style = Paint.Style.FILL
                    paint.color = 0x260C4A6E
                    canvas.drawRect(0f, 0f, w, h, paint)

                    paint.style = Paint.Style.STROKE
                    val rng = Random(1101)
                    repeat(130) { i ->
                        val near = i % 3 == 0
                        val spd = if (near) 38f else 24f
                        val rx = ((rng.nextFloat() * w - frame * (if (near) 12f else 7f)) % w + w) % w
                        val ry = ((rng.nextFloat() * h + frame * spd) % h + h) % h
                        paint.strokeWidth = if (near) 2.8f else 1.5f
                        paint.color = if (near) 0xBBE0F2FE.toInt() else 0x777DD3FC
                        canvas.drawLine(rx, ry, rx - (if (near) 13f else 8f), ry + (if (near) 44f else 26f), paint)
                    }
                    // Animated puddle splash rings along lower ground
                    repeat(22) { i ->
                        val phase = ((frame + i * 4) % 9) / 9f
                        val sx = ((rng.nextFloat() * w + (frame / 9) * 51f) % w + w) % w
                        val sy = h * (0.84f + (i % 5) * 0.03f)
                        val r = 4f + phase * 18f
                        paint.strokeWidth = 2f
                        paint.color = Color.argb(((1f - phase) * 195).toInt().coerceIn(0, 255), 224, 242, 254)
                        canvas.drawOval(RectF(sx - r, sy - r * 0.3f, sx + r, sy + r * 0.3f), paint)
                    }
                }
                SceneVfxType.SNOW -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xDDFFFFFF.toInt()
                    val rng = Random(404)
                    repeat(54) { i ->
                        val sx = ((rng.nextFloat() * w + sin((frame + i * 5) * 0.07) * 30f).toFloat() % w + w) % w
                        val sy = (rng.nextFloat() * h + frame * (2.5f + i % 3)) % h
                        canvas.drawCircle(sx, sy, 2.5f + (i % 4), paint)
                    }
                }
                SceneVfxType.RAINBOW -> {
                    val shimmer = (0.78f + 0.22f * sin(frame * 0.08)).toFloat()
                    val rainbowBandColors = intArrayOf(
                        0xFFEF4444.toInt(),
                        0xFFF97316.toInt(),
                        0xFFFACC15.toInt(),
                        0xFF22C55E.toInt(),
                        0xFF38BDF8.toInt(),
                        0xFF6366F1.toInt(),
                        0xFFA855F7.toInt()
                    )
                    paint.style = Paint.Style.STROKE
                    val bandW = min(w, h) * 0.028f
                    val baseR = min(w, h) * 0.72f
                    val cx = w * 0.5f
                    val cy = h * 0.88f
                    rainbowBandColors.forEachIndexed { idx, col ->
                        val r = baseR - idx * bandW
                        paint.strokeWidth = bandW + 1.5f
                        paint.color = col
                        paint.alpha = (88 * shimmer).toInt().coerceIn(30, 140)
                        canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 185f, 170f, false, paint)
                    }
                    paint.alpha = 255
                }
                SceneVfxType.AURORA -> {
                    paint.style = Paint.Style.FILL
                    val bands = listOf(
                        Triple(0x5534D399, 0.14f, 0.05f),
                        Triple(0x4A22D3EE, 0.22f, 0.07f),
                        Triple(0x45A855F7, 0.19f, 0.04f)
                    )
                    bands.forEachIndexed { bIdx, (col, yFrac, speed) ->
                        val path = Path()
                        val baseY = h * yFrac
                        val ribbonH = h * 0.24f
                        path.moveTo(0f, baseY)
                        val steps = 16
                        for (s in 0..steps) {
                            val x = w * (s.toFloat() / steps)
                            val wave = sin(s * 0.65 + frame * speed + bIdx * 1.9).toFloat() * (h * 0.06f)
                            path.lineTo(x, baseY + wave)
                        }
                        for (s in steps downTo 0) {
                            val x = w * (s.toFloat() / steps)
                            val wave = sin(s * 0.65 + frame * speed + bIdx * 1.9 + 0.6).toFloat() * (h * 0.05f)
                            path.lineTo(x, baseY + ribbonH + wave)
                        }
                        path.close()
                        paint.shader = LinearGradient(
                            0f, baseY - 20f, 0f, baseY + ribbonH + 20f,
                            intArrayOf(0x00000000, col, 0x00000000),
                            floatArrayOf(0f, 0.45f, 1f),
                            Shader.TileMode.CLAMP
                        )
                        canvas.drawPath(path, paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.AUTUMN_LEAVES -> {
                    // Swirling translucent breeze ribbons
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 2.5f
                    paint.color = 0x44F8FAFC
                    repeat(5) { i ->
                        val gy = h * (0.20f + i * 0.15f)
                        val gx = ((frame * (12f + i * 2) + i * 230f) % (w + 260f)) - 130f
                        val gust = Path().apply {
                            moveTo(gx - 90f, gy)
                            quadTo(gx - 20f, gy - 26f, gx + 60f, gy + 6f)
                            quadTo(gx + 100f, gy + 20f, gx + 125f, gy - 12f)
                        }
                        canvas.drawPath(gust, paint)
                    }
                    // Tumbling autumn leaves
                    val leafColors = intArrayOf(
                        0xEEF97316.toInt(),
                        0xEEF59E0B.toInt(),
                        0xEEDC2626.toInt(),
                        0xEEEAB308.toInt()
                    )
                    paint.style = Paint.Style.FILL
                    val rng = Random(1202)
                    repeat(34) { i ->
                        val lx = ((rng.nextFloat() * w + frame * (5.5f + i % 4)) % (w + 50f)) - 25f
                        val ly = ((rng.nextFloat() * h + frame * (2.6f + i % 3) + sin((frame + i * 7) * 0.14) * 26f).toFloat() % (h + 50f)) - 25f
                        paint.color = leafColors[i % leafColors.size]
                        canvas.save()
                        canvas.translate(lx, ly)
                        canvas.rotate((frame * (6f + i % 4) + i * 33f) % 360f)
                        val leaf = Path().apply {
                            moveTo(-11f, 0f)
                            quadTo(0f, -9f, 12f, 0f)
                            quadTo(0f, 9f, -11f, 0f)
                            close()
                        }
                        canvas.drawPath(leaf, paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.STARLIGHT -> {
                    val rng = Random(1303)
                    paint.style = Paint.Style.FILL
                    repeat(42) { i ->
                        val sx = rng.nextFloat() * w
                        val sy = rng.nextFloat() * h * 0.78f
                        val twinkle = (0.3f + 0.7f * sin((frame + i * 9) * 0.22).toFloat()).coerceIn(0.15f, 1f)
                        val r = (3.5f + (i % 4) * 2.2f) * twinkle
                        paint.color = Color.argb((twinkle * 245).toInt(), 255, 251, 235)
                        // 4-point cartoon sparkle star
                        val star = Path().apply {
                            moveTo(sx, sy - r * 1.6f)
                            lineTo(sx + r * 0.42f, sy - r * 0.42f)
                            lineTo(sx + r * 1.6f, sy)
                            lineTo(sx + r * 0.42f, sy + r * 0.42f)
                            lineTo(sx, sy + r * 1.6f)
                            lineTo(sx - r * 0.42f, sy + r * 0.42f)
                            lineTo(sx - r * 1.6f, sy)
                            lineTo(sx - r * 0.42f, sy - r * 0.42f)
                            close()
                        }
                        canvas.drawPath(star, paint)
                    }
                    // Shooting star every 36 frames
                    val shootFrame = frame % 36
                    if (shootFrame in 4..16) {
                        val t = (shootFrame - 4) / 12f
                        val headX = w * (0.18f + t * 0.62f)
                        val headY = h * (0.10f + t * 0.28f)
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 3.5f
                        paint.strokeCap = Paint.Cap.ROUND
                        paint.shader = LinearGradient(
                            headX, headY, headX - 110f, headY - 48f,
                            0xFFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP
                        )
                        canvas.drawLine(headX, headY, headX - 110f, headY - 48f, paint)
                        paint.shader = null
                    }
                }
                SceneVfxType.FIRE_EMBERS -> {
                    // Subtle warm furnace glow along bottom
                    paint.style = Paint.Style.FILL
                    paint.shader = LinearGradient(
                        0f, h, 0f, h * 0.62f,
                        0x55EA580C, 0x00EA580C, Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, h * 0.62f, w, h, paint)
                    paint.shader = null

                    val rng = Random(1404)
                    repeat(45) { i ->
                        val ex = ((rng.nextFloat() * w + sin((frame + i * 6) * 0.11) * 32f).toFloat() % w + w) % w
                        val ey = ((rng.nextFloat() * h - frame * (4.2f + i % 4)) % h + h) % h
                        val life = (ey / h).coerceIn(0.1f, 1f)
                        val r = 2.2f + (i % 4) * 1.2f
                        paint.color = Color.argb((life * 110).toInt(), 249, 115, 22)
                        canvas.drawCircle(ex, ey, r * 3.1f, paint)
                        paint.color = Color.argb((life * 245).toInt(), 254, 240, 138)
                        canvas.drawCircle(ex, ey, r, paint)
                    }
                }
                SceneVfxType.SPOOKY_FOG -> {
                    paint.style = Paint.Style.FILL
                    val drift1 = (frame * 2.4f) % (w + 380f)
                    val drift2 = (frame * 1.3f) % (w + 420f)
                    for (i in 0..5) {
                        val fx = ((i * (w / 4f) + drift1) % (w + 360f)) - 180f
                        val fy = h * (0.76f + (i % 2) * 0.08f)
                        paint.shader = RadialGradient(
                            fx, fy, 190f,
                            0x48CBD5E1, 0x00CBD5E1, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(fx - 220f, fy - 75f, fx + 220f, fy + 75f), paint)
                    }
                    for (i in 0..3) {
                        val fx = w - (((i * (w / 3f) + drift2) % (w + 360f)) - 180f)
                        val fy = h * 0.88f
                        paint.shader = RadialGradient(
                            fx, fy, 220f,
                            0x55E2E8F0, 0x00E2E8F0, Shader.TileMode.CLAMP
                        )
                        canvas.drawOval(RectF(fx - 260f, fy - 90f, fx + 260f, fy + 90f), paint)
                    }
                    paint.shader = null
                }
                SceneVfxType.LIGHTNING_FLASH -> {
                    val cycle = frame % 48
                    if (cycle == 14 || cycle == 16 || cycle == 39) {
                        paint.style = Paint.Style.FILL
                        paint.color = if (cycle == 14) 0x88E0F2FE.toInt() else 0x55FFFFFF.toInt()
                        canvas.drawRect(0f, 0f, w, h, paint)

                        val boltX = if (cycle == 39) w * 0.25f else w * 0.72f
                        val boltPath = Path().apply {
                            moveTo(boltX, 0f)
                            lineTo(boltX - 28f, h * 0.22f)
                            lineTo(boltX + 18f, h * 0.26f)
                            lineTo(boltX - 36f, h * 0.56f)
                            lineTo(boltX + 12f, h * 0.58f)
                            lineTo(boltX - 18f, h * 0.82f)
                        }
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 10f
                        paint.color = 0x9938BDF8.toInt()
                        canvas.drawPath(boltPath, paint)
                        paint.strokeWidth = 4f
                        paint.color = Color.WHITE
                        canvas.drawPath(boltPath, paint)
                    }
                }
                SceneVfxType.VIGNETTE_HORROR -> {
                    paint.style = Paint.Style.FILL
                    val r = hypot(w, h) * 0.62f
                    paint.shader = RadialGradient(
                        w / 2f, h / 2f, r,
                        intArrayOf(0x00000000, 0x22000000, 0xCC020617.toInt()),
                        floatArrayOf(0.38f, 0.72f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.drawRect(0f, 0f, w, h, paint)
                    paint.shader = null
                }
                SceneVfxType.CONFETTI_POP -> {
                    paint.style = Paint.Style.FILL
                    val colors = intArrayOf(
                        0xFFFF6B35.toInt(), 0xFF2DD4BF.toInt(), 0xFFFBBF24.toInt(),
                        0xFFA78BFA.toInt(), 0xFFFB7185.toInt(), 0xFF34D399.toInt()
                    )
                    val rng = Random(707)
                    repeat(46) { i ->
                        val cx = (rng.nextFloat() * w + sin((frame + i * 7) * 0.1) * 28f).toFloat()
                        val cy = (rng.nextFloat() * h + frame * (4.5f + i % 4)) % h
                        paint.color = colors[i % colors.size]
                        canvas.save()
                        canvas.translate(cx, cy)
                        canvas.rotate((frame * (7f + i % 5) + i * 25f) % 360f)
                        canvas.drawRect(-7f, -4f, 7f, 4f, paint)
                        canvas.restore()
                    }
                }
                SceneVfxType.CINEMA_BARS -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xFF000000.toInt()
                    val barH = h * 0.105f
                    canvas.drawRect(0f, 0f, w, barH, paint)
                    canvas.drawRect(0f, h - barH, w, h, paint)
                }
                SceneVfxType.SPEED_LINES -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 3f
                    paint.color = 0xAAFFFFFF.toInt()
                    val cx = w / 2f; val cy = h / 2f
                    val outerR = hypot(cx, cy) * 1.15f
                    val rng = Random(505 + frame / 2)
                    repeat(36) {
                        val a = rng.nextFloat() * 2f * PI.toFloat()
                        val innerR = outerR * (0.48f + rng.nextFloat() * 0.22f)
                        canvas.drawLine(
                            cx + cos(a) * innerR, cy + sin(a) * innerR,
                            cx + cos(a) * outerR, cy + sin(a) * outerR,
                            paint
                        )
                    }
                }
                null -> Unit
            }
        }
    }

    private fun drawColorGradeOverlay(
        canvas: Canvas,
        gradeName: String,
        w: Float,
        h: Float,
        frame: Int
    ) {
        val grade = runCatching { SceneColorGrade.valueOf(gradeName) }.getOrDefault(SceneColorGrade.NONE)
        if (grade == SceneColorGrade.NONE) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (grade) {
            SceneColorGrade.HORROR_COLD -> {
                paint.color = 0x380B253A
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0x3304141D, 0x44020617, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.NIGHT_BLUE -> {
                paint.color = 0x480F172A
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.WARM_SUNSET -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0x30FB923C, 0x26F43F5E, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.VINTAGE_VHS -> {
                paint.color = 0x2278350F
                canvas.drawRect(0f, 0f, w, h, paint)
                val linePaint = Paint().apply { color = 0x22000000; strokeWidth = 2f }
                var y = 0f
                while (y < h) {
                    canvas.drawLine(0f, y, w, y, linePaint)
                    y += 6f
                }
                // Rolling VHS tracking bar + REC timestamp
                val trackY = (frame * 11f) % h
                paint.color = 0x1EFFFFFF
                canvas.drawRect(0f, trackY, w, trackY + 18f, paint)
                val recPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xDDFF3B30.toInt()
                    textSize = (h * 0.036f).coerceIn(18f, 34f)
                    typeface = Typeface.MONOSPACE
                }
                if ((frame / 12) % 2 == 0) {
                    canvas.drawCircle(38f, 40f, 9f, recPaint)
                }
                recPaint.color = 0xEEFFFFFF.toInt()
                canvas.drawText("PLAY  VHS", 56f, 48f, recPaint)
            }
            SceneColorGrade.NOIR_BW -> {
                paint.color = 0x660B0F17
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w, h) * 0.58f,
                    0x00000000, 0xAA000000.toInt(), Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            SceneColorGrade.NONE -> Unit
        }
    }

    private fun drawSubtitles(
        canvas: Canvas,
        subtitles: List<SubtitleCue>,
        frame: Int,
        w: Float,
        h: Float
    ) {
        val active = subtitles.lastOrNull { frame in it.startFrame..it.endFrame } ?: return
        val subStyle = runCatching { SubtitleStyle.valueOf(active.style) }.getOrDefault(SubtitleStyle.YOUTUBE_BOLD)
        val ageFrames = (frame - active.startFrame).coerceAtLeast(0)
        // Snappy YouTube pop-in bounce over the first 4 frames
        val popScale = when (ageFrames) {
            0 -> 0.82f
            1 -> 1.08f
            2 -> 0.98f
            else -> 1f
        }
        val baseTextSize = (min(w, h) * 0.064f).coerceIn(26f, 64f)
        val displayLine = if (active.speakerName.isNotBlank()) "${active.speakerName}: ${active.text}" else active.text
        val centerX = w / 2f
        val baseY = h * 0.88f

        canvas.save()
        canvas.translate(centerX, baseY)
        canvas.scale(popScale, popScale)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = baseTextSize
            typeface = when (subStyle) {
                SubtitleStyle.YOUTUBE_BOLD, SubtitleStyle.COMIC_BOX -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                SubtitleStyle.HORROR_DRIP -> Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
                SubtitleStyle.CINEMATIC -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
        }
        val textW = textPaint.measureText(displayLine)

        when (subStyle) {
            SubtitleStyle.COMIC_BOX -> {
                val padX = 24f; val padY = 14f
                val boxRect = RectF(-textW / 2f - padX, -baseTextSize - padY * 0.4f, textW / 2f + padX, padY)
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE0F172A.toInt() }
                val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = active.colorArgb.toInt()
                    style = Paint.Style.STROKE
                    strokeWidth = 4f
                }
                canvas.drawRoundRect(boxRect, 14f, 14f, bg)
                canvas.drawRoundRect(boxRect, 14f, 14f, border)
            }
            SubtitleStyle.CINEMATIC -> {
                val padX = 22f; val padY = 10f
                val boxRect = RectF(-textW / 2f - padX, -baseTextSize - padY * 0.3f, textW / 2f + padX, padY)
                val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA000000.toInt() }
                canvas.drawRoundRect(boxRect, 8f, 8f, bg)
            }
            else -> Unit
        }

        // Crisp dark outline + shadow
        val strokePaint = Paint(textPaint).apply {
            color = 0xFF000000.toInt()
            style = Paint.Style.STROKE
            strokeWidth = if (subStyle == SubtitleStyle.YOUTUBE_BOLD || subStyle == SubtitleStyle.HORROR_DRIP) 10f else 5f
            strokeJoin = Paint.Join.ROUND
        }
        canvas.drawText(displayLine, 0f, 0f, strokePaint)

        textPaint.style = Paint.Style.FILL
        textPaint.color = if (subStyle == SubtitleStyle.HORROR_DRIP) 0xFFFF3B5C.toInt() else active.colorArgb.toInt()
        canvas.drawText(displayLine, 0f, 0f, textPaint)
        canvas.restore()
    }

    private fun drawBackgroundTemplate(
        canvas: Canvas,
        templateName: String,
        bgColorArgb: Long,
        w: Float,
        h: Float,
        panX: Float,
        panY: Float,
        frame: Int
    ) {
        val template = runCatching { BackgroundTemplate.valueOf(templateName) }.getOrDefault(BackgroundTemplate.SOLID)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (template) {
            BackgroundTemplate.SOLID -> {
                paint.color = bgColorArgb.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            BackgroundTemplate.PASTEL_SKY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF93C5FD.toInt(), 0xFFFBCFE8.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Soft pastel drifting clouds
                paint.color = 0xEEFFFFFF.toInt()
                val drift = (frame * 0.8f) % (w + 260f)
                listOf(0.18f to 0.22f, 0.56f to 0.16f, 0.84f to 0.28f).forEach { (xf, yf) ->
                    val cx = (w * xf + drift) % (w + 180f) - 90f - panX * 0.25f
                    val cy = h * yf - panY * 0.2f
                    canvas.drawCircle(cx - 38f, cy, 32f, paint)
                    canvas.drawCircle(cx, cy - 14f, 44f, paint)
                    canvas.drawCircle(cx + 40f, cy, 34f, paint)
                }
                paint.color = 0xFF86EFAC.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.68f, w * 0.8f - panX * 0.5f, h * 1.35f), paint)
                paint.color = 0xFF4ADE80.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.72f, w * 1.3f - panX * 0.7f, h * 1.4f), paint)
            }
            BackgroundTemplate.CHERRY_BLOSSOM -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFFFDE68A.toInt(), 0xFFF9A8D4.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(w * 0.08f - panX * 0.4f, h * 0.35f, w * 0.13f - panX * 0.4f, h * 0.85f, paint)
                paint.color = 0xFFF472B6.toInt()
                canvas.drawCircle(w * 0.12f - panX * 0.4f, h * 0.28f, 125f, paint)
                paint.color = 0xFFFBCFE8.toInt()
                canvas.drawCircle(w * 0.22f - panX * 0.4f, h * 0.32f, 95f, paint)
                paint.color = 0xFF6EE7B7.toInt()
                canvas.drawRect(0f, h * 0.76f, w, h, paint)
            }
            BackgroundTemplate.TWILIGHT_DREAM -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF312E81.toInt(), 0xFFEC4899.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFEF08A.toInt()
                canvas.drawCircle(w * 0.76f - panX * 0.2f, h * 0.24f, 54f, paint)
                paint.color = 0xFF1E1B4B.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.6f, h * 0.66f, w * 1.15f - panX * 0.6f, h * 1.38f), paint)
            }
            BackgroundTemplate.HAUNTED_FOREST -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF040914.toInt(), 0xFF132238.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Eerie glowing full moon
                val moonX = w * 0.74f - (panX * 0.12f) % (w * 0.5f)
                paint.shader = RadialGradient(moonX, h * 0.22f, 150f, 0x55BAE6FD, 0x00BAE6FD, Shader.TileMode.CLAMP)
                canvas.drawCircle(moonX, h * 0.22f, 150f, paint)
                paint.shader = null
                paint.color = 0xFFE2E8F0.toInt()
                canvas.drawCircle(moonX, h * 0.22f, 58f, paint)
                // Seamlessly wrapping silhouettes of twisted dead trees
                val span = w + 320f
                paint.color = 0xFF070D19.toInt()
                for (i in 0..8) {
                    val tx = (((i * (span / 8f) - panX * 0.65f) % span) + span) % span - 160f
                    val treeH = h * (0.48f + (i % 3) * 0.12f)
                    val trunkW = 24f + (i % 3) * 8f
                    canvas.drawRect(tx - trunkW / 2f, h - treeH, tx + trunkW / 2f, h * 0.84f, paint)
                    // Spooky crooked branches
                    val branchP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = 0xFF070D19.toInt()
                        strokeWidth = 9f
                        strokeCap = Paint.Cap.ROUND
                    }
                    canvas.drawLine(tx, h - treeH * 0.72f, tx - 56f, h - treeH * 0.88f, branchP)
                    canvas.drawLine(tx, h - treeH * 0.60f, tx + 62f, h - treeH * 0.78f, branchP)
                }
                // Dark misty ground
                paint.color = 0xFF020617.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
            }
            BackgroundTemplate.SPOOKY_MANSION -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF1A1025.toInt(), 0xFF0B0712.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Repeating haunted hallway pillars & gothic arched windows
                val span = w + 320f
                for (i in 0..4) {
                    val wx = (((i * (span / 4f) - panX * 0.6f) % span) + span) % span - 140f
                    // Gothic moonlight window
                    paint.color = 0xFF1E293B.toInt()
                    canvas.drawRoundRect(RectF(wx - 44f, h * 0.16f, wx + 44f, h * 0.54f), 44f, 44f, paint)
                    paint.color = 0xFF334155.toInt()
                    canvas.drawRect(wx - 3f, h * 0.16f, wx + 3f, h * 0.54f, paint)
                    canvas.drawRect(wx - 44f, h * 0.36f, wx + 44f, h * 0.38f, paint)
                    // Flickering wall torch glow
                    val flicker = 0.85f + 0.15f * sin((frame + i * 7) * 0.6).toFloat()
                    paint.shader = RadialGradient(
                        wx + 110f, h * 0.42f, 90f * flicker,
                        0x66F59E0B, 0x00F59E0B, Shader.TileMode.CLAMP
                    )
                    canvas.drawCircle(wx + 110f, h * 0.42f, 90f * flicker, paint)
                    paint.shader = null
                }
                paint.color = 0xFF1C1329.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0xFF3B0764.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h * 0.77f, paint)
            }
            BackgroundTemplate.COMIC_BURST -> {
                paint.shader = RadialGradient(
                    w / 2f, h / 2f, hypot(w, h) * 0.6f,
                    0xFFFEF08A.toInt(), 0xFFFF6B35.toInt(), Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val cx = w / 2f; val cy = h / 2f
                val r = hypot(w, h)
                val rotOffset = frame * 0.8f
                paint.color = 0x33FFFFFF
                for (i in 0 until 16) {
                    val a1 = Math.toRadians((i * 22.5 + rotOffset))
                    val a2 = Math.toRadians((i * 22.5 + 10.0 + rotOffset))
                    val tri = Path().apply {
                        moveTo(cx, cy)
                        lineTo(cx + (cos(a1) * r).toFloat(), cy + (sin(a1) * r).toFloat())
                        lineTo(cx + (cos(a2) * r).toFloat(), cy + (sin(a2) * r).toFloat())
                        close()
                    }
                    canvas.drawPath(tri, paint)
                }
            }
            BackgroundTemplate.CLASSROOM_STAGE -> {
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                // Classic green chalkboard
                val bx = w * 0.14f - panX * 0.35f
                paint.color = 0xFF78350F.toInt()
                canvas.drawRoundRect(RectF(bx - 12f, h * 0.14f - 12f, bx + w * 0.72f + 12f, h * 0.58f + 12f), 14f, 14f, paint)
                paint.color = 0xFF14532D.toInt()
                canvas.drawRect(bx, h * 0.14f, bx + w * 0.72f, h * 0.58f, paint)
                // Wooden floor
                paint.color = 0xFFB45309.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0xFF92400E.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h * 0.76f, paint)
            }
            BackgroundTemplate.GRID_PAPER -> {
                paint.color = 0xFFF8FAFC.toInt()
                canvas.drawRect(0f, 0f, w, h, paint)
                val gridPaint = Paint().apply { color = 0xFFCBD5E1.toInt(); strokeWidth = 1.5f }
                var x = 0f; while (x <= w) { canvas.drawLine(x, 0f, x, h, gridPaint); x += 64f }
                var y = 0f; while (y <= h) { canvas.drawLine(0f, y, w, y, gridPaint); y += 64f }
                val centerPaint = Paint().apply { color = 0xFF94A3B8.toInt(); strokeWidth = 2f }
                canvas.drawLine(w / 2f, 0f, w / 2f, h, centerPaint)
                canvas.drawLine(0f, h / 2f, w, h / 2f, centerPaint)
            }
            BackgroundTemplate.SUNNY_MEADOW -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF38BDF8.toInt(), 0xFFBAE6FD.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.82f - panX * 0.2f, h * 0.2f - panY * 0.2f, 64f, paint)
                paint.color = 0xFF22C55E.toInt()
                canvas.drawOval(RectF(-w * 0.2f - panX * 0.5f, h * 0.62f, w * 0.7f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF16A34A.toInt()
                canvas.drawOval(RectF(w * 0.35f - panX * 0.7f, h * 0.66f, w * 1.25f - panX * 0.7f, h * 1.35f), paint)
            }
            BackgroundTemplate.CYBERPUNK_CITY -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF090D1A.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.shader = LinearGradient(0f, h * 0.55f, 0f, h, 0x44FF6B35, 0x00000000, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, h * 0.55f, w, h, paint)
                paint.shader = null
                val bWidths = listOf(110f, 85f, 140f, 95f, 130f, 105f, 150f, 90f, 135f, 120f)
                val bHeights = listOf(260f, 380f, 220f, 420f, 300f, 360f, 250f, 410f, 290f, 330f)
                var bx = -40f - panX * 0.6f
                bWidths.forEachIndexed { idx, bw ->
                    val bh = bHeights[idx]
                    paint.color = 0xFF0F172A.toInt()
                    canvas.drawRect(bx, h - bh, bx + bw - 8f, h, paint)
                    paint.color = if (idx % 2 == 0) 0xAA2DD4BF.toInt() else 0xAAFF6B35.toInt()
                    var wy = h - bh + 20f
                    while (wy < h - 60f) { canvas.drawRect(bx + 14f, wy, bx + bw - 26f, wy + 7f, paint); wy += 26f }
                    bx += bw
                }
                paint.color = 0xFF151922.toInt()
                canvas.drawRect(0f, h * 0.78f, w, h, paint)
                paint.color = 0x552DD4BF; paint.strokeWidth = 2f
                canvas.drawLine(0f, h * 0.78f, w, h * 0.78f, paint)
            }
            BackgroundTemplate.COZY_STUDIO -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF292524.toInt(), 0xFF1C1917.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF44403C.toInt()
                canvas.drawRect(0f, h * 0.74f, w, h, paint)
                paint.color = 0x33FBBF24
                canvas.drawCircle(w * 0.5f, h * 0.35f, 280f, paint)
            }
            BackgroundTemplate.OUTER_SPACE -> {
                paint.shader = LinearGradient(0f, 0f, w, h, 0xFF030712.toInt(), 0xFF1E1B4B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val rng = Random(42)
                paint.color = 0xFFFFFFFF.toInt()
                repeat(70) { canvas.drawCircle(rng.nextFloat() * w, rng.nextFloat() * h, 1.5f + rng.nextFloat() * 2.5f, paint) }
                paint.color = 0xFF7C3AED.toInt()
                canvas.drawCircle(w * 0.78f - panX * 0.3f, h * 0.28f, 74f, paint)
                paint.color = 0x552DD4BF; paint.style = Paint.Style.STROKE; paint.strokeWidth = 10f
                canvas.drawOval(RectF(w * 0.78f - 125f - panX * 0.3f, h * 0.28f - 24f, w * 0.78f + 125f - panX * 0.3f, h * 0.28f + 24f), paint)
            }
            BackgroundTemplate.SUNSET_DESERT -> {
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f, 0xFF7C2D12.toInt(), 0xFFFB923C.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFFFDE047.toInt()
                canvas.drawCircle(w * 0.5f, h * 0.58f, 92f, paint)
                paint.color = 0xFF9A3412.toInt()
                canvas.drawOval(RectF(-w * 0.15f - panX * 0.5f, h * 0.65f, w * 0.75f - panX * 0.5f, h * 1.3f), paint)
                paint.color = 0xFF7C2D12.toInt()
                canvas.drawOval(RectF(w * 0.3f - panX * 0.7f, h * 0.7f, w * 1.2f - panX * 0.7f, h * 1.35f), paint)
            }
            // Module 9: 6 Multi-Plane South Asian / Folk & Horror Story Backdrops
            BackgroundTemplate.ZAMINDAR_VERANDA -> {
                // Warm courtyard sunlight + ochre mansion wall + arched heritage doorways
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f, 0xFFFEF3C7.toInt(), 0xFFF59E0B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Heritage cream-ochre wall with terracotta molding
                paint.color = 0xFFFEF9C3.toInt()
                canvas.drawRect(0f, h * 0.14f, w, h * 0.72f, paint)
                paint.color = 0xFFB45309.toInt()
                canvas.drawRect(0f, 0f, w, h * 0.16f, paint)
                // Repeating Mughal/Bengali wooden louvered arches
                val span = w + 320f
                for (i in 0..4) {
                    val ax = (((i * (span / 4f) - panX * 0.5f) % span) + span) % span - 120f
                    paint.color = 0xFF14532D.toInt()
                    canvas.drawRoundRect(RectF(ax - 55f, h * 0.24f, ax + 55f, h * 0.70f), 55f, 55f, paint)
                    paint.color = 0xFF166534.toInt()
                    canvas.drawRect(ax - 44f, h * 0.38f, ax + 44f, h * 0.70f, paint)
                }
                // Red oxide traditional veranda floor
                paint.color = 0xFF991B1B.toInt()
                canvas.drawRect(0f, h * 0.70f, w, h, paint)
                paint.color = 0xFF7F1D1D.toInt()
                canvas.drawRect(0f, h * 0.70f, w, h * 0.73f, paint)
            }
            BackgroundTemplate.VILLAGE_HUT_POND -> {
                // Golden Bengali village sky + distant palms + thatched mud hut + shimmering pond
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.65f, 0xFF38BDF8.toInt(), 0xFFFEF08A.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Distant green village treeline
                paint.color = 0xFF15803D.toInt()
                canvas.drawOval(RectF(-w * 0.1f - panX * 0.3f, h * 0.45f, w * 0.65f - panX * 0.3f, h * 0.92f), paint)
                paint.color = 0xFF16A34A.toInt()
                canvas.drawOval(RectF(w * 0.4f - panX * 0.35f, h * 0.48f, w * 1.2f - panX * 0.35f, h * 0.95f), paint)
                // Thatched Mud Hut on left-midground
                val hx = w * 0.28f - panX * 0.55f
                paint.color = 0xFFD6B98C.toInt()
                canvas.drawRect(hx - 110f, h * 0.48f, hx + 110f, h * 0.74f, paint)
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(hx - 28f, h * 0.56f, hx + 28f, h * 0.74f, paint)
                val roof = Path().apply {
                    moveTo(hx - 140f, h * 0.50f); lineTo(hx, h * 0.30f); lineTo(hx + 140f, h * 0.50f); close()
                }
                paint.color = 0xFFB45309.toInt()
                canvas.drawPath(roof, paint)
                // Village earth bank + Pond with animated water ripples
                paint.color = 0xFF4ADE80.toInt()
                canvas.drawRect(0f, h * 0.70f, w, h, paint)
                paint.color = 0xFF0284C7.toInt()
                canvas.drawOval(RectF(w * 0.48f - panX * 0.6f, h * 0.73f, w * 1.15f - panX * 0.6f, h * 1.15f), paint)
                paint.color = 0x88BAE6FD.toInt()
                val ripple = sin(frame * 0.15).toFloat() * 14f
                canvas.drawRect(w * 0.64f + ripple - panX * 0.6f, h * 0.82f, w * 0.84f + ripple - panX * 0.6f, h * 0.835f, paint)
            }
            BackgroundTemplate.ROYAL_DARBAR -> {
                // Deep crimson & gold royal Indian palace hall + carved archways + carpet runner
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.74f, 0xFF450A0A.toInt(), 0xFF991B1B.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                // Ornate gold arch back wall
                paint.color = 0xFFD97706.toInt()
                canvas.drawRoundRect(RectF(w * 0.24f - panX * 0.4f, h * 0.12f, w * 0.76f - panX * 0.4f, h * 0.74f), 140f, 140f, paint)
                paint.color = 0xFF7F1D1D.toInt()
                canvas.drawRoundRect(RectF(w * 0.28f - panX * 0.4f, h * 0.17f, w * 0.72f - panX * 0.4f, h * 0.74f), 120f, 120f, paint)
                // Royal throne platform
                paint.color = 0xFFF59E0B.toInt()
                canvas.drawRoundRect(RectF(w * 0.41f - panX * 0.45f, h * 0.40f, w * 0.59f - panX * 0.45f, h * 0.70f), 18f, 18f, paint)
                // Marble floor + red royal carpet
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, h * 0.72f, w, h, paint)
                val carpet = Path().apply {
                    moveTo(w * 0.36f, h * 0.72f); lineTo(w * 0.64f, h * 0.72f)
                    lineTo(w * 0.78f, h); lineTo(w * 0.22f, h); close()
                }
                paint.color = 0xFFB91C1C.toInt()
                canvas.drawPath(carpet, paint)
            }
            BackgroundTemplate.VILLAGE_ROAD -> {
                // Bright countryside sky + green paddy fields + winding dusty village road
                paint.shader = LinearGradient(0f, 0f, 0f, h * 0.58f, 0xFF60A5FA.toInt(), 0xFFDBEAFE.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                paint.color = 0xFF22C55E.toInt()
                canvas.drawRect(0f, h * 0.54f, w, h, paint)
                // Winding ochre mud road
                val road = Path().apply {
                    moveTo(w * 0.42f - panX * 0.4f, h * 0.54f)
                    lineTo(w * 0.58f - panX * 0.4f, h * 0.54f)
                    lineTo(w * 0.86f - panX * 0.7f, h)
                    lineTo(w * 0.14f - panX * 0.7f, h)
                    close()
                }
                paint.color = 0xFFD97706.toInt()
                canvas.drawPath(road, paint)
                paint.color = 0xFFFDE68A.toInt()
                canvas.drawRect(0f, h * 0.72f, w, h * 0.735f, paint)
            }
            BackgroundTemplate.HAUNTED_FOREST_MULTIPLANE -> {
                // Deep midnight teal haunted woods + large eerie moon + distant dead silhouettes
                paint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF020617.toInt(), 0xFF0F2942.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
                val moonX = w * 0.52f - panX * 0.12f
                paint.shader = RadialGradient(moonX, h * 0.26f, 180f, 0x66E0F2FE, 0x00E0F2FE, Shader.TileMode.CLAMP)
                canvas.drawCircle(moonX, h * 0.26f, 180f, paint)
                paint.shader = null
                paint.color = 0xFFF1F5F9.toInt()
                canvas.drawCircle(moonX, h * 0.26f, 64f, paint)
                paint.color = 0xFF091324.toInt()
                val span = w + 320f
                for (i in 0..7) {
                    val tx = (((i * (span / 7f) - panX * 0.45f) % span) + span) % span - 140f
                    canvas.drawRect(tx - 16f, h * 0.24f, tx + 16f, h * 0.80f, paint)
                }
                paint.color = 0xFF020617.toInt()
                canvas.drawRect(0f, h * 0.76f, w, h, paint)
            }
            BackgroundTemplate.TRADITIONAL_ROOM -> {
                // Warm cream traditional Indian home interior with wall frame, wooden window & woven mat
                paint.color = 0xFFFEF3C7.toInt()
                canvas.drawRect(0f, 0f, w, h * 0.72f, paint)
                // Wooden window showing evening sky
                val wx = w * 0.58f - panX * 0.4f
                paint.color = 0xFF78350F.toInt()
                canvas.drawRoundRect(RectF(wx - 92f, h * 0.16f, wx + 92f, h * 0.48f), 8f, 8f, paint)
                paint.color = 0xFF38BDF8.toInt()
                canvas.drawRect(wx - 78f, h * 0.19f, wx + 78f, h * 0.45f, paint)
                paint.color = 0xFF78350F.toInt()
                canvas.drawRect(wx - 4f, h * 0.19f, wx + 4f, h * 0.45f, paint)
                canvas.drawRect(wx - 78f, h * 0.31f, wx + 78f, h * 0.33f, paint)
                // Terracotta floor + woven Madur mat
                paint.color = 0xFFC2410C.toInt()
                canvas.drawRect(0f, h * 0.72f, w, h, paint)
                paint.color = 0xFFEA580C.toInt()
                canvas.drawRoundRect(RectF(w * 0.18f - panX * 0.5f, h * 0.80f, w * 0.82f - panX * 0.5f, h * 0.94f), 10f, 10f, paint)
            }
        }
    }

    /**
     * Module 9: Multi-Plane Foreground Props (pillars, trees, columns, curtains) rendered AFTER
     * mid-ground characters so characters naturally walk BEHIND foreground architecture & foliage!
     */
    private fun drawBackgroundForegroundPlane(
        canvas: Canvas,
        templateName: String,
        w: Float,
        h: Float,
        panX: Float,
        panY: Float,
        frame: Int
    ) {
        val template = runCatching { BackgroundTemplate.valueOf(templateName) }.getOrDefault(BackgroundTemplate.SOLID)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val sway = sin(frame * 0.08).toFloat() * 6f
        when (template) {
            BackgroundTemplate.ZAMINDAR_VERANDA -> {
                // Tall foreground Zamindar veranda pillars on left & right edges
                listOf(w * 0.08f, w * 0.92f).forEach { baseX ->
                    val px = baseX - panX * 0.25f
                    paint.color = 0xFFE2D9C5.toInt()
                    canvas.drawRect(px - 34f, 0f, px + 34f, h, paint)
                    paint.color = 0xFFB45309.toInt()
                    canvas.drawRect(px - 44f, 0f, px + 44f, h * 0.12f, paint)
                    canvas.drawRect(px - 44f, h * 0.86f, px + 44f, h, paint)
                }
            }
            BackgroundTemplate.VILLAGE_HUT_POND, BackgroundTemplate.VILLAGE_ROAD -> {
                // Foreground silhouetted banana / mango foliage framing left & right edges
                paint.color = 0xDD14532D.toInt()
                canvas.drawOval(RectF(-70f - panX * 0.2f + sway, h * 0.62f, 150f - panX * 0.2f + sway, h * 1.1f), paint)
                canvas.drawOval(RectF(w - 150f - panX * 0.2f - sway, h * 0.64f, w + 70f - panX * 0.2f - sway, h * 1.12f), paint)
                paint.color = 0xCC166534.toInt()
                canvas.drawOval(RectF(-40f + sway, -60f, 220f + sway, 130f), paint)
            }
            BackgroundTemplate.ROYAL_DARBAR -> {
                // Golden Darbar foreground pillars + velvet red side curtains
                listOf(w * 0.06f, w * 0.94f).forEach { baseX ->
                    val px = baseX - panX * 0.2f
                    paint.color = 0xFFB45309.toInt()
                    canvas.drawRect(px - 36f, 0f, px + 36f, h, paint)
                    paint.color = 0xFFF59E0B.toInt()
                    canvas.drawRect(px - 14f, 0f, px + 14f, h, paint)
                }
            }
            BackgroundTemplate.HAUNTED_FOREST_MULTIPLANE, BackgroundTemplate.HAUNTED_FOREST -> {
                // Dark foreground gnarled tree trunks framing the left & right camera edges!
                paint.color = 0xF0020617.toInt()
                canvas.drawRect(-12f - panX * 0.2f, 0f, 76f - panX * 0.2f, h, paint)
                canvas.drawRect(w - 76f - panX * 0.2f, 0f, w + 12f - panX * 0.2f, h, paint)
                val branchP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xF0020617.toInt(); strokeWidth = 14f; strokeCap = Paint.Cap.ROUND
                }
                canvas.drawLine(64f, h * 0.22f, 190f + sway, h * 0.08f, branchP)
                canvas.drawLine(w - 64f, h * 0.28f, w - 185f - sway, h * 0.14f, branchP)
            }
            BackgroundTemplate.TRADITIONAL_ROOM -> {
                // Wooden doorway frame edges
                paint.color = 0xFF5C2D0C.toInt()
                canvas.drawRect(0f, 0f, 44f, h, paint)
                canvas.drawRect(w - 44f, 0f, w, h, paint)
                canvas.drawRect(0f, 0f, w, 34f, paint)
            }
            else -> Unit
        }
    }

    fun parseSimpleSvgShapes(svgContent: String, canvasW: Float, canvasH: Float): List<VectorShape> {
        val shapes = mutableListOf<VectorShape>()
        val cx = canvasW / 2f; val cy = canvasH / 2f
        fun extractAttr(tag: String, attr: String): Float? =
            Regex("""$attr\s*=\s*["']([0-9.\-]+)["']""").find(tag)?.groupValues?.getOrNull(1)?.toFloatOrNull()

        Regex("<rect[^>]+>").findAll(svgContent).forEach { m ->
            val x = extractAttr(m.value, "x") ?: 0f; val y = extractAttr(m.value, "y") ?: 0f
            val w = extractAttr(m.value, "width") ?: 120f; val h = extractAttr(m.value, "height") ?: 80f
            shapes.add(VectorShape(kind = ShapeKind.RECTANGLE.name, startX = cx - 150f + x, startY = cy - 100f + y, endX = cx - 150f + x + w, endY = cy - 100f + y + h, strokeColorArgb = 0xFF2DD4BFL, fillColorArgb = 0x662DD4BF, strokeWidth = 4f))
        }
        Regex("<circle[^>]+>").findAll(svgContent).forEach { m ->
            val x = extractAttr(m.value, "cx") ?: 80f; val y = extractAttr(m.value, "cy") ?: 80f
            val r = extractAttr(m.value, "r") ?: 50f
            shapes.add(VectorShape(kind = ShapeKind.CIRCLE.name, startX = cx - 150f + x - r, startY = cy - 100f + y - r, endX = cx - 150f + x + r, endY = cy - 100f + y + r, strokeColorArgb = 0xFFFF6B35L, fillColorArgb = 0x66FF6B35, strokeWidth = 4f))
        }
        Regex("<line[^>]+>").findAll(svgContent).forEach { m ->
            val x1 = extractAttr(m.value, "x1") ?: 0f; val y1 = extractAttr(m.value, "y1") ?: 0f
            val x2 = extractAttr(m.value, "x2") ?: 120f; val y2 = extractAttr(m.value, "y2") ?: 120f
            shapes.add(VectorShape(kind = ShapeKind.LINE.name, startX = cx - 150f + x1, startY = cy - 100f + y1, endX = cx - 150f + x2, endY = cy - 100f + y2, strokeColorArgb = 0xFFFBBF24L, strokeWidth = 5f))
        }
        return shapes
    }
}
