package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.webkit.MimeTypeMap
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.FacialTimingConfig
import com.example.data.model.MouthPhoneme
import com.example.data.model.VoiceEffectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

enum class BuiltInAudioPreset(val title: String, val kind: AudioTrackKind, val durationSec: Float) {
    SFX_POP("Cartoon Pop", AudioTrackKind.SFX, 0.35f),
    SFX_BOING("Spring Boing", AudioTrackKind.SFX, 0.75f),
    SFX_WHOOSH("Fast Whoosh", AudioTrackKind.SFX, 0.55f),
    SFX_SPARKLE("Magic Chime", AudioTrackKind.SFX, 0.9f),
    SFX_FOOTSTEP("Soft Step", AudioTrackKind.SFX, 0.25f),
    SFX_JUMPSCARE("Horror Scare", AudioTrackKind.SFX, 0.95f),
    SFX_GHOST_MOAN("Ghost Wail", AudioTrackKind.SFX, 1.5f),
    SFX_THUNDER("Thunder Clap", AudioTrackKind.SFX, 1.6f),
    SFX_HEARTBEAT("Suspense Pulse", AudioTrackKind.SFX, 2.0f),
    MUSIC_SYNTH_LOOP("Studio Synth Loop", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_PLAYFUL_BEAT("Playful Marimba", AudioTrackKind.MUSIC, 3.2f),
    MUSIC_HORROR_DRONE("Horror Ambience", AudioTrackKind.MUSIC, 4.0f)
}

class AudioStudioEngine(private val context: Context) {

    enum class BlinkPhase { OPEN, HALF_BLINK, CLOSED }

    private val audioDir: File by lazy {
        File(context.filesDir, "audio").apply { mkdirs() }
    }

    private data class ActiveTrackPlayer(
        val trackId: String,
        val player: MediaPlayer,
        val startFrame: Int,
        val endFrame: Int,
        val loopClip: Boolean
    )

    private var activeRecorder: AudioRecord? = null
    @Volatile
    private var isRecordingFlag = false
    private val activePlayers = mutableListOf<ActiveTrackPlayer>()

    @SuppressLint("MissingPermission")
    suspend fun recordVoiceToWav(
        onAmplitude: (Float) -> Unit,
        onFinished: (AudioTrackItem?) -> Unit
    ) = withContext(Dispatchers.IO) {
        val sampleRate = 22050
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, encoding).coerceAtLeast(2048)

        val recorder = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, encoding, minBuf * 2)
        }.getOrNull()

        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        activeRecorder = recorder
        isRecordingFlag = true
        val pcmStream = ByteArrayOutputStream()
        val buffer = ShortArray(1024)

        try {
            recorder.startRecording()
            while (isRecordingFlag && isActive) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    var peak = 0
                    val byteBuf = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until read) {
                        val s = buffer[i]
                        byteBuf.putShort(s)
                        val a = abs(s.toInt())
                        if (a > peak) peak = a
                    }
                    pcmStream.write(byteBuf.array())
                    val norm = (peak / 32768f).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main) { onAmplitude(norm) }
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
            activeRecorder = null
            isRecordingFlag = false
        }

        val pcmBytes = pcmStream.toByteArray()
        if (pcmBytes.size < 400) {
            withContext(Dispatchers.Main) { onFinished(null) }
            return@withContext
        }

        val file = File(audioDir, "voice_${System.currentTimeMillis()}.wav")
        writeWavFile(file, pcmBytes, sampleRate)
        val durationMs = ((pcmBytes.size / 2.0) / sampleRate * 1000.0).toLong().coerceAtLeast(200L)
        val peaks = extractPeaksFromPcm16(pcmBytes, 48)
        val track = AudioTrackItem(
            id = UUID.randomUUID().toString(),
            name = "Voice Take ${(System.currentTimeMillis() % 1000)}",
            uri = file.absolutePath,
            filePath = file.absolutePath,
            originalFilePath = file.absolutePath,
            kind = AudioTrackKind.VOICE.name,
            trackIndex = 0,
            voiceEffect = VoiceEffectType.NORMAL.name,
            startFrame = 0,
            durationMs = durationMs,
            sourceDurationMs = durationMs,
            trimStartMs = 0L,
            trimEndMs = durationMs,
            volume = 0.95f,
            fadeInMs = 50L,
            fadeOutMs = 80L,
            waveformPeaks = peaks
        )
        withContext(Dispatchers.Main) { onFinished(track) }
    }

    fun stopVoiceRecording() {
        isRecordingFlag = false
    }

    suspend fun synthesizeBuiltInPreset(preset: BuiltInAudioPreset, startFrame: Int): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val sampleRate = 22050
            val totalSamples = (sampleRate * preset.durationSec).toInt()
            val pcm = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
            val rng = Random(preset.ordinal * 997 + 13)

            for (i in 0 until totalSamples) {
                val t = i.toFloat() / sampleRate.toFloat()
                val progress = i.toFloat() / totalSamples.toFloat()
                val sample = when (preset) {
                    BuiltInAudioPreset.SFX_POP -> {
                        val freq = 220f + 560f * progress
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 14f)
                    }
                    BuiltInAudioPreset.SFX_BOING -> {
                        val freq = 140f + 240f * sin(2.0 * PI * 9.0 * t).toFloat()
                        sin(2.0 * PI * freq * t).toFloat() * exp(-t * 3.2f)
                    }
                    BuiltInAudioPreset.SFX_WHOOSH -> {
                        val env = sin(PI * progress).toFloat()
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.45f
                        val tone = sin(2.0 * PI * (180f + 420f * progress) * t).toFloat() * 0.35f
                        (noise + tone) * env
                    }
                    BuiltInAudioPreset.SFX_SPARKLE -> {
                        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f)
                        val noteIdx = (progress * notes.size).toInt().coerceIn(0, notes.lastIndex)
                        val localT = t - (noteIdx * (preset.durationSec / notes.size))
                        val env = exp(-localT.coerceAtLeast(0f) * 8f)
                        (sin(2.0 * PI * notes[noteIdx] * t) + 0.4 * sin(4.0 * PI * notes[noteIdx] * t)).toFloat() * 0.6f * env
                    }
                    BuiltInAudioPreset.SFX_FOOTSTEP -> {
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.5f
                        val thud = sin(2.0 * PI * (95f - 45f * progress) * t).toFloat() * 0.6f
                        (noise + thud) * exp(-t * 22f)
                    }
                    BuiltInAudioPreset.SFX_JUMPSCARE -> {
                        val shriek = sin(2.0 * PI * (680f + 420f * sin(t * 28.0)) * t).toFloat() * 0.45f
                        val dissonance = sin(2.0 * PI * 725.0 * t).toFloat() * 0.38f
                        val rumble = sin(2.0 * PI * 62.0 * t).toFloat() * 0.4f
                        val noise = (rng.nextFloat() * 2f - 1f) * 0.35f
                        (shriek + dissonance + rumble + noise) * exp(-t * 3.1f)
                    }
                    BuiltInAudioPreset.SFX_GHOST_MOAN -> {
                        val env = sin(PI * progress).toFloat()
                        val vibrato = sin(2.0 * PI * 5.2 * t).toFloat() * 28f
                        val freq = 340f - 140f * progress + vibrato
                        val wail = sin(2.0 * PI * freq * t).toFloat() * 0.55f +
                            sin(2.0 * PI * (freq * 1.5f) * t).toFloat() * 0.22f
                        val breath = (rng.nextFloat() * 2f - 1f) * 0.14f
                        (wail + breath) * env
                    }
                    BuiltInAudioPreset.SFX_THUNDER -> {
                        val crack = (rng.nextFloat() * 2f - 1f) * exp(-t * 6.5f) * 0.7f
                        val roll = (rng.nextFloat() * 2f - 1f) * (0.4f + 0.3f * sin(t * 9.0).toFloat()) * exp(-t * 1.4f)
                        val sub = sin(2.0 * PI * (52f - 18f * progress) * t).toFloat() * exp(-t * 1.8f) * 0.5f
                        crack + roll * 0.55f + sub
                    }
                    BuiltInAudioPreset.SFX_HEARTBEAT -> {
                        val cycle = t % 0.85f
                        val beat1 = if (cycle < 0.16f) sin(2.0 * PI * 58.0 * cycle).toFloat() * exp(-cycle * 22f) else 0f
                        val beat2 = if (cycle in 0.22f..0.38f) {
                            val lt = cycle - 0.22f
                            sin(2.0 * PI * 50.0 * lt).toFloat() * exp(-lt * 24f) * 0.75f
                        } else 0f
                        (beat1 + beat2) * 0.95f
                    }
                    BuiltInAudioPreset.MUSIC_SYNTH_LOOP -> {
                        val stepDur = 0.2f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val chord = floatArrayOf(261.63f, 329.63f, 392.0f, 329.63f, 220.0f, 261.63f, 349.23f, 392.0f)
                        val f = chord[step % chord.size]
                        val bass = sin(2.0 * PI * (f / 2f) * t).toFloat() * 0.32f
                        val lead = sin(2.0 * PI * f * t).toFloat() * exp(-localT * 6.5f) * 0.45f
                        (bass + lead) * (1f - 0.1f * progress)
                    }
                    BuiltInAudioPreset.MUSIC_PLAYFUL_BEAT -> {
                        val stepDur = 0.16f
                        val step = (t / stepDur).toInt()
                        val localT = t % stepDur
                        val scale = floatArrayOf(392f, 440f, 523.25f, 587.33f, 659.25f, 587.33f, 523.25f, 440f)
                        val f = scale[step % scale.size]
                        sin(2.0 * PI * f * t).toFloat() * exp(-localT * 11f) * 0.65f
                    }
                    BuiltInAudioPreset.MUSIC_HORROR_DRONE -> {
                        val drone1 = sin(2.0 * PI * 55.0 * t).toFloat() * 0.38f
                        val drone2 = sin(2.0 * PI * 58.27 * t).toFloat() * 0.32f
                        val eerieHigh = sin(2.0 * PI * (466.16 + 8.0 * sin(t * 1.7)) * t).toFloat() * 0.12f
                        val wind = (rng.nextFloat() * 2f - 1f) * 0.08f * (0.5f + 0.5f * sin(t * 2.1).toFloat())
                        (drone1 + drone2 + eerieHigh + wind) * sin(PI * progress).toFloat().coerceAtLeast(0.25f)
                    }
                }
                val s16 = (sample.coerceIn(-0.98f, 0.98f) * 32000f).toInt().toShort()
                pcm.putShort(s16)
            }

            val pcmBytes = pcm.array()
            val file = File(audioDir, "preset_${preset.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(file, pcmBytes, sampleRate)
            val durationMs = (preset.durationSec * 1000L).toLong()
            val defaultLane = when (preset.kind) {
                AudioTrackKind.VOICE -> 0
                AudioTrackKind.SFX -> 1
                AudioTrackKind.MUSIC -> 2
            }
            AudioTrackItem(
                id = UUID.randomUUID().toString(),
                name = preset.title,
                uri = file.absolutePath,
                filePath = file.absolutePath,
                originalFilePath = file.absolutePath,
                kind = preset.kind.name,
                trackIndex = defaultLane,
                voiceEffect = VoiceEffectType.NORMAL.name,
                startFrame = startFrame,
                durationMs = durationMs,
                sourceDurationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                volume = 0.85f,
                fadeInMs = 40L,
                fadeOutMs = 100L,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 44)
            )
        }

    /**
     * Real offline PCM16 Voice Changer DSP for Cartoon Kid, Deep Monster, Ghost Echo & Robot voices.
     */
    suspend fun applyVoiceEffect(track: AudioTrackItem, effect: VoiceEffectType): AudioTrackItem =
        withContext(Dispatchers.IO) {
            val basePath = track.originalFilePath.ifBlank { track.filePath }
            val sourceFile = File(basePath)
            if (!sourceFile.exists()) return@withContext track.copy(voiceEffect = effect.name)

            if (effect == VoiceEffectType.NORMAL) {
                val bytes = runCatching { sourceFile.readBytes() }.getOrNull()
                val wav = bytes?.let { parseWavPcm16(it) }
                val durMs = wav?.let { ((it.samples.size.toDouble() / it.sampleRate) * 1000.0).toLong().coerceAtLeast(200L) }
                    ?: track.durationMs
                val restoredPeaks = if (wav != null) {
                    val bb = ByteBuffer.allocate(wav.samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                    wav.samples.forEach { bb.putShort(it) }
                    extractPeaksFromPcm16(bb.array(), 48)
                } else track.waveformPeaks
                return@withContext track.copy(
                    filePath = basePath,
                    originalFilePath = basePath,
                    voiceEffect = effect.name,
                    durationMs = durMs,
                    trimStartMs = 0L,
                    trimEndMs = durMs,
                    waveformPeaks = restoredPeaks
                )
            }

            val rawBytes = runCatching { sourceFile.readBytes() }.getOrNull()
                ?: return@withContext track.copy(voiceEffect = effect.name)
            val parsed = parseWavPcm16(rawBytes)
                ?: return@withContext track.copy(voiceEffect = effect.name)

            val processedSamples = processVoicePcm16(parsed.samples, parsed.sampleRate, effect)
            val outBytes = ByteBuffer.allocate(processedSamples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            processedSamples.forEach { outBytes.putShort(it) }
            val pcmBytes = outBytes.array()

            val outFile = File(audioDir, "fx_${effect.name.lowercase()}_${System.currentTimeMillis()}.wav")
            writeWavFile(outFile, pcmBytes, parsed.sampleRate)
            val durationMs = ((processedSamples.size.toDouble() / parsed.sampleRate) * 1000.0).toLong().coerceAtLeast(200L)
            track.copy(
                filePath = outFile.absolutePath,
                originalFilePath = basePath,
                voiceEffect = effect.name,
                durationMs = durationMs,
                trimStartMs = 0L,
                trimEndMs = durationMs,
                waveformPeaks = extractPeaksFromPcm16(pcmBytes, 48)
            )
        }

    /**
     * Master Upgrade Module 5: Immediate Local 16-bit 44100Hz WAV/PCM Caching on Import!
     * Immediately copies & decodes any imported audio/voice (MP3/M4A/AAC/OGG/WAV/OPUS) via MediaExtractor+MediaCodec
     * into a local 16-bit 44100Hz WAV file inside app internal storage so URI permissions never expire and
     * audio is 100% present and lip-synced during both preview and MP4 export!
     */
    suspend fun importAudioUri(uri: Uri, displayName: String, startFrame: Int): AudioTrackItem? =
        withContext(Dispatchers.IO) {
            val mimeType = runCatching { context.contentResolver.getType(uri) }.getOrNull()
            val nameExt = displayName.substringAfterLast('.', "").lowercase(Locale.US)
                .takeIf { it in setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "3gp", "amr", "opus") }
            val mimeExt = mimeType?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
                ?.lowercase(Locale.US)
                ?.takeIf { it.isNotBlank() && it.length <= 5 }
            val ext = nameExt ?: mimeExt ?: "m4a"
            val ts = System.currentTimeMillis()
            val rawTempFile = File(audioDir, "import_raw_$ts.$ext")
            val cachedWavFile = File(audioDir, "import_pcm44k_$ts.wav")

            val result = runCatching {
                val inputStream = runCatching { context.contentResolver.openInputStream(uri) }.getOrNull()
                    ?: runCatching { context.contentResolver.openAssetFileDescriptor(uri, "r")?.createInputStream() }.getOrNull()
                    ?: return@runCatching null
                inputStream.use { input ->
                    FileOutputStream(rawTempFile).use { output -> input.copyTo(output) }
                }
                if (!rawTempFile.exists() || rawTempFile.length() <= 0L) {
                    runCatching { rawTempFile.delete() }
                    return@runCatching null
                }

                // Decode immediately to canonical 16-bit 44100Hz mono WAV for guaranteed playback, voice DSP, & MP4 export
                val decoded = decodeAnyAudioFileToMonoPcm16(rawTempFile, targetSampleRate = 44100)
                val finalFile: File
                val durationMs: Long
                val peaks: List<Float>

                if (decoded != null && decoded.samples.isNotEmpty()) {
                    val bb = ByteBuffer.allocate(decoded.samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                    decoded.samples.forEach { bb.putShort(it) }
                    val pcmBytes = bb.array()
                    writeWavFile(cachedWavFile, pcmBytes, decoded.sampleRate)
                    runCatching { rawTempFile.delete() }
                    finalFile = cachedWavFile
                    durationMs = ((decoded.samples.size.toDouble() / decoded.sampleRate) * 1000.0)
                        .toLong().coerceAtLeast(250L)
                    peaks = extractPeaksFromPcm16(pcmBytes, 64)
                } else {
                    // Fallback if device lacks codec: keep copied local file
                    finalFile = rawTempFile
                    durationMs = runCatching {
                        val mmr = MediaMetadataRetriever()
                        try {
                            mmr.setDataSource(rawTempFile.absolutePath)
                            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                                ?.toLongOrNull()?.coerceAtLeast(300L) ?: 3000L
                        } finally {
                            runCatching { mmr.release() }
                        }
                    }.getOrDefault(3000L)
                    val sampleBytes = readBoundedBytes(rawTempFile, maxBytes = 512 * 1024)
                    peaks = if (sampleBytes.size > 44 && String(sampleBytes.copyOfRange(0, 4)) == "RIFF") {
                        extractPeaksFromPcm16(sampleBytes.copyOfRange(44, sampleBytes.size), 64)
                    } else {
                        extractApproximatePeaks(sampleBytes, 64)
                    }
                }

                AudioTrackItem(
                    id = UUID.randomUUID().toString(),
                    name = displayName.substringBeforeLast('.').ifBlank { "Imported Audio" },
                    uri = finalFile.absolutePath,
                    filePath = finalFile.absolutePath,
                    originalFilePath = finalFile.absolutePath,
                    kind = AudioTrackKind.VOICE.name,
                    trackIndex = 0,
                    voiceEffect = VoiceEffectType.NORMAL.name,
                    startFrame = startFrame,
                    endFrame = -1,
                    loopClip = false,
                    isLooping = false,
                    durationMs = durationMs,
                    sourceDurationMs = durationMs,
                    trimStartMs = 0L,
                    trimEndMs = durationMs,
                    volume = 0.90f,
                    fadeInMs = 30L,
                    fadeOutMs = 60L,
                    waveformPeaks = peaks
                )
            }.getOrNull()
            if (result == null) {
                runCatching { if (rawTempFile.exists()) rawTempFile.delete() }
                runCatching { if (cachedWavFile.exists()) cachedWavFile.delete() }
            }
            result
        }

    private fun readBoundedBytes(file: File, maxBytes: Int): ByteArray {
        return runCatching {
            val toRead = file.length().coerceAtMost(maxBytes.toLong()).toInt().coerceAtLeast(0)
            if (toRead == 0) return@runCatching ByteArray(0)
            val buf = ByteArray(toRead)
            FileInputStream(file).use { fis ->
                var offset = 0
                while (offset < toRead) {
                    val n = fis.read(buf, offset, toRead - offset)
                    if (n <= 0) break
                    offset += n
                }
                if (offset == toRead) buf else buf.copyOf(offset)
            }
        }.getOrDefault(ByteArray(0))
    }

    private fun applySpeedAndPitchToPlayer(mp: MediaPlayer, speed: Float, pitch: Float) {
        val safeSpeed = speed.coerceIn(0.5f, 2.0f)
        val safePitch = pitch.coerceIn(0.5f, 2.0f)
        if (kotlin.math.abs(safeSpeed - 1.0f) > 0.01f || kotlin.math.abs(safePitch - 1.0f) > 0.01f) {
            runCatching {
                val params = mp.playbackParams
                params.speed = safeSpeed
                params.pitch = safePitch
                mp.playbackParams = params
            }
        }
    }

    fun previewTrack(track: AudioTrackItem) {
        stopAllPlayback()
        val resolvedPath = track.filePath.ifBlank { track.uri }
        if (track.muted || track.isMuted || resolvedPath.isBlank()) return
        val file = File(resolvedPath)
        if (!file.exists() || file.length() <= 0L) return
        val shouldLoop = track.loopClip || track.isLooping
        val mp = MediaPlayer()
        runCatching {
            mp.apply {
                setDataSource(file.absolutePath)
                isLooping = shouldLoop // Strict one-shot unless explicitly enabled
                prepare()
                val vol = track.volume.coerceIn(0f, 1.5f).coerceAtMost(1.0f)
                setVolume(vol, vol)
                if (track.trimStartMs > 0L) seekTo(track.trimStartMs.toInt())
                setOnCompletionListener { finished ->
                    runCatching { finished.release() }
                    activePlayers.removeAll { it.player === finished }
                }
                start()
                applySpeedAndPitchToPlayer(this, track.speed, track.pitch)
            }
            activePlayers.add(ActiveTrackPlayer(track.id, mp, track.startFrame, Int.MAX_VALUE, shouldLoop))
        }.onFailure {
            runCatching { mp.release() }
        }
    }

    /**
     * Master Upgrade Module 5 & Upgrade 8: Frame-Accurate Multi-Track Playback Sync.
     * - Starts tracks entering their [startFrame, endFrame] range (seeking accurately if playback starts mid-clip).
     * - Applies real-time fade-in / fade-out volume envelope, speed, pitch, and per-lane mute state.
     * - Immediately stops & releases any active track once playhead passes its [endFrame] or trimmed audio duration
     *   so one-shot voice/audio clips NEVER repeat or bleed past their cut point!
     */
    fun triggerTracksForFrame(
        tracks: List<AudioTrackItem>,
        frame: Int,
        fps: Int = 24,
        isPlaybackStartFrame: Boolean = false,
        trackLaneMuted: Map<Int, Boolean> = emptyMap()
    ) {
        val safeFps = fps.coerceAtLeast(1)
        fun isTrackEffectivelyMuted(t: AudioTrackItem): Boolean =
            t.muted || t.isMuted || (trackLaneMuted[t.trackIndex] == true)

        // 1. Stop any active player whose track is now muted, removed, or past its effective end frame
        val toStop = activePlayers.filter { ap ->
            val t = tracks.firstOrNull { it.id == ap.trackId }
            val loop = t != null && (t.loopClip || t.isLooping)
            val clipFrames = if (t != null) resolveTrackDurationFrames(t, safeFps) else 0
            val effEnd = if (t != null) {
                if (t.endFrame > t.startFrame) {
                    if (loop) t.endFrame else minOf(t.endFrame, t.startFrame + clipFrames)
                } else {
                    t.startFrame + clipFrames
                }
            } else ap.endFrame
            t == null || isTrackEffectivelyMuted(t) || frame < ap.startFrame || frame >= effEnd
        }
        toStop.forEach { ap ->
            runCatching {
                if (ap.player.isPlaying) ap.player.stop()
                ap.player.release()
            }
            activePlayers.remove(ap)
        }

        // 2. Update dynamic fade-in / fade-out volume on currently playing tracks
        activePlayers.forEach { ap ->
            val track = tracks.firstOrNull { it.id == ap.trackId } ?: return@forEach
            val elapsedMs = (((frame - track.startFrame).coerceAtLeast(0).toLong() * 1000L) / safeFps)
            val remainingMs = (((ap.endFrame - frame).coerceAtLeast(0).toLong() * 1000L) / safeFps)
            var gain = track.volume.coerceIn(0f, 1.5f)
            if (track.fadeInMs > 0L && elapsedMs < track.fadeInMs) {
                gain *= (elapsedMs.toFloat() / track.fadeInMs.toFloat()).coerceIn(0f, 1f)
            }
            if (track.fadeOutMs > 0L && remainingMs < track.fadeOutMs) {
                gain *= (remainingMs.toFloat() / track.fadeOutMs.toFloat()).coerceIn(0f, 1f)
            }
            val clampedVol = gain.coerceIn(0f, 1.0f)
            runCatching { ap.player.setVolume(clampedVol, clampedVol) }
        }

        // 3. Start tracks entering playhead (or active at exact start frame of playback)
        tracks.filter { !isTrackEffectivelyMuted(it) && (it.filePath.isNotBlank() || it.uri.isNotBlank()) }.forEach { track ->
            val shouldLoop = track.loopClip || track.isLooping
            val clipFrames = resolveTrackDurationFrames(track, safeFps)
            val effEnd = if (track.endFrame > track.startFrame) {
                if (shouldLoop) track.endFrame else minOf(track.endFrame, track.startFrame + clipFrames)
            } else {
                track.startFrame + clipFrames
            }
            val alreadyPlaying = activePlayers.any { it.trackId == track.id }
            val shouldStart = if (isPlaybackStartFrame) {
                frame in track.startFrame until effEnd
            } else {
                frame == track.startFrame
            }
            if (!shouldStart || alreadyPlaying) return@forEach

            val resolvedPath = track.filePath.ifBlank { track.uri }
            val file = File(resolvedPath)
            if (file.exists() && file.length() > 0L) {
                val mp = MediaPlayer()
                runCatching {
                    mp.apply {
                        setDataSource(file.absolutePath)
                        isLooping = shouldLoop // Strict one-shot default!
                        prepare()
                        val initVol = if (track.fadeInMs > 120L && frame == track.startFrame) {
                            (track.volume * 0.2f).coerceIn(0f, 1.0f)
                        } else {
                            track.volume.coerceIn(0f, 1.0f)
                        }
                        setVolume(initVol, initVol)
                        val offsetMs = ((frame - track.startFrame).coerceAtLeast(0).toLong() * 1000L) / safeFps
                        val seekMs = (track.trimStartMs + offsetMs).toInt()
                        if (seekMs > 0 && seekMs < duration) seekTo(seekMs)
                        setOnCompletionListener { finished ->
                            if (!shouldLoop) {
                                runCatching { finished.release() }
                                activePlayers.removeAll { it.player === finished }
                            }
                        }
                        start()
                        applySpeedAndPitchToPlayer(this, track.speed, track.pitch)
                    }
                    activePlayers.add(ActiveTrackPlayer(track.id, mp, track.startFrame, effEnd, shouldLoop))
                }.onFailure {
                    runCatching { mp.release() }
                }
            }
        }
    }

    fun stopAllPlayback() {
        val copy = activePlayers.toList()
        activePlayers.clear()
        copy.forEach { ap ->
            runCatching {
                if (ap.player.isPlaying) ap.player.stop()
                ap.player.release()
            }
        }
    }

    private fun writeWavFile(file: File, pcmData: ByteArray, sampleRate: Int) {
        val channels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + dataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1) // PCM
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort((channels * bitsPerSample / 8).toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray())
            putInt(dataSize)
        }
        FileOutputStream(file).use { out ->
            out.write(header.array())
            out.write(pcmData)
        }
    }

    private fun extractPeaksFromPcm16(pcmBytes: ByteArray, bars: Int): List<Float> {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return List(bars) { 0.15f }
        val step = (sampleCount / bars).coerceAtLeast(1)
        val bb = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)
        val peaks = mutableListOf<Float>()
        for (b in 0 until bars) {
            var maxAmp = 0
            val start = b * step
            val end = ((b + 1) * step).coerceAtMost(sampleCount)
            for (s in start until end) {
                val v = abs(bb.getShort(s * 2).toInt())
                if (v > maxAmp) maxAmp = v
            }
            peaks.add((maxAmp / 32768f).coerceIn(0.08f, 1f))
        }
        return peaks
    }

    private fun extractApproximatePeaks(bytes: ByteArray, bars: Int): List<Float> {
        if (bytes.isEmpty()) return List(bars) { 0.25f }
        val step = (bytes.size / bars).coerceAtLeast(1)
        return List(bars) { b ->
            val idx = (b * step).coerceIn(0, bytes.lastIndex)
            val norm = abs(bytes[idx].toInt()) / 128f
            norm.coerceIn(0.15f, 0.95f)
        }
    }

    data class ParsedWav(val sampleRate: Int, val samples: ShortArray)

    companion object {
        fun parseWavPcm16(bytes: ByteArray): ParsedWav? {
            if (bytes.size <= 44) return null
            if (String(bytes.copyOfRange(0, 4)) != "RIFF") return null
            if (String(bytes.copyOfRange(8, 12)) != "WAVE") return null
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

            var channels = 1
            var sampleRate = 22050
            var bits = 16
            var foundFmt = false
            var dataOffset = -1
            var dataSize = 0

            var cursor = 12
            while (cursor + 8 <= bytes.size) {
                val chunkId = String(bytes.copyOfRange(cursor, cursor + 4))
                val chunkSize = bb.getInt(cursor + 4).coerceAtLeast(0)
                val bodyStart = cursor + 8
                if (chunkId == "fmt " && bodyStart + 16 <= bytes.size) {
                    channels = bb.getShort(bodyStart + 2).toInt().coerceIn(1, 8)
                    sampleRate = bb.getInt(bodyStart + 4).coerceIn(8000, 48000)
                    bits = bb.getShort(bodyStart + 14).toInt()
                    foundFmt = true
                } else if (chunkId == "data") {
                    dataOffset = bodyStart
                    dataSize = chunkSize.coerceAtMost((bytes.size - bodyStart).coerceAtLeast(0))
                    break
                }
                val padded = chunkSize + (chunkSize and 1)
                if (padded <= 0) break
                cursor = bodyStart + padded
            }

            if (!foundFmt || bits != 16 || dataOffset < 0 || dataSize <= 0) return null
            val frameCount = dataSize / (2 * channels)
            if (frameCount <= 0) return null
            val mono = ShortArray(frameCount)
            for (i in 0 until frameCount) {
                var sum = 0
                for (c in 0 until channels) {
                    val pos = dataOffset + (i * channels + c) * 2
                    if (pos + 1 < bytes.size) sum += bb.getShort(pos).toInt()
                }
                mono[i] = (sum / channels).toShort()
            }
            return ParsedWav(sampleRate, mono)
        }

        fun processVoicePcm16(
            input: ShortArray,
            sampleRate: Int,
            effect: VoiceEffectType
        ): ShortArray {
            if (input.isEmpty() || effect == VoiceEffectType.NORMAL) return input
            return when (effect) {
                VoiceEffectType.CHIPMUNK -> resamplePitch(input, 1.48f)
                VoiceEffectType.DEEP_MONSTER -> {
                    val pitched = resamplePitch(input, 0.68f)
                    ShortArray(pitched.size) { i ->
                        val t = i.toDouble() / sampleRate.toDouble()
                        val growl = 1.0 + 0.18 * sin(2.0 * PI * 32.0 * t)
                        (pitched[i] * growl).toInt().coerceIn(-32767, 32767).toShort()
                    }
                }
                VoiceEffectType.GHOST_ECHO -> {
                    val pitched = resamplePitch(input, 0.90f)
                    val tailSamples = (sampleRate * 0.55f).toInt()
                    val out = FloatArray(pitched.size + tailSamples)
                    val d1 = (sampleRate * 0.17f).toInt().coerceAtLeast(1)
                    val d2 = (sampleRate * 0.34f).toInt().coerceAtLeast(1)
                    for (i in out.indices) {
                        var v = if (i < pitched.size) pitched[i].toFloat() else 0f
                        if (i >= d1) v += out[i - d1] * 0.45f
                        if (i >= d2) v += out[i - d2] * 0.25f
                        out[i] = v.coerceIn(-32767f, 32767f)
                    }
                    ShortArray(out.size) { out[it].toInt().toShort() }
                }
                VoiceEffectType.ROBOT -> {
                    ShortArray(input.size) { i ->
                        val t = i.toDouble() / sampleRate.toDouble()
                        val carrier = sin(2.0 * PI * 58.0 * t)
                        val mod = input[i] * (0.45 + 0.55 * carrier)
                        // Subtle bit-crushed metallic edge
                        val stepped = ((mod / 2048.0).toInt() * 2048.0)
                        (mod * 0.72 + stepped * 0.28).toInt().coerceIn(-32767, 32767).toShort()
                    }
                }
                VoiceEffectType.NORMAL -> input
            }
        }

        private fun resamplePitch(input: ShortArray, speedFactor: Float): ShortArray {
            val outLen = (input.size / speedFactor).toInt().coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = i * speedFactor
                val i0 = srcPos.toInt().coerceIn(0, input.lastIndex)
                val i1 = (i0 + 1).coerceAtMost(input.lastIndex)
                val frac = srcPos - i0
                val sample = input[i0] * (1f - frac) + input[i1] * frac
                sample.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        /**
         * Resamples mono 16-bit PCM samples from [srcSampleRate] to [targetSampleRate]
         * using linear interpolation so mixed audio tracks always align cleanly at 44100Hz.
         */
        fun resampleMonoPcm16(
            input: ShortArray,
            srcSampleRate: Int,
            targetSampleRate: Int
        ): ShortArray {
            if (input.isEmpty() || srcSampleRate <= 0 || targetSampleRate <= 0 || srcSampleRate == targetSampleRate) {
                return input.copyOf()
            }
            val ratio = srcSampleRate.toDouble() / targetSampleRate.toDouble()
            val outLen = (input.size / ratio).toInt().coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = i * ratio
                val i0 = srcPos.toInt().coerceIn(0, input.lastIndex)
                val i1 = (i0 + 1).coerceAtMost(input.lastIndex)
                val frac = (srcPos - i0).toFloat()
                val sample = input[i0] * (1f - frac) + input[i1] * frac
                sample.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        fun resolveTrackDurationFrames(track: AudioTrackItem, fps: Int): Int {
            val safeFps = fps.coerceAtLeast(1)
            val safeSpeed = track.speed.coerceIn(0.5f, 2.0f)
            val effectiveEndMs = if (track.trimEndMs > track.trimStartMs) track.trimEndMs else track.sourceDurationMs.coerceAtLeast(track.durationMs)
            val spanMs = ((effectiveEndMs - track.trimStartMs).coerceAtLeast(100L) / safeSpeed).toDouble()
            return kotlin.math.ceil((spanMs / 1000.0) * safeFps).toInt().coerceAtLeast(1)
        }

        /**
         * Master Upgrade Module 5: Decodes ANY audio format (WAV, MP3, M4A, AAC, OGG, FLAC, OPUS)
         * via WAV fast-path or Android MediaExtractor + MediaCodec into mono 16-bit PCM resampled to [targetSampleRate].
         */
        fun decodeAnyAudioFileToMonoPcm16(file: File, targetSampleRate: Int = 44100): ParsedWav? {
            if (!file.exists() || file.length() <= 0L) return null
            // Fast path for WAV files
            val head = ByteArray(12)
            val isWav = runCatching {
                FileInputStream(file).use { it.read(head) == 12 } &&
                    String(head, 0, 4) == "RIFF" && String(head, 8, 4) == "WAVE"
            }.getOrDefault(false)
            if (isWav) {
                val raw = runCatching { file.readBytes() }.getOrNull()
                val parsed = raw?.let { parseWavPcm16(it) }
                if (parsed != null) {
                    val resampled = if (parsed.sampleRate != targetSampleRate) {
                        resampleMonoPcm16(parsed.samples, parsed.sampleRate, targetSampleRate)
                    } else parsed.samples
                    return ParsedWav(targetSampleRate, resampled)
                }
            }

            // General compressed format decode via MediaExtractor + MediaCodec (MP3/M4A/AAC/OGG/OPUS/etc.)
            return runCatching {
                val extractor = MediaExtractor()
                var codec: MediaCodec? = null
                try {
                    extractor.setDataSource(file.absolutePath)
                    var trackIdx = -1
                    var inputFormat: MediaFormat? = null
                    for (i in 0 until extractor.trackCount) {
                        val fmt = extractor.getTrackFormat(i)
                        val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                        if (mime.startsWith("audio/")) {
                            trackIdx = i
                            inputFormat = fmt
                            break
                        }
                    }
                    if (trackIdx < 0 || inputFormat == null) return@runCatching null
                    val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return@runCatching null
                    extractor.selectTrack(trackIdx)

                    var srcSampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    } else 44100
                    var srcChannels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 8)
                    } else 1

                    codec = MediaCodec.createDecoderByType(mime)
                    codec.configure(inputFormat, null, null, 0)
                    codec.start()

                    val pcmMonoOut = ByteArrayOutputStream()
                    val info = MediaCodec.BufferInfo()
                    var inputEos = false
                    var outputEos = false
                    var safetyTicks = 0
                    val maxDecodedBytes = targetSampleRate * 2 * 600 // Cap at 10 minutes to protect mobile RAM

                    while (!outputEos && safetyTicks < 60000 && pcmMonoOut.size() < maxDecodedBytes) {
                        safetyTicks++
                        if (!inputEos) {
                            val inIdx = codec.dequeueInputBuffer(10_000)
                            if (inIdx >= 0) {
                                val inBuf = codec.getInputBuffer(inIdx)
                                if (inBuf != null) {
                                    val sampleSize = extractor.readSampleData(inBuf, 0)
                                    if (sampleSize < 0) {
                                        codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                        inputEos = true
                                    } else {
                                        val pts = extractor.sampleTime.coerceAtLeast(0L)
                                        codec.queueInputBuffer(inIdx, 0, sampleSize, pts, 0)
                                        extractor.advance()
                                    }
                                }
                            }
                        }

                        val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                        when {
                            outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                val outFmt = codec.outputFormat
                                if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                                    srcSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE).coerceIn(8000, 96000)
                                }
                                if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                                    srcChannels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 8)
                                }
                            }
                            outIdx >= 0 -> {
                                val outBuf = codec.getOutputBuffer(outIdx)
                                if (outBuf != null && info.size > 0) {
                                    val chunk = ByteArray(info.size)
                                    outBuf.position(info.offset)
                                    outBuf.get(chunk)
                                    val bb = ByteBuffer.wrap(chunk).order(ByteOrder.LITTLE_ENDIAN)
                                    val frameCount = chunk.size / (2 * srcChannels)
                                    val monoChunk = ByteBuffer.allocate(frameCount * 2).order(ByteOrder.LITTLE_ENDIAN)
                                    for (f in 0 until frameCount) {
                                        var sum = 0
                                        for (c in 0 until srcChannels) {
                                            sum += bb.getShort((f * srcChannels + c) * 2).toInt()
                                        }
                                        monoChunk.putShort((sum / srcChannels).coerceIn(-32767, 32767).toShort())
                                    }
                                    pcmMonoOut.write(monoChunk.array())
                                }
                                codec.releaseOutputBuffer(outIdx, false)
                                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                    outputEos = true
                                }
                            }
                        }
                    }

                    val rawMonoBytes = pcmMonoOut.toByteArray()
                    val count = rawMonoBytes.size / 2
                    if (count <= 0) return@runCatching null
                    val bb = ByteBuffer.wrap(rawMonoBytes).order(ByteOrder.LITTLE_ENDIAN)
                    val samples = ShortArray(count) { bb.getShort(it * 2) }
                    val finalSamples = if (srcSampleRate != targetSampleRate) {
                        resampleMonoPcm16(samples, srcSampleRate, targetSampleRate)
                    } else samples
                    ParsedWav(targetSampleRate, finalSamples)
                } finally {
                    runCatching { codec?.stop() }
                    runCatching { codec?.release() }
                    runCatching { extractor.release() }
                }
            }.getOrNull()
        }

        /**
         * Mixes all active audio tracks (WAV or MP3/M4A/AAC auto-decoded!) into a single mono 44.1kHz PCM16 timeline buffer
         * for real offline AAC audio muxing inside exported MP4 videos.
         *
         * Master Upgrade Module 5 guarantees:
         * - Strict One-Shot mixing by default (loopClip = false): strictly clamps to [startFrame, endFrame] AND actual
         *   decoded buffer length so clips NEVER loop or repeat unwanted audio!
         * - Frame-accurate start sample alignment (`(relativeStartFrames * targetSampleRate) / fps`).
         * - Smooth Auto-Ducking to BGM tracks whenever Voiceover tracks speak.
         */
        fun mixTracksToPcm16(
            tracks: List<AudioTrackItem>,
            totalFrames: Int,
            fps: Int,
            targetSampleRate: Int = 44100,
            startFrameOffset: Int = 0,
            trackLaneMuted: Map<Int, Boolean> = emptyMap()
        ): ShortArray? {
            val active = tracks.filter {
                !it.muted && !it.isMuted && (trackLaneMuted[it.trackIndex] != true) &&
                    (it.filePath.isNotBlank() || it.uri.isNotBlank())
            }
            if (active.isEmpty() || totalFrames <= 0) return null
            val safeFps = fps.coerceAtLeast(1)
            val durationSec = totalFrames.toDouble() / safeFps.toDouble()
            val totalSamples = (durationSec * targetSampleRate).toInt().coerceAtLeast(1024)
            val voiceBus = FloatArray(totalSamples)
            val voiceEnvelope = FloatArray(totalSamples)
            val otherBus = FloatArray(totalSamples)
            val duckedMusicBus = FloatArray(totalSamples)
            var wroteAny = false

            fun mixIntoBus(track: AudioTrackItem, targetBus: FloatArray, recordEnvelope: Boolean) {
                val resolvedPath = track.filePath.ifBlank { track.uri }
                val file = File(resolvedPath)
                if (!file.exists()) return
                val parsed = decodeAnyAudioFileToMonoPcm16(file, targetSampleRate) ?: return
                if (parsed.samples.isEmpty()) return
                wroteAny = true

                val relativeStartFrames = track.startFrame - startFrameOffset
                val dstStart = ((relativeStartFrames.toDouble() / safeFps.toDouble()) * targetSampleRate).toInt()
                val trimStartSample = ((track.trimStartMs / 1000.0) * parsed.sampleRate).toInt().coerceIn(0, parsed.samples.size)
                val rawTrimEnd = if (track.trimEndMs > track.trimStartMs) {
                    ((track.trimEndMs / 1000.0) * parsed.sampleRate).toInt()
                } else parsed.samples.size
                val trimEndSample = rawTrimEnd.coerceIn(trimStartSample, parsed.samples.size)
                val rawTrimSpan = (trimEndSample - trimStartSample).coerceAtLeast(0)
                if (rawTrimSpan <= 0) return

                // Apply speed and pitch resampling factor to trimmed slice if needed
                val safeSpeed = track.speed.coerceIn(0.5f, 2.0f)
                val safePitch = track.pitch.coerceIn(0.5f, 2.0f)
                val trimmedSlice = parsed.samples.copyOfRange(trimStartSample, trimEndSample)
                val rateFactor = (safeSpeed * safePitch).coerceIn(0.25f, 4.0f)
                val effectiveSamples = if (kotlin.math.abs(rateFactor - 1.0f) > 0.01f) {
                    resamplePitch(trimmedSlice, rateFactor)
                } else {
                    trimmedSlice
                }
                val srcSpan = effectiveSamples.size
                if (srcSpan <= 0) return

                val isLoop = track.loopClip || track.isLooping
                // Strict One-Shot clamp: limit destination span to BOTH clip [startFrame..endFrame] AND actual PCM length
                // (unless loopClip/isLooping == true, in which case repeat up to endFrame or totalSamples).
                val clipFrameLimitSamples = if (track.endFrame > track.startFrame) {
                    (((track.endFrame - track.startFrame).toDouble() / safeFps.toDouble()) * targetSampleRate).toInt().coerceAtLeast(1)
                } else {
                    if (isLoop) (totalSamples - dstStart).coerceAtLeast(0) else srcSpan
                }
                val dstSpan = if (isLoop) {
                    clipFrameLimitSamples.coerceAtMost((totalSamples - dstStart).coerceAtLeast(0))
                } else {
                    minOf(srcSpan, clipFrameLimitSamples)
                }
                if (dstSpan <= 0) return

                val fadeInSamples = ((track.fadeInMs / 1000.0) * targetSampleRate).toInt().coerceAtLeast(1)
                val fadeOutSamples = ((track.fadeOutMs / 1000.0) * targetSampleRate).toInt().coerceAtLeast(1)

                for (k in 0 until dstSpan) {
                    val dstIdx = dstStart + k
                    if (dstIdx < 0) continue
                    if (dstIdx >= totalSamples) break
                    val localK = if (isLoop) (k % srcSpan) else k
                    if (localK >= srcSpan) break
                    val srcIdx = localK.coerceIn(0, effectiveSamples.lastIndex)
                    var sample = effectiveSamples[srcIdx].toFloat() * track.volume.coerceIn(0f, 1.5f)
                    if (track.fadeInMs > 0L && k < fadeInSamples) sample *= (k.toFloat() / fadeInSamples)
                    val rem = dstSpan - k
                    if (track.fadeOutMs > 0L && rem < fadeOutSamples) sample *= (rem.toFloat() / fadeOutSamples)
                    targetBus[dstIdx] += sample
                    if (recordEnvelope) {
                        val mag = abs(sample) / 32768f
                        if (mag > voiceEnvelope[dstIdx]) voiceEnvelope[dstIdx] = mag
                    }
                }
            }

            // Pass 1: Mix voice tracks first so we know exact speech segments for Auto-Ducking
            active.forEach { track ->
                when {
                    track.trackIndex == 0 || track.kind == AudioTrackKind.VOICE.name -> mixIntoBus(track, voiceBus, recordEnvelope = true)
                    (track.trackIndex == 2 || track.kind == AudioTrackKind.MUSIC.name) && track.autoDuckMusic -> mixIntoBus(track, duckedMusicBus, recordEnvelope = false)
                    else -> mixIntoBus(track, otherBus, recordEnvelope = false)
                }
            }
            if (!wroteAny) return null

            // Smooth attack/release voice ducking gain envelope (ducks BGM smoothly down to 28% during speech)
            var currentGain = 1.0f
            val attackCoeff = 0.004f
            val releaseCoeff = 0.0005f
            return ShortArray(totalSamples) { i ->
                val isVoiceActive = voiceEnvelope[i] > 0.045f
                val targetGain = if (isVoiceActive) 0.28f else 1.0f
                val coeff = if (targetGain < currentGain) attackCoeff else releaseCoeff
                currentGain += (targetGain - currentGain) * coeff
                val combined = voiceBus[i] + otherBus[i] + duckedMusicBus[i] * currentGain
                combined.toInt().coerceIn(-32767, 32767).toShort()
            }
        }

        /**
         * Resolves a manual Frame or Second interval setting into exact integer frame count at [fps].
         */
        fun resolveIntervalFrames(
            framesValue: Int,
            secondsValue: Float,
            useSeconds: Boolean,
            fps: Int,
            minFrames: Int = 1,
            maxFrames: Int = 240
        ): Int {
            val safeFps = fps.coerceAtLeast(1)
            val raw = if (useSeconds) {
                kotlin.math.round(secondsValue.coerceIn(0.05f, 10.0f) * safeFps).toInt()
            } else {
                framesValue
            }
            return raw.coerceIn(minFrames, maxFrames)
        }

        fun resolveLipSyncIntervalFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.lipSyncIntervalFrames,
                secondsValue = timing.lipSyncIntervalSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 1,
                maxFrames = 120
            )

        fun resolveBlinkIntervalFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.blinkIntervalFrames,
                secondsValue = timing.blinkIntervalSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 4,
                maxFrames = 300
            )

        fun resolveBlinkDurationFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.blinkDurationFrames,
                secondsValue = timing.blinkDurationSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 1,
                maxFrames = 36
            )

        fun resolveEmotionCycleFrames(timing: FacialTimingConfig, fps: Int): Int =
            resolveIntervalFrames(
                framesValue = timing.emotionLoopSpeedFrames,
                secondsValue = timing.emotionLoopSpeedSec,
                useSeconds = timing.useSecondsUnit,
                fps = fps,
                minFrames = 1,
                maxFrames = 120
            )

        /**
         * Evaluates smooth multi-stage eye blink phase (OPEN -> HALF_BLINK -> CLOSED -> HALF_BLINK -> OPEN)
         * governed strictly by the user's manual Frame or Second blink interval and hold duration.
         */
        fun evaluateBlinkPhase(frame: Int, fps: Int, timing: FacialTimingConfig): BlinkPhase {
            val period = resolveBlinkIntervalFrames(timing, fps)
            val dur = resolveBlinkDurationFrames(timing, fps).coerceAtMost((period - 1).coerceAtLeast(1))
            val safeFrame = frame.coerceAtLeast(0)
            val phase = safeFrame % period
            if (phase >= dur) return BlinkPhase.OPEN
            return when {
                dur <= 1 -> BlinkPhase.CLOSED
                dur == 2 -> if (phase == 0) BlinkPhase.HALF_BLINK else BlinkPhase.CLOSED
                phase == 0 || phase == dur - 1 -> BlinkPhase.HALF_BLINK
                else -> BlinkPhase.CLOSED
            }
        }

        /**
         * Evaluates normalized voice waveform energy (0f..1f) stepped at the user's exact Lip-Sync Change Interval.
         */
        fun evaluateVoiceEnergyWithTiming(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            timing: FacialTimingConfig = FacialTimingConfig()
        ): Pair<Float, Int> {
            val voiceTracks = audioTracks.filter { !it.muted && !it.isMuted && it.waveformPeaks.isNotEmpty() }
                .sortedByDescending { it.trackIndex == 0 || it.kind == AudioTrackKind.VOICE.name }
            if (voiceTracks.isEmpty()) return 0f to 0

            val safeFps = fps.coerceAtLeast(1)
            val stepFrames = resolveLipSyncIntervalFrames(timing, safeFps)
            val stepBucket = frame.coerceAtLeast(0) / stepFrames
            val sampledFrame = stepBucket * stepFrames

            var maxEnergy = 0f
            for (track in voiceTracks) {
                val clipFrames = resolveTrackDurationFrames(track, safeFps)
                val isLoop = track.loopClip || track.isLooping
                val effEnd = if (track.endFrame > track.startFrame) {
                    if (isLoop) track.endFrame else minOf(track.endFrame, track.startFrame + clipFrames)
                } else {
                    track.startFrame + clipFrames
                }
                if (sampledFrame >= track.startFrame && sampledFrame < effEnd) {
                    val localOffset = if (isLoop) (sampledFrame - track.startFrame) % clipFrames else (sampledFrame - track.startFrame)
                    val rel = localOffset.toFloat() / clipFrames.toFloat()
                    val idx = (rel * track.waveformPeaks.size).toInt().coerceIn(0, track.waveformPeaks.lastIndex)
                    val energy = track.waveformPeaks[idx] * track.volume
                    if (energy > maxEnergy) maxEnergy = energy
                }
            }
            return maxEnergy.coerceIn(0f, 1.2f) to stepBucket
        }

        /**
         * Evaluates voice audio energy stepped cleanly at the user's exact Lip-Sync Change Interval
         * (frames or seconds) so mouth transitions never jitter faster than configured.
         */
        fun evaluateLipSyncPhonemeWithTiming(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            timing: FacialTimingConfig = FacialTimingConfig()
        ): MouthPhoneme {
            val (maxEnergy, stepBucket) = evaluateVoiceEnergyWithTiming(audioTracks, frame, fps, timing)
            return when {
                maxEnergy < 0.14f -> MouthPhoneme.REST
                maxEnergy < 0.30f -> MouthPhoneme.HALF_OPEN
                maxEnergy < 0.50f -> if (stepBucket % 2 == 0) MouthPhoneme.E else MouthPhoneme.I
                maxEnergy < 0.72f -> if (stepBucket % 2 == 0) MouthPhoneme.O else MouthPhoneme.U
                else -> MouthPhoneme.A
            }
        }

        /**
         * Module 5: Smart Auto-Dubbing 6-Frame Mouth Mood Evaluator.
         * - During voice speech: automatically triggers Frames 3..6 driven by audio amplitude & lip-sync interval.
         * - During silent pauses: automatically falls back to Frames 1..2 while preserving the active emotion
         *   (e.g., Crying stays silently crying on Frame 2 during pauses instead of snapping to neutral!).
         */
        fun evaluateMouthMoodFrame(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            timing: FacialTimingConfig = FacialTimingConfig(),
            activeMouthMood: String = com.example.data.model.FaceMoodCategory.NORMAL.name
        ): Int {
            val (energy, stepBucket) = evaluateVoiceEnergyWithTiming(audioTracks, frame, fps, timing)
            val isSilent = energy < 0.14f
            if (isSilent) {
                val emoCycle = resolveEmotionCycleFrames(timing, fps).coerceAtLeast(2)
                val isExpressiveMood = activeMouthMood != com.example.data.model.FaceMoodCategory.NORMAL.name
                return if (isExpressiveMood) {
                    if ((frame / emoCycle) % 3 == 0) 1 else 2
                } else {
                    if ((frame / (emoCycle * 2)) % 4 == 0) 2 else 1
                }
            }
            return when {
                energy < 0.30f -> 3 // Soft speech
                energy < 0.52f -> 4 // Medium speech
                energy < 0.74f -> if (stepBucket % 3 == 0) 6 else 5 // Wide speech with accent
                else -> 6 // Peak emotion accent
            }
        }

        /**
         * Module 6: Auto-Dialogue Head Bounce.
         * Returns (headNodDeg in -6f..6f, chinBouncePx in 0f..5f) synced to voice syllables when speaking.
         */
        fun evaluateDialogueHeadBounce(
            audioTracks: List<AudioTrackItem>,
            frame: Int,
            fps: Int,
            enabled: Boolean,
            timing: FacialTimingConfig = FacialTimingConfig()
        ): Pair<Float, Float> {
            if (!enabled) return 0f to 0f
            val (energy, _) = evaluateVoiceEnergyWithTiming(audioTracks, frame, fps, timing)
            if (energy < 0.14f) return 0f to 0f
            val intensity = ((energy - 0.14f) / 0.86f).coerceIn(0f, 1f)
            val syllableWave = sin(frame * 0.62).toFloat()
            val nodDeg = (syllableWave * (1.2f + intensity * 4.8f)).coerceIn(-6f, 6f)
            val chinBouncePx = (kotlin.math.abs(syllableWave) * intensity * 4.2f).coerceIn(0f, 5f)
            return nodDeg to chinBouncePx
        }
    }
}
