package com.example.engine

import com.example.data.model.AnimationLayer
import com.example.data.model.AnimationScene
import com.example.data.model.AudioTrackItem
import com.example.data.model.AudioTrackKind
import com.example.data.model.BoneAttachmentState
import com.example.data.model.CameraKeyframe
import com.example.data.model.CharacterBehaviorPreset
import com.example.data.model.CharacterFormKeyframe
import com.example.data.model.CharacterViewAngle
import com.example.data.model.EasingType
import com.example.data.model.EyePackStyle
import com.example.data.model.EyebrowStyle
import com.example.data.model.FaceMoodCategory
import com.example.data.model.FrameContent
import com.example.data.model.HandGesturePose
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.PropGrabKeyframe
import com.example.data.model.PuppetRootKeyframe
import com.example.data.model.SkeletalRig
import com.example.data.model.TargetedLoopType
import com.example.data.model.TransformKeyframe
import com.example.data.model.Vec2
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

data class EvaluatedTransform(
    val x: Float = 0f,
    val y: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val opacity: Float = 1f
)

data class EvaluatedCamera(
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val rotationDeg: Float = 0f,
    val shakeIntensity: Float = 0f,
    val impactFlashAlpha: Float = 0f,
    val impactFlashColorArgb: Long = 0xFFFFFFFFL,
    val motionBlurAmount: Float = 0f
)

data class EvaluatedPuppetRoot(
    val rootX: Float,
    val rootY: Float,
    val scale: Float,
    val flippedHorizontal: Boolean,
    val eyePack: String,
    val mouthPhoneme: String,
    val viewAngle: String = CharacterViewAngle.FRONT.name,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val eyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftHandGesture: String = HandGesturePose.RELAXED.name,
    val rightHandGesture: String = HandGesturePose.RELAXED.name,
    val behaviorPreset: String = CharacterBehaviorPreset.NORMAL_CALM.name,
    val headTurn25D: Float = 0f,
    val leftEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val rightEyebrowStyle: String = EyebrowStyle.NORMAL.name,
    val leftPupilX: Float = 0f,
    val leftPupilY: Float = 0f,
    val rightPupilX: Float = 0f,
    val rightPupilY: Float = 0f,
    val activeEyeMood: String = FaceMoodCategory.NORMAL.name,
    val activeMouthMood: String = FaceMoodCategory.NORMAL.name,
    // Decoupled Eyebrow & Eye independent keyframeable properties
    val leftBrowY: Float = 0f,
    val rightBrowY: Float = 0f,
    val leftBrowTilt: Float = 0f,
    val rightBrowTilt: Float = 0f,
    val browArch: Float = 0f,
    val browSpacing: Float = 1f,
    val browScale: Float = 1f,
    val eyeSpacing: Float = 1f,
    val eyeScale: Float = 1f,
    // Automatic Head Bob / Sway controls
    val headBobEnabled: Boolean = true,
    val headBobMode: String = "TALK_ONLY",
    val headBobIntensity: Float = 0.4f,
    // Step-hold evaluated semantic body-part Z-order overrides
    val partZOrder: Map<String, Int> = emptyMap()
)

data class EvaluatedFormMorph(
    val form: CharacterFormKeyframe,
    val transitionProgress: Float // 0f..1f during transition burst, -1f when steady
)

object InterpolationEngine {

    /**
     * Checks global track visibility, Instant Visibility Keyframes (Instant Show & Hide),
     * and explicit Frame Visibility Ranges. Clip start/end filtering is intentionally omitted
     * so characters and layers never disappear unexpectedly across frames.
     */
    fun isLayerVisibleAtFrame(layer: AnimationLayer, frame: Int): Boolean {
        if (!layer.visible) return false
        if (layer.visibilityKeyframes.isNotEmpty()) {
            val activeKf = layer.visibilityKeyframes
                .filter { it.frame <= frame }
                .maxByOrNull { it.frame }
            if (activeKf != null && !activeKf.visible) return false
        }
        if (layer.visibilityRanges.isEmpty()) return true
        return layer.visibilityRanges.any { range -> frame in range.startFrame..range.endFrame }
    }

    /**
     * Evaluates keyframed character swaps using strict step/hold interpolation:
     * returns the latest targetCharacterId at or before [frame], or null if no swap applies yet.
     */
    fun evaluateCharacterSwapId(layer: AnimationLayer, frame: Int): String? {
        if (layer.characterSwapKeyframes.isEmpty()) return null
        return layer.characterSwapKeyframes.entries
            .filter { it.key <= frame }
            .maxByOrNull { it.key }
            ?.value
    }

    /**
     * Resolves the active SkeletalRig for [layer] at [frame], merging any active step-hold
     * character swap target's artwork, rig bones, and facial sets while preserving the layer's
     * stage position, scale, and animated bone/root keyframes cleanly.
     */
    fun resolveEffectiveRigAtFrame(
        layer: AnimationLayer,
        frame: Int,
        libraryLookup: Map<String, SkeletalRig> = emptyMap()
    ): SkeletalRig? {
        val baseRig = layer.rig ?: return null
        val targetId = evaluateCharacterSwapId(layer, frame) ?: return baseRig
        val targetRig = layer.characterSwapRigs[targetId] ?: libraryLookup[targetId] ?: return baseRig
        return targetRig.copy(
            rootX = baseRig.rootX,
            rootY = baseRig.rootY,
            scale = baseRig.scale,
            scaleX = baseRig.scaleX,
            scaleY = baseRig.scaleY,
            flippedHorizontal = baseRig.flippedHorizontal,
            viewAngle = baseRig.viewAngle,
            rootKeyframes = baseRig.rootKeyframes,
            poseKeyframes = baseRig.poseKeyframes,
            boneLengthKeyframes = baseRig.boneLengthKeyframes,
            boneZOrderKeyframes = baseRig.boneZOrderKeyframes,
            ikEnabled = baseRig.ikEnabled
        )
    }

    fun applyEasing(t: Float, easingName: String): Float {
        val clamped = t.coerceIn(0f, 1f)
        val easing = runCatching { EasingType.valueOf(easingName) }.getOrDefault(EasingType.EASE_IN_OUT)
        return when (easing) {
            EasingType.LINEAR -> clamped
            EasingType.SNAP -> if (clamped < 0.99f) 0f else 1f
            EasingType.EASE_IN -> clamped * clamped * clamped
            EasingType.EASE_OUT -> 1f - (1f - clamped).pow(3)
            EasingType.EASE_IN_OUT -> if (clamped < 0.5f) {
                4f * clamped * clamped * clamped
            } else {
                1f - (-2f * clamped + 2f).pow(3) / 2f
            }
            EasingType.BOUNCE -> bounceOut(clamped)
        }
    }

    private fun bounceOut(x: Float): Float {
        val n1 = 7.5625f
        val d1 = 2.75f
        return when {
            x < 1f / d1 -> n1 * x * x
            x < 2f / d1 -> {
                val t = x - 1.5f / d1
                n1 * t * t + 0.75f
            }
            x < 2.5f / d1 -> {
                val t = x - 2.25f / d1
                n1 * t * t + 0.9375f
            }
            else -> {
                val t = x - 2.625f / d1
                n1 * t * t + 0.984375f
            }
        }
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    data class PathSample(
        val position: Vec2,
        val tangentAngleDeg: Float,
        val distanceTraveled: Float,
        val totalLength: Float,
        val dx: Float,
        val dy: Float
    )

    /**
     * Evaluates motion path progress [0f..1f] strictly inside the explicit frame bounds
     * [layer.motionPathStartFrame..layer.motionPathEndFrame].
     * NEVER stretches or scales with [totalFrames] when extra frames are added to the timeline!
     */
    fun evaluateMotionPathProgress(layer: AnimationLayer, frame: Int, totalFrames: Int): Float {
        if (layer.motionPath.size < 2) return 0f
        val startF = layer.motionPathStartFrame.coerceAtLeast(0)
        val endF = if (layer.motionPathEndFrame > startF) {
            layer.motionPathEndFrame
        } else {
            startF + 10
        }
        val rawT = when {
            frame <= startF -> 0f
            frame >= endF -> 1f
            else -> (frame - startF).toFloat() / (endF - startF).coerceAtLeast(1).toFloat()
        }
        return applyEasing(rawT, layer.motionPathEasing).coerceIn(0f, 1f)
    }

    /**
     * Computes the un-transformed visual center of a non-rig layer (character, PNG image, shape, or drawing)
     * so motion path following glides the object directly ON the drawn curve instead of off-screen.
     */
    fun computeLayerVisualCenter(layer: AnimationLayer, frame: Int): Vec2? {
        layer.character?.let { c -> return Vec2(c.x, c.y) }
        val content = resolveFrameContent(layer, frame, holdPrevious = true) ?: return null
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        fun include(x: Float, y: Float) {
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }
        content.images.forEach { img ->
            include(img.x - img.width / 2f, img.y - img.height / 2f)
            include(img.x + img.width / 2f, img.y + img.height / 2f)
        }
        content.shapes.filter { it.kind != com.example.data.model.ShapeKind.FILL_BACKDROP.name }.forEach { s ->
            include(s.startX, s.startY); include(s.endX, s.endY)
        }
        content.strokes.forEach { st -> st.points.forEach { include(it.x, it.y) } }
        content.texts.forEach { t -> include(t.x, t.y) }
        if (!minX.isFinite()) return null
        return Vec2((minX + maxX) / 2f, (minY + maxY) / 2f)
    }

    fun evaluateLayerTransform(layer: AnimationLayer, frame: Int, totalFrames: Int): EvaluatedTransform {
        var base = if (layer.keyframes.isEmpty()) {
            EvaluatedTransform(
                x = if (layer.baseX.isFinite()) layer.baseX else 0f,
                y = if (layer.baseY.isFinite()) layer.baseY else 0f,
                rotationDeg = if (layer.baseRotationDeg.isFinite()) layer.baseRotationDeg else 0f,
                scaleX = if (layer.baseScaleX.isFinite() && layer.baseScaleX >= 0.05f) layer.baseScaleX else 1f,
                scaleY = if (layer.baseScaleY.isFinite() && layer.baseScaleY >= 0.05f) layer.baseScaleY else 1f,
                opacity = 1f
            )
        } else {
            val sorted = layer.keyframes.sortedBy { it.frame }
            when {
                frame <= sorted.first().frame -> sorted.first().toEvaluated()
                frame >= sorted.last().frame -> sorted.last().toEvaluated()
                else -> {
                    val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                    val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                    val next = sorted[nextIdx]
                    if (prev.frame == next.frame) {
                        next.toEvaluated()
                    } else {
                        val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                        val eased = applyEasing(rawT, prev.easing)
                        EvaluatedTransform(
                            x = lerp(prev.x, next.x, eased),
                            y = lerp(prev.y, next.y, eased),
                            rotationDeg = lerp(prev.rotationDeg, next.rotationDeg, eased),
                            scaleX = lerp(prev.scaleX, next.scaleX, eased),
                            scaleY = lerp(prev.scaleY, next.scaleY, eased),
                            opacity = lerp(prev.opacity, next.opacity, eased)
                        )
                    }
                }
            }
        }

        // For RIG layers, motion path moves the puppet root directly in evaluatePuppetRootWithPath (avoid double-offsetting!).
        val isRigLayer = layer.type == com.example.data.model.LayerType.RIG.name && layer.rig != null
        if (!isRigLayer && layer.motionPath.size >= 2 && totalFrames > 1) {
            val progress = evaluateMotionPathProgress(layer, frame, totalFrames)
            val sample = sampleSmoothPath(layer.motionPath, progress)
            val anchor = computeLayerVisualCenter(layer, frame) ?: layer.motionPath.first()
            base = base.copy(
                x = base.x + (sample.position.x - anchor.x),
                y = base.y + (sample.position.y - anchor.y),
                rotationDeg = if (layer.motionPathOrientToPath) {
                    base.rotationDeg + sample.tangentAngleDeg
                } else {
                    base.rotationDeg
                }
            )
        }
        // Master Upgrade Module 4: VN-Style Clip In-Animation, Out-Animation & Loop Animation Presets
        val clipStart = layer.clipStartFrame.coerceAtLeast(0)
        val clipEnd = if (layer.clipEndFrame >= clipStart) layer.clipEndFrame else (totalFrames - 1).coerceAtLeast(clipStart)
        val animLen = layer.clipAnimationFrames.coerceIn(1, 60)
        val inFrames = frame - clipStart
        val outFrames = clipEnd - frame

        if (inFrames in 0 until animLen) {
            val p = applyEasing(inFrames.toFloat() / animLen.toFloat(), EasingType.EASE_OUT.name)
            base = when (layer.clipInAnimation) {
                com.example.data.model.ClipAnimationPreset.FADE.name -> base.copy(opacity = base.opacity * p)
                com.example.data.model.ClipAnimationPreset.POP.name -> base.copy(
                    scaleX = base.scaleX * (0.2f + 0.8f * applyEasing(inFrames.toFloat() / animLen.toFloat(), EasingType.BOUNCE.name)),
                    scaleY = base.scaleY * (0.2f + 0.8f * applyEasing(inFrames.toFloat() / animLen.toFloat(), EasingType.BOUNCE.name)),
                    opacity = base.opacity * p.coerceAtLeast(0.25f)
                )
                com.example.data.model.ClipAnimationPreset.SLIDE.name -> base.copy(
                    x = base.x - (1f - p) * 240f,
                    opacity = base.opacity * p.coerceAtLeast(0.2f)
                )
                com.example.data.model.ClipAnimationPreset.FLASH.name -> base.copy(
                    opacity = base.opacity * (if (inFrames % 2 == 0) 1f else 0.35f)
                )
                else -> base
            }
        }
        if (outFrames in 0 until animLen) {
            val p = applyEasing(outFrames.toFloat() / animLen.toFloat(), EasingType.EASE_IN.name)
            base = when (layer.clipOutAnimation) {
                com.example.data.model.ClipAnimationPreset.FADE.name -> base.copy(opacity = base.opacity * p)
                com.example.data.model.ClipAnimationPreset.POP.name -> base.copy(
                    scaleX = base.scaleX * (0.2f + 0.8f * p),
                    scaleY = base.scaleY * (0.2f + 0.8f * p),
                    opacity = base.opacity * p
                )
                com.example.data.model.ClipAnimationPreset.SLIDE.name -> base.copy(
                    x = base.x + (1f - p) * 240f,
                    opacity = base.opacity * p
                )
                com.example.data.model.ClipAnimationPreset.FLASH.name -> base.copy(
                    opacity = base.opacity * (if (outFrames % 2 == 0) 1f else 0.25f)
                )
                else -> base
            }
        }
        if (layer.clipLoopAnimation != com.example.data.model.ClipAnimationPreset.NONE.name && frame in clipStart..clipEnd) {
            val phase = (frame - clipStart) * 0.32
            base = when (layer.clipLoopAnimation) {
                com.example.data.model.ClipAnimationPreset.FADE.name ->
                    base.copy(opacity = base.opacity * (0.55f + 0.45f * kotlin.math.sin(phase).toFloat()))
                com.example.data.model.ClipAnimationPreset.POP.name -> {
                    val s = 1f + 0.08f * kotlin.math.sin(phase).toFloat()
                    base.copy(scaleX = base.scaleX * s, scaleY = base.scaleY * s)
                }
                com.example.data.model.ClipAnimationPreset.SLIDE.name ->
                    base.copy(y = base.y + kotlin.math.sin(phase).toFloat() * 14f)
                com.example.data.model.ClipAnimationPreset.FLASH.name ->
                    base.copy(opacity = base.opacity * if (((frame - clipStart) / 3) % 2 == 0) 1f else 0.35f)
                else -> base
            }
        }
        return EvaluatedTransform(
            x = if (base.x.isFinite()) base.x else 0f,
            y = if (base.y.isFinite()) base.y else 0f,
            rotationDeg = if (base.rotationDeg.isFinite()) base.rotationDeg else 0f,
            scaleX = if (base.scaleX.isFinite() && base.scaleX >= 0.05f) base.scaleX else 1f,
            scaleY = if (base.scaleY.isFinite() && base.scaleY >= 0.05f) base.scaleY else 1f,
            opacity = if (base.opacity.isFinite()) base.opacity.coerceIn(0f, 1f) else 1f
        )
    }

    fun evaluatePuppetRoot(rig: SkeletalRig, frame: Int): EvaluatedPuppetRoot {
        if (rig.rootKeyframes.isEmpty()) {
            return EvaluatedPuppetRoot(
                rootX = rig.rootX,
                rootY = rig.rootY,
                scale = rig.scale,
                flippedHorizontal = rig.flippedHorizontal,
                eyePack = rig.eyePack,
                mouthPhoneme = rig.mouthPhoneme,
                viewAngle = rig.viewAngle,
                scaleX = rig.scaleX,
                scaleY = rig.scaleY,
                eyebrowStyle = rig.eyebrowStyle,
                leftHandGesture = rig.leftHandGesture,
                rightHandGesture = rig.rightHandGesture,
                behaviorPreset = rig.behaviorPreset,
                headTurn25D = rig.headTurn25D,
                leftEyebrowStyle = rig.leftEyebrowStyle,
                rightEyebrowStyle = rig.rightEyebrowStyle,
                leftPupilX = rig.leftPupilX,
                leftPupilY = rig.leftPupilY,
                rightPupilX = rig.rightPupilX,
                rightPupilY = rig.rightPupilY,
                activeEyeMood = rig.activeEyeMood,
                activeMouthMood = rig.activeMouthMood,
                leftBrowY = rig.leftBrowY,
                rightBrowY = rig.rightBrowY,
                leftBrowTilt = rig.leftBrowTilt,
                rightBrowTilt = rig.rightBrowTilt,
                browArch = rig.browArch,
                browSpacing = rig.browSpacing,
                browScale = rig.browScale,
                eyeSpacing = rig.eyeSpacing,
                eyeScale = rig.eyeScale,
                headBobEnabled = rig.headBobEnabled,
                headBobMode = rig.headBobMode,
                headBobIntensity = rig.headBobIntensity,
                partZOrder = rig.partZOrder
            )
        }
        val sorted = rig.rootKeyframes.sortedBy { it.frame }
        return when {
            frame <= sorted.first().frame -> sorted.first().toEvaluated()
            frame >= sorted.last().frame -> sorted.last().toEvaluated()
            else -> {
                val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                val next = sorted[nextIdx]
                if (prev.frame == next.frame) {
                    next.toEvaluated()
                } else {
                    val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                    val eased = applyEasing(rawT, prev.easing)
                    EvaluatedPuppetRoot(
                        rootX = lerp(prev.rootX, next.rootX, eased),
                        rootY = lerp(prev.rootY, next.rootY, eased),
                        scale = lerp(prev.scale, next.scale, eased).coerceIn(0.1f, 10f),
                        flippedHorizontal = prev.flippedHorizontal,
                        eyePack = prev.eyePack,
                        mouthPhoneme = prev.mouthPhoneme,
                        viewAngle = prev.viewAngle,
                        scaleX = lerp(prev.scaleX, next.scaleX, eased).coerceIn(0.15f, 6f),
                        scaleY = lerp(prev.scaleY, next.scaleY, eased).coerceIn(0.15f, 6f),
                        eyebrowStyle = prev.eyebrowStyle,
                        leftHandGesture = prev.leftHandGesture,
                        rightHandGesture = prev.rightHandGesture,
                        behaviorPreset = prev.behaviorPreset,
                        headTurn25D = lerp(prev.headTurn25D, next.headTurn25D, eased).coerceIn(-1f, 1f),
                        leftEyebrowStyle = prev.leftEyebrowStyle,
                        rightEyebrowStyle = prev.rightEyebrowStyle,
                        leftPupilX = lerp(prev.leftPupilX, next.leftPupilX, eased).coerceIn(-1f, 1f),
                        leftPupilY = lerp(prev.leftPupilY, next.leftPupilY, eased).coerceIn(-1f, 1f),
                        rightPupilX = lerp(prev.rightPupilX, next.rightPupilX, eased).coerceIn(-1f, 1f),
                        rightPupilY = lerp(prev.rightPupilY, next.rightPupilY, eased).coerceIn(-1f, 1f),
                        activeEyeMood = prev.activeEyeMood,
                        activeMouthMood = prev.activeMouthMood,
                        leftBrowY = lerp(prev.leftBrowY, next.leftBrowY, eased).coerceIn(-36f, 36f),
                        rightBrowY = lerp(prev.rightBrowY, next.rightBrowY, eased).coerceIn(-36f, 36f),
                        leftBrowTilt = lerp(prev.leftBrowTilt, next.leftBrowTilt, eased).coerceIn(-45f, 45f),
                        rightBrowTilt = lerp(prev.rightBrowTilt, next.rightBrowTilt, eased).coerceIn(-45f, 45f),
                        browArch = lerp(prev.browArch, next.browArch, eased).coerceIn(-1f, 1f),
                        browSpacing = lerp(prev.browSpacing, next.browSpacing, eased).coerceIn(0.45f, 1.85f),
                        browScale = lerp(prev.browScale, next.browScale, eased).coerceIn(0.45f, 1.85f),
                        eyeSpacing = lerp(prev.eyeSpacing, next.eyeSpacing, eased).coerceIn(0.45f, 1.85f),
                        eyeScale = lerp(prev.eyeScale, next.eyeScale, eased).coerceIn(0.45f, 1.85f),
                        headBobEnabled = prev.headBobEnabled,
                        headBobMode = prev.headBobMode,
                        headBobIntensity = lerp(prev.headBobIntensity, next.headBobIntensity, eased).coerceIn(0f, 1f),
                        // Strict step-hold evaluation for partZOrder (nearest-previous keyframe!)
                        partZOrder = prev.partZOrder
                    )
                }
            }
        }
    }

    /**
     * Evaluates a rigged puppet's root transform while smoothly gliding directly along [layer.motionPath]
     * AND applying Targeted Loop facial overrides (Talking/Crying/Laughing) + Auto-Dialogue Hand Gestures.
     */
    fun evaluatePuppetRootWithPath(
        layer: AnimationLayer,
        rig: SkeletalRig,
        frame: Int,
        totalFrames: Int,
        audioTracks: List<AudioTrackItem> = emptyList(),
        fps: Int = 24
    ): EvaluatedPuppetRoot {
        var result = evaluatePuppetRoot(rig, frame)
        if (layer.motionPath.size >= 2 && totalFrames > 1) {
            val progress = evaluateMotionPathProgress(layer, frame, totalFrames)
            val sample = sampleSmoothPath(layer.motionPath, progress)
            val shouldAutoFlip = (layer.motionPathOrientToPath || rig.autoWalkWhenDragged) && kotlin.math.abs(sample.dx) > 0.25f
            val autoFlipped = if (shouldAutoFlip) sample.dx < 0f else result.flippedHorizontal
            result = result.copy(
                rootX = sample.position.x,
                rootY = sample.position.y,
                flippedHorizontal = autoFlipped
            )
        }

        // Apply active Targeted Loop expression overrides inside selected frame ranges (Module 8)
        layer.targetedLoops.filter { frame in it.startFrame..it.endFrame }.forEach { clip ->
            when (runCatching { TargetedLoopType.valueOf(clip.loopType) }.getOrNull()) {
                TargetedLoopType.TALKING_LOOP -> {
                    result = result.copy(mouthPhoneme = MouthPhoneme.TALKING_LOOP.name)
                }
                TargetedLoopType.CRYING_LOOP -> {
                    result = result.copy(
                        eyePack = EyePackStyle.SAD_TEARS.name,
                        mouthPhoneme = MouthPhoneme.CRYING.name,
                        eyebrowStyle = EyebrowStyle.WORRIED.name
                    )
                }
                TargetedLoopType.LAUGHING_LOOP -> {
                    result = result.copy(
                        eyePack = EyePackStyle.LAUGHING.name,
                        mouthPhoneme = MouthPhoneme.LAUGHING.name
                    )
                }
                TargetedLoopType.HORROR_TWITCH -> {
                    result = result.copy(
                        eyePack = EyePackStyle.SCARED_HORROR.name,
                        mouthPhoneme = MouthPhoneme.SCARED.name
                    )
                }
                else -> Unit
            }
        }

        // Apply active Preset Character Animation root motion & facial overrides strictly inside [clip.startFrame..clip.endFrame]
        layer.presetAnimations.filter { frame in it.startFrame..it.endFrame }.forEach { clip ->
            val localF = (frame - clip.startFrame).coerceAtLeast(0)
            val span = (clip.endFrame - clip.startFrame).coerceAtLeast(1)
            val normT = (localF.toFloat() / span.toFloat()).coerceIn(0f, 1f)
            when (clip.actionKind.uppercase()) {
                "WALK", "AUTO_WALK" -> {
                    val bobY = -kotlin.math.abs(kotlin.math.sin(localF * 0.45).toFloat()) * 8f
                    result = result.copy(rootY = result.rootY + bobY)
                }
                "RUN" -> {
                    val bobY = -kotlin.math.abs(kotlin.math.sin(localF * 0.72).toFloat()) * 14f
                    result = result.copy(rootY = result.rootY + bobY)
                }
                "JUMP" -> {
                    val arc = kotlin.math.sin(normT * Math.PI).toFloat()
                    val squashX = when {
                        normT < 0.15f || normT > 0.85f -> 1.12f
                        else -> 0.94f
                    }
                    val stretchY = when {
                        normT < 0.15f || normT > 0.85f -> 0.88f
                        else -> 1.08f
                    }
                    result = result.copy(
                        rootY = result.rootY - arc * 95f,
                        scaleX = (result.scaleX * squashX).coerceIn(0.15f, 3.5f),
                        scaleY = (result.scaleY * stretchY).coerceIn(0.15f, 3.5f)
                    )
                }
                "TALK", "TALKING" -> {
                    result = result.copy(mouthPhoneme = MouthPhoneme.TALKING_LOOP.name)
                }
                "SLIP_FALL", "FALL" -> {
                    val drop = applyEasing(normT, EasingType.BOUNCE.name)
                    result = result.copy(
                        rootY = result.rootY + drop * 72f,
                        eyePack = EyePackStyle.SURPRISED.name,
                        mouthPhoneme = MouthPhoneme.SCARED.name
                    )
                }
                "ANIME_PUNCH", "PUNCH" -> {
                    val lunge = kotlin.math.sin(normT * Math.PI).toFloat() * 34f
                    val dir = if (result.flippedHorizontal) -1f else 1f
                    result = result.copy(
                        rootX = result.rootX + lunge * dir,
                        eyebrowStyle = EyebrowStyle.ANGRY.name
                    )
                }
            }
        }

        // Module 4 & 6: Auto-Dialogue Acting cycles natural open-palm / pointing hand gestures while speaking
        if (rig.autoDialogueActing) {
            val speakingFromAudio = audioTracks.isNotEmpty() &&
                evaluateLipSyncPhoneme(audioTracks, frame, fps) != MouthPhoneme.REST
            val speakingFromMouth = result.mouthPhoneme == MouthPhoneme.TALKING_LOOP.name
            if (speakingFromAudio || speakingFromMouth) {
                val gestureCycle = (frame / 14) % 3
                val autoRight = when (gestureCycle) {
                    0 -> HandGesturePose.OPEN_PALM.name
                    1 -> HandGesturePose.POINTING.name
                    else -> HandGesturePose.OPEN_PALM.name
                }
                val autoLeft = if (gestureCycle == 2) HandGesturePose.OPEN_PALM.name else result.leftHandGesture
                result = result.copy(rightHandGesture = autoRight, leftHandGesture = autoLeft)
            }
        }
        // Whole-Character Acting Behavior Preset root motion (floating hover, bouncy step, tremor)
        val activeMood = runCatching { CharacterBehaviorPreset.valueOf(result.behaviorPreset) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
        when (activeMood) {
            CharacterBehaviorPreset.HORROR_GHOSTLY -> {
                val hoverY = kotlin.math.sin(frame * 0.16).toFloat() * 14f
                val driftX = kotlin.math.cos(frame * 0.11).toFloat() * 4f
                result = result.copy(rootX = result.rootX + driftX, rootY = result.rootY + hoverY)
            }
            CharacterBehaviorPreset.HAPPY_PLAYFUL -> {
                val bounceY = -kotlin.math.abs(kotlin.math.sin(frame * 0.34).toFloat()) * 9f
                result = result.copy(rootY = result.rootY + bounceY)
            }
            CharacterBehaviorPreset.ELDERLY_WEAK -> {
                val tremorX = kotlin.math.sin(frame * 1.9).toFloat() * 1.1f
                result = result.copy(rootX = result.rootX + tremorX)
            }
            else -> Unit
        }

        return result
    }

    /**
     * Evaluates interpolated bone lengths (Module 2 Live Stretch Rig keyframes + Horror elongated limb tension).
     */
    fun evaluateBoneLengths(rig: SkeletalRig, frame: Int): Map<String, Float> {
        val mood = runCatching { CharacterBehaviorPreset.valueOf(evaluatePuppetRoot(rig, frame).behaviorPreset) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)
        val defaultLengths = rig.bones.associate { bone ->
            val canStretch = bone.allowLengthStretch && bone.id != "neck"
            val horrorTension = if (canStretch && mood == CharacterBehaviorPreset.HORROR_GHOSTLY &&
                (bone.id == "arm_l_low" || bone.id == "arm_r_low" || bone.id == "hand_l" || bone.id == "hand_r")
            ) 1.18f else 1.0f
            bone.id to (bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f) * horrorTension)
        }
        if (rig.boneLengthKeyframes.isEmpty()) return defaultLengths

        val sortedFrames = rig.boneLengthKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        if (sortedFrames.isEmpty()) return defaultLengths

        fun clampForBone(bone: com.example.data.model.RigBone, rawLen: Float): Float {
            val baseLen = defaultLengths[bone.id] ?: (bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f))
            return if (!bone.allowLengthStretch || bone.id == "neck") baseLen else rawLen.coerceIn(8f, 420f)
        }

        rig.boneLengthKeyframes[frame.toString()]?.let { exact ->
            return rig.bones.associate { b -> b.id to clampForBone(b, exact[b.id] ?: (defaultLengths[b.id] ?: b.length)) }
        }

        return when {
            frame < sortedFrames.first() -> {
                val firstMap = rig.boneLengthKeyframes[sortedFrames.first().toString()] ?: emptyMap()
                rig.bones.associate { b -> b.id to clampForBone(b, firstMap[b.id] ?: (defaultLengths[b.id] ?: b.length)) }
            }
            frame > sortedFrames.last() -> {
                val lastMap = rig.boneLengthKeyframes[sortedFrames.last().toString()] ?: emptyMap()
                rig.bones.associate { b -> b.id to clampForBone(b, lastMap[b.id] ?: (defaultLengths[b.id] ?: b.length)) }
            }
            else -> {
                val nextIdx = sortedFrames.indexOfFirst { it >= frame }
                val prevF = sortedFrames[(nextIdx - 1).coerceAtLeast(0)]
                val nextF = sortedFrames[nextIdx]
                val prevMap = rig.boneLengthKeyframes[prevF.toString()] ?: emptyMap()
                val nextMap = rig.boneLengthKeyframes[nextF.toString()] ?: emptyMap()
                val t = applyEasing((frame - prevF).toFloat() / (nextF - prevF).coerceAtLeast(1).toFloat(), EasingType.EASE_IN_OUT.name)
                rig.bones.associate { bone ->
                    val baseLen = defaultLengths[bone.id] ?: (bone.length * bone.limbLengthScale.coerceIn(0.2f, 5f))
                    val a = prevMap[bone.id] ?: baseLen
                    val b = nextMap[bone.id] ?: baseLen
                    bone.id to clampForBone(bone, lerp(a, b, t))
                }
            }
        }
    }

    /**
     * Module 7: Evaluates Detached / Severed Bones (head, hand, limb) at [frame] with optional gravity fall.
     */
    fun evaluateDetachedBones(
        rig: SkeletalRig,
        frame: Int,
        fps: Int = 24
    ): Map<String, EvaluatedDetachedBone> {
        if (rig.detachedBoneKeyframes.isEmpty()) return emptyMap()
        val safeFps = fps.coerceAtLeast(1).toFloat()
        val byBone = rig.detachedBoneKeyframes.groupBy { it.boneId }
        val result = LinkedHashMap<String, EvaluatedDetachedBone>()
        for ((boneId, kfs) in byBone) {
            val sorted = kfs.sortedBy { it.frame }
            val active = sorted.lastOrNull { it.frame <= frame } ?: continue
            if (!active.detached) continue
            val next = sorted.firstOrNull { it.frame > frame && it.detached }
            if (next != null) {
                val rawT = (frame - active.frame).toFloat() / (next.frame - active.frame).coerceAtLeast(1).toFloat()
                val eased = applyEasing(rawT, EasingType.EASE_IN_OUT.name)
                result[boneId] = EvaluatedDetachedBone(
                    boneId = boneId,
                    worldX = lerp(active.worldX, next.worldX, eased),
                    worldY = lerp(active.worldY, next.worldY, eased),
                    worldAngleDeg = lerpAngle(active.rotationDeg, next.rotationDeg, eased)
                )
            } else {
                val elapsedSec = ((frame - active.frame).coerceAtLeast(0)) / safeFps
                val gravityDropY = if (active.gravityFall) {
                    (0.5f * 680f * elapsedSec * elapsedSec).coerceAtMost(560f)
                } else 0f
                val spinDeg = if (active.gravityFall) elapsedSec * 145f else 0f
                result[boneId] = EvaluatedDetachedBone(
                    boneId = boneId,
                    worldX = active.worldX,
                    worldY = active.worldY + gravityDropY,
                    worldAngleDeg = active.rotationDeg + spinDeg
                )
            }
        }
        return result
    }

    /**
     * Module 7: Evaluates Variable Hand Prop Socket (swap/drop/equip props mid-scene on Left or Right hand).
     */
    fun evaluateHandPropSocket(
        rig: SkeletalRig,
        isRightHand: Boolean,
        frame: Int
    ): Pair<String, String?> {
        val active = rig.handPropSocketKeyframes
            .filter { it.isRightHand == isRightHand && it.frame <= frame }
            .maxByOrNull { it.frame }
        if (active != null) return active.propKind to active.customImagePath
        return if (isRightHand) {
            rig.rightHandProp to rig.rightHandCustomImagePath
        } else {
            rig.leftHandProp to rig.leftHandCustomImagePath
        }
    }

    data class ResolvedPropWorldTransform(
        val worldX: Float,
        val worldY: Float,
        val worldAngleDeg: Float,
        val isAttached: Boolean,
        val worldScaleX: Float = 1f,
        val worldScaleY: Float = 1f,
        val hostLayerId: String? = null,
        val hostBoneId: String? = null,
        val hostBoneWorldX: Float = 0f,
        val hostBoneWorldY: Float = 0f,
        val hostBoneWorldAngleDeg: Float = 0f
    )

    /**
     * Evaluates universal any-bone attachment state ([BoneAttachmentState]) at [frame] via step-hold.
     * Checks generic [AnimationLayer.propBoneLinkKeyframes] first (supporting ANY bone on ANY character,
     * plus clean `isAttached = false` detach keyframes), falling back to legacy [AnimationLayer.propGrabKeyframes].
     */
    fun evaluatePropBoneLink(layer: AnimationLayer, frame: Int): BoneAttachmentState? {
        val linkEntry = layer.propBoneLinkKeyframes.entries
            .filter { it.key <= frame }
            .maxByOrNull { it.key }
        val legacyEntry = layer.propGrabKeyframes
            .filter { it.frame <= frame }
            .maxByOrNull { it.frame }

        // Prefer whichever keyframe is newer (or propBoneLinkKeyframes on ties)
        if (linkEntry != null && (legacyEntry == null || linkEntry.key >= legacyEntry.frame)) {
            return linkEntry.value
        }
        if (legacyEntry != null) {
            val attached = !legacyEntry.targetLayerId.isNullOrBlank() && !legacyEntry.targetBoneId.isNullOrBlank()
            return BoneAttachmentState(
                isAttached = attached,
                targetCharacterLayerId = legacyEntry.targetLayerId,
                targetBoneId = legacyEntry.targetBoneId,
                localOffsetX = legacyEntry.offsetX,
                localOffsetY = legacyEntry.offsetY,
                localRotationDeg = legacyEntry.rotationOffsetDeg
            )
        }
        return null
    }

    /**
     * Evaluates Scene Prop "Parent Socket / Grab Target" at [frame] so any rigid prop or imported image
     * can lock onto ANY bone/joint of ANY character and release cleanly with zero jump.
     */
    fun evaluatePropGrabTarget(layer: AnimationLayer, frame: Int): PropGrabKeyframe? {
        val link = evaluatePropBoneLink(layer, frame)
        if (link != null) {
            if (!link.isAttached || link.targetCharacterLayerId.isNullOrBlank() || link.targetBoneId.isNullOrBlank()) {
                return null
            }
            return PropGrabKeyframe(
                frame = frame,
                targetLayerId = link.targetCharacterLayerId,
                targetBoneId = link.targetBoneId,
                offsetX = link.localOffsetX,
                offsetY = link.localOffsetY,
                rotationOffsetDeg = link.localRotationDeg,
                useBoneLocalSpace = true,
                isBoneLocked = true
            )
        }
        if (layer.propGrabKeyframes.isEmpty()) return null
        val active = layer.propGrabKeyframes
            .filter { it.frame <= frame }
            .maxByOrNull { it.frame } ?: return null
        return if (active.targetLayerId.isNullOrBlank()) null else active
    }

    /**
     * Evaluates the exact world position (center pivot) and world rotation of a prop/image layer at [frame],
     * accounting for rigid child-bone attachment onto ANY bone of ANY character (or clean detached world coords).
     */
    fun resolvePropWorldTransform(
        scene: AnimationScene,
        layer: AnimationLayer,
        pivot: Vec2,
        frame: Int,
        audioTracks: List<AudioTrackItem> = emptyList(),
        fps: Int = 24
    ): ResolvedPropWorldTransform {
        val tf = evaluateLayerTransform(layer, frame, scene.durationFrames)
        val link = evaluatePropBoneLink(layer, frame)
        val isLinkAttached = link != null && link.isAttached &&
            !link.targetCharacterLayerId.isNullOrBlank() && !link.targetBoneId.isNullOrBlank()
        // Check legacy non-bone-local offset mode if the active record came from a legacy PropGrabKeyframe
        val legacyActive = layer.propGrabKeyframes.filter { it.frame <= frame }.maxByOrNull { it.frame }
        val linkFrame = layer.propBoneLinkKeyframes.keys.filter { it <= frame }.maxOrNull() ?: Int.MIN_VALUE
        val useBoneLocal = if (linkFrame >= (legacyActive?.frame ?: Int.MIN_VALUE)) {
            true
        } else {
            (legacyActive?.useBoneLocalSpace == true) || (legacyActive?.isBoneLocked == true)
        }

        if (isLinkAttached && link != null && layer.type != LayerType.RIG.name) {
            val hostLayer = scene.layers.firstOrNull { it.id == link.targetCharacterLayerId && it.rig != null }
            val hostRig = hostLayer?.let { resolveEffectiveRigAtFrame(it, frame) }
            if (hostLayer != null && hostRig != null) {
                val hostRoot = evaluatePuppetRootWithPath(hostLayer, hostRig, frame, scene.durationFrames, audioTracks, fps)
                val hostAngles = evaluateRigAnglesWithPath(hostLayer, hostRig, frame, scene.durationFrames, audioTracks, fps)
                val hostLens = evaluateBoneLengths(hostRig, frame)
                val hostDetached = evaluateDetachedBones(hostRig, frame, fps)
                val hostViewAngle = runCatching { CharacterViewAngle.valueOf(hostRoot.viewAngle) }.getOrDefault(CharacterViewAngle.FRONT)
                val hostFlipped = SceneRenderer.isLeftFacingView(hostViewAngle, hostRoot.flippedHorizontal)
                val hostSolved = RigSolver.solveForwardKinematics(
                    rig = hostRig,
                    angleOverrides = hostAngles,
                    rootX = hostRoot.rootX,
                    rootY = hostRoot.rootY,
                    scale = hostRoot.scale,
                    flippedHorizontal = hostFlipped,
                    lengthOverrides = hostLens,
                    scaleX = hostRoot.scaleX,
                    scaleY = hostRoot.scaleY,
                    frame = frame,
                    detachedBones = hostDetached,
                    viewAngle = hostViewAngle
                )
                val targetBone = hostSolved.firstOrNull { it.bone.id == link.targetBoneId }
                    ?: hostSolved.firstOrNull()
                if (targetBone != null) {
                    val hostTf = evaluateLayerTransform(hostLayer, frame, scene.durationFrames)
                    val boneX = targetBone.end.x + hostTf.x
                    val boneY = targetBone.end.y + hostTf.y
                    val boneAngleDeg = targetBone.worldAngleDeg + hostTf.rotationDeg
                    val (wx, wy, wAngle) = if (useBoneLocal) {
                        RigSolver.solveBoneAttachedWorldTransform(
                            boneWorldX = boneX,
                            boneWorldY = boneY,
                            boneWorldAngleDeg = boneAngleDeg,
                            localOffsetX = link.localOffsetX,
                            localOffsetY = link.localOffsetY,
                            localRotationDeg = link.localRotationDeg,
                            independentObjectRotationDeg = tf.rotationDeg
                        )
                    } else {
                        Triple(
                            boneX + link.localOffsetX,
                            boneY + link.localOffsetY,
                            boneAngleDeg + link.localRotationDeg + tf.rotationDeg
                        )
                    }
                    val safeWx = if (wx.isFinite()) wx else (pivot.x + tf.x)
                    val safeWy = if (wy.isFinite()) wy else (pivot.y + tf.y)
                    val safeWAngle = if (wAngle.isFinite()) wAngle else tf.rotationDeg
                    val safeScaleX = if (tf.scaleX.isFinite() && tf.scaleX >= 0.05f) tf.scaleX else 1f
                    val safeScaleY = if (tf.scaleY.isFinite() && tf.scaleY >= 0.05f) tf.scaleY else 1f
                    return ResolvedPropWorldTransform(
                        worldX = safeWx,
                        worldY = safeWy,
                        worldAngleDeg = safeWAngle,
                        isAttached = true,
                        worldScaleX = safeScaleX,
                        worldScaleY = safeScaleY,
                        hostLayerId = hostLayer.id,
                        hostBoneId = targetBone.bone.id,
                        hostBoneWorldX = boneX,
                        hostBoneWorldY = boneY,
                        hostBoneWorldAngleDeg = boneAngleDeg
                    )
                }
            }
        }
        val safeDetachedX = (pivot.x + tf.x).let { if (it.isFinite()) it else pivot.x }
        val safeDetachedY = (pivot.y + tf.y).let { if (it.isFinite()) it else pivot.y }
        val safeDetachedRot = if (tf.rotationDeg.isFinite()) tf.rotationDeg else 0f
        val safeDetachedSx = if (tf.scaleX.isFinite() && tf.scaleX >= 0.05f) tf.scaleX else 1f
        val safeDetachedSy = if (tf.scaleY.isFinite() && tf.scaleY >= 0.05f) tf.scaleY else 1f
        return ResolvedPropWorldTransform(
            worldX = safeDetachedX,
            worldY = safeDetachedY,
            worldAngleDeg = safeDetachedRot,
            isAttached = false,
            worldScaleX = safeDetachedSx,
            worldScaleY = safeDetachedSy
        )
    }

    /**
     * Module 9: Evaluates Same-Track Character Form Morph (e.g., Human -> Ghost / Witch) + transition FX progress.
     */
    fun evaluateFormMorph(layer: AnimationLayer, frame: Int): EvaluatedFormMorph? {
        if (layer.formMorphKeyframes.isEmpty()) return null
        val active = layer.formMorphKeyframes
            .filter { it.frame <= frame }
            .maxByOrNull { it.frame } ?: return null
        val dur = active.transitionDurationFrames.coerceAtLeast(1)
        val delta = frame - active.frame
        val progress = if (active.transitionFx != "NONE" && delta in 0..dur) {
            delta.toFloat() / dur.toFloat()
        } else {
            -1f
        }
        return EvaluatedFormMorph(form = active, transitionProgress = progress)
    }

    /**
     * Maps semantic body-part Z-order keys ("HEAD", "TORSO", "UPPER_ARM_L", "LOWER_ARM_L",
     * "UPPER_ARM_R", "LOWER_ARM_R", "LEG_L", "LEG_R") onto the matching skeleton bone IDs
     * so both semantic partZOrder maps and direct boneId maps work seamlessly.
     */
    fun expandPartZOrderToBoneIds(partZOrder: Map<String, Int>): Map<String, Int> {
        if (partZOrder.isEmpty()) return emptyMap()
        val out = LinkedHashMap<String, Int>()
        // Pass 1: expand semantic group keys for any bone not explicitly present in partZOrder
        for ((key, zVal) in partZOrder) {
            when (key) {
                "HEAD" -> {
                    if ("neck" !in partZOrder) out["neck"] = zVal
                    if ("head" !in partZOrder) out["head"] = zVal
                }
                "TORSO" -> {
                    if ("spine" !in partZOrder) out["spine"] = zVal
                    if ("waist" !in partZOrder) out["waist"] = zVal
                    if ("pelvis" !in partZOrder) out["pelvis"] = zVal - 1
                    if ("body" !in partZOrder) out["body"] = zVal
                }
                "UPPER_ARM_L" -> {
                    if ("shoulder_l" !in partZOrder) out["shoulder_l"] = zVal
                    if ("arm_l_up" !in partZOrder) out["arm_l_up"] = zVal
                }
                "LOWER_ARM_L" -> {
                    if ("arm_l_low" !in partZOrder) out["arm_l_low"] = zVal
                    if ("hand_l" !in partZOrder) out["hand_l"] = zVal
                }
                "UPPER_ARM_R" -> {
                    if ("shoulder_r" !in partZOrder) out["shoulder_r"] = zVal
                    if ("arm_r_up" !in partZOrder) out["arm_r_up"] = zVal
                }
                "LOWER_ARM_R" -> {
                    if ("arm_r_low" !in partZOrder) out["arm_r_low"] = zVal
                    if ("hand_r" !in partZOrder) out["hand_r"] = zVal
                }
                "LEG_L" -> {
                    if ("hip_l" !in partZOrder) out["hip_l"] = zVal
                    if ("leg_l_up" !in partZOrder) out["leg_l_up"] = zVal
                    if ("leg_l_low" !in partZOrder) out["leg_l_low"] = zVal
                    if ("foot_l" !in partZOrder) out["foot_l"] = zVal
                }
                "LEG_R" -> {
                    if ("hip_r" !in partZOrder) out["hip_r"] = zVal
                    if ("leg_r_up" !in partZOrder) out["leg_r_up"] = zVal
                    if ("leg_r_low" !in partZOrder) out["leg_r_low"] = zVal
                    if ("foot_r" !in partZOrder) out["foot_r"] = zVal
                }
            }
        }
        // Pass 2: copy all explicit entries from partZOrder directly so explicit bone IDs always win
        for ((key, zVal) in partZOrder) {
            out[key] = zVal
        }
        return out
    }

    /**
     * Maps a boneId to its canonical semantic body-part key for `partZOrder` storage.
     */
    fun canonicalPartKeyForBone(boneId: String): String {
        return when (boneId) {
            "neck", "head" -> "HEAD"
            "spine", "waist", "pelvis", "body" -> "TORSO"
            "shoulder_l", "arm_l_up" -> "UPPER_ARM_L"
            "arm_l_low", "hand_l" -> "LOWER_ARM_L"
            "shoulder_r", "arm_r_up" -> "UPPER_ARM_R"
            "arm_r_low", "hand_r" -> "LOWER_ARM_R"
            "hip_l", "leg_l_up", "leg_l_low", "foot_l" -> "LEG_L"
            "hip_r", "leg_r_up", "leg_r_low", "foot_r" -> "LEG_R"
            else -> boneId
        }
    }

    /**
     * Evaluates active per-bone & per-part Z-Order (Front/Back draw order) at [frame].
     * Uses strict step-hold (nearest-previous keyframe) across both `rig.boneZOrderKeyframes`
     * and `PuppetRootKeyframe.partZOrder` so moving an arm/hand above the Head at Frame 12 and
     * back below the Head at Frame 25 switches cleanly on those exact frames without flickering!
     */
    fun evaluateBoneZOrders(rig: SkeletalRig, frame: Int): Map<String, Int> {
        val base = rig.bones.associate { it.id to it.zOrder }.toMutableMap()
        if (rig.partZOrder.isNotEmpty()) {
            base.putAll(expandPartZOrderToBoneIds(rig.partZOrder))
        }

        // 1. Evaluate step-hold from boneZOrderKeyframes
        val sortedBoneZFrames = rig.boneZOrderKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        val activeBoneZFrame = sortedBoneZFrames.lastOrNull { it <= frame }
        val boneZMap = if (activeBoneZFrame != null) {
            expandPartZOrderToBoneIds(rig.boneZOrderKeyframes[activeBoneZFrame.toString()] ?: emptyMap())
        } else {
            emptyMap()
        }

        // 2. Evaluate step-hold from rootKeyframes.partZOrder
        val sortedRootWithZ = rig.rootKeyframes.filter { it.partZOrder.isNotEmpty() }.sortedBy { it.frame }
        val activeRootZ = sortedRootWithZ.lastOrNull { it.frame <= frame }
        val rootZMap = if (activeRootZ != null) {
            expandPartZOrderToBoneIds(activeRootZ.partZOrder)
        } else {
            emptyMap()
        }

        // Merge in chronological priority order so whichever keyframe is more recent wins
        val boneKfFrame = activeBoneZFrame ?: Int.MIN_VALUE
        val rootKfFrame = activeRootZ?.frame ?: Int.MIN_VALUE
        if (boneKfFrame <= rootKfFrame) {
            base.putAll(boneZMap)
            base.putAll(rootZMap)
        } else {
            base.putAll(rootZMap)
            base.putAll(boneZMap)
        }
        return base
    }

    /**
     * Returns true if [rig] has an explicit per-frame Z-order override at [frame] that places any
     * non-head bone/part at or above the Head bone's Z-order.
     */
    fun hasExplicitAboveHeadZOrderAtFrame(rig: SkeletalRig, frame: Int): Boolean {
        val hasAnyOverride = rig.partZOrder.isNotEmpty() ||
            rig.boneZOrderKeyframes.isNotEmpty() ||
            rig.rootKeyframes.any { it.partZOrder.isNotEmpty() }
        if (!hasAnyOverride) return false
        val evalZ = evaluateBoneZOrders(rig, frame)
        val headZ = evalZ["neck"] ?: evalZ["head"] ?: evalZ["HEAD"] ?: 16
        return evalZ.any { (id, z) ->
            id != "neck" && id != "head" && id != "HEAD" && !id.startsWith("ear_") && !id.startsWith("hair_") && z >= headZ
        }
    }

    fun getBoneZOrderKeyframeFrames(rig: SkeletalRig): Set<Int> {
        val fromBoneZ = rig.boneZOrderKeyframes.keys.mapNotNull { it.toIntOrNull() }
        val fromRootZ = rig.rootKeyframes.filter { it.partZOrder.isNotEmpty() }.map { it.frame }
        return (fromBoneZ + fromRootZ).toSet()
    }

    /**
     * Evaluates bone angles for a rigged puppet, smoothly layering automatic walk/flap cycles along [layer.motionPath],
     * Targeted Action Loops (Auto-Walk, Idle Breathing, Horror Twitch), and Auto-Dialogue head-bobbing & arm acting!
     */
    fun evaluateRigAnglesWithPath(
        layer: AnimationLayer,
        rig: SkeletalRig,
        frame: Int,
        totalFrames: Int,
        audioTracks: List<AudioTrackItem> = emptyList(),
        fps: Int = 24
    ): Map<String, Float> {
        var angles = evaluateRigAngles(rig, frame)
        val existingIds = rig.bones.map { it.id }.toSet()

        // Apply posture slouch from CharacterSpec if configured (Module 4)
        val slouch = rig.characterAppearance?.postureSlouch?.coerceIn(0f, 1f) ?: 0f
        if (slouch > 0.02f && "spine" in existingIds) {
            angles = angles + ("spine" to ((angles["spine"] ?: -90f) + slouch * 22f))
            if ("neck" in existingIds) {
                angles = angles + ("neck" to ((angles["neck"] ?: 0f) - slouch * 14f))
            }
        }

        val evalRoot = evaluatePuppetRoot(rig, frame)
        val activeMood = runCatching { CharacterBehaviorPreset.valueOf(evalRoot.behaviorPreset) }
            .getOrDefault(CharacterBehaviorPreset.NORMAL_CALM)

        val lockedIds = rig.bones.filter { RigSolver.isBoneLocked(rig, it) }.map { it.id }.toSet()
        val unlockedExistingIds = existingIds - lockedIds

        // Manual bone keyframes ALWAYS take strict priority over Auto-Walk!
        if (layer.motionPath.size >= 2 && totalFrames > 1 && rig.autoWalkWhenDragged && rig.poseKeyframes.isEmpty()) {
            val progress = evaluateMotionPathProgress(layer, frame, totalFrames)
            val sample = sampleSmoothPath(layer.motionPath, progress)
            if (sample.totalLength >= 4f) {
                angles = when (rig.rigCategory) {
                    "BIRD" -> {
                        val phase = (sample.distanceTraveled / 34f).toDouble()
                        val flap = kotlin.math.sin(phase).toFloat()
                        angles + mapOf(
                            "wing_l_in" to (-90f + flap * 52f),
                            "wing_l_tip" to (-15f + flap * 28f),
                            "wing_r_in" to (-90f - flap * 52f),
                            "wing_r_tip" to (15f - flap * 28f),
                            "tail_base" to (165f + flap * 10f)
                        ).filterKeys { it in unlockedExistingIds }
                    }
                    "QUADRUPED" -> {
                        val phase = (sample.distanceTraveled / 38f).toDouble()
                        val swing = kotlin.math.sin(phase).toFloat()
                        angles + mapOf(
                            "leg_fl_up" to (82f + swing * 28f),
                            "leg_fr_up" to (98f - swing * 28f),
                            "leg_bl_up" to (104f - swing * 28f),
                            "leg_br_up" to (86f + swing * 28f),
                            "tail_base" to (-145f + swing * 16f)
                        ).filterKeys { it in unlockedExistingIds }
                    }
                    else -> {
                        val walkPose = RigSolver.computeAutoWalkPose(sample.distanceTraveled, activeMood.name)
                        angles + walkPose.filterKeys { it in unlockedExistingIds }
                    }
                }
            }
        }

        // Apply Targeted Loop body motion inside selected frame ranges (Module 8)
        layer.targetedLoops.filter { frame in it.startFrame..it.endFrame }.forEach { clip ->
            val localF = frame - clip.startFrame
            when (runCatching { TargetedLoopType.valueOf(clip.loopType) }.getOrNull()) {
                TargetedLoopType.AUTO_WALK -> {
                    val walkPose = RigSolver.computeAutoWalkPose(localF * 16f, activeMood.name)
                    angles = angles + walkPose.filterKeys { it in unlockedExistingIds }
                }
                TargetedLoopType.IDLE_BREATHING -> {
                    val breath = kotlin.math.sin(localF * 0.24).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("spine" in unlockedExistingIds) delta["spine"] = (angles["spine"] ?: -90f) + breath * 2.5f
                    if ("neck" in unlockedExistingIds) delta["neck"] = (angles["neck"] ?: 0f) - breath * 2.2f
                    if ("arm_l_up" in unlockedExistingIds) delta["arm_l_up"] = (angles["arm_l_up"] ?: -138f) - breath * 3.5f
                    if ("arm_r_up" in unlockedExistingIds) delta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) + breath * 3.5f
                    angles = angles + delta
                }
                TargetedLoopType.HORROR_TWITCH -> {
                    val jitter = if (localF % 7 == 0 || localF % 11 == 0) 24f else kotlin.math.sin(localF * 1.4).toFloat() * 7f
                    val delta = mutableMapOf<String, Float>()
                    if ("neck" in unlockedExistingIds) delta["neck"] = (angles["neck"] ?: 0f) + jitter
                    if ("arm_l_low" in unlockedExistingIds) delta["arm_l_low"] = (angles["arm_l_low"] ?: 22f) + jitter * 0.6f
                    if ("arm_r_low" in unlockedExistingIds) delta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - jitter * 0.6f
                    angles = angles + delta
                }
                else -> Unit
            }
        }

        // Apply Preset Character Animations strictly inside [clip.startFrame..clip.endFrame]
        // Outside this range, no preset angle deltas are applied so the character settles cleanly to its base/keyframed pose!
        layer.presetAnimations.filter { frame in it.startFrame..it.endFrame }.forEach { clip ->
            val localF = (frame - clip.startFrame).coerceAtLeast(0)
            val span = (clip.endFrame - clip.startFrame).coerceAtLeast(1)
            val normT = (localF.toFloat() / span.toFloat()).coerceIn(0f, 1f)
            when (clip.actionKind.uppercase()) {
                "WALK", "AUTO_WALK" -> {
                    val walkPose = RigSolver.computeAutoWalkPose(localF * 16f, activeMood.name)
                    angles = angles + walkPose.filterKeys { it in unlockedExistingIds }
                    // Support Animal / Quadruped & Veg walk cycles too
                    if ("leg_front_l" in unlockedExistingIds || "leg_fl_up" in unlockedExistingIds) {
                        val swing = kotlin.math.sin(localF * 0.45).toFloat() * 28f
                        val quadDelta = mutableMapOf<String, Float>()
                        if ("leg_front_l" in unlockedExistingIds) quadDelta["leg_front_l"] = 85f + swing
                        if ("leg_front_r" in unlockedExistingIds) quadDelta["leg_front_r"] = 95f - swing
                        if ("leg_back_l" in unlockedExistingIds) quadDelta["leg_back_l"] = 100f - swing
                        if ("leg_back_r" in unlockedExistingIds) quadDelta["leg_back_r"] = 80f + swing
                        if ("tail" in unlockedExistingIds) quadDelta["tail"] = -145f + swing * 0.6f
                        angles = angles + quadDelta
                    } else if ("body" in unlockedExistingIds && "spine" !in unlockedExistingIds) {
                        val sway = kotlin.math.sin(localF * 0.45).toFloat() * 12f
                        angles = angles + ("body" to (-90f + sway))
                    }
                }
                "RUN" -> {
                    val runPose = RigSolver.computeAutoWalkPose(localF * 28f, activeMood.name)
                    val delta = runPose.filterKeys { it in unlockedExistingIds }.toMutableMap()
                    if ("spine" in unlockedExistingIds) delta["spine"] = -74f
                    angles = angles + delta
                }
                "JUMP" -> {
                    val arc = kotlin.math.sin(normT * Math.PI).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("arm_l_up" in unlockedExistingIds) delta["arm_l_up"] = -138f - arc * 55f
                    if ("arm_r_up" in unlockedExistingIds) delta["arm_r_up"] = 138f + arc * 55f
                    if ("leg_l_up" in unlockedExistingIds) delta["leg_l_up"] = 96f + arc * 26f
                    if ("leg_r_up" in unlockedExistingIds) delta["leg_r_up"] = 84f - arc * 26f
                    if ("leg_l_low" in unlockedExistingIds) delta["leg_l_low"] = 4f + arc * 32f
                    if ("leg_r_low" in unlockedExistingIds) delta["leg_r_low"] = -4f - arc * 32f
                    angles = angles + delta
                }
                "WAVE" -> {
                    val wave = kotlin.math.sin(localF * 0.65).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("arm_r_up" in unlockedExistingIds) delta["arm_r_up"] = -45f + wave * 14f
                    if ("arm_r_low" in unlockedExistingIds) delta["arm_r_low"] = -55f + wave * 34f
                    if ("neck" in unlockedExistingIds) delta["neck"] = wave * 6f
                    angles = angles + delta
                }
                "TALK", "TALKING" -> {
                    val bob = kotlin.math.sin(localF * 0.55).toFloat()
                    val gesture = kotlin.math.sin(localF * 0.30).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("neck" in unlockedExistingIds) delta["neck"] = (angles["neck"] ?: 0f) + bob * 7f
                    if ("head" in unlockedExistingIds) delta["head"] = (angles["head"] ?: 0f) + bob * 7f
                    if ("arm_r_low" in unlockedExistingIds) delta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 20f + gesture * 16f
                    angles = angles + delta
                }
                "IDLE", "IDLE_BREATHING" -> {
                    val breath = kotlin.math.sin(localF * 0.24).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("spine" in unlockedExistingIds) delta["spine"] = (angles["spine"] ?: -90f) + breath * 2.5f
                    if ("body" in unlockedExistingIds) delta["body"] = (angles["body"] ?: -90f) + breath * 2.5f
                    if ("neck" in unlockedExistingIds) delta["neck"] = (angles["neck"] ?: 0f) - breath * 2.2f
                    if ("arm_l_up" in unlockedExistingIds) delta["arm_l_up"] = (angles["arm_l_up"] ?: -138f) - breath * 3.5f
                    if ("arm_r_up" in unlockedExistingIds) delta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) + breath * 3.5f
                    angles = angles + delta
                }
                "ANIME_PUNCH", "PUNCH" -> {
                    val thrust = kotlin.math.sin(normT * Math.PI).toFloat()
                    val delta = mutableMapOf<String, Float>()
                    if ("spine" in unlockedExistingIds) delta["spine"] = -90f + thrust * 18f
                    if ("arm_r_up" in unlockedExistingIds) delta["arm_r_up"] = 138f - thrust * 135f
                    if ("arm_r_low" in unlockedExistingIds) delta["arm_r_low"] = -22f + thrust * 22f
                    if ("arm_l_up" in unlockedExistingIds) delta["arm_l_up"] = -138f - thrust * 25f
                    angles = angles + delta
                }
                "SLIP_FALL", "FALL" -> {
                    val fallT = applyEasing(normT, EasingType.EASE_OUT.name)
                    val delta = mutableMapOf<String, Float>()
                    if ("spine" in unlockedExistingIds) delta["spine"] = -90f - fallT * 82f
                    if ("body" in unlockedExistingIds) delta["body"] = -90f - fallT * 82f
                    if ("arm_l_up" in unlockedExistingIds) delta["arm_l_up"] = -138f - fallT * 45f
                    if ("arm_r_up" in unlockedExistingIds) delta["arm_r_up"] = 138f + fallT * 45f
                    if ("leg_l_up" in unlockedExistingIds) delta["leg_l_up"] = 96f - fallT * 50f
                    if ("leg_r_up" in unlockedExistingIds) delta["leg_r_up"] = 84f - fallT * 40f
                    angles = angles + delta
                }
            }
        }

        // Whole-Character Acting Behavior Preset continuous idle/mood body language!
        val moodDelta = mutableMapOf<String, Float>()
        when (activeMood) {
            CharacterBehaviorPreset.NORMAL_CALM -> Unit
            CharacterBehaviorPreset.ANGRY_STRICT -> {
                val jab = kotlin.math.sin(frame * 0.45).toFloat()
                if ("spine" in unlockedExistingIds) moodDelta["spine"] = (angles["spine"] ?: -90f) + 6f
                if ("neck" in unlockedExistingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) - 5f + jab * 3f
                if ("arm_r_up" in unlockedExistingIds) moodDelta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) - 18f + jab * 8f
                if ("arm_r_low" in unlockedExistingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 24f + jab * 14f
            }
            CharacterBehaviorPreset.HORROR_GHOSTLY -> {
                val twitch = if (frame % 9 == 0 || frame % 13 == 0) 18f else kotlin.math.sin(frame * 0.7).toFloat() * 5f
                val floatSway = kotlin.math.sin(frame * 0.18).toFloat()
                if ("neck" in unlockedExistingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) + 10f + twitch
                if ("arm_l_up" in unlockedExistingIds) moodDelta["arm_l_up"] = (angles["arm_l_up"] ?: -138f) + 18f + floatSway * 10f
                if ("arm_r_up" in unlockedExistingIds) moodDelta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) - 18f - floatSway * 10f
                if ("arm_l_low" in unlockedExistingIds) moodDelta["arm_l_low"] = (angles["arm_l_low"] ?: 22f) + twitch * 0.45f
                if ("arm_r_low" in unlockedExistingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - twitch * 0.45f
            }
            CharacterBehaviorPreset.HAPPY_PLAYFUL -> {
                val wave = kotlin.math.sin(frame * 0.42).toFloat()
                if ("neck" in unlockedExistingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) + wave * 7f
                if ("arm_r_up" in unlockedExistingIds) moodDelta["arm_r_up"] = (angles["arm_r_up"] ?: 138f) - 42f + wave * 12f
                if ("arm_r_low" in unlockedExistingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 38f + wave * 24f
            }
            CharacterBehaviorPreset.ELDERLY_WEAK -> {
                val tremor = kotlin.math.sin(frame * 2.1).toFloat() * 2.6f
                if ("spine" in unlockedExistingIds) moodDelta["spine"] = (angles["spine"] ?: -90f) + 16f
                if ("neck" in unlockedExistingIds) moodDelta["neck"] = (angles["neck"] ?: 0f) - 11f + tremor
                if ("arm_l_low" in unlockedExistingIds) moodDelta["arm_l_low"] = (angles["arm_l_low"] ?: 22f) + 14f + tremor
                if ("arm_r_low" in unlockedExistingIds) moodDelta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 14f - tremor
            }
        }
        if (moodDelta.isNotEmpty()) angles = angles + moodDelta

        // Upgrade 5: Automatic Head Bob / Nodding Toggle & Sway Intensity Slider
        // When headBobEnabled == false or headBobIntensity <= 0f, apply ZERO automatic head tilt/bobbing!
        val headBobOn = evalRoot.headBobEnabled && rig.headBobEnabled && evalRoot.headBobIntensity > 0.001f
        val speakingNow = (audioTracks.isNotEmpty() && evaluateLipSyncPhoneme(audioTracks, frame, fps) != MouthPhoneme.REST) ||
            evalRoot.mouthPhoneme == MouthPhoneme.TALKING_LOOP.name ||
            rig.mouthPhoneme == MouthPhoneme.TALKING_LOOP.name ||
            layer.targetedLoops.any { frame in it.startFrame..it.endFrame && it.loopType == TargetedLoopType.TALKING_LOOP.name } ||
            layer.presetAnimations.any { frame in it.startFrame..it.endFrame && (it.actionKind.equals("TALK", true) || it.actionKind.equals("TALKING", true)) }

        if (headBobOn) {
            val shouldBobThisFrame = evalRoot.headBobMode.equals("ALWAYS", ignoreCase = true) || speakingNow
            if (shouldBobThisFrame) {
                val intensity = evalRoot.headBobIntensity.coerceIn(0f, 1f)
                // Max ~18° gentle head nodding scaled directly by headBobIntensity (0%..100%)
                val headTiltDelta = kotlin.math.sin(frame * 0.52).toFloat() * (18f * intensity)
                val delta = mutableMapOf<String, Float>()
                if ("neck" in unlockedExistingIds) delta["neck"] = (angles["neck"] ?: 0f) + headTiltDelta
                if ("head" in unlockedExistingIds) delta["head"] = (angles["head"] ?: 0f) + headTiltDelta
                angles = angles + delta
            }
        }

        // Conversational arm cadence when autoDialogueActing is enabled and voice speaks
        if (rig.autoDialogueActing && speakingNow) {
            val gestureWave = kotlin.math.sin(frame * 0.28).toFloat()
            val delta = mutableMapOf<String, Float>()
            if ("arm_r_low" in unlockedExistingIds) delta["arm_r_low"] = (angles["arm_r_low"] ?: -22f) - 18f + gestureWave * 14f
            if (headBobOn && "neck" !in unlockedExistingIds && "head" !in unlockedExistingIds) {
                // No head bone present
            }
            angles = angles + delta
        }
        return angles
    }

    fun evaluateCamera(scene: AnimationScene, frame: Int, projectWidth: Float = 1280f, projectHeight: Float = 720f): EvaluatedCamera {
        val sorted = scene.cameraKeyframes.sortedBy { it.frame }
        val baseCam = if (sorted.isEmpty()) {
            EvaluatedCamera()
        } else {
            when {
                frame <= sorted.first().frame -> sorted.first().toEvaluated()
                frame >= sorted.last().frame -> sorted.last().toEvaluated()
                else -> {
                    val nextIdx = sorted.indexOfFirst { it.frame >= frame }
                    val prev = sorted[(nextIdx - 1).coerceAtLeast(0)]
                    val next = sorted[nextIdx]
                    if (prev.frame == next.frame) {
                        next.toEvaluated()
                    } else {
                        val rawT = (frame - prev.frame).toFloat() / (next.frame - prev.frame).toFloat()
                        val eased = applyEasing(rawT, prev.easing)
                        EvaluatedCamera(
                            panX = lerp(prev.panX, next.panX, eased),
                            panY = lerp(prev.panY, next.panY, eased),
                            zoom = lerp(prev.zoom, next.zoom, eased).coerceIn(0.25f, 4f),
                            rotationDeg = lerp(prev.rotationDeg, next.rotationDeg, eased),
                            shakeIntensity = lerp(prev.shakeIntensity, next.shakeIntensity, eased).coerceIn(0f, 1f),
                            impactFlashAlpha = lerp(prev.impactFlashAlpha, next.impactFlashAlpha, eased).coerceIn(0f, 1f),
                            impactFlashColorArgb = prev.impactFlashColorArgb,
                            motionBlurAmount = lerp(prev.motionBlurAmount, next.motionBlurAmount, eased).coerceIn(0f, 1f)
                        )
                    }
                }
            }
        }

        // Module 9: Camera Follow Character tracks the target layer/puppet smoothly!
        val followId = scene.cameraFollowLayerId
        var resolvedCam = baseCam
        if (!followId.isNullOrBlank()) {
            val targetLayer = scene.layers.firstOrNull { it.id == followId }
            if (targetLayer != null) {
                val targetPos = if (targetLayer.rig != null) {
                    val pRoot = evaluatePuppetRootWithPath(targetLayer, targetLayer.rig, frame, scene.durationFrames)
                    Vec2(pRoot.rootX, pRoot.rootY - 40f * pRoot.scale)
                } else {
                    val tf = evaluateLayerTransform(targetLayer, frame, scene.durationFrames)
                    val center = computeLayerVisualCenter(targetLayer, frame) ?: Vec2(projectWidth / 2f, projectHeight / 2f)
                    Vec2(center.x + tf.x, center.y + tf.y)
                }
                resolvedCam = resolvedCam.copy(
                    panX = resolvedCam.panX + (targetPos.x - projectWidth / 2f) * 0.85f,
                    panY = resolvedCam.panY + (targetPos.y - projectHeight / 2f) * 0.65f
                )
            }
        }

        // Strict Frame-Clamped Screen Shake & Red Flash from scene.screenEffectClips
        val activeEffectClips = scene.screenEffectClips.filter { frame in it.startFrame..it.endFrame }
        for (clip in activeEffectClips) {
            when (clip.effectType) {
                com.example.data.model.SceneVfxType.SCREEN_SHAKE.name -> {
                    val clipShake = clip.intensity.coerceIn(0.1f, 2f) * 0.65f
                    resolvedCam = resolvedCam.copy(
                        shakeIntensity = max(resolvedCam.shakeIntensity, clipShake).coerceIn(0f, 1f)
                    )
                }
                com.example.data.model.SceneVfxType.RED_FLASH.name -> {
                    val pulse = 0.45f + 0.35f * kotlin.math.abs(kotlin.math.sin((frame - clip.startFrame) * 0.9f))
                    resolvedCam = resolvedCam.copy(
                        impactFlashAlpha = max(resolvedCam.impactFlashAlpha, (pulse * clip.intensity).coerceIn(0f, 0.85f)),
                        impactFlashColorArgb = 0xFFEF4444L
                    )
                }
            }
        }
        return resolvedCam
    }

    fun evaluateRigAngles(rig: SkeletalRig, frame: Int): Map<String, Float> {
        val defaultAngles = rig.bones.associate { it.id to it.localAngleDeg }
        if (rig.poseKeyframes.isEmpty()) return defaultAngles

        val sortedFrames = rig.poseKeyframes.keys.mapNotNull { it.toIntOrNull() }.sorted()
        if (sortedFrames.isEmpty()) return defaultAngles

        val exact = rig.poseKeyframes[frame.toString()]
        if (exact != null) return defaultAngles + exact

        return when {
            frame < sortedFrames.first() -> defaultAngles + (rig.poseKeyframes[sortedFrames.first().toString()] ?: emptyMap())
            frame > sortedFrames.last() -> defaultAngles + (rig.poseKeyframes[sortedFrames.last().toString()] ?: emptyMap())
            else -> {
                val nextIdx = sortedFrames.indexOfFirst { it >= frame }
                val prevF = sortedFrames[(nextIdx - 1).coerceAtLeast(0)]
                val nextF = sortedFrames[nextIdx]
                val prevMap = rig.poseKeyframes[prevF.toString()] ?: emptyMap()
                val nextMap = rig.poseKeyframes[nextF.toString()] ?: emptyMap()
                val t = applyEasing((frame - prevF).toFloat() / (nextF - prevF).coerceAtLeast(1).toFloat(), EasingType.EASE_IN_OUT.name)
                rig.bones.associate { bone ->
                    val a = prevMap[bone.id] ?: bone.localAngleDeg
                    val b = nextMap[bone.id] ?: bone.localAngleDeg
                    bone.id to lerpAngle(a, b, t)
                }
            }
        }
    }

    /**
     * Evaluates voiceover audio waveform energy at [frame] to drive Auto Lip-Sync talking mouths,
     * honoring custom Frame or Second Lip-Sync Change Intervals.
     */
    fun evaluateLipSyncPhoneme(
        audioTracks: List<AudioTrackItem>,
        frame: Int,
        fps: Int,
        timing: com.example.data.model.FacialTimingConfig = com.example.data.model.FacialTimingConfig()
    ): MouthPhoneme {
        return AudioStudioEngine.evaluateLipSyncPhonemeWithTiming(
            audioTracks = audioTracks,
            frame = frame,
            fps = fps,
            timing = timing
        )
    }

    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        // Preserve continuous multi-turn unwrapped spins (e.g. 0° -> 360°) instead of snapping backward!
        if (abs(b - a) > 185f) {
            return a + (b - a) * t
        }
        var diff = (b - a) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return a + diff * t
    }

    /**
     * Module 10: Pure-Kotlin HSL Hue/Saturation Shift + optional RGB Tint blending for Universal Multi-Frame Batch Recoloring.
     */
    fun shiftColorArgb(
        argb: Long,
        hueDeltaDeg: Float,
        satScale: Float = 1f,
        tintColorArgb: Long? = null,
        tintAmount: Float = 0f
    ): Long {
        val alpha = (argb ushr 24) and 0xFFL
        var r = ((argb ushr 16) and 0xFFL).toFloat() / 255f
        var g = ((argb ushr 8) and 0xFFL).toFloat() / 255f
        var b = (argb and 0xFFL).toFloat() / 255f

        if (abs(hueDeltaDeg) > 0.01f || abs(satScale - 1f) > 0.01f) {
            val cMax = max(r, max(g, b))
            val cMin = min(r, min(g, b))
            val delta = cMax - cMin
            val l = (cMax + cMin) * 0.5f
            var s = if (delta < 1e-5f) 0f else delta / (1f - abs(2f * l - 1f))
            var h = when {
                delta < 1e-5f -> 0f
                cMax == r -> 60f * (((g - b) / delta) % 6f)
                cMax == g -> 60f * (((b - r) / delta) + 2f)
                else -> 60f * (((r - g) / delta) + 4f)
            }
            if (h < 0f) h += 360f
            h = ((h + hueDeltaDeg) % 360f + 360f) % 360f
            s = (s * satScale).coerceIn(0f, 1f)

            val c = (1f - abs(2f * l - 1f)) * s
            val x = c * (1f - abs((h / 60f) % 2f - 1f))
            val m = l - c * 0.5f
            val (rp, gp, bp) = when {
                h < 60f -> Triple(c, x, 0f)
                h < 120f -> Triple(x, c, 0f)
                h < 180f -> Triple(0f, c, x)
                h < 240f -> Triple(0f, x, c)
                h < 300f -> Triple(x, 0f, c)
                else -> Triple(c, 0f, x)
            }
            r = (rp + m).coerceIn(0f, 1f)
            g = (gp + m).coerceIn(0f, 1f)
            b = (bp + m).coerceIn(0f, 1f)
        }

        if (tintColorArgb != null && tintAmount > 0.001f) {
            val t = tintAmount.coerceIn(0f, 1f)
            val tr = ((tintColorArgb ushr 16) and 0xFFL).toFloat() / 255f
            val tg = ((tintColorArgb ushr 8) and 0xFFL).toFloat() / 255f
            val tb = (tintColorArgb and 0xFFL).toFloat() / 255f
            r = lerp(r, tr, t)
            g = lerp(g, tg, t)
            b = lerp(b, tb, t)
        }

        val ri = (r * 255f).toInt().coerceIn(0, 255).toLong()
        val gi = (g * 255f).toInt().coerceIn(0, 255).toLong()
        val bi = (b * 255f).toInt().coerceIn(0, 255).toLong()
        return (alpha shl 24) or (ri shl 16) or (gi shl 8) or bi
    }

    /**
     * Module 10: Applies batch hue/saturation/tint color shift across every stroke, vector shape,
     * and text item in a FrameContent (works identically in Cel Studio & Main Stage Timeline!).
     */
    fun applyBatchColorShiftToFrameContent(
        content: FrameContent,
        hueDeltaDeg: Float,
        satScale: Float = 1f,
        tintColorArgb: Long? = null,
        tintAmount: Float = 0f
    ): FrameContent {
        return content.copy(
            strokes = content.strokes.map { st ->
                st.copy(
                    colorArgb = shiftColorArgb(st.colorArgb, hueDeltaDeg, satScale, tintColorArgb, tintAmount),
                    gradientEndArgb = st.gradientEndArgb?.let { shiftColorArgb(it, hueDeltaDeg, satScale, tintColorArgb, tintAmount) }
                )
            },
            shapes = content.shapes.map { sh ->
                sh.copy(
                    strokeColorArgb = shiftColorArgb(sh.strokeColorArgb, hueDeltaDeg, satScale, tintColorArgb, tintAmount),
                    fillColorArgb = sh.fillColorArgb?.let { shiftColorArgb(it, hueDeltaDeg, satScale, tintColorArgb, tintAmount) },
                    gradientEndArgb = sh.gradientEndArgb?.let { shiftColorArgb(it, hueDeltaDeg, satScale, tintColorArgb, tintAmount) }
                )
            },
            texts = content.texts.map { tx ->
                tx.copy(
                    colorArgb = shiftColorArgb(tx.colorArgb, hueDeltaDeg, satScale, tintColorArgb, tintAmount),
                    gradientEndArgb = tx.gradientEndArgb?.let { shiftColorArgb(it, hueDeltaDeg, satScale, tintColorArgb, tintAmount) }
                )
            }
        )
    }

    fun resolveFrameContent(layer: AnimationLayer, frame: Int, holdPrevious: Boolean = true): FrameContent? {
        layer.frames[frame.toString()]?.let { return it }
        // Module 7: Frame-by-Frame Cel Studio layers automatically hide previous frame's solid drawing!
        if (!holdPrevious || layer.isCelFrameByFrame) return null
        val prevKey = layer.frames.keys
            .mapNotNull { it.toIntOrNull() }
            .filter { it < frame }
            .maxOrNull() ?: return null
        return layer.frames[prevKey.toString()]
    }

    /**
     * Generates dense Catmull-Rom spline points from user control waypoints for butter-smooth motion curves.
     */
    fun buildSmoothSplinePoints(points: List<Vec2>, subdivisionsPerSegment: Int = 12): List<Vec2> {
        if (points.size <= 2) return points
        val out = ArrayList<Vec2>((points.size - 1) * subdivisionsPerSegment + 1)
        val n = points.size
        for (i in 0 until n - 1) {
            val p0 = points[(i - 1).coerceAtLeast(0)]
            val p1 = points[i]
            val p2 = points[i + 1]
            val p3 = points[(i + 2).coerceAtMost(n - 1)]
            val steps = subdivisionsPerSegment.coerceAtLeast(2)
            for (s in 0 until steps) {
                val u = s.toFloat() / steps.toFloat()
                out.add(evalCatmullRom(p0, p1, p2, p3, u))
            }
        }
        out.add(points.last())
        return out
    }

    private fun evalCatmullRom(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2, t: Float): Vec2 {
        val t2 = t * t
        val t3 = t2 * t
        val x = 0.5f * (
            (2f * p1.x) +
                (-p0.x + p2.x) * t +
                (2f * p0.x - 5f * p1.x + 4f * p2.x - p3.x) * t2 +
                (-p0.x + 3f * p1.x - 3f * p2.x + p3.x) * t3
            )
        val y = 0.5f * (
            (2f * p1.y) +
                (-p0.y + p2.y) * t +
                (2f * p0.y - 5f * p1.y + 4f * p2.y - p3.y) * t2 +
                (-p0.y + 3f * p1.y - 3f * p2.y + p3.y) * t3
            )
        return Vec2(x, y)
    }

    /**
     * Arc-length parameterized Catmull-Rom smooth spline sampler.
     * Guarantees constant, jitter-free velocity along curves + smooth tangent angle & arc distance.
     */
    fun sampleSmoothPath(points: List<Vec2>, t: Float): PathSample {
        if (points.isEmpty()) return PathSample(Vec2(0f, 0f), 0f, 0f, 0f, 1f, 0f)
        if (points.size == 1) return PathSample(points.first(), 0f, 0f, 0f, 1f, 0f)
        val dense = buildSmoothSplinePoints(points, subdivisionsPerSegment = 14)
        val lengths = FloatArray(dense.size - 1)
        var total = 0f
        for (i in 0 until dense.size - 1) {
            val d = hypot(dense[i + 1].x - dense[i].x, dense[i + 1].y - dense[i].y)
            lengths[i] = d
            total += d
        }
        if (total <= 0.001f) return PathSample(dense.first(), 0f, 0f, 0f, 1f, 0f)
        val clampedT = t.coerceIn(0f, 1f)
        val target = total * clampedT
        var acc = 0f
        for (i in lengths.indices) {
            if (acc + lengths[i] >= target || i == lengths.lastIndex) {
                val segLen = lengths[i]
                val segT = if (segLen > 0.0001f) ((target - acc) / segLen).coerceIn(0f, 1f) else 0f
                val pos = Vec2(
                    lerp(dense[i].x, dense[i + 1].x, segT),
                    lerp(dense[i].y, dense[i + 1].y, segT)
                )
                val dx = dense[i + 1].x - dense[i].x
                val dy = dense[i + 1].y - dense[i].y
                val tangent = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                return PathSample(
                    position = pos,
                    tangentAngleDeg = tangent,
                    distanceTraveled = target,
                    totalLength = total,
                    dx = dx,
                    dy = dy
                )
            }
            acc += lengths[i]
        }
        val lastDx = dense.last().x - dense[dense.lastIndex - 1].x
        val lastDy = dense.last().y - dense[dense.lastIndex - 1].y
        return PathSample(
            position = dense.last(),
            tangentAngleDeg = Math.toDegrees(kotlin.math.atan2(lastDy.toDouble(), lastDx.toDouble())).toFloat(),
            distanceTraveled = total,
            totalLength = total,
            dx = lastDx,
            dy = lastDy
        )
    }

    fun samplePolyline(points: List<Vec2>, t: Float): Vec2 {
        return sampleSmoothPath(points, t).position
    }

    /**
     * Computes horizontal background auto-scroll shift matching SceneRenderer.drawLayerAtFrame.
     */
    fun computeBgScrollShiftX(
        layer: AnimationLayer,
        scene: AnimationScene,
        frame: Int,
        projectWidth: Float
    ): Float {
        if (layer.type != LayerType.BACKGROUND.name || scene.backgroundScrollSpeed == 0f || projectWidth <= 0f) {
            return 0f
        }
        val raw = -(frame * scene.backgroundScrollSpeed * 2.5f * layer.parallaxDepth)
        return ((raw % projectWidth) + projectWidth) % projectWidth - projectWidth * 0.5f
    }

    /**
     * Exact forward transform from Layer local coordinates to Compose Canvas pixel coordinates.
     * Matches CanvasStage viewport + SceneRenderer.applyCameraTransform + drawLayerAtFrame 1:1.
     */
    fun layerLocalToCanvasPx(
        localPt: Vec2,
        projectWidth: Float,
        projectHeight: Float,
        originX: Float,
        originY: Float,
        totalScale: Float,
        camera: EvaluatedCamera,
        parallax: Float,
        layerTransform: EvaluatedTransform,
        bgAutoShiftX: Float = 0f
    ): Vec2 {
        val halfW = projectWidth / 2f
        val halfH = projectHeight / 2f

        // 1. Layer transform around stage center
        val lx1 = (localPt.x - halfW) * layerTransform.scaleX
        val ly1 = (localPt.y - halfH) * layerTransform.scaleY
        val radL = Math.toRadians(layerTransform.rotationDeg.toDouble())
        val cosL = kotlin.math.cos(radL)
        val sinL = kotlin.math.sin(radL)
        val lx2 = (lx1 * cosL - ly1 * sinL).toFloat()
        val ly2 = (lx1 * sinL + ly1 * cosL).toFloat()
        val worldX = lx2 + halfW + layerTransform.x + bgAutoShiftX
        val worldY = ly2 + halfH + layerTransform.y

        // 2. Camera transform with layer parallax
        val effZoom = (1f + (camera.zoom - 1f) * parallax).coerceAtLeast(0.05f)
        val cx1 = (worldX - halfW - camera.panX * parallax) * effZoom
        val cy1 = (worldY - halfH - camera.panY * parallax) * effZoom
        val radC = Math.toRadians(camera.rotationDeg.toDouble())
        val cosC = kotlin.math.cos(radC)
        val sinC = kotlin.math.sin(radC)
        val stageX = (cx1 * cosC - cy1 * sinC).toFloat() + halfW
        val stageY = (cx1 * sinC + cy1 * cosC).toFloat() + halfH

        // 3. Stage viewport transform to raw Canvas pixels
        return Vec2(
            x = stageX * totalScale + originX,
            y = stageY * totalScale + originY
        )
    }

    /**
     * Exact inverse transform from Compose Canvas pixel coordinates to Stage World coordinates (accounting for parallax).
     */
    fun canvasPxToStageWorld(
        canvasPxX: Float,
        canvasPxY: Float,
        projectWidth: Float,
        projectHeight: Float,
        originX: Float,
        originY: Float,
        totalScale: Float,
        camera: EvaluatedCamera,
        parallax: Float = 1f
    ): Vec2 {
        val safeScale = totalScale.coerceAtLeast(0.0001f)
        val stageX = (canvasPxX - originX) / safeScale
        val stageY = (canvasPxY - originY) / safeScale
        val halfW = projectWidth / 2f
        val halfH = projectHeight / 2f

        val dx = stageX - halfW
        val dy = stageY - halfH
        val radCInv = Math.toRadians((-camera.rotationDeg).toDouble())
        val cosC = kotlin.math.cos(radCInv)
        val sinC = kotlin.math.sin(radCInv)
        val effZoom = (1f + (camera.zoom - 1f) * parallax).coerceAtLeast(0.05f)
        val rx = (dx * cosC - dy * sinC).toFloat() / effZoom
        val ry = (dx * sinC + dy * cosC).toFloat() / effZoom
        return Vec2(
            x = rx + halfW + camera.panX * parallax,
            y = ry + halfH + camera.panY * parallax
        )
    }

    /**
     * Exact mathematical inverse of [layerLocalToCanvasPx].
     * Guarantees finger touches land at the exact drawn pixel even when zoomed, panned, rotated, or on parallax/transformed layers.
     */
    fun canvasPxToLayerLocal(
        canvasPxX: Float,
        canvasPxY: Float,
        projectWidth: Float,
        projectHeight: Float,
        originX: Float,
        originY: Float,
        totalScale: Float,
        camera: EvaluatedCamera,
        parallax: Float,
        layerTransform: EvaluatedTransform,
        bgAutoShiftX: Float = 0f
    ): Vec2 {
        val world = canvasPxToStageWorld(
            canvasPxX = canvasPxX,
            canvasPxY = canvasPxY,
            projectWidth = projectWidth,
            projectHeight = projectHeight,
            originX = originX,
            originY = originY,
            totalScale = totalScale,
            camera = camera,
            parallax = parallax
        )
        val halfW = projectWidth / 2f
        val halfH = projectHeight / 2f

        val tx = world.x - (halfW + layerTransform.x + bgAutoShiftX)
        val ty = world.y - (halfH + layerTransform.y)
        val radLInv = Math.toRadians((-layerTransform.rotationDeg).toDouble())
        val cosL = kotlin.math.cos(radLInv)
        val sinL = kotlin.math.sin(radLInv)
        val rx = (tx * cosL - ty * sinL).toFloat()
        val ry = (tx * sinL + ty * cosL).toFloat()

        val sx = if (kotlin.math.abs(layerTransform.scaleX) < 0.001f) {
            if (layerTransform.scaleX < 0f) -0.001f else 0.001f
        } else layerTransform.scaleX
        val sy = if (kotlin.math.abs(layerTransform.scaleY) < 0.001f) {
            if (layerTransform.scaleY < 0f) -0.001f else 0.001f
        } else layerTransform.scaleY

        return Vec2(
            x = rx / sx + halfW,
            y = ry / sy + halfH
        )
    }

    private fun TransformKeyframe.toEvaluated() = EvaluatedTransform(
        x = x, y = y, rotationDeg = rotationDeg, scaleX = scaleX, scaleY = scaleY, opacity = opacity
    )

    private fun CameraKeyframe.toEvaluated() = EvaluatedCamera(
        panX = panX,
        panY = panY,
        zoom = zoom,
        rotationDeg = rotationDeg,
        shakeIntensity = shakeIntensity,
        impactFlashAlpha = impactFlashAlpha,
        impactFlashColorArgb = impactFlashColorArgb,
        motionBlurAmount = motionBlurAmount
    )

    private fun PuppetRootKeyframe.toEvaluated() = EvaluatedPuppetRoot(
        rootX = rootX,
        rootY = rootY,
        scale = scale,
        flippedHorizontal = flippedHorizontal,
        eyePack = eyePack,
        mouthPhoneme = mouthPhoneme,
        viewAngle = viewAngle,
        scaleX = scaleX,
        scaleY = scaleY,
        eyebrowStyle = eyebrowStyle,
        leftHandGesture = leftHandGesture,
        rightHandGesture = rightHandGesture,
        behaviorPreset = behaviorPreset,
        headTurn25D = headTurn25D,
        leftEyebrowStyle = leftEyebrowStyle,
        rightEyebrowStyle = rightEyebrowStyle,
        leftPupilX = leftPupilX,
        leftPupilY = leftPupilY,
        rightPupilX = rightPupilX,
        rightPupilY = rightPupilY,
        activeEyeMood = activeEyeMood,
        activeMouthMood = activeMouthMood,
        leftBrowY = leftBrowY,
        rightBrowY = rightBrowY,
        leftBrowTilt = leftBrowTilt,
        rightBrowTilt = rightBrowTilt,
        browArch = browArch,
        browSpacing = browSpacing,
        browScale = browScale,
        eyeSpacing = eyeSpacing,
        eyeScale = eyeScale,
        headBobEnabled = headBobEnabled,
        headBobMode = headBobMode,
        headBobIntensity = headBobIntensity,
        partZOrder = partZOrder
    )
}
