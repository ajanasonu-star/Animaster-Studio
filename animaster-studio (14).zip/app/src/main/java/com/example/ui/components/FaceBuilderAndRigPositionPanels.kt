package com.example.ui.components

import android.graphics.BitmapFactory
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CharacterViewAngle
import com.example.data.model.DrawStroke
import com.example.data.model.FaceFeatureTransform
import com.example.data.model.NoseStylePreset
import com.example.data.model.SkeletalRig
import com.example.data.model.Vec2
import com.example.engine.EvaluatedPuppetRoot
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioMint
import com.example.ui.theme.StudioRose
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioViewModel
import java.io.File
import kotlin.math.roundToInt

/**
 * Master Upgrade Module 1 & 2:
 * Rig Joint Position & Pivot Editor (1px Micro-Nudge, X/Y Numeric Inputs, Lock Base Rig Position,
 * Shoulder L/R Bones, Unrestricted 360° Joints, and Exact Per-View Anatomical Z-Order Layering).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RigPositionAndAnatomicalLayerCard(
    rig: SkeletalRig,
    selectedBoneId: String?,
    isRigPositionMode: Boolean,
    onToggleRigPositionMode: () -> Unit,
    viewModel: StudioViewModel
) {
    val activeBone = rig.bones.firstOrNull { it.id == selectedBoneId } ?: rig.bones.firstOrNull()
    var stepPx by remember { mutableStateOf(1f) }
    var xText by remember(activeBone?.id, activeBone?.basePivotOffsetX) {
        mutableStateOf((activeBone?.basePivotOffsetX ?: 0f).roundToInt().toString())
    }
    var yText by remember(activeBone?.id, activeBone?.basePivotOffsetY) {
        mutableStateOf((activeBone?.basePivotOffsetY ?: 0f).roundToInt().toString())
    }

    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isRigPositionMode) StudioMint else StudioCyan.copy(alpha = 0.55f),
                RoundedCornerShape(12.dp)
            )
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "RIG JOINT POSITION & 360° PIVOT SETUP",
                        color = StudioMint,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Drag joints on stage onto exact anatomical spots • 0°–360° unrestricted rotation",
                        color = StudioTextSecondary,
                        fontSize = 10.sp
                    )
                }
                Button(
                    onClick = onToggleRigPositionMode,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isRigPositionMode) StudioMint else PanelSurface
                    ),
                    shape = RoundedCornerShape(9.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp).testTag("toggle_rig_position_mode_btn")
                ) {
                    Icon(
                        Icons.Default.OpenWith,
                        contentDescription = null,
                        tint = if (isRigPositionMode) Color(0xFF080B12) else StudioMint,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (isRigPositionMode) "Rig Pos ON" else "Rig Position",
                        color = if (isRigPositionMode) Color(0xFF080B12) else StudioMint,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Lock Base Rig Position Control
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (rig.baseRigPositionLocked) StudioAmber.copy(alpha = 0.16f) else PanelSurface)
                    .border(
                        1.dp,
                        if (rig.baseRigPositionLocked) StudioAmber else StudioBorder,
                        RoundedCornerShape(9.dp)
                    )
                    .clickable { viewModel.toggleStudioBaseRigPositionLock() }
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("lock_base_rig_position_btn"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        if (rig.baseRigPositionLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = null,
                        tint = if (rig.baseRigPositionLocked) StudioAmber else StudioTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Column {
                        Text(
                            if (rig.baseRigPositionLocked) "Base Rig Position LOCKED" else "Lock Base Rig Position",
                            color = if (rig.baseRigPositionLocked) StudioAmber else StudioTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Pivots never drift during animation when locked",
                            color = StudioTextSecondary,
                            fontSize = 9.sp
                        )
                    }
                }
                Switch(
                    checked = rig.baseRigPositionLocked,
                    onCheckedChange = { viewModel.toggleStudioBaseRigPositionLock() }
                )
            }

            // Joint Chip Picker (including dedicated L Shoulder & R Shoulder!)
            Text("SELECT JOINT PIVOT (${rig.bones.size} BONES incl. L/R SHOULDERS)", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                rig.bones.forEach { bone ->
                    val sel = bone.id == activeBone?.id
                    val isShoulder = bone.id == "shoulder_l" || bone.id == "shoulder_r"
                    FilterChip(
                        selected = sel,
                        onClick = { viewModel.selectStudioDraftBone(bone.id) },
                        label = {
                            Text(
                                if (isShoulder) "★ ${bone.name}" else bone.name,
                                fontSize = 10.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (isShoulder) StudioMint.copy(alpha = 0.25f) else StudioCyan.copy(alpha = 0.25f),
                            selectedLabelColor = if (isShoulder) StudioMint else StudioCyan
                        )
                    )
                }
            }

            if (activeBone != null) {
                HorizontalDivider(color = StudioBorder)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Pivot: ${activeBone.name} (X:${activeBone.basePivotOffsetX.roundToInt()} Y:${activeBone.basePivotOffsetY.roundToInt()})",
                        color = StudioTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = stepPx == 1f,
                            onClick = { stepPx = 1f },
                            label = { Text("1px", fontSize = 9.sp) }
                        )
                        FilterChip(
                            selected = stepPx == 5f,
                            onClick = { stepPx = 5f },
                            label = { Text("5px", fontSize = 9.sp) }
                        )
                    }
                }

                // 1px Micro-Nudge Arrows + Numeric X / Y Fields
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { viewModel.nudgeStudioBonePivot(activeBone.id, -stepPx, 0f) },
                        enabled = !rig.baseRigPositionLocked,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(36.dp).testTag("rig_pivot_nudge_left")
                    ) { Text("←", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = { viewModel.nudgeStudioBonePivot(activeBone.id, 0f, -stepPx) },
                        enabled = !rig.baseRigPositionLocked,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(36.dp).testTag("rig_pivot_nudge_up")
                    ) { Text("↑", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = { viewModel.nudgeStudioBonePivot(activeBone.id, 0f, stepPx) },
                        enabled = !rig.baseRigPositionLocked,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(36.dp).testTag("rig_pivot_nudge_down")
                    ) { Text("↓", fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = { viewModel.nudgeStudioBonePivot(activeBone.id, stepPx, 0f) },
                        enabled = !rig.baseRigPositionLocked,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(36.dp).testTag("rig_pivot_nudge_right")
                    ) { Text("→", fontWeight = FontWeight.Bold) }

                    OutlinedTextField(
                        value = xText,
                        onValueChange = { v ->
                            xText = v
                            v.toFloatOrNull()?.let { nx ->
                                viewModel.setStudioBonePivotNumeric(activeBone.id, nx, activeBone.basePivotOffsetY)
                            }
                        },
                        enabled = !rig.baseRigPositionLocked,
                        label = { Text("X", fontSize = 9.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = yText,
                        onValueChange = { v ->
                            yText = v
                            v.toFloatOrNull()?.let { ny ->
                                viewModel.setStudioBonePivotNumeric(activeBone.id, activeBone.basePivotOffsetX, ny)
                            }
                        },
                        enabled = !rig.baseRigPositionLocked,
                        label = { Text("Y", fontSize = 9.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.setStudioBonePivotNumeric(activeBone.id, 0f, 0f) },
                        enabled = !rig.baseRigPositionLocked
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Reset Pivot", tint = StudioCoral, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Module 2: Per-View Exact Anatomical Z-Order Layering Presets
            HorizontalDivider(color = StudioBorder)
            Text("EXACT ANATOMICAL Z-ORDER BY VIEW SIDE", color = StudioViolet, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(
                "Front: Head > Body > Hands & Legs • Side: Near Limbs > Head > Body > Far Limbs • Back: Limbs > Body > Head",
                color = StudioTextSecondary,
                fontSize = 9.sp
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(
                    "Front View" to CharacterViewAngle.FRONT,
                    "Left Side" to CharacterViewAngle.SIDE_LEFT,
                    "Right Side" to CharacterViewAngle.SIDE_RIGHT,
                    "Back View" to CharacterViewAngle.BACK
                ).forEach { (label, angle) ->
                    OutlinedButton(
                        onClick = { viewModel.applyStudioAutoLayerOrderForView(angle) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp).testTag("auto_zorder_${angle.name.lowercase()}")
                    ) {
                        Text(label, fontSize = 10.sp, color = StudioViolet, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private enum class FaceLayerTarget(val key: String, val label: String, val accent: Color) {
    LEFT_EAR("LEFT_EAR", "Left Ear", StudioAmber),
    RIGHT_EAR("RIGHT_EAR", "Right Ear", StudioAmber),
    NOSE("NOSE", "Nose", StudioCoral),
    LEFT_EYE("LEFT_EYE", "Left Eye", StudioCyan),
    RIGHT_EYE("RIGHT_EYE", "Right Eye", StudioCyan),
    LEFT_BROW("LEFT_BROW", "Left Brow", StudioViolet),
    RIGHT_BROW("RIGHT_BROW", "Right Brow", StudioViolet),
    MOUTH("MOUTH", "Mouth", StudioMint)
}

/**
 * Master Upgrade Module 3:
 * Dedicated Face Making Layers (Zoomed Head Canvas with Symmetry Guide, Left/Right Ear PNGs,
 * Nose, 3-Layer Eye Making [Sclera/Pupil/Eyelid], Left/Right Brow, Mouth + 30% Watermark Frame Builder).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DedicatedFaceMakingLayersTab(
    rig: SkeletalRig,
    fps: Int,
    viewModel: StudioViewModel,
    onPickFaceFeaturePng: (featureKey: String) -> Unit,
    onPickEyeContainerPng: (isRight: Boolean, subLayer: String) -> Unit
) {
    var selectedTarget by remember { mutableStateOf(FaceLayerTarget.LEFT_EYE) }
    var editingRightEye by remember { mutableStateOf(false) }
    var builderIsMouth by remember { mutableStateOf(true) }
    var watermarkPreviewIdx by remember { mutableIntStateOf(0) }
    val fl = rig.faceLayers

    val activeTransform: FaceFeatureTransform = when (selectedTarget) {
        FaceLayerTarget.LEFT_EAR -> fl.leftEar
        FaceLayerTarget.RIGHT_EAR -> fl.rightEar
        FaceLayerTarget.NOSE -> fl.nose
        FaceLayerTarget.LEFT_EYE -> fl.leftEye
        FaceLayerTarget.RIGHT_EYE -> fl.rightEye
        FaceLayerTarget.LEFT_BROW -> fl.leftBrow
        FaceLayerTarget.RIGHT_BROW -> fl.rightBrow
        FaceLayerTarget.MOUTH -> fl.mouth
    }

    // 1. Zoomed-in Head & Face Builder Canvas with Vertical Center Symmetry Guide Line
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioCyan.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ZOOMED FACE & HEAD LAYERS BUILDER", color = StudioCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Drag on canvas to position ${selectedTarget.label} • Locked to Head bone",
                        color = StudioTextSecondary,
                        fontSize = 10.sp
                    )
                }
                Text("Symmetry |", color = StudioCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0E1422))
                    .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
                    .testTag("face_layers_zoomed_canvas")
                    .pointerInput(selectedTarget) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val scaleFactor = 0.42f
                            viewModel.nudgeStudioFaceFeature(
                                featureKey = selectedTarget.key,
                                dx = dragAmount.x * scaleFactor,
                                dy = dragAmount.y * scaleFactor
                            )
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawIntoCanvas { composeCanvas ->
                        val nc = composeCanvas.nativeCanvas
                        val w = size.width
                        val h = size.height
                        nc.save()

                        // Zoom right onto the character's Head!
                        val solved = RigSolver.solveForwardKinematics(
                            rig = rig,
                            angleOverrides = emptyMap(),
                            rootX = rig.rootX,
                            rootY = rig.rootY,
                            scale = rig.scale,
                            flippedHorizontal = SceneRenderer.isLeftFacingView(rig.viewAngle, rig.flippedHorizontal)
                        )
                        val headBone = solved.firstOrNull { it.bone.id == "neck" }
                        val hx = headBone?.let { (it.start.x + it.end.x * 2f) / 3f } ?: rig.rootX
                        val hy = headBone?.let { (it.start.y + it.end.y * 2f) / 3f } ?: (rig.rootY - 90f)
                        val zoom = (minOf(w, h) / 165f).coerceIn(0.8f, 3.5f)
                        nc.translate(w / 2f, h / 2f)
                        nc.scale(zoom, zoom)
                        nc.translate(-hx, -hy)

                        SceneRenderer.drawSkeletalRig(
                            canvas = nc,
                            rig = rig,
                            puppetRoot = EvaluatedPuppetRoot(
                                rootX = rig.rootX,
                                rootY = rig.rootY,
                                scale = rig.scale,
                                scaleX = rig.baseScaleX,
                                scaleY = rig.baseScaleY,
                                flippedHorizontal = rig.flippedHorizontal,
                                viewAngle = rig.viewAngle,
                                eyePack = rig.eyePack,
                                eyebrowStyle = rig.eyebrowStyle,
                                mouthPhoneme = rig.mouthPhoneme,
                                behaviorPreset = rig.behaviorPreset
                            ),
                            angles = emptyMap(),
                            frame = 0,
                            fps = fps,
                            audioTracks = emptyList(),
                            alpha = 1f,
                            tintColorArgb = null,
                            showOverlay = false,
                            isSelectedPuppet = false,
                            selectedBoneId = null
                        )
                        nc.restore()

                        // Vertical Center Symmetry Guide Line & Horizontal Face Proportions Guide
                        val symPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0xAA06B6D4.toInt()
                            style = Paint.Style.STROKE
                            strokeWidth = 2f
                            pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
                        }
                        nc.drawLine(w / 2f, 0f, w / 2f, h, symPaint)
                        val horizPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = 0x44FFFFFF
                            style = Paint.Style.STROKE
                            strokeWidth = 1.5f
                            pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f)
                        }
                        nc.drawLine(0f, h * 0.44f, w, h * 0.44f, horizPaint)
                        nc.drawLine(0f, h * 0.64f, w, h * 0.64f, horizPaint)
                    }
                }
            }

            // Face Layer Selector Chips
            FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FaceLayerTarget.entries.forEach { target ->
                    val isSelected = target == selectedTarget
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTarget = target },
                        label = { Text(target.label, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = target.accent.copy(alpha = 0.25f),
                            selectedLabelColor = target.accent
                        ),
                        modifier = Modifier.testTag("face_layer_chip_${target.key.lowercase()}")
                    )
                }
            }

            // Selected Feature Controls: 1px Micro-Nudge + Scale + Rotation + Z-Order + PNG Slot
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${selectedTarget.label}: X=${activeTransform.offsetX.roundToInt()} Y=${activeTransform.offsetY.roundToInt()} • Z:${activeTransform.zOrder}",
                    color = StudioTextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = {
                        viewModel.updateStudioFaceFeatureTransform(selectedTarget.key) {
                            it.copy(visible = !it.visible)
                        }
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        if (activeTransform.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "Toggle Layer Visibility",
                        tint = if (activeTransform.visible) StudioCyan else StudioTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { viewModel.nudgeStudioFaceFeature(selectedTarget.key, -1f, 0f) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(34.dp)
                ) { Text("←") }
                OutlinedButton(
                    onClick = { viewModel.nudgeStudioFaceFeature(selectedTarget.key, 0f, -1f) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(34.dp)
                ) { Text("↑") }
                OutlinedButton(
                    onClick = { viewModel.nudgeStudioFaceFeature(selectedTarget.key, 0f, 1f) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(34.dp)
                ) { Text("↓") }
                OutlinedButton(
                    onClick = { viewModel.nudgeStudioFaceFeature(selectedTarget.key, 1f, 0f) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(34.dp)
                ) { Text("→") }

                OutlinedButton(
                    onClick = {
                        viewModel.updateStudioFaceFeatureTransform(selectedTarget.key) {
                            it.copy(zOrder = (it.zOrder + 1).coerceAtMost(20))
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(13.dp))
                    Text("Z+", fontSize = 10.sp)
                }
                OutlinedButton(
                    onClick = {
                        viewModel.updateStudioFaceFeatureTransform(selectedTarget.key) {
                            it.copy(zOrder = (it.zOrder - 1).coerceAtLeast(-10))
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(13.dp))
                    Text("Z-", fontSize = 10.sp)
                }
                OutlinedButton(
                    onClick = {
                        viewModel.updateStudioFaceFeatureTransform(selectedTarget.key) {
                            FaceFeatureTransform(zOrder = it.zOrder)
                        }
                    },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = "Reset Feature", tint = StudioCoral, modifier = Modifier.size(16.dp))
                }
            }

            Text(
                "Scale: ${String.format("%.2f×", activeTransform.scale)}  |  Rot: ${activeTransform.rotationDeg.roundToInt()}°",
                color = StudioTextSecondary,
                fontSize = 10.sp
            )
            Slider(
                value = activeTransform.scale.coerceIn(0.3f, 3.0f),
                onValueChange = { v ->
                    viewModel.updateStudioFaceFeatureTransform(selectedTarget.key) { it.copy(scale = v) }
                },
                valueRange = 0.3f..3.0f,
                colors = SliderDefaults.colors(thumbColor = selectedTarget.accent, activeTrackColor = selectedTarget.accent)
            )
            Slider(
                value = activeTransform.rotationDeg.coerceIn(-45f, 45f),
                onValueChange = { v ->
                    viewModel.updateStudioFaceFeatureTransform(selectedTarget.key) { it.copy(rotationDeg = v) }
                },
                valueRange = -45f..45f,
                colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber)
            )

            // Custom PNG Import for Ears, Nose, Left/Right Brow
            if (selectedTarget in listOf(
                    FaceLayerTarget.LEFT_EAR,
                    FaceLayerTarget.RIGHT_EAR,
                    FaceLayerTarget.NOSE,
                    FaceLayerTarget.LEFT_BROW,
                    FaceLayerTarget.RIGHT_BROW
                )
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { onPickFaceFeaturePng(selectedTarget.key) },
                        colors = ButtonDefaults.buttonColors(containerColor = selectedTarget.accent),
                        shape = RoundedCornerShape(9.dp),
                        modifier = Modifier.weight(1f).testTag("import_face_feature_${selectedTarget.key.lowercase()}")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("Import ${selectedTarget.label} PNG", color = Color(0xFF080B12), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { viewModel.clearStudioFaceFeaturePng(selectedTarget.key) },
                        shape = RoundedCornerShape(9.dp)
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear PNG", tint = StudioRose, modifier = Modifier.size(15.dp))
                    }
                }
            }

            if (selectedTarget == FaceLayerTarget.NOSE) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    NoseStylePreset.entries.forEach { preset ->
                        FilterChip(
                            selected = rig.noseStyle == preset.name,
                            onClick = { viewModel.updateStudioDraftRig { it.copy(noseStyle = preset.name) } },
                            label = { Text(preset.label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        }
    }

    // 2. Dedicated 3-Layer Eye Making System (Sclera / Pupil / Eyelid)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioViolet.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
    ) {
        val eyeContainer = if (editingRightEye) rig.rightEyeContainer else rig.leftEyeContainer
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("3-LAYER EYE MAKING SYSTEM (ALPHA-MASKED)", color = StudioViolet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Pupil/Iris stays cleanly clipped inside Sclera boundary", color = StudioTextSecondary, fontSize = 9.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = !editingRightEye,
                        onClick = { editingRightEye = false },
                        label = { Text("L-Eye", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = editingRightEye,
                        onClick = { editingRightEye = true },
                        label = { Text("R-Eye", fontSize = 10.sp) }
                    )
                }
            }

            listOf(
                Triple("SCLERA", "1. Bottom: Eye White / Sclera (সাদা অংশ)", !eyeContainer.scleraImagePath.isNullOrBlank()),
                Triple("PUPIL", "2. Middle: Pupil / Iris (চোখের মণি)", !eyeContainer.pupilImagePath.isNullOrBlank()),
                Triple("EYELID", "3. Top: Eyelid / Blink (চোখের পাতা)", !eyeContainer.eyelidImagePath.isNullOrBlank())
            ).forEach { (subKey, title, assigned) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(PanelSurface)
                        .border(1.dp, if (assigned) StudioMint else StudioBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (assigned) "$title ✓" else title,
                        color = if (assigned) StudioMint else StudioTextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { onPickEyeContainerPng(editingRightEye, subKey) },
                        shape = RoundedCornerShape(7.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(if (assigned) "Replace" else "Import PNG", fontSize = 10.sp, color = StudioCyan)
                    }
                }
            }
        }
    }

    // 3. Frame-by-Frame Watermark Builder (Mouth & Eyebrows — shows Frame N-1 at 30% Onion-Skin Watermark!)
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StudioAmber.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
    ) {
        val frames = if (builderIsMouth) fl.mouthBuilderFrames else fl.browBuilderFrames
        val clampedIdx = watermarkPreviewIdx.coerceIn(0, (frames.size - 1).coerceAtLeast(0))
        val prevFramePath = if (frames.size >= 2 && clampedIdx > 0) frames[clampedIdx - 1] else frames.lastOrNull()
        val curFramePath = frames.getOrNull(clampedIdx)
        val prevBmp = remember(prevFramePath) {
            prevFramePath?.takeIf { File(it).exists() }?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
        }
        val curBmp = remember(curFramePath) {
            curFramePath?.takeIf { File(it).exists() }?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
        }

        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("WATERMARK FRAME BUILDER (30% ONION-SKIN)", color = StudioAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Shows previous frame at 30% watermark so Frame 2, 3, 4 align accurately", color = StudioTextSecondary, fontSize = 9.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = builderIsMouth,
                        onClick = { builderIsMouth = true; watermarkPreviewIdx = 0 },
                        label = { Text("Mouth (${fl.mouthBuilderFrames.size})", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = !builderIsMouth,
                        onClick = { builderIsMouth = false; watermarkPreviewIdx = 0 },
                        label = { Text("Brows (${fl.browBuilderFrames.size})", fontSize = 10.sp) }
                    )
                }
            }

            // Onion-Skin Watermark Preview Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0C1220))
                    .border(1.dp, StudioBorder, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (frames.isEmpty()) {
                    Text(
                        "Tap '+ Add Frame PNG' to start building aligned ${if (builderIsMouth) "Mouth" else "Eyebrow"} frames",
                        color = StudioTextSecondary,
                        fontSize = 10.sp
                    )
                } else {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawIntoCanvas { cc ->
                            val nc = cc.nativeCanvas
                            val pad = 16f
                            val dst = RectF(size.width / 2f - 70f, pad, size.width / 2f + 70f, size.height - pad)
                            // Vertical symmetry centerline
                            val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = 0x6606B6D4
                                strokeWidth = 1.5f
                                pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
                            }
                            nc.drawLine(size.width / 2f, 0f, size.width / 2f, size.height, guideP)

                            // Previous Frame N-1 rendered underneath at 30% opacity Watermark!
                            if (prevBmp != null && frames.size >= 2 && clampedIdx > 0) {
                                val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                                    alpha = (255 * 0.30f).toInt()
                                }
                                nc.drawBitmap(prevBmp, null, dst, wmPaint)
                            }
                            if (curBmp != null) {
                                val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                                nc.drawBitmap(curBmp, null, dst, fgPaint)
                            }
                        }
                    }
                }
            }

            if (frames.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    frames.forEachIndexed { idx, _ ->
                        val active = idx == clampedIdx
                        Surface(
                            color = if (active) StudioAmber.copy(alpha = 0.25f) else PanelSurface,
                            shape = RoundedCornerShape(7.dp),
                            modifier = Modifier
                                .border(1.dp, if (active) StudioAmber else StudioBorder, RoundedCornerShape(7.dp))
                                .clickable { watermarkPreviewIdx = idx }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("F${idx + 1}", color = if (active) StudioAmber else StudioTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(4.dp))
                                Icon(
                                    Icons.Default.Clear,
                                    contentDescription = "Remove Frame",
                                    tint = StudioRose,
                                    modifier = Modifier
                                        .size(13.dp)
                                        .clickable { viewModel.removeStudioBuilderFrame(builderIsMouth, idx) }
                                )
                            }
                        }
                    }
                }
            }

            var showWatermarkDrawDialog by remember { mutableStateOf(false) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { showWatermarkDrawDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
                    shape = RoundedCornerShape(9.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f).testTag("draw_watermark_builder_frame_btn")
                ) {
                    Icon(Icons.Default.Brush, contentDescription = null, tint = Color(0xFF080B12), modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "Draw F#${frames.size + 1} (30% Ghost)",
                        color = Color(0xFF080B12),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedButton(
                    onClick = {
                        onPickFaceFeaturePng(if (builderIsMouth) "MOUTH_BUILDER_FRAME" else "BROW_BUILDER_FRAME")
                    },
                    shape = RoundedCornerShape(9.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1f).testTag("add_watermark_builder_frame_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = StudioAmber, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "Import PNG F#${frames.size + 1}",
                        color = StudioAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (showWatermarkDrawDialog) {
                val referenceWatermarkPath = frames.lastOrNull()
                WatermarkFrameDrawDialog(
                    title = "Draw ${if (builderIsMouth) "Mouth" else "Eyebrow"} Frame #${frames.size + 1}",
                    watermarkImagePath = referenceWatermarkPath,
                    onDismiss = { showWatermarkDrawDialog = false },
                    onSave = { strokes, w, h ->
                        viewModel.saveDrawnStudioBuilderFrame(builderIsMouth, strokes, w, h)
                        showWatermarkDrawDialog = false
                        watermarkPreviewIdx = frames.size
                    }
                )
            }
        }
    }
}

@Composable
private fun WatermarkFrameDrawDialog(
    title: String,
    watermarkImagePath: String?,
    onDismiss: () -> Unit,
    onSave: (strokes: List<DrawStroke>, width: Float, height: Float) -> Unit
) {
    val strokes = remember { mutableStateListOf<DrawStroke>() }
    var activePoints by remember { mutableStateOf<List<Vec2>>(emptyList()) }
    var activeColorArgb by remember { mutableStateOf(0xFF141824L) }
    var brushWidth by remember { mutableFloatStateOf(9f) }
    var padWidth by remember { mutableFloatStateOf(360f) }
    var padHeight by remember { mutableFloatStateOf(200f) }
    val wmBmp = remember(watermarkImagePath) {
        watermarkImagePath?.takeIf { File(it).exists() }?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
    }
    val palette = listOf(0xFF141824L, 0xFFFFFFFFL, 0xFFEF4444L, 0xFF991B1BL, 0xFF78350FL, 0xFFF59E0BL)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PanelElevated,
        title = {
            Column {
                Text(title, color = StudioTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (wmBmp != null) "Previous frame shown underneath at 30% Watermark for exact alignment"
                    else "Draw Frame #1 directly — Frame #2 will show this at 30% Watermark",
                    color = StudioAmber,
                    fontSize = 10.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFE2E8F0))
                        .border(1.5.dp, StudioAmber, RoundedCornerShape(12.dp))
                        .pointerInput(activeColorArgb, brushWidth) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                down.consume()
                                val pts = mutableListOf(Vec2(down.position.x, down.position.y))
                                activePoints = pts.toList()
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull() ?: break
                                    if (!ch.pressed) break
                                    ch.consume()
                                    pts.add(Vec2(ch.position.x, ch.position.y))
                                    activePoints = pts.toList()
                                }
                                if (pts.isNotEmpty()) {
                                    strokes.add(DrawStroke(points = pts.toList(), colorArgb = activeColorArgb, strokeWidth = brushWidth, opacity = 1f))
                                }
                                activePoints = emptyList()
                            }
                        }
                        .testTag("watermark_frame_draw_canvas")
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        padWidth = size.width
                        padHeight = size.height
                        drawIntoCanvas { cc ->
                            val nc = cc.nativeCanvas
                            // Center vertical symmetry guide
                            val guideP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                color = 0x8806B6D4.toInt()
                                strokeWidth = 1.5f
                                pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
                            }
                            nc.drawLine(size.width / 2f, 0f, size.width / 2f, size.height, guideP)
                            // Previous frame 30% Onion-Skin Watermark!
                            if (wmBmp != null) {
                                val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                                    alpha = (255 * 0.30f).toInt()
                                }
                                nc.drawBitmap(wmBmp, null, RectF(0f, 0f, size.width, size.height), wmPaint)
                            }
                        }
                        strokes.forEach { st ->
                            if (st.points.size == 1) {
                                drawCircle(Color(st.colorArgb), st.strokeWidth * 0.5f, Offset(st.points[0].x, st.points[0].y))
                            } else if (st.points.size > 1) {
                                val p = Path().apply {
                                    moveTo(st.points[0].x, st.points[0].y)
                                    for (i in 1 until st.points.size) lineTo(st.points[i].x, st.points[i].y)
                                }
                                drawPath(p, Color(st.colorArgb), style = Stroke(st.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                        if (activePoints.size > 1) {
                            val p = Path().apply {
                                moveTo(activePoints[0].x, activePoints[0].y)
                                for (i in 1 until activePoints.size) lineTo(activePoints[i].x, activePoints[i].y)
                            }
                            drawPath(p, Color(activeColorArgb), style = Stroke(brushWidth, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        palette.forEach { argb ->
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(argb))
                                    .border(if (activeColorArgb == argb) 2.dp else 1.dp, if (activeColorArgb == argb) StudioAmber else StudioBorder, CircleShape)
                                    .clickable { activeColorArgb = argb }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) }) {
                            Text("Undo", color = StudioCyan, fontSize = 11.sp)
                        }
                        TextButton(onClick = { strokes.clear() }) {
                            Text("Clear", color = StudioRose, fontSize = 11.sp)
                        }
                    }
                }
                Slider(
                    value = brushWidth,
                    onValueChange = { brushWidth = it },
                    valueRange = 2f..24f,
                    colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(strokes.toList(), padWidth, padHeight) },
                enabled = strokes.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = StudioAmber)
            ) {
                Text("Save Frame", color = Color(0xFF080B12), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = StudioTextSecondary) }
        }
    )
}
