package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AnimationLayer
import com.example.data.model.CanvasTextItem
import com.example.data.model.CharacterViewAngle
import com.example.data.model.DrawStroke
import com.example.data.model.EditorTool
import com.example.data.model.EyePackStyle
import com.example.data.model.HandPropKind
import com.example.data.model.LayerType
import com.example.data.model.MouthPhoneme
import com.example.data.model.ShapeKind
import com.example.data.model.TextInAnimation
import com.example.data.model.TextLoopAnimation
import com.example.data.model.Vec2
import com.example.data.model.VectorShape
import com.example.engine.InterpolationEngine
import com.example.engine.RigSolver
import com.example.engine.SceneRenderer
import com.example.ui.theme.CanvasBackdrop
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCoral
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.StudioViolet
import com.example.ui.viewmodel.StudioUiState
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private enum class SelectionHandleMode {
    NONE,
    TRANSLATE,
    RESIZE_CORNER,
    RESIZE_EDGE_X,
    RESIZE_EDGE_Y,
    ROTATE
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CanvasStage(
    uiState: StudioUiState,
    onCommitStroke: (DrawStroke) -> Unit,
    onCommitShape: (VectorShape) -> Unit,
    onPaintBucket: (Float, Float) -> Unit,
    onPickColor: (Float, Float) -> Unit,
    onAddText: (String, Float, Float, TextInAnimation, TextLoopAnimation) -> Unit,
    onSelectText: (String?) -> Unit,
    onMoveText: (String, Float, Float, Boolean) -> Unit,
    onUpdateText: (String, Boolean, (CanvasTextItem) -> CanvasTextItem) -> Unit,
    onDuplicateText: (String) -> Unit,
    onDeleteText: (String) -> Unit,
    onOpenTextStudio: () -> Unit,
    onDirectTransform: (dx: Float, dy: Float, scaleFactor: Float, rotationDeltaDeg: Float, recordUndo: Boolean) -> Unit,
    onDirectTransformXY: ((dx: Float, dy: Float, scaleFactor: Float, scaleXFactor: Float, scaleYFactor: Float, rotationDeltaDeg: Float, recordUndo: Boolean) -> Unit)? = null,
    onSetAbsoluteTransform: (rotationDeg: Float?, scale: Float?, reset: Boolean) -> Unit = { _, _, _ -> },
    onSelectLayer: (String) -> Unit,
    onSelectBone: (String?) -> Unit,
    onDragRigBone: (String, Vec2, Boolean) -> Unit,
    onRotateRigBoneDelta: (String, Float, Boolean) -> Unit = { _, _, _ -> },
    onRotatePropDelta: (Float, Boolean) -> Unit = { _, _ -> },
    onMovePuppetRoot: (Float, Float, Boolean) -> Unit,
    onTogglePuppetFlip: () -> Unit,
    onTogglePuppetAutoWalk: () -> Unit,
    onTogglePuppetGhostMode: () -> Unit,
    onCyclePuppetViewAngle: () -> Unit,
    onCyclePuppetHandProp: (isRightHand: Boolean) -> Unit,
    onCyclePuppetEyePack: (EyePackStyle) -> Unit,
    onCyclePuppetMouthPhoneme: (MouthPhoneme) -> Unit,
    onApplyPuppetPose: (String) -> Unit,
    onOpenImportCharacter: () -> Unit,
    onToggleCameraHud: () -> Unit = {},
    onUpdateCamera: (panX: Float, panY: Float, zoom: Float, rotationDeg: Float) -> Unit = { _, _, _, _ -> },
    onCameraDollyZoom: () -> Unit = {},
    onCameraPanAcross: () -> Unit = {},
    onCameraShake: () -> Unit = {},
    onResetCamera: () -> Unit = {},
    onToggleCharacterActions: () -> Unit = {},
    onOpenExtraRigPanel: () -> Unit = {},
    onToggleStretchRig: () -> Unit = {},
    onToggleLiveRecord: () -> Unit = {},
    onRecordLivePad: (String) -> Unit = {},
    isCelStudioMode: Boolean = false,
    onAddMotionPathPoint: (Vec2) -> Unit,
    onSetMotionPath: (List<Vec2>) -> Unit = {},
    onUndoMotionPathPoint: () -> Unit = {},
    onReverseMotionPath: () -> Unit = {},
    onToggleMotionPathOrient: () -> Unit = {},
    onCycleMotionPathEasing: () -> Unit = {},
    onClearMotionPath: () -> Unit = {},
    onUpdateViewport: (Float, Float, Float) -> Unit,
    onResetViewport: () -> Unit,
    onMicroNudge: (Float, Float) -> Unit = { _, _ -> },
    onToggleMicroNudgeStep: () -> Unit = {},
    onToggleFaceMoodDock: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val project = uiState.activeProject ?: return
    val scene = uiState.activeScene ?: return

    var activeStroke by remember { mutableStateOf<DrawStroke?>(null) }
    var activeShape by remember { mutableStateOf<VectorShape?>(null) }
    var activeMotionPathDraft by remember { mutableStateOf<List<Vec2>?>(null) }
    var magnifierStagePt by remember { mutableStateOf<Vec2?>(null) }
    var pendingTextPos by remember { mutableStateOf<Vec2?>(null) }
    var editingTextId by remember { mutableStateOf<String?>(null) }
    var textDraft by remember { mutableStateOf("") }
    var draftInAnim by remember { mutableStateOf(TextInAnimation.POP_BOUNCE) }
    var draftLoopAnim by remember { mutableStateOf(TextLoopAnimation.NONE) }

    val latestState by rememberUpdatedState(uiState)
    val latestCommitStroke by rememberUpdatedState(onCommitStroke)
    val latestCommitShape by rememberUpdatedState(onCommitShape)
    val latestPaintBucket by rememberUpdatedState(onPaintBucket)
    val latestPickColor by rememberUpdatedState(onPickColor)
    val latestSelectText by rememberUpdatedState(onSelectText)
    val latestMoveText by rememberUpdatedState(onMoveText)
    val latestDirectTransform by rememberUpdatedState(onDirectTransform)
    val latestDirectTransformXY by rememberUpdatedState(onDirectTransformXY)
    val latestSelectLayer by rememberUpdatedState(onSelectLayer)
    val latestSelectBone by rememberUpdatedState(onSelectBone)
    val latestDragBone by rememberUpdatedState(onDragRigBone)
    val latestRotateBoneDelta by rememberUpdatedState(onRotateRigBoneDelta)
    val latestRotatePropDelta by rememberUpdatedState(onRotatePropDelta)
    val latestMovePuppetRoot by rememberUpdatedState(onMovePuppetRoot)
    val latestAddMotionPath by rememberUpdatedState(onAddMotionPathPoint)
    val latestSetMotionPath by rememberUpdatedState(onSetMotionPath)
    val latestUpdateViewport by rememberUpdatedState(onUpdateViewport)

    val selectedLayer = uiState.selectedLayer
    val selectedRig = selectedLayer?.rig
    val selectedPuppetRoot = remember(selectedLayer, selectedRig, uiState.currentFrame, scene.durationFrames) {
        if (selectedLayer != null && selectedRig != null) {
            InterpolationEngine.evaluatePuppetRootWithPath(selectedLayer, selectedRig, uiState.currentFrame, scene.durationFrames)
        } else null
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasBackdrop)
            .clipToBounds()
            .testTag("animation_canvas_stage")
    ) {
        val density = LocalDensity.current
        // Track exact raw Canvas pixel size so pointerInput & drawIntoCanvas share the EXACT same pixel grid
        var canvasSizePx by remember { mutableStateOf(IntSize.Zero) }
        val viewW = (if (canvasSizePx.width > 0) canvasSizePx.width.toFloat() else constraints.maxWidth.toFloat()).coerceAtLeast(1f)
        val viewH = (if (canvasSizePx.height > 0) canvasSizePx.height.toFloat() else constraints.maxHeight.toFloat()).coerceAtLeast(1f)
        val projW = project.width.toFloat().coerceAtLeast(1f)
        val projH = project.height.toFloat().coerceAtLeast(1f)

        val baseScale = min((viewW * 0.92f) / projW, (viewH * 0.92f) / projH)
        val totalScale = baseScale * uiState.canvasZoom
        val stageW = projW * totalScale
        val stageH = projH * totalScale
        val originX = (viewW - stageW) / 2f + uiState.canvasPanX
        val originY = (viewH - stageH) / 2f + uiState.canvasPanY

        val latestOriginX by rememberUpdatedState(originX)
        val latestOriginY by rememberUpdatedState(originY)
        val latestTotalScale by rememberUpdatedState(totalScale)
        val latestProjW by rememberUpdatedState(projW)
        val latestProjH by rememberUpdatedState(projH)

        fun toStageWorld(offset: Offset, parallax: Float = 1f): Vec2 {
            val st = latestState
            val sc = st.activeScene
            val safeScale = latestTotalScale.coerceAtLeast(0.0001f)
            if (sc == null) {
                return Vec2(
                    (offset.x - latestOriginX) / safeScale,
                    (offset.y - latestOriginY) / safeScale
                )
            }
            val cam = InterpolationEngine.evaluateCamera(sc, st.currentFrame)
            return InterpolationEngine.canvasPxToStageWorld(
                canvasPxX = offset.x,
                canvasPxY = offset.y,
                projectWidth = latestProjW,
                projectHeight = latestProjH,
                originX = latestOriginX,
                originY = latestOriginY,
                totalScale = safeScale,
                camera = cam,
                parallax = parallax
            )
        }

        fun toLayerLocal(offset: Offset, layer: AnimationLayer?): Vec2 {
            val st = latestState
            val sc = st.activeScene
            if (sc == null || layer == null) return toStageWorld(offset)
            val world = toStageWorld(offset, layer.parallaxDepth)
            val tf = InterpolationEngine.evaluateLayerTransform(layer, st.currentFrame, sc.durationFrames)
            val bgShiftX = InterpolationEngine.computeBgScrollShiftX(layer, sc, st.currentFrame, latestProjW)
            val pivot = SceneRenderer.computeLayerPivot(layer, st.currentFrame, sc.durationFrames, latestProjW, latestProjH)
            val dx = world.x - (pivot.x + tf.x + bgShiftX)
            val dy = world.y - (pivot.y + tf.y)
            val rad = Math.toRadians((-tf.rotationDeg).toDouble())
            val cosR = cos(rad).toFloat()
            val sinR = sin(rad).toFloat()
            val rx = dx * cosR - dy * sinR
            val ry = dx * sinR + dy * cosR
            val safeSx = if (kotlin.math.abs(tf.scaleX) < 0.0001f) 1f else tf.scaleX
            val safeSy = if (kotlin.math.abs(tf.scaleY) < 0.0001f) 1f else tf.scaleY
            return Vec2(rx / safeSx + pivot.x, ry / safeSy + pivot.y)
        }

        fun toStageScreen(offset: Offset): Vec2 {
            val safeScale = latestTotalScale.coerceAtLeast(0.0001f)
            val rawX = (offset.x - latestOriginX) / safeScale
            val rawY = (offset.y - latestOriginY) / safeScale
            return Vec2(rawX, rawY)
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { canvasSizePx = it }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val firstDown = awaitFirstDown(requireUnconsumed = false)
                        val startPos = firstDown.position
                        val st0 = latestState
                        val tool = st0.activeTool
                        val selLayer0 = st0.selectedLayer
                        val startStage = toStageWorld(startPos, selLayer0?.parallaxDepth ?: 1f)
                        val startLayerPt = toLayerLocal(startPos, selLayer0)
                        val startScreen = toStageScreen(startPos)
                        val curProjW = latestProjW
                        val curProjH = latestProjH

                        val isDrawingOrShapeTool = tool in listOf(
                            EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH,
                            EditorTool.ERASER, EditorTool.PEN_BEZIER,
                            EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON
                        )
                        if (isDrawingOrShapeTool) {
                            // Claim initial touch immediately so zero starting pixels are lost or shifted
                            firstDown.consume()
                        }

                        var isMultiTouch = false
                        var hasDragged = false
                        var lastPos = startPos
                        var lastStage = startStage
                        var lastLayerPt = startLayerPt

                        var draggingTextId: String? = null
                        var draggingTextOffsetX = 0f
                        var draggingTextOffsetY = 0f
                        var textUndoRecorded = false

                        var draggingBoneId: String? = null
                        var rotatingRingBoneId: String? = null
                        var rotatingPropRing = false
                        var propRingPivot = Vec2(0f, 0f)
                        var prevPropRingAngleDeg = 0f
                        var propRingUndoRecorded = false
                        var ringPivot = Vec2(0f, 0f)
                        var ringFlipped = false
                        var prevRingAngleDeg = 0f
                        var ringUndoRecorded = false
                        var draggingPuppetRoot = false
                        var puppetUndoRecorded = false
                        var selectUndoRecorded = false
                        var handleMode = SelectionHandleMode.NONE
                        var boundsCenterX = curProjW / 2f
                        var boundsCenterY = curProjH / 2f

                        val activeSc = st0.activeScene
                        // Guarantee >= 48dp touch hit-test radius in screen space for all rig & gizmo handles!
                        val minTouch48dpWorld = with(density) { 48.dp.toPx() } / latestTotalScale.coerceAtLeast(0.1f)
                        val rigTouchRadius = max(minTouch48dpWorld, 68f)
                        val gizmoTouchRadius = max(minTouch48dpWorld, 54f)

                        // PRIORITY 0 (PROP ROTATION RING): When Rotate Prop mode is active on a rigid prop layer,
                        // lock touch exclusively onto the Prisma-style Prop Rotation Ring until finger release!
                        val selProp0 = st0.selectedLayer
                        if (st0.propRotateMode && !st0.isPlaying && activeSc != null &&
                            selProp0 != null && selProp0.rig == null &&
                            selProp0.type != LayerType.BACKGROUND.name &&
                            selProp0.type != LayerType.VIDEO.name &&
                            InterpolationEngine.isLayerVisibleAtFrame(selProp0, st0.currentFrame)
                        ) {
                            val propStageStart = toStageWorld(startPos, selProp0.parallaxDepth)
                            val propWorld = InterpolationEngine.resolvePropWorldTransform(
                                scene = activeSc,
                                layer = selProp0,
                                pivot = Vec2(curProjW / 2f, curProjH / 2f),
                                frame = st0.currentFrame,
                                audioTracks = st0.activeProject?.audioTracks ?: emptyList(),
                                fps = st0.activeProject?.fps ?: 24
                            )
                            val ringR = SceneRenderer.PRISMA_ROTATION_RING_RADIUS + 8f
                            val ringBand = max(32f, minTouch48dpWorld * 0.68f)
                            val dxP = propStageStart.x - propWorld.worldX
                            val dyP = propStageStart.y - propWorld.worldY
                            val distFromPivot = hypot(dxP, dyP)
                            val hRad = Math.toRadians(propWorld.worldAngleDeg.toDouble())
                            val hX = propWorld.worldX + cos(hRad).toFloat() * ringR
                            val hY = propWorld.worldY + sin(hRad).toFloat() * ringR
                            val distToHandle = hypot(propStageStart.x - hX, propStageStart.y - hY)
                            if (kotlin.math.abs(distFromPivot - ringR) <= ringBand ||
                                distToHandle <= max(40f, minTouch48dpWorld * 0.78f)
                            ) {
                                rotatingPropRing = true
                                propRingPivot = Vec2(propWorld.worldX, propWorld.worldY)
                                prevPropRingAngleDeg = Math.toDegrees(atan2(dyP.toDouble(), dxP.toDouble())).toFloat()
                                firstDown.consume()
                            }
                        }

                        // PRIORITY 1 (RIG_EDIT): Prisma 3D Circular Joint Rotation Ring (exclusive lock) + Single-Bone Pivot Selection
                        if (!rotatingPropRing && tool == EditorTool.RIG_EDIT && activeSc != null) {
                            val visibleRigs = activeSc.layers.reversed().filter {
                                InterpolationEngine.isLayerVisibleAtFrame(it, st0.currentFrame) && it.rig != null
                            }
                            val orderedRigs = buildList {
                                st0.selectedLayer?.takeIf {
                                    InterpolationEngine.isLayerVisibleAtFrame(it, st0.currentFrame) && it.rig != null
                                }?.let { add(it) }
                                visibleRigs.forEach { if (it.id != st0.selectedLayer?.id) add(it) }
                            }
                            for (rigLayer in orderedRigs) {
                                val rig = InterpolationEngine.resolveEffectiveRigAtFrame(rigLayer, st0.currentFrame) ?: continue
                                val rigStartStage = toStageWorld(startPos, rigLayer.parallaxDepth)
                                val pRoot = InterpolationEngine.evaluatePuppetRootWithPath(rigLayer, rig, st0.currentFrame, activeSc.durationFrames)
                                val distRoot = hypot(rigStartStage.x - pRoot.rootX, rigStartStage.y - pRoot.rootY)
                                val angles = InterpolationEngine.evaluateRigAnglesWithPath(rigLayer, rig, st0.currentFrame, activeSc.durationFrames)
                                val lengths = InterpolationEngine.evaluateBoneLengths(rig, st0.currentFrame)
                                val effectiveFlipped = SceneRenderer.isLeftFacingView(pRoot.viewAngle, pRoot.flippedHorizontal)
                                val solved = RigSolver.solveForwardKinematics(
                                    rig = rig,
                                    angleOverrides = angles,
                                    lengthOverrides = lengths,
                                    rootX = pRoot.rootX,
                                    rootY = pRoot.rootY,
                                    scale = pRoot.scale,
                                    scaleX = pRoot.scaleX,
                                    scaleY = pRoot.scaleY,
                                    flippedHorizontal = effectiveFlipped,
                                    frame = st0.currentFrame
                                )

                                // Priority 1A: If a single bone is already selected on this rig, check its Circular Rotation Ring FIRST
                                // and lock touch capture exclusively onto the ring until finger release!
                                if (rigLayer.id == st0.selectedLayerId && st0.selectedBoneId != null) {
                                    val activeSolved = solved.firstOrNull { it.bone.id == st0.selectedBoneId && !it.bone.locked }
                                    if (activeSolved != null) {
                                        val ringR = SceneRenderer.PRISMA_ROTATION_RING_RADIUS * pRoot.scale.coerceAtLeast(0.45f)
                                        val ringBand = max(28f, minTouch48dpWorld * 0.6f)
                                        val dxRing = rigStartStage.x - activeSolved.start.x
                                        val dyRing = rigStartStage.y - activeSolved.start.y
                                        val distFromPivot = hypot(dxRing, dyRing)
                                        val handleRad = Math.toRadians(activeSolved.worldAngleDeg.toDouble())
                                        val handleX = activeSolved.start.x + cos(handleRad).toFloat() * ringR
                                        val handleY = activeSolved.start.y + sin(handleRad).toFloat() * ringR
                                        val distToHandle = hypot(rigStartStage.x - handleX, rigStartStage.y - handleY)
                                        val hitRingCircumference = kotlin.math.abs(distFromPivot - ringR) <= ringBand
                                        val hitHandleKnob = distToHandle <= max(36f, minTouch48dpWorld * 0.7f)
                                        if (hitRingCircumference || hitHandleKnob) {
                                            rotatingRingBoneId = activeSolved.bone.id
                                            ringPivot = activeSolved.start
                                            ringFlipped = effectiveFlipped
                                            prevRingAngleDeg = Math.toDegrees(atan2(dyRing.toDouble(), dxRing.toDouble())).toFloat()
                                            firstDown.consume()
                                            break
                                        }
                                    }
                                }

                                // Priority 1B: Tap any active unlocked limb/head joint pivot (or bone tip) to select ONLY that single bone.
                                // Structurally fixed core bones (Pelvis, Waist, Chest, Shoulders, Hips) are excluded unless Unlock Core is ON.
                                val unlockedBones = solved.filterNot { sb ->
                                    sb.bone.locked ||
                                        RigSolver.isBoneStructurallyFixed(rig, sb.bone) ||
                                        (!rig.unlockCoreBones && sb.bone.id == "neck_base")
                                }
                                val nearestPivotBone = unlockedBones.minByOrNull { hypot(it.start.x - rigStartStage.x, it.start.y - rigStartStage.y) }
                                val pivotDist = nearestPivotBone?.let { hypot(it.start.x - rigStartStage.x, it.start.y - rigStartStage.y) } ?: Float.MAX_VALUE
                                val nearestTipBone = unlockedBones.minByOrNull { hypot(it.end.x - rigStartStage.x, it.end.y - rigStartStage.y) }
                                val tipDist = nearestTipBone?.let { hypot(it.end.x - rigStartStage.x, it.end.y - rigStartStage.y) } ?: Float.MAX_VALUE

                                val pickPivot = nearestPivotBone != null && pivotDist < rigTouchRadius * 0.72f && pivotDist <= tipDist * 0.9f
                                val pickedBone = if (pickPivot) nearestPivotBone else nearestTipBone
                                val pickedDist = if (pickPivot) pivotDist else tipDist

                                if (pickedBone != null && pickedDist < rigTouchRadius && (distRoot > rigTouchRadius * 0.42f || pickedDist <= distRoot)) {
                                    if (st0.selectedLayerId != rigLayer.id) latestSelectLayer(rigLayer.id)
                                    // Select ONLY this single bone; its Prisma 3D rotation ring appears immediately!
                                    latestSelectBone(pickedBone.bone.id)
                                    // If tapped on the bone tip (not pivot center), allow immediate strict-FK drag;
                                    // if tapped right on the joint pivot dot, just select so the user can smoothly rotate via the ring.
                                    if (!pickPivot) {
                                        draggingBoneId = pickedBone.bone.id
                                        magnifierStagePt = rigStartStage
                                        latestDragBone(pickedBone.bone.id, rigStartStage, true)
                                    }
                                    firstDown.consume()
                                    break
                                }
                                if (distRoot < rigTouchRadius) {
                                    if (st0.selectedLayerId != rigLayer.id) latestSelectLayer(rigLayer.id)
                                    draggingPuppetRoot = true
                                    magnifierStagePt = rigStartStage
                                    break
                                }
                            }
                        }

                        // PRIORITY 1 (SELECT): Check Bounding Box Top 360° Rotation + 4 Corner Resize + 4 Edge X/Y Squash-Stretch Handles,
                        // and allow 1-tap selection of ANY visible rigged or un-rigged layer on the stage!
                        var hitGizmoHandle = false
                        if (!rotatingPropRing && tool == EditorTool.SELECT && activeSc != null) {
                            var selLayer = st0.selectedLayer
                            if (selLayer != null && InterpolationEngine.isLayerVisibleAtFrame(selLayer, st0.currentFrame)) {
                                val selStage = toStageWorld(startPos, selLayer.parallaxDepth)
                                val bounds = SceneRenderer.computeLayerBounds(selLayer, st0.currentFrame, activeSc.durationFrames, curProjW, curProjH)
                                if (bounds != null) {
                                    boundsCenterX = bounds.centerX()
                                    boundsCenterY = bounds.centerY()
                                    val rotHandleX = bounds.centerX()
                                    val rotHandleY = bounds.top - 52f
                                    val corners = listOf(
                                        bounds.left to bounds.top,
                                        bounds.right to bounds.top,
                                        bounds.left to bounds.bottom,
                                        bounds.right to bounds.bottom
                                    )
                                    val edgeX = listOf(
                                        bounds.left to bounds.centerY(),
                                        bounds.right to bounds.centerY()
                                    )
                                    val edgeY = listOf(
                                        bounds.centerX() to bounds.top,
                                        bounds.centerX() to bounds.bottom
                                    )
                                    when {
                                        hypot(selStage.x - rotHandleX, selStage.y - rotHandleY) < gizmoTouchRadius -> {
                                            handleMode = SelectionHandleMode.ROTATE
                                            hitGizmoHandle = true
                                        }
                                        corners.any { (cx, cy) -> hypot(selStage.x - cx, selStage.y - cy) < gizmoTouchRadius } -> {
                                            handleMode = SelectionHandleMode.RESIZE_CORNER
                                            hitGizmoHandle = true
                                        }
                                        edgeX.any { (ex, ey) -> hypot(selStage.x - ex, selStage.y - ey) < gizmoTouchRadius * 0.88f } -> {
                                            handleMode = SelectionHandleMode.RESIZE_EDGE_X
                                            hitGizmoHandle = true
                                        }
                                        edgeY.any { (ex, ey) -> hypot(selStage.x - ex, selStage.y - ey) < gizmoTouchRadius * 0.88f } -> {
                                            handleMode = SelectionHandleMode.RESIZE_EDGE_Y
                                            hitGizmoHandle = true
                                        }
                                    }
                                    // If finger did NOT hit a gizmo handle or inside the selected layer, hit-test other layers top-to-bottom!
                                    val insideSelected = bounds.contains(selStage.x, selStage.y)
                                    if (!hitGizmoHandle && !insideSelected) {
                                        val tappedOther = activeSc.layers.reversed().firstOrNull { candidate ->
                                            candidate.id != selLayer.id &&
                                                !candidate.locked &&
                                                InterpolationEngine.isLayerVisibleAtFrame(candidate, st0.currentFrame) &&
                                                SceneRenderer.computeLayerBounds(candidate, st0.currentFrame, activeSc.durationFrames, curProjW, curProjH)
                                                    ?.contains(
                                                        toStageWorld(startPos, candidate.parallaxDepth).x,
                                                        toStageWorld(startPos, candidate.parallaxDepth).y
                                                    ) == true
                                        }
                                        if (tappedOther != null) {
                                            latestSelectLayer(tappedOther.id)
                                            SceneRenderer.computeLayerBounds(tappedOther, st0.currentFrame, activeSc.durationFrames, curProjW, curProjH)?.let { b ->
                                                boundsCenterX = b.centerX()
                                                boundsCenterY = b.centerY()
                                            }
                                        }
                                    }
                                }
                            } else {
                                // No currently visible layer selected — pick topmost visible layer under tap!
                                val tapped = activeSc.layers.reversed().firstOrNull { candidate ->
                                    !candidate.locked &&
                                        InterpolationEngine.isLayerVisibleAtFrame(candidate, st0.currentFrame) &&
                                        SceneRenderer.computeLayerBounds(candidate, st0.currentFrame, activeSc.durationFrames, curProjW, curProjH)
                                            ?.contains(
                                                toStageWorld(startPos, candidate.parallaxDepth).x,
                                                toStageWorld(startPos, candidate.parallaxDepth).y
                                            ) == true
                                }
                                if (tapped != null) {
                                    latestSelectLayer(tapped.id)
                                }
                            }
                        }

                        // PRIORITY 2: Hit-test Animated Text on stage in SELECT, TEXT, or RIG_EDIT modes (when not grabbing a rig or gizmo handle)
                        val canInteractWithText = !draggingPuppetRoot && draggingBoneId == null && !hitGizmoHandle &&
                            (tool == EditorTool.TEXT || tool == EditorTool.SELECT || tool == EditorTool.RIG_EDIT)
                        if (canInteractWithText && activeSc != null && activeSc.animatedTexts.isNotEmpty()) {
                            val hitText = activeSc.animatedTexts.reversed().firstOrNull { item ->
                                st0.currentFrame in item.startFrame..item.endFrame &&
                                    SceneRenderer.computeTextBounds(item).contains(startScreen.x, startScreen.y)
                            }
                            if (hitText != null) {
                                draggingTextId = hitText.id
                                draggingTextOffsetX = hitText.x - startScreen.x
                                draggingTextOffsetY = hitText.y - startScreen.y
                                latestSelectText(hitText.id)
                            } else if (tool == EditorTool.SELECT && st0.selectedTextId != null) {
                                latestSelectText(null)
                            }
                        }

                        // Prepare drawing / shape / selection translate if not dragging text, puppet, or gizmo handle
                        if (draggingTextId == null && !draggingPuppetRoot && draggingBoneId == null && !hitGizmoHandle) {
                            when (tool) {
                                EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                    activeStroke = DrawStroke(
                                        tool = tool.name,
                                        points = listOf(startLayerPt),
                                        colorArgb = if (tool == EditorTool.ERASER) 0xFFFB7185L else st0.primaryColorArgb,
                                        gradientEndArgb = if (st0.useGradient && tool != EditorTool.ERASER) st0.gradientColorArgb else null,
                                        strokeWidth = st0.brushSize,
                                        opacity = st0.brushOpacity
                                    )
                                }
                                EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                    val kind = when (tool) {
                                        EditorTool.LINE -> ShapeKind.LINE
                                        EditorTool.RECTANGLE -> ShapeKind.RECTANGLE
                                        EditorTool.CIRCLE -> ShapeKind.CIRCLE
                                        else -> ShapeKind.POLYGON
                                    }
                                    activeShape = VectorShape(
                                        kind = kind.name,
                                        startX = startLayerPt.x,
                                        startY = startLayerPt.y,
                                        endX = startLayerPt.x,
                                        endY = startLayerPt.y,
                                        polygonSides = st0.polygonSides,
                                        strokeColorArgb = st0.primaryColorArgb,
                                        fillColorArgb = if (st0.fillShapes && kind != ShapeKind.LINE) st0.primaryColorArgb else null,
                                        gradientEndArgb = if (st0.useGradient) st0.gradientColorArgb else null,
                                        strokeWidth = st0.brushSize.coerceAtLeast(2f),
                                        opacity = st0.brushOpacity
                                    )
                                }
                                EditorTool.SELECT -> {
                                    handleMode = SelectionHandleMode.TRANSLATE
                                }
                                EditorTool.MOTION_PATH -> {
                                    activeMotionPathDraft = listOf(startStage)
                                }
                                else -> Unit
                            }
                        }

                        while (true) {
                            val event = awaitPointerEvent()
                            val activePointers = event.changes.filter { it.pressed }
                            if (activePointers.isEmpty()) {
                                // Capture final release position so strokes & shapes finish cleanly under the fingertip
                                if (!isMultiTouch) {
                                    event.changes.firstOrNull()?.let { upChange ->
                                        val upLayerPt = toLayerLocal(upChange.position, latestState.selectedLayer)
                                        lastLayerPt = upLayerPt
                                        activeStroke = activeStroke?.let { s ->
                                            val prev = s.points.lastOrNull()
                                            if (prev == null || hypot(upLayerPt.x - prev.x, upLayerPt.y - prev.y) >= 1.2f) {
                                                s.copy(points = s.points + upLayerPt)
                                            } else s
                                        }
                                        activeShape = activeShape?.copy(endX = upLayerPt.x, endY = upLayerPt.y)
                                    }
                                }
                                break
                            }

                            // Seamless 2-finger pinch-to-zoom & pan
                            if (activePointers.size >= 2) {
                                if (!isMultiTouch) {
                                    isMultiTouch = true
                                    activeStroke = null
                                    activeShape = null
                                    activeMotionPathDraft = null
                                    draggingTextId = null
                                    draggingBoneId = null
                                    rotatingRingBoneId = null
                                    rotatingPropRing = false
                                    draggingPuppetRoot = false
                                    handleMode = SelectionHandleMode.NONE
                                }
                                val zoomChange = event.calculateZoom()
                                val panChange = event.calculatePan()
                                if (zoomChange != 1f || panChange != Offset.Zero) {
                                    val cur = latestState
                                    latestUpdateViewport(
                                        (cur.canvasZoom * zoomChange).coerceIn(0.4f, 4.5f),
                                        cur.canvasPanX + panChange.x,
                                        cur.canvasPanY + panChange.y
                                    )
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                                continue
                            }

                            if (isMultiTouch) continue

                            val change = activePointers.first()
                            val pos = change.position
                            val delta = pos - lastPos
                            if (hypot(pos.x - startPos.x, pos.y - startPos.y) > 4f) {
                                hasDragged = true
                            }
                            lastPos = pos
                            val curSelLayer = latestState.selectedLayer
                            val pt = toStageWorld(pos, curSelLayer?.parallaxDepth ?: 1f)
                            val layerPt = toLayerLocal(pos, curSelLayer)
                            val scrPt = toStageScreen(pos)

                            when {
                                draggingTextId != null -> {
                                    val firstMove = !textUndoRecorded
                                    textUndoRecorded = true
                                    latestMoveText(
                                        draggingTextId,
                                        (scrPt.x + draggingTextOffsetX).coerceIn(20f, curProjW - 20f),
                                        (scrPt.y + draggingTextOffsetY).coerceIn(20f, curProjH - 20f),
                                        firstMove
                                    )
                                    change.consume()
                                }
                                draggingPuppetRoot -> {
                                    val firstMove = !puppetUndoRecorded
                                    puppetUndoRecorded = true
                                    magnifierStagePt = pt
                                    latestMovePuppetRoot(pt.x, pt.y, firstMove)
                                    change.consume()
                                }
                                rotatingPropRing -> {
                                    val curAngleDeg = Math.toDegrees(
                                        atan2((pt.y - propRingPivot.y).toDouble(), (pt.x - propRingPivot.x).toDouble())
                                    ).toFloat()
                                    var rawDeltaDeg = curAngleDeg - prevPropRingAngleDeg
                                    while (rawDeltaDeg > 180f) rawDeltaDeg -= 360f
                                    while (rawDeltaDeg < -180f) rawDeltaDeg += 360f
                                    prevPropRingAngleDeg = curAngleDeg
                                    if (kotlin.math.abs(rawDeltaDeg) > 0.05f) {
                                        val firstMove = !propRingUndoRecorded
                                        propRingUndoRecorded = true
                                        latestRotatePropDelta(rawDeltaDeg, firstMove)
                                    }
                                    change.consume()
                                }
                                rotatingRingBoneId != null -> {
                                    val curAngleDeg = Math.toDegrees(
                                        atan2((pt.y - ringPivot.y).toDouble(), (pt.x - ringPivot.x).toDouble())
                                    ).toFloat()
                                    var rawDeltaDeg = curAngleDeg - prevRingAngleDeg
                                    while (rawDeltaDeg > 180f) rawDeltaDeg -= 360f
                                    while (rawDeltaDeg < -180f) rawDeltaDeg += 360f
                                    prevRingAngleDeg = curAngleDeg
                                    // Negate delta when horizontally mirrored so clockwise finger drag always rotates clockwise on screen
                                    val signedDelta = if (ringFlipped) -rawDeltaDeg else rawDeltaDeg
                                    if (kotlin.math.abs(signedDelta) > 0.05f) {
                                        val firstMove = !ringUndoRecorded
                                        ringUndoRecorded = true
                                        latestRotateBoneDelta(rotatingRingBoneId, signedDelta, firstMove)
                                    }
                                    change.consume()
                                }
                                draggingBoneId != null -> {
                                    magnifierStagePt = pt
                                    latestDragBone(draggingBoneId, pt, false)
                                    change.consume()
                                }
                                tool in listOf(
                                    EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH,
                                    EditorTool.ERASER, EditorTool.PEN_BEZIER
                                ) -> {
                                    activeStroke = activeStroke?.let { s ->
                                        val prev = s.points.lastOrNull()
                                        if (prev == null || hypot(layerPt.x - prev.x, layerPt.y - prev.y) >= 1.2f) {
                                            s.copy(points = s.points + layerPt)
                                        } else s
                                    }
                                    change.consume()
                                }
                                tool in listOf(
                                    EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON
                                ) -> {
                                    activeShape = activeShape?.copy(endX = layerPt.x, endY = layerPt.y)
                                    change.consume()
                                }
                                tool == EditorTool.MOTION_PATH -> {
                                    activeMotionPathDraft = activeMotionPathDraft?.let { pts ->
                                        val prev = pts.lastOrNull()
                                        if (prev == null || hypot(pt.x - prev.x, pt.y - prev.y) >= 22f) {
                                            pts + pt
                                        } else pts
                                    } ?: listOf(startStage, pt)
                                    change.consume()
                                }
                                tool == EditorTool.HAND_PAN -> {
                                    if (delta != Offset.Zero) {
                                        val cur = latestState
                                        latestUpdateViewport(
                                            cur.canvasZoom,
                                            cur.canvasPanX + delta.x,
                                            cur.canvasPanY + delta.y
                                        )
                                        change.consume()
                                    }
                                }
                                tool == EditorTool.SELECT -> {
                                    if (delta != Offset.Zero) {
                                        val firstMove = !selectUndoRecorded
                                        selectUndoRecorded = true
                                        when (handleMode) {
                                            SelectionHandleMode.ROTATE -> {
                                                val prevAng = Math.toDegrees(
                                                    atan2((lastStage.y - boundsCenterY).toDouble(), (lastStage.x - boundsCenterX).toDouble())
                                                ).toFloat()
                                                val curAng = Math.toDegrees(
                                                    atan2((pt.y - boundsCenterY).toDouble(), (pt.x - boundsCenterX).toDouble())
                                                ).toFloat()
                                                var dRot = curAng - prevAng
                                                if (dRot > 180f) dRot -= 360f
                                                if (dRot < -180f) dRot += 360f
                                                latestDirectTransform(0f, 0f, 1f, dRot, firstMove)
                                            }
                                            SelectionHandleMode.RESIZE_CORNER -> {
                                                val prevDist = hypot(lastStage.x - boundsCenterX, lastStage.y - boundsCenterY).coerceAtLeast(12f)
                                                val curDist = hypot(pt.x - boundsCenterX, pt.y - boundsCenterY).coerceAtLeast(12f)
                                                val factor = (curDist / prevDist).coerceIn(0.65f, 1.55f)
                                                latestDirectTransform(0f, 0f, factor, 0f, firstMove)
                                            }
                                            SelectionHandleMode.RESIZE_EDGE_X -> {
                                                val prevDx = kotlin.math.abs(lastStage.x - boundsCenterX).coerceAtLeast(12f)
                                                val curDx = kotlin.math.abs(pt.x - boundsCenterX).coerceAtLeast(12f)
                                                val factorX = (curDx / prevDx).coerceIn(0.65f, 1.55f)
                                                val xyCb = latestDirectTransformXY
                                                if (xyCb != null) {
                                                    xyCb(0f, 0f, 1f, factorX, 1f, 0f, firstMove)
                                                } else {
                                                    latestDirectTransform(0f, 0f, factorX, 0f, firstMove)
                                                }
                                            }
                                            SelectionHandleMode.RESIZE_EDGE_Y -> {
                                                val prevDy = kotlin.math.abs(lastStage.y - boundsCenterY).coerceAtLeast(12f)
                                                val curDy = kotlin.math.abs(pt.y - boundsCenterY).coerceAtLeast(12f)
                                                val factorY = (curDy / prevDy).coerceIn(0.65f, 1.55f)
                                                val xyCb = latestDirectTransformXY
                                                if (xyCb != null) {
                                                    xyCb(0f, 0f, 1f, 1f, factorY, 0f, firstMove)
                                                } else {
                                                    latestDirectTransform(0f, 0f, factorY, 0f, firstMove)
                                                }
                                            }
                                            else -> {
                                                latestDirectTransform(
                                                    delta.x / latestTotalScale,
                                                    delta.y / latestTotalScale,
                                                    1f,
                                                    0f,
                                                    firstMove
                                                )
                                            }
                                        }
                                        change.consume()
                                    }
                                }
                            }
                            lastStage = pt
                            lastLayerPt = layerPt
                        }

                        // Gesture ended: commit stroke/shape/motion path or trigger tap-based tools
                        if (!isMultiTouch && draggingTextId == null && !draggingPuppetRoot && draggingBoneId == null) {
                            when (tool) {
                                EditorTool.PENCIL, EditorTool.BRUSH, EditorTool.AIRBRUSH, EditorTool.ERASER, EditorTool.PEN_BEZIER -> {
                                    activeStroke?.let { if (it.points.isNotEmpty()) latestCommitStroke(it) }
                                }
                                EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.CIRCLE, EditorTool.POLYGON -> {
                                    activeShape?.let { shape ->
                                        val dist = hypot(shape.endX - shape.startX, shape.endY - shape.startY)
                                        val finalShape = if (dist < 6f) {
                                            shape.copy(endX = shape.startX + 120f, endY = shape.startY + 90f)
                                        } else shape
                                        latestCommitShape(finalShape)
                                    }
                                }
                                EditorTool.BUCKET -> if (!hasDragged) latestPaintBucket(startLayerPt.x, startLayerPt.y)
                                EditorTool.EYEDROPPER -> if (!hasDragged) latestPickColor(startScreen.x, startScreen.y)
                                EditorTool.TEXT -> if (!hasDragged) {
                                    textDraft = ""
                                    draftInAnim = TextInAnimation.POP_BOUNCE
                                    draftLoopAnim = TextLoopAnimation.NONE
                                    pendingTextPos = startScreen
                                }
                                EditorTool.MOTION_PATH -> {
                                    val draft = activeMotionPathDraft
                                    if (hasDragged && draft != null && draft.size >= 2) {
                                        val finalPts = if (hypot(lastStage.x - draft.last().x, lastStage.y - draft.last().y) > 8f) {
                                            draft + lastStage
                                        } else draft
                                        latestSetMotionPath(finalPts)
                                    } else {
                                        latestAddMotionPath(startStage)
                                    }
                                }
                                else -> Unit
                            }
                        }
                        activeStroke = null
                        activeShape = null
                        activeMotionPathDraft = null
                        magnifierStagePt = null
                    }
                }
        ) {
            drawIntoCanvas { composeCanvas ->
                val nc = composeCanvas.nativeCanvas
                nc.save()
                nc.translate(originX, originY)
                nc.scale(totalScale, totalScale)
                nc.clipRect(0f, 0f, projW, projH)

                SceneRenderer.renderScene(
                    canvas = nc,
                    scene = scene,
                    frame = uiState.currentFrame,
                    projectWidth = projW,
                    projectHeight = projH,
                    fps = project.fps,
                    audioTracks = project.audioTracks,
                    onionSkin = uiState.onionSkinEnabled && !uiState.isPlaying,
                    ghostFrames = uiState.ghostFramesEnabled && !uiState.isPlaying,
                    celOnionNext = uiState.celOnionNextEnabled && !uiState.isPlaying,
                    celOnionOpacity = uiState.celOnionOpacity,
                    showRigBones = uiState.showRigOverlay && !uiState.isPlaying && !isCelStudioMode,
                    showMotionPaths = uiState.showMotionPaths && !uiState.isPlaying && !isCelStudioMode,
                    showSelectionBox = uiState.activeTool == EditorTool.SELECT && !uiState.isPlaying && !isCelStudioMode,
                    showCameraFrame = (uiState.showCameraFrame || uiState.showCameraHud) && !uiState.isPlaying && !isCelStudioMode,
                    selectedLayerId = uiState.selectedLayer?.id,
                    selectedBoneId = uiState.selectedBoneId,
                    selectedTextId = if (!uiState.isPlaying && !isCelStudioMode) uiState.selectedTextId else null,
                    propRotateMode = uiState.propRotateMode && !uiState.isPlaying && !isCelStudioMode,
                    activePreviewStroke = activeStroke,
                    activePreviewShape = activeShape,
                    activePreviewMotionPath = activeMotionPathDraft
                )
                nc.restore()
            }

            // Stage Frame Border
            drawRect(
                color = if (uiState.isPlaying) StudioCoral else if (uiState.activeTool == EditorTool.SELECT) StudioCyan else StudioBorder,
                topLeft = Offset(originX, originY),
                size = Size(stageW, stageH),
                style = Stroke(width = 2.5f)
            )
        }

        // Top-Left Stage HUD Badge + Top-Right Quick "Import Character" Button
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = StudioSurface.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudioBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = uiState.activeTool.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioCoral,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• ${uiState.selectedLayer?.name ?: "No Layer"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudioTextSecondary
                        )
                    }
                }

                // Prominent on-stage "+ Character" button for Multi-Character Importing (hidden in Cel Studio)
                if (!uiState.isPlaying && !isCelStudioMode) {
                    Surface(
                        color = StudioViolet.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenImportCharacter)
                            .testTag("stage_import_character_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.AccessibilityNew,
                                contentDescription = "Import Character",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                "+ Character",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Prominent on-stage "+ Text" button for Kinetic Animated Text
                    Surface(
                        color = StudioAmber.copy(alpha = 0.94f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenTextStudio)
                            .testTag("stage_add_text_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Title,
                                contentDescription = "Add Animated Text",
                                tint = Color(0xFF0F172A),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                "+ Text",
                                color = Color(0xFF0F172A),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Module 5: On-Stage Face & Mood Swapper Dock button when a rigged character is selected
                    if (selectedRig != null) {
                        Surface(
                            color = if (uiState.showFaceMoodDock) StudioCoral else Color(0xFF1D283A),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (uiState.showFaceMoodDock) StudioCoral else StudioCyan.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onToggleFaceMoodDock)
                                .testTag("stage_face_mood_dock_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Default.Mood,
                                    contentDescription = "Face & Mood Dock",
                                    tint = if (uiState.showFaceMoodDock) Color.White else StudioCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    "Face/Mood",
                                    color = if (uiState.showFaceMoodDock) Color.White else StudioCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // On-Stage Camera Director HUD toggle pill
                    Surface(
                        color = if (uiState.showCameraHud) StudioAmber else StudioSurface.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (uiState.showCameraHud) StudioAmber else StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onToggleCameraHud)
                            .testTag("stage_camera_hud_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Videocam,
                                contentDescription = "Camera Director HUD",
                                tint = if (uiState.showCameraHud) Color(0xFF0F172A) else StudioAmber,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                "Cam",
                                color = if (uiState.showCameraHud) Color(0xFF0F172A) else StudioAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Single Clean Toggle Button to Hide/Reveal ALL Character Behavior Controls
                    if (selectedRig != null && selectedPuppetRoot != null) {
                        val expanded = uiState.characterActionsExpanded
                        Surface(
                            color = if (expanded) StudioViolet else StudioSurface.copy(alpha = 0.92f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (expanded) StudioViolet else StudioViolet.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onToggleCharacterActions)
                                .testTag("stage_character_actions_toggle")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    Icons.Default.Face,
                                    contentDescription = "Toggle Character Behaviors",
                                    tint = if (expanded) Color.White else StudioViolet,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    "Actions",
                                    color = if (expanded) Color.White else StudioViolet,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = if (expanded) "Hide Character Actions" else "Show Character Actions",
                                    tint = if (expanded) Color.White else StudioViolet,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        // Prominent "Stretch Rig" Toggle Pill (Module 2)
                        Surface(
                            color = if (uiState.stretchRigMode) StudioCoral else StudioSurface.copy(alpha = 0.92f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (uiState.stretchRigMode) StudioCoral else StudioCoral.copy(alpha = 0.65f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onToggleStretchRig)
                                .testTag("stage_stretch_rig_toggle")
                        ) {
                            Text(
                                text = if (uiState.stretchRigMode) "Stretch ON" else "Stretch Rig",
                                color = if (uiState.stretchRigMode) Color.White else StudioCoral,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                            )
                        }

                        // Live Record Acting Pad Toggle Pill (Module 8)
                        Surface(
                            color = if (uiState.liveRecordMode) Color(0xFFDC2626) else StudioSurface.copy(alpha = 0.92f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (uiState.liveRecordMode) Color(0xFFEF4444) else StudioBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onToggleLiveRecord)
                                .testTag("stage_live_record_toggle")
                        ) {
                            Text(
                                text = if (uiState.liveRecordMode) "● Live Rec" else "Live Rec",
                                color = if (uiState.liveRecordMode) Color.White else StudioTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            // Smooth Motion Path Quick Bar when MOTION_PATH tool is active
            if (uiState.activeTool == EditorTool.MOTION_PATH && selectedLayer != null && !uiState.isPlaying) {
                val ptsCount = selectedLayer.motionPath.size
                val curEase = runCatching { com.example.data.model.EasingType.valueOf(selectedLayer.motionPathEasing) }
                    .getOrDefault(com.example.data.model.EasingType.EASE_IN_OUT)
                Surface(
                    color = StudioSurface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.75f)),
                    modifier = Modifier.testTag("motion_path_hud")
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(Icons.Default.Timeline, contentDescription = null, tint = StudioCoral, modifier = Modifier.size(15.dp))
                        Text(
                            if (ptsCount >= 2) "Path ($ptsCount pts)" else "Draw or Tap Path",
                            color = StudioTextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        PuppetQuickPill(
                            label = if (selectedLayer.motionPathOrientToPath) "Orient ON" else "Orient",
                            icon = Icons.Default.Explore,
                            active = selectedLayer.motionPathOrientToPath,
                            accent = StudioCyan,
                            tag = "path_toggle_orient_btn",
                            onClick = onToggleMotionPathOrient
                        )
                        PuppetQuickPill(
                            label = curEase.displayName,
                            icon = Icons.Default.Speed,
                            active = true,
                            accent = StudioAmber,
                            tag = "path_cycle_easing_btn",
                            onClick = onCycleMotionPathEasing
                        )
                        if (ptsCount >= 2) {
                            PuppetQuickPill(
                                label = "Reverse",
                                icon = Icons.Default.SwapHoriz,
                                active = false,
                                accent = StudioViolet,
                                tag = "path_reverse_btn",
                                onClick = onReverseMotionPath
                            )
                        }
                        if (ptsCount >= 1) {
                            PuppetQuickPill(
                                label = "Undo Pt",
                                icon = Icons.AutoMirrored.Filled.Undo,
                                active = false,
                                accent = StudioEmerald,
                                tag = "path_undo_pt_btn",
                                onClick = onUndoMotionPathPoint
                            )
                            PuppetQuickPill(
                                label = "Clear",
                                icon = Icons.Default.Delete,
                                active = false,
                                accent = StudioCoral,
                                tag = "path_clear_btn",
                                onClick = onClearMotionPath
                            )
                        }
                    }
                }
            }

            // Select Tool Fine Rotation (360°) & Free Scale (0.1x..10.0x) Quick Bar
            val selLayerForTransform = uiState.selectedLayer
            if (uiState.activeTool == EditorTool.SELECT && selLayerForTransform != null && uiState.selectedText == null && !uiState.isPlaying) {
                val evalTf = InterpolationEngine.evaluateLayerTransform(selLayerForTransform, uiState.currentFrame, scene.durationFrames)
                val normalizedRot = (((evalTf.rotationDeg % 360f) + 540f) % 360f) - 180f
                Surface(
                    color = StudioSurface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.7f)),
                    modifier = Modifier.testTag("select_transform_hud")
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "Rot ${normalizedRot.toInt()}°",
                            color = StudioCoral,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Slider(
                            value = normalizedRot.coerceIn(-180f, 180f),
                            onValueChange = { deg -> onSetAbsoluteTransform(deg, null, false) },
                            valueRange = -180f..180f,
                            colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                            modifier = Modifier.width(108.dp).testTag("select_rotation_slider")
                        )
                        Text(
                            "Scale ${String.format(Locale.US, "%.2fx", evalTf.scaleX)}",
                            color = StudioCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Slider(
                            value = evalTf.scaleX.coerceIn(0.1f, 10.0f),
                            onValueChange = { sc -> onSetAbsoluteTransform(null, sc, false) },
                            valueRange = 0.1f..10.0f,
                            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                            modifier = Modifier.width(108.dp).testTag("select_scale_slider")
                        )
                        Surface(
                            color = Color(0xFF212838),
                            shape = RoundedCornerShape(7.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(7.dp))
                                .clickable { onSetAbsoluteTransform(null, null, true) }
                                .testTag("select_reset_transform_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(Icons.Default.RestartAlt, contentDescription = "Reset transform", tint = StudioAmber, modifier = Modifier.size(13.dp))
                                Text("Reset", color = StudioAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Floating Animated Text Quick Action Bar whenever a Text Item is selected!
            val selText = uiState.selectedText
            if (selText != null && !uiState.isPlaying) {
                val inEntries = TextInAnimation.entries
                val curIn = runCatching { TextInAnimation.valueOf(selText.inAnimation) }.getOrDefault(TextInAnimation.POP_BOUNCE)
                val nextIn = inEntries[(inEntries.indexOf(curIn) + 1) % inEntries.size]

                val loopEntries = TextLoopAnimation.entries
                val curLoop = runCatching { TextLoopAnimation.valueOf(selText.loopAnimation) }.getOrDefault(TextLoopAnimation.NONE)
                val nextLoop = loopEntries[(loopEntries.indexOf(curLoop) + 1) % loopEntries.size]

                Surface(
                    color = StudioSurface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.65f))
                ) {
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        PuppetQuickPill(
                            label = "Edit Text",
                            icon = Icons.Default.Edit,
                            active = true,
                            accent = StudioAmber,
                            tag = "text_bar_edit_btn",
                            onClick = {
                                textDraft = selText.text
                                editingTextId = selText.id
                            }
                        )
                        PuppetQuickPill(
                            label = "In: ${curIn.label}",
                            icon = Icons.Default.AutoAwesome,
                            active = curIn != TextInAnimation.NONE,
                            accent = StudioCoral,
                            tag = "text_bar_in_anim_btn",
                            onClick = { onUpdateText(selText.id, true) { it.copy(inAnimation = nextIn.name) } }
                        )
                        PuppetQuickPill(
                            label = "Loop: ${curLoop.label}",
                            icon = Icons.Default.AutoAwesome,
                            active = curLoop != TextLoopAnimation.NONE,
                            accent = StudioViolet,
                            tag = "text_bar_loop_anim_btn",
                            onClick = { onUpdateText(selText.id, true) { it.copy(loopAnimation = nextLoop.name) } }
                        )
                        PuppetQuickPill(
                            label = "Style",
                            icon = Icons.Default.Tune,
                            active = true,
                            accent = StudioCyan,
                            tag = "text_bar_style_btn",
                            onClick = onOpenTextStudio
                        )
                        PuppetQuickPill(
                            label = "Copy",
                            icon = Icons.Default.ContentCopy,
                            active = false,
                            accent = StudioEmerald,
                            tag = "text_bar_duplicate_btn",
                            onClick = { onDuplicateText(selText.id) }
                        )
                        PuppetQuickPill(
                            label = "Delete",
                            icon = Icons.Default.Delete,
                            active = false,
                            accent = StudioCoral,
                            tag = "text_bar_delete_btn",
                            onClick = { onDeleteText(selText.id) }
                        )
                    }
                }
            }

            // Single-Button Collapsible Character Behavior Bar (hidden by default for a clean stage preview!)
            AnimatedVisibility(
                visible = uiState.characterActionsExpanded && selText == null && selectedRig != null && selectedPuppetRoot != null && !uiState.isPlaying,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                if (selectedRig != null && selectedPuppetRoot != null) {
                    val eyeEntries = EyePackStyle.entries
                    val curEye = runCatching { EyePackStyle.valueOf(selectedPuppetRoot.eyePack) }.getOrDefault(EyePackStyle.AUTO_BLINK)
                    val nextEye = eyeEntries[(eyeEntries.indexOf(curEye) + 1) % eyeEntries.size]

                    val mouthEntries = MouthPhoneme.entries
                    val curMouth = runCatching { MouthPhoneme.valueOf(selectedPuppetRoot.mouthPhoneme) }.getOrDefault(MouthPhoneme.AUTO_LIPSYNC)
                    val nextMouth = mouthEntries[(mouthEntries.indexOf(curMouth) + 1) % mouthEntries.size]

                    Surface(
                        color = StudioSurface.copy(alpha = 0.94f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, StudioViolet.copy(alpha = 0.65f)),
                        modifier = Modifier.testTag("character_behaviors_expanded_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            val curView = runCatching { CharacterViewAngle.valueOf(selectedPuppetRoot.viewAngle) }
                                .getOrDefault(CharacterViewAngle.FRONT)
                            val curRightProp = runCatching { HandPropKind.valueOf(selectedRig.rightHandProp) }
                                .getOrDefault(HandPropKind.NONE)
                            val rightPropLabel = if (!selectedRig.rightHandCustomImagePath.isNullOrBlank()) "PNG" else curRightProp.label

                            PuppetQuickPill(
                                label = "View: ${curView.label}",
                                icon = Icons.Default.AccessibilityNew,
                                active = curView != CharacterViewAngle.FRONT,
                                accent = StudioAmber,
                                tag = "puppet_cycle_view_btn",
                                onClick = onCyclePuppetViewAngle
                            )
                            PuppetQuickPill(
                                label = "Hand: $rightPropLabel",
                                icon = Icons.Default.AutoAwesome,
                                active = curRightProp != HandPropKind.NONE || !selectedRig.rightHandCustomImagePath.isNullOrBlank(),
                                accent = StudioCoral,
                                tag = "puppet_cycle_hand_prop_btn",
                                onClick = { onCyclePuppetHandProp(true) }
                            )
                            PuppetQuickPill(
                                label = "+Extra Rig",
                                icon = Icons.Default.AddCircleOutline,
                                active = selectedRig.bones.any { it.isExtraRigBone },
                                accent = StudioEmerald,
                                tag = "puppet_extra_rig_shortcut_btn",
                                onClick = onOpenExtraRigPanel
                            )
                            PuppetQuickPill(
                                label = if (selectedPuppetRoot.flippedHorizontal) "Flip L" else "Flip R",
                                icon = Icons.Default.Flip,
                                active = selectedPuppetRoot.flippedHorizontal,
                                accent = StudioCyan,
                                tag = "puppet_flip_h_btn",
                                onClick = onTogglePuppetFlip
                            )
                            val isGhostMode = (uiState.selectedLayer?.opacity ?: 1f) < 0.85f
                            PuppetQuickPill(
                                label = "Auto-Walk",
                                icon = Icons.AutoMirrored.Filled.DirectionsWalk,
                                active = selectedRig.autoWalkWhenDragged,
                                accent = StudioEmerald,
                                tag = "puppet_autowalk_btn",
                                onClick = onTogglePuppetAutoWalk
                            )
                            PuppetQuickPill(
                                label = if (isGhostMode) "Ghost 55%" else "Ghost",
                                icon = Icons.Default.Visibility,
                                active = isGhostMode,
                                accent = Color(0xFF7DD3FC),
                                tag = "puppet_ghost_mode_btn",
                                onClick = onTogglePuppetGhostMode
                            )
                            PuppetQuickPill(
                                label = "Eyes: ${curEye.label}",
                                icon = Icons.Default.Visibility,
                                active = true,
                                accent = StudioViolet,
                                tag = "puppet_cycle_eyes_btn",
                                onClick = { onCyclePuppetEyePack(nextEye) }
                            )
                            PuppetQuickPill(
                                label = "Mouth: ${curMouth.label}",
                                icon = Icons.Default.Face,
                                active = true,
                                accent = StudioCoral,
                                tag = "puppet_cycle_mouth_btn",
                                onClick = { onCyclePuppetMouthPhoneme(nextMouth) }
                            )
                            listOf("IDLE", "WAVE", "WALK", "JUMP", "SIT").forEach { pose ->
                                Surface(
                                    color = Color(0xFF212838),
                                    shape = RoundedCornerShape(7.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(7.dp))
                                        .clickable { onApplyPuppetPose(pose) }
                                        .testTag("puppet_pose_${pose.lowercase()}")
                                ) {
                                    Text(
                                        text = pose,
                                        color = StudioAmber,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Top-Right Compact On-Stage Camera Motion Director HUD
        if (uiState.showCameraHud && !uiState.isPlaying) {
            val cam = InterpolationEngine.evaluateCamera(scene, uiState.currentFrame)
            Surface(
                color = StudioSurface.copy(alpha = 0.94f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, StudioAmber.copy(alpha = 0.8f)),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .width(214.dp)
                    .testTag("stage_camera_director_hud")
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.width(194.dp)
                    ) {
                        Text(
                            "CAMERA DIRECTOR (F${uiState.currentFrame + 1})",
                            color = StudioAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onToggleCameraHud, modifier = Modifier.size(22.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close Camera HUD", tint = StudioTextSecondary, modifier = Modifier.size(14.dp))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Zoom ${String.format(Locale.US, "%.2fx", cam.zoom)}", color = StudioTextPrimary, fontSize = 10.sp, modifier = Modifier.width(64.dp))
                        Slider(
                            value = cam.zoom.coerceIn(0.3f, 4.0f),
                            onValueChange = { z -> onUpdateCamera(cam.panX, cam.panY, z, cam.rotationDeg) },
                            valueRange = 0.3f..4.0f,
                            colors = SliderDefaults.colors(thumbColor = StudioAmber, activeTrackColor = StudioAmber),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pan X ${cam.panX.toInt()}", color = StudioTextPrimary, fontSize = 10.sp, modifier = Modifier.width(64.dp))
                        Slider(
                            value = cam.panX.coerceIn(-800f, 800f),
                            onValueChange = { px -> onUpdateCamera(px, cam.panY, cam.zoom, cam.rotationDeg) },
                            valueRange = -800f..800f,
                            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pan Y ${cam.panY.toInt()}", color = StudioTextPrimary, fontSize = 10.sp, modifier = Modifier.width(64.dp))
                        Slider(
                            value = cam.panY.coerceIn(-600f, 600f),
                            onValueChange = { py -> onUpdateCamera(cam.panX, py, cam.zoom, cam.rotationDeg) },
                            valueRange = -600f..600f,
                            colors = SliderDefaults.colors(thumbColor = StudioCyan, activeTrackColor = StudioCyan),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Tilt ${cam.rotationDeg.toInt()}°", color = StudioTextPrimary, fontSize = 10.sp, modifier = Modifier.width(64.dp))
                        Slider(
                            value = cam.rotationDeg.coerceIn(-180f, 180f),
                            onValueChange = { r -> onUpdateCamera(cam.panX, cam.panY, cam.zoom, r) },
                            valueRange = -180f..180f,
                            colors = SliderDefaults.colors(thumbColor = StudioCoral, activeTrackColor = StudioCoral),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "Dolly" to onCameraDollyZoom,
                            "Pan" to onCameraPanAcross,
                            "Shake" to onCameraShake,
                            "Reset" to onResetCamera
                        ).forEach { (label, action) ->
                            Surface(
                                color = Color(0xFF212838),
                                shape = RoundedCornerShape(7.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(7.dp))
                                    .clickable(onClick = action)
                            ) {
                                Text(
                                    label,
                                    color = StudioAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom-Center Live Record On-Stage Acting Pad (Module 8 — works even DURING playback!)
        if (uiState.liveRecordMode && selectedRig != null && !isCelStudioMode) {
            Surface(
                color = StudioSurface.copy(alpha = 0.95f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.5.dp, Color(0xFFEF4444)),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 8.dp, bottom = 8.dp, end = 160.dp)
                    .testTag("live_record_acting_pad")
            ) {
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "● LIVE F${uiState.currentFrame + 1}",
                        color = Color(0xFFEF4444),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    listOf(
                        "TALK" to "Talk",
                        "BLINK" to "Blink",
                        "LAUGH" to "Laugh",
                        "CRY" to "Cry",
                        "ANGRY" to "Angry",
                        "SHOCK" to "Shock",
                        "WAVE" to "Wave",
                        "NAMASTE" to "Namaste"
                    ).forEach { (key, label) ->
                        Surface(
                            color = Color(0xFF1F2937),
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, StudioCoral.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(9.dp))
                                .clickable { onRecordLivePad(key) }
                                .testTag("live_pad_${key.lowercase()}")
                        ) {
                            Text(
                                text = label,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
            }
        }

        // Bottom-Right Floating Zoom Controls
        Surface(
            color = StudioSurface.copy(alpha = 0.9f),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom - 0.25f).coerceAtLeast(0.4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Rounded.Remove, contentDescription = "Zoom out", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "${(uiState.canvasZoom * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioCyan
                )
                IconButton(
                    onClick = { onUpdateViewport((uiState.canvasZoom + 0.25f).coerceAtMost(4f), uiState.canvasPanX, uiState.canvasPanY) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Zoom in", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = onResetViewport,
                    modifier = Modifier.size(36.dp).testTag("canvas_fit_reset_btn")
                ) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Fit stage to screen", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }

        // Module 11: Corner Touch Magnifier Loupe (2.2x live zoom preview while dragging rig joints/root)
        magnifierStagePt?.let { magPt ->
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(104.dp)
                    .testTag("touch_magnifier_loupe"),
                shape = CircleShape,
                color = StudioSurface,
                border = BorderStroke(2.5.dp, StudioCyan),
                shadowElevation = 8.dp
            ) {
                Canvas(modifier = Modifier.fillMaxSize().clip(CircleShape)) {
                    drawIntoCanvas { c ->
                        val nc = c.nativeCanvas
                        val loupeScale = 2.2f
                        nc.save()
                        nc.translate(size.width / 2f - magPt.x * loupeScale, size.height / 2f - magPt.y * loupeScale)
                        nc.scale(loupeScale, loupeScale)
                        SceneRenderer.renderScene(
                            canvas = nc,
                            scene = scene,
                            frame = uiState.currentFrame,
                            projectWidth = projW,
                            projectHeight = projH,
                            fps = project.fps,
                            audioTracks = project.audioTracks,
                            onionSkin = false,
                            ghostFrames = false,
                            showRigBones = true,
                            showMotionPaths = false,
                            showSelectionBox = false,
                            showCameraFrame = false,
                            selectedLayerId = uiState.selectedLayer?.id,
                            selectedBoneId = uiState.selectedBoneId,
                            selectedTextId = null
                        )
                        nc.restore()
                    }
                    // Precision crosshair in center of loupe
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    drawLine(StudioCyan, Offset(cx - 10f, cy), Offset(cx + 10f, cy), strokeWidth = 1.5f)
                    drawLine(StudioCyan, Offset(cx, cy - 10f), Offset(cx, cy + 10f), strokeWidth = 1.5f)
                }
            }
        }

        // Module 11: Compact Micro-Nudge D-Pad (1px / 5px) for touchscreen precision alignment
        if (!uiState.isPlaying && !isCelStudioMode && selectedLayer != null &&
            (uiState.activeTool == EditorTool.SELECT || uiState.activeTool == EditorTool.RIG_EDIT)
        ) {
            Surface(
                color = StudioSurface.copy(alpha = 0.9f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, StudioBorder),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .testTag("micro_nudge_dpad")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    Surface(
                        color = StudioCyan.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onToggleMicroNudgeStep)
                            .testTag("micro_nudge_step_btn")
                    ) {
                        Text(
                            text = "${uiState.microNudgeStepPx.toInt()}px",
                            color = StudioCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                    IconButton(onClick = { onMicroNudge(-1f, 0f) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Nudge Left", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onMicroNudge(0f, -1f) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Nudge Up", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onMicroNudge(0f, 1f) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Nudge Down", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onMicroNudge(1f, 0f) }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Nudge Right", tint = StudioTextPrimary, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    // Upgraded Add Animated Text Dialog when tapping stage with TEXT tool
    pendingTextPos?.let { pos ->
        AlertDialog(
            onDismissRequest = { pendingTextPos = null },
            containerColor = StudioSurface,
            title = { Text("Add Animated Text", color = StudioTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = textDraft,
                        onValueChange = { textDraft = it },
                        label = { Text("Title, dialogue or sound FX") },
                        maxLines = 3
                    )
                    Text("Entrance Animation", style = MaterialTheme.typography.labelSmall, color = StudioCoral)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            TextInAnimation.POP_BOUNCE,
                            TextInAnimation.TYPEWRITER,
                            TextInAnimation.ZOOM_SLAM,
                            TextInAnimation.DROP_LETTERS,
                            TextInAnimation.SLIDE_UP,
                            TextInAnimation.SPIN_POP
                        ).forEach { anim ->
                            FilterChip(
                                selected = draftInAnim == anim,
                                onClick = { draftInAnim = anim },
                                label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Text("Loop Motion", style = MaterialTheme.typography.labelSmall, color = StudioViolet)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            TextLoopAnimation.NONE,
                            TextLoopAnimation.WAVE,
                            TextLoopAnimation.BOUNCE,
                            TextLoopAnimation.FLOAT,
                            TextLoopAnimation.SHAKE_HORROR,
                            TextLoopAnimation.GLITCH,
                            TextLoopAnimation.RAINBOW
                        ).forEach { anim ->
                            FilterChip(
                                selected = draftLoopAnim == anim,
                                onClick = { draftLoopAnim = anim },
                                label = { Text(anim.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = textDraft.isNotBlank(),
                    onClick = {
                        onAddText(textDraft, pos.x, pos.y, draftInAnim, draftLoopAnim)
                        pendingTextPos = null
                    }
                ) { Text("Place Animated Text") }
            },
            dismissButton = {
                TextButton(onClick = { pendingTextPos = null }) { Text("Cancel") }
            }
        )
    }

    // Quick Edit Existing Text Dialog
    editingTextId?.let { editId ->
        AlertDialog(
            onDismissRequest = { editingTextId = null },
            containerColor = StudioSurface,
            title = { Text("Edit Text Content", color = StudioTextPrimary) },
            text = {
                OutlinedTextField(
                    value = textDraft,
                    onValueChange = { textDraft = it },
                    label = { Text("Text (Enter for new line)") },
                    maxLines = 3
                )
            },
            confirmButton = {
                Button(
                    enabled = textDraft.isNotBlank(),
                    onClick = {
                        onUpdateText(editId, true) { it.copy(text = textDraft.trim()) }
                        editingTextId = null
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { editingTextId = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PuppetQuickPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        color = if (active) accent.copy(alpha = 0.2f) else Color(0xFF1A202E),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (active) accent else StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = label, tint = if (active) accent else StudioTextSecondary, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                text = label,
                color = if (active) accent else StudioTextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
